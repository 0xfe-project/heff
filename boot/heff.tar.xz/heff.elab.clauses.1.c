// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CMatch 53053
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_ExplicitParam 63083
#define TAG_ILitEq 53459
#define TAG_ImplicitParam 51130
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_PAs 26446
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_PatAs 19989
#define TAG_PatBytes 60255
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define LBL_anys 9494734
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_bad 306815
#define LBL_chk 308000
#define LBL_end 310101
#define LBL_msg 317947
#define LBL_order 307364712
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_row 322644
#define LBL_rows 10002080
#define LBL_scrutinee 73860976
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tag 324116
#define LBL_tree 10063973
#define LBL_typ 324869
#define LBL_x 338
static uint32_t shape_arms__order__anys[] = {LBL_arms, LBL_order, LBL_anys};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_row__bad__rows[] = {LBL_row, LBL_bad, LBL_rows};
static uint32_t shape_scrutinee__tree[] = {LBL_scrutinee, LBL_tree};
static uint32_t shape_span__msg[] = {LBL_span, LBL_msg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_tag__arity__pats__span[] = {LBL_tag, LBL_arity, LBL_pats, LBL_span};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eclauses_2eanyC(V, V);
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_clo;
V g_heff_2eelab_2eclauses_2eanyIn(V, V, V);
V g_heff_2eelab_2eclauses_2eanyIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyIn_clo;
V g_heff_2eelab_2eclauses_2eappendC(V, V);
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_clo;
V g_heff_2eelab_2eclauses_2earmFields(V, V, V, V);
V g_heff_2eelab_2eclauses_2earmFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmFields_clo;
V g_heff_2eelab_2eclauses_2earmSubName(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmSubName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmSubName_clo;
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_clo;
V g_heff_2eelab_2eclauses_2ecaseTreeOf(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecaseTreeOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecaseTreeOf_clo;
V g_heff_2eelab_2eclauses_2ecatMaybesC(V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo;
V g_heff_2eelab_2eclauses_2ecolName(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolName_clo;
V g_heff_2eelab_2eclauses_2ecolPick(V, V, V);
V g_heff_2eelab_2eclauses_2ecolPick_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolPick_clo;
V g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_clo;
V g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_clo;
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_clo;
V g_heff_2eelab_2eclauses_2edropAt(V, V);
V g_heff_2eelab_2eclauses_2edropAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropAt_clo;
V g_heff_2eelab_2eclauses_2edropC(V, V);
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropC_clo;
V g_heff_2eelab_2eclauses_2efindTagLit(V, V);
V g_heff_2eelab_2eclauses_2efindTagLit_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efindTagLit_clo;
V g_heff_2eelab_2eclauses_2efoldr2(V, V, V);
V g_heff_2eelab_2eclauses_2efoldr2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efoldr2_clo;
V g_heff_2eelab_2eclauses_2efreshIn(V, V, V);
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efreshIn_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_clo;
V g_heff_2eelab_2eclauses_2elitChecks(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2elitChecks_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitChecks_clo;
V g_heff_2eelab_2eclauses_2elitExpr(V);
V g_heff_2eelab_2eclauses_2elitExpr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitExpr_clo;
V g_heff_2eelab_2eclauses_2elitNo(V, V, V);
V g_heff_2eelab_2eclauses_2elitNo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitNo_clo;
V g_heff_2eelab_2eclauses_2elitNoOne(V, V, V, V);
V g_heff_2eelab_2eclauses_2elitNoOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitNoOne_clo;
V g_heff_2eelab_2eclauses_2elitYes(V, V, V, V);
V g_heff_2eelab_2eclauses_2elitYes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitYes_clo;
V g_heff_2eelab_2eclauses_2elitYesOne(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2elitYesOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitYesOne_clo;
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll(V, V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_clo;
V g_heff_2eelab_2eclauses_2enthC(V, V);
V g_heff_2eelab_2eclauses_2enthC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enthC_clo;
V g_heff_2eelab_2eclauses_2enubStr(V);
V g_heff_2eelab_2eclauses_2enubStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enubStr_clo;
V g_heff_2eelab_2eclauses_2epat(V);
V g_heff_2eelab_2eclauses_2epat_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epat_clo;
V g_heff_2eelab_2eclauses_2epatBinds(V);
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_clo;
V g_heff_2eelab_2eclauses_2epatBinds_24dps(V, V);
V g_heff_2eelab_2eclauses_2epatBinds_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_24dps_clo;
V g_heff_2eelab_2eclauses_2epatIdents(V, V);
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_clo;
V g_heff_2eelab_2eclauses_2epeelCols(V, V, V);
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epeelCols_clo;
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297(V, V);
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_clo;
V g_heff_2eelab_2eclauses_2erecSubName(V, V, V, V);
V g_heff_2eelab_2eclauses_2erecSubName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecSubName_clo;
V g_heff_2eelab_2eclauses_2erenameDecl(V, V);
V g_heff_2eelab_2eclauses_2erenameDecl_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameDecl_clo;
V g_heff_2eelab_2eclauses_2erenameEquation(V, V);
V g_heff_2eelab_2eclauses_2erenameEquation_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameEquation_clo;
V g_heff_2eelab_2eclauses_2erenameSeq(V, V, V);
V g_heff_2eelab_2eclauses_2erenameSeq_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameSeq_clo;
V g_heff_2eelab_2eclauses_2erenamer(V, V);
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamer_clo;
V g_heff_2eelab_2eclauses_2esameLit(V, V);
V g_heff_2eelab_2eclauses_2esameLit_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esameLit_clo;
V g_heff_2eelab_2eclauses_2etagArmStep(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagArmStep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagArmStep_clo;
V g_heff_2eelab_2eclauses_2etagColAt(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagColAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagColAt_clo;
V g_heff_2eelab_2eclauses_2etakeC(V, V);
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_clo;
V g_heff_2eelab_2eclauses_2etakeC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2etakeC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_24dps_clo;
V g_heff_2eelab_2eclauses_2etraverseC(V, V);
V g_heff_2eelab_2eclauses_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s246054844x100991343(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s246054844x100991343_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s246054844x100991343_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027_clo;
V g_heff_2eelab_2eclauses_2eupToGo(V, V);
V g_heff_2eelab_2eclauses_2eupToGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eupToGo_clo;
V g_heff_2eelab_2eclauses_2ezipC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2ezipC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ezipC_24dps_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2emapValues(V, V);
V g_map_2emapValues_entry(V self, V *a);
extern Clo g_map_2emapValues_clo;
Clo g_heff_2eelab_2eclauses_2etraverseC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etraverseC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2etraverseC(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x1_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Left: {
      V v_e_245 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24Left = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_tag_at_n(v_ru_24x1_244_24Left, TAG_Left, 1, (V[]){v_e_245});
    }
    case TAG_Right: {
      V v_x_246 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24Right = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      V v_x1_247 = (g_heff_2eelab_2eclauses_2etraverseC(v_f_240, v_xs_243));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Left: {
        V v_e_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_x_246);
        return heff_tag_at_n(v_ru_24x1_244_24Right, TAG_Left, 1, (V[]){v_e_248});
      }
      case TAG_Right: {
        V v_x_249 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_244_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_x_249})});
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2etraverseC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etraverseC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2enthC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enthC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enthC(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2enthC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enthC(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2ezipC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ezipC_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2ezipC_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ezipC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ezipC_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2etakeC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etakeC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2etakeC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_heff_2eelab_2eclauses_2etakeC_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etakeC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2edropC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edropC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2edropC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2edropC(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2epat_str0, 86, "a pattern is a variable, a literal, a tag applied to patterns, or a record of patterns");
HEFF_LIT(g_heff_2eelab_2eclauses_2epat_str1, 86, "a pattern is a variable, a literal, a tag applied to patterns, or a record of patterns");
Clo g_heff_2eelab_2eclauses_2epat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epat_entry, 1, 0};

V g_heff_2eelab_2eclauses_2epat(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_dup(heff_field(v_p_240, 0));
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      V v_ru_24p1_241_24PatVar = heff_take_reuse_n(v_p1_241, 1ULL, 1);
      heff_drop_tag(v_p_240, 2);
      return heff_tag_at_n(v_ru_24p1_241_24PatVar, TAG_Right, 1, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){v_x_243})});
    }
    case TAG_PatTag: {
      V v_t_244 = heff_field(v_p1_241, 0);
      V v_tsp_245 = heff_field(v_p1_241, 1);
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_ru_24p1_241_24PatTag = heff_take_reuse_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_x1_247 = (g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381(v_ps_246));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Left: {
        V v_e_248 = heff_field(v_x1_247, 0);
        V v_ru_24x1_247_24Left = heff_take_reuse_n(v_x1_247, 1ULL, 1);
        heff_drop(v_t_244);
        heff_drop(v_tsp_245);
        heff_drop_cell(v_ru_24p1_241_24PatTag, 3);
        return heff_tag_at_n(v_ru_24x1_247_24Left, TAG_Left, 1, (V[]){v_e_248});
      }
      case TAG_Right: {
        V v_x_249 = heff_field(v_x1_247, 0);
        V v_ru_24x1_247_24Right = heff_take_reuse_n(v_x1_247, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_247_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24p1_241_24PatTag, TAG_PTag, 3, (V[]){v_t_244, v_x_249, v_tsp_245})});
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    case TAG_PatOp: {
      heff_take_n(v_p1_241, 0ULL, 3);
      V v_span_2415;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2414 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_span_2415 = v_s_2414;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_span_2415, ((V)&g_heff_2eelab_2eclauses_2epat_str0)})});
    }
    case TAG_PatInt: {
      V v_ru_24p1_241_24PatInt = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24p1_241_24PatInt, TAG_Right, 1, (V[]){heff_tag_n(TAG_PLit, 1, (V[]){v_p_240})});
    }
    case TAG_PatFloat: {
      V v_ru_24p1_241_24PatFloat = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24p1_241_24PatFloat, TAG_Right, 1, (V[]){heff_tag_n(TAG_PLit, 1, (V[]){v_p_240})});
    }
    case TAG_PatString: {
      V v_ru_24p1_241_24PatString = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24p1_241_24PatString, TAG_Right, 1, (V[]){heff_tag_n(TAG_PLit, 1, (V[]){v_p_240})});
    }
    case TAG_PatBytes: {
      V v_ru_24p1_241_24PatBytes = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24p1_241_24PatBytes, TAG_Right, 1, (V[]){heff_tag_n(TAG_PLit, 1, (V[]){v_p_240})});
    }
    case TAG_PatRune: {
      V v_ru_24p1_241_24PatRune = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24p1_241_24PatRune, TAG_Right, 1, (V[]){heff_tag_n(TAG_PLit, 1, (V[]){v_p_240})});
    }
    case TAG_PatRecord: {
      V v_fs_2421 = heff_field(v_p1_241, 0);
      V v_ru_24p1_241_24PatRecord = heff_take_reuse_n(v_p1_241, 1ULL, 1);
      V v_x1_2422 = (g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027(v_fs_2421));
      switch (heff_tag_of(v_x1_2422)) {
      case TAG_Left: {
        V v_e_2423 = heff_field(v_x1_2422, 0);
        heff_take_n(v_x1_2422, 1ULL, 1);
        heff_drop_tag(v_p_240, 2);
        return heff_tag_at_n(v_ru_24p1_241_24PatRecord, TAG_Left, 1, (V[]){v_e_2423});
      }
      case TAG_Right: {
        V v_x_2424 = heff_field(v_x1_2422, 0);
        heff_take_n(v_x1_2422, 1ULL, 1);
        V v_t_2427;
        switch (heff_tag_of(v_p_240)) {
        case TAG_At: {
          V v_s_2426 = heff_field(v_p_240, 1);
          heff_take_n(v_p_240, 2ULL, 2);
          v_t_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_p_240);
        }
        return heff_tag_at_n(v_ru_24p1_241_24PatRecord, TAG_Right, 1, (V[]){heff_tag_n(TAG_PRec, 2, (V[]){v_x_2424, v_t_2427})});
      }
      default: return heff_nomatch(v_x1_2422);
      }
    }
    case TAG_PatWord: {
      V v_ru_24p1_241_24PatWord = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      V v_span_2431;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2430 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_span_2431 = v_s_2430;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_tag_at_n(v_ru_24p1_241_24PatWord, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_span_2431, ((V)&g_heff_2eelab_2eclauses_2epat_str1)})});
    }
    case TAG_PatAs: {
      V v_x_2432 = heff_field(v_p1_241, 0);
      V v_q_2434 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 5ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_x1_2435 = (g_heff_2eelab_2eclauses_2epat(v_q_2434));
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_Left: {
        V v_e_2436 = heff_field(v_x1_2435, 0);
        V v_ru_24x1_2435_24Left = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
        heff_drop(v_x_2432);
        return heff_tag_at_n(v_ru_24x1_2435_24Left, TAG_Left, 1, (V[]){v_e_2436});
      }
      case TAG_Right: {
        V v_x_2437 = heff_field(v_x1_2435, 0);
        V v_ru_24x1_2435_24Right = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2435_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_PAs, 2, (V[]){v_x_2432, v_x_2437})});
      }
      default: return heff_nomatch(v_x1_2435);
      }
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epat(a[0]);
}
Clo g_heff_2eelab_2eclauses_2esameLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esameLit_entry, 2, 0};

V g_heff_2eelab_2eclauses_2esameLit(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      return NTAG(TAG_False);
    }
    case TAG_PatTag: {
      return NTAG(TAG_False);
    }
    case TAG_PatOp: {
      return NTAG(TAG_False);
    }
    case TAG_PatInt: {
      V v_x_2411 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2412 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2412)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          V v_y_2421 = heff_field(v_x21_2412, 0);
          return heff_intEq(heff_dup(v_x_2411), heff_dup(v_y_2421));
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          return NTAG(TAG_False);
        }
        case TAG_PatBytes: {
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2412);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatFloat: {
      V v_x_2431 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2432 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2432)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          V v_y_2442 = heff_field(v_x21_2432, 0);
          return heff_bool((heff_peek_f64(v_x_2431) == heff_peek_f64(v_y_2442)));
        }
        case TAG_PatString: {
          return NTAG(TAG_False);
        }
        case TAG_PatBytes: {
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2432);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatString: {
      V v_x_2451 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2452 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2452)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          V v_y_2463 = heff_field(v_x21_2452, 0);
          return heff_strEq(heff_dup(v_x_2451), heff_dup(v_y_2463));
        }
        case TAG_PatBytes: {
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2452);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatBytes: {
      V v_x_2471 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2472 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2472)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          return NTAG(TAG_False);
        }
        case TAG_PatBytes: {
          V v_y_2484 = heff_field(v_x21_2472, 0);
          return heff_strEq(heff_dup(v_x_2471), heff_dup(v_y_2484));
        }
        case TAG_PatRune: {
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2472);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatRune: {
      V v_x_2491 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2492 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2492)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          return NTAG(TAG_False);
        }
        case TAG_PatBytes: {
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          V v_y_24105 = heff_field(v_x21_2492, 0);
          return heff_intEq(heff_dup(v_x_2491), heff_dup(v_y_24105));
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2492);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatRecord: {
      return NTAG(TAG_False);
    }
    case TAG_PatWord: {
      return NTAG(TAG_False);
    }
    case TAG_PatAs: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2esameLit_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2esameLit(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_entry, 3, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll(V v_f_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){heff_dup(v_x_243), v_acc_242}));
    V t_0 = v_f_240;
    V t_1 = v_xs_244;
    V t_2 = v_t_245;
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2enamesOfAll(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_entry, 2, 0};

V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_t_244 = heff_field(v_x2_240, 2);
    V v_t_245 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_244, v_acc_241));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_242), v_t_245});
  }
  case TAG_PiImplicit: {
    V v_x_246 = heff_field(v_x2_240, 0);
    V v_t_249 = heff_field(v_x2_240, 3);
    V v_d_2410 = heff_field(v_x2_240, 4);
    V v_acc_2412;
    switch (heff_tag_of(v_d_2410)) {
    case TAG_Nothing: {
      v_acc_2412 = v_acc_241;
      break;
    }
    case TAG_Just: {
      V v_c_2411 = heff_field(v_d_2410, 0);
      v_acc_2412 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_c_2411), v_acc_241));
      break;
    }
    default: heff_nomatch(v_d_2410);
    }
    V v_t_2413 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_249, v_acc_2412));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_246), v_t_2413});
  }
  case TAG_PiInstance: {
    V v_x_2414 = heff_field(v_x2_240, 0);
    V v_t_2417 = heff_field(v_x2_240, 3);
    V v_t_2418 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_2417, v_acc_241));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2414), v_t_2418});
  }
  case TAG_PiAnon: {
    V v_d_2419 = heff_field(v_x2_240, 0);
    HEFF_LAST return g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_d_2419, v_acc_241);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_t_248 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_a_247), v_acc_241));
        v_t_249 = (g_heff_2eelab_2eclauses_2epatIdents(heff_dup(v_a_246), v_t_248));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_249;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2epatBinds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatBinds_entry, 1, 0};

V g_heff_2eelab_2eclauses_2epatBinds(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 1ULL, 2);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
    }
    case TAG_PatTag: {
      V v_ps_246 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_ps_246; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a_0)); heff_drop(v_ps_246); r_; });
    }
    case TAG_PatOp: {
      V v_ps_249 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_ps_249; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a_0)); heff_drop(v_ps_249); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBytes: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2415 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_fs_2415; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(a_0)); heff_drop(v_fs_2415); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2417 = heff_field(v_p1_241, 0);
      V v_q_2419 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 5ULL, 3);
      V v_cell_2420 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_2417, heff_hole()});
      V v_u_2421 = (g_heff_2eelab_2eclauses_2epatBinds_24dps(v_q_2419, heff_dup(v_cell_2420)));
      heff_drop(v_u_2421);
      return v_cell_2420;
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatBinds(a[0]);
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameDecl_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameDecl_lam2(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameDecl_lam3(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameDecl_lam4(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameDecl_lam5(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameDecl_lam6(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameDecl_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameDecl(V v_r_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_d1_242 = heff_dup(heff_field(v_d_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_d_241, 1));
    switch (heff_tag_of(v_d1_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_d1_242, 0);
      V v_fsp_245 = heff_field(v_d1_242, 1);
      V v_declared_246 = heff_field(v_d1_242, 2);
      V v_ty_247 = heff_field(v_d1_242, 3);
      V v_eqs_248 = heff_field(v_d1_242, 4);
      V v_ru_24d1_242_24DeclEquations = heff_take_reuse_n(v_d1_242, 31ULL, 5);
      heff_drop_tag(v_d_241, 2);
      V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 4)), 1, (V[]){v_ty_247}));
      V v_t_2412;
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 0)), heff_dup(v_f_244))) {
        heff_drop_rec(v_r_240, 5);
        v_t_2412 = v_eqs_248;
      } else {
        V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2eelab_2eclauses_2erenameEquation_clo), 1, (V[]){v_r_240}));
        v_t_2412 = (g_list_2emap(v_t_2411, v_eqs_248));
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_244, v_fsp_245, v_declared_246, v_t_249, v_t_2412}), v_sp_243});
    }
    case TAG_DeclDefine: {
      V v_y_2413 = heff_field(v_d1_242, 0);
      V v_ysp_2414 = heff_field(v_d1_242, 1);
      V v_ps_2415 = heff_field(v_d1_242, 2);
      V v_u_2416 = heff_field(v_d1_242, 3);
      V v_body_2417 = heff_field(v_d1_242, 4);
      V v_ru_24d1_242_24DeclDefine = heff_take_reuse_n(v_d1_242, 31ULL, 5);
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 0)), heff_dup(v_y_2413))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop(v_y_2413);
        heff_drop(v_ysp_2414);
        heff_drop(v_ps_2415);
        heff_drop(v_u_2416);
        heff_drop(v_body_2417);
        heff_drop_cell(v_ru_24d1_242_24DeclDefine, 5);
        return v_d_241;
      } else {
        heff_drop_tag(v_d_241, 2);
        V v_x_2419 = heff_dup(heff_rfield(v_r_240, 0));
        V v_t_2440 = (g_heff_2eelab_2eclauses_2erenameSeq(heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam1, 1, 1, (V[]){v_x_2419}), heff_dup(v_ps_2415)));
        V v_x_2441 = heff_dup(heff_rfield(v_r_240, 0));
        V v_t_2451 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam2, 1, 1, (V[]){v_x_2441}), v_ps_2415));
        V v_t_2452;
        if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
          heff_drop(v_t_2451);
          v_t_2452 = v_u_2416;
        } else {
          heff_drop(v_t_2451);
          v_t_2452 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 4)), 1, (V[]){v_u_2416}));
        }
        V v_x_2453 = heff_take_field(v_r_240, 0);
        V v_t_2463 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam3, 1, 1, (V[]){v_x_2453}); V a_1 = v_ps_2415; V r_ = (g_heff_2eelab_2eclauses_2eanyC(a_0, a_1)); heff_drop(v_ps_2415); r_; });
        V v_t_2464;
        if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
          heff_drop_rec(v_r_240, 5);
          heff_drop(v_t_2463);
          v_t_2464 = v_body_2417;
        } else {
          heff_drop(v_t_2463);
          v_t_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_body_2417}));
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_y_2413, v_ysp_2414, v_t_2440, v_t_2452, v_t_2464}), v_sp_243});
      }
    }
    case TAG_DeclTheory: {
      V v_y_2465 = heff_field(v_d1_242, 0);
      V v_ysp_2466 = heff_field(v_d1_242, 1);
      V v_ps_2467 = heff_field(v_d1_242, 2);
      V v_body_2468 = heff_field(v_d1_242, 3);
      V v_ru_24d1_242_24DeclTheory = heff_take_reuse_n(v_d1_242, 15ULL, 4);
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 0)), heff_dup(v_y_2465))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop(v_y_2465);
        heff_drop(v_ysp_2466);
        heff_drop(v_ps_2467);
        heff_drop(v_body_2468);
        heff_drop_cell(v_ru_24d1_242_24DeclTheory, 4);
        return v_d_241;
      } else {
        heff_drop_tag(v_d_241, 2);
        V v_x_2470 = heff_dup(heff_rfield(v_r_240, 0));
        V v_t_2491 = (g_heff_2eelab_2eclauses_2erenameSeq(heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam4, 1, 1, (V[]){heff_dup(v_r_240)}), heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam5, 1, 1, (V[]){v_x_2470}), heff_dup(v_ps_2467)));
        V v_x_2492 = heff_take_field(v_r_240, 0);
        V v_t_24102 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam6, 1, 1, (V[]){v_x_2492}); V a_1 = v_ps_2467; V r_ = (g_heff_2eelab_2eclauses_2eanyC(a_0, a_1)); heff_drop(v_ps_2467); r_; });
        V v_t_24103;
        if ((heff_dup(v_t_24102) == NTAG(TAG_True))) {
          heff_drop_rec(v_r_240, 5);
          heff_drop(v_t_24102);
          v_t_24103 = v_body_2468;
        } else {
          heff_drop(v_t_24102);
          v_t_24103 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_body_2468}));
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_y_2465, v_ysp_2466, v_t_2491, v_t_24103}), v_sp_243});
      }
    }
    case TAG_DeclPrimitive: {
      V v_y_24104 = heff_field(v_d1_242, 0);
      V v_ysp_24105 = heff_field(v_d1_242, 1);
      V v_t_24106 = heff_field(v_d1_242, 2);
      V v_ru_24d1_242_24DeclPrimitive = heff_take_reuse_n(v_d1_242, 7ULL, 3);
      heff_drop_tag(v_d_241, 2);
      V v_t_24107 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_24106}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_y_24104, v_ysp_24105, v_t_24107}), v_sp_243});
    }
    case TAG_DeclTest: {
      heff_take_n(v_d1_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_d_241;
    }
    case TAG_DeclWatch: {
      V v_e_24110 = heff_field(v_d1_242, 0);
      V v_ru_24d1_242_24DeclWatch = heff_take_reuse_n(v_d1_242, 1ULL, 1);
      heff_drop_tag(v_d_241, 2);
      V v_t_24111 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_e_24110}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_24111}), v_sp_243});
    }
    default: return heff_nomatch(v_d1_242);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameDecl(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam0(V self, V *args) {
  V v_x2_2420 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_At: {
    V v_x21_2421 = heff_field(v_x2_2420, 0);
    V v_sp_2422 = heff_field(v_x2_2420, 1);
    V v_ru_24x2_2420_24At = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
    switch (heff_tag_of(v_x21_2421)) {
    case TAG_ExplicitParam: {
      V v_y_2423 = heff_field(v_x21_2421, 0);
      V v_ysp_2424 = heff_field(v_x21_2421, 1);
      V v_t_2425 = heff_field(v_x21_2421, 2);
      heff_take_n(v_x21_2421, 7ULL, 3);
      V v_t_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2425}));
      return heff_tag_at_n(v_ru_24x2_2420_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_y_2423, v_ysp_2424, v_t_2426}), v_sp_2422});
    }
    case TAG_ImplicitParam: {
      V v_y_2427 = heff_field(v_x21_2421, 0);
      V v_ysp_2428 = heff_field(v_x21_2421, 1);
      V v_t_2429 = heff_field(v_x21_2421, 2);
      heff_take_n(v_x21_2421, 7ULL, 3);
      V v_t_2430 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2429}));
      return heff_tag_at_n(v_ru_24x2_2420_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ImplicitParam, 3, (V[]){v_y_2427, v_ysp_2428, v_t_2430}), v_sp_2422});
    }
    default: return heff_nomatch(v_x21_2421);
    }
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam1(V self, V *args) {
  V v_x2_2431 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_At: {
    V v_x21_2432 = heff_field(v_x2_2431, 0);
    heff_take_n(v_x2_2431, 1ULL, 2);
    switch (heff_tag_of(v_x21_2432)) {
    case TAG_ExplicitParam: {
      V v_y_2434 = heff_field(v_x21_2432, 0);
      heff_take_n(v_x21_2432, 1ULL, 3);
      return heff_strEq(v_x_2419, v_y_2434);
    }
    case TAG_ImplicitParam: {
      V v_y_2437 = heff_field(v_x21_2432, 0);
      heff_take_n(v_x21_2432, 1ULL, 3);
      return heff_strEq(v_x_2419, v_y_2437);
    }
    default: return heff_nomatch(v_x21_2432);
    }
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam2(V self, V *args) {
  V v_x2_2442 = args[0];
  V v_x_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_At: {
    V v_x21_2443 = heff_field(v_x2_2442, 0);
    heff_take_n(v_x2_2442, 1ULL, 2);
    switch (heff_tag_of(v_x21_2443)) {
    case TAG_ExplicitParam: {
      V v_y_2445 = heff_field(v_x21_2443, 0);
      heff_take_n(v_x21_2443, 1ULL, 3);
      return heff_strEq(v_x_2441, v_y_2445);
    }
    case TAG_ImplicitParam: {
      V v_y_2448 = heff_field(v_x21_2443, 0);
      heff_take_n(v_x21_2443, 1ULL, 3);
      return heff_strEq(v_x_2441, v_y_2448);
    }
    default: return heff_nomatch(v_x21_2443);
    }
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam3(V self, V *args) {
  V v_x2_2454 = args[0];
  V v_x_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2454)) {
  case TAG_At: {
    V v_x21_2455 = heff_field(v_x2_2454, 0);
    heff_take_n(v_x2_2454, 1ULL, 2);
    switch (heff_tag_of(v_x21_2455)) {
    case TAG_ExplicitParam: {
      V v_y_2457 = heff_field(v_x21_2455, 0);
      heff_take_n(v_x21_2455, 1ULL, 3);
      return heff_strEq(v_x_2453, v_y_2457);
    }
    case TAG_ImplicitParam: {
      V v_y_2460 = heff_field(v_x21_2455, 0);
      heff_take_n(v_x21_2455, 1ULL, 3);
      return heff_strEq(v_x_2453, v_y_2460);
    }
    default: return heff_nomatch(v_x21_2455);
    }
  }
  default: return heff_nomatch(v_x2_2454);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam4(V self, V *args) {
  V v_x2_2471 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_At: {
    V v_x21_2472 = heff_field(v_x2_2471, 0);
    V v_sp_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24At = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    switch (heff_tag_of(v_x21_2472)) {
    case TAG_ExplicitParam: {
      V v_y_2474 = heff_field(v_x21_2472, 0);
      V v_ysp_2475 = heff_field(v_x21_2472, 1);
      V v_t_2476 = heff_field(v_x21_2472, 2);
      heff_take_n(v_x21_2472, 7ULL, 3);
      V v_t_2477 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2476}));
      return heff_tag_at_n(v_ru_24x2_2471_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_y_2474, v_ysp_2475, v_t_2477}), v_sp_2473});
    }
    case TAG_ImplicitParam: {
      V v_y_2478 = heff_field(v_x21_2472, 0);
      V v_ysp_2479 = heff_field(v_x21_2472, 1);
      V v_t_2480 = heff_field(v_x21_2472, 2);
      heff_take_n(v_x21_2472, 7ULL, 3);
      V v_t_2481 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2480}));
      return heff_tag_at_n(v_ru_24x2_2471_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ImplicitParam, 3, (V[]){v_y_2478, v_ysp_2479, v_t_2481}), v_sp_2473});
    }
    default: return heff_nomatch(v_x21_2472);
    }
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam5(V self, V *args) {
  V v_x2_2482 = args[0];
  V v_x_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2482)) {
  case TAG_At: {
    V v_x21_2483 = heff_field(v_x2_2482, 0);
    heff_take_n(v_x2_2482, 1ULL, 2);
    switch (heff_tag_of(v_x21_2483)) {
    case TAG_ExplicitParam: {
      V v_y_2485 = heff_field(v_x21_2483, 0);
      heff_take_n(v_x21_2483, 1ULL, 3);
      return heff_strEq(v_x_2470, v_y_2485);
    }
    case TAG_ImplicitParam: {
      V v_y_2488 = heff_field(v_x21_2483, 0);
      heff_take_n(v_x21_2483, 1ULL, 3);
      return heff_strEq(v_x_2470, v_y_2488);
    }
    default: return heff_nomatch(v_x21_2483);
    }
  }
  default: return heff_nomatch(v_x2_2482);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam6(V self, V *args) {
  V v_x2_2493 = args[0];
  V v_x_2492 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_At: {
    V v_x21_2494 = heff_field(v_x2_2493, 0);
    heff_take_n(v_x2_2493, 1ULL, 2);
    switch (heff_tag_of(v_x21_2494)) {
    case TAG_ExplicitParam: {
      V v_y_2496 = heff_field(v_x21_2494, 0);
      heff_take_n(v_x21_2494, 1ULL, 3);
      return heff_strEq(v_x_2492, v_y_2496);
    }
    case TAG_ImplicitParam: {
      V v_y_2499 = heff_field(v_x21_2494, 0);
      heff_take_n(v_x21_2494, 1ULL, 3);
      return heff_strEq(v_x_2492, v_y_2499);
    }
    default: return heff_nomatch(v_x21_2494);
    }
  }
  default: return heff_nomatch(v_x2_2493);
  }
}
Clo g_heff_2eelab_2eclauses_2efindTagLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efindTagLit_entry, 2, 0};

V g_heff_2eelab_2eclauses_2efindTagLit(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_2413;
    switch (heff_tag_of(v_p_242)) {
    case TAG_PVar: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_PTag: {
      v_t_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_PLit: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_PRec: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_PAs: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_p_242);
    }
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
    } else {
      heff_drop(v_t_2413);
      switch (heff_tag_of(v_p_242)) {
      case TAG_PVar: {
        switch (heff_tag_of(v_p_242)) {
        case TAG_PVar: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PTag: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PLit: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PRec: {
          return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
        }
        case TAG_PAs: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_p_242);
        }
      }
      case TAG_PTag: {
        switch (heff_tag_of(v_p_242)) {
        case TAG_PVar: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PTag: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PLit: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PRec: {
          return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
        }
        case TAG_PAs: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_p_242);
        }
      }
      case TAG_PLit: {
        return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
      }
      case TAG_PRec: {
        switch (heff_tag_of(v_p_242)) {
        case TAG_PVar: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PTag: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PLit: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PRec: {
          return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
        }
        case TAG_PAs: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_p_242);
        }
      }
      case TAG_PAs: {
        switch (heff_tag_of(v_p_242)) {
        case TAG_PVar: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PTag: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PLit: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PRec: {
          return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
        }
        case TAG_PAs: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_p_242);
        }
      }
      default: return heff_nomatch(v_p_242);
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2efindTagLit_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2efindTagLit(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2earmFields_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2earmFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2earmFields_entry, 4, 0};

V g_heff_2eelab_2eclauses_2earmFields(V v_used_240, V v_bound_241, V v_t_242, V v_v_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2eclauses_2eupToGo(MK_INT(0LL), heff_dup(heff_rfield(v_t_242, 1))));
  return (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2earmFields_lam0, 1, 4, (V[]){v_t_242, heff_dup(v_used_240), heff_dup(v_bound_241), v_v_243}), v_t_244));
}
V g_heff_2eelab_2eclauses_2earmFields_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2earmFields(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eclauses_2earmFields_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_t_242 = heff_env(self)[0];
  V v_used_240 = heff_env(self)[1];
  V v_bound_241 = heff_env(self)[2];
  V v_v_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = ({ V b_0 = heff_get_n(v_t_242, 2, 4); V a_1 = heff_dup(v_i_245); V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    V v_t_247 = heff_intShow(heff_intAdd(v_i_245, MK_INT(1LL)));
    return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = heff_strAppend(v_v_243, v_t_247); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_240); heff_drop(v_bound_241); r_; });
  }
  case TAG_Just: {
    V v_p_248 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_p_248)) {
    case TAG_PVar: {
      V v_x_249 = heff_field(v_p_248, 0);
      heff_take_n(v_p_248, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_x_249});
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_p_248, 0ULL, 3);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_p_248, 0ULL, 1);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_p_248, 0ULL, 2);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_PAs: {
      V v_x_2416 = heff_field(v_p_248, 0);
      heff_take_n(v_p_248, 1ULL, 2);
      v_t_2418 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_x_2416});
      break;
    }
    default: heff_nomatch(v_p_248);
    }
    return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_v_243; V a_3 = v_i_245; V a_4 = v_t_2418; V r_ = (g_heff_2eelab_2eclauses_2earmSubName(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_used_240); heff_drop(v_bound_241); heff_drop(v_t_2418); r_; });
  }
  default: return heff_nomatch(v_t_246);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2etagColAt_str0, 1, "_");
V g_heff_2eelab_2eclauses_2etagColAt_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2etagColAt_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2etagColAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etagColAt_entry, 5, 0};

V g_heff_2eelab_2eclauses_2etagColAt(V v_c_240, V v_v_241, V v_col_242, V v_r_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_PVar: {
    V v_x_245 = heff_field(v_x5_244, 0);
    V v_e_246 = heff_take_field(v_r_243, 1);
    V v_rhs_2410;
    if (heff_strEq_c(heff_dup(v_x_245), ((V)&g_heff_2eelab_2eclauses_2etagColAt_str0))) {
      heff_drop(v_v_241);
      v_rhs_2410 = v_e_246;
    } else {
      if (heff_strEq_c(heff_dup(v_x_245), heff_dup(v_v_241))) {
        heff_drop(v_v_241);
        v_rhs_2410 = v_e_246;
      } else {
        V v_t_249 = (g_heff_2eelab_2eclauses_2erenamer(heff_dup(v_x_245), v_v_241));
        v_rhs_2410 = heff_tr(heff_call(heff_get_n(v_t_249, 3, 5), 1, (V[]){v_e_246}));
      }
    }
    V v_a_2411 = ({ V rv_1 = v_rhs_2410; V rr_ = heff_rec_reuse_nf(v_r_243, 1ULL, 2, shape_pats__rhs, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2416 = (g_map_2emapValues(heff_clo_n(g_heff_2eelab_2eclauses_2etagColAt_lam0, 1, 2, (V[]){v_c_240, heff_dup(v_a_2411)}), heff_take_field(v_col_242, 0)));
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2411, heff_take_field(v_col_242, 2)});
    return ({ V rv_0 = v_t_2416; V rv_2 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_col_242, 2ULL, 3, shape_arms__order__anys, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  case TAG_PTag: {
    V v_t_2418 = heff_field(v_x5_244, 0);
    V v_ps_2419 = heff_field(v_x5_244, 1);
    V v_sp_2420 = heff_field(v_x5_244, 2);
    heff_drop(v_v_241);
    V v_t_2421 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ps_2419));
    V v_xs_2422 = heff_take_field(v_r_243, 0);
    V v_t_2423 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2422)));
    V v_t_2424 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2422));
    V v_t_2425 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_ps_2419), v_t_2424));
    V v_pats_2426 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2423, v_t_2425));
    V v_t_2427 = ({ V rv_0 = v_pats_2426; V rr_ = heff_rec_reuse_nf(v_r_243, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2428 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_t_2418), heff_rfield(v_col_242, 0)));
    return ({ V a_0 = v_c_240; V a_1 = v_col_242; V a_2 = heff_rec_n(4, shape_tag__arity__pats__span, (V[]){heff_dup(v_t_2418), v_t_2421, heff_dup(v_ps_2419), heff_dup(v_sp_2420)}); V a_3 = v_t_2427; V a_4 = v_t_2428; V r_ = (g_heff_2eelab_2eclauses_2etagArmStep(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2428); r_; });
  }
  case TAG_PLit: {
    heff_drop(v_v_241);
    V v_t_2434 = (g_map_2emapValues(heff_clo_n(g_heff_2eelab_2eclauses_2etagColAt_lam1, 1, 2, (V[]){v_c_240, heff_dup(v_r_243)}), heff_take_field(v_col_242, 0)));
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243, heff_take_field(v_col_242, 2)});
    return ({ V rv_0 = v_t_2434; V rv_2 = v_t_2435; V rr_ = heff_rec_reuse_nf(v_col_242, 2ULL, 3, shape_arms__order__anys, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  case TAG_PRec: {
    heff_drop(v_c_240);
    heff_drop(v_v_241);
    heff_drop_rec(v_r_243, 2);
    return v_col_242;
  }
  case TAG_PAs: {
    heff_drop(v_c_240);
    heff_drop(v_v_241);
    heff_drop_rec(v_r_243, 2);
    return v_col_242;
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eclauses_2etagColAt_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2etagColAt(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2eelab_2eclauses_2etagColAt_lam0(V self, V *args) {
  V v_arm_2412 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_a_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_arm_2412, 0)), 1, 4);
  V v_t_2414 = (g_heff_2eelab_2eclauses_2eanyIn(v_c_240, v_t_2413, v_a_2411));
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_arm_2412, 2)});
  return ({ V rv_2 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_arm_2412, 3ULL, 3, shape_row__bad__rows, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eclauses_2etagColAt_lam1(V self, V *args) {
  V v_arm_2430 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_r_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_get_n(heff_dup(heff_rfield(v_arm_2430, 0)), 1, 4);
  V v_t_2432 = (g_heff_2eelab_2eclauses_2eanyIn(v_c_240, v_t_2431, v_r_243));
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, heff_take_field(v_arm_2430, 2)});
  return ({ V rv_2 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_arm_2430, 3ULL, 3, shape_row__bad__rows, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
Clo g_heff_2eelab_2eclauses_2elitYes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitYes_entry, 4, 0};

V g_heff_2eelab_2eclauses_2elitYes(V v_c_240, V v_l_241, V v_v_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_v_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_t_246 = (g_heff_2eelab_2eclauses_2elitYes(heff_dup(v_c_240), v_l_241, heff_dup(v_v_242), v_rest_245));
    return (g_heff_2eelab_2eclauses_2elitYesOne(v_c_240, v_l_241, v_v_242, heff_dup(v_r_244), v_t_246));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eclauses_2elitYes_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2eelab_2eclauses_2elitYes(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2eelab_2eclauses_2elitNoOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitNoOne_entry, 4, 0};

V g_heff_2eelab_2eclauses_2elitNoOne(V v_c_240, V v_l_241, V v_r_242, V v_acc_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_242, 0), v_c_240));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
  }
  case TAG_Just: {
    V v_p_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    switch (heff_tag_of(v_p_245)) {
    case TAG_PVar: {
      heff_take_n(v_p_245, 0ULL, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
    }
    case TAG_PTag: {
      heff_take_n(v_p_245, 0ULL, 3);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
    }
    case TAG_PLit: {
      V v_l_27_2410 = heff_field(v_p_245, 0);
      heff_take_n(v_p_245, 1ULL, 1);
      V v_t_2411 = ({ V a_0 = v_l_241; V a_1 = v_l_27_2410; V r_ = (g_heff_2eelab_2eclauses_2esameLit(a_0, a_1)); heff_drop(v_l_27_2410); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop_rec(v_r_242, 2);
        heff_drop(v_t_2411);
        return v_acc_243;
      } else {
        heff_drop(v_t_2411);
        return heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
      }
    }
    case TAG_PRec: {
      V v_ru_24p_245_24PRec = heff_take_reuse_n(v_p_245, 0ULL, 2);
      return heff_tag_at_n(v_ru_24p_245_24PRec, TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
    }
    case TAG_PAs: {
      V v_ru_24p_245_24PAs = heff_take_reuse_n(v_p_245, 0ULL, 2);
      return heff_tag_at_n(v_ru_24p_245_24PAs, TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
    }
    default: return heff_nomatch(v_p_245);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2eclauses_2elitNoOne_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2elitNoOne(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2elitNo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitNo_entry, 3, 0};

V g_heff_2eelab_2eclauses_2elitNo(V v_c_240, V v_l_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2eelab_2eclauses_2elitNo(heff_dup(v_c_240), v_l_241, v_rest_244));
    return (g_heff_2eelab_2eclauses_2elitNoOne(v_c_240, v_l_241, heff_dup(v_r_243), v_t_245));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2elitNo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2elitNo(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSubName_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2erecSubName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSubName_entry, 4, 0};

V g_heff_2eelab_2eclauses_2erecSubName(V v_used_240, V v_bound_241, V v_x3_242, V v_f_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, v_f_243));
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x3_242, 0);
    if (heff_strEq_c(heff_dup(v_x_244), ((V)&g_heff_2eelab_2eclauses_2erecSubName_str0))) {
      return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, v_f_243));
    } else {
      V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_244)}));
      V v_x1_247 = (g_list_2eany(v_t_246, v_bound_241));
      if ((heff_dup(v_x1_247) == NTAG(TAG_True))) {
        heff_drop(v_x1_247);
        return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, v_f_243));
      } else {
        heff_drop(v_f_243);
        heff_drop(v_x1_247);
        return heff_dup(v_x_244);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2erecSubName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2erecSubName(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2eclauses_2ecolName_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ecolName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecolName_entry, 4, 0};

V g_heff_2eelab_2eclauses_2ecolName(V v_used_240, V v_params_241, V v_rows_242, V v_i_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2eclauses_2enthC(v_params_241, heff_dup(v_i_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ecolName_lam0, 1, 1, (V[]){heff_dup(v_i_243)}), v_rows_242));
    V v_t_2418 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2417));
    V v_t_2419 = (g_heff_2eelab_2eclauses_2enubStr(v_t_2418));
    return ({ V a_0 = v_used_240; V a_1 = v_i_243; V a_2 = v_t_2419; V r_ = (g_heff_2eelab_2eclauses_2ecolPick(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
  }
  case TAG_Just: {
    V v_p_2420 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_rows_242);
    heff_drop(v_i_243);
    return v_p_2420;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2eclauses_2ecolName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2ecolName(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eclauses_2ecolName_lam0(V self, V *args) {
  V v_r_245 = args[0];
  V v_i_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = ({ V b_0 = heff_get_n(v_r_245, 0, 2); V a_1 = v_i_243; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_p_247 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
    switch (heff_tag_of(v_p_247)) {
    case TAG_PVar: {
      V v_x_248 = heff_field(v_p_247, 0);
      heff_take_n(v_p_247, 1ULL, 1);
      return heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_x_248});
    }
    case TAG_PTag: {
      heff_take_n(v_p_247, 0ULL, 3);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_PLit: {
      heff_take_n(v_p_247, 0ULL, 1);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_PRec: {
      heff_take_n(v_p_247, 0ULL, 2);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_PAs: {
      V v_x_2415 = heff_field(v_p_247, 0);
      heff_take_n(v_p_247, 1ULL, 2);
      return heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_x_2415});
    }
    default: return heff_nomatch(v_p_247);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
Clo g_heff_2eelab_2eclauses_2efoldr2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efoldr2_entry, 3, 0};

V g_heff_2eelab_2eclauses_2efoldr2(V v_f_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(g_heff_2eelab_2eclauses_2efoldr2(heff_dup(v_f_240), v_z_241, v_xs_244));
    return heff_tail(v_f_240, 2, (V[]){heff_dup(v_x_243), v_t_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2efoldr2_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2efoldr2(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_str0, 44, " is used with different numbers of arguments");
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry, 7, 0};

V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_c_244, V v_arm_245, V v_fs_246) {
top: ;
  V v_t_247 = heff_take_field(v_arm_245, 1);
  V v_e_2411;
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_arm_245, 0)), 3, 4);
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_arm_245, 0)), 0, 4);
    V v_t_2410 = heff_rec_n(2, shape_span__msg, (V[]){v_t_248, heff_strAppend(v_t_249, ((V)&g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_str0))});
    v_e_2411 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2410});
  } else {
    heff_drop(v_t_247);
    v_e_2411 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  switch (heff_tag_of(v_e_2411)) {
  case TAG_Left: {
    V v_e_2412 = heff_field(v_e_2411, 0);
    V v_ru_24e_2411_24Left = heff_take_reuse_n(v_e_2411, 1ULL, 1);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_c_244);
    heff_drop_rec(v_arm_245, 3);
    heff_drop(v_fs_246);
    return heff_tag_at_n(v_ru_24e_2411_24Left, TAG_Left, 1, (V[]){v_e_2412});
  }
  case TAG_Right: {
    V v_ru_24e_2411_24Right = heff_take_reuse_n(v_e_2411, 0ULL, 1);
    V v_bound_2414 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_fs_246), v_bound_241));
    V v_t_2415 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_244), heff_dup(v_vars_243)));
    V v_t_2416 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_244, MK_INT(1LL)), v_vars_243));
    V v_t_2417 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_fs_246), v_t_2416));
    V v_vars_2418 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2415, v_t_2417));
    V v_rows_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_arm_245, 2)));
    V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam0, 1, 1, (V[]){heff_dup(v_vars_2418)}), v_rows_2419));
    V v_x1_2422 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(v_used_240, v_bound_2414, heff_dup(v_sp_242), v_vars_2418, v_t_2421));
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_Left: {
      V v_e_2423 = heff_field(v_x1_2422, 0);
      heff_take_n(v_x1_2422, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_rec(v_arm_245, 3);
      heff_drop(v_fs_246);
      return heff_tag_at_n(v_ru_24e_2411_24Right, TAG_Left, 1, (V[]){v_e_2423});
    }
    case TAG_Right: {
      V v_x_2424 = heff_field(v_x1_2422, 0);
      V v_ru_24x1_2422_24Right = heff_take_reuse_n(v_x1_2422, 1ULL, 1);
      V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_arm_245, 0)), 0, 4);
      V v_tsp_2426 = heff_get_n(heff_get_n(v_arm_245, 0, 3), 3, 4);
      V v_ps_2428 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam1, 1, 1, (V[]){v_sp_242}), v_fs_246));
      V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e_2411_24Right, TAG_PatVar, 1, (V[]){heff_dup(v_t_2425)}), heff_dup(v_tsp_2426)});
      V v_x1_2430 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2429, v_ps_2428));
      V v_b_2433;
      switch (heff_tag_of(v_x1_2430)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_x1_2430, 1);
        heff_take_n(v_x1_2430, 2ULL, 2);
        v_b_2433 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_x1_2430);
      }
      V v_t_2434 = ({ V rv_0 = heff_dup(heff_rfield(v_tsp_2426, 0)); V rr_ = heff_rec_reuse_nf(v_b_2433, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_p_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_2425, v_tsp_2426, v_ps_2428}), v_t_2434});
      V v_a_2438;
      switch (heff_tag_of(v_p_2435)) {
      case TAG_At: {
        V v_s_2437 = heff_dup(heff_field(v_p_2435, 1));
        v_a_2438 = v_s_2437;
        break;
      }
      default: heff_nomatch(v_p_2435);
      }
      V v_b_2441;
      switch (heff_tag_of(v_x_2424)) {
      case TAG_At: {
        V v_s_2440 = heff_dup(heff_field(v_x_2424, 1));
        v_b_2441 = v_s_2440;
        break;
      }
      default: heff_nomatch(v_x_2424);
      }
      V v_t_2442 = ({ V rv_1 = heff_get_n(v_b_2441, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_2438, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2435, v_x_2424}), v_t_2442});
      return heff_tag_at_n(v_ru_24x1_2422_24Right, TAG_Right, 1, (V[]){v_t_2443});
    }
    default: return heff_nomatch(v_x1_2422);
    }
  }
  default: return heff_nomatch(v_e_2411);
  }
}
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam0(V self, V *args) {
  V v_row_2420 = args[0];
  V v_vars_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_2418, heff_dup(heff_rfield(v_row_2420, 0)), heff_get_n(v_row_2420, 1, 2)));
}
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam1(V self, V *args) {
  V v_y_2427 = args[0];
  V v_sp_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_y_2427}), v_sp_242});
}
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str3, 1, "_");
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_entry, 7, 0};

V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_rest_246) {
top: ;
  switch (heff_tag_of(v_rest_246)) {
  case TAG_Nil: {
    heff_drop(v_bound_241);
    heff_drop_rec(v_sp_242, 2);
    heff_drop(v_vars_243);
    heff_drop(v_c_245);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_vars_249 = (g_heff_2eelab_2eclauses_2edropAt(heff_dup(v_c_245), heff_dup(v_vars_243)));
    V v_rows_2432 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_lam0, 1, 2, (V[]){v_c_245, v_vars_243}), v_rest_246));
    V v_t_2434 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_lam1, 1, 1, (V[]){heff_dup(v_vars_249)}), v_rows_2432));
    V v_x1_2435 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(v_used_240, v_bound_241, heff_dup(v_sp_242), v_vars_249, v_t_2434));
    switch (heff_tag_of(v_x1_2435)) {
    case TAG_Left: {
      V v_e_2436 = heff_field(v_x1_2435, 0);
      V v_ru_24x1_2435_24Left = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
      heff_drop_rec(v_sp_242, 2);
      return heff_tag_at_n(v_ru_24x1_2435_24Left, TAG_Left, 1, (V[]){v_e_2436});
    }
    case TAG_Right: {
      V v_x_2437 = heff_field(v_x1_2435, 0);
      V v_ru_24x1_2435_24Right = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
      V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2435_24Right, TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str3)}), heff_dup(v_sp_242)});
      V v_b_2441;
      switch (heff_tag_of(v_x_2437)) {
      case TAG_At: {
        V v_s_2440 = heff_dup(heff_field(v_x_2437, 1));
        v_b_2441 = v_s_2440;
        break;
      }
      default: heff_nomatch(v_x_2437);
      }
      V v_t_2442 = ({ V rv_1 = heff_get_n(v_b_2441, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_242, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2438, v_x_2437}), v_t_2442});
      V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Right, 1, (V[]){v_t_2444});
    }
    default: return heff_nomatch(v_x1_2435);
    }
  }
  default: return heff_nomatch(v_rest_246);
  }
}
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860(a0, a[1], a[2], a[3], a4, a[5], a[6]); heff_drop(a0); heff_drop(a4); return r;
}
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_lam0(V self, V *args) {
  V v_row_2410 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_vars_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_pats_2411 = (g_heff_2eelab_2eclauses_2edropAt(heff_dup(v_c_245), heff_dup(heff_rfield(v_row_2410, 0))));
  V v_t_2412 = ({ V a_0 = v_vars_243; V a_1 = heff_dup(v_c_245); V r_ = (g_heff_2eelab_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
  V v_v_2414;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    v_v_2414 = ((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str0);
    break;
  }
  case TAG_Just: {
    V v_v_2413 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    v_v_2414 = v_v_2413;
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_t_2415 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_row_2410, 0), v_c_245));
  V v_x2_2417;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    v_x2_2417 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str1)});
    break;
  }
  case TAG_Just: {
    V v_p_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    v_x2_2417 = v_p_2416;
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_e_2418 = heff_get_n(v_row_2410, 1, 2);
  V v_rhs_2431;
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_PVar: {
    V v_x_2419 = heff_field(v_x2_2417, 0);
    heff_take_n(v_x2_2417, 1ULL, 1);
    if (heff_strEq_c(heff_dup(v_x_2419), ((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str2))) {
      heff_drop(v_v_2414);
      heff_drop(v_x_2419);
      v_rhs_2431 = v_e_2418;
    } else {
      if (heff_strEq_c(heff_dup(v_x_2419), heff_dup(v_v_2414))) {
        heff_drop(v_v_2414);
        heff_drop(v_x_2419);
        v_rhs_2431 = v_e_2418;
      } else {
        V v_t_2422 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2419, v_v_2414));
        v_rhs_2431 = heff_tr(heff_call(heff_get_n(v_t_2422, 3, 5), 1, (V[]){v_e_2418}));
      }
    }
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x2_2417, 0ULL, 3);
    heff_drop(v_v_2414);
    v_rhs_2431 = v_e_2418;
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x2_2417, 0ULL, 1);
    heff_drop(v_v_2414);
    v_rhs_2431 = v_e_2418;
    break;
  }
  case TAG_PRec: {
    heff_take_n(v_x2_2417, 0ULL, 2);
    heff_drop(v_v_2414);
    v_rhs_2431 = v_e_2418;
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x2_2417, 0ULL, 2);
    heff_drop(v_v_2414);
    v_rhs_2431 = v_e_2418;
    break;
  }
  default: heff_nomatch(v_x2_2417);
  }
  return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2411, v_rhs_2431});
}
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_lam1(V self, V *args) {
  V v_row_2433 = args[0];
  V v_vars_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_249, heff_dup(heff_rfield(v_row_2433, 0)), heff_get_n(v_row_2433, 1, 2)));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_str0, 1, "_");
V g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_entry, 6, 0};

V g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245) {
top: ;
  V v_t_2420 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_lam0, 1, 1, (V[]){heff_dup(v_c_245)}), heff_dup(v_rows_244)));
  return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_sp_242; V a_3 = v_vars_243; V a_4 = v_rows_244; V a_5 = v_c_245; V a_6 = v_t_2420; V r_ = (g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rows_244); r_; });
}
V g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_lam0(V self, V *args) {
  V v_row_246 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = ({ V b_0 = heff_get_n(v_row_246, 0, 2); V a_1 = v_c_245; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    v_x1_249 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    v_x1_249 = v_p_248;
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_x1_2419;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_PVar: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_x1_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x1_249, 0ULL, 3);
    v_x1_2419 = NTAG(TAG_True);
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_x1_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_PRec: {
    heff_take_n(v_x1_249, 0ULL, 2);
    v_x1_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x1_249, 0ULL, 2);
    v_x1_2419 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2419) == NTAG(TAG_True)));
  heff_drop(v_x1_2419);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str2, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str3, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str4, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str5, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str6, 7, "floatEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str7, 5, "strEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str8, 7, "bytesEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str9, 6, "runeEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str10, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str11, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str12, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str13, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str14, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str15, 5, "False");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str16, 5, "False");
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_entry, 7, 0};

V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_l_246) {
top: ;
  V v_x1_247 = (g_heff_2eelab_2eclauses_2elitChecks(v_sp_242, v_vars_243, v_rows_244, heff_dup(v_c_245), v_l_246));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Left: {
    V v_e_248 = heff_field(v_x1_247, 0);
    V v_ru_24x1_247_24Left = heff_take_reuse_n(v_x1_247, 1ULL, 1);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_c_245);
    heff_drop(v_l_246);
    return heff_tag_at_n(v_ru_24x1_247_24Left, TAG_Left, 1, (V[]){v_e_248});
  }
  case TAG_Right: {
    V v_ru_24x1_247_24Right = heff_take_reuse_n(v_x1_247, 0ULL, 1);
    V v_vars_2410 = (g_heff_2eelab_2eclauses_2edropAt(heff_dup(v_c_245), heff_dup(v_vars_243)));
    V v_t_2411 = (g_heff_2eelab_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
    V v_t_2413;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      v_t_2413 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str0);
      break;
    }
    case TAG_Just: {
      V v_v_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      v_t_2413 = v_v_2412;
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    V v_rows_2414 = (g_heff_2eelab_2eclauses_2elitYes(heff_dup(v_c_245), v_l_246, v_t_2413, v_rows_244));
    V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_lam0, 1, 1, (V[]){heff_dup(v_vars_2410)}), v_rows_2414));
    V v_x1_2417 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(v_used_240, heff_dup(v_bound_241), heff_dup(v_sp_242), v_vars_2410, v_t_2416));
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Left: {
      V v_e_2418 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 1);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_c_245);
      heff_drop(v_l_246);
      return heff_tag_at_n(v_ru_24x1_247_24Right, TAG_Left, 1, (V[]){v_e_2418});
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_x1_2417, 0);
      V v_ru_24x1_2417_24Right = heff_take_reuse_n(v_x1_2417, 1ULL, 1);
      V v_rows_2420 = (g_heff_2eelab_2eclauses_2elitNo(heff_dup(v_c_245), v_l_246, v_rows_244));
      V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_lam1, 1, 1, (V[]){heff_dup(v_vars_243)}), v_rows_2420));
      V v_x1_2423 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(v_used_240, v_bound_241, heff_dup(v_sp_242), heff_dup(v_vars_243), v_t_2422));
      switch (heff_tag_of(v_x1_2423)) {
      case TAG_Left: {
        V v_e_2424 = heff_field(v_x1_2423, 0);
        heff_take_n(v_x1_2423, 1ULL, 1);
        heff_drop(v_sp_242);
        heff_drop(v_vars_243);
        heff_drop(v_c_245);
        heff_drop(v_l_246);
        heff_drop(v_x_2419);
        heff_drop_cell(v_ru_24x1_2417_24Right, 1);
        return heff_tag_at_n(v_ru_24x1_247_24Right, TAG_Left, 1, (V[]){v_e_2424});
      }
      case TAG_Right: {
        V v_x_2425 = heff_field(v_x1_2423, 0);
        V v_ru_24x1_2423_24Right = heff_take_reuse_n(v_x1_2423, 1ULL, 1);
        V v_t_2426 = ({ V a_0 = v_vars_243; V a_1 = v_c_245; V r_ = (g_heff_2eelab_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
        V v_t_2428;
        switch (heff_tag_of(v_t_2426)) {
        case TAG_Nothing: {
          v_t_2428 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str1);
          break;
        }
        case TAG_Just: {
          V v_v_2427 = heff_field(v_t_2426, 0);
          heff_take_n(v_t_2426, 1ULL, 1);
          v_t_2428 = v_v_2427;
          break;
        }
        default: heff_nomatch(v_t_2426);
        }
        V v_t_2448;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_x11_2429 = heff_dup(heff_field(v_l_246, 0));
          switch (heff_tag_of(v_x11_2429)) {
          case TAG_PatVar: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2448 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str2);
            break;
          }
          case TAG_PatTag: {
            heff_take_n(v_x11_2429, 0ULL, 3);
            v_t_2448 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str3);
            break;
          }
          case TAG_PatOp: {
            heff_take_n(v_x11_2429, 0ULL, 3);
            v_t_2448 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str4);
            break;
          }
          case TAG_PatInt: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2448 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str5);
            break;
          }
          case TAG_PatFloat: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2448 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str6);
            break;
          }
          case TAG_PatString: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2448 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str7);
            break;
          }
          case TAG_PatBytes: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2448 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str8);
            break;
          }
          case TAG_PatRune: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2448 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str9);
            break;
          }
          case TAG_PatRecord: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2448 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str10);
            break;
          }
          case TAG_PatWord: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2448 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str11);
            break;
          }
          case TAG_PatAs: {
            heff_take_n(v_x11_2429, 0ULL, 3);
            v_t_2448 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str12);
            break;
          }
          default: heff_nomatch(v_x11_2429);
          }
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_t_2449 = (g_heff_2eelab_2eclauses_2elitExpr(heff_dup(v_l_246)));
        V v_t_2452;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_s_2451 = heff_dup(heff_field(v_l_246, 1));
          v_t_2452 = v_s_2451;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_t_2453 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ILitEq, 4, (V[]){v_t_2428, v_sp_242, v_t_2448, v_t_2449}), v_t_2452});
        V v_tsp_2456;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_s_2455 = heff_dup(heff_field(v_l_246, 1));
          v_tsp_2456 = v_s_2455;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_t_2457 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str13), heff_dup(v_tsp_2456), NTAG(TAG_Nil)});
        V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_247_24Right, TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str14)}), heff_dup(v_tsp_2456)});
        V v_x1_2459 = ({ V a_0 = v_t_2458; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
        V v_b_2462;
        switch (heff_tag_of(v_x1_2459)) {
        case TAG_At: {
          V v_s_2461 = heff_field(v_x1_2459, 1);
          heff_take_n(v_x1_2459, 2ULL, 2);
          v_b_2462 = v_s_2461;
          break;
        }
        default: heff_nomatch(v_x1_2459);
        }
        V v_t_2463 = ({ V rv_1 = heff_get_n(v_b_2462, 1, 2); V rr_ = heff_rec_reuse_nf(v_tsp_2456, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_p_2464 = heff_tag_n(TAG_At, 2, (V[]){v_t_2457, v_t_2463});
        V v_a_2467;
        switch (heff_tag_of(v_p_2464)) {
        case TAG_At: {
          V v_s_2466 = heff_dup(heff_field(v_p_2464, 1));
          v_a_2467 = v_s_2466;
          break;
        }
        default: heff_nomatch(v_p_2464);
        }
        V v_b_2470;
        switch (heff_tag_of(v_x_2419)) {
        case TAG_At: {
          V v_s_2469 = heff_dup(heff_field(v_x_2419, 1));
          v_b_2470 = v_s_2469;
          break;
        }
        default: heff_nomatch(v_x_2419);
        }
        V v_t_2471 = ({ V rv_1 = heff_get_n(v_b_2470, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_2467, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2464, v_x_2419}), v_t_2471});
        V v_tsp_2475;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_s_2474 = heff_dup(heff_field(v_l_246, 1));
          v_tsp_2475 = v_s_2474;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_t_2476 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str15), heff_dup(v_tsp_2475), NTAG(TAG_Nil)});
        V v_t_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2417_24Right, TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str16)}), heff_dup(v_tsp_2475)});
        V v_x1_2478 = ({ V a_0 = v_t_2477; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
        V v_b_2481;
        switch (heff_tag_of(v_x1_2478)) {
        case TAG_At: {
          V v_s_2480 = heff_field(v_x1_2478, 1);
          heff_take_n(v_x1_2478, 2ULL, 2);
          v_b_2481 = v_s_2480;
          break;
        }
        default: heff_nomatch(v_x1_2478);
        }
        V v_t_2482 = ({ V rv_1 = heff_get_n(v_b_2481, 1, 2); V rr_ = heff_rec_reuse_nf(v_tsp_2475, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_p_2483 = heff_tag_n(TAG_At, 2, (V[]){v_t_2476, v_t_2482});
        V v_a_2486;
        switch (heff_tag_of(v_p_2483)) {
        case TAG_At: {
          V v_s_2485 = heff_dup(heff_field(v_p_2483, 1));
          v_a_2486 = v_s_2485;
          break;
        }
        default: heff_nomatch(v_p_2483);
        }
        V v_b_2489;
        switch (heff_tag_of(v_x_2425)) {
        case TAG_At: {
          V v_s_2488 = heff_dup(heff_field(v_x_2425, 1));
          v_b_2489 = v_s_2488;
          break;
        }
        default: heff_nomatch(v_x_2425);
        }
        V v_t_2490 = ({ V rv_1 = heff_get_n(v_b_2489, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_2486, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2491 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2483, v_x_2425}), v_t_2490});
        V v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2491, NTAG(TAG_Nil)});
        V v_t_2493 = heff_tag_n(TAG_CMatch, 2, (V[]){v_t_2453, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2472, v_t_2492})});
        V v_t_2496;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_s_2495 = heff_field(v_l_246, 1);
          heff_take_n(v_l_246, 2ULL, 2);
          v_t_2496 = v_s_2495;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        return heff_tag_at_n(v_ru_24x1_2423_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2493, v_t_2496})});
      }
      default: return heff_nomatch(v_x1_2423);
      }
    }
    default: return heff_nomatch(v_x1_2417);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018(a0, a[1], a[2], a[3], a4, a[5], a[6]); heff_drop(a0); heff_drop(a4); return r;
}
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_lam0(V self, V *args) {
  V v_row_2415 = args[0];
  V v_vars_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_2410, heff_dup(heff_rfield(v_row_2415, 0)), heff_get_n(v_row_2415, 1, 2)));
}
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_lam1(V self, V *args) {
  V v_row_2421 = args[0];
  V v_vars_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_243, heff_dup(heff_rfield(v_row_2421, 0)), heff_get_n(v_row_2421, 1, 2)));
}
V g_heff_2eelab_2eclauses_2ecaseTreeOf_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ecaseTreeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecaseTreeOf_entry, 4, 0};

V g_heff_2eelab_2eclauses_2ecaseTreeOf(V v_sp_240, V v_rows_241, V v_used_242, V v_x_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_248 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ecaseTreeOf_lam0, 1, 1, (V[]){heff_dup(v_x_243)}), v_rows_241));
  V v_x1_249 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), v_used_242}); V a_1 = v_t_244; V a_2 = v_sp_240; V a_3 = v_t_245; V a_4 = v_t_248; V r_ = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Left: {
    V v_e_2410 = heff_field(v_x1_249, 0);
    V v_ru_24x1_249_24Left = heff_take_reuse_n(v_x1_249, 1ULL, 1);
    heff_drop(v_x_243);
    return heff_tag_at_n(v_ru_24x1_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
  }
  case TAG_Right: {
    V v_x_2411 = heff_field(v_x1_249, 0);
    V v_ru_24x1_249_24Right = heff_take_reuse_n(v_x1_249, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_249_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_scrutinee__tree, (V[]){v_x_243, v_x_2411})});
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2eelab_2eclauses_2ecaseTreeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ecaseTreeOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eclauses_2ecaseTreeOf_lam0(V self, V *args) {
  V v_row_246 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
  return (g_heff_2eelab_2eclauses_2epeelCols(v_t_247, heff_dup(heff_rfield(v_row_246, 0)), heff_get_n(v_row_246, 1, 2)));
}
Clo g_heff_2eelab_2eclauses_2etraverseC_24s246054844x100991343_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etraverseC_24s246054844x100991343_entry, 1, 0};

V g_heff_2eelab_2eclauses_2etraverseC_24s246054844x100991343(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        heff_take_n(v_a_243, 3ULL, 2);
        V v_a_247 = (g_heff_2eelab_2eclauses_2epat(v_a_245));
        switch (heff_tag_of(v_a_247)) {
        case TAG_Left: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_ru_24a_247_24Left = heff_take_reuse_n(v_a_247, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_a_246);
          v_x1_2411 = heff_tag_at_n(v_ru_24a_247_24Left, TAG_Left, 1, (V[]){v_a_248});
          break;
        }
        case TAG_Right: {
          V v_a_249 = heff_field(v_a_247, 0);
          V v_ru_24a_247_24Right = heff_take_reuse_n(v_a_247, 1ULL, 1);
          V v_t_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_249, NTAG(TAG_Nil)});
          v_x1_2411 = heff_tag_at_n(v_ru_24a_247_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_t_2410, v_a_246})});
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x1_2411, 0);
      V v_ru_24x1_2411_24Left = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
      heff_drop(v_xs_242);
      return heff_tag_at_n(v_ru_24x1_2411_24Left, TAG_Left, 1, (V[]){v_e_2412});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x1_2411, 0);
      V v_ru_24x1_2411_24Right = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
      V v_x1_2414 = (g_heff_2eelab_2eclauses_2etraverseC_24s246054844x100991343(v_xs_242));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Left: {
        V v_e_2415 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        heff_drop(v_x_2413);
        return heff_tag_at_n(v_ru_24x1_2411_24Right, TAG_Left, 1, (V[]){v_e_2415});
      }
      case TAG_Right: {
        V v_x_2416 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2411_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_x_2416})});
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2etraverseC_24s246054844x100991343_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etraverseC_24s246054844x100991343(a[0]);
}