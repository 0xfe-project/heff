// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CInf 46723
#define TAG_CLetIn 34208
#define TAG_CMatch 53053
#define TAG_CTag 56892
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_ExplicitParam 63083
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IPrim 59489
#define TAG_IVar 40993
#define TAG_ImplicitParam 51130
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_PAs 26446
#define TAG_PBin 33976
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define LBL_anys 9494734
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_bad 306815
#define LBL_bits 9519565
#define LBL_bound 295286168
#define LBL_chk 308000
#define LBL_digits 615232529
#define LBL_end 310101
#define LBL_exponent 966452320
#define LBL_flags 298871457
#define LBL_go 10063
#define LBL_len 316559
#define LBL_msg 317947
#define LBL_negative 1666250321
#define LBL_order 307364712
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_row 322644
#define LBL_rows 10002080
#define LBL_size 10026184
#define LBL_sizes 310811820
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tag 324116
#define LBL_terms 311608737
#define LBL_ty 10476
#define LBL_typ 324869
#define LBL_used 10094724
#define LBL_v 336
#define LBL_value 313331083
#define LBL_x 338
static uint32_t shape_arms__order__anys[] = {LBL_arms, LBL_order, LBL_anys};
static uint32_t shape_bits__terms[] = {LBL_bits, LBL_terms};
static uint32_t shape_go[] = {LBL_go};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_row__bad__rows[] = {LBL_row, LBL_bad, LBL_rows};
static uint32_t shape_span__msg[] = {LBL_span, LBL_msg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_tag__arity__pats__span[] = {LBL_tag, LBL_arity, LBL_pats, LBL_span};
static uint32_t shape_v__bits__len__sizes__used__bound__span[] = {LBL_v, LBL_bits, LBL_len, LBL_sizes, LBL_used, LBL_bound, LBL_span};
V g_heff_2eelab_2eclauses_2eallC(V, V);
V g_heff_2eelab_2eclauses_2eallC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eallC_clo;
V g_heff_2eelab_2eclauses_2eandC(V, V, V);
V g_heff_2eelab_2eclauses_2eandC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eandC_clo;
V g_heff_2eelab_2eclauses_2eandC_24tok3(V, V, V, V);
V g_heff_2eelab_2eclauses_2eandC_24tok3_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eandC_24tok3_clo;
V g_heff_2eelab_2eclauses_2eanyC(V, V);
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_clo;
V g_heff_2eelab_2eclauses_2eanyC_24s77926680x1031377762(V, V);
V g_heff_2eelab_2eclauses_2eanyC_24s77926680x1031377762_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_24s77926680x1031377762_clo;
V g_heff_2eelab_2eclauses_2eanyIn(V, V, V);
V g_heff_2eelab_2eclauses_2eanyIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyIn_clo;
V g_heff_2eelab_2eclauses_2eappendC(V, V);
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_clo;
V g_heff_2eelab_2eclauses_2eappendC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24dps_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514(V, V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_24dps(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_24dps_clo;
V g_heff_2eelab_2eclauses_2eappendC_24tok2(V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24tok2_clo;
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_clo;
V g_heff_2eelab_2eclauses_2ebinBind(V);
V g_heff_2eelab_2eclauses_2ebinBind_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinBind_clo;
V g_heff_2eelab_2eclauses_2ebinBindGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ebinBindGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinBindGo_clo;
HeffT2 g_heff_2eelab_2eclauses_2ebinChecks_24cpr(V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2ebinaryOf_24s1676894398x132520022_24cpr(V, V, V, V, V, V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr(V, V, V, V, V, V, V, V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecatMaybesC(V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo;
V g_heff_2eelab_2eclauses_2ecolNames(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolNames_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolNames_clo;
V g_heff_2eelab_2eclauses_2ecolNames_24dps(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolNames_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolNames_24dps_clo;
HeffT2 g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_clo;
V g_heff_2eelab_2eclauses_2edropAt(V, V);
V g_heff_2eelab_2eclauses_2edropAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropAt_clo;
V g_heff_2eelab_2eclauses_2edropC(V, V);
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropC_clo;
HeffT2 g_heff_2eelab_2eclauses_2efindTagLit_24cpr(V, V);
HeffT2 g_heff_2eelab_2eclauses_2eforC_24cpr(V, V);
V g_heff_2eelab_2eclauses_2efreshIn(V, V, V);
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efreshIn_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2eintRead(V, V, V, V);
V g_heff_2eelab_2eclauses_2eintRead_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eintRead_clo;
V g_heff_2eelab_2eclauses_2eintTest(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2eintTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eintTest_clo;
HeffT2 g_heff_2eelab_2eclauses_2elitChecks_24cpr(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2elitNo(V, V, V);
V g_heff_2eelab_2eclauses_2elitNo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitNo_clo;
V g_heff_2eelab_2eclauses_2elitYes(V, V, V, V);
V g_heff_2eelab_2eclauses_2elitYes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitYes_clo;
V g_heff_2eelab_2eclauses_2emapWithIndexC(V, V, V);
V g_heff_2eelab_2eclauses_2emapWithIndexC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2emapWithIndexC_clo;
V g_heff_2eelab_2eclauses_2enameFits(V, V, V);
V g_heff_2eelab_2eclauses_2enameFits_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enameFits_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll(V, V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_clo;
HeffT2 g_heff_2eelab_2eclauses_2enoRecMix_24cpr(V, V);
HeffT2 g_heff_2eelab_2eclauses_2enthC_24cpr(V, V);
V g_heff_2eelab_2eclauses_2enubStr(V);
V g_heff_2eelab_2eclauses_2enubStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enubStr_clo;
HeffT2 g_heff_2eelab_2eclauses_2epat_24cpr(V);
V g_heff_2eelab_2eclauses_2epatBinds(V);
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_clo;
V g_heff_2eelab_2eclauses_2epatBinds_24dps(V, V);
V g_heff_2eelab_2eclauses_2epatBinds_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_24dps_clo;
V g_heff_2eelab_2eclauses_2epatIdents(V, V);
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_clo;
V g_heff_2eelab_2eclauses_2epatIdents_24tok2(V, V, V);
V g_heff_2eelab_2eclauses_2epatIdents_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_24tok2_clo;
V g_heff_2eelab_2eclauses_2epeelCols(V, V, V);
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epeelCols_clo;
V g_heff_2eelab_2eclauses_2ereached(V, V);
V g_heff_2eelab_2eclauses_2ereached_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ereached_clo;
V g_heff_2eelab_2eclauses_2erenameDecl(V, V);
V g_heff_2eelab_2eclauses_2erenameDecl_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameDecl_clo;
V g_heff_2eelab_2eclauses_2erenameSeq_24s595361288x433123245(V, V, V);
V g_heff_2eelab_2eclauses_2erenameSeq_24s595361288x433123245_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameSeq_24s595361288x433123245_clo;
V g_heff_2eelab_2eclauses_2erenamer(V, V);
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamer_clo;
V g_heff_2eelab_2eclauses_2eresolve(V, V);
V g_heff_2eelab_2eclauses_2eresolve_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eresolve_clo;
V g_heff_2eelab_2eclauses_2esameLit(V, V);
V g_heff_2eelab_2eclauses_2esameLit_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esameLit_clo;
V g_heff_2eelab_2eclauses_2esoleBin(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esoleBin_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esoleBin_clo;
V g_heff_2eelab_2eclauses_2esoleBin_24tok2(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esoleBin_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esoleBin_24tok2_clo;
V g_heff_2eelab_2eclauses_2etagColAt(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagColAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagColAt_clo;
V g_heff_2eelab_2eclauses_2etakeC(V, V);
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_clo;
V g_heff_2eelab_2eclauses_2etakeC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2etakeC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_24dps_clo;
V g_heff_2eelab_2eclauses_2eunreachedGo_24dps(V, V, V, V);
V g_heff_2eelab_2eclauses_2eunreachedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eunreachedGo_24dps_clo;
V g_heff_2eelab_2eclauses_2ewholeBin(V, V);
V g_heff_2eelab_2eclauses_2ewholeBin_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ewholeBin_clo;
HeffT2 g_heff_2eelab_2eclauses_2ewholeSeg_24cpr(V, V, V, V);
V g_heff_2eelab_2eclauses_2ewidthBy(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ewidthBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ewidthBy_clo;
V g_heff_2eelab_2eclauses_2ezipC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2ezipC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ezipC_24dps_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_list_2eall_24s457861111x1513113784(V, V);
V g_list_2eall_24s457861111x1513113784_entry(V self, V *a);
extern Clo g_list_2eall_24s457861111x1513113784_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1116296567x1614305171(V);
V g_list_2eany_24s1116296567x1614305171_entry(V self, V *a);
extern Clo g_list_2eany_24s1116296567x1614305171_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s871632021x1241775640(V, V, V, V);
V g_list_2efoldl_24s871632021x1241775640_entry(V self, V *a);
extern Clo g_list_2efoldl_24s871632021x1241775640_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1539731936x1117725130(V, V, V);
V g_list_2emap_24f1539731936x1117725130_entry(V self, V *a);
extern Clo g_list_2emap_24f1539731936x1117725130_clo;
V g_list_2emap_24s1134745827x519521524(V);
V g_list_2emap_24s1134745827x519521524_entry(V self, V *a);
extern Clo g_list_2emap_24s1134745827x519521524_clo;
V g_list_2emap_24s1230649048x711093514(V, V);
V g_list_2emap_24s1230649048x711093514_entry(V self, V *a);
extern Clo g_list_2emap_24s1230649048x711093514_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1368853467x919806006(V);
V g_list_2emap_24s1368853467x919806006_entry(V self, V *a);
extern Clo g_list_2emap_24s1368853467x919806006_clo;
V g_list_2emap_24s1722943925x2063725971(V);
V g_list_2emap_24s1722943925x2063725971_entry(V self, V *a);
extern Clo g_list_2emap_24s1722943925x2063725971_clo;
V g_list_2emap_24s502656580x1955732096(V);
V g_list_2emap_24s502656580x1955732096_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_clo;
V g_list_2emap_24s584558070x895760461(V, V);
V g_list_2emap_24s584558070x895760461_entry(V self, V *a);
extern Clo g_list_2emap_24s584558070x895760461_clo;
V g_list_2emap_24s886389550x1086668531(V);
V g_list_2emap_24s886389550x1086668531_entry(V self, V *a);
extern Clo g_list_2emap_24s886389550x1086668531_clo;
V g_list_2emap_24s939813003x1383013550(V);
V g_list_2emap_24s939813003x1383013550_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1483742185x1081287844_24cpr(V);
HeffT2 g_prelude_2etraverse_24s890471069x803991723_24cpr(V);
double g_std_2emath_2efromDecimal_w(V, V);
V g_std_2emath_2efromDecimal(V, V);
V g_std_2emath_2efromDecimal_entry(V self, V *a);
extern Clo g_std_2emath_2efromDecimal_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2emapValues(V, V);
V g_std_2eordmap_2emapValues_entry(V self, V *a);
extern Clo g_std_2eordmap_2emapValues_clo;
Clo g_heff_2eelab_2eclauses_2ezipC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ezipC_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2ezipC_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ezipC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ezipC_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2etakeC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etakeC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2etakeC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_heff_2eelab_2eclauses_2etakeC_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etakeC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2edropC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edropC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2edropC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2edropC(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2epat_24cpr_str0, 86, "a pattern is a variable, a literal, a tag applied to patterns, or a record of patterns");
HEFF_LIT(g_heff_2eelab_2eclauses_2epat_24cpr_str1, 86, "a pattern is a variable, a literal, a tag applied to patterns, or a record of patterns");

HeffT2 g_heff_2eelab_2eclauses_2epat_24cpr(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_dup(heff_field(v_p_240, 0));
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      V v_ru_24p1_241_24PatVar = heff_take_reuse_n(v_p1_241, 1ULL, 1);
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        heff_take_n(v_p_240, 0ULL, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24p1_241_24PatVar, TAG_PVar, 1, (V[]){v_x_243})}});
      }
      default: return ((HeffT2){{heff_nomatch(v_p_240)}});
      }
    }
    case TAG_PatTag: {
      V v_t_246 = heff_field(v_p1_241, 0);
      V v_tsp_247 = heff_field(v_p1_241, 1);
      V v_ps_248 = heff_field(v_p1_241, 2);
      V v_ru_24p1_241_24PatTag = heff_take_reuse_n(v_p1_241, 7ULL, 3);
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        heff_take_n(v_p_240, 0ULL, 2);
        HeffT2 v_t_2411 = (g_prelude_2etraverse_24s890471069x803991723_24cpr(v_ps_248));
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            heff_drop(v_t_246);
            heff_drop(v_tsp_247);
            heff_drop_cell(v_ru_24p1_241_24PatTag, 3);
            V v_e_2414 = v_field_2413;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2414}});
          } else {
            V v_x_2415 = v_field_2413;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24p1_241_24PatTag, TAG_PTag, 3, (V[]){v_t_246, v_x_2415, v_tsp_247})}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_p_240)}});
      }
    }
    case TAG_PatOp: {
      heff_take_n(v_p1_241, 0ULL, 3);
      V v_t_2421;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2420 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_t_2421 = v_s_2420;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_f_2422 = heff_rec_n(2, shape_span__msg, (V[]){v_t_2421, ((V)&g_heff_2eelab_2eclauses_2epat_24cpr_str0)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2422}});
    }
    case TAG_PatInt: {
      V v_ru_24p1_241_24PatInt = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24p1_241_24PatInt, TAG_PLit, 1, (V[]){v_p_240})}});
    }
    case TAG_PatFloat: {
      V v_ru_24p1_241_24PatFloat = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24p1_241_24PatFloat, TAG_PLit, 1, (V[]){v_p_240})}});
    }
    case TAG_PatString: {
      V v_ru_24p1_241_24PatString = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24p1_241_24PatString, TAG_PLit, 1, (V[]){v_p_240})}});
    }
    case TAG_PatBinary: {
      V v_segs_2426 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_p2_2428 = heff_field(v_p_240, 1);
        V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 2ULL, 2);
        V v_segs_2429 = (g_list_2emap_24s886389550x1086668531(v_segs_2426));
        V v_f_2436;
        switch (heff_tag_of(v_segs_2429)) {
        case TAG_Nil: {
          v_f_2436 = heff_tag_at_n(v_ru_24p_240_24At, TAG_PBin, 2, (V[]){v_segs_2429, v_p2_2428});
          break;
        }
        case TAG_Cons: {
          V v_segs2_2431 = heff_dup(heff_field(v_segs_2429, 1));
          switch (heff_tag_of(v_segs2_2431)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24p_240_24At, 2);
            switch (heff_tag_of(v_segs_2429)) {
            case TAG_Cons: {
              V v_s_2432 = heff_field(v_segs_2429, 0);
              V v_ru_24segs_2429_24Cons = heff_take_reuse_n(v_segs_2429, 1ULL, 2);
              v_f_2436 = ({ V a_0 = v_ru_24segs_2429_24Cons; V a_1 = heff_dup(v_s_2432); V a_2 = heff_dup(heff_rfield(v_s_2432, 0)); V b_3 = heff_dup(heff_rfield(v_s_2432, 1)); V b_4 = heff_get_n(v_s_2432, 2, 5); V a_5 = v_p2_2428; V r_ = (g_heff_2eelab_2eclauses_2esoleBin_24tok2(a_0, a_1, a_2, b_3, b_4, a_5)); heff_drop(b_3); heff_drop(b_4); r_; });
              break;
            }
            default: heff_nomatch(v_segs_2429);
            }
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_segs2_2431, 0ULL, 2);
            v_f_2436 = heff_tag_at_n(v_ru_24p_240_24At, TAG_PBin, 2, (V[]){v_segs_2429, v_p2_2428});
            break;
          }
          default: heff_nomatch(v_segs2_2431);
          }
          break;
        }
        default: heff_nomatch(v_segs_2429);
        }
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2436}});
      }
      default: return ((HeffT2){{heff_nomatch(v_p_240)}});
      }
    }
    case TAG_PatRune: {
      V v_ru_24p1_241_24PatRune = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24p1_241_24PatRune, TAG_PLit, 1, (V[]){v_p_240})}});
    }
    case TAG_PatRecord: {
      V v_fs_2438 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      HeffT2 v_t_2439 = (g_prelude_2etraverse_24s1483742185x1081287844_24cpr(v_fs_2438));
      {
        V v_field_2441 = v_t_2439.f[1];
        int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
        if ((v_tag_2440 == ((int64_t)0ULL))) {
          heff_drop_tag(v_p_240, 2);
          V v_e_2442 = v_field_2441;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2442}});
        } else {
          V v_x_2443 = v_field_2441;
          V v_t_2446;
          switch (heff_tag_of(v_p_240)) {
          case TAG_At: {
            V v_s_2445 = heff_field(v_p_240, 1);
            heff_take_n(v_p_240, 2ULL, 2);
            v_t_2446 = v_s_2445;
            break;
          }
          default: heff_nomatch(v_p_240);
          }
          V v_f_2447 = heff_tag_n(TAG_PRec, 2, (V[]){v_x_2443, v_t_2446});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2447}});
        }
      }
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      V v_t_2451;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2450 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_t_2451 = v_s_2450;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_f_2452 = heff_rec_n(2, shape_span__msg, (V[]){v_t_2451, ((V)&g_heff_2eelab_2eclauses_2epat_24cpr_str1)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2452}});
    }
    case TAG_PatAs: {
      V v_x_2453 = heff_field(v_p1_241, 0);
      V v_q_2455 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 5ULL, 3);
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 0ULL, 2);
        HeffT2 v_t_2458 = (g_heff_2eelab_2eclauses_2epat_24cpr(v_q_2455));
        {
          V v_field_2460 = v_t_2458.f[1];
          int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
          if ((v_tag_2459 == ((int64_t)0ULL))) {
            heff_drop(v_x_2453);
            heff_drop_cell(v_ru_24p_240_24At, 2);
            V v_e_2461 = v_field_2460;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2461}});
          } else {
            V v_x_2462 = v_field_2460;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24p_240_24At, TAG_PAs, 2, (V[]){v_x_2453, v_x_2462})}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_p_240)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_p1_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_p_240)}});
  }
}
Clo g_heff_2eelab_2eclauses_2esameLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esameLit_entry, 2, 0};

V g_heff_2eelab_2eclauses_2esameLit(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      return NTAG(TAG_False);
    }
    case TAG_PatTag: {
      return NTAG(TAG_False);
    }
    case TAG_PatOp: {
      return NTAG(TAG_False);
    }
    case TAG_PatInt: {
      V v_x_2411 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2412 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2412)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          V v_y_2421 = heff_field(v_x21_2412, 0);
          V v_ret_24bool = heff_bool(heff_intEq_c_lent(v_x_2411, v_y_2421, 0));
          return v_ret_24bool;
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          return NTAG(TAG_False);
        }
        case TAG_PatBinary: {
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2412);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatFloat: {
      V v_x_2431 = heff_field(v_x11_242, 0);
      V v_negative_2432 = heff_dup(heff_rfield(v_x_2431, 0));
      V v_digits_2433 = heff_dup(heff_rfield(v_x_2431, 1));
      V v_exponent_2434 = heff_dup(heff_rfield(v_x_2431, 2));
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2435 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2435)) {
        case TAG_PatVar: {
          heff_drop(v_negative_2432);
          heff_drop(v_digits_2433);
          heff_drop(v_exponent_2434);
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          heff_drop(v_negative_2432);
          heff_drop(v_digits_2433);
          heff_drop(v_exponent_2434);
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          heff_drop(v_negative_2432);
          heff_drop(v_digits_2433);
          heff_drop(v_exponent_2434);
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          heff_drop(v_negative_2432);
          heff_drop(v_digits_2433);
          heff_drop(v_exponent_2434);
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          V v_y_2445 = heff_field(v_x21_2435, 0);
          V v_negative_2446 = heff_dup(heff_rfield(v_y_2445, 0));
          V v_digits_2447 = heff_dup(heff_rfield(v_y_2445, 1));
          V v_exponent_2448 = heff_dup(heff_rfield(v_y_2445, 2));
          double v_t_2450;
          if ((heff_dup(v_negative_2432) == NTAG(TAG_True))) {
            heff_drop(v_negative_2432);
            double v_x_2449 = (g_std_2emath_2efromDecimal_w(v_digits_2433, v_exponent_2434));
            v_t_2450 = ((-1.0) * v_x_2449);
          } else {
            heff_drop(v_negative_2432);
            v_t_2450 = (g_std_2emath_2efromDecimal_w(v_digits_2433, v_exponent_2434));
          }
          double v_t_2452;
          if ((heff_dup(v_negative_2446) == NTAG(TAG_True))) {
            heff_drop(v_negative_2446);
            double v_x_2451 = (g_std_2emath_2efromDecimal_w(v_digits_2447, v_exponent_2448));
            v_t_2452 = ((-1.0) * v_x_2451);
          } else {
            heff_drop(v_negative_2446);
            v_t_2452 = (g_std_2emath_2efromDecimal_w(v_digits_2447, v_exponent_2448));
          }
          V v_ret_24bool = heff_bool((v_t_2450 == v_t_2452));
          return v_ret_24bool;
        }
        case TAG_PatString: {
          heff_drop(v_negative_2432);
          heff_drop(v_digits_2433);
          heff_drop(v_exponent_2434);
          return NTAG(TAG_False);
        }
        case TAG_PatBinary: {
          heff_drop(v_negative_2432);
          heff_drop(v_digits_2433);
          heff_drop(v_exponent_2434);
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          heff_drop(v_negative_2432);
          heff_drop(v_digits_2433);
          heff_drop(v_exponent_2434);
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          heff_drop(v_negative_2432);
          heff_drop(v_digits_2433);
          heff_drop(v_exponent_2434);
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          heff_drop(v_negative_2432);
          heff_drop(v_digits_2433);
          heff_drop(v_exponent_2434);
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          heff_drop(v_negative_2432);
          heff_drop(v_digits_2433);
          heff_drop(v_exponent_2434);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2435);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatString: {
      V v_x_2461 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2462 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2462)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          V v_y_2473 = heff_field(v_x21_2462, 0);
          V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_2461, v_y_2473, 0));
          return v_ret_24bool;
        }
        case TAG_PatBinary: {
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2462);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatBinary: {
      return NTAG(TAG_False);
    }
    case TAG_PatRune: {
      V v_x_2482 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2483 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2483)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          return NTAG(TAG_False);
        }
        case TAG_PatBinary: {
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          V v_y_2496 = heff_field(v_x21_2483, 0);
          V v_ret_24bool = heff_bool(heff_intEq_c_lent(v_x_2482, v_y_2496, 0));
          return v_ret_24bool;
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2483);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatRecord: {
      return NTAG(TAG_False);
    }
    case TAG_PatWord: {
      return NTAG(TAG_False);
    }
    case TAG_PatAs: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2esameLit_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2esameLit(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_entry, 3, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll(V v_f_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){heff_dup(v_x_243), v_acc_242}));
    V t_0 = v_f_240;
    V t_1 = v_xs_244;
    V t_2 = v_t_245;
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2enamesOfAll(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_t_248 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_a_247), v_acc_241));
        v_t_249 = (g_heff_2eelab_2eclauses_2epatIdents(heff_dup(v_a_246), v_t_248));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_249;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2epatBinds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatBinds_entry, 1, 0};

V g_heff_2eelab_2eclauses_2epatBinds(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 1ULL, 2);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
    }
    case TAG_PatTag: {
      V v_ps_246 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_ps_246; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a_0)); heff_drop(v_ps_246); r_; });
    }
    case TAG_PatOp: {
      V v_ps_249 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_ps_249; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a_0)); heff_drop(v_ps_249); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      V v_segs_2413 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_segs_2413; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(a_0)); heff_drop(v_segs_2413); r_; });
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2415 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_fs_2415; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(a_0)); heff_drop(v_fs_2415); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2417 = heff_field(v_p1_241, 0);
      V v_q_2419 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 5ULL, 3);
      V v_cell_2420 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_2417, heff_hole()});
      V v_u_2421 = (g_heff_2eelab_2eclauses_2epatBinds_24dps(v_q_2419, heff_dup(v_cell_2420)));
      heff_drop(v_u_2421);
      return v_cell_2420;
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatBinds(a[0]);
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameDecl_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameDecl_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameDecl(V v_r_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_d1_242 = heff_dup(heff_field(v_d_241, 0));
    switch (heff_tag_of(v_d1_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_d1_242, 0);
      V v_fsp_245 = heff_field(v_d1_242, 1);
      V v_declared_246 = heff_field(v_d1_242, 2);
      V v_ty_247 = heff_field(v_d1_242, 3);
      V v_eqs_248 = heff_field(v_d1_242, 4);
      V v_ru_24d1_242_24DeclEquations = heff_take_reuse_n(v_d1_242, 31ULL, 5);
      switch (heff_tag_of(v_d_241)) {
      case TAG_At: {
        V v_sp_2410 = heff_field(v_d_241, 1);
        V v_ru_24d_241_24At = heff_take_reuse_n(v_d_241, 2ULL, 2);
        V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 4)), 1, (V[]){v_ty_247}));
        V v_t_2412;
        if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 0)), heff_dup(v_f_244))) {
          heff_drop_rec(v_r_240, 5);
          v_t_2412 = v_eqs_248;
        } else {
          v_t_2412 = (g_list_2emap_24s584558070x895760461(v_r_240, v_eqs_248));
        }
        return heff_tag_at_n(v_ru_24d_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_244, v_fsp_245, v_declared_246, v_t_2411, v_t_2412}), v_sp_2410});
      }
      default: return heff_nomatch(v_d_241);
      }
    }
    case TAG_DeclDefine: {
      V v_y_2413 = heff_field(v_d1_242, 0);
      V v_ysp_2414 = heff_field(v_d1_242, 1);
      V v_ps_2415 = heff_field(v_d1_242, 2);
      V v_u_2416 = heff_field(v_d1_242, 3);
      V v_body_2417 = heff_field(v_d1_242, 4);
      V v_ru_24d1_242_24DeclDefine = heff_take_reuse_n(v_d1_242, 31ULL, 5);
      switch (heff_tag_of(v_d_241)) {
      case TAG_At: {
        V v_sp_2419 = heff_dup(heff_field(v_d_241, 1));
        if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 0)), heff_dup(v_y_2413))) {
          heff_drop_rec(v_r_240, 5);
          heff_drop(v_y_2413);
          heff_drop(v_ysp_2414);
          heff_drop(v_ps_2415);
          heff_drop(v_u_2416);
          heff_drop(v_body_2417);
          heff_drop_cell(v_ru_24d1_242_24DeclDefine, 5);
          heff_drop(v_sp_2419);
          return v_d_241;
        } else {
          heff_drop_tag(v_d_241, 2);
          V v_t_2431 = (g_heff_2eelab_2eclauses_2erenameSeq_24s595361288x433123245(heff_rfield(v_r_240, 0), heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), heff_dup(v_ps_2415)));
          V v_t_2432 = (g_heff_2eelab_2eclauses_2eanyC_24s77926680x1031377762(heff_rfield(v_r_240, 0), v_ps_2415));
          V v_t_2433;
          if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
            heff_drop(v_t_2432);
            v_t_2433 = v_u_2416;
          } else {
            heff_drop(v_t_2432);
            v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 4)), 1, (V[]){v_u_2416}));
          }
          V v_t_2434 = ({ V a_0 = heff_rfield(v_r_240, 0); V a_1 = v_ps_2415; V r_ = (g_heff_2eelab_2eclauses_2eanyC_24s77926680x1031377762(a_0, a_1)); heff_drop(v_ps_2415); r_; });
          V v_t_2435;
          if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
            heff_drop_rec(v_r_240, 5);
            heff_drop(v_t_2434);
            v_t_2435 = v_body_2417;
          } else {
            heff_drop(v_t_2434);
            v_t_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_body_2417}));
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_y_2413, v_ysp_2414, v_t_2431, v_t_2433, v_t_2435}), v_sp_2419});
        }
      }
      default: return heff_nomatch(v_d_241);
      }
    }
    case TAG_DeclTheory: {
      V v_y_2436 = heff_field(v_d1_242, 0);
      V v_ysp_2437 = heff_field(v_d1_242, 1);
      V v_ps_2438 = heff_field(v_d1_242, 2);
      V v_body_2439 = heff_field(v_d1_242, 3);
      V v_ru_24d1_242_24DeclTheory = heff_take_reuse_n(v_d1_242, 15ULL, 4);
      switch (heff_tag_of(v_d_241)) {
      case TAG_At: {
        V v_sp_2441 = heff_dup(heff_field(v_d_241, 1));
        if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 0)), heff_dup(v_y_2436))) {
          heff_drop_rec(v_r_240, 5);
          heff_drop(v_y_2436);
          heff_drop(v_ysp_2437);
          heff_drop(v_ps_2438);
          heff_drop(v_body_2439);
          heff_drop_cell(v_ru_24d1_242_24DeclTheory, 4);
          heff_drop(v_sp_2441);
          return v_d_241;
        } else {
          heff_drop_tag(v_d_241, 2);
          V v_t_2453 = (g_heff_2eelab_2eclauses_2erenameSeq_24s595361288x433123245(heff_rfield(v_r_240, 0), heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam1, 1, 1, (V[]){heff_dup(v_r_240)}), heff_dup(v_ps_2438)));
          V v_t_2454 = ({ V a_0 = heff_rfield(v_r_240, 0); V a_1 = v_ps_2438; V r_ = (g_heff_2eelab_2eclauses_2eanyC_24s77926680x1031377762(a_0, a_1)); heff_drop(v_ps_2438); r_; });
          V v_t_2455;
          if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
            heff_drop_rec(v_r_240, 5);
            heff_drop(v_t_2454);
            v_t_2455 = v_body_2439;
          } else {
            heff_drop(v_t_2454);
            v_t_2455 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_body_2439}));
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_y_2436, v_ysp_2437, v_t_2453, v_t_2455}), v_sp_2441});
        }
      }
      default: return heff_nomatch(v_d_241);
      }
    }
    case TAG_DeclPrimitive: {
      V v_y_2456 = heff_field(v_d1_242, 0);
      V v_ysp_2457 = heff_field(v_d1_242, 1);
      V v_t_2458 = heff_field(v_d1_242, 2);
      V v_ru_24d1_242_24DeclPrimitive = heff_take_reuse_n(v_d1_242, 7ULL, 3);
      switch (heff_tag_of(v_d_241)) {
      case TAG_At: {
        V v_sp_2460 = heff_field(v_d_241, 1);
        V v_ru_24d_241_24At = heff_take_reuse_n(v_d_241, 2ULL, 2);
        V v_t_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2458}));
        return heff_tag_at_n(v_ru_24d_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_y_2456, v_ysp_2457, v_t_2461}), v_sp_2460});
      }
      default: return heff_nomatch(v_d_241);
      }
    }
    case TAG_DeclTest: {
      heff_take_n(v_d1_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 5);
      return v_d_241;
    }
    case TAG_DeclWatch: {
      V v_e_2464 = heff_field(v_d1_242, 0);
      V v_ru_24d1_242_24DeclWatch = heff_take_reuse_n(v_d1_242, 1ULL, 1);
      switch (heff_tag_of(v_d_241)) {
      case TAG_At: {
        V v_sp_2466 = heff_field(v_d_241, 1);
        V v_ru_24d_241_24At = heff_take_reuse_n(v_d_241, 2ULL, 2);
        V v_t_2467 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_e_2464}));
        return heff_tag_at_n(v_ru_24d_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_2467}), v_sp_2466});
      }
      default: return heff_nomatch(v_d_241);
      }
    }
    default: return heff_nomatch(v_d1_242);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameDecl(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam0(V self, V *args) {
  V v_x2_2420 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_At: {
    V v_x21_2421 = heff_field(v_x2_2420, 0);
    V v_sp_2422 = heff_field(v_x2_2420, 1);
    V v_ru_24x2_2420_24At = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
    switch (heff_tag_of(v_x21_2421)) {
    case TAG_ExplicitParam: {
      V v_y_2423 = heff_field(v_x21_2421, 0);
      V v_ysp_2424 = heff_field(v_x21_2421, 1);
      V v_t_2425 = heff_field(v_x21_2421, 2);
      V v_ru_24x21_2421_24ExplicitParam = heff_take_reuse_n(v_x21_2421, 7ULL, 3);
      V v_t_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2425}));
      return heff_tag_at_n(v_ru_24x2_2420_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_2421_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_y_2423, v_ysp_2424, v_t_2426}), v_sp_2422});
    }
    case TAG_ImplicitParam: {
      V v_y_2427 = heff_field(v_x21_2421, 0);
      V v_ysp_2428 = heff_field(v_x21_2421, 1);
      V v_t_2429 = heff_field(v_x21_2421, 2);
      V v_ru_24x21_2421_24ImplicitParam = heff_take_reuse_n(v_x21_2421, 7ULL, 3);
      V v_t_2430 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2429}));
      return heff_tag_at_n(v_ru_24x2_2420_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_2421_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_y_2427, v_ysp_2428, v_t_2430}), v_sp_2422});
    }
    default: return heff_nomatch(v_x21_2421);
    }
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam1(V self, V *args) {
  V v_x2_2442 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_At: {
    V v_x21_2443 = heff_field(v_x2_2442, 0);
    V v_sp_2444 = heff_field(v_x2_2442, 1);
    V v_ru_24x2_2442_24At = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
    switch (heff_tag_of(v_x21_2443)) {
    case TAG_ExplicitParam: {
      V v_y_2445 = heff_field(v_x21_2443, 0);
      V v_ysp_2446 = heff_field(v_x21_2443, 1);
      V v_t_2447 = heff_field(v_x21_2443, 2);
      V v_ru_24x21_2443_24ExplicitParam = heff_take_reuse_n(v_x21_2443, 7ULL, 3);
      V v_t_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2447}));
      return heff_tag_at_n(v_ru_24x2_2442_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_2443_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_y_2445, v_ysp_2446, v_t_2448}), v_sp_2444});
    }
    case TAG_ImplicitParam: {
      V v_y_2449 = heff_field(v_x21_2443, 0);
      V v_ysp_2450 = heff_field(v_x21_2443, 1);
      V v_t_2451 = heff_field(v_x21_2443, 2);
      V v_ru_24x21_2443_24ImplicitParam = heff_take_reuse_n(v_x21_2443, 7ULL, 3);
      V v_t_2452 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2451}));
      return heff_tag_at_n(v_ru_24x2_2442_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_2443_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_y_2449, v_ysp_2450, v_t_2452}), v_sp_2444});
    }
    default: return heff_nomatch(v_x21_2443);
    }
  }
  default: return heff_nomatch(v_x2_2442);
  }
}

HeffT2 g_heff_2eelab_2eclauses_2efindTagLit_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_2415;
    switch (heff_tag_of(v_p_242)) {
    case TAG_PVar: {
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    case TAG_PTag: {
      v_t_2415 = NTAG(TAG_True);
      break;
    }
    case TAG_PLit: {
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    case TAG_PRec: {
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    case TAG_PAs: {
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    case TAG_PBin: {
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_p_242);
    }
    V v_t_2494;
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_t_2415);
      v_t_2494 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2415);
      V v_t_2427;
      switch (heff_tag_of(v_p_242)) {
      case TAG_PVar: {
        v_t_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_PTag: {
        v_t_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_PLit: {
        v_t_2427 = NTAG(TAG_True);
        break;
      }
      case TAG_PRec: {
        v_t_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_PAs: {
        v_t_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_PBin: {
        v_t_2427 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_p_242);
      }
      if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
        heff_drop(v_t_2427);
        v_t_2494 = NTAG(TAG_True);
      } else {
        heff_drop(v_t_2427);
        switch (heff_tag_of(v_p_242)) {
        case TAG_PVar: {
          switch (heff_tag_of(v_p_242)) {
          case TAG_PVar: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PTag: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PLit: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PRec: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PAs: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PBin: {
            v_t_2494 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_p_242);
          }
          break;
        }
        case TAG_PTag: {
          switch (heff_tag_of(v_p_242)) {
          case TAG_PVar: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PTag: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PLit: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PRec: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PAs: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PBin: {
            v_t_2494 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_p_242);
          }
          break;
        }
        case TAG_PLit: {
          switch (heff_tag_of(v_p_242)) {
          case TAG_PVar: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PTag: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PLit: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PRec: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PAs: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PBin: {
            v_t_2494 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_p_242);
          }
          break;
        }
        case TAG_PRec: {
          v_t_2494 = NTAG(TAG_True);
          break;
        }
        case TAG_PAs: {
          switch (heff_tag_of(v_p_242)) {
          case TAG_PVar: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PTag: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PLit: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PRec: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PAs: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PBin: {
            v_t_2494 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_p_242);
          }
          break;
        }
        case TAG_PBin: {
          switch (heff_tag_of(v_p_242)) {
          case TAG_PVar: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PTag: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PLit: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PRec: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PAs: {
            v_t_2494 = NTAG(TAG_False);
            break;
          }
          case TAG_PBin: {
            v_t_2494 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_p_242);
          }
          break;
        }
        default: heff_nomatch(v_p_242);
        }
      }
    }
    if ((heff_dup(v_t_2494) == NTAG(TAG_True))) {
      heff_drop(v_t_2494);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
    } else {
      heff_drop(v_t_2494);
      V t_0 = v_rest_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2etagColAt_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2etagColAt_str1, 1, "_");
V g_heff_2eelab_2eclauses_2etagColAt_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2etagColAt_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2etagColAt_lam2(V self, V *args);
Clo g_heff_2eelab_2eclauses_2etagColAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etagColAt_entry, 5, 0};

V g_heff_2eelab_2eclauses_2etagColAt(V v_c_240, V v_v_241, V v_col_242, V v_r_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_PVar: {
    V v_x_245 = heff_field(v_x5_244, 0);
    V v_pats_246 = heff_take_field(v_r_243, 0);
    V v_e_247 = heff_get_n(v_r_243, 1, 2);
    V v_rhs_249;
    if ((heff_strEq_c_lent(v_x_245, ((V)&g_heff_2eelab_2eclauses_2etagColAt_str0), 2) ? 0 : !heff_strEq_c_lent(v_x_245, v_v_241, 0))) {
      V v_t_248 = (g_heff_2eelab_2eclauses_2erenamer(heff_dup(v_x_245), v_v_241));
      v_rhs_249 = heff_tr(heff_call(heff_get_n(v_t_248, 3, 5), 1, (V[]){v_e_247}));
    } else {
      heff_drop(v_v_241);
      v_rhs_249 = v_e_247;
    }
    V v_t_2418 = (g_std_2eordmap_2emapValues(heff_clo_n(g_heff_2eelab_2eclauses_2etagColAt_lam0, 1, 3, (V[]){v_c_240, heff_dup(v_pats_246), heff_dup(v_rhs_249)}), heff_take_field(v_col_242, 0)));
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_246, v_rhs_249}), heff_take_field(v_col_242, 2)});
    return ({ V rv_0 = v_t_2418; V rv_2 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_col_242, 2ULL, 3, shape_arms__order__anys, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  case TAG_PTag: {
    V v_t_2420 = heff_field(v_x5_244, 0);
    V v_ps_2421 = heff_field(v_x5_244, 1);
    V v_sp_2422 = heff_field(v_x5_244, 2);
    heff_drop(v_v_241);
    V v_c_2423 = heff_dup(v_c_240);
    V v_col_2424 = heff_dup(v_col_242);
    V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_2421));
    V v_t_2426 = heff_rec_n(4, shape_tag__arity__pats__span, (V[]){heff_dup(v_t_2420), v_t_2425, heff_dup(v_ps_2421), heff_dup(v_sp_2422)});
    V v_xs_2427 = heff_take_field(v_r_243, 0);
    V v_t_2428 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2427)));
    V v_t_2429 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_240, MK_INT(1LL)), v_xs_2427));
    V v_t_2430 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_ps_2421), v_t_2429));
    V v_pats_2431 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2428, v_t_2430));
    V v_r_2432 = ({ V rv_0 = v_pats_2431; V rr_ = heff_rec_reuse_nf(v_r_243, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    HeffT2 v_t_2433 = ({ V b_0 = heff_get_n(v_col_242, 0, 3); V a_1 = v_t_2420; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2435 = v_t_2433.f[1];
      int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
      if ((v_tag_2434 == ((int64_t)0ULL))) {
        heff_drop(v_c_2423);
        V v_arm_2436 = v_field_2435;
        V v_t_2437 = heff_bool(((heff_dup(heff_rfield(v_arm_2436, 1)) == NTAG(TAG_True)) || !heff_intEq_c(heff_dup(heff_rfield(v_t_2426, 1)), heff_get_n(heff_dup(heff_rfield(v_arm_2436, 0)), 1, 4))));
        V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_2432, heff_take_field(v_arm_2436, 2)});
        V v_t_2439 = ({ V rv_1 = v_t_2437; V rv_2 = v_t_2438; V rr_ = heff_rec_reuse_nf(v_arm_2436, 1ULL, 3, shape_row__bad__rows, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2440 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_col_2424, 0), heff_get_n(v_t_2426, 0, 4), v_t_2439));
        return ({ V rv_0 = v_t_2440; V rr_ = heff_rec_reuse_nf(v_col_2424, 6ULL, 3, shape_arms__order__anys, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      } else {
        heff_drop(v_field_2435);
        V v_t_2442 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2etagColAt_lam1, 1, 2, (V[]){v_c_2423, heff_dup(v_t_2426)}), heff_dup(heff_rfield(v_col_2424, 2))));
        V v_t_2443 = heff_rec_n(3, shape_row__bad__rows, (V[]){heff_dup(v_t_2426), NTAG(TAG_False), heff_tag_n(TAG_Cons, 2, (V[]){v_r_2432, v_t_2442})});
        V v_t_2444 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_col_2424, 0), heff_dup(heff_rfield(v_t_2426, 0)), v_t_2443));
        V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, heff_take_field(v_col_2424, 1)});
        return ({ V rv_0 = v_t_2444; V rv_1 = v_t_2445; V rr_ = heff_rec_reuse_nf(v_col_2424, 4ULL, 3, shape_arms__order__anys, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
    }
  }
  case TAG_PLit: {
    heff_drop(v_v_241);
    V v_t_2451 = (g_std_2eordmap_2emapValues(heff_clo_n(g_heff_2eelab_2eclauses_2etagColAt_lam2, 1, 2, (V[]){v_c_240, heff_dup(v_r_243)}), heff_take_field(v_col_242, 0)));
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243, heff_take_field(v_col_242, 2)});
    return ({ V rv_0 = v_t_2451; V rv_2 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_col_242, 2ULL, 3, shape_arms__order__anys, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  case TAG_PRec: {
    heff_drop(v_c_240);
    heff_drop(v_v_241);
    heff_drop_rec(v_r_243, 2);
    return v_col_242;
  }
  case TAG_PAs: {
    heff_drop(v_c_240);
    heff_drop(v_v_241);
    heff_drop_rec(v_r_243, 2);
    return v_col_242;
  }
  case TAG_PBin: {
    heff_drop(v_c_240);
    heff_drop(v_v_241);
    heff_drop_rec(v_r_243, 2);
    return v_col_242;
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eclauses_2etagColAt_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2etagColAt(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2eelab_2eclauses_2etagColAt_lam0(V self, V *args) {
  V v_arm_2410 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_pats_246 = heff_env(self)[1];
  V v_rhs_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_arm_2410, 0)), 1, 4);
  V v_ys_2412 = (g_list_2emap_24f1539731936x1117725130(((V)&g_heff_2eelab_2eclauses_2etagColAt_str1), MK_INT(0LL), v_t_2411));
  V v_t_2413 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_pats_246)));
  V v_t_2414 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_240, MK_INT(1LL)), v_pats_246));
  V v_t_2415 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2412, v_t_2414));
  V v_pats_2416 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2413, v_t_2415));
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2416, v_rhs_249}), heff_take_field(v_arm_2410, 2)});
  return ({ V rv_2 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_arm_2410, 3ULL, 3, shape_row__bad__rows, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eclauses_2etagColAt_lam1(V self, V *args) {
  V v_a_2441 = args[0];
  V v_c_2423 = heff_env(self)[0];
  V v_t_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2eclauses_2eanyIn(v_c_2423, heff_get_n(v_t_2426, 1, 4), v_a_2441));
}
V g_heff_2eelab_2eclauses_2etagColAt_lam2(V self, V *args) {
  V v_arm_2447 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_r_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2448 = heff_get_n(heff_dup(heff_rfield(v_arm_2447, 0)), 1, 4);
  V v_t_2449 = (g_heff_2eelab_2eclauses_2eanyIn(v_c_240, v_t_2448, v_r_243));
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, heff_take_field(v_arm_2447, 2)});
  return ({ V rv_2 = v_t_2450; V rr_ = heff_rec_reuse_nf(v_arm_2447, 3ULL, 3, shape_row__bad__rows, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
HEFF_LIT(g_heff_2eelab_2eclauses_2elitYes_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2elitYes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitYes_entry, 4, 0};

V g_heff_2eelab_2eclauses_2elitYes(V v_c_240, V v_l_241, V v_v_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_l_241);
    heff_drop(v_v_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_c_246 = heff_dup(v_c_240);
    V v_l_247 = heff_dup(v_l_241);
    V v_v_248 = heff_dup(v_v_242);
    V v_r_249 = v_r_244;
    V v_acc_2410 = (g_heff_2eelab_2eclauses_2elitYes(v_c_240, v_l_241, v_v_242, v_rest_245));
    HeffT2 v_t_2411 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_rfield(v_r_249, 0), heff_dup(v_c_246)));
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_p_2414 = v_field_2413;
        switch (heff_tag_of(v_p_2414)) {
        case TAG_PVar: {
          V v_x_2415 = heff_field(v_p_2414, 0);
          heff_take_n(v_p_2414, 1ULL, 1);
          heff_drop(v_l_247);
          V v_pats_2416 = (g_heff_2eelab_2eclauses_2edropAt(v_c_246, heff_take_field(v_r_249, 0)));
          V v_e_2417 = heff_get_n(v_r_249, 1, 2);
          V v_rhs_2419;
          if ((heff_strEq_c_lent(v_x_2415, ((V)&g_heff_2eelab_2eclauses_2elitYes_str0), 2) ? 0 : !heff_strEq_c_lent(v_x_2415, v_v_248, 0))) {
            V v_t_2418 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2415, v_v_248));
            v_rhs_2419 = heff_tr(heff_call(heff_get_n(v_t_2418, 3, 5), 1, (V[]){v_e_2417}));
          } else {
            heff_drop(v_v_248);
            heff_drop(v_x_2415);
            v_rhs_2419 = v_e_2417;
          }
          return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2416, v_rhs_2419}), v_acc_2410});
        }
        case TAG_PTag: {
          heff_take_n(v_p_2414, 0ULL, 3);
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          heff_drop(v_c_246);
          heff_drop(v_l_247);
          heff_drop(v_v_248);
          heff_drop_rec(v_r_249, 2);
          return v_acc_2410;
        }
        case TAG_PLit: {
          V v_l_27_2423 = heff_field(v_p_2414, 0);
          heff_take_n(v_p_2414, 1ULL, 1);
          heff_drop(v_v_248);
          V v_t_2424 = ({ V a_0 = v_l_247; V a_1 = v_l_27_2423; V r_ = (g_heff_2eelab_2eclauses_2esameLit(a_0, a_1)); heff_drop(v_l_247); heff_drop(v_l_27_2423); r_; });
          if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
            heff_drop(v_t_2424);
            V v_pats_2425 = (g_heff_2eelab_2eclauses_2edropAt(v_c_246, heff_take_field(v_r_249, 0)));
            V v_t_2426 = ({ V rv_0 = v_pats_2425; V rr_ = heff_rec_reuse_nf(v_r_249, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2426, v_acc_2410});
          } else {
            heff_drop_cell(v_ru_24x4_243_24Cons, 2);
            heff_drop(v_c_246);
            heff_drop_rec(v_r_249, 2);
            heff_drop(v_t_2424);
            return v_acc_2410;
          }
        }
        case TAG_PRec: {
          heff_take_n(v_p_2414, 0ULL, 2);
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          heff_drop(v_c_246);
          heff_drop(v_l_247);
          heff_drop(v_v_248);
          heff_drop_rec(v_r_249, 2);
          return v_acc_2410;
        }
        case TAG_PAs: {
          heff_take_n(v_p_2414, 0ULL, 2);
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          heff_drop(v_c_246);
          heff_drop(v_l_247);
          heff_drop(v_v_248);
          heff_drop_rec(v_r_249, 2);
          return v_acc_2410;
        }
        case TAG_PBin: {
          heff_take_n(v_p_2414, 0ULL, 2);
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          heff_drop(v_c_246);
          heff_drop(v_l_247);
          heff_drop(v_v_248);
          heff_drop_rec(v_r_249, 2);
          return v_acc_2410;
        }
        default: return heff_nomatch(v_p_2414);
        }
      } else {
        heff_drop(v_l_247);
        heff_drop(v_v_248);
        heff_drop(v_field_2413);
        V v_pats_2433 = (g_heff_2eelab_2eclauses_2edropAt(v_c_246, heff_take_field(v_r_249, 0)));
        V v_t_2434 = ({ V rv_0 = v_pats_2433; V rr_ = heff_rec_reuse_nf(v_r_249, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2434, v_acc_2410});
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eclauses_2elitYes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2elitYes(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eclauses_2elitNo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitNo_entry, 3, 0};

V g_heff_2eelab_2eclauses_2elitNo(V v_c_240, V v_l_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_l_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_c_245 = heff_dup(v_c_240);
    V v_l_246 = heff_dup(v_l_241);
    V v_r_247 = v_r_243;
    V v_acc_248 = (g_heff_2eelab_2eclauses_2elitNo(v_c_240, v_l_241, v_rest_244));
    HeffT2 v_t_249 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_rfield(v_r_247, 0), v_c_245));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_p_2412 = v_field_2411;
        switch (heff_tag_of(v_p_2412)) {
        case TAG_PVar: {
          heff_take_n(v_p_2412, 0ULL, 1);
          heff_drop(v_l_246);
          return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_r_247, v_acc_248});
        }
        case TAG_PTag: {
          heff_take_n(v_p_2412, 0ULL, 3);
          heff_drop(v_l_246);
          return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_r_247, v_acc_248});
        }
        case TAG_PLit: {
          V v_l_27_2417 = heff_field(v_p_2412, 0);
          heff_take_n(v_p_2412, 1ULL, 1);
          V v_t_2418 = ({ V a_0 = v_l_246; V a_1 = v_l_27_2417; V r_ = (g_heff_2eelab_2eclauses_2esameLit(a_0, a_1)); heff_drop(v_l_246); heff_drop(v_l_27_2417); r_; });
          if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            heff_drop_rec(v_r_247, 2);
            heff_drop(v_t_2418);
            return v_acc_248;
          } else {
            heff_drop(v_t_2418);
            return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_r_247, v_acc_248});
          }
        }
        case TAG_PRec: {
          heff_take_n(v_p_2412, 0ULL, 2);
          heff_drop(v_l_246);
          return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_r_247, v_acc_248});
        }
        case TAG_PAs: {
          heff_take_n(v_p_2412, 0ULL, 2);
          heff_drop(v_l_246);
          return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_r_247, v_acc_248});
        }
        case TAG_PBin: {
          heff_take_n(v_p_2412, 0ULL, 2);
          heff_drop(v_l_246);
          return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_r_247, v_acc_248});
        }
        default: return heff_nomatch(v_p_2412);
        }
      } else {
        heff_drop(v_l_246);
        heff_drop(v_field_2411);
        return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_r_247, v_acc_248});
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2elitNo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2elitNo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_24cpr_str0, 43, "a literal and a tag match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_24cpr_str1, 46, "a literal and a binary match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_24cpr_str2, 88, "literals are matched here: one of them must match every other value (a variable, or `_`)");
V g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2elitChecks_24cpr(V v_sp_240, V v_vars_241, V v_rows_242, V v_c_243, V v_l_244) {
top: ;
  V v_t_2421 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam0, 1, 1, (V[]){heff_dup(v_c_243)}), v_rows_242));
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_c_243);
    heff_drop(v_t_2421);
    V v_t_2424;
    switch (heff_tag_of(v_l_244)) {
    case TAG_At: {
      V v_s_2423 = heff_field(v_l_244, 1);
      v_t_2424 = heff_dup(v_s_2423);
      break;
    }
    default: heff_nomatch(v_l_244);
    }
    V v_f_2425 = heff_rec_n(2, shape_span__msg, (V[]){v_t_2424, ((V)&g_heff_2eelab_2eclauses_2elitChecks_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2425}});
  } else {
    heff_drop(v_t_2421);
    V v_t_2442 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam1, 1, 1, (V[]){heff_dup(v_c_243)}), v_rows_242));
    if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
      heff_drop(v_c_243);
      heff_drop(v_t_2442);
      V v_t_2445;
      switch (heff_tag_of(v_l_244)) {
      case TAG_At: {
        V v_s_2444 = heff_field(v_l_244, 1);
        v_t_2445 = heff_dup(v_s_2444);
        break;
      }
      default: heff_nomatch(v_l_244);
      }
      V v_f_2446 = heff_rec_n(2, shape_span__msg, (V[]){v_t_2445, ((V)&g_heff_2eelab_2eclauses_2elitChecks_24cpr_str1)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2446}});
    } else {
      heff_drop(v_t_2442);
      V v_t_2463 = (g_heff_2eelab_2eclauses_2eallC(heff_clo_n(g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam2, 1, 1, (V[]){v_c_243}), v_rows_242));
      if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
        heff_drop(v_t_2463);
        V v_t_2466;
        switch (heff_tag_of(v_l_244)) {
        case TAG_At: {
          V v_s_2465 = heff_field(v_l_244, 1);
          v_t_2466 = heff_dup(v_s_2465);
          break;
        }
        default: heff_nomatch(v_l_244);
        }
        V v_f_2467 = heff_rec_n(2, shape_span__msg, (V[]){v_t_2466, ((V)&g_heff_2eelab_2eclauses_2elitChecks_24cpr_str2)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2467}});
      } else {
        heff_drop(v_t_2463);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_MkUnit)}});
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam0(V self, V *args) {
  V v_row_245 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_row_245, 0, 2); V a_1 = v_c_243; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_p_249 = v_field_248;
      switch (heff_tag_of(v_p_249)) {
      case TAG_PVar: {
        heff_take_n(v_p_249, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_PTag: {
        heff_take_n(v_p_249, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_PLit: {
        heff_take_n(v_p_249, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_PRec: {
        heff_take_n(v_p_249, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_PAs: {
        heff_take_n(v_p_249, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_PBin: {
        heff_take_n(v_p_249, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_p_249);
      }
    } else {
      heff_drop(v_field_248);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam1(V self, V *args) {
  V v_row_2426 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2427 = ({ V b_0 = heff_get_n(v_row_2426, 0, 2); V a_1 = v_c_243; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2429 = v_t_2427.f[1];
    int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
    if ((v_tag_2428 == ((int64_t)0ULL))) {
      V v_p_2430 = v_field_2429;
      switch (heff_tag_of(v_p_2430)) {
      case TAG_PVar: {
        heff_take_n(v_p_2430, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_PTag: {
        heff_take_n(v_p_2430, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_PLit: {
        heff_take_n(v_p_2430, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_PRec: {
        heff_take_n(v_p_2430, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_PAs: {
        heff_take_n(v_p_2430, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_PBin: {
        heff_take_n(v_p_2430, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_p_2430);
      }
    } else {
      heff_drop(v_field_2429);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam2(V self, V *args) {
  V v_row_2447 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2448 = ({ V b_0 = heff_get_n(v_row_2447, 0, 2); V a_1 = v_c_243; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2450 = v_t_2448.f[1];
    int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
    if ((v_tag_2449 == ((int64_t)0ULL))) {
      V v_p_2451 = v_field_2450;
      switch (heff_tag_of(v_p_2451)) {
      case TAG_PVar: {
        heff_take_n(v_p_2451, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_PTag: {
        heff_take_n(v_p_2451, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_PLit: {
        heff_take_n(v_p_2451, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_PRec: {
        heff_take_n(v_p_2451, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_PAs: {
        heff_take_n(v_p_2451, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_PBin: {
        heff_take_n(v_p_2451, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_p_2451);
      }
    } else {
      heff_drop(v_field_2450);
      return NTAG(TAG_False);
    }
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2enoRecMix_24cpr_str0, 42, "a record and a tag match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2enoRecMix_24cpr_str1, 46, "a record and a literal match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2enoRecMix_24cpr_str2, 45, "a record and a binary match the same argument");
V g_heff_2eelab_2eclauses_2enoRecMix_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2enoRecMix_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2enoRecMix_24cpr(V v_rows_240, V v_c_241) {
top: ;
  V v_t_2418 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2enoRecMix_24cpr_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_rows_240));
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    HEFF_LAST return g_heff_2eelab_2eclauses_2eforC_24cpr(v_rows_240, heff_clo_n(g_heff_2eelab_2eclauses_2enoRecMix_24cpr_lam1, 1, 1, (V[]){v_c_241}));
  } else {
    heff_drop(v_c_241);
    heff_drop(v_t_2418);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_MkUnit)}});
  }
}
V g_heff_2eelab_2eclauses_2enoRecMix_24cpr_lam0(V self, V *args) {
  V v_row_242 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_row_242, 0, 2); V a_1 = v_c_241; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_p_246 = v_field_245;
      switch (heff_tag_of(v_p_246)) {
      case TAG_PVar: {
        heff_take_n(v_p_246, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_PTag: {
        heff_take_n(v_p_246, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_PLit: {
        heff_take_n(v_p_246, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_PRec: {
        heff_take_n(v_p_246, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_PAs: {
        heff_take_n(v_p_246, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_PBin: {
        heff_take_n(v_p_246, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_p_246);
      }
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2eelab_2eclauses_2enoRecMix_24cpr_lam1(V self, V *args) {
  V v_row_2419 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2420 = ({ V b_0 = heff_get_n(v_row_2419, 0, 2); V a_1 = v_c_241; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2422 = v_t_2420.f[1];
    int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
    if ((v_tag_2421 == ((int64_t)0ULL))) {
      V v_p_2423 = v_field_2422;
      switch (heff_tag_of(v_p_2423)) {
      case TAG_PVar: {
        V v_ru_24p_2423_24PVar = heff_take_reuse_n(v_p_2423, 0ULL, 1);
        return heff_tag_at_n(v_ru_24p_2423_24PVar, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_PTag: {
        V v_sp_2427 = heff_field(v_p_2423, 2);
        heff_take_n(v_p_2423, 4ULL, 3);
        return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_sp_2427, ((V)&g_heff_2eelab_2eclauses_2enoRecMix_24cpr_str0)})});
      }
      case TAG_PLit: {
        V v_l_2428 = heff_field(v_p_2423, 0);
        V v_ru_24p_2423_24PLit = heff_take_reuse_n(v_p_2423, 1ULL, 1);
        V v_t_2431;
        switch (heff_tag_of(v_l_2428)) {
        case TAG_At: {
          V v_s_2430 = heff_field(v_l_2428, 1);
          heff_take_n(v_l_2428, 2ULL, 2);
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_l_2428);
        }
        return heff_tag_at_n(v_ru_24p_2423_24PLit, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_t_2431, ((V)&g_heff_2eelab_2eclauses_2enoRecMix_24cpr_str1)})});
      }
      case TAG_PRec: {
        heff_take_n(v_p_2423, 0ULL, 2);
        return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_PAs: {
        heff_take_n(v_p_2423, 0ULL, 2);
        return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_PBin: {
        V v_bsp_2437 = heff_field(v_p_2423, 1);
        heff_take_n(v_p_2423, 2ULL, 2);
        return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_bsp_2437, ((V)&g_heff_2eelab_2eclauses_2enoRecMix_24cpr_str2)})});
      }
      default: return heff_nomatch(v_p_2423);
      }
    } else {
      heff_drop(v_field_2422);
      return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ewidthBy_str0, 6, "intMul");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewidthBy_str1, 6, "intMul");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewidthBy_str2, 6, "intMul");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewidthBy_str3, 6, "intMul");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewidthBy_str4, 6, "intMul");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewidthBy_str5, 6, "intMul");
Clo g_heff_2eelab_2eclauses_2ewidthBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ewidthBy_entry, 5, 0};

V g_heff_2eelab_2eclauses_2ewidthBy(V v_env_240, V v_sp_241, V v_ty_242, V v_x4_243, V v_v_244) {
top: ;
  switch (heff_tag_of(v_ty_242)) {
  case TAG_SegmentInteger: {
    switch (heff_tag_of(v_x4_243)) {
    case TAG_SizeDefault: {
      heff_drop(v_sp_241);
      return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(8LL), NTAG(TAG_Nil)});
    }
    case TAG_SizeNumber: {
      V v_n_245 = heff_field(v_x4_243, 0);
      heff_drop(v_sp_241);
      return heff_rec_n(2, shape_bits__terms, (V[]){heff_dup(v_n_245), NTAG(TAG_Nil)});
    }
    case TAG_SizeName: {
      V v_x_246 = heff_field(v_x4_243, 0);
      V v_xsp_247 = heff_field(v_x4_243, 1);
      V v_x43_248 = heff_field(v_x4_243, 2);
      if (heff_intEq_c_lent(v_x43_248, MK_INT(1LL), 2)) {
        heff_drop(v_sp_241);
        V v_x_249 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_246)));
        V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_249}), heff_dup(v_xsp_247)});
        V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2410}), heff_dup(v_xsp_247)});
        V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2412});
      } else {
        V v_x_2413 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_246)));
        V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2413}), heff_dup(v_xsp_247)});
        V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2414}), heff_dup(v_xsp_247)});
        V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_x43_248)}), heff_dup(v_sp_241)});
        V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2416}), heff_dup(v_sp_241)});
        V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
        V v_args_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2418});
        V v_t_2420 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2419));
        V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ewidthBy_str0)}), heff_dup(v_sp_241)});
        V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2421, v_t_2420}), heff_dup(v_sp_241)});
        V v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2422}), v_sp_241});
        V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2424});
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  case TAG_SegmentBinary: {
    switch (heff_tag_of(v_x4_243)) {
    case TAG_SizeDefault: {
      heff_drop(v_sp_241);
      switch (heff_tag_of(v_v_244)) {
      case TAG_At: {
        V v_v1_2425 = heff_field(v_v_244, 0);
        switch (heff_tag_of(v_v1_2425)) {
        case TAG_PatVar: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatTag: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatOp: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatInt: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatFloat: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatString: {
          V v_str_2436 = heff_field(v_v1_2425, 0);
          int64_t v_t_2437 = (((int64_t)8ULL) * heff_unbox_word(heff_strLength_lent(v_str_2436, 0)));
          return heff_rec_n(2, shape_bits__terms, (V[]){heff_box_word(v_t_2437), NTAG(TAG_Nil)});
        }
        case TAG_PatBinary: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatRune: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatRecord: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatWord: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatAs: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        default: return heff_nomatch(v_v1_2425);
        }
      }
      default: return heff_nomatch(v_v_244);
      }
    }
    case TAG_SizeNumber: {
      V v_n_2445 = heff_field(v_x4_243, 0);
      heff_drop(v_sp_241);
      return heff_rec_n(2, shape_bits__terms, (V[]){heff_dup(v_n_2445), NTAG(TAG_Nil)});
    }
    case TAG_SizeName: {
      V v_x_2446 = heff_field(v_x4_243, 0);
      V v_xsp_2447 = heff_field(v_x4_243, 1);
      V v_x43_2448 = heff_field(v_x4_243, 2);
      if (heff_intEq_c_lent(v_x43_2448, MK_INT(1LL), 2)) {
        heff_drop(v_sp_241);
        V v_x_2449 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_2446)));
        V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2449}), heff_dup(v_xsp_2447)});
        V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2450}), heff_dup(v_xsp_2447)});
        V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2452});
      } else {
        V v_x_2453 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_2446)));
        V v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2453}), heff_dup(v_xsp_2447)});
        V v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2454}), heff_dup(v_xsp_2447)});
        V v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_x43_2448)}), heff_dup(v_sp_241)});
        V v_t_2457 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2456}), heff_dup(v_sp_241)});
        V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, NTAG(TAG_Nil)});
        V v_args_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_t_2458});
        V v_t_2460 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2459));
        V v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ewidthBy_str1)}), heff_dup(v_sp_241)});
        V v_t_2462 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2461, v_t_2460}), heff_dup(v_sp_241)});
        V v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2462}), v_sp_241});
        V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2464});
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  case TAG_SegmentBits: {
    switch (heff_tag_of(v_x4_243)) {
    case TAG_SizeDefault: {
      heff_drop(v_sp_241);
      return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_SizeNumber: {
      V v_n_2465 = heff_field(v_x4_243, 0);
      heff_drop(v_sp_241);
      return heff_rec_n(2, shape_bits__terms, (V[]){heff_dup(v_n_2465), NTAG(TAG_Nil)});
    }
    case TAG_SizeName: {
      V v_x_2466 = heff_field(v_x4_243, 0);
      V v_xsp_2467 = heff_field(v_x4_243, 1);
      V v_x43_2468 = heff_field(v_x4_243, 2);
      if (heff_intEq_c_lent(v_x43_2468, MK_INT(1LL), 2)) {
        heff_drop(v_sp_241);
        V v_x_2469 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_2466)));
        V v_t_2470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2469}), heff_dup(v_xsp_2467)});
        V v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2470}), heff_dup(v_xsp_2467)});
        V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2471, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2472});
      } else {
        V v_x_2473 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_2466)));
        V v_t_2474 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2473}), heff_dup(v_xsp_2467)});
        V v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2474}), heff_dup(v_xsp_2467)});
        V v_t_2476 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_x43_2468)}), heff_dup(v_sp_241)});
        V v_t_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2476}), heff_dup(v_sp_241)});
        V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, NTAG(TAG_Nil)});
        V v_args_2479 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, v_t_2478});
        V v_t_2480 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2479));
        V v_t_2481 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ewidthBy_str2)}), heff_dup(v_sp_241)});
        V v_t_2482 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2481, v_t_2480}), heff_dup(v_sp_241)});
        V v_t_2483 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2482}), v_sp_241});
        V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2483, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2484});
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  case TAG_SegmentFloat: {
    switch (heff_tag_of(v_x4_243)) {
    case TAG_SizeDefault: {
      heff_drop(v_sp_241);
      return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(64LL), NTAG(TAG_Nil)});
    }
    case TAG_SizeNumber: {
      V v_n_2485 = heff_field(v_x4_243, 0);
      heff_drop(v_sp_241);
      return heff_rec_n(2, shape_bits__terms, (V[]){heff_dup(v_n_2485), NTAG(TAG_Nil)});
    }
    case TAG_SizeName: {
      V v_x_2486 = heff_field(v_x4_243, 0);
      V v_xsp_2487 = heff_field(v_x4_243, 1);
      V v_x43_2488 = heff_field(v_x4_243, 2);
      if (heff_intEq_c_lent(v_x43_2488, MK_INT(1LL), 2)) {
        heff_drop(v_sp_241);
        V v_x_2489 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_2486)));
        V v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2489}), heff_dup(v_xsp_2487)});
        V v_t_2491 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2490}), heff_dup(v_xsp_2487)});
        V v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2491, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2492});
      } else {
        V v_x_2493 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_2486)));
        V v_t_2494 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2493}), heff_dup(v_xsp_2487)});
        V v_t_2495 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2494}), heff_dup(v_xsp_2487)});
        V v_t_2496 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_x43_2488)}), heff_dup(v_sp_241)});
        V v_t_2497 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2496}), heff_dup(v_sp_241)});
        V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2497, NTAG(TAG_Nil)});
        V v_args_2499 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2495, v_t_2498});
        V v_t_24100 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2499));
        V v_t_24101 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ewidthBy_str3)}), heff_dup(v_sp_241)});
        V v_t_24102 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24101, v_t_24100}), heff_dup(v_sp_241)});
        V v_t_24103 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24102}), v_sp_241});
        V v_t_24104 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24103, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_24104});
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  case TAG_SegmentUtf: {
    V v_ty1_24105 = heff_field(v_ty_242, 0);
    V v_ru_24ty_242_24SegmentUtf = heff_take_reuse_n(v_ty_242, 1ULL, 1);
    if (heff_intEq_c(v_ty1_24105, MK_INT(32LL))) {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_SizeDefault: {
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24ty_242_24SegmentUtf, 1);
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(32LL), NTAG(TAG_Nil)});
      }
      case TAG_SizeNumber: {
        V v_n_24106 = heff_field(v_x4_243, 0);
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24ty_242_24SegmentUtf, 1);
        return heff_rec_n(2, shape_bits__terms, (V[]){heff_dup(v_n_24106), NTAG(TAG_Nil)});
      }
      case TAG_SizeName: {
        V v_x_24107 = heff_field(v_x4_243, 0);
        V v_xsp_24108 = heff_field(v_x4_243, 1);
        V v_x43_24109 = heff_field(v_x4_243, 2);
        if (heff_intEq_c_lent(v_x43_24109, MK_INT(1LL), 2)) {
          heff_drop(v_sp_241);
          V v_x_24110 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_24107)));
          V v_t_24111 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24ty_242_24SegmentUtf, TAG_IVar, 1, (V[]){v_x_24110}), heff_dup(v_xsp_24108)});
          V v_t_24112 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24111}), heff_dup(v_xsp_24108)});
          V v_t_24113 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24112, NTAG(TAG_Nil)});
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_24113});
        } else {
          V v_x_24114 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_24107)));
          V v_t_24115 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24ty_242_24SegmentUtf, TAG_IVar, 1, (V[]){v_x_24114}), heff_dup(v_xsp_24108)});
          V v_t_24116 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24115}), heff_dup(v_xsp_24108)});
          V v_t_24117 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_x43_24109)}), heff_dup(v_sp_241)});
          V v_t_24118 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24117}), heff_dup(v_sp_241)});
          V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24118, NTAG(TAG_Nil)});
          V v_args_24120 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24116, v_t_24119});
          V v_t_24121 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_24120));
          V v_t_24122 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ewidthBy_str4)}), heff_dup(v_sp_241)});
          V v_t_24123 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24122, v_t_24121}), heff_dup(v_sp_241)});
          V v_t_24124 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24123}), v_sp_241});
          V v_t_24125 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24124, NTAG(TAG_Nil)});
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_24125});
        }
      }
      default: return heff_nomatch(v_x4_243);
      }
    } else {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_SizeDefault: {
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24ty_242_24SegmentUtf, 1);
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      }
      case TAG_SizeNumber: {
        V v_n_24126 = heff_field(v_x4_243, 0);
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24ty_242_24SegmentUtf, 1);
        return heff_rec_n(2, shape_bits__terms, (V[]){heff_dup(v_n_24126), NTAG(TAG_Nil)});
      }
      case TAG_SizeName: {
        V v_x_24127 = heff_field(v_x4_243, 0);
        V v_xsp_24128 = heff_field(v_x4_243, 1);
        V v_x43_24129 = heff_field(v_x4_243, 2);
        if (heff_intEq_c_lent(v_x43_24129, MK_INT(1LL), 2)) {
          heff_drop(v_sp_241);
          V v_x_24130 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_24127)));
          V v_t_24131 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24ty_242_24SegmentUtf, TAG_IVar, 1, (V[]){v_x_24130}), heff_dup(v_xsp_24128)});
          V v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24131}), heff_dup(v_xsp_24128)});
          V v_t_24133 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_24133});
        } else {
          V v_x_24134 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_24127)));
          V v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24ty_242_24SegmentUtf, TAG_IVar, 1, (V[]){v_x_24134}), heff_dup(v_xsp_24128)});
          V v_t_24136 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24135}), heff_dup(v_xsp_24128)});
          V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_x43_24129)}), heff_dup(v_sp_241)});
          V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24137}), heff_dup(v_sp_241)});
          V v_t_24139 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24138, NTAG(TAG_Nil)});
          V v_args_24140 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24136, v_t_24139});
          V v_t_24141 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_24140));
          V v_t_24142 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ewidthBy_str5)}), heff_dup(v_sp_241)});
          V v_t_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24142, v_t_24141}), heff_dup(v_sp_241)});
          V v_t_24144 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24143}), v_sp_241});
          V v_t_24145 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24144, NTAG(TAG_Nil)});
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_24145});
        }
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
  }
  default: return heff_nomatch(v_ty_242);
  }
}
V g_heff_2eelab_2eclauses_2ewidthBy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2ewidthBy(a0, a[1], a[2], a3, a4); heff_drop(a0); heff_drop(a3); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eintRead_str0, 9, "bitsIntAt");
HEFF_LIT(g_heff_2eelab_2eclauses_2eintRead_str1, 10, "bytesIntAt");
HEFF_LIT(g_heff_2eelab_2eclauses_2eintRead_str2, 6, "intAdd");
HEFF_LIT(g_heff_2eelab_2eclauses_2eintRead_str3, 6, "intAdd");
Clo g_heff_2eelab_2eclauses_2eintRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eintRead_entry, 4, 0};

V g_heff_2eelab_2eclauses_2eintRead(V v_k_240, V v_off_241, V v_w_242, V v_flags_243) {
top: ;
  V v_bits_244 = heff_take_field(v_w_242, 0);
  V v_terms_245 = heff_get_n(v_w_242, 1, 2);
  V v_bits_246 = heff_take_field(v_off_241, 0);
  V v_terms_247 = heff_get_n(v_off_241, 1, 2);
  V v_bits_248 = heff_take_field(v_k_240, 1);
  V v_v_249 = heff_take_field(v_k_240, 0);
  V v_span_2410 = heff_get_n(v_k_240, 6, 7);
  V v_p_2411;
  if ((heff_dup(v_bits_248) == NTAG(TAG_True))) {
    heff_drop(v_bits_248);
    v_p_2411 = ((V)&g_heff_2eelab_2eclauses_2eintRead_str0);
  } else {
    heff_drop(v_bits_248);
    v_p_2411 = ((V)&g_heff_2eelab_2eclauses_2eintRead_str1);
  }
  V v_x_2412 = v_v_249;
  V v_sp_2413 = heff_dup(v_span_2410);
  V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2412}), heff_dup(v_sp_2413)});
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2414}), v_sp_2413});
  V v_sp_2416 = heff_dup(v_span_2410);
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_bits_246}), heff_dup(v_sp_2416)});
  V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2417}), heff_dup(v_sp_2416)});
  V v_t_2419 = (g_list_2efoldl_24s871632021x1241775640(((V)&g_heff_2eelab_2eclauses_2eintRead_str2), v_sp_2416, v_t_2418, v_terms_247));
  V v_sp_2420 = heff_dup(v_span_2410);
  V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_bits_244}), heff_dup(v_sp_2420)});
  V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2421}), heff_dup(v_sp_2420)});
  V v_t_2423 = (g_list_2efoldl_24s871632021x1241775640(((V)&g_heff_2eelab_2eclauses_2eintRead_str3), v_sp_2420, v_t_2422, v_terms_245));
  V v_sp_2424 = heff_dup(v_span_2410);
  V v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_flags_243}), heff_dup(v_sp_2424)});
  V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2425}), v_sp_2424});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2427})});
  V v_args_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2428});
  V v_sp_2430 = v_span_2410;
  V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_p_2411}), heff_dup(v_sp_2430)});
  V v_t_2432 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2430), v_args_2429));
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2431, v_t_2432}), v_sp_2430});
}
V g_heff_2eelab_2eclauses_2eintRead_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eintRead(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eintTest_str0, 4, "Size");
HEFF_LIT(g_heff_2eelab_2eclauses_2eintTest_str1, 4, "Size");
HEFF_LIT(g_heff_2eelab_2eclauses_2eintTest_str2, 5, "intEq");
Clo g_heff_2eelab_2eclauses_2eintTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eintTest_entry, 9, 0};

V g_heff_2eelab_2eclauses_2eintTest(V v_t_240, V v_k_241, V v_env_242, V v_i_243, V v_off_244, V v_s_245, V v_rest_246, V v_w_247, V v_v_248) {
top: ;
  switch (heff_tag_of(v_v_248)) {
  case TAG_At: {
    V v_v1_249 = heff_field(v_v_248, 0);
    V v_ru_24v_248_24At = heff_take_reuse_n(v_v_248, 1ULL, 2);
    switch (heff_tag_of(v_v1_249)) {
    case TAG_PatVar: {
      V v_x_2411 = heff_field(v_v1_249, 0);
      V v_ru_24v1_249_24PatVar = heff_take_reuse_n(v_v1_249, 1ULL, 1);
      V v_t_2412 = (g_list_2eany_24s1006624359x760861690(v_x_2411, heff_rfield(v_k_241, 3)));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        V v_t_2413 = heff_strAppend(heff_dup(heff_rfield(v_k_241, 0)), ((V)&g_heff_2eelab_2eclauses_2eintTest_str0));
        V v_t_2414 = heff_intShow(heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
        V v_x_2415 = (g_heff_2eelab_2eclauses_2efreshIn(heff_rfield(v_k_241, 4), heff_rfield(v_k_241, 5), heff_strAppend(v_t_2413, v_t_2414)));
        V v_rhs_2416 = (g_heff_2eelab_2eclauses_2eintRead(heff_dup(v_k_241), heff_dup(v_off_244), heff_dup(v_w_247), heff_get_n(v_s_245, 3, 5)));
        V v_t_2417 = heff_strAppend(heff_take_field(v_k_241, 0), ((V)&g_heff_2eelab_2eclauses_2eintTest_str1));
        V v_t_2418 = heff_intShow(heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
        V v_t_2419 = (g_heff_2eelab_2eclauses_2efreshIn(heff_rfield(v_k_241, 4), heff_rfield(v_k_241, 5), heff_strAppend(v_t_2417, v_t_2418)));
        V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_t_2419}), v_env_242});
        V v_t_2421 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
        V v_t_2422 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
        V v_body_2423 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_t_2420, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2421, v_t_2422}), v_rest_246}));
        V v_sp_2424 = heff_get_n(v_k_241, 6, 7);
        V v_t_2425 = heff_tag_at_n(v_ru_24v_248_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24v1_249_24PatVar, TAG_PatVar, 1, (V[]){v_x_2415}), heff_dup(v_sp_2424)});
        V v_t_2428;
        switch (heff_tag_of(v_body_2423)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_body_2423, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_body_2423);
        }
        V v_t_2429 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_2424, 0)); V rr_ = heff_rec_reuse_nf(v_t_2428, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2425, v_body_2423}), v_t_2429});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhs_2416, v_t_2430}), v_sp_2424});
      } else {
        heff_drop_rec(v_k_241, 7);
        heff_drop_rec(v_s_245, 5);
        heff_drop(v_x_2411);
        heff_drop_cell(v_ru_24v1_249_24PatVar, 1);
        heff_drop(v_t_2412);
        V v_t_2431 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
        V v_t_2432 = (g_heff_2eelab_2eclauses_2eappendC_24tok2(v_ru_24v_248_24At, heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
        return heff_tail(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2431, v_t_2432}), v_rest_246});
      }
    }
    case TAG_PatInt: {
      V v_n_2433 = heff_field(v_v1_249, 0);
      V v_ru_24v1_249_24PatInt = heff_take_reuse_n(v_v1_249, 1ULL, 1);
      V v_i_2434 = (g_heff_2eelab_2eclauses_2eintRead(heff_dup(v_k_241), heff_dup(v_off_244), heff_dup(v_w_247), heff_get_n(v_s_245, 3, 5)));
      V v_t_2437;
      switch (heff_tag_of(v_i_2434)) {
      case TAG_At: {
        V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
        v_t_2437 = v_s_2436;
        break;
      }
      default: heff_nomatch(v_i_2434);
      }
      V v_t_2438 = heff_tag_at_n(v_ru_24v_248_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24v1_249_24PatInt, TAG_CInf, 1, (V[]){v_i_2434}), v_t_2437});
      V v_sp_2439 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_2440 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_n_2433}), heff_dup(v_sp_2439)});
      V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2440}), v_sp_2439});
      V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
      V v_args_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, v_t_2442});
      V v_sp_2444 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eintTest_str2)}), heff_dup(v_sp_2444)});
      V v_t_2446 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2444), v_args_2443));
      V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2445, v_t_2446}), v_sp_2444});
      V v_t_2448 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
      V v_t_2449 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
      V v_t_2450 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2448, v_t_2449}), v_rest_246}));
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2447, v_t_2450, heff_get_n(v_k_241, 6, 7)));
    }
    default: {
      heff_drop_rec(v_k_241, 7);
      heff_drop_rec(v_s_245, 5);
      heff_drop(v_v1_249);
      V v_t_2451 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
      V v_t_2452 = (g_heff_2eelab_2eclauses_2eappendC_24tok2(v_ru_24v_248_24At, heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
      return heff_tail(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2451, v_t_2452}), v_rest_246});
    }
    }
  }
  default: return heff_nomatch(v_v_248);
  }
}
V g_heff_2eelab_2eclauses_2eintTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eintTest(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_heff_2eelab_2eclauses_2ewholeBin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ewholeBin_entry, 2, 0};

V g_heff_2eelab_2eclauses_2ewholeBin(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    HeffT2 v_t_244 = (g_heff_2eelab_2eclauses_2ewholeSeg_24cpr(heff_dup(v_s_242), heff_rfield(v_s_242, 1), heff_rfield(v_s_242, 2), heff_rfield(v_s_242, 0)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_b_247 = v_field_246;
        V t_0 = v_rest_243;
        V t_1 = heff_strAppend(v_acc_241, v_b_247);
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      } else {
        heff_drop(v_acc_241);
        heff_drop(v_field_246);
        return NTAG(TAG_Nothing);
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ewholeBin_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2ewholeBin(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2ebinBind_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ebinBind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ebinBind_entry, 1, 0};

V g_heff_2eelab_2eclauses_2ebinBind(V v_k_240) {
top: ;
  return heff_rec_n(1, shape_go, (V[]){heff_clo_n(g_heff_2eelab_2eclauses_2ebinBind_lam0, 6, 1, (V[]){v_k_240})});
}
V g_heff_2eelab_2eclauses_2ebinBind_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ebinBind(a[0]);
}
V g_heff_2eelab_2eclauses_2ebinBind_lam0(V self, V *args) {
  V v_env_241 = args[0];
  V v_i_242 = args[1];
  V v_ys_243 = args[2];
  V v_off_244 = args[3];
  V v_segs_245 = args[4];
  V v_body_246 = args[5];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = (g_heff_2eelab_2eclauses_2ebinBind(heff_dup(v_k_240)));
  return (g_heff_2eelab_2eclauses_2ebinBindGo(v_t_247, v_k_240, v_env_241, v_i_242, v_ys_243, v_off_244, v_segs_245, v_body_246));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str0, 42, "a binary and a tag match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str1, 46, "a literal and a binary match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str2, 45, "a record and a binary match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str3, 88, "binaries are matched here: one of them must match every other value (a variable, or `_`)");
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam3(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2ebinChecks_24cpr(V v_rows_240, V v_c_241, V v_bsp_242) {
top: ;
  V v_t_2419 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_rows_240));
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_c_241);
    heff_drop(v_t_2419);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_bsp_242, ((V)&g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str0)})}});
  } else {
    heff_drop(v_t_2419);
    V v_t_2436 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam1, 1, 1, (V[]){heff_dup(v_c_241)}), v_rows_240));
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop(v_c_241);
      heff_drop(v_t_2436);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_bsp_242, ((V)&g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str1)})}});
    } else {
      heff_drop(v_t_2436);
      V v_t_2453 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam2, 1, 1, (V[]){heff_dup(v_c_241)}), v_rows_240));
      if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
        heff_drop(v_c_241);
        heff_drop(v_t_2453);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_bsp_242, ((V)&g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str2)})}});
      } else {
        heff_drop(v_t_2453);
        V v_t_2470 = (g_heff_2eelab_2eclauses_2eallC(heff_clo_n(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam3, 1, 1, (V[]){v_c_241}), v_rows_240));
        if ((heff_dup(v_t_2470) == NTAG(TAG_True))) {
          heff_drop(v_t_2470);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_bsp_242, ((V)&g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str3)})}});
        } else {
          heff_drop(v_bsp_242);
          heff_drop(v_t_2470);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_MkUnit)}});
        }
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam0(V self, V *args) {
  V v_row_243 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_row_243, 0, 2); V a_1 = v_c_241; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_p_247 = v_field_246;
      switch (heff_tag_of(v_p_247)) {
      case TAG_PVar: {
        heff_take_n(v_p_247, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_PTag: {
        heff_take_n(v_p_247, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_PLit: {
        heff_take_n(v_p_247, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_PRec: {
        heff_take_n(v_p_247, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_PAs: {
        heff_take_n(v_p_247, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_PBin: {
        heff_take_n(v_p_247, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_p_247);
      }
    } else {
      heff_drop(v_field_246);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam1(V self, V *args) {
  V v_row_2420 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2421 = ({ V b_0 = heff_get_n(v_row_2420, 0, 2); V a_1 = v_c_241; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2423 = v_t_2421.f[1];
    int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
    if ((v_tag_2422 == ((int64_t)0ULL))) {
      V v_p_2424 = v_field_2423;
      switch (heff_tag_of(v_p_2424)) {
      case TAG_PVar: {
        heff_take_n(v_p_2424, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_PTag: {
        heff_take_n(v_p_2424, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_PLit: {
        heff_take_n(v_p_2424, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_PRec: {
        heff_take_n(v_p_2424, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_PAs: {
        heff_take_n(v_p_2424, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_PBin: {
        heff_take_n(v_p_2424, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_p_2424);
      }
    } else {
      heff_drop(v_field_2423);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam2(V self, V *args) {
  V v_row_2437 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2438 = ({ V b_0 = heff_get_n(v_row_2437, 0, 2); V a_1 = v_c_241; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2440 = v_t_2438.f[1];
    int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
    if ((v_tag_2439 == ((int64_t)0ULL))) {
      V v_p_2441 = v_field_2440;
      switch (heff_tag_of(v_p_2441)) {
      case TAG_PVar: {
        heff_take_n(v_p_2441, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_PTag: {
        heff_take_n(v_p_2441, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_PLit: {
        heff_take_n(v_p_2441, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_PRec: {
        heff_take_n(v_p_2441, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_PAs: {
        heff_take_n(v_p_2441, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_PBin: {
        heff_take_n(v_p_2441, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_p_2441);
      }
    } else {
      heff_drop(v_field_2440);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam3(V self, V *args) {
  V v_row_2454 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2455 = ({ V b_0 = heff_get_n(v_row_2454, 0, 2); V a_1 = v_c_241; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2457 = v_t_2455.f[1];
    int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
    if ((v_tag_2456 == ((int64_t)0ULL))) {
      V v_p_2458 = v_field_2457;
      switch (heff_tag_of(v_p_2458)) {
      case TAG_PVar: {
        heff_take_n(v_p_2458, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_PTag: {
        heff_take_n(v_p_2458, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_PLit: {
        heff_take_n(v_p_2458, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_PRec: {
        heff_take_n(v_p_2458, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_PAs: {
        heff_take_n(v_p_2458, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_PBin: {
        heff_take_n(v_p_2458, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_p_2458);
      }
    } else {
      heff_drop(v_field_2457);
      return NTAG(TAG_False);
    }
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolNames_str0, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolNames_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolNames_str2, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolNames_str3, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolNames_str4, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolNames_str5, 1, "x");
V g_heff_2eelab_2eclauses_2ecolNames_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ecolNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecolNames_entry, 6, 0};

V g_heff_2eelab_2eclauses_2ecolNames(V v_used_240, V v_params_241, V v_rows_242, V v_i_243, V v_n_244, V v_taken_245) {
top: ;
  if (heff_intLe_c_lent(v_n_244, v_i_243, 0)) {
    heff_drop(v_used_240);
    heff_drop(v_rows_242);
    heff_drop(v_i_243);
    heff_drop(v_n_244);
    heff_drop(v_taken_245);
    return NTAG(TAG_Nil);
  } else {
    HeffT2 v_t_246 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_params_241, heff_dup(v_i_243)));
    V v_x_2448;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_p_249 = v_field_248;
        v_x_2448 = v_p_249;
      } else {
        heff_drop(v_field_248);
        V v_used_2410 = heff_dup(v_used_240);
        V v_taken_2411 = heff_dup(v_taken_245);
        V v_rows_2412 = heff_dup(v_rows_242);
        V v_i_2413 = heff_dup(v_i_243);
        V v_used_2414 = v_used_2410;
        V v_taken_2415 = v_taken_2411;
        V v_rows_2416 = heff_dup(v_rows_2412);
        V v_i_2417 = heff_dup(v_i_2413);
        V v_t_2434 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ecolNames_lam0, 1, 1, (V[]){v_i_2413}), v_rows_2412));
        V v_t_2435 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2434));
        V v_xs_2436 = (g_heff_2eelab_2eclauses_2enubStr(v_t_2435));
        switch (heff_tag_of(v_xs_2436)) {
        case TAG_Nil: {
          heff_drop(v_rows_2416);
          V v_t_2437 = heff_intShow(heff_box_word((heff_unbox_word(v_i_2417) + ((int64_t)1ULL))));
          v_x_2448 = ({ V a_0 = v_used_2414; V a_1 = v_taken_2415; V a_2 = heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolNames_str0), v_t_2437); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2414); heff_drop(v_taken_2415); r_; });
          break;
        }
        case TAG_Cons: {
          V v_x_2438 = heff_field(v_xs_2436, 0);
          V v_xs2_2439 = heff_field(v_xs_2436, 1);
          heff_take_n(v_xs_2436, 3ULL, 2);
          switch (heff_tag_of(v_xs2_2439)) {
          case TAG_Nil: {
            if (!heff_strEq_c_lent(v_x_2438, ((V)&g_heff_2eelab_2eclauses_2ecolNames_str1), 2)) {
              V v_x1_2440 = (g_list_2eany_24s1006624359x760861690(v_x_2438, v_taken_2415));
              if (!(heff_dup(v_x1_2440) == NTAG(TAG_True))) {
                heff_drop(v_x1_2440);
                V v_t_2441 = ({ V a_0 = v_x_2438; V a_1 = heff_dup(v_i_2417); V a_2 = v_rows_2416; V r_ = (g_heff_2eelab_2eclauses_2enameFits(a_0, a_1, a_2)); heff_drop(v_rows_2416); r_; });
                if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
                  heff_drop(v_used_2414);
                  heff_drop(v_taken_2415);
                  heff_drop(v_i_2417);
                  heff_drop(v_t_2441);
                  v_x_2448 = v_x_2438;
                } else {
                  heff_drop(v_x_2438);
                  heff_drop(v_t_2441);
                  V v_t_2442 = heff_intShow(heff_box_word((heff_unbox_word(v_i_2417) + ((int64_t)1ULL))));
                  v_x_2448 = ({ V a_0 = v_used_2414; V a_1 = v_taken_2415; V a_2 = heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolNames_str2), v_t_2442); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2414); heff_drop(v_taken_2415); r_; });
                }
              } else {
                heff_drop(v_rows_2416);
                heff_drop(v_x_2438);
                heff_drop(v_x1_2440);
                V v_t_2443 = heff_intShow(heff_box_word((heff_unbox_word(v_i_2417) + ((int64_t)1ULL))));
                v_x_2448 = ({ V a_0 = v_used_2414; V a_1 = v_taken_2415; V a_2 = heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolNames_str3), v_t_2443); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2414); heff_drop(v_taken_2415); r_; });
              }
            } else {
              heff_drop(v_rows_2416);
              heff_drop(v_x_2438);
              V v_t_2444 = heff_intShow(heff_box_word((heff_unbox_word(v_i_2417) + ((int64_t)1ULL))));
              v_x_2448 = ({ V a_0 = v_used_2414; V a_1 = v_taken_2415; V a_2 = heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolNames_str4), v_t_2444); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2414); heff_drop(v_taken_2415); r_; });
            }
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_xs2_2439, 0ULL, 2);
            heff_drop(v_rows_2416);
            heff_drop(v_x_2438);
            V v_t_2447 = heff_intShow(heff_box_word((heff_unbox_word(v_i_2417) + ((int64_t)1ULL))));
            v_x_2448 = ({ V a_0 = v_used_2414; V a_1 = v_taken_2415; V a_2 = heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolNames_str5), v_t_2447); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2414); heff_drop(v_taken_2415); r_; });
            break;
          }
          default: heff_nomatch(v_xs2_2439);
          }
          break;
        }
        default: heff_nomatch(v_xs_2436);
        }
      }
    }
    V v_cell_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2448), heff_hole()});
    V v_u_2450 = (g_heff_2eelab_2eclauses_2ecolNames_24dps(v_used_240, v_params_241, v_rows_242, heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL))), v_n_244, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2448, v_taken_245}), heff_dup(v_cell_2449)));
    heff_drop(v_u_2450);
    return v_cell_2449;
  }
}
V g_heff_2eelab_2eclauses_2ecolNames_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2ecolNames(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eclauses_2ecolNames_lam0(V self, V *args) {
  V v_r_2418 = args[0];
  V v_i_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2419 = ({ V b_0 = heff_get_n(v_r_2418, 0, 2); V a_1 = v_i_2413; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_p_2422 = v_field_2421;
      switch (heff_tag_of(v_p_2422)) {
      case TAG_PVar: {
        V v_x_2423 = heff_field(v_p_2422, 0);
        V v_ru_24p_2422_24PVar = heff_take_reuse_n(v_p_2422, 1ULL, 1);
        return heff_tag_at_n(v_ru_24p_2422_24PVar, TAG_Just, 1, (V[]){v_x_2423});
      }
      case TAG_PTag: {
        heff_take_n(v_p_2422, 0ULL, 3);
        return NTAG(TAG_Nothing);
      }
      case TAG_PLit: {
        heff_take_n(v_p_2422, 0ULL, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_PRec: {
        heff_take_n(v_p_2422, 0ULL, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_PAs: {
        V v_x_2430 = heff_field(v_p_2422, 0);
        heff_take_n(v_p_2422, 1ULL, 2);
        return heff_tag_n(TAG_Just, 1, (V[]){v_x_2430});
      }
      case TAG_PBin: {
        heff_take_n(v_p_2422, 0ULL, 2);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_p_2422);
      }
    } else {
      heff_drop(v_field_2421);
      return NTAG(TAG_Nothing);
    }
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolNames_24dps_str0, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolNames_24dps_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolNames_24dps_str2, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolNames_24dps_str3, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolNames_24dps_str4, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolNames_24dps_str5, 1, "x");
V g_heff_2eelab_2eclauses_2ecolNames_24dps_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ecolNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecolNames_24dps_entry, 7, 0};

V g_heff_2eelab_2eclauses_2ecolNames_24dps(V v_used_240, V v_params_241, V v_rows_242, V v_i_243, V v_n_244, V v_taken_245, V v_d_246) {
top: ;
  if (heff_intLe_c_lent(v_n_244, v_i_243, 0)) {
    heff_drop(v_used_240);
    heff_drop(v_rows_242);
    heff_drop(v_i_243);
    heff_drop(v_n_244);
    heff_drop(v_taken_245);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_params_241, heff_dup(v_i_243)));
    V v_x_2449;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_p_2410 = v_field_249;
        v_x_2449 = v_p_2410;
      } else {
        heff_drop(v_field_249);
        V v_used_2411 = heff_dup(v_used_240);
        V v_taken_2412 = heff_dup(v_taken_245);
        V v_rows_2413 = heff_dup(v_rows_242);
        V v_i_2414 = heff_dup(v_i_243);
        V v_used_2415 = v_used_2411;
        V v_taken_2416 = v_taken_2412;
        V v_rows_2417 = heff_dup(v_rows_2413);
        V v_i_2418 = heff_dup(v_i_2414);
        V v_t_2435 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ecolNames_24dps_lam0, 1, 1, (V[]){v_i_2414}), v_rows_2413));
        V v_t_2436 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2435));
        V v_xs_2437 = (g_heff_2eelab_2eclauses_2enubStr(v_t_2436));
        switch (heff_tag_of(v_xs_2437)) {
        case TAG_Nil: {
          heff_drop(v_rows_2417);
          V v_t_2438 = heff_intShow(heff_intAdd(v_i_2418, MK_INT(1LL)));
          v_x_2449 = ({ V a_0 = v_used_2415; V a_1 = v_taken_2416; V a_2 = heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolNames_24dps_str0), v_t_2438); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2415); heff_drop(v_taken_2416); r_; });
          break;
        }
        case TAG_Cons: {
          V v_x_2439 = heff_field(v_xs_2437, 0);
          V v_xs2_2440 = heff_field(v_xs_2437, 1);
          heff_take_n(v_xs_2437, 3ULL, 2);
          switch (heff_tag_of(v_xs2_2440)) {
          case TAG_Nil: {
            if (!heff_strEq_c_lent(v_x_2439, ((V)&g_heff_2eelab_2eclauses_2ecolNames_24dps_str1), 2)) {
              V v_x1_2441 = (g_list_2eany_24s1006624359x760861690(v_x_2439, v_taken_2416));
              if (!(heff_dup(v_x1_2441) == NTAG(TAG_True))) {
                heff_drop(v_x1_2441);
                V v_t_2442 = ({ V a_0 = v_x_2439; V a_1 = heff_dup(v_i_2418); V a_2 = v_rows_2417; V r_ = (g_heff_2eelab_2eclauses_2enameFits(a_0, a_1, a_2)); heff_drop(v_rows_2417); r_; });
                if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
                  heff_drop(v_used_2415);
                  heff_drop(v_taken_2416);
                  heff_drop(v_i_2418);
                  heff_drop(v_t_2442);
                  v_x_2449 = v_x_2439;
                } else {
                  heff_drop(v_x_2439);
                  heff_drop(v_t_2442);
                  V v_t_2443 = heff_intShow(heff_intAdd(v_i_2418, MK_INT(1LL)));
                  v_x_2449 = ({ V a_0 = v_used_2415; V a_1 = v_taken_2416; V a_2 = heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolNames_24dps_str2), v_t_2443); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2415); heff_drop(v_taken_2416); r_; });
                }
              } else {
                heff_drop(v_rows_2417);
                heff_drop(v_x_2439);
                heff_drop(v_x1_2441);
                V v_t_2444 = heff_intShow(heff_intAdd(v_i_2418, MK_INT(1LL)));
                v_x_2449 = ({ V a_0 = v_used_2415; V a_1 = v_taken_2416; V a_2 = heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolNames_24dps_str3), v_t_2444); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2415); heff_drop(v_taken_2416); r_; });
              }
            } else {
              heff_drop(v_rows_2417);
              heff_drop(v_x_2439);
              V v_t_2445 = heff_intShow(heff_intAdd(v_i_2418, MK_INT(1LL)));
              v_x_2449 = ({ V a_0 = v_used_2415; V a_1 = v_taken_2416; V a_2 = heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolNames_24dps_str4), v_t_2445); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2415); heff_drop(v_taken_2416); r_; });
            }
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_xs2_2440, 0ULL, 2);
            heff_drop(v_rows_2417);
            heff_drop(v_x_2439);
            V v_t_2448 = heff_intShow(heff_intAdd(v_i_2418, MK_INT(1LL)));
            v_x_2449 = ({ V a_0 = v_used_2415; V a_1 = v_taken_2416; V a_2 = heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolNames_24dps_str5), v_t_2448); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2415); heff_drop(v_taken_2416); r_; });
            break;
          }
          default: heff_nomatch(v_xs2_2440);
          }
          break;
        }
        default: heff_nomatch(v_xs_2437);
        }
      }
    }
    V v_cell_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2449), heff_hole()});
    V v_u_2451 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2450));
    heff_drop(v_u_2451);
    V t_0 = v_used_240;
    V t_1 = v_params_241;
    V t_2 = v_rows_242;
    V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
    V t_4 = v_n_244;
    V t_5 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2449, v_taken_245});
    V t_6 = v_cell_2450;
    v_used_240 = t_0;
    v_params_241 = t_1;
    v_rows_242 = t_2;
    v_i_243 = t_3;
    v_n_244 = t_4;
    v_taken_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
}
V g_heff_2eelab_2eclauses_2ecolNames_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2ecolNames_24dps(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eclauses_2ecolNames_24dps_lam0(V self, V *args) {
  V v_r_2419 = args[0];
  V v_i_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2420 = ({ V b_0 = heff_get_n(v_r_2419, 0, 2); V a_1 = v_i_2414; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2422 = v_t_2420.f[1];
    int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
    if ((v_tag_2421 == ((int64_t)0ULL))) {
      V v_p_2423 = v_field_2422;
      switch (heff_tag_of(v_p_2423)) {
      case TAG_PVar: {
        V v_x_2424 = heff_field(v_p_2423, 0);
        V v_ru_24p_2423_24PVar = heff_take_reuse_n(v_p_2423, 1ULL, 1);
        return heff_tag_at_n(v_ru_24p_2423_24PVar, TAG_Just, 1, (V[]){v_x_2424});
      }
      case TAG_PTag: {
        heff_take_n(v_p_2423, 0ULL, 3);
        return NTAG(TAG_Nothing);
      }
      case TAG_PLit: {
        heff_take_n(v_p_2423, 0ULL, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_PRec: {
        heff_take_n(v_p_2423, 0ULL, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_PAs: {
        V v_x_2431 = heff_field(v_p_2423, 0);
        heff_take_n(v_p_2423, 1ULL, 2);
        return heff_tag_n(TAG_Just, 1, (V[]){v_x_2431});
      }
      case TAG_PBin: {
        heff_take_n(v_p_2423, 0ULL, 2);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_p_2423);
      }
    } else {
      heff_drop(v_field_2422);
      return NTAG(TAG_Nothing);
    }
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_str0, 44, " is used with different numbers of arguments");
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry, 7, 0};

V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_c_244, V v_arm_245, V v_fs_246) {
top: ;
  V v_bad_247 = heff_take_field(v_arm_245, 1);
  V v_row_248 = heff_take_field(v_arm_245, 0);
  V v_rows_249 = heff_get_n(v_arm_245, 2, 3);
  if ((heff_dup(v_bad_247) == NTAG(TAG_True))) {
    heff_drop(v_used_240);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_c_244);
    heff_drop(v_fs_246);
    heff_drop(v_bad_247);
    heff_drop(v_rows_249);
    V v_t_2410 = heff_strAppend(heff_take_field(v_row_248, 0), ((V)&g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_str0));
    V v_t_2411 = heff_rec_n(2, shape_span__msg, (V[]){heff_get_n(v_row_248, 3, 4), v_t_2410});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2411});
  } else {
    heff_drop(v_bad_247);
    V v_bound_2412 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_fs_246), v_bound_241));
    V v_t_2413 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_244), heff_dup(v_vars_243)));
    V v_t_2414 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_244, MK_INT(1LL)), v_vars_243));
    V v_t_2415 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_fs_246), v_t_2414));
    V v_vars_2416 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2413, v_t_2415));
    V v_rows_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rows_249));
    V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam0, 1, 1, (V[]){heff_dup(v_vars_2416)}), v_rows_2417));
    HeffT2 v_t_2422 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(v_used_240, v_bound_2412, heff_dup(v_sp_242), v_vars_2416, v_t_2421));
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        heff_drop(v_sp_242);
        heff_drop(v_fs_246);
        heff_drop_rec(v_row_248, 4);
        V v_e_2425 = v_field_2424;
        return heff_tag_n(TAG_Left, 1, (V[]){v_e_2425});
      } else {
        V v_x_2426 = v_field_2424;
        V v_t_2427 = heff_take_field(v_row_248, 0);
        V v_tsp_2428 = heff_get_n(v_row_248, 3, 4);
        V v_ps_2429 = (g_list_2emap_24s1230649048x711093514(v_sp_242, v_fs_246));
        V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_t_2427)}), heff_dup(v_tsp_2428)});
        V v_x1_2431 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2430, v_ps_2429));
        V v_t_2434;
        switch (heff_tag_of(v_x1_2431)) {
        case TAG_At: {
          V v_s_2433 = heff_field(v_x1_2431, 1);
          heff_take_n(v_x1_2431, 2ULL, 2);
          v_t_2434 = v_s_2433;
          break;
        }
        default: heff_nomatch(v_x1_2431);
        }
        V v_t_2435 = ({ V rv_0 = heff_dup(heff_rfield(v_tsp_2428, 0)); V rr_ = heff_rec_reuse_nf(v_t_2434, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_2427, v_tsp_2428, v_ps_2429}), heff_dup(v_t_2435)});
        V v_t_2439;
        switch (heff_tag_of(v_x_2426)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_x_2426, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_x_2426);
        }
        V v_t_2440 = ({ V rv_1 = heff_get_n(v_t_2439, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2435, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2436, v_x_2426}), v_t_2440});
        return heff_tag_n(TAG_Right, 1, (V[]){v_t_2441});
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam0(V self, V *args) {
  V v_row_2418 = args[0];
  V v_vars_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_pats_2419 = heff_take_field(v_row_2418, 0);
  V v_rhs_2420 = heff_get_n(v_row_2418, 1, 2);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_2416, v_pats_2419, v_rhs_2420));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str1, 7, "Segment");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str3, 6, "AsBits");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str4, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str5, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str6, 4, "Bits");
V g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_segs_246, V v_bsp_247, V v_bits_248, V v_made_249) {
top: ;
  V v_t_2410 = (g_list_2emap_24s502656580x1955732096(heff_dup(v_segs_246)));
  V v_t_2411 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2410));
  V v_t_2412 = (g_list_2emap_24s502656580x1955732096(heff_dup(v_segs_246)));
  V v_t_2413 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2412));
  V v_t_2423 = (g_heff_2eelab_2eclauses_2emapWithIndexC(MK_INT(0LL), heff_clo_n(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_lam0, 2, 4, (V[]){heff_dup(v_vars_243), heff_dup(v_c_245), heff_dup(v_used_240), heff_dup(v_bound_241)}), v_t_2413));
  V v_t_2433;
  if ((heff_dup(v_made_249) == NTAG(TAG_True))) {
    HeffT2 v_t_2424 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_vars_243, heff_dup(v_c_245)));
    V v_t_2428;
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      if ((v_tag_2425 == ((int64_t)0ULL))) {
        V v_v_2427 = v_field_2426;
        v_t_2428 = v_v_2427;
      } else {
        heff_drop(v_field_2426);
        v_t_2428 = ((V)&g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str2);
      }
    }
    v_t_2433 = (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_t_2428, ((V)&g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str3))));
  } else {
    HeffT2 v_t_2429 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_vars_243, heff_dup(v_c_245)));
    {
      V v_field_2431 = v_t_2429.f[1];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        V v_v_2432 = v_field_2431;
        v_t_2433 = v_v_2432;
      } else {
        heff_drop(v_field_2431);
        v_t_2433 = ((V)&g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str4);
      }
    }
  }
  HeffT2 v_t_2434 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_vars_243, heff_dup(v_c_245)));
  V v_t_2438;
  {
    V v_field_2436 = v_t_2434.f[1];
    int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
    if ((v_tag_2435 == ((int64_t)0ULL))) {
      V v_v_2437 = v_field_2436;
      v_t_2438 = v_v_2437;
    } else {
      heff_drop(v_field_2436);
      v_t_2438 = ((V)&g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str5);
    }
  }
  V v_t_2439 = (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_t_2438, ((V)&g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str6))));
  V v_t_2440 = (g_list_2emap_24s939813003x1383013550(heff_dup(v_segs_246)));
  V v_t_2441 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2440));
  return (g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr(heff_dup(v_used_240), heff_dup(v_bound_241), v_sp_242, v_vars_243, v_rows_244, v_c_245, v_segs_246, heff_dup(v_bsp_247), v_t_2411, v_t_2423, heff_rec_n(7, shape_v__bits__len__sizes__used__bound__span, (V[]){v_t_2433, v_bits_248, v_t_2439, v_t_2441, v_used_240, v_bound_241, v_bsp_247}), v_made_249));
}
V g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_lam0(V self, V *args) {
  V v_i_2414 = args[0];
  V v_x_2415 = args[1];
  V v_vars_243 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_used_240 = heff_env(self)[2];
  V v_bound_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2415);
  HeffT2 v_t_2416 = ({ V a_0 = v_vars_243; V a_1 = v_c_245; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(a_0, a_1)); heff_drop(v_vars_243); r_; });
  V v_t_2420;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_v_2419 = v_field_2418;
      v_t_2420 = v_v_2419;
    } else {
      heff_drop(v_field_2418);
      v_t_2420 = ((V)&g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str0);
    }
  }
  V v_t_2421 = heff_intShow(heff_intAdd(v_i_2414, MK_INT(1LL)));
  V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str1)), v_t_2421);
  return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_t_2422; V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_240); heff_drop(v_bound_241); r_; });
}

HeffT2 g_heff_2eelab_2eclauses_2ebinaryOf_24s1676894398x132520022_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_segs_246, V v_bsp_247) {
top: ;
  V v_t_248 = (g_list_2eany_24s1116296567x1614305171(v_segs_246));
  V v_t_2416;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    v_t_2416 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_248);
    V v_t_249 = (g_list_2emap_24s1134745827x519521524(heff_dup(v_segs_246)));
    HeffT2 v_t_2410 = ({ V a_0 = v_t_249; V a_1 = MK_INT(0LL); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(a_0, a_1)); heff_drop(v_t_249); r_; });
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_n_2413 = v_field_2412;
        if (!heff_intEq_c_lent(v_n_2413, MK_INT(0LL), 2)) {
          heff_drop(v_n_2413);
          v_t_2416 = NTAG(TAG_True);
        } else {
          heff_drop(v_n_2413);
          V v_x1_2414 = (g_list_2eany_24s1116296567x1614305171(v_segs_246));
          if (!(heff_dup(v_x1_2414) == NTAG(TAG_True))) {
            heff_drop(v_x1_2414);
            V v_x1_2415 = (g_list_2eall_24s457861111x1513113784(MK_INT(0LL), v_segs_246));
            v_t_2416 = heff_bool(!(heff_dup(v_x1_2415) == NTAG(TAG_True)));
            heff_drop(v_x1_2415);
          } else {
            heff_drop(v_x1_2414);
            v_t_2416 = NTAG(TAG_True);
          }
        }
      } else {
        heff_drop(v_field_2412);
        v_t_2416 = NTAG(TAG_True);
      }
    }
  }
  V v_t_2417 = (g_list_2eany_24s1116296567x1614305171(v_segs_246));
  V v_t_2425;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_t_2417);
    v_t_2425 = NTAG(TAG_False);
  } else {
    heff_drop(v_t_2417);
    V v_t_2418 = (g_list_2emap_24s1134745827x519521524(heff_dup(v_segs_246)));
    HeffT2 v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = MK_INT(0LL); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(a_0, a_1)); heff_drop(v_t_2418); r_; });
    {
      V v_field_2421 = v_t_2419.f[1];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        V v_n_2422 = v_field_2421;
        if (heff_intEq_c(v_n_2422, MK_INT(0LL))) {
          V v_x1_2423 = (g_list_2eany_24s1116296567x1614305171(v_segs_246));
          if (!(heff_dup(v_x1_2423) == NTAG(TAG_True))) {
            heff_drop(v_x1_2423);
            V v_x1_2424 = (g_list_2eall_24s457861111x1513113784(MK_INT(0LL), v_segs_246));
            v_t_2425 = heff_bool(!(heff_dup(v_x1_2424) == NTAG(TAG_True)));
            heff_drop(v_x1_2424);
          } else {
            heff_drop(v_x1_2423);
            v_t_2425 = NTAG(TAG_True);
          }
        } else {
          v_t_2425 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_field_2421);
        v_t_2425 = NTAG(TAG_False);
      }
    }
  }
  return (g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_segs_246, v_bsp_247, v_t_2416, v_t_2425));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ereached_str0, 1, "_");
V g_heff_2eelab_2eclauses_2ereached_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2ereached_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ereached_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ereached_entry, 2, 0};

V g_heff_2eelab_2eclauses_2ereached(V v_rows_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_rows_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop_tag(v_rows_240, 2);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_244 = heff_field(v_x2_241, 0);
      V v_q_245 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_PVar: {
        heff_take_n(v_x21_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_t_247 = (g_list_2emap_24s1368853467x919806006(v_rows_240));
        V v_t_248 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_247));
        V t_0 = v_t_248;
        V t_1 = v_q_245;
        v_rows_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_PTag: {
        V v_t_249 = heff_field(v_x21_244, 0);
        V v_ps_2410 = heff_field(v_x21_244, 1);
        heff_take_n(v_x21_244, 3ULL, 3);
        V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_2410));
        V v_t_2433 = (g_list_2emap_24tok2(v_ru_24x2_241_24Cons, heff_clo_n(g_heff_2eelab_2eclauses_2ereached_lam0, 1, 2, (V[]){v_t_249, v_t_2412}), v_rows_240));
        V v_t_2434 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2433));
        V v_t_2435 = (g_heff_2eelab_2eclauses_2eappendC(v_ps_2410, v_q_245));
        V t_0 = v_t_2434;
        V t_1 = v_t_2435;
        v_rows_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_PLit: {
        V v_l_2436 = heff_field(v_x21_244, 0);
        heff_take_n(v_x21_244, 1ULL, 1);
        V v_t_2452 = (g_list_2emap_24tok2(v_ru_24x2_241_24Cons, heff_clo_n(g_heff_2eelab_2eclauses_2ereached_lam1, 1, 1, (V[]){v_l_2436}), v_rows_240));
        V v_t_2453 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2452));
        V t_0 = v_t_2453;
        V t_1 = v_q_245;
        v_rows_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_PRec: {
        heff_take_n(v_x21_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_t_2456 = (g_list_2emap_24s1368853467x919806006(v_rows_240));
        V v_t_2457 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2456));
        V t_0 = v_t_2457;
        V t_1 = v_q_245;
        v_rows_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_PAs: {
        heff_take_n(v_x21_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_t_2460 = (g_list_2emap_24s1368853467x919806006(v_rows_240));
        V v_t_2461 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2460));
        V t_0 = v_t_2461;
        V t_1 = v_q_245;
        v_rows_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_PBin: {
        heff_take_n(v_x21_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_t_2464 = (g_list_2emap_24s1368853467x919806006(v_rows_240));
        V v_t_2465 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2464));
        V t_0 = v_t_2465;
        V t_1 = v_q_245;
        v_rows_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x21_244);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_rows_240);
  }
}
V g_heff_2eelab_2eclauses_2ereached_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ereached(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2ereached_lam0(V self, V *args) {
  V v_x2_2413 = args[0];
  V v_t_249 = heff_env(self)[0];
  V v_t_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nil: {
    heff_drop(v_t_249);
    heff_drop(v_t_2412);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_2414 = heff_field(v_x2_2413, 0);
    V v_ps_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24Cons = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = v_t_249;
    V v_n_2417 = v_t_2412;
    V v_x3_2418 = v_p_2414;
    V v_rest_2419 = v_ps_2415;
    switch (heff_tag_of(v_x3_2418)) {
    case TAG_PVar: {
      V v_ru_24x3_2418_24PVar = heff_take_reuse_n(v_x3_2418, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_2413_24Cons, 2);
      heff_drop(v_t_2416);
      V v_t_2421 = (g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514(v_rest_2419, ((V)&g_heff_2eelab_2eclauses_2ereached_str0), MK_INT(0LL), v_n_2417));
      return heff_tag_at_n(v_ru_24x3_2418_24PVar, TAG_Just, 1, (V[]){v_t_2421});
    }
    case TAG_PTag: {
      V v_t2_2422 = heff_field(v_x3_2418, 0);
      V v_ps_2423 = heff_field(v_x3_2418, 1);
      heff_take_n(v_x3_2418, 3ULL, 3);
      if ((heff_strEq_c_lent(v_t_2416, v_t2_2422, 0) && ({ V v_t_2466 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_2423)); int c_ = heff_intEq_c_lent(v_t_2466, v_n_2417, 0); heff_drop(v_t_2466); c_; }))) {
        heff_drop(v_t_2416);
        heff_drop(v_n_2417);
        heff_drop(v_t2_2422);
        V v_t_2425 = (g_heff_2eelab_2eclauses_2eappendC_24tok2(v_ru_24x2_2413_24Cons, v_ps_2423, v_rest_2419));
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2425});
      } else {
        heff_drop_cell(v_ru_24x2_2413_24Cons, 2);
        heff_drop(v_t_2416);
        heff_drop(v_n_2417);
        heff_drop(v_rest_2419);
        heff_drop(v_t2_2422);
        heff_drop(v_ps_2423);
        return NTAG(TAG_Nothing);
      }
    }
    case TAG_PLit: {
      heff_take_n(v_x3_2418, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_2413_24Cons, 2);
      heff_drop(v_t_2416);
      heff_drop(v_n_2417);
      heff_drop(v_rest_2419);
      return NTAG(TAG_Nothing);
    }
    case TAG_PRec: {
      heff_take_n(v_x3_2418, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_2413_24Cons, 2);
      heff_drop(v_t_2416);
      heff_drop(v_n_2417);
      heff_drop(v_rest_2419);
      return NTAG(TAG_Nothing);
    }
    case TAG_PAs: {
      heff_take_n(v_x3_2418, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_2413_24Cons, 2);
      heff_drop(v_t_2416);
      heff_drop(v_n_2417);
      heff_drop(v_rest_2419);
      return NTAG(TAG_Nothing);
    }
    case TAG_PBin: {
      heff_take_n(v_x3_2418, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_2413_24Cons, 2);
      heff_drop(v_t_2416);
      heff_drop(v_n_2417);
      heff_drop(v_rest_2419);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_2418);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2eelab_2eclauses_2ereached_lam1(V self, V *args) {
  V v_x2_2437 = args[0];
  V v_l_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_Nil: {
    heff_drop(v_l_2436);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_2438 = heff_field(v_x2_2437, 0);
    V v_ps_2439 = heff_field(v_x2_2437, 1);
    heff_take_n(v_x2_2437, 3ULL, 2);
    switch (heff_tag_of(v_p_2438)) {
    case TAG_PVar: {
      V v_ru_24p_2438_24PVar = heff_take_reuse_n(v_p_2438, 0ULL, 1);
      heff_drop(v_l_2436);
      return heff_tag_at_n(v_ru_24p_2438_24PVar, TAG_Just, 1, (V[]){v_ps_2439});
    }
    case TAG_PTag: {
      heff_take_n(v_p_2438, 0ULL, 3);
      heff_drop(v_l_2436);
      heff_drop(v_ps_2439);
      return NTAG(TAG_Nothing);
    }
    case TAG_PLit: {
      V v_l2_2444 = heff_field(v_p_2438, 0);
      V v_ru_24p_2438_24PLit = heff_take_reuse_n(v_p_2438, 1ULL, 1);
      V v_t_2445 = ({ V a_0 = v_l_2436; V a_1 = v_l2_2444; V r_ = (g_heff_2eelab_2eclauses_2esameLit(a_0, a_1)); heff_drop(v_l_2436); heff_drop(v_l2_2444); r_; });
      if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
        heff_drop(v_t_2445);
        return heff_tag_at_n(v_ru_24p_2438_24PLit, TAG_Just, 1, (V[]){v_ps_2439});
      } else {
        heff_drop(v_ps_2439);
        heff_drop_cell(v_ru_24p_2438_24PLit, 1);
        heff_drop(v_t_2445);
        return NTAG(TAG_Nothing);
      }
    }
    case TAG_PRec: {
      heff_take_n(v_p_2438, 0ULL, 2);
      heff_drop(v_l_2436);
      heff_drop(v_ps_2439);
      return NTAG(TAG_Nothing);
    }
    case TAG_PAs: {
      heff_take_n(v_p_2438, 0ULL, 2);
      heff_drop(v_l_2436);
      heff_drop(v_ps_2439);
      return NTAG(TAG_Nothing);
    }
    case TAG_PBin: {
      heff_take_n(v_p_2438, 0ULL, 2);
      heff_drop(v_l_2436);
      heff_drop(v_ps_2439);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_p_2438);
    }
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
Clo g_heff_2eelab_2eclauses_2eunreachedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eunreachedGo_24dps_entry, 4, 0};

V g_heff_2eelab_2eclauses_2eunreachedGo_24dps(V v_above_240, V v_i_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_above_240);
    heff_drop(v_i_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = (g_list_2emap_24s1722943925x2063725971(heff_dup(heff_rfield(v_r_244, 0))));
    V v_t_247 = (g_heff_2eelab_2eclauses_2ereached(heff_dup(v_above_240), v_t_246));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_t_248 = (g_list_2emap_24s1722943925x2063725971(heff_get_n(v_r_244, 0, 2)));
      V t_0 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, v_above_240});
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_rest_245;
      V t_3 = v_d_243;
      v_above_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_rec(v_r_244, 2);
      heff_drop(v_t_247);
      V v_cell_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_i_241), heff_hole()});
      V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_above_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_rest_245;
      V t_3 = v_cell_249;
      v_above_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2eunreachedGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eunreachedGo_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_entry, 4, 0};

V g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514(V v_ys_240, V v_lit_241, V v_i_242, V v_n_243) {
top: ;
  if (heff_intLe_c_lent(v_n_243, v_i_242, 0)) {
    heff_drop(v_lit_241);
    heff_drop(v_i_242);
    heff_drop(v_n_243);
    return v_ys_240;
  } else {
    V v_x_244 = heff_tag_n(TAG_PVar, 1, (V[]){heff_dup(v_lit_241)});
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_24dps(v_ys_240, v_lit_241, heff_box_word((heff_unbox_word(v_i_242) + ((int64_t)1ULL))), v_n_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
}
V g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eandC_24tok3_str0, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2eandC_24tok3_str1, 5, "False");
HEFF_LIT(g_heff_2eelab_2eclauses_2eandC_24tok3_str2, 5, "False");
Clo g_heff_2eelab_2eclauses_2eandC_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eandC_24tok3_entry, 4, 0};

V g_heff_2eelab_2eclauses_2eandC_24tok3(V v_tok_240, V v_c_241, V v_rest_242, V v_sp_243) {
top: ;
  V v_t_244 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_243, 0)), heff_dup(heff_rfield(v_sp_243, 1))});
  V v_t_245 = heff_tag_at_n(v_tok_240, TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eandC_24tok3_str0), heff_dup(v_sp_243), NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_245, heff_dup(v_t_244)}), heff_dup(v_rest_242)});
  V v_t_249;
  switch (heff_tag_of(v_rest_242)) {
  case TAG_At: {
    V v_s_248 = heff_field(v_rest_242, 1);
    heff_take_n(v_rest_242, 2ULL, 2);
    v_t_249 = v_s_248;
    break;
  }
  default: heff_nomatch(v_rest_242);
  }
  V v_t_2410 = ({ V rv_1 = heff_get_n(v_t_249, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_244, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_243, 0)), heff_dup(heff_rfield(v_sp_243, 1))});
  V v_t_2412 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eandC_24tok3_str1), heff_dup(v_sp_243), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eandC_24tok3_str2), heff_dup(v_sp_243), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_t_2411)}), heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_243)})});
  V v_t_2415 = ({ V rv_1 = heff_dup(heff_rfield(v_sp_243, 1)); V rr_ = heff_rec_reuse_nf(v_t_2411, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_t_2415}), NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_t_2410}), v_t_2416});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_c_241, v_t_2417}), v_sp_243});
}
V g_heff_2eelab_2eclauses_2eandC_24tok3_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eandC_24tok3(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eclauses_2eappendC_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_24tok2_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eappendC_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_heff_2eelab_2eclauses_2eappendC_24dps(v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC_24tok2(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2esoleBin_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esoleBin_24tok2_entry, 6, 0};

V g_heff_2eelab_2eclauses_2esoleBin_24tok2(V v_tok_240, V v_s_241, V v_v_242, V v_ty_243, V v_size_244, V v_sp_245) {
top: ;
  switch (heff_tag_of(v_v_242)) {
  case TAG_At: {
    V v_v1_246 = heff_field(v_v_242, 0);
    V v_ru_24v_242_24At = heff_take_reuse_n(v_v_242, 1ULL, 2);
    switch (heff_tag_of(v_v1_246)) {
    case TAG_PatVar: {
      V v_x_248 = heff_field(v_v1_246, 0);
      V v_ru_24v1_246_24PatVar = heff_take_reuse_n(v_v1_246, 1ULL, 1);
      switch (heff_tag_of(v_ty_243)) {
      case TAG_SegmentInteger: {
        heff_drop(v_x_248);
        heff_drop_cell(v_ru_24v1_246_24PatVar, 1);
        V v_t_249 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_249, v_sp_245});
      }
      case TAG_SegmentBinary: {
        switch (heff_tag_of(v_size_244)) {
        case TAG_SizeDefault: {
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_s_241);
          heff_drop(v_sp_245);
          heff_drop_cell(v_ru_24v_242_24At, 2);
          return heff_tag_at_n(v_ru_24v1_246_24PatVar, TAG_PVar, 1, (V[]){v_x_248});
        }
        case TAG_SizeNumber: {
          heff_drop(v_x_248);
          heff_drop_cell(v_ru_24v1_246_24PatVar, 1);
          V v_t_2411 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2411, v_sp_245});
        }
        case TAG_SizeName: {
          heff_drop(v_x_248);
          heff_drop_cell(v_ru_24v1_246_24PatVar, 1);
          V v_t_2415 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2415, v_sp_245});
        }
        default: return heff_nomatch(v_size_244);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_x_248);
        heff_drop_cell(v_ru_24v1_246_24PatVar, 1);
        V v_t_2416 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2416, v_sp_245});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_x_248);
        heff_drop_cell(v_ru_24v1_246_24PatVar, 1);
        V v_t_2417 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2417, v_sp_245});
      }
      case TAG_SegmentUtf: {
        heff_drop(v_x_248);
        heff_drop_cell(v_ru_24v1_246_24PatVar, 1);
        V v_t_2419 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2419, v_sp_245});
      }
      default: return heff_nomatch(v_ty_243);
      }
    }
    case TAG_PatTag: {
      heff_take_n(v_v1_246, 0ULL, 3);
      V v_t_2423 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2423, v_sp_245});
    }
    case TAG_PatOp: {
      heff_take_n(v_v1_246, 0ULL, 3);
      V v_t_2427 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2427, v_sp_245});
    }
    case TAG_PatInt: {
      heff_take_n(v_v1_246, 0ULL, 1);
      V v_t_2429 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2429, v_sp_245});
    }
    case TAG_PatFloat: {
      heff_take_n(v_v1_246, 0ULL, 1);
      V v_t_2431 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2431, v_sp_245});
    }
    case TAG_PatString: {
      heff_take_n(v_v1_246, 0ULL, 1);
      V v_t_2433 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2433, v_sp_245});
    }
    case TAG_PatBinary: {
      heff_take_n(v_v1_246, 0ULL, 1);
      V v_t_2435 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2435, v_sp_245});
    }
    case TAG_PatRune: {
      heff_take_n(v_v1_246, 0ULL, 1);
      V v_t_2437 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2437, v_sp_245});
    }
    case TAG_PatRecord: {
      heff_take_n(v_v1_246, 0ULL, 1);
      V v_t_2439 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2439, v_sp_245});
    }
    case TAG_PatWord: {
      heff_take_n(v_v1_246, 0ULL, 1);
      V v_t_2441 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2441, v_sp_245});
    }
    case TAG_PatAs: {
      heff_take_n(v_v1_246, 0ULL, 3);
      V v_t_2445 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_s_241, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24v_242_24At, TAG_PBin, 2, (V[]){v_t_2445, v_sp_245});
    }
    default: return heff_nomatch(v_v1_246);
    }
  }
  default: return heff_nomatch(v_v_242);
  }
}
V g_heff_2eelab_2eclauses_2esoleBin_24tok2_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2esoleBin_24tok2(a[0], a[1], a[2], a3, a4, a[5]); heff_drop(a3); heff_drop(a4); return r;
}