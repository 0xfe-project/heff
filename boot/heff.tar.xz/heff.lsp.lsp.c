// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Await 41810
#define TAG_Closed 4831
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Message 12631
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_ProjectFiles 9175
#define TAG_Quit 47258
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Send 26077
#define TAG_Timeout 14063
#define TAG_UriPath 39251
#define LBL_checked 974171621
#define LBL_children 257181584
#define LBL_code 9554612
#define LBL_defines 1776893014
#define LBL_deps 9575179
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_done 9584713
#define LBL_due 309358
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_imports 10411951
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_line 9817275
#define LBL_local 304503685
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_rune 10007553
#define LBL_selection 2055983820
#define LBL_severity 75955546
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
#define LBL_width 314485216
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_path__target__name__occurrences[] = {LBL_path, LBL_target, LBL_name, LBL_occurrences};
static uint32_t shape_root__program[] = {LBL_root, LBL_program};
static uint32_t shape_rune__width[] = {LBL_rune, LBL_width};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_st__text__program[] = {LBL_st, LBL_text, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_text__program[] = {LBL_text, LBL_program};
static uint32_t shape_uri__text[] = {LBL_uri, LBL_text};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2edriver_2etraceless(V);
V g_heff_2ebuild_2edriver_2etraceless_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etraceless_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
V g_heff_2ebuild_2equery_2ecompletionsAt(V, V);
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo;
V g_heff_2ebuild_2equery_2edefinitionAt(V, V);
V g_heff_2ebuild_2equery_2edefinitionAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionAt_clo;
V g_heff_2ebuild_2equery_2edocMarkdown(V);
V g_heff_2ebuild_2equery_2edocMarkdown_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMarkdown_clo;
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
V g_heff_2ebuild_2equery_2erenameRefused(V, V, V);
V g_heff_2ebuild_2equery_2erenameRefused_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2erenameRefused_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2equery_2etargetAt(V, V);
V g_heff_2ebuild_2equery_2etargetAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etargetAt_clo;
V g_heff_2ebuild_2equery_2etypeAt(V, V);
V g_heff_2ebuild_2equery_2etypeAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etypeAt_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_clo;
V g_heff_2elsp_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2elsp_2ebrokenImport(V, V);
V g_heff_2elsp_2elsp_2ebrokenImport_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ebrokenImport_clo;
V g_heff_2elsp_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2elsp_2ecatMaybesL(V);
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo;
V g_heff_2elsp_2elsp_2echanged(V, V, V);
V g_heff_2elsp_2elsp_2echanged_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echanged_clo;
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266(V, V, V);
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_clo;
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(V, V);
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_clo;
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421(V, V);
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_clo;
V g_heff_2elsp_2elsp_2echildJson(V, V);
V g_heff_2elsp_2elsp_2echildJson_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echildJson_clo;
V g_heff_2elsp_2elsp_2eclosed(V, V);
V g_heff_2elsp_2elsp_2eclosed_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclosed_clo;
V g_heff_2elsp_2elsp_2edependentsOf(V, V);
V g_heff_2elsp_2elsp_2edependentsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edependentsOf_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(V);
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_clo;
V g_heff_2elsp_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028(V, V, V);
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_clo;
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493(V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_clo;
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_clo;
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459(V, V);
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_clo;
V g_heff_2elsp_2elsp_2ehoverOf(V, V);
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2elastChange(V);
V g_heff_2elsp_2elsp_2elastChange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elastChange_clo;
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073(V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_clo;
V g_heff_2elsp_2elsp_2eloadError(V, V);
V g_heff_2elsp_2elsp_2eloadError_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadError_clo;
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873(V, V);
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_clo;
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104(V, V);
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
V g_heff_2elsp_2elsp_2enotification_24s270589690x602944811(V, V, V);
V g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_clo;
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559(V, V, V);
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubRoots(V);
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574(V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_clo;
V g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215(V, V);
V g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_clo;
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576(V, V);
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_clo;
V g_heff_2elsp_2elsp_2epublish_24s471405199x320951611(V, V);
V g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2eregistration_get(void);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555(V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_clo;
V g_heff_2elsp_2elsp_2erenameVerdict(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenameVerdict_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameVerdict_clo;
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918(V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_clo;
V g_heff_2elsp_2elsp_2erenamedTarget(V, V);
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamedTarget_clo;
V g_heff_2elsp_2elsp_2erenamedText(V, V);
V g_heff_2elsp_2elsp_2erenamedText_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamedText_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_clo;
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277(V, V, V, V);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_clo;
V g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005(V, V);
V g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_clo;
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099(V, V, V);
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_clo;
V g_heff_2elsp_2elsp_2eshiftOf(V, V, V);
V g_heff_2elsp_2elsp_2eshiftOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eshiftOf_clo;
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041(V, V, V);
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_clo;
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573(V, V, V);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_clo;
V g_heff_2elsp_2elsp_2etargetIn(V, V, V, V, V);
V g_heff_2elsp_2elsp_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2etargetIn_clo;
V g_heff_2elsp_2elsp_2eunits16Go(V, V, V, V);
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eunits16Go_clo;
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(V, V);
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_clo;
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799(V, V);
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2erepeated(V, V);
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_clo;
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_clo;
V g_heff_2esyntax_2eformat_2emeaningFrom(V);
V g_heff_2esyntax_2eformat_2emeaningFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2emeaningFrom_clo;
V g_heff_2esyntax_2eformat_2esameMeaning(V, V, V, V);
V g_heff_2esyntax_2eformat_2esameMeaning_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2esameMeaning_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2eutil_2ejson_2eat(V, V);
V g_heff_2eutil_2ejson_2eat_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2eat_clo;
V g_heff_2eutil_2ejson_2estringify(V);
V g_heff_2eutil_2ejson_2estringify_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2estringify_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s835571418x868029304(V);
V g_list_2efilter_24s835571418x868029304_entry(V self, V *a);
extern Clo g_list_2efilter_24s835571418x868029304_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efind_24s913819130x636901392(V, V);
V g_list_2efind_24s913819130x636901392_entry(V self, V *a);
extern Clo g_list_2efind_24s913819130x636901392_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1221316612x1915668835(V, V);
V g_list_2efoldl_24s1221316612x1915668835_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1221316612x1915668835_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s361191175x1417189158(V, V);
V g_list_2efoldl_24s361191175x1417189158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s361191175x1417189158_clo;
V g_list_2efoldl_24s844754919x2100408598(V, V, V, V);
V g_list_2efoldl_24s844754919x2100408598_entry(V self, V *a);
extern Clo g_list_2efoldl_24s844754919x2100408598_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1120421688x983574011(V);
V g_list_2emap_24s1120421688x983574011_entry(V self, V *a);
extern Clo g_list_2emap_24s1120421688x983574011_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1533895818x411093629(V);
V g_list_2emap_24s1533895818x411093629_entry(V self, V *a);
extern Clo g_list_2emap_24s1533895818x411093629_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s4199228x1154005405(V);
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_clo;
V g_list_2emap_24s434052990x93204247(V);
V g_list_2emap_24s434052990x93204247_entry(V self, V *a);
extern Clo g_list_2emap_24s434052990x93204247_clo;
V g_map_2edelete_24s805420727x38051515(V, V);
V g_map_2edelete_24s805420727x38051515_entry(V self, V *a);
extern Clo g_map_2edelete_24s805420727x38051515_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;

static V g_heff_2elsp_2elsp_2ejtrue_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejtrue_st;
static V g_heff_2elsp_2elsp_2ejtrue_init(void) {
  return heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_True)});
}
V g_heff_2elsp_2elsp_2ejtrue_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejtrue_st)) return g_heff_2elsp_2elsp_2ejtrue_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejtrue_val, &g_heff_2elsp_2elsp_2ejtrue_st, g_heff_2elsp_2elsp_2ejtrue_init);
}

static V g_heff_2elsp_2elsp_2ejfalse_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejfalse_st;
static V g_heff_2elsp_2elsp_2ejfalse_init(void) {
  return heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2elsp_2elsp_2ejfalse_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejfalse_st)) return g_heff_2elsp_2elsp_2ejfalse_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejfalse_val, &g_heff_2elsp_2elsp_2ejfalse_st, g_heff_2elsp_2elsp_2ejfalse_init);
}
Clo g_heff_2elsp_2elsp_2eunits16Go_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eunits16Go_entry, 4, 0};

V g_heff_2elsp_2elsp_2eunits16Go(V v_src_240, V v_i_241, V v_j_242, V v_n_243) {
top: ;
  V v_t_245;
  if (heff_intLe_c(heff_dup(v_j_242), heff_dup(v_i_241))) {
    v_t_245 = NTAG(TAG_True);
  } else {
    v_t_245 = heff_intLe(heff_strLength(heff_dup(v_src_240)), heff_dup(v_i_241));
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_src_240);
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return v_n_243;
  }
  case TAG_False: {
    if (heff_intLt_c(heff_strByteAt(heff_dup(v_src_240), heff_dup(v_i_241)), MK_INT(128LL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_j_242;
      V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_n_243 = t_3;
      goto top;
    } else {
      V v_r_247 = heff_rec_n(2, shape_rune__width, (V[]){heff_strRuneAt(heff_dup(v_src_240), heff_dup(v_i_241)), heff_strRuneWidth(heff_dup(v_src_240), heff_dup(v_i_241))});
      V v_t_248 = heff_intAdd(v_i_241, heff_take_field(v_r_247, 1));
      V v_t_249 = heff_runeToInt(heff_get_n(v_r_247, 0, 2));
      V v_t_2411;
      if (heff_intLe_c(MK_INT(65536LL), v_t_249)) {
        v_t_2411 = MK_INT(2LL);
      } else {
        v_t_2411 = MK_INT(1LL);
      }
      V t_0 = v_src_240;
      V t_1 = v_t_248;
      V t_2 = v_j_242;
      V t_3 = heff_intAdd(v_n_243, v_t_2411);
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eunits16Go(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2elsp_2elsp_2eoffset16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffset16_entry, 4, 0};

V g_heff_2elsp_2elsp_2eoffset16(V v_src_240, V v_i_241, V v_e_242, V v_n_243) {
top: ;
  V v_t_245;
  if (heff_intLe_c(heff_dup(v_n_243), MK_INT(0LL))) {
    v_t_245 = NTAG(TAG_True);
  } else {
    v_t_245 = heff_intLe(heff_dup(v_e_242), heff_dup(v_i_241));
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_src_240);
    heff_drop(v_n_243);
    if (heff_intLe_c(heff_dup(v_i_241), heff_dup(v_e_242))) {
      heff_drop(v_e_242);
      return v_i_241;
    } else {
      heff_drop(v_i_241);
      return v_e_242;
    }
  }
  case TAG_False: {
    if (heff_intLt_c(heff_strByteAt(heff_dup(v_src_240), heff_dup(v_i_241)), MK_INT(128LL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_e_242;
      V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_n_243 = t_3;
      goto top;
    } else {
      V v_r_248 = heff_rec_n(2, shape_rune__width, (V[]){heff_strRuneAt(heff_dup(v_src_240), heff_dup(v_i_241)), heff_strRuneWidth(heff_dup(v_src_240), heff_dup(v_i_241))});
      V v_t_249 = heff_intAdd(v_i_241, heff_take_field(v_r_248, 1));
      V v_t_2410 = heff_runeToInt(heff_get_n(v_r_248, 0, 2));
      V v_t_2412;
      if (heff_intLe_c(MK_INT(65536LL), v_t_2410)) {
        v_t_2412 = MK_INT(2LL);
      } else {
        v_t_2412 = MK_INT(1LL);
      }
      V t_0 = v_src_240;
      V t_1 = v_t_249;
      V t_2 = v_e_242;
      V t_3 = heff_intSub(v_n_243, v_t_2412);
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eoffset16(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2eoffsetGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetGo_entry, 5, 0};

V g_heff_2elsp_2elsp_2eoffsetGo(V v_src_240, V v_line_241, V v_ch_242, V v_i_243, V v_l_244) {
top: ;
  if (heff_intLe_c(heff_dup(v_line_241), heff_dup(v_l_244))) {
    heff_drop(v_line_241);
    heff_drop(v_l_244);
    V v_x2_246 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str0), heff_dup(v_src_240), heff_dup(v_i_243)));
    V v_t_248;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nothing: {
      v_t_248 = heff_strLength(heff_dup(v_src_240));
      break;
    }
    case TAG_Just: {
      V v_x_247 = heff_field(v_x2_246, 0);
      heff_take_n(v_x2_246, 1ULL, 1);
      v_t_248 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return (g_heff_2elsp_2elsp_2eoffset16(v_src_240, v_i_243, v_t_248, v_ch_242));
  } else {
    V v_t_249 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str1), heff_dup(v_src_240), v_i_243));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop(v_line_241);
      heff_drop(v_ch_242);
      heff_drop(v_l_244);
      return heff_strLength(v_src_240);
    }
    case TAG_Just: {
      V v_e_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V t_0 = v_src_240;
      V t_1 = v_line_241;
      V t_2 = v_ch_242;
      V t_3 = heff_intAdd(v_e_2410, MK_INT(1LL));
      V t_4 = heff_intAdd(v_l_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_line_241 = t_1;
      v_ch_242 = t_2;
      v_i_243 = t_3;
      v_l_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
}
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eoffsetGo(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str1, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str2, 4, "line");
Clo g_heff_2elsp_2elsp_2eposition_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eposition_entry, 2, 0};

V g_heff_2elsp_2elsp_2eposition(V v_src_240, V v_i_241) {
top: ;
  V v_a_242 = heff_strLength(heff_dup(v_src_240));
  V v_b_244;
  if (heff_intLe_c(heff_dup(v_a_242), heff_dup(v_i_241))) {
    v_b_244 = v_a_242;
  } else {
    heff_drop(v_a_242);
    v_b_244 = heff_dup(v_i_241);
  }
  V v_i_246;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_b_244))) {
    v_i_246 = v_b_244;
  } else {
    heff_drop(v_b_244);
    v_i_246 = MK_INT(0LL);
  }
  V v_a_247 = heff_strLength(heff_dup(v_src_240));
  V v_b_249;
  if (heff_intLe_c(heff_dup(v_a_247), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    v_b_249 = v_a_247;
  } else {
    heff_drop(v_a_247);
    v_b_249 = v_i_241;
  }
  V v_i_2411;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_b_249))) {
    v_i_2411 = v_b_249;
  } else {
    heff_drop(v_b_249);
    v_i_2411 = MK_INT(0LL);
  }
  V v_t_2412 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2elsp_2eposition_str0), heff_dup(v_src_240), MK_INT(0LL)));
  V v_lc_2413 = (g_heff_2elsp_2erender_2elineColAt(heff_dup(v_src_240), v_i_2411, MK_INT(0LL), MK_INT(0LL), v_t_2412));
  V v_t_2414 = heff_tag_n(TAG_JInt, 1, (V[]){heff_take_field(v_lc_2413, 0)});
  V v_t_2415 = heff_intSub(heff_dup(v_i_246), heff_get_n(v_lc_2413, 1, 3));
  V v_t_2416 = heff_tag_n(TAG_JInt, 1, (V[]){(g_heff_2elsp_2elsp_2eunits16Go(v_src_240, v_t_2415, v_i_246, MK_INT(0LL)))});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eposition_str1), v_t_2416}), NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eposition_str2), v_t_2414}), v_t_2417});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2418});
}
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eposition(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erange_str0, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2erange_str1, 3, "end");
Clo g_heff_2elsp_2elsp_2erange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erange_entry, 2, 0};

V g_heff_2elsp_2elsp_2erange(V v_src_240, V v_sp_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erange_str0), (g_heff_2elsp_2elsp_2eposition(heff_dup(v_src_240), heff_dup(heff_rfield(v_sp_241, 0))))});
  V v_a_243 = heff_take_field(v_sp_241, 0);
  V v_b_244 = heff_get_n(v_sp_241, 1, 2);
  V v_t_246;
  if (heff_intLe_c(heff_dup(v_a_243), heff_dup(v_b_244))) {
    heff_drop(v_a_243);
    v_t_246 = v_b_244;
  } else {
    heff_drop(v_b_244);
    v_t_246 = v_a_243;
  }
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erange_str1), (g_heff_2elsp_2elsp_2eposition(v_src_240, v_t_246))});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_248})});
}
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erange(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str0, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str1, 8, "position");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str2, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str3, 8, "position");
Clo g_heff_2elsp_2elsp_2eoffsetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetIn_entry, 2, 0};

V g_heff_2elsp_2elsp_2eoffsetIn(V v_src_240, V v_params_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str0), NTAG(TAG_Nil)});
  V v_it_243 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str1), v_t_242}); V a_1 = heff_dup(v_params_241); V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_2412;
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    v_x2_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Just = heff_take_reuse_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      V v_i_246 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 1);
      v_x2_2412 = heff_tag_at_n(v_ru_24it_243_24Just, TAG_Just, 1, (V[]){v_i_246});
      break;
    }
    case TAG_JFloat: {
      V v_x_247 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 1);
      V v_t_248 = heff_floatFloor(v_x_247);
      v_x2_2412 = heff_tag_at_n(v_ru_24it_243_24Just, TAG_Just, 1, (V[]){v_t_248});
      break;
    }
    case TAG_JString: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_x2_2412 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_244);
    }
    break;
  }
  default: heff_nomatch(v_it_243);
  }
  V v_line_2414;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nothing: {
    v_line_2414 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    heff_take_n(v_x2_2412, 1ULL, 1);
    v_line_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str2), NTAG(TAG_Nil)});
  V v_it_2416 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str3), v_t_2415}); V a_1 = v_params_241; V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_2425;
  switch (heff_tag_of(v_it_2416)) {
  case TAG_Nothing: {
    v_x2_2425 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_2417 = heff_field(v_it_2416, 0);
    V v_ru_24it_2416_24Just = heff_take_reuse_n(v_it_2416, 1ULL, 1);
    switch (heff_tag_of(v_it1_2417)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_2416_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_2417, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2416_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      V v_i_2419 = heff_field(v_it1_2417, 0);
      heff_take_n(v_it1_2417, 1ULL, 1);
      v_x2_2425 = heff_tag_at_n(v_ru_24it_2416_24Just, TAG_Just, 1, (V[]){v_i_2419});
      break;
    }
    case TAG_JFloat: {
      V v_x_2420 = heff_field(v_it1_2417, 0);
      heff_take_n(v_it1_2417, 1ULL, 1);
      V v_t_2421 = heff_floatFloor(v_x_2420);
      v_x2_2425 = heff_tag_at_n(v_ru_24it_2416_24Just, TAG_Just, 1, (V[]){v_t_2421});
      break;
    }
    case TAG_JString: {
      heff_take_n(v_it1_2417, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2416_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_2417, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2416_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_2417, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2416_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_2417);
    }
    break;
  }
  default: heff_nomatch(v_it_2416);
  }
  V v_ch_2427;
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_Nothing: {
    v_ch_2427 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    heff_take_n(v_x2_2425, 1ULL, 1);
    v_ch_2427 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_x2_2425);
  }
  return (g_heff_2elsp_2elsp_2eoffsetGo(v_src_240, v_line_2414, v_ch_2427, MK_INT(0LL), MK_INT(0LL)));
}
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eoffsetIn(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str0, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str1, 8, "severity");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str2, 6, "source");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str3, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str4, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str5, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str6, 1, "E");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str7, 1, "W");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str8, 1, "D");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str9, 1, "0");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str10, 4, "code");
Clo g_heff_2elsp_2elsp_2ediagnostic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagnostic_entry, 2, 0};

V g_heff_2elsp_2elsp_2ediagnostic(V v_src_240, V v_d_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str0), (g_heff_2elsp_2elsp_2erange(v_src_240, heff_dup(heff_rfield(v_d_241, 3))))});
  V v_t_243 = heff_dup(heff_rfield(v_d_241, 1));
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SError: {
    v_t_244 = MK_INT(1LL);
    break;
  }
  case TAG_SWarning: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_SDebug: {
    v_t_244 = MK_INT(4LL);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str1), heff_tag_n(TAG_JInt, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str2), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str3)})});
  V v_t_247 = heff_take_field(v_d_241, 4);
  V v_t_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    v_t_249 = heff_dup(heff_rfield(v_d_241, 2));
    break;
  }
  case TAG_Just: {
    V v_n_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 2)), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ediagnostic_str4), v_n_248));
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str5), heff_tag_n(TAG_JString, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2411})});
  V v_t_2421;
  if (heff_intEq_c(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL))) {
    heff_drop_rec(v_d_241, 5);
    v_t_2421 = NTAG(TAG_Nil);
  } else {
    V v_t_2414 = heff_take_field(v_d_241, 1);
    V v_t_2415;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_SError: {
      v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str6);
      break;
    }
    case TAG_SWarning: {
      v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str7);
      break;
    }
    case TAG_SDebug: {
      v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str8);
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2416 = (g_heff_2elsp_2erender_2enumDigits(heff_dup(heff_rfield(v_d_241, 0))));
    V v_t_2417 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_2416), ((V)&g_heff_2elsp_2elsp_2ediagnostic_str9)));
    V v_t_2418 = heff_intShow(heff_get_n(v_d_241, 0, 5));
    V v_t_2419 = heff_strAppend(v_t_2415, heff_strAppend(v_t_2417, v_t_2418));
    V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str10), heff_tag_n(TAG_JString, 1, (V[]){v_t_2419})});
    v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
  }
  return heff_tag_n(TAG_JObject, 1, (V[]){(g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_2412}), v_t_2421))});
}
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ediagnostic(a[0], a[1]);
}

static V g_heff_2elsp_2elsp_2ezeroSpan_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ezeroSpan_st;
static V g_heff_2elsp_2elsp_2ezeroSpan_init(void) {
  return heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2elsp_2elsp_2ezeroSpan_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ezeroSpan_st)) return g_heff_2elsp_2elsp_2ezeroSpan_val;
  return heff_global(&g_heff_2elsp_2elsp_2ezeroSpan_val, &g_heff_2elsp_2elsp_2ezeroSpan_st, g_heff_2elsp_2elsp_2ezeroSpan_init);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eloadError_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2eloadError_str1, 1, " ");
V g_heff_2elsp_2elsp_2eloadError_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eloadError_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadError_entry, 2, 0};

V g_heff_2elsp_2elsp_2eloadError(V v_imports_240, V v_e_241) {
top: ;
  V v_t_246 = (g_list_2efind(heff_clo_n(g_heff_2elsp_2elsp_2eloadError_lam0, 1, 1, (V[]){heff_dup(v_e_241)}), v_imports_240));
  V v_sp_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_sp_248 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
    break;
  }
  case TAG_Just: {
    V v_i_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_sp_248 = heff_get_n(v_i_247, 2, 3);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_e_241, v_sp_248, NTAG(TAG_Nothing)});
}
V g_heff_2elsp_2elsp_2eloadError_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eloadError(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eloadError_lam0(V self, V *args) {
  V v_i_242 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2eloadError_str0), heff_strAppend(heff_get_n(v_i_242, 0, 3), ((V)&g_heff_2elsp_2elsp_2eloadError_str1)));
  V v_x3_244 = (g_prelude_2eindexFrom(v_t_243, v_e_241, MK_INT(0LL)));
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_244);
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str1, 1, "s");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str2, 7, "module ");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str3, 2, " (");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str4, 22, ") does not elaborate: ");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str5, 6, " error");
V g_heff_2elsp_2elsp_2ebrokenImport_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ebrokenImport_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ebrokenImport_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ebrokenImport_entry, 2, 0};

V g_heff_2elsp_2elsp_2ebrokenImport(V v_imports_240, V v_c_241) {
top: ;
  V v_x1_242 = (g_list_2efilter_24s835571418x868029304(heff_dup(heff_rfield(v_c_241, 6))));
  V v_x1_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    v_x1_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_242, 0ULL, 2);
    v_x1_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  V v_t_247;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_True: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_247 = (g_list_2eany(heff_clo_n(g_heff_2elsp_2elsp_2ebrokenImport_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_imports_240));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    V v_t_249 = (g_list_2efind(heff_clo_n(g_heff_2elsp_2elsp_2ebrokenImport_lam1, 1, 1, (V[]){heff_dup(v_c_241)}), v_imports_240));
    V v_sp_2411;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      v_sp_2411 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
      break;
    }
    case TAG_Just: {
      V v_i_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      v_sp_2411 = heff_get_n(v_i_2410, 2, 3);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_xs_2412 = (g_list_2efilter_24s835571418x868029304(heff_dup(heff_rfield(v_c_241, 6))));
    V v_t_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2412; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    V v_xs_2414 = (g_list_2efilter_24s835571418x868029304(heff_take_field(v_c_241, 6)));
    V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2414; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    V v_t_2417;
    if (heff_intEq_c(v_t_2415, MK_INT(1LL))) {
      v_t_2417 = ((V)&g_heff_2elsp_2elsp_2ebrokenImport_str0);
    } else {
      v_t_2417 = ((V)&g_heff_2elsp_2elsp_2ebrokenImport_str1);
    }
    V v_msg_2418 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str2), heff_strAppend(heff_dup(heff_rfield(v_c_241, 0)), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str3), heff_strAppend(heff_get_n(v_c_241, 1, 13), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str4), heff_strAppend(heff_intShow(v_t_2413), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str5), v_t_2417)))))));
    V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SWarning), v_msg_2418, v_sp_2411, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2419});
  }
  case TAG_False: {
    heff_drop_rec(v_c_241, 13);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2elsp_2elsp_2ebrokenImport_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ebrokenImport(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2ebrokenImport_lam0(V self, V *args) {
  V v_i_246 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_i_246, 0, 3), heff_get_n(v_c_241, 0, 13));
}
V g_heff_2elsp_2elsp_2ebrokenImport_lam1(V self, V *args) {
  V v_i_248 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_i_248, 0, 3), heff_get_n(v_c_241, 0, 13));
}
Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecatMaybesL_entry, 1, 0};

V g_heff_2elsp_2elsp_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2elsp_2elsp_2ecatMaybesL(v_rest_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecatMaybesL(a[0]);
}
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ediagsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagsOf_entry, 3, 0};

V g_heff_2elsp_2elsp_2ediagsOf(V v_src_240, V v_program_241, V v_errors_242) {
top: ;
  V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_241)));
  V v_t_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    v_t_246 = heff_get_n(v_x_244, 6, 13);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_249 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam0, 1, 1, (V[]){heff_dup(v_src_240)}), v_errors_242));
  V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_241));
  V v_xs_2411 = (g_list_2edrop(MK_INT(1LL), v_t_2410));
  V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2411));
  V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam1, 1, 1, (V[]){v_src_240}), v_t_2412));
  V v_t_2416 = (g_heff_2elsp_2elsp_2ecatMaybesL(v_t_2415));
  V v_t_2417 = (g_prelude_2e_2b_2b(v_t_249, v_t_2416));
  return (g_prelude_2e_2b_2b(v_t_246, v_t_2417));
}
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ediagsOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
  return ({ V b_0 = heff_get_n(v_t_248, 0, 3); V a_1 = v_e_247; V r_ = (g_heff_2elsp_2elsp_2eloadError(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args) {
  V v_c_2413 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = (g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
  return ({ V b_0 = heff_get_n(v_t_2414, 0, 3); V a_1 = v_c_2413; V r_ = (g_heff_2elsp_2elsp_2ebrokenImport(b_0, a_1)); heff_drop(b_0); r_; });
}
Clo g_heff_2elsp_2elsp_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeptOf_entry, 1, 0};

V g_heff_2elsp_2elsp_2ekeptOf(V v_program_240) {
top: ;
  V v_x1_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_240)));
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_program_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
    V v_xs_245 = (g_list_2edrop(MK_INT(1LL), v_t_244));
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
    V v_t_247 = (g_list_2emap_24s1533895818x411093629(v_t_246));
    V v_t_248 = (g_heff_2ebuild_2edriver_2etraceless(v_x_242));
    V v_t_249 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return (g_prelude_2e_2b_2b(v_t_247, v_t_249));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ekeptOf(a[0]);
}
V g_heff_2elsp_2elsp_2edependentsOf_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2edependentsOf_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2edependentsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edependentsOf_entry, 2, 0};

V g_heff_2elsp_2elsp_2edependentsOf(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_get_n(v_st_240, 1, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2412 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2edependentsOf_lam0, 1, 1, (V[]){v_f_241}), v_t_242));
  return (g_list_2emap_24s1415906091x1371825187(v_t_2412));
}
V g_heff_2elsp_2elsp_2edependentsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edependentsOf(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2edependentsOf_lam1(V self, V *args) {
  V v_c_2411 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_c_2411, 1, 13), v_f_241);
}
V g_heff_2elsp_2elsp_2edependentsOf_lam0(V self, V *args) {
  V v_p_243 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_dup(heff_field(v_p_243, 0));
    v_t_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  if (heff_strEq_c(v_t_246, heff_dup(v_f_241))) {
    heff_drop(v_p_243);
    heff_drop(v_f_241);
    return NTAG(TAG_False);
  } else {
    V v_t_2410;
    switch (heff_tag_of(v_p_243)) {
    case TAG_MkPair: {
      V v_y_249 = heff_field(v_p_243, 1);
      heff_take_n(v_p_243, 2ULL, 2);
      v_t_2410 = v_y_249;
      break;
    }
    default: heff_nomatch(v_p_243);
    }
    return ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2edependentsOf_lam1, 1, 1, (V[]){v_f_241}); V b_1 = heff_get_n(v_t_2410, 1, 2); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  }
}
V g_heff_2elsp_2elsp_2enubPaths_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enubPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2enubPaths_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2elsp_2elsp_2enubPaths(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubPaths(a[0]);
}
V g_heff_2elsp_2elsp_2enubPaths_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(v_y_243, v_x_241)) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
V g_heff_2elsp_2elsp_2enubSources_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enubSources_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubSources(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_241 = heff_field(v_x1_240, 0);
    V v_ss_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2enubSources_lam0, 1, 1, (V[]){heff_dup(v_s_241)}), v_ss_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_241, (g_heff_2elsp_2elsp_2enubSources(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubSources(a[0]);
}
V g_heff_2elsp_2elsp_2enubSources_lam0(V self, V *args) {
  V v_t_243 = args[0];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_get_n(v_t_243, 1, 7), heff_get_n(v_s_241, 1, 7))) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str0, 6, "change");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str1, 11, "includeText");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str2, 4, "save");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str3, 9, "openClose");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str4, 16, "textDocumentSync");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str5, 1, ".");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str6, 17, "triggerCharacters");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str7, 18, "completionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str8, 15, "prepareProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str9, 14, "renameProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str10, 23, "workspaceSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str11, 22, "documentSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str12, 18, "referencesProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str13, 26, "documentFormattingProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str14, 18, "definitionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str15, 13, "hoverProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str16, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str17, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str18, 10, "serverInfo");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str19, 12, "capabilities");

static V g_heff_2elsp_2elsp_2ecapabilities_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ecapabilities_st;
static V g_heff_2elsp_2elsp_2ecapabilities_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str0), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(1LL)})});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str1), heff_dup(g_heff_2elsp_2elsp_2ejfalse_get())}), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str2), heff_tag_n(TAG_JObject, 1, (V[]){v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str3), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_243})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str4), heff_tag_n(TAG_JObject, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str5)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str6), heff_tag_n(TAG_JArray, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str8), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str9), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str10), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str11), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2412});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str12), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str13), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str14), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2415});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str15), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2416});
  V v_t_2418 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str16), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str17)})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str18), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str19), v_t_2418}), v_t_2422});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2423});
}
V g_heff_2elsp_2elsp_2ecapabilities_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ecapabilities_st)) return g_heff_2elsp_2elsp_2ecapabilities_val;
  return heff_global(&g_heff_2elsp_2elsp_2ecapabilities_val, &g_heff_2elsp_2elsp_2ecapabilities_st, g_heff_2elsp_2elsp_2ecapabilities_init);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str0, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str1, 8, "markdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str2, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str3, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str4, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str5, 4, "\012```");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str6, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str7, 11, "\012```\012\012---\012\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str8, 5, "value");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str9, 8, "contents");
Clo g_heff_2elsp_2elsp_2ehoverOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehoverOf_entry, 2, 0};

V g_heff_2elsp_2elsp_2ehoverOf(V v_a_240, V v_p_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_a_240, 2))));
  V v_t_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){v_x_243});
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop_rec(v_a_240, 3);
    heff_drop(v_p_241);
    return NTAG(TAG_JNull);
  }
  case TAG_Just: {
    V v_c_246 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    V v_t_247 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_dup(heff_rfield(v_a_240, 1)), heff_dup(v_p_241)));
    V v_t_248 = (g_heff_2ebuild_2equery_2etypeAt(v_c_246, v_t_247));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop_rec(v_a_240, 3);
      heff_drop(v_p_241);
      heff_drop_cell(v_ru_24t_245_24Just, 1);
      return NTAG(TAG_JNull);
    }
    case TAG_Just: {
      V v_t_249 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str0), heff_tag_at_n(v_ru_24t_245_24Just, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str1)})});
      V v_off_2411 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_take_field(v_a_240, 1), v_p_241));
      V v_t_2412 = (g_heff_2ebuild_2equery_2edefinitionAt(heff_get_n(v_a_240, 2, 3), v_off_2411));
      V v_doc_2419;
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nothing: {
        v_doc_2419 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str2);
        break;
      }
      case TAG_Just: {
        V v_d_2413 = heff_field(v_t_2412, 0);
        heff_take_n(v_t_2412, 1ULL, 1);
        V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_d_2413, 2)), 0, 2);
        V v_start_2415 = (g_heff_2ebuild_2equery_2elineStartOf(heff_dup(heff_rfield(v_d_2413, 1)), v_t_2414));
        V v_t_2416 = (g_heff_2ebuild_2equery_2ecommentAbove(heff_get_n(v_d_2413, 1, 3), v_start_2415, NTAG(TAG_Nil)));
        V v_t_2417 = (g_list_2emap_24s1819241345x1511673126(v_t_2416));
        V v_t_2418 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2417));
        v_doc_2419 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2ebuild_2equery_2edocMarkdown(a_0)); heff_drop(v_t_2418); r_; });
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      V v_t_2421;
      if (heff_strEq_c(heff_dup(v_doc_2419), ((V)&g_heff_2elsp_2elsp_2ehoverOf_str3))) {
        heff_drop(v_doc_2419);
        v_t_2421 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str4), heff_strAppend(v_t_249, ((V)&g_heff_2elsp_2elsp_2ehoverOf_str5)));
      } else {
        v_t_2421 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str6), heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str7), v_doc_2419)));
      }
      V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str8), heff_tag_at_n(v_ru_24t_248_24Just, TAG_JString, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
      V v_t_2424 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str9), v_t_2424}), NTAG(TAG_Nil)});
      return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2425});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehoverOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str0, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str1, 14, "selectionRange");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str2, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2echildJson_str3, 4, "name");
Clo g_heff_2elsp_2elsp_2echildJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echildJson_entry, 2, 0};

V g_heff_2elsp_2elsp_2echildJson(V v_src_240, V v_m_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_m_241, 0)});
  V v_t_243 = heff_tag_n(TAG_JInt, 1, (V[]){heff_take_field(v_m_241, 1)});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str0), (g_heff_2elsp_2elsp_2erange(heff_dup(v_src_240), heff_dup(heff_rfield(v_m_241, 2))))});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str1), (g_heff_2elsp_2elsp_2erange(v_src_240, heff_get_n(v_m_241, 2, 3)))});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str2), v_t_243}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echildJson_str3), v_t_242}), v_t_247});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_248});
}
V g_heff_2elsp_2elsp_2echildJson_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echildJson(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str0, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str1, 14, "selectionRange");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str2, 8, "children");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str3, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str4, 4, "name");
V g_heff_2elsp_2elsp_2edocSymbol_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2edocSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocSymbol_entry, 2, 0};

V g_heff_2elsp_2elsp_2edocSymbol(V v_src_240, V v_y_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_y_241, 0)});
  V v_t_243 = heff_tag_n(TAG_JInt, 1, (V[]){heff_take_field(v_y_241, 1)});
  V v_a_244 = heff_get_n(heff_dup(heff_rfield(v_y_241, 2)), 1, 2);
  V v_b_245 = heff_get_n(heff_dup(heff_rfield(v_y_241, 3)), 1, 2);
  V v_e_247;
  if (heff_intLe_c(heff_dup(v_a_244), heff_dup(v_b_245))) {
    heff_drop(v_a_244);
    v_e_247 = v_b_245;
  } else {
    heff_drop(v_b_245);
    v_e_247 = v_a_244;
  }
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_y_241, 2)), 0, 2);
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str0), (g_heff_2elsp_2elsp_2erange(heff_dup(v_src_240), heff_rec_n(2, shape_start__end, (V[]){v_t_248, v_e_247})))});
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str1), (g_heff_2elsp_2elsp_2erange(heff_dup(v_src_240), heff_dup(heff_rfield(v_y_241, 3))))});
  V v_t_2412 = heff_tag_n(TAG_JArray, 1, (V[]){(g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2edocSymbol_lam0, 1, 1, (V[]){v_src_240}), heff_get_n(v_y_241, 4, 5)))});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str2), v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str3), v_t_243}), v_t_2414});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str4), v_t_242}), v_t_2415});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2416});
}
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edocSymbol(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2edocSymbol_lam0(V self, V *args) {
  V v_m_2411 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2elsp_2elsp_2echildJson(v_src_240, v_m_2411));
}
Clo g_heff_2elsp_2elsp_2elowerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elowerGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2elowerGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_t_247;
    if (heff_intLe_c(MK_INT(65LL), heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)))) {
      if (heff_intLe_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(90LL))) {
        V v_t_246 = heff_intAdd(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(32LL));
        v_t_247 = heff_strFromByte(v_t_246);
      } else {
        v_t_247 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
      }
    } else {
      v_t_247 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
    }
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = heff_strAppend(v_acc_242, v_t_247);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elowerGo(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2etargetIn_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2etargetIn_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2etargetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2etargetIn_entry, 5, 0};

V g_heff_2elsp_2elsp_2etargetIn(V v_st_240, V v_f_241, V v_d_242, V v_p_243, V v_program_244) {
top: ;
  V v_t_246 = (g_list_2efind(heff_clo_n(g_heff_2elsp_2elsp_2etargetIn_lam0, 1, 1, (V[]){heff_dup(v_f_241)}), v_program_244));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_f_241);
    heff_drop_rec(v_d_242, 2);
    heff_drop(v_p_243);
    heff_drop(v_program_244);
    return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
  }
  case TAG_Just: {
    V v_c_247 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_c_247, 3)), heff_dup(heff_rfield(v_d_242, 1)))) {
      V v_t_2411 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2etargetIn_lam1, 1, 1, (V[]){heff_dup(v_f_241)}), heff_dup(v_program_244)));
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_247, NTAG(TAG_Nil)});
      V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2412));
      V v_t_2414 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_dup(heff_rfield(v_d_242, 1)), heff_dup(v_p_243)));
      V v_t_2415 = (g_heff_2ebuild_2equery_2etargetAt(v_t_2413, v_t_2414));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nothing: {
        heff_drop(v_f_241);
        heff_drop_rec(v_d_242, 2);
        heff_drop(v_p_243);
        heff_drop(v_program_244);
        heff_drop_cell(v_ru_24t_246_24Just, 1);
        return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
      }
      case TAG_Just: {
        V v_t_2416 = heff_field(v_t_2415, 0);
        heff_take_n(v_t_2415, 1ULL, 1);
        V v_off_2417 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_get_n(v_d_242, 1, 2), v_p_243));
        V v_occurrences_2418 = (g_heff_2ebuild_2equery_2eoccurrences(v_program_244, heff_dup(heff_rfield(v_t_2416, 0)), heff_dup(heff_rfield(v_t_2416, 1))));
        V v_t_2419 = heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_241, heff_take_field(v_t_2416, 0), heff_get_n(v_t_2416, 1, 2), v_occurrences_2418});
        V v_target_2420 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_t_2419});
        return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, v_off_2417, v_target_2420});
      }
      default: return heff_nomatch(v_t_2415);
      }
    } else {
      heff_drop(v_f_241);
      heff_drop_rec(v_d_242, 2);
      heff_drop(v_p_243);
      heff_drop(v_program_244);
      heff_drop_rec(v_c_247, 13);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      return heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2elsp_2elsp_2etargetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2etargetIn(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2etargetIn_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_c_245, 1, 13), v_f_241);
}
V g_heff_2elsp_2elsp_2etargetIn_lam1(V self, V *args) {
  V v_c2_249 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_get_n(v_c2_249, 1, 13), v_f_241)) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenamedText_str0, 0, "");
V g_heff_2elsp_2elsp_2erenamedText_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenamedText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamedText_entry, 2, 0};

V g_heff_2elsp_2elsp_2erenamedText(V v_new_240, V v_os_241) {
top: ;
  V v_z_244;
  switch (heff_tag_of(v_os_241)) {
  case TAG_Nil: {
    v_z_244 = ((V)&g_heff_2elsp_2elsp_2erenamedText_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_os_241, 0));
    v_z_244 = heff_get_n(v_x_242, 1, 4);
    break;
  }
  default: heff_nomatch(v_os_241);
  }
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_os_241));
  return ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2erenamedText_lam0, 2, 1, (V[]){v_new_240}); V a_1 = v_z_244; V a_2 = v_t_245; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
}
V g_heff_2elsp_2elsp_2erenamedText_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamedText(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2erenamedText_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_x_247 = args[1];
  V v_new_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_x_247, 2)), 0, 2);
  V v_t_249 = heff_get_n(heff_get_n(v_x_247, 2, 4), 1, 2);
  V v_t_2410 = heff_strSlice(heff_dup(v_acc_246), v_t_249, heff_strLength(heff_dup(v_acc_246)));
  return heff_strAppend(heff_strSlice(v_acc_246, MK_INT(0LL), v_t_248), heff_strAppend(v_new_240, v_t_2410));
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_cs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2enubCheckedPaths_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_cs_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_241, (g_heff_2elsp_2elsp_2enubCheckedPaths(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubCheckedPaths(a[0]);
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_lam0(V self, V *args) {
  V v_d_243 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_get_n(v_d_243, 1, 13), heff_get_n(v_c_241, 1, 13))) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
V g_heff_2elsp_2elsp_2eshiftOf_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eshiftOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eshiftOf_entry, 3, 0};

V g_heff_2elsp_2elsp_2eshiftOf(V v_t_240, V v_new_241, V v_b_242) {
top: ;
  V v_t_243 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
  V v_t_244 = heff_intSub(heff_strLength(v_new_241), v_t_243);
  V v_xs_248 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2eshiftOf_lam0, 1, 2, (V[]){heff_dup(v_t_240), v_b_242}), heff_get_n(v_t_240, 3, 4)));
  V v_t_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_248; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
  return heff_intMul(v_t_244, v_t_249);
}
V g_heff_2elsp_2elsp_2eshiftOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eshiftOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eshiftOf_lam0(V self, V *args) {
  V v_o_245 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_b_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_o_245, 0)), heff_get_n(v_t_240, 0, 4))) {
    V v_t_247 = heff_get_n(heff_get_n(v_o_245, 2, 4), 0, 2);
    return heff_intLt(v_t_247, heff_get_n(v_b_242, 0, 2));
  } else {
    heff_drop_rec(v_o_245, 4);
    heff_drop_rec(v_b_242, 2);
    return NTAG(TAG_False);
  }
}
Clo g_heff_2elsp_2elsp_2erenamedTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamedTarget_entry, 2, 0};

V g_heff_2elsp_2elsp_2erenamedTarget(V v_t_240, V v_new_241) {
top: ;
  V v_target_242 = heff_dup(heff_rfield(v_t_240, 1));
  V v_t_243 = heff_take_field(v_target_242, 2);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_get_n(v_target_242, 1, 3);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_t_240, 1)), 0, 3);
      V v_t_247 = heff_strLength(heff_get_n(v_t_240, 2, 4));
      V v_t_248 = heff_intSub(heff_strLength(v_t_246), v_t_247);
      V v_t_249 = heff_strAppend(heff_strSlice(v_t_245, MK_INT(0LL), v_t_248), v_new_241);
      return heff_rec_n(3, shape_key__member__local, (V[]){v_t_249, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      V v_t_2411 = heff_get_n(heff_get_n(v_t_240, 1, 4), 0, 3);
      return heff_rec_n(3, shape_key__member__local, (V[]){v_t_2411, heff_tag_n(TAG_Just, 1, (V[]){v_new_241}), NTAG(TAG_Nothing)});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_b_2412 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_target_242, 3);
    V v_t_2413 = (g_heff_2elsp_2elsp_2eshiftOf(heff_dup(v_t_240), heff_dup(v_new_241), heff_dup(v_b_2412)));
    V v_s_2414 = heff_intAdd(heff_dup(heff_rfield(v_b_2412, 0)), v_t_2413);
    V v_t_2415 = (g_heff_2elsp_2elsp_2eshiftOf(heff_dup(v_t_240), heff_dup(v_new_241), heff_dup(v_b_2412)));
    V v_t_2416 = heff_intAdd(heff_get_n(v_b_2412, 0, 2), v_t_2415);
    V v_e_2417 = heff_intAdd(v_t_2416, heff_strLength(v_new_241));
    V v_t_2418 = heff_get_n(heff_get_n(v_t_240, 1, 4), 0, 3);
    V v_t_2419 = heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_s_2414, v_e_2417})});
    return heff_rec_n(3, shape_key__member__local, (V[]){v_t_2418, NTAG(TAG_Nothing), v_t_2419});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamedTarget(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str0, 10, "renaming `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str1, 6, "` to `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str2, 13, "` would make ");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str3, 14, " more error(s)");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str4, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameVerdict_str5, 60, "` is already a name some of these occurrences would refer to");
Clo g_heff_2elsp_2elsp_2erenameVerdict_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameVerdict_entry, 6, 0};

V g_heff_2elsp_2elsp_2erenameVerdict(V v_before_240, V v_t_241, V v_new_242, V v_errorsBefore_243, V v_errorsAfter_244, V v_after_245) {
top: ;
  V v_t_2415;
  if (heff_intLt_c(heff_dup(v_errorsBefore_243), heff_dup(v_errorsAfter_244))) {
    heff_drop(v_after_245);
    V v_t_247 = heff_intShow(heff_intSub(v_errorsAfter_244, v_errorsBefore_243));
    V v_t_248 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str0), heff_strAppend(heff_get_n(v_t_241, 2, 4), heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str1), heff_strAppend(v_new_242, heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str2), heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2elsp_2erenameVerdict_str3)))))));
    v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
  } else {
    heff_drop(v_errorsBefore_243);
    heff_drop(v_errorsAfter_244);
    V v_t_249 = (g_heff_2elsp_2elsp_2erenamedTarget(heff_dup(v_t_241), heff_dup(v_new_242)));
    V v_xs_2410 = (g_heff_2ebuild_2equery_2eoccurrences(v_after_245, v_t_249, heff_dup(v_new_242)));
    V v_a_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2410; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    V v_b_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_t_241, 3, 4); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    if (heff_intEq_c(v_a_2411, v_b_2412)) {
      heff_drop(v_new_242);
      v_t_2415 = NTAG(TAG_Nothing);
    } else {
      V v_t_2414 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameVerdict_str4), heff_strAppend(v_new_242, ((V)&g_heff_2elsp_2elsp_2erenameVerdict_str5)));
      v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_before_240, 0, 2), v_t_2415});
}
V g_heff_2elsp_2elsp_2erenameVerdict_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenameVerdict(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eaffectedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eaffectedGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2eaffectedGo(V v_changed_240, V v_mods_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_c_243, 1))}));
    V v_t_246 = (g_list_2eany(v_t_245, v_changed_240));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_243, 0)), v_mods_241});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_243, 1, 13), (g_heff_2elsp_2elsp_2eaffectedGo(v_changed_240, v_t_247, v_rest_244))});
    }
    case TAG_False: {
      V v_t_2410 = (g_list_2eany(heff_clo_n(g_heff_2elsp_2elsp_2eaffectedGo_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}), heff_rfield(v_c_243, 8)));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        V v_t_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_243, 0)), v_mods_241});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_243, 1, 13), (g_heff_2elsp_2elsp_2eaffectedGo(v_changed_240, v_t_2411, v_rest_244))});
      }
      case TAG_False: {
        heff_drop_rec(v_c_243, 13);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_244;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eaffectedGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_lam0(V self, V *args) {
  V v_d_248 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_d_248}));
  return ({ V a_0 = v_t_249; V a_1 = v_mods_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_mods_241); r_; });
}
V g_heff_2elsp_2elsp_2enubRoots_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enubRoots_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubRoots(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2411 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2enubRoots_lam0, 1, 1, (V[]){heff_dup(v_r_241)}), v_rs_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_r_241, (g_heff_2elsp_2elsp_2enubRoots(v_t_2411))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubRoots(a[0]);
}
V g_heff_2elsp_2elsp_2enubRoots_lam0(V self, V *args) {
  V v_q_243 = args[0];
  V v_r_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246;
  switch (heff_tag_of(v_q_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_q_243, 0);
    heff_take_n(v_q_243, 1ULL, 2);
    v_t_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_q_243);
  }
  V v_t_249;
  switch (heff_tag_of(v_r_241)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_r_241, 0);
    heff_take_n(v_r_241, 1ULL, 2);
    v_t_249 = v_x_247;
    break;
  }
  default: heff_nomatch(v_r_241);
  }
  if (heff_strEq_c(v_t_246, v_t_249)) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str2, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str3, 10, "heff-watch");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str4, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str5, 25, "client/registerCapability");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str6, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str7, 10, "heff-watch");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str8, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str9, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str10, 11, "globPattern");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str11, 7, "**/*.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str12, 8, "watchers");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str13, 15, "registerOptions");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str14, 13, "registrations");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str15, 6, "params");

static V g_heff_2elsp_2elsp_2eregistration_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2eregistration_st;
static V g_heff_2elsp_2elsp_2eregistration_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str1)})});
  V v_t_241 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str2), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str3)})});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str4), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str5)})});
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str6), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str7)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str8), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str9)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str10), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str11)})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_246}), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str12), heff_tag_n(TAG_JArray, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str13), heff_tag_n(TAG_JObject, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str14), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str15), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_2417})});
  return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_2418})});
}
V g_heff_2elsp_2elsp_2eregistration_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2eregistration_st)) return g_heff_2elsp_2elsp_2eregistration_val;
  return heff_global(&g_heff_2elsp_2elsp_2eregistration_val, &g_heff_2elsp_2elsp_2eregistration_st, g_heff_2elsp_2elsp_2eregistration_init);
}
HEFF_LIT(g_heff_2elsp_2elsp_2elastChange_str0, 14, "contentChanges");
HEFF_LIT(g_heff_2elsp_2elsp_2elastChange_str1, 4, "text");
Clo g_heff_2elsp_2elsp_2elastChange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elastChange_entry, 1, 0};

V g_heff_2elsp_2elsp_2elastChange(V v_p_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elastChange_str0), NTAG(TAG_Nil)});
  V v_it_242 = ({ V a_0 = v_t_241; V a_1 = v_p_240; V r_ = (g_heff_2eutil_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_241, 2); r_; });
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_it1_243 = heff_field(v_it_242, 0);
    V v_ru_24it_242_24Just = heff_take_reuse_n(v_it_242, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_it1_243)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      V v_xs_248 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24it_242_24Just, TAG_Just, 1, (V[]){v_xs_248});
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_243);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_cs_2411 = heff_field(v_t_2410, 0);
      V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 1ULL, 1);
      V v_x1_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_2411));
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24t_2410_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_x_2413 = heff_field(v_x1_2412, 0);
        V v_ru_24x1_2412_24Cons = heff_take_reuse_n(v_x1_2412, 1ULL, 2);
        V v_t_2415 = heff_tag_at_n(v_ru_24x1_2412_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elastChange_str1), NTAG(TAG_Nil)});
        V v_it_2416 = ({ V a_0 = v_t_2415; V a_1 = v_x_2413; V r_ = (g_heff_2eutil_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_2415, 2); r_; });
        switch (heff_tag_of(v_it_2416)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24t_2410_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_it1_2417 = heff_field(v_it_2416, 0);
          heff_take_n(v_it_2416, 1ULL, 1);
          switch (heff_tag_of(v_it1_2417)) {
          case TAG_JNull: {
            heff_drop_cell(v_ru_24t_2410_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2410_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2410_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JFloat: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2410_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JString: {
            V v_s_2421 = heff_field(v_it1_2417, 0);
            heff_take_n(v_it1_2417, 1ULL, 1);
            return heff_tag_at_n(v_ru_24t_2410_24Just, TAG_Just, 1, (V[]){v_s_2421});
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2410_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            heff_drop_cell(v_ru_24t_2410_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_it1_2417);
          }
        }
        default: return heff_nomatch(v_it_2416);
        }
      }
      default: return heff_nomatch(v_x1_2412);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2elsp_2elsp_2elastChange_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elastChange(a[0]);
}
Clo g_heff_2elsp_2elsp_2echanged_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echanged_entry, 3, 0};

V g_heff_2elsp_2elsp_2echanged(V v_st_240, V v_f_241, V v_text_242) {
top: ;
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_f_241), heff_rfield(v_st_240, 0)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_f_241);
    heff_drop(v_text_242);
    return v_st_240;
  }
  case TAG_Just: {
    V v_d_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = ({ V rv_1 = v_text_242; V rr_ = heff_rec_reuse_n(v_d_244, 1ULL, 2, shape_uri__text); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_d_246 = (g_map_2einsert_24s1341440536x470972936(v_f_241, v_t_245, heff_take_field(v_st_240, 0)));
    return ({ V rv_0 = v_d_246; V rr_ = heff_rec_reuse_n(v_st_240, 126ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2elsp_2echanged_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echanged(a[0], a[1], a[2]);
}
Clo g_heff_2elsp_2elsp_2eclosed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclosed_entry, 2, 0};

V g_heff_2elsp_2elsp_2eclosed(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = (g_map_2edelete_24s805420727x38051515(heff_dup(v_f_241), heff_rfield(v_st_240, 2)));
  V v_c_243 = (g_map_2edelete_24s805420727x38051515(heff_dup(v_f_241), heff_rfield(v_st_240, 1)));
  V v_d_244 = (g_map_2edelete_24s805420727x38051515(v_f_241, heff_rfield(v_st_240, 0)));
  V v_s_245 = ({ V rv_0 = v_d_244; V rr_ = heff_rec_reuse_n(v_st_240, 126ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_s_246 = ({ V rv_1 = v_c_243; V rr_ = heff_rec_reuse_n(v_s_245, 125ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib); heff_rfield(rr_, 1) = rv_1; rr_; });
  return ({ V rv_2 = v_t_242; V rr_ = heff_rec_reuse_n(v_s_246, 123ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2elsp_2elsp_2eclosed_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eclosed(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_str1, 12, "textDocument");
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam0, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam1, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam2, 1, 0};
Clo g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_entry, 1, 0};

V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(V v_p_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_str0), NTAG(TAG_Nil)});
  V v_it_242 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_str1), v_t_241}); V a_1 = v_p_240; V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam0_clo);
  }
  case TAG_Just: {
    V v_it1_245 = heff_field(v_it_242, 0);
    V v_ru_24it_242_24Just = heff_take_reuse_n(v_it_242, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_it1_245)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_249 = heff_field(v_it1_245, 0);
      heff_take_n(v_it1_245, 1ULL, 1);
      v_t_2412 = heff_tag_at_n(v_ru_24it_242_24Just, TAG_Just, 1, (V[]){v_s_249});
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_245);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      return ((V)&g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam1_clo);
    }
    case TAG_Just: {
      V v_u_2415 = heff_field(v_t_2412, 0);
      V v_ru_24t_2412_24Just = heff_take_reuse_n(v_t_2412, 1ULL, 1);
      V v_t_2417 = heff_tag_at_n(v_ru_24t_2412_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_UriPath, 2, (V[]){v_u_2415, ((V)&g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam2_clo)})});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      return heff_tail(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2418});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(a[0]);
}
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam2(V self, V *args) {
  V v_p_2416 = args[0];
  return v_p_2416;
}
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str2, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str3, 31, "textDocument/publishDiagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str4, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str5, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str6, 6, "params");
Clo g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_entry, 2, 0};

V g_heff_2elsp_2elsp_2epublish_24s471405199x320951611(V v_uri_240, V v_ds_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str1)})});
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str2), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str3)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str4), heff_tag_n(TAG_JString, 1, (V[]){v_uri_240})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str5), heff_tag_n(TAG_JArray, 1, (V[]){v_ds_241})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_str6), v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_248})});
  V v_t_2410 = ({ V b_0 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_249}); V r_ = (g_heff_2eutil_2ejson_2estringify(b_0)); heff_drop(b_0); r_; });
  V v_a_2411 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  return heff_tail(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
}
V g_heff_2elsp_2elsp_2epublish_24s471405199x320951611_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2epublish_24s471405199x320951611(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam2, 1, 0};
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam4(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_entry, 2, 0};

V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_f_241), heff_rfield(v_st_240, 0)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_f_241);
    return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Just: {
    V v_d_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_c_2416 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam1, 1, 1, (V[]){heff_dup(v_st_240)}), heff_dup(heff_rfield(v_st_240, 6)), heff_dup(v_f_241)));
    return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam4, 2, 4, (V[]){v_c_2416, v_d_245, v_f_241, v_st_240});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam2(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam3(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_d_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2413);
  V v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2412, 1, 2)});
  V f_ = v_k_2414;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam1(V self, V *args) {
  V v_p_246 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = ({ V a_0 = heff_dup(v_p_246); V b_1 = heff_get_n(v_st_240, 0, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_p_246, ((V)&g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam2_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V f_ = ((V)&g_co_2eop_24s1084803226x1249263831_clo);
    args[0] = v_t_2411;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_d_2412 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    heff_drop(v_p_246);
    return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam3, 2, 1, (V[]){v_d_2412});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam7(V self, V *args) {
  V v_x_2424 = args[0];
  V v_d_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2elsp_2elsp_2ediagnostic(heff_get_n(v_d_245, 1, 2), v_x_2424));
}
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_d_245 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_k_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_rec_n(2, shape_text__program, (V[]){heff_get_n(v_d_245, 1, 2), v_x_2422});
  V v_c_2429 = (g_map_2einsert_24s1341440536x470972936(v_f_241, v_t_2428, heff_take_field(v_st_240, 1)));
  V v_t_2430 = ({ V rv_1 = v_c_2429; V rr_ = heff_rec_reuse_n(v_st_240, 125ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2418;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_d_245 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_hd_2417 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_k_2418 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2422 = (g_heff_2elsp_2elsp_2ekeptOf(heff_get_n(v_x_2421, 0, 2)));
  V v_t_2423 = (g_heff_2elsp_2elsp_2ediagsOf(heff_dup(heff_rfield(v_d_245, 1)), heff_dup(v_x_2422), heff_get_n(v_x_2419, 1, 5)));
  V v_t_2425 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam7, 1, 1, (V[]){heff_dup(v_d_245)}), v_t_2423));
  V v_c_2426 = heff_tr(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611(heff_dup(heff_rfield(v_d_245, 0)), v_t_2425));
  V f_ = v_c_2426;
  heff_room[0] = v_hd_2417;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam8, 1, 5, (V[]){v_d_245, v_x_2422, v_f_241, v_st_240, v_k_2418});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_d_245 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_k_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2420 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(heff_dup(v_x_2419)));
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_2417);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam6, 1, 6, (V[]){v_d_245, v_x_2419, v_hd_2417, v_f_241, v_st_240, v_k_2418});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_d_245 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_lam5, 1, 5, (V[]){v_hd_2417, v_d_245, v_f_241, v_st_240, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_entry, 4, 0};

V g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(V v_st_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_c_246 = (g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(v_st_240, heff_dup(v_f_244)));
    return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_lam0, 1, 3, (V[]){heff_dup(v_rest_245), v_z_242, v_z_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_x_247; V a_1 = v_rest_245; V a_2 = v_z_242; V a_3 = v_z_243; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str0, 4, "exit");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str1, 11, "initialized");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str2, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str3, 20, "textDocument/didOpen");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str4, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str5, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str6, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str7, 4, "text");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str8, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str10, 22, "textDocument/didChange");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str11, 20, "textDocument/didSave");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str12, 21, "textDocument/didClose");
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam4, 1, 0};
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam7(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam7, 2, 0};
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_entry, 3, 0};

V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559(V v_st_240, V v_m_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(heff_dup(v_p_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam0, 2, 4, (V[]){v_c_243, v_m_241, v_st_240, v_p_242});
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2417);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam3(V self, V *args) {
  V v_x_2452 = args[0];
  V v_st_2448 = heff_env(self)[0];
  V v_f_2421 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2453 = (g_heff_2elsp_2elsp_2edependentsOf(v_st_2448, v_f_2421));
  return ({ V a_0 = v_x_2452; V a_1 = v_t_2453; V a_2 = v_hd_244; V a_3 = v_k_245; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(a_0, a_1, a_2, a_3)); heff_drop(v_t_2453); r_; });
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam4(V self, V *args) {
  V v_n_2457 = args[0];
  return v_n_2457;
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam5(V self, V *args) {
  V v_x_2460 = args[0];
  V v_f_2421 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_text_2456 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2461 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_f_2421), heff_intAdd(v_x_2460, MK_INT(200LL)), heff_dup(heff_rfield(v_st_240, 2))));
  V v_s_2462 = (g_heff_2elsp_2elsp_2echanged(v_st_240, v_f_2421, v_text_2456));
  V v_t_2463 = ({ V rv_2 = v_t_2461; V rr_ = heff_rec_reuse_n(v_s_2462, 123ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_k_245;
  args[0] = v_t_2463;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam6(V self, V *args) {
  V v_x_2468 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_2421 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2469 = (g_heff_2elsp_2elsp_2edependentsOf(v_st_240, v_f_2421));
  return ({ V a_0 = v_x_2468; V a_1 = v_t_2469; V a_2 = v_hd_244; V a_3 = v_k_245; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(a_0, a_1, a_2, a_3)); heff_drop(v_t_2469); r_; });
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam7(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k_2473 = args[1];
  heff_drop(v_hd_2472);
  V f_ = v_k_2473;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam8(V self, V *args) {
  V v_x_2476 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_2421 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2476);
  V v_x_2477 = (g_heff_2elsp_2elsp_2eclosed(v_st_240, v_f_2421));
  V f_ = v_k_245;
  args[0] = v_x_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str0))) {
    heff_drop(v_x_246);
    heff_drop(v_m_241);
    heff_drop(v_p_242);
    V v_t_248 = heff_get_n(v_st_240, 5, 7);
    V v_code_249;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      v_code_249 = MK_INT(0LL);
      break;
    }
    case TAG_False: {
      v_code_249 = MK_INT(1LL);
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){v_code_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, v_hd_244, v_k_245));
  } else {
    if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str1))) {
      heff_drop(v_x_246);
      heff_drop(v_m_241);
      heff_drop(v_p_242);
      V v_t_2413 = heff_dup(heff_rfield(v_st_240, 4));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        V v_t_2414 = ({ V b_0 = heff_dup(g_heff_2elsp_2elsp_2eregistration_get()); V r_ = (g_heff_2eutil_2ejson_2estringify(b_0)); heff_drop(b_0); r_; });
        V v_a_2415 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2414, NTAG(TAG_MkUnit)});
        V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
        return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam2, 1, 2, (V[]){v_k_245, v_st_240})));
      }
      case TAG_False: {
        heff_drop(v_hd_244);
        V f_ = v_k_245;
        args[0] = v_st_240;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_t_2413);
      }
    } else {
      if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str2))) {
        heff_drop(v_x_246);
        heff_drop(v_m_241);
        heff_drop(v_p_242);
        V v_t_2419 = (g_map_2etoListOnto(heff_rfield(v_st_240, 0), NTAG(TAG_Nil)));
        V v_t_2420 = (g_list_2emap_24s1415906091x1371825187(v_t_2419));
        return ({ V a_0 = v_st_240; V a_1 = v_t_2420; V a_2 = v_hd_244; V a_3 = v_k_245; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(a_0, a_1, a_2, a_3)); heff_drop(v_t_2420); r_; });
      } else {
        switch (heff_tag_of(v_x_246)) {
        case TAG_Nothing: {
          heff_drop(v_m_241);
          heff_drop(v_hd_244);
          heff_drop(v_p_242);
          V f_ = v_k_245;
          args[0] = v_st_240;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_Just: {
          V v_f_2421 = heff_field(v_x_246, 0);
          V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
          if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str3))) {
            heff_drop(v_m_241);
            V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str4), NTAG(TAG_Nil)});
            V v_it_2424 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str5), v_t_2423}); V a_1 = heff_dup(v_p_242); V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
            V v_x2_2432;
            switch (heff_tag_of(v_it_2424)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24x_246_24Just, 1);
              v_x2_2432 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_it1_2425 = heff_field(v_it_2424, 0);
              heff_take_n(v_it_2424, 1ULL, 1);
              switch (heff_tag_of(v_it1_2425)) {
              case TAG_JNull: {
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_x2_2432 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2425, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_x2_2432 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_it1_2425, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_x2_2432 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JFloat: {
                heff_take_n(v_it1_2425, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_x2_2432 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JString: {
                V v_s_2429 = heff_field(v_it1_2425, 0);
                heff_take_n(v_it1_2425, 1ULL, 1);
                v_x2_2432 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_Just, 1, (V[]){v_s_2429});
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2425, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_x2_2432 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2425, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_x2_2432 = NTAG(TAG_Nothing);
                break;
              }
              default: heff_nomatch(v_it1_2425);
              }
              break;
            }
            default: heff_nomatch(v_it_2424);
            }
            V v_uri_2434;
            switch (heff_tag_of(v_x2_2432)) {
            case TAG_Nothing: {
              v_uri_2434 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str6);
              break;
            }
            case TAG_Just: {
              V v_x_2433 = heff_field(v_x2_2432, 0);
              heff_take_n(v_x2_2432, 1ULL, 1);
              v_uri_2434 = v_x_2433;
              break;
            }
            default: heff_nomatch(v_x2_2432);
            }
            V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str7), NTAG(TAG_Nil)});
            V v_it_2436 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str8), v_t_2435}); V a_1 = v_p_242; V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
            V v_x2_2444;
            switch (heff_tag_of(v_it_2436)) {
            case TAG_Nothing: {
              v_x2_2444 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_it1_2437 = heff_field(v_it_2436, 0);
              V v_ru_24it_2436_24Just = heff_take_reuse_n(v_it_2436, 1ULL, 1);
              switch (heff_tag_of(v_it1_2437)) {
              case TAG_JNull: {
                heff_drop_cell(v_ru_24it_2436_24Just, 1);
                v_x2_2444 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2437, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2436_24Just, 1);
                v_x2_2444 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_it1_2437, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2436_24Just, 1);
                v_x2_2444 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JFloat: {
                heff_take_n(v_it1_2437, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2436_24Just, 1);
                v_x2_2444 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JString: {
                V v_s_2441 = heff_field(v_it1_2437, 0);
                heff_take_n(v_it1_2437, 1ULL, 1);
                v_x2_2444 = heff_tag_at_n(v_ru_24it_2436_24Just, TAG_Just, 1, (V[]){v_s_2441});
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2437, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2436_24Just, 1);
                v_x2_2444 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2437, 0ULL, 1);
                heff_drop_cell(v_ru_24it_2436_24Just, 1);
                v_x2_2444 = NTAG(TAG_Nothing);
                break;
              }
              default: heff_nomatch(v_it1_2437);
              }
              break;
            }
            default: heff_nomatch(v_it_2436);
            }
            V v_text_2446;
            switch (heff_tag_of(v_x2_2444)) {
            case TAG_Nothing: {
              v_text_2446 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str9);
              break;
            }
            case TAG_Just: {
              V v_x_2445 = heff_field(v_x2_2444, 0);
              heff_take_n(v_x2_2444, 1ULL, 1);
              v_text_2446 = v_x_2445;
              break;
            }
            default: heff_nomatch(v_x2_2444);
            }
            V v_d_2447 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_f_2421), heff_rec_n(2, shape_uri__text, (V[]){v_uri_2434, v_text_2446}), heff_take_field(v_st_240, 0)));
            V v_st_2448 = ({ V rv_0 = v_d_2447; V rr_ = heff_rec_reuse_n(v_st_240, 126ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib); heff_rfield(rr_, 0) = rv_0; rr_; });
            V v_t_2449 = (g_map_2edelete_24s805420727x38051515(heff_dup(v_f_2421), heff_rfield(v_st_2448, 2)));
            V v_t_2450 = heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(heff_rfield(v_st_2448, 0)), heff_dup(heff_rfield(v_st_2448, 1)), v_t_2449, heff_dup(heff_rfield(v_st_2448, 3)), heff_dup(heff_rfield(v_st_2448, 4)), heff_dup(heff_rfield(v_st_2448, 5)), heff_dup(heff_rfield(v_st_2448, 6))});
            V v_c_2451 = (g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(v_t_2450, heff_dup(v_f_2421)));
            V f_ = v_c_2451;
            heff_room[0] = heff_dup(v_hd_244);
            heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam3, 1, 4, (V[]){v_st_2448, v_f_2421, v_hd_244, v_k_245});
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          } else {
            if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str10))) {
              heff_drop(v_m_241);
              V v_t_2455 = (g_heff_2elsp_2elsp_2elastChange(v_p_242));
              switch (heff_tag_of(v_t_2455)) {
              case TAG_Nothing: {
                heff_drop(v_hd_244);
                heff_drop(v_f_2421);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                V f_ = v_k_245;
                args[0] = v_st_240;
                if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                return heff_tail(f_, 1, args);
              }
              case TAG_Just: {
                V v_text_2456 = heff_field(v_t_2455, 0);
                V v_ru_24t_2455_24Just = heff_take_reuse_n(v_t_2455, 1ULL, 1);
                V v_t_2458 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam4_clo)})});
                V v_t_2459 = heff_tag_at_n(v_ru_24t_2455_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
                return (g_co_2eop_24s954557541x749476273(v_t_2459, v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam5, 1, 4, (V[]){v_f_2421, v_st_240, v_text_2456, v_k_245})));
              }
              default: return heff_nomatch(v_t_2455);
              }
            } else {
              heff_drop(v_p_242);
              heff_drop_cell(v_ru_24x_246_24Just, 1);
              if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str11))) {
                heff_drop(v_m_241);
                V v_t_2465 = (g_map_2edelete_24s805420727x38051515(heff_dup(v_f_2421), heff_rfield(v_st_240, 2)));
                V v_t_2466 = heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(heff_rfield(v_st_240, 0)), heff_dup(heff_rfield(v_st_240, 1)), v_t_2465, heff_dup(heff_rfield(v_st_240, 3)), heff_dup(heff_rfield(v_st_240, 4)), heff_dup(heff_rfield(v_st_240, 5)), heff_dup(heff_rfield(v_st_240, 6))});
                V v_c_2467 = (g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(v_t_2466, heff_dup(v_f_2421)));
                V f_ = v_c_2467;
                heff_room[0] = heff_dup(v_hd_244);
                heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam6, 1, 4, (V[]){v_st_240, v_f_2421, v_hd_244, v_k_245});
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              } else {
                if (heff_strEq_c(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_str12))) {
                  V v_t_2471 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_f_2421), heff_rfield(v_st_240, 0)));
                  V v_c_2475;
                  switch (heff_tag_of(v_t_2471)) {
                  case TAG_Nothing: {
                    v_c_2475 = ((V)&g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam7_clo);
                    break;
                  }
                  case TAG_Just: {
                    V v_d_2474 = heff_field(v_t_2471, 0);
                    heff_take_n(v_t_2471, 1ULL, 1);
                    v_c_2475 = heff_tr(g_heff_2elsp_2elsp_2epublish_24s471405199x320951611(heff_get_n(v_d_2474, 0, 2), NTAG(TAG_Nil)));
                    break;
                  }
                  default: heff_nomatch(v_t_2471);
                  }
                  V f_ = v_c_2475;
                  heff_room[0] = v_hd_244;
                  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam8, 1, 3, (V[]){v_st_240, v_f_2421, v_k_245});
                  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                } else {
                  heff_drop(v_hd_244);
                  heff_drop(v_f_2421);
                  V f_ = v_k_245;
                  args[0] = v_st_240;
                  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                  return heff_tail(f_, 1, args);
                }
              }
            }
          }
        }
        default: return heff_nomatch(v_x_246);
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559_lam1, 1, 5, (V[]){v_m_241, v_st_240, v_hd_244, v_k_245, v_p_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_str0, 13, "textDocument/");
HEFF_LIT(g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_str1, 31, "workspace/didChangeWatchedFiles");
Clo g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_entry, 3, 0};

V g_heff_2elsp_2elsp_2enotification_24s270589690x602944811(V v_st_240, V v_m_241, V v_p_242) {
top: ;
  V v_t_245;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_m_241), MK_INT(0LL), MK_INT(13LL)), ((V)&g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_str0))) {
    v_t_245 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_st_240, 119ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib); heff_rfield(rr_, 3) = rv_3; rr_; });
  } else {
    if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_str1))) {
      v_t_245 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_st_240, 119ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      v_t_245 = v_st_240;
    }
  }
  HEFF_LAST return g_heff_2elsp_2elsp_2enotified_24s742146644x1822634559(v_t_245, v_m_241, v_p_242);
}
V g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enotification_24s270589690x602944811(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str2, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str3, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str4, 5, "error");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str5, 2, "id");
Clo g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_entry, 3, 0};

V g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(V v_id_240, V v_code_241, V v_msg_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str1)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_code_241})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str3), heff_tag_n(TAG_JString, 1, (V[]){v_msg_242})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str4), v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_str5), v_id_240}), v_t_248});
  V v_t_2410 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_249})});
  V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2410, 1); r_; });
  V v_a_2412 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
  return heff_tail(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
}
V g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_str1, 0, "");
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(v_p_241));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam0, 2, 2, (V[]){v_c_242, v_st_240});
}
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_d_2410 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2414 = heff_get_n(v_d_2410, 1, 2);
  V v_t_2415 = (g_map_2elookup_24s1546226666x2146984184(v_f_247, heff_rfield(v_x_2413, 1)));
  V v_x_2418;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    v_x_2418 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2413, v_text_2414, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_c_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_c_2416, 0)), heff_dup(v_text_2414))) {
      v_x_2418 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2413, v_text_2414, heff_get_n(v_c_2416, 1, 2)});
    } else {
      heff_drop_rec(v_c_2416, 2);
      v_x_2418 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2413, v_text_2414, NTAG(TAG_Nil)});
    }
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V f_ = v_k_244;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_d_2410 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2428 = heff_get_n(v_d_2410, 1, 2);
  V v_t_2429 = (g_map_2elookup_24s1546226666x2146984184(v_f_247, heff_rfield(v_x_2427, 1)));
  V v_x_2432;
  switch (heff_tag_of(v_t_2429)) {
  case TAG_Nothing: {
    v_x_2432 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2427, v_text_2428, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_c_2430 = heff_field(v_t_2429, 0);
    heff_take_n(v_t_2429, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_c_2430, 0)), heff_dup(v_text_2428))) {
      v_x_2432 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2427, v_text_2428, heff_get_n(v_c_2430, 1, 2)});
    } else {
      heff_drop_rec(v_c_2430, 2);
      v_x_2432 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2427, v_text_2428, NTAG(TAG_Nil)});
    }
    break;
  }
  default: heff_nomatch(v_t_2429);
  }
  V f_ = v_k_244;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    V v_t_246 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_str0), NTAG(TAG_Nil)});
    V f_ = v_k_244;
    args[0] = v_t_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    V v_t_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_f_247), heff_rfield(v_st_240, 0)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_hd_243);
      heff_drop(v_f_247);
      V v_t_249 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_str1), NTAG(TAG_Nil)});
      V f_ = v_k_244;
      args[0] = v_t_249;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_d_2410 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      V v_t_2411 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_f_247), heff_rfield(v_st_240, 1)));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        V v_c_2412 = (g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(v_st_240, heff_dup(v_f_247)));
        V f_ = v_c_2412;
        heff_room[0] = v_hd_243;
        heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam2, 1, 3, (V[]){v_d_2410, v_f_247, v_k_244});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      case TAG_Just: {
        V v_c_2419 = heff_field(v_t_2411, 0);
        heff_take_n(v_t_2411, 1ULL, 1);
        if (heff_strEq_c(heff_get_n(v_c_2419, 0, 2), heff_dup(heff_rfield(v_d_2410, 1)))) {
          heff_drop(v_hd_243);
          V v_text_2421 = heff_get_n(v_d_2410, 1, 2);
          V v_t_2422 = (g_map_2elookup_24s1546226666x2146984184(v_f_247, heff_rfield(v_st_240, 1)));
          V v_x_2425;
          switch (heff_tag_of(v_t_2422)) {
          case TAG_Nothing: {
            v_x_2425 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2421, NTAG(TAG_Nil)});
            break;
          }
          case TAG_Just: {
            V v_c_2423 = heff_field(v_t_2422, 0);
            heff_take_n(v_t_2422, 1ULL, 1);
            if (heff_strEq_c(heff_dup(heff_rfield(v_c_2423, 0)), heff_dup(v_text_2421))) {
              v_x_2425 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2421, heff_get_n(v_c_2423, 1, 2)});
            } else {
              heff_drop_rec(v_c_2423, 2);
              v_x_2425 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2421, NTAG(TAG_Nil)});
            }
            break;
          }
          default: heff_nomatch(v_t_2422);
          }
          V f_ = v_k_244;
          args[0] = v_x_2425;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        } else {
          V v_c_2426 = (g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(v_st_240, heff_dup(v_f_247)));
          V f_ = v_c_2426;
          heff_room[0] = v_hd_243;
          heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam3, 1, 3, (V[]){v_d_2410, v_f_247, v_k_244});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_lam1, 1, 3, (V[]){v_st_240, v_k_244, v_hd_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_lam0, 2, 0};
V g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_entry, 2, 0};

V g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_st_240, 7);
    return ((V)&g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(heff_dup(heff_rfield(v_st_240, 6)), heff_dup(v_f_244)));
    return heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_lam1, 2, 4, (V[]){v_c_246, v_st_240, v_rest_245, v_f_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_249, 0, 6), v_f_244});
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = (g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005(v_st_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_lam3, 1, 3, (V[]){v_x_249, v_f_244, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_lam2, 1, 5, (V[]){v_st_240, v_rest_245, v_hd_247, v_f_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_entry, 3, 0};

V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073(V v_read_240, V v_lib_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_lib_241);
    return ((V)&g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(heff_dup(v_read_240), heff_dup(v_lib_241), heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam1, 2, 4, (V[]){v_c_247, v_read_240, v_lib_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = (g_prelude_2e_2b_2b(heff_get_n(v_x_2410, 0, 5), v_x_2412));
  V f_ = v_k_249;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_lib_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = ({ V a_0 = v_read_240; V a_1 = v_lib_241; V a_2 = v_rest_246; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam3, 1, 2, (V[]){v_x_2410, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_lib_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073_lam2, 1, 5, (V[]){v_read_240, v_lib_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam0, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam3, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_entry, 5, 0};

V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346(V v_st_240, V v_root_241, V v_f_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProjectFiles, 2, (V[]){heff_dup(v_root_241), ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(v_t_247, heff_dup(v_hd_243), heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam1, 1, 5, (V[]){v_f_242, v_st_240, v_hd_243, v_root_241, v_k_244})));
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam0(V self, V *args) {
  V v_fs_245 = args[0];
  return v_fs_245;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam3(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_d_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2419);
  V v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2418, 1, 2)});
  V f_ = v_k_2420;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam2(V self, V *args) {
  V v_p_2412 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = ({ V a_0 = heff_dup(v_p_2412); V b_1 = heff_get_n(v_st_240, 0, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_p_2412, ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam3_clo)})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V f_ = ((V)&g_co_2eop_24s1084803226x1249263831_clo);
    args[0] = v_t_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_d_2418 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    heff_drop(v_p_2412);
    return heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam4, 2, 1, (V[]){v_d_2418});
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_root_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_sources_2424 = (g_heff_2elsp_2elsp_2enubSources(v_x_2423));
  V v_x_2425 = (g_list_2efoldl_24s1221316612x1915668835(NTAG(TAG_Nil), v_sources_2424));
  V v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_root__program, (V[]){v_root_241, heff_dup(v_x_2425)})});
  V v_t_2427 = ({ V rv_3 = v_t_2426; V rr_ = heff_rec_reuse_n(v_st_240, 119ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib); heff_rfield(rr_, 3) = rv_3; rr_; });
  V f_ = v_k_244;
  args[0] = heff_rec_n(2, shape_st__program, (V[]){v_t_2427, v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_242, NTAG(TAG_Nil)});
  V v_files_2410 = (g_prelude_2e_2b_2b(v_x_248, v_t_249));
  V v_t_2411 = (g_heff_2elsp_2elsp_2enubPaths(v_files_2410));
  V v_c_2422 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam2, 1, 1, (V[]){heff_dup(v_st_240)}); V a_1 = heff_dup(heff_rfield(v_st_240, 6)); V a_2 = v_t_2411; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  V f_ = v_c_2422;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346_lam5, 1, 3, (V[]){v_root_241, v_st_240, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_entry, 2, 0};

V g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215(V v_st_240, V v_f_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(heff_dup(heff_rfield(v_st_240, 6)), heff_dup(v_f_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_lam0, 2, 3, (V[]){v_c_242, v_st_240, v_f_241});
}
V g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_dup(heff_rfield(v_st_240, 3));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    return (g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346(v_st_240, heff_get_n(v_x_245, 0, 6), v_f_241, v_hd_243, v_k_244));
  }
  case TAG_Just: {
    V v_pr_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_pr_247, 0)), heff_dup(heff_rfield(v_x_245, 0)))) {
      heff_drop_rec(v_x_245, 6);
      heff_drop(v_f_241);
      heff_drop(v_hd_243);
      V v_t_249 = heff_rec_n(2, shape_st__program, (V[]){v_st_240, heff_get_n(v_pr_247, 1, 2)});
      V f_ = v_k_244;
      args[0] = v_t_249;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop_rec(v_pr_247, 2);
      return (g_heff_2elsp_2elsp_2eprojectAnew_24s2027470516x1170999346(v_st_240, heff_get_n(v_x_245, 0, 6), v_f_241, v_hd_243, v_k_244));
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_lam1, 1, 4, (V[]){v_st_240, v_f_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_entry, 2, 0};

V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_f_248 = heff_field(v_x21_245, 1);
      V v_c_249 = (g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215(v_st_240, heff_dup(v_f_248)));
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam1, 2, 2, (V[]){v_c_249, heff_dup(v_rest_246)});
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V v_t_244 = heff_rec_n(2, shape_st__program, (V[]){v_st_240, NTAG(TAG_Nil)});
  V f_ = v_k_243;
  args[0] = v_t_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_program_2415 = (g_prelude_2e_2b_2b(heff_get_n(v_x_2412, 1, 2), heff_take_field(v_x_2414, 1)));
  V v_t_2416 = ({ V rv_1 = v_program_2415; V rr_ = heff_rec_reuse_n(v_x_2414, 1ULL, 2, shape_st__program); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2411;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2413 = ({ V a_0 = heff_dup(heff_rfield(v_x_2412, 0)); V a_1 = v_rest_246; V r_ = (g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576(a_0, a_1)); heff_drop(v_rest_246); r_; });
  V f_ = v_c_2413;
  heff_room[0] = v_hd_2410;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam3, 1, 2, (V[]){v_x_2412, v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_lam2, 1, 3, (V[]){v_rest_246, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str1, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str2, 8, "location");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str3, 13, "containerName");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str4, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str5, 4, "name");
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam0, 1, 0};
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_entry, 3, 0};

V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041(V v_st_240, V v_c_241, V v_y_242) {
top: ;
  V v_p_243 = heff_dup(heff_rfield(v_c_241, 1));
  V v_t_244 = ({ V a_0 = heff_dup(v_p_243); V b_1 = heff_get_n(v_st_240, 0, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_c_2411;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_243, ((V)&g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam0_clo)})});
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    v_c_2411 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_247}));
    break;
  }
  case TAG_Just: {
    V v_d_248 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_p_243);
    v_c_2411 = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam1, 2, 1, (V[]){v_d_248});
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam2, 2, 3, (V[]){v_c_2411, v_y_242, v_c_241});
}
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam0(V self, V *args) {
  V v_u_245 = args[0];
  return v_u_245;
}
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_d_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_get_n(v_d_248, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_y_242 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_y_242, 0)});
  V v_t_2416 = heff_tag_n(TAG_JInt, 1, (V[]){heff_take_field(v_y_242, 1)});
  V v_t_2417 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_c_241, 0)});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str0), heff_tag_n(TAG_JString, 1, (V[]){v_x_2414})});
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str1), (g_heff_2elsp_2elsp_2erange(heff_get_n(v_c_241, 3, 13), heff_get_n(v_y_242, 3, 5)))});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str2), v_t_2421}), NTAG(TAG_Nil)});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str3), v_t_2417}), v_t_2422});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str4), v_t_2416}), v_t_2423});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_str5), v_t_2415}), v_t_2424});
  V v_x_2426 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_2425});
  V f_ = v_k_2413;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_y_242 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_lam3, 1, 3, (V[]){v_y_242, v_c_241, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_entry, 3, 0};

V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028(V v_st_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_c_241);
    return ((V)&g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam0_clo);
  }
  case TAG_Cons: {
    V v_y_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = (g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041(heff_dup(v_st_240), heff_dup(v_c_241), v_y_245));
    return heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam1, 2, 4, (V[]){v_c_247, v_st_240, v_c_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = (g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028(v_st_240, v_c_241, v_rest_246));
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam3, 1, 2, (V[]){v_k_249, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam2, 1, 5, (V[]){v_st_240, v_c_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_str0, 0, "");
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam0, 2, 0};
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_entry, 3, 0};

V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573(V v_st_240, V v_query_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_query_241);
    return ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_t_247 = (g_heff_2ebuild_2equery_2esymbols(heff_dup(v_c_245)));
    V v_t_2412 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam1, 1, 1, (V[]){heff_dup(v_query_241)}), v_t_247));
    V v_c_2413 = (g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028(heff_dup(v_st_240), heff_dup(v_c_245), v_t_2412));
    return heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam2, 2, 4, (V[]){v_c_2413, v_st_240, v_query_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam1(V self, V *args) {
  V v_y_248 = args[0];
  V v_query_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_s_249 = (g_heff_2elsp_2elsp_2elowerGo(heff_get_n(v_y_248, 0, 5), MK_INT(0LL), ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_str0)));
  V v_x3_2410 = (g_prelude_2eindexFrom(v_query_241, v_s_249, MK_INT(0LL)));
  switch (heff_tag_of(v_x3_2410)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_2410, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_2410);
  }
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2419 = (g_prelude_2e_2b_2b(v_x_2416, v_x_2418));
  V f_ = v_k_2415;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_query_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2414 = heff_env(self)[3];
  V v_k_2415 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2417 = ({ V a_0 = v_st_240; V a_1 = v_query_241; V a_2 = v_rest_246; V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_c_2417;
  heff_room[0] = v_hd_2414;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam4, 1, 2, (V[]){v_x_2416, v_k_2415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_query_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_lam3, 1, 5, (V[]){v_st_240, v_query_241, v_rest_246, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(heff_dup(v_p_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam0, 2, 3, (V[]){v_c_242, v_st_240, v_p_241});
}
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_f_247 = heff_env(self)[0];
  V v_d_2410 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2413 = (g_heff_2elsp_2elsp_2etargetIn(heff_take_field(v_x_2412, 0), v_f_247, v_d_2410, v_p_241, heff_get_n(v_x_2412, 1, 2)));
  V f_ = v_k_244;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_p_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    heff_drop(v_p_241);
    V v_t_246 = heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
    V f_ = v_k_244;
    args[0] = v_t_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    V v_t_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_f_247), heff_rfield(v_st_240, 0)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_hd_243);
      heff_drop(v_p_241);
      heff_drop(v_f_247);
      V v_t_249 = heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
      V f_ = v_k_244;
      args[0] = v_t_249;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_d_2410 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      V v_c_2411 = (g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215(v_st_240, heff_dup(v_f_247)));
      V f_ = v_c_2411;
      heff_room[0] = v_hd_243;
      heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam2, 1, 4, (V[]){v_f_247, v_d_2410, v_p_241, v_k_244});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam1, 1, 4, (V[]){v_st_240, v_k_244, v_hd_243, v_p_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_str1, 5, "range");
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam0, 1, 0};
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_entry, 2, 0};

V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873(V v_st_240, V v_o_241) {
top: ;
  V v_p_242 = heff_dup(heff_rfield(v_o_241, 0));
  V v_t_243 = ({ V a_0 = heff_dup(v_p_242); V b_1 = heff_get_n(v_st_240, 0, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_c_2410;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_242, ((V)&g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam0_clo)})});
    V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    v_c_2410 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_246}));
    break;
  }
  case TAG_Just: {
    V v_d_247 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_p_242);
    v_c_2410 = heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam1, 2, 1, (V[]){v_d_247});
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam2, 2, 2, (V[]){v_c_2410, v_o_241});
}
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam0(V self, V *args) {
  V v_u_244 = args[0];
  return v_u_244;
}
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_get_n(v_d_247, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_o_241 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_str0), heff_tag_n(TAG_JString, 1, (V[]){v_x_2413})});
  V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_str1), (g_heff_2elsp_2elsp_2erange(heff_dup(heff_rfield(v_o_241, 1)), heff_get_n(v_o_241, 2, 4)))});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  V v_x_2417 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2416})});
  V f_ = v_k_2412;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_o_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2410;
  args[0] = v_hd_2411;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam3, 1, 2, (V[]){v_o_241, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam0, 2, 0};
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_entry, 2, 0};

V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    return ((V)&g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873(heff_dup(v_st_240), v_o_244));
    return heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam1, 2, 3, (V[]){v_c_246, v_st_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104(v_st_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam3, 1, 2, (V[]){v_k_248, v_x_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_lam2, 1, 4, (V[]){v_st_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str4, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str5, 21, "` is not written here");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str6, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str7, 11, "placeholder");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str8, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str9, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str10, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str11, 2, "id");
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam4(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_entry, 4, 0};

V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574(V v_id_240, V v_tg_241, V v_z_242, V v_z_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_tg_241, 2));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str1)})});
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str2), NTAG(TAG_JNull)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str3), v_id_240}), v_t_247});
    V v_t_249 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_248})});
    V v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_249, 1); r_; });
    V v_a_2411 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam0, 1, 2, (V[]){v_z_243, v_tg_241})));
  }
  case TAG_Just: {
    V v_t_2414 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_2415 = (g_heff_2ebuild_2equery_2erenameRefused(heff_dup(heff_rfield(v_t_2414, 1)), heff_dup(heff_rfield(v_t_2414, 2)), heff_dup(heff_rfield(v_t_2414, 2))));
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      V v_off_2416 = heff_dup(heff_rfield(v_tg_241, 1));
      V v_t_2422 = (g_list_2efind(heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam1, 1, 2, (V[]){heff_dup(v_t_2414), v_off_2416}), heff_rfield(v_t_2414, 3)));
      switch (heff_tag_of(v_t_2422)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24t_244_24Just, 1);
        V v_t_2423 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str4), heff_strAppend(heff_get_n(v_t_2414, 2, 4), ((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str5)));
        V v_c_2424 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(v_id_240, MK_INT(-32803LL), v_t_2423));
        return heff_tail(v_c_2424, 2, (V[]){v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam2, 1, 2, (V[]){v_z_243, v_tg_241})});
      }
      case TAG_Just: {
        V v_o_2426 = heff_field(v_t_2422, 0);
        V v_ru_24t_2422_24Just = heff_take_reuse_n(v_t_2422, 1ULL, 1);
        V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str6), (g_heff_2elsp_2elsp_2erange(heff_dup(heff_rfield(v_o_2426, 1)), heff_get_n(v_o_2426, 2, 4)))});
        V v_t_2428 = heff_tag_at_n(v_ru_24t_244_24Just, TAG_JString, 1, (V[]){heff_get_n(v_t_2414, 2, 4)});
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str7), v_t_2428}), NTAG(TAG_Nil)});
        V v_result_2430 = heff_tag_at_n(v_ru_24t_2422_24Just, TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2429})});
        V v_t_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str8), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str9)})});
        V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str10), v_result_2430}), NTAG(TAG_Nil)});
        V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_str11), v_id_240}), v_t_2432});
        V v_t_2434 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, v_t_2433})});
        V v_t_2435 = ({ V a_0 = v_t_2434; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2434, 1); r_; });
        V v_a_2436 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2435, NTAG(TAG_MkUnit)});
        V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2436})});
        return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam3, 1, 2, (V[]){v_z_243, v_tg_241})));
      }
      default: return heff_nomatch(v_t_2422);
      }
    }
    case TAG_Just: {
      V v_why_2439 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop_rec(v_t_2414, 4);
      heff_drop_cell(v_ru_24t_244_24Just, 1);
      V v_c_2440 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(v_id_240, MK_INT(-32803LL), v_why_2439));
      return heff_tail(v_c_2440, 2, (V[]){v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam4, 1, 2, (V[]){v_z_243, v_tg_241})});
    }
    default: return heff_nomatch(v_t_2415);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2413);
  V f_ = v_z_243;
  args[0] = heff_get_n(v_tg_241, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam1(V self, V *args) {
  V v_o_2417 = args[0];
  V v_t_2414 = heff_env(self)[0];
  V v_off_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_o_2417, 0)), heff_get_n(v_t_2414, 0, 4))) {
    V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_o_2417, 2)), 0, 2);
    if (heff_intLe_c(v_t_2419, heff_dup(v_off_2416))) {
      V v_t_2421 = heff_get_n(heff_get_n(v_o_2417, 2, 4), 1, 2);
      return heff_intLe(v_off_2416, v_t_2421);
    } else {
      heff_drop_rec(v_o_2417, 4);
      heff_drop(v_off_2416);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop_rec(v_o_2417, 4);
    heff_drop(v_off_2416);
    return NTAG(TAG_False);
  }
}
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2425);
  V f_ = v_z_243;
  args[0] = heff_get_n(v_tg_241, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam3(V self, V *args) {
  V v_x_2438 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2438);
  V f_ = v_z_243;
  args[0] = heff_get_n(v_tg_241, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_tg_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2441);
  V f_ = v_z_243;
  args[0] = heff_get_n(v_tg_241, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam9(V self, V *args); static Clo g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam9, 1, 0};
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam14(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_entry, 3, 0};

V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555(V v_st_240, V v_t_241, V v_new_242) {
top: ;
  V v_c_243 = (g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_241, 0))));
  return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam0, 2, 4, (V[]){v_c_243, v_t_241, v_new_242, v_st_240});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam3(V self, V *args) {
  V v_o_2411 = args[0];
  V v_p_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_o_2411, 0, 4), v_p_2410);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam2(V self, V *args) {
  V v_p_2410 = args[0];
  V v_os_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2412 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam3, 1, 1, (V[]){heff_dup(v_p_2410)}), v_os_247));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2410, v_os_2412});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam6(V self, V *args) {
  V v_o_2422 = args[0];
  V v_p_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_o_2422, 0, 4), v_p_2421);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam5(V self, V *args) {
  V v_p_2421 = args[0];
  V v_os_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2423 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam6, 1, 1, (V[]){heff_dup(v_p_2421)}), v_os_2418));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2421, v_os_2423});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam7(V self, V *args) {
  V v_b_2425 = args[0];
  V v_new_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_b_2425, 0)), (g_heff_2elsp_2elsp_2erenamedText(v_new_242, heff_get_n(v_b_2425, 1, 2)))});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam8(V self, V *args) {
  V v_q_2427 = args[0];
  V v_p_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430;
  switch (heff_tag_of(v_q_2427)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_field(v_q_2427, 0);
    heff_take_n(v_q_2427, 1ULL, 2);
    v_t_2430 = v_x_2428;
    break;
  }
  default: heff_nomatch(v_q_2427);
  }
  return heff_strEq(v_t_2430, v_p_2417);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam9(V self, V *args) {
  V v_t_2433 = args[0];
  return v_t_2433;
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam10(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_d_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2438);
  V v_t_2440 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2437, 1, 2)});
  V f_ = v_k_2439;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam11(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_txt_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2445);
  V f_ = v_k_2446;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_txt_2444});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam4(V self, V *args) {
  V v_p_2417 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_new_242 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_os_2418 = heff_get_n(v_t_241, 3, 4);
  V v_t_2419 = (g_list_2emap_24s1120421688x983574011(heff_dup(v_os_2418)));
  V v_t_2420 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2419));
  V v_t_2424 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam5, 1, 1, (V[]){v_os_2418}), v_t_2420));
  V v_texts_2426 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam7, 1, 1, (V[]){v_new_242}), v_t_2424));
  V v_t_2431 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam8, 1, 1, (V[]){heff_dup(v_p_2417)}); V a_1 = v_texts_2426; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_texts_2426); r_; });
  switch (heff_tag_of(v_t_2431)) {
  case TAG_Nothing: {
    V v_t_2432 = ({ V a_0 = heff_dup(v_p_2417); V b_1 = heff_get_n(v_st_240, 0, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nothing: {
      V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_p_2417, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam9_clo)})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V f_ = ((V)&g_co_2eop_24s1084803226x1249263831_clo);
      args[0] = v_t_2436;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_d_2437 = heff_field(v_t_2432, 0);
      heff_take_n(v_t_2432, 1ULL, 1);
      heff_drop(v_p_2417);
      return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam10, 2, 1, (V[]){v_d_2437});
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  case TAG_Just: {
    V v_q_2441 = heff_field(v_t_2431, 0);
    heff_take_n(v_t_2431, 1ULL, 1);
    heff_drop(v_p_2417);
    heff_drop_rec(v_st_240, 7);
    V v_txt_2444;
    switch (heff_tag_of(v_q_2441)) {
    case TAG_MkPair: {
      V v_y_2443 = heff_field(v_q_2441, 1);
      heff_take_n(v_q_2441, 2ULL, 2);
      v_txt_2444 = v_y_2443;
      break;
    }
    default: heff_nomatch(v_q_2441);
    }
    return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam11, 2, 1, (V[]){v_txt_2444});
  }
  default: return heff_nomatch(v_t_2431);
  }
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam13(V self, V *args) {
  V v_c_2451 = args[0];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2452 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_2451, 1, 13)}));
  return ({ V a_0 = v_t_2452; V a_1 = v_x_2415; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_x_2415); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam14(V self, V *args) {
  V v_c_2456 = args[0];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2457 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_2456, 1, 13)}));
  return ({ V a_0 = v_t_2457; V a_1 = v_x_2415; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_x_2415); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam12(V self, V *args) {
  V v_x_2448 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_new_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_sources_2449 = (g_heff_2elsp_2elsp_2enubSources(v_x_2448));
  V v_x_2450 = (g_list_2efoldl_24s1221316612x1915668835(NTAG(TAG_Nil), v_sources_2449));
  V v_program_2453 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam13, 1, 1, (V[]){heff_dup(v_x_2415)}), heff_dup(heff_rfield(v_x_246, 1))));
  V v_t_2454 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_2453));
  V v_t_2455 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2454; V r_ = (g_list_2efoldl_24s844754919x2100408598(a_0, a_1, a_2, a_3)); heff_drop(v_t_2454); r_; });
  V v_program_2458 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam14, 1, 1, (V[]){v_x_2415}), heff_dup(v_x_2450)));
  V v_t_2459 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_2458));
  V v_t_2460 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2459; V r_ = (g_list_2efoldl_24s844754919x2100408598(a_0, a_1, a_2, a_3)); heff_drop(v_t_2459); r_; });
  V v_x_2461 = (g_heff_2elsp_2elsp_2erenameVerdict(v_x_246, v_t_241, v_new_242, v_t_2455, v_t_2460, v_x_2450));
  V f_ = v_k_245;
  args[0] = v_x_2461;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_new_242 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_os_247 = heff_dup(heff_rfield(v_t_241, 3));
  V v_t_248 = (g_list_2emap_24s1120421688x983574011(heff_dup(v_os_247)));
  V v_t_249 = (g_heff_2elsp_2elsp_2enubPaths(v_t_248));
  V v_t_2413 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam2, 1, 1, (V[]){v_os_247}), v_t_249));
  V v_t_2414 = (g_list_2emap_24s434052990x93204247(v_t_2413));
  V v_x_2415 = ({ V a_0 = v_t_2414; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(heff_rfield(v_x_246, 1)); V r_ = (g_heff_2elsp_2elsp_2eaffectedGo(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_heff_2elsp_2elsp_2enubPaths(heff_dup(v_x_2415)));
  V v_c_2447 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam4, 1, 3, (V[]){heff_dup(v_t_241), heff_dup(v_new_242), heff_dup(v_st_240)}); V a_1 = heff_get_n(v_st_240, 6, 7); V a_2 = v_t_2416; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s2061268164x1814995073(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
  V f_ = v_c_2447;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam12, 1, 5, (V[]){v_x_2415, v_x_246, v_t_241, v_new_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555_lam1, 1, 5, (V[]){v_t_241, v_new_242, v_st_240, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_str0, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_str1, 7, "newText");
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam0, 2, 0};
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam1, 1, 0};
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_entry, 3, 0};

V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266(V v_st_240, V v_new_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_st_240, 7);
    heff_drop(v_new_241);
    return ((V)&g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam0_clo);
  }
  case TAG_Cons: {
    V v_b_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_p_247 = heff_dup(heff_rfield(v_b_245, 0));
    V v_t_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_p_247), heff_rfield(v_st_240, 0)));
    V v_c_2415;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_PathUri, 2, (V[]){v_p_247, ((V)&g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam1_clo)})});
      V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      v_c_2415 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2411}));
      break;
    }
    case TAG_Just: {
      V v_d_2412 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_p_247);
      v_c_2415 = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam2, 2, 1, (V[]){v_d_2412});
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    return heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam3, 2, 5, (V[]){v_c_2415, v_st_240, v_new_241, v_rest_246, v_b_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam1(V self, V *args) {
  V v_u_249 = args[0];
  return v_u_249;
}
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_d_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_get_n(v_d_2412, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam6(V self, V *args) {
  V v_o_2421 = args[0];
  V v_new_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_str0), (g_heff_2elsp_2elsp_2erange(heff_dup(heff_rfield(v_o_2421, 1)), heff_get_n(v_o_2421, 2, 4)))});
  V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_str1), heff_tag_n(TAG_JString, 1, (V[]){v_new_241})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2424})});
}
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_new_241 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_k_2417 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2425 = heff_tag_n(TAG_JArray, 1, (V[]){(g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam6, 1, 1, (V[]){v_new_241}), heff_get_n(v_b_245, 1, 2)))});
  V v_x_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2418, v_t_2425}), v_x_2420});
  V f_ = v_k_2417;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_new_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2416 = heff_env(self)[3];
  V v_b_245 = heff_env(self)[4];
  V v_k_2417 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2419 = (g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266(v_st_240, heff_dup(v_new_241), v_rest_246));
  V f_ = v_c_2419;
  heff_room[0] = v_hd_2416;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam5, 1, 4, (V[]){v_new_241, v_b_245, v_x_2418, v_k_2417});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_new_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_b_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266_lam4, 1, 6, (V[]){v_st_240, v_new_241, v_rest_246, v_hd_2416, v_b_245, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str6, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str7, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str8, 2, "id");
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam7(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_entry, 5, 0};

V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918(V v_id_240, V v_new_241, V v_tg_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_tg_242, 2));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_new_241);
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str1)})});
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str2), NTAG(TAG_JNull)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str3), v_id_240}), v_t_248});
    V v_t_2410 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_249})});
    V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2410, 1); r_; });
    V v_a_2412 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam0, 1, 2, (V[]){v_z_244, v_tg_242})));
  }
  case TAG_Just: {
    V v_t_2415 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_2416 = (g_heff_2ebuild_2equery_2erenameRefused(heff_dup(heff_rfield(v_t_2415, 1)), heff_dup(heff_rfield(v_t_2415, 2)), heff_dup(v_new_241)));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      V v_c_2417 = (g_heff_2elsp_2elsp_2erenameChecked_24s135359643x1924097555(heff_get_n(v_tg_242, 0, 3), heff_dup(v_t_2415), heff_dup(v_new_241)));
      return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam1, 1, 5, (V[]){v_t_2415, v_new_241, v_z_243, v_id_240, v_z_244})});
    }
    case TAG_Just: {
      V v_why_2454 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      heff_drop(v_new_241);
      heff_drop_rec(v_t_2415, 4);
      V v_c_2455 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(v_id_240, MK_INT(-32803LL), v_why_2454));
      return heff_tail(v_c_2455, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam7, 1, 2, (V[]){v_z_244, v_tg_242})});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V f_ = v_z_244;
  args[0] = heff_get_n(v_tg_242, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam3(V self, V *args) {
  V v_o_2429 = args[0];
  V v_p_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_o_2429, 0, 4), v_p_2428);
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam2(V self, V *args) {
  V v_p_2428 = args[0];
  V v_os_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2430 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam3, 1, 1, (V[]){heff_dup(v_p_2428)}), v_os_2425));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2428, v_os_2430});
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  V v_x_2447;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkPair: {
    V v_x_2445 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 2);
    v_x_2447 = v_x_2445;
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_z_244;
  args[0] = v_x_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_id_240 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2434 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str4), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str5)})});
  V v_t_2435 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str6), heff_tag_n(TAG_JObject, 1, (V[]){v_x_2433})});
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
  V v_t_2437 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str7), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
  V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_str8), v_id_240}), v_t_2438});
  V v_t_2440 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_t_2439})});
  V v_t_2441 = ({ V a_0 = v_t_2440; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2440, 1); r_; });
  V v_a_2442 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2441, NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2442})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam5, 1, 2, (V[]){v_x_2418, v_z_244})));
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam6(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2450);
  V v_x_2453;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 2);
    v_x_2453 = v_x_2451;
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_z_244;
  args[0] = v_x_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_t_2415 = heff_env(self)[0];
  V v_new_241 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_id_240 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2421;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkPair: {
    V v_y_2420 = heff_dup(heff_field(v_x_2418, 1));
    v_t_2421 = v_y_2420;
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nothing: {
    V v_t_2424;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_dup(heff_field(v_x_2418, 0));
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    V v_os_2425 = heff_get_n(v_t_2415, 3, 4);
    V v_t_2426 = (g_list_2emap_24s1120421688x983574011(heff_dup(v_os_2425)));
    V v_t_2427 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2426));
    V v_t_2431 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam2, 1, 1, (V[]){v_os_2425}), v_t_2427));
    V v_c_2432 = (g_heff_2elsp_2elsp_2echangesOf_24s43355038x1683815266(v_t_2424, v_new_241, v_t_2431));
    V f_ = v_c_2432;
    heff_room[0] = heff_dup(v_z_243);
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam4, 1, 4, (V[]){v_id_240, v_z_243, v_x_2418, v_z_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_why_2448 = heff_field(v_t_2421, 0);
    heff_take_n(v_t_2421, 1ULL, 1);
    heff_drop_rec(v_t_2415, 4);
    heff_drop(v_new_241);
    V v_c_2449 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(v_id_240, MK_INT(-32803LL), v_why_2448));
    V f_ = v_c_2449;
    heff_room[0] = v_z_243;
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam6, 1, 2, (V[]){v_x_2418, v_z_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_lam7(V self, V *args) {
  V v_x_2456 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2456);
  V f_ = v_z_244;
  args[0] = heff_get_n(v_tg_242, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str6, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str7, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str8, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str9, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str10, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str11, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str12, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str13, 2, "id");
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_entry, 6, 0};

V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126(V v_st_240, V v_id_241, V v_d_242, V v_fix_243, V v_z_244, V v_z_245) {
top: ;
  V v_src_246 = heff_dup(heff_rfield(v_d_242, 1));
  V v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(v_fix_243, heff_dup(v_src_246)));
  V v_t_2414;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Left: {
    V v_why_248 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24Left = heff_take_reuse_n(v_t_247, 1ULL, 1);
    heff_drop(v_src_246);
    v_t_2414 = heff_tag_at_n(v_ru_24t_247_24Left, TAG_Left, 1, (V[]){v_why_248});
    break;
  }
  case TAG_Right: {
    V v_out_249 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_t_2410 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_246), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2411 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2410));
    V v_t_2412 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_out_249), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2413 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2412));
    v_t_2414 = (g_heff_2esyntax_2eformat_2esameMeaning(v_src_246, v_out_249, v_t_2411, v_t_2413));
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Left: {
    V v_ru_24t_2414_24Left = heff_take_reuse_n(v_t_2414, 0ULL, 1);
    heff_drop_rec(v_d_242, 2);
    V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str0), heff_tag_at_n(v_ru_24t_2414_24Left, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str1)})});
    V v_t_2417 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str2), v_t_2417}), NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str3), v_id_241}), v_t_2418});
    V v_t_2420 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2419})});
    V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2420, 1); r_; });
    V v_a_2422 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2421, NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2422})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam0, 1, 2, (V[]){v_z_245, v_st_240})));
  }
  case TAG_Right: {
    V v_t_2425 = heff_field(v_t_2414, 0);
    V v_ru_24t_2414_24Right = heff_take_reuse_n(v_t_2414, 1ULL, 1);
    if (heff_strEq_c(heff_dup(v_t_2425), heff_dup(heff_rfield(v_d_242, 1)))) {
      heff_drop_rec(v_d_242, 2);
      heff_drop(v_t_2425);
      V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str4), heff_tag_at_n(v_ru_24t_2414_24Right, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str5)})});
      V v_t_2428 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str6), v_t_2428}), NTAG(TAG_Nil)});
      V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str7), v_id_241}), v_t_2429});
      V v_t_2431 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2430})});
      V v_t_2432 = ({ V a_0 = v_t_2431; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2431, 1); r_; });
      V v_a_2433 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2432, NTAG(TAG_MkUnit)});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2433})});
      return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam1, 1, 2, (V[]){v_z_245, v_st_240})));
    } else {
      V v_t_2436 = heff_strLength(heff_dup(heff_rfield(v_d_242, 1)));
      V v_t_2437 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str8), (g_heff_2elsp_2elsp_2erange(heff_get_n(v_d_242, 1, 2), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), v_t_2436})))});
      V v_t_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str9), heff_tag_at_n(v_ru_24t_2414_24Right, TAG_JString, 1, (V[]){v_t_2425})});
      V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
      V v_t_2440 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
      V v_result_2442 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_2441});
      V v_t_2443 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str10), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str11)})});
      V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str12), v_result_2442}), NTAG(TAG_Nil)});
      V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_str13), v_id_241}), v_t_2444});
      V v_t_2446 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, v_t_2445})});
      V v_t_2447 = ({ V a_0 = v_t_2446; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2446, 1); r_; });
      V v_a_2448 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2447, NTAG(TAG_MkUnit)});
      V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2448})});
      return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam2, 1, 2, (V[]){v_z_245, v_st_240})));
    }
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam0(V self, V *args) {
  V v_x_2424 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2424);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam1(V self, V *args) {
  V v_x_2435 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126_lam2(V self, V *args) {
  V v_x_2450 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2450);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str6, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str7, 2, "id");
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam5, 1, 0};
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_entry, 3, 0};

V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493(V v_st_240, V v_id_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(v_p_242));
  return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam0, 2, 3, (V[]){v_c_243, v_id_241, v_st_240});
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam5(V self, V *args) {
  V v_t_2430 = args[0];
  return v_t_2430;
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam6(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_d_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2435);
  V v_t_2437 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2434, 1, 2)});
  V f_ = v_k_2436;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam4(V self, V *args) {
  V v_q_2428 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = ({ V a_0 = heff_dup(v_q_2428); V b_1 = heff_get_n(v_st_240, 0, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_2429)) {
  case TAG_Nothing: {
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_q_2428, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam5_clo)})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V f_ = ((V)&g_co_2eop_24s1084803226x1249263831_clo);
    args[0] = v_t_2433;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_d_2434 = heff_field(v_t_2429, 0);
    heff_take_n(v_t_2429, 1ULL, 1);
    heff_drop(v_q_2428);
    return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam6, 2, 1, (V[]){v_d_2434});
  }
  default: return heff_nomatch(v_t_2429);
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_id_241 = heff_env(self)[1];
  V v_d_2427 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2440 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2439, 0, 5)));
  return (g_heff_2elsp_2elsp_2eformattedIn_24s1574141169x1346217126(v_st_240, v_id_241, v_d_2427, v_t_2440, v_hd_244, v_k_245));
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_id_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str1)})});
    V v_t_248 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str2), v_t_248}), NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str3), v_id_241}), v_t_249});
    V v_t_2411 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2410})});
    V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2411, 1); r_; });
    V v_a_2413 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam2, 1, 2, (V[]){v_k_245, v_st_240})));
  }
  case TAG_Just: {
    V v_f_2416 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
    V v_t_2417 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_f_2416), heff_rfield(v_st_240, 0)));
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nothing: {
      heff_drop(v_f_2416);
      V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str4), heff_tag_at_n(v_ru_24x_246_24Just, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str5)})});
      V v_t_2419 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
      V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str6), v_t_2419}), NTAG(TAG_Nil)});
      V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_str7), v_id_241}), v_t_2420});
      V v_t_2422 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2421})});
      V v_t_2423 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2422, 1); r_; });
      V v_a_2424 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2423, NTAG(TAG_MkUnit)});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2424})});
      return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam3, 1, 2, (V[]){v_k_245, v_st_240})));
    }
    case TAG_Just: {
      V v_d_2427 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x_246_24Just, 1);
      V v_c_2438 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1596557770x734764569(heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam4, 1, 1, (V[]){heff_dup(v_st_240)}), heff_dup(heff_rfield(v_st_240, 6)), v_f_2416));
      V f_ = v_c_2438;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam7, 1, 5, (V[]){v_st_240, v_id_241, v_d_2427, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_id_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_lam1, 1, 4, (V[]){v_id_241, v_hd_244, v_k_245, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str0, 10, "initialize");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str1, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str2, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str3, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str4, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str5, 19, "dynamicRegistration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str6, 9, "workspace");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str7, 21, "didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str8, 12, "capabilities");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str9, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str10, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str11, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str12, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str13, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str14, 18, "textDocument/hover");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str15, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str16, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str17, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str18, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str19, 23, "textDocument/definition");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str20, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str21, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str22, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str23, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str24, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str25, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str26, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str27, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str28, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str29, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str30, 23, "textDocument/completion");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str31, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str32, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str33, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str34, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str35, 27, "textDocument/documentSymbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str36, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str37, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str38, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str39, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str40, 16, "workspace/symbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str41, 5, "query");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str42, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str43, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str44, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str45, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str46, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str47, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str48, 23, "textDocument/references");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str49, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str50, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str51, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str52, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str53, 18, "includeDeclaration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str54, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str55, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str56, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str57, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str58, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str59, 26, "textDocument/prepareRename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str60, 19, "textDocument/rename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str61, 7, "newName");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str62, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str63, 23, "textDocument/formatting");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str64, 10, "no method ");
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam9(V self, V *args); static Clo g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam9, 1, 0};
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam16(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam15(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam14(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam19(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam20(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam18(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam17(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam25(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam24(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam23(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam22(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam21(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam28(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam30(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam29(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam31(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam27(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam26(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam33(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam32(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam35(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam34(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam37(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam36(V self, V *args);
Clo g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_entry, 4, 0};

V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277(V v_st_240, V v_m_241, V v_id_242, V v_p_243) {
top: ;
  if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str0))) {
    heff_drop(v_m_241);
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str1), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str2)})});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str3), heff_dup(g_heff_2elsp_2elsp_2ecapabilities_get())}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str4), v_id_242}), v_t_246});
    V v_t_248 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
    V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_248, 1); r_; });
    V v_a_2410 = heff_tag_n(TAG_Send, 2, (V[]){v_t_249, NTAG(TAG_MkUnit)});
    return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam0, 2, 3, (V[]){v_a_2410, v_p_243, v_st_240});
  } else {
    if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str9))) {
      heff_drop(v_m_241);
      heff_drop(v_p_243);
      V v_t_2430 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str10), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str11)})});
      V v_t_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str12), NTAG(TAG_JNull)});
      V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
      V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str13), v_id_242}), v_t_2432});
      V v_t_2434 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, v_t_2433})});
      V v_t_2435 = ({ V a_0 = v_t_2434; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2434, 1); r_; });
      V v_a_2436 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2435, NTAG(TAG_MkUnit)});
      return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam2, 2, 2, (V[]){v_a_2436, v_st_240});
    } else {
      if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str14))) {
        heff_drop(v_m_241);
        V v_c_2443 = (g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(v_st_240, heff_dup(v_p_243)));
        return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam4, 2, 3, (V[]){v_c_2443, v_p_243, v_id_242});
      } else {
        if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str19))) {
          heff_drop(v_m_241);
          V v_c_2457 = (g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(v_st_240, heff_dup(v_p_243)));
          return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam7, 2, 3, (V[]){v_c_2457, v_p_243, v_id_242});
        } else {
          if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str30))) {
            heff_drop(v_m_241);
            V v_c_2499 = (g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(v_st_240, heff_dup(v_p_243)));
            return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam14, 2, 3, (V[]){v_c_2499, v_p_243, v_id_242});
          } else {
            if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str35))) {
              heff_drop(v_m_241);
              V v_c_24119 = (g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(v_st_240, v_p_243));
              return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam17, 2, 2, (V[]){v_c_24119, v_id_242});
            } else {
              if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str40))) {
                heff_drop(v_m_241);
                V v_t_24139 = (g_map_2etoListOnto(heff_rfield(v_st_240, 0), NTAG(TAG_Nil)));
                V v_t_24140 = (g_list_2emap_24s1415906091x1371825187(v_t_24139));
                V v_c_24141 = (g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005(heff_dup(v_st_240), v_t_24140));
                return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam21, 2, 4, (V[]){v_c_24141, v_st_240, v_p_243, v_id_242});
              } else {
                if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str48))) {
                  heff_drop(v_m_241);
                  V v_c_24174 = (g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799(v_st_240, heff_dup(v_p_243)));
                  return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam26, 2, 3, (V[]){v_c_24174, v_id_242, v_p_243});
                } else {
                  if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str59))) {
                    heff_drop(v_m_241);
                    V v_c_24217 = (g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799(v_st_240, v_p_243));
                    return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam32, 2, 2, (V[]){v_c_24217, v_id_242});
                  } else {
                    if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str60))) {
                      heff_drop(v_m_241);
                      V v_c_24222 = (g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799(v_st_240, heff_dup(v_p_243)));
                      return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam34, 2, 3, (V[]){v_c_24222, v_p_243, v_id_242});
                    } else {
                      if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str63))) {
                        heff_drop(v_m_241);
                        return (g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493(v_st_240, v_id_242, v_p_243));
                      } else {
                        heff_drop(v_p_243);
                        V v_c_24239 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(v_id_242, MK_INT(-32601LL), heff_strAppend(((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str64), v_m_241)));
                        return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam36, 2, 2, (V[]){v_c_24239, v_st_240});
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str5), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str7), v_t_2415})});
  V v_it_2417 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str8), v_t_2416}); V a_1 = v_p_243; V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_2425;
  switch (heff_tag_of(v_it_2417)) {
  case TAG_Nothing: {
    v_x2_2425 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_2418 = heff_field(v_it_2417, 0);
    V v_ru_24it_2417_24Just = heff_take_reuse_n(v_it_2417, 1ULL, 1);
    switch (heff_tag_of(v_it1_2418)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_2417_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      V v_b_2419 = heff_field(v_it1_2418, 0);
      heff_take_n(v_it1_2418, 1ULL, 1);
      v_x2_2425 = heff_tag_at_n(v_ru_24it_2417_24Just, TAG_Just, 1, (V[]){v_b_2419});
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_2418, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2417_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_2418, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2417_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_it1_2418, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2417_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_2418, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2417_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_2418, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2417_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_2418);
    }
    break;
  }
  default: heff_nomatch(v_it_2417);
  }
  V v_w_2427;
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_Nothing: {
    v_w_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    heff_take_n(v_x2_2425, 1ULL, 1);
    v_w_2427 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_x2_2425);
  }
  V v_t_2428 = ({ V rv_4 = v_w_2427; V rr_ = heff_rec_reuse_n(v_st_240, 111ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib); heff_rfield(rr_, 4) = rv_4; rr_; });
  V f_ = v_k_2412;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_a_2410 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), v_hd_2411, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam1, 1, 3, (V[]){v_p_243, v_st_240, v_k_2412})));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam3(V self, V *args) {
  V v_x_2440 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2440);
  V v_t_2441 = ({ V rv_5 = NTAG(TAG_True); V rr_ = heff_rec_reuse_n(v_st_240, 95ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib); heff_rfield(rr_, 5) = rv_5; rr_; });
  V f_ = v_k_2438;
  args[0] = v_t_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam2(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_a_2436 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2436})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_hd_2437, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam3, 1, 2, (V[]){v_st_240, v_k_2438})));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam6(V self, V *args) {
  V v_x_2455 = args[0];
  V v_k_2445 = heff_env(self)[0];
  V v_x_2446 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2455);
  V f_ = v_k_2445;
  args[0] = heff_get_n(v_x_2446, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam5(V self, V *args) {
  V v_x_2446 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_2444 = heff_env(self)[2];
  V v_k_2445 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_result_2447 = (g_heff_2elsp_2elsp_2ehoverOf(heff_dup(v_x_2446), v_p_243));
  V v_t_2448 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str15), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str16)})});
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str17), v_result_2447}), NTAG(TAG_Nil)});
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str18), v_id_242}), v_t_2449});
  V v_t_2451 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, v_t_2450})});
  V v_t_2452 = ({ V a_0 = v_t_2451; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2451, 1); r_; });
  V v_a_2453 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2452, NTAG(TAG_MkUnit)});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2453})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), v_hd_2444, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam6, 1, 2, (V[]){v_k_2445, v_x_2446})));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam4(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_c_2443 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2443;
  args[0] = heff_dup(v_hd_2444);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam5, 1, 4, (V[]){v_p_243, v_id_242, v_hd_2444, v_k_2445});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam9(V self, V *args) {
  V v_u_2475 = args[0];
  return v_u_2475;
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam10(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  V v_d_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2479);
  V f_ = v_k_2480;
  args[0] = heff_get_n(v_d_2478, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam12(V self, V *args) {
  V v_x_2484 = args[0];
  V v_d_2471 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_2482 = heff_env(self)[2];
  V v_k_2483 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2485 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str24), heff_tag_n(TAG_JString, 1, (V[]){v_x_2484})});
  V v_t_2486 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str25), (g_heff_2elsp_2elsp_2erange(heff_dup(heff_rfield(v_d_2471, 1)), heff_get_n(v_d_2471, 2, 3)))});
  V v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2486, NTAG(TAG_Nil)});
  V v_result_2488 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2485, v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str26), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str27)})});
  V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str28), v_result_2488}), NTAG(TAG_Nil)});
  V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str29), v_id_242}), v_t_2490});
  V v_t_2492 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, v_t_2491})});
  V v_t_2493 = ({ V a_0 = v_t_2492; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2492, 1); r_; });
  V v_a_2494 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2493, NTAG(TAG_MkUnit)});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2494})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2495}), v_hd_2482, v_k_2483));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam11(V self, V *args) {
  V v_hd_2482 = args[0];
  V v_k_2483 = args[1];
  V v_c_2481 = heff_env(self)[0];
  V v_d_2471 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2481;
  args[0] = heff_dup(v_hd_2482);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam12, 1, 4, (V[]){v_d_2471, v_id_242, v_hd_2482, v_k_2483});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam13(V self, V *args) {
  V v_x_2497 = args[0];
  V v_k_2459 = heff_env(self)[0];
  V v_x_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2497);
  V f_ = v_k_2459;
  args[0] = heff_get_n(v_x_2460, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam8(V self, V *args) {
  V v_x_2460 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_2458 = heff_env(self)[2];
  V v_k_2459 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2461 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_dup(heff_rfield(v_x_2460, 1)), v_p_243));
  V v_t_2462 = (g_heff_2ebuild_2equery_2edefinitionAt(heff_dup(heff_rfield(v_x_2460, 2)), v_t_2461));
  V v_c_2496;
  switch (heff_tag_of(v_t_2462)) {
  case TAG_Nothing: {
    V v_t_2463 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str20), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str21)})});
    V v_t_2464 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str22), NTAG(TAG_JNull)});
    V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
    V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str23), v_id_242}), v_t_2465});
    V v_t_2467 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, v_t_2466})});
    V v_t_2468 = ({ V a_0 = v_t_2467; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2467, 1); r_; });
    V v_a_2469 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2468, NTAG(TAG_MkUnit)});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2469})});
    v_c_2496 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})}));
    break;
  }
  case TAG_Just: {
    V v_d_2471 = heff_field(v_t_2462, 0);
    V v_ru_24t_2462_24Just = heff_take_reuse_n(v_t_2462, 1ULL, 1);
    V v_p_2472 = heff_dup(heff_rfield(v_d_2471, 0));
    V v_t_2473 = heff_get_n(heff_dup(heff_rfield(v_x_2460, 0)), 0, 7);
    V v_t_2474 = ({ V a_0 = heff_dup(v_p_2472); V a_1 = v_t_2473; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2473); r_; });
    V v_c_2481;
    switch (heff_tag_of(v_t_2474)) {
    case TAG_Nothing: {
      V v_t_2476 = heff_tag_at_n(v_ru_24t_2462_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_2472, ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam9_clo)})});
      V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
      v_c_2481 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2477}));
      break;
    }
    case TAG_Just: {
      V v_d_2478 = heff_field(v_t_2474, 0);
      heff_take_n(v_t_2474, 1ULL, 1);
      heff_drop_cell(v_ru_24t_2462_24Just, 1);
      heff_drop(v_p_2472);
      v_c_2481 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam10, 2, 1, (V[]){v_d_2478});
      break;
    }
    default: heff_nomatch(v_t_2474);
    }
    v_c_2496 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam11, 2, 3, (V[]){v_c_2481, v_d_2471, v_id_242});
    break;
  }
  default: heff_nomatch(v_t_2462);
  }
  V f_ = v_c_2496;
  heff_room[0] = v_hd_2458;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam13, 1, 2, (V[]){v_k_2459, v_x_2460});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam7(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_c_2457 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2457;
  args[0] = heff_dup(v_hd_2458);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam8, 1, 4, (V[]){v_p_243, v_id_242, v_hd_2458, v_k_2459});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam16(V self, V *args) {
  V v_x_24117 = args[0];
  V v_k_24101 = heff_env(self)[0];
  V v_x_24102 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24117);
  V f_ = v_k_24101;
  args[0] = heff_get_n(v_x_24102, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam15(V self, V *args) {
  V v_x_24102 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_24100 = heff_env(self)[2];
  V v_k_24101 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24103 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_x_24102, 2))));
  V v_t_24108;
  switch (heff_tag_of(v_x1_24103)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    v_t_24108 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24104 = heff_field(v_x1_24103, 0);
    heff_take_n(v_x1_24103, 1ULL, 2);
    V v_t_24106 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_dup(heff_rfield(v_x_24102, 1)), v_p_243));
    V v_t_24107 = (g_heff_2ebuild_2equery_2ecompletionsAt(v_x_24104, v_t_24106));
    v_t_24108 = (g_list_2emap_24s4199228x1154005405(v_t_24107));
    break;
  }
  default: heff_nomatch(v_x1_24103);
  }
  V v_result_24109 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24108});
  V v_t_24110 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str31), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str32)})});
  V v_t_24111 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str33), v_result_24109}), NTAG(TAG_Nil)});
  V v_t_24112 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str34), v_id_242}), v_t_24111});
  V v_t_24113 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24110, v_t_24112})});
  V v_t_24114 = ({ V a_0 = v_t_24113; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_24113, 1); r_; });
  V v_a_24115 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24114, NTAG(TAG_MkUnit)});
  V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24115})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_24116}), v_hd_24100, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam16, 1, 2, (V[]){v_k_24101, v_x_24102})));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam14(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k_24101 = args[1];
  V v_c_2499 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2499;
  args[0] = heff_dup(v_hd_24100);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam15, 1, 4, (V[]){v_p_243, v_id_242, v_hd_24100, v_k_24101});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam19(V self, V *args) {
  V v_y_24127 = args[0];
  V v_x_24122 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2elsp_2elsp_2edocSymbol(heff_get_n(v_x_24122, 1, 3), v_y_24127));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam20(V self, V *args) {
  V v_x_24137 = args[0];
  V v_k_24121 = heff_env(self)[0];
  V v_x_24122 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24137);
  V f_ = v_k_24121;
  args[0] = heff_get_n(v_x_24122, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam18(V self, V *args) {
  V v_x_24122 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24120 = heff_env(self)[1];
  V v_k_24121 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24123 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_x_24122, 2))));
  V v_t_24128;
  switch (heff_tag_of(v_x1_24123)) {
  case TAG_Nil: {
    v_t_24128 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24124 = heff_field(v_x1_24123, 0);
    heff_take_n(v_x1_24123, 1ULL, 2);
    V v_t_24126 = (g_heff_2ebuild_2equery_2esymbols(v_x_24124));
    v_t_24128 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam19, 1, 1, (V[]){heff_dup(v_x_24122)}), v_t_24126));
    break;
  }
  default: heff_nomatch(v_x1_24123);
  }
  V v_result_24129 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24128});
  V v_t_24130 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str36), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str37)})});
  V v_t_24131 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str38), v_result_24129}), NTAG(TAG_Nil)});
  V v_t_24132 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str39), v_id_242}), v_t_24131});
  V v_t_24133 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24130, v_t_24132})});
  V v_t_24134 = ({ V a_0 = v_t_24133; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_24133, 1); r_; });
  V v_a_24135 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24134, NTAG(TAG_MkUnit)});
  V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24135})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_24136}), v_hd_24120, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam20, 1, 2, (V[]){v_k_24121, v_x_24122})));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam17(V self, V *args) {
  V v_hd_24120 = args[0];
  V v_k_24121 = args[1];
  V v_c_24119 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24119;
  args[0] = heff_dup(v_hd_24120);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam18, 1, 3, (V[]){v_id_242, v_hd_24120, v_k_24121});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam25(V self, V *args) {
  V v_x_24172 = args[0];
  V v_k_24143 = heff_env(self)[0];
  V v_x_24147 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24172);
  V f_ = v_k_24143;
  args[0] = heff_get_n(v_x_24147, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam24(V self, V *args) {
  V v_x_24163 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24142 = heff_env(self)[1];
  V v_k_24143 = heff_env(self)[2];
  V v_x_24147 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24164 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str44), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str45)})});
  V v_t_24165 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str46), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24163})});
  V v_t_24166 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24165, NTAG(TAG_Nil)});
  V v_t_24167 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str47), v_id_242}), v_t_24166});
  V v_t_24168 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24164, v_t_24167})});
  V v_t_24169 = ({ V a_0 = v_t_24168; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_24168, 1); r_; });
  V v_a_24170 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24169, NTAG(TAG_MkUnit)});
  V v_t_24171 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24170})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_24171}), v_hd_24142, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam25, 1, 2, (V[]){v_k_24143, v_x_24147})));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam23(V self, V *args) {
  V v_x_24147 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_hd_24142 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_k_24143 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24148 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str41), NTAG(TAG_Nil)});
  V v_it_24149 = ({ V a_0 = v_t_24148; V a_1 = v_p_243; V r_ = (g_heff_2eutil_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_24148, 2); r_; });
  V v_x2_24157;
  switch (heff_tag_of(v_it_24149)) {
  case TAG_Nothing: {
    v_x2_24157 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_24150 = heff_field(v_it_24149, 0);
    V v_ru_24it_24149_24Just = heff_take_reuse_n(v_it_24149, 1ULL, 1);
    switch (heff_tag_of(v_it1_24150)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_24149_24Just, 1);
      v_x2_24157 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_24150, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24149_24Just, 1);
      v_x2_24157 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_24150, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24149_24Just, 1);
      v_x2_24157 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_24150, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24149_24Just, 1);
      v_x2_24157 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_24154 = heff_field(v_it1_24150, 0);
      heff_take_n(v_it1_24150, 1ULL, 1);
      v_x2_24157 = heff_tag_at_n(v_ru_24it_24149_24Just, TAG_Just, 1, (V[]){v_s_24154});
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_24150, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24149_24Just, 1);
      v_x2_24157 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_24150, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24149_24Just, 1);
      v_x2_24157 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_24150);
    }
    break;
  }
  default: heff_nomatch(v_it_24149);
  }
  V v_s_24159;
  switch (heff_tag_of(v_x2_24157)) {
  case TAG_Nothing: {
    v_s_24159 = ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str42);
    break;
  }
  case TAG_Just: {
    V v_x_24158 = heff_field(v_x2_24157, 0);
    heff_take_n(v_x2_24157, 1ULL, 1);
    v_s_24159 = v_x_24158;
    break;
  }
  default: heff_nomatch(v_x2_24157);
  }
  V v_t_24160 = (g_heff_2elsp_2elsp_2elowerGo(v_s_24159, MK_INT(0LL), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str43)));
  V v_t_24161 = (g_heff_2elsp_2elsp_2enubCheckedPaths(heff_dup(heff_rfield(v_x_24147, 1))));
  V v_c_24162 = ({ V a_0 = heff_dup(heff_rfield(v_x_24147, 0)); V a_1 = v_t_24160; V a_2 = v_t_24161; V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573(a_0, a_1, a_2)); heff_drop(v_t_24161); r_; });
  V f_ = v_c_24162;
  heff_room[0] = heff_dup(v_hd_24142);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam24, 1, 4, (V[]){v_id_242, v_hd_24142, v_k_24143, v_x_24147});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam22(V self, V *args) {
  V v_x_24144 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_24142 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  V v_k_24143 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24145 = (g_heff_2elsp_2elsp_2enubRoots(v_x_24144));
  V v_c_24146 = ({ V a_0 = v_st_240; V a_1 = v_t_24145; V r_ = (g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576(a_0, a_1)); heff_drop(v_t_24145); r_; });
  V f_ = v_c_24146;
  heff_room[0] = heff_dup(v_hd_24142);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam23, 1, 4, (V[]){v_p_243, v_hd_24142, v_id_242, v_k_24143});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam21(V self, V *args) {
  V v_hd_24142 = args[0];
  V v_k_24143 = args[1];
  V v_c_24141 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24141;
  args[0] = heff_dup(v_hd_24142);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam22, 1, 5, (V[]){v_st_240, v_hd_24142, v_p_243, v_id_242, v_k_24143});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam28(V self, V *args) {
  V v_o_24188 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24189 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str53), NTAG(TAG_Nil)});
  V v_it_24190 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str54), v_t_24189}); V a_1 = v_p_243; V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_24198;
  switch (heff_tag_of(v_it_24190)) {
  case TAG_Nothing: {
    v_x2_24198 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_24191 = heff_field(v_it_24190, 0);
    V v_ru_24it_24190_24Just = heff_take_reuse_n(v_it_24190, 1ULL, 1);
    switch (heff_tag_of(v_it1_24191)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_24190_24Just, 1);
      v_x2_24198 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      V v_b_24192 = heff_field(v_it1_24191, 0);
      heff_take_n(v_it1_24191, 1ULL, 1);
      v_x2_24198 = heff_tag_at_n(v_ru_24it_24190_24Just, TAG_Just, 1, (V[]){v_b_24192});
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_24191, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24190_24Just, 1);
      v_x2_24198 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_24191, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24190_24Just, 1);
      v_x2_24198 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_it1_24191, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24190_24Just, 1);
      v_x2_24198 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_24191, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24190_24Just, 1);
      v_x2_24198 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_24191, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24190_24Just, 1);
      v_x2_24198 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_24191);
    }
    break;
  }
  default: heff_nomatch(v_it_24190);
  }
  switch (heff_tag_of(v_x2_24198)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_24188, 4);
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    V v_x_24199 = heff_field(v_x2_24198, 0);
    heff_take_n(v_x2_24198, 1ULL, 1);
    switch (heff_tag_of(v_x_24199)) {
    case TAG_True: {
      heff_drop_rec(v_o_24188, 4);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_24200 = heff_get_n(v_o_24188, 3, 4);
      switch (heff_tag_of(v_t_24200)) {
      case TAG_True: {
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_t_24200);
      }
    }
    default: return heff_nomatch(v_x_24199);
    }
  }
  default: return heff_nomatch(v_x2_24198);
  }
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam30(V self, V *args) {
  V v_x_24205 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24203 = heff_env(self)[1];
  V v_k_24204 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24206 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str55), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str56)})});
  V v_t_24207 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str57), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24205})});
  V v_t_24208 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24207, NTAG(TAG_Nil)});
  V v_t_24209 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str58), v_id_242}), v_t_24208});
  V v_t_24210 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24206, v_t_24209})});
  V v_t_24211 = ({ V a_0 = v_t_24210; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_24210, 1); r_; });
  V v_a_24212 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24211, NTAG(TAG_MkUnit)});
  V v_t_24213 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24212})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_24213}), v_hd_24203, v_k_24204));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam29(V self, V *args) {
  V v_hd_24203 = args[0];
  V v_k_24204 = args[1];
  V v_c_24202 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24202;
  args[0] = heff_dup(v_hd_24203);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam30, 1, 3, (V[]){v_id_242, v_hd_24203, v_k_24204});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam31(V self, V *args) {
  V v_x_24215 = args[0];
  V v_k_24176 = heff_env(self)[0];
  V v_x_24177 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24215);
  V f_ = v_k_24176;
  args[0] = heff_get_n(v_x_24177, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam27(V self, V *args) {
  V v_x_24177 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_hd_24175 = heff_env(self)[2];
  V v_k_24176 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24178 = heff_dup(heff_rfield(v_x_24177, 2));
  V v_c_24214;
  switch (heff_tag_of(v_t_24178)) {
  case TAG_Nothing: {
    heff_drop(v_p_243);
    V v_t_24179 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str49), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str50)})});
    V v_t_24180 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str51), NTAG(TAG_JNull)});
    V v_t_24181 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24180, NTAG(TAG_Nil)});
    V v_t_24182 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str52), v_id_242}), v_t_24181});
    V v_t_24183 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24179, v_t_24182})});
    V v_t_24184 = ({ V a_0 = v_t_24183; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_24183, 1); r_; });
    V v_a_24185 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24184, NTAG(TAG_MkUnit)});
    V v_t_24186 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24185})});
    v_c_24214 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24186})}));
    break;
  }
  case TAG_Just: {
    V v_t_24187 = heff_field(v_t_24178, 0);
    heff_take_n(v_t_24178, 1ULL, 1);
    V v_t_24201 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam28, 1, 1, (V[]){v_p_243}), heff_get_n(v_t_24187, 3, 4)));
    V v_c_24202 = (g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104(heff_dup(heff_rfield(v_x_24177, 0)), v_t_24201));
    v_c_24214 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam29, 2, 2, (V[]){v_c_24202, v_id_242});
    break;
  }
  default: heff_nomatch(v_t_24178);
  }
  V f_ = v_c_24214;
  heff_room[0] = v_hd_24175;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam31, 1, 2, (V[]){v_k_24176, v_x_24177});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam26(V self, V *args) {
  V v_hd_24175 = args[0];
  V v_k_24176 = args[1];
  V v_c_24174 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24174;
  args[0] = heff_dup(v_hd_24175);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam27, 1, 4, (V[]){v_id_242, v_p_243, v_hd_24175, v_k_24176});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam33(V self, V *args) {
  V v_x_24220 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24218 = heff_env(self)[1];
  V v_k_24219 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574(v_id_242, v_x_24220, v_hd_24218, v_k_24219));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam32(V self, V *args) {
  V v_hd_24218 = args[0];
  V v_k_24219 = args[1];
  V v_c_24217 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24217;
  args[0] = heff_dup(v_hd_24218);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam33, 1, 3, (V[]){v_id_242, v_hd_24218, v_k_24219});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam35(V self, V *args) {
  V v_x_24225 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_24223 = heff_env(self)[2];
  V v_k_24224 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24226 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str61), NTAG(TAG_Nil)});
  V v_it_24227 = ({ V a_0 = v_t_24226; V a_1 = v_p_243; V r_ = (g_heff_2eutil_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_24226, 2); r_; });
  V v_x2_24235;
  switch (heff_tag_of(v_it_24227)) {
  case TAG_Nothing: {
    v_x2_24235 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_24228 = heff_field(v_it_24227, 0);
    V v_ru_24it_24227_24Just = heff_take_reuse_n(v_it_24227, 1ULL, 1);
    switch (heff_tag_of(v_it1_24228)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_24227_24Just, 1);
      v_x2_24235 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24227_24Just, 1);
      v_x2_24235 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24227_24Just, 1);
      v_x2_24235 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24227_24Just, 1);
      v_x2_24235 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_24232 = heff_field(v_it1_24228, 0);
      heff_take_n(v_it1_24228, 1ULL, 1);
      v_x2_24235 = heff_tag_at_n(v_ru_24it_24227_24Just, TAG_Just, 1, (V[]){v_s_24232});
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24227_24Just, 1);
      v_x2_24235 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24227_24Just, 1);
      v_x2_24235 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_24228);
    }
    break;
  }
  default: heff_nomatch(v_it_24227);
  }
  V v_t_24237;
  switch (heff_tag_of(v_x2_24235)) {
  case TAG_Nothing: {
    v_t_24237 = ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str62);
    break;
  }
  case TAG_Just: {
    V v_x_24236 = heff_field(v_x2_24235, 0);
    heff_take_n(v_x2_24235, 1ULL, 1);
    v_t_24237 = v_x_24236;
    break;
  }
  default: heff_nomatch(v_x2_24235);
  }
  return (g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918(v_id_242, v_t_24237, v_x_24225, v_hd_24223, v_k_24224));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam34(V self, V *args) {
  V v_hd_24223 = args[0];
  V v_k_24224 = args[1];
  V v_c_24222 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24222;
  args[0] = heff_dup(v_hd_24223);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam35, 1, 4, (V[]){v_p_243, v_id_242, v_hd_24223, v_k_24224});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam37(V self, V *args) {
  V v_x_24242 = args[0];
  V v_k_24241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24242);
  V f_ = v_k_24241;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam36(V self, V *args) {
  V v_hd_24240 = args[0];
  V v_k_24241 = args[1];
  V v_c_24239 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24239;
  args[0] = v_hd_24240;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam37, 1, 2, (V[]){v_k_24241, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str0, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str1, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str2, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str3, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str4, 9, "shut down");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str5, 6, "params");
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_entry, 2, 0};

V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459(V v_st_240, V v_msg_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str0), NTAG(TAG_Nil)});
  V v_it_243 = ({ V a_0 = v_t_242; V a_1 = heff_dup(v_msg_241); V r_ = (g_heff_2eutil_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_242, 2); r_; });
  V v_t_2411;
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Just = heff_take_reuse_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_248 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 1);
      v_t_2411 = heff_tag_at_n(v_ru_24it_243_24Just, TAG_Just, 1, (V[]){v_s_248});
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_244);
    }
    break;
  }
  default: heff_nomatch(v_it_243);
  }
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    heff_drop(v_msg_241);
    return heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Just: {
    V v_m_2414 = heff_field(v_t_2411, 0);
    V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 1ULL, 1);
    V v_t_2426;
    switch (heff_tag_of(v_msg_241)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_2420 = heff_dup(heff_field(v_msg_241, 0));
      V v_t_2421 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str1); V a_1 = v_fs_2420; V r_ = (g_list_2efind_24s913819130x636901392(a_0, a_1)); heff_drop(v_fs_2420); r_; });
      switch (heff_tag_of(v_t_2421)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24t_2411_24Just, 1);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_p_2422 = heff_field(v_t_2421, 0);
        heff_take_n(v_t_2421, 1ULL, 1);
        V v_t_2425;
        switch (heff_tag_of(v_p_2422)) {
        case TAG_MkPair: {
          V v_y_2424 = heff_field(v_p_2422, 1);
          heff_take_n(v_p_2422, 2ULL, 2);
          v_t_2425 = v_y_2424;
          break;
        }
        default: heff_nomatch(v_p_2422);
        }
        v_t_2426 = heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Just, 1, (V[]){v_t_2425});
        break;
      }
      default: heff_nomatch(v_t_2421);
      }
      break;
    }
    default: heff_nomatch(v_msg_241);
    }
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nothing: {
      V v_x2_2438;
      switch (heff_tag_of(v_msg_241)) {
      case TAG_JNull: {
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        V v_fs_2432 = heff_field(v_msg_241, 0);
        V v_ru_24msg_241_24JObject = heff_take_reuse_n(v_msg_241, 1ULL, 1);
        V v_t_2433 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str2); V a_1 = v_fs_2432; V r_ = (g_list_2efind_24s913819130x636901392(a_0, a_1)); heff_drop(v_fs_2432); r_; });
        switch (heff_tag_of(v_t_2433)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24msg_241_24JObject, 1);
          v_x2_2438 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_p_2434 = heff_field(v_t_2433, 0);
          heff_take_n(v_t_2433, 1ULL, 1);
          V v_t_2437;
          switch (heff_tag_of(v_p_2434)) {
          case TAG_MkPair: {
            V v_y_2436 = heff_field(v_p_2434, 1);
            heff_take_n(v_p_2434, 2ULL, 2);
            v_t_2437 = v_y_2436;
            break;
          }
          default: heff_nomatch(v_p_2434);
          }
          v_x2_2438 = heff_tag_at_n(v_ru_24msg_241_24JObject, TAG_Just, 1, (V[]){v_t_2437});
          break;
        }
        default: heff_nomatch(v_t_2433);
        }
        break;
      }
      default: heff_nomatch(v_msg_241);
      }
      V v_t_2440;
      switch (heff_tag_of(v_x2_2438)) {
      case TAG_Nothing: {
        v_t_2440 = NTAG(TAG_JNull);
        break;
      }
      case TAG_Just: {
        V v_x_2439 = heff_field(v_x2_2438, 0);
        heff_take_n(v_x2_2438, 1ULL, 1);
        v_t_2440 = v_x_2439;
        break;
      }
      default: heff_nomatch(v_x2_2438);
      }
      return (g_heff_2elsp_2elsp_2enotification_24s270589690x602944811(v_st_240, v_m_2414, v_t_2440));
    }
    case TAG_Just: {
      V v_id_2441 = heff_field(v_t_2426, 0);
      V v_ru_24t_2426_24Just = heff_take_reuse_n(v_t_2426, 1ULL, 1);
      V v_t_2442 = heff_dup(heff_rfield(v_st_240, 5));
      V v_t_2444;
      switch (heff_tag_of(v_t_2442)) {
      case TAG_True: {
        if (heff_strEq_c(heff_dup(v_m_2414), ((V)&g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str3))) {
          v_t_2444 = NTAG(TAG_False);
        } else {
          v_t_2444 = NTAG(TAG_True);
        }
        break;
      }
      case TAG_False: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2442);
      }
      switch (heff_tag_of(v_t_2444)) {
      case TAG_True: {
        heff_drop(v_msg_241);
        heff_drop(v_m_2414);
        heff_drop_cell(v_ru_24t_2426_24Just, 1);
        V v_c_2445 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(v_id_2441, MK_INT(-32600LL), ((V)&g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str4)));
        return heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam1, 2, 2, (V[]){v_c_2445, v_st_240});
      }
      case TAG_False: {
        V v_x2_2460;
        switch (heff_tag_of(v_msg_241)) {
        case TAG_JNull: {
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          V v_fs_2454 = heff_field(v_msg_241, 0);
          heff_take_n(v_msg_241, 1ULL, 1);
          V v_t_2455 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str5); V a_1 = v_fs_2454; V r_ = (g_list_2efind_24s913819130x636901392(a_0, a_1)); heff_drop(v_fs_2454); r_; });
          switch (heff_tag_of(v_t_2455)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24t_2426_24Just, 1);
            v_x2_2460 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_p_2456 = heff_field(v_t_2455, 0);
            heff_take_n(v_t_2455, 1ULL, 1);
            V v_t_2459;
            switch (heff_tag_of(v_p_2456)) {
            case TAG_MkPair: {
              V v_y_2458 = heff_field(v_p_2456, 1);
              heff_take_n(v_p_2456, 2ULL, 2);
              v_t_2459 = v_y_2458;
              break;
            }
            default: heff_nomatch(v_p_2456);
            }
            v_x2_2460 = heff_tag_at_n(v_ru_24t_2426_24Just, TAG_Just, 1, (V[]){v_t_2459});
            break;
          }
          default: heff_nomatch(v_t_2455);
          }
          break;
        }
        default: heff_nomatch(v_msg_241);
        }
        V v_t_2462;
        switch (heff_tag_of(v_x2_2460)) {
        case TAG_Nothing: {
          v_t_2462 = NTAG(TAG_JNull);
          break;
        }
        case TAG_Just: {
          V v_x_2461 = heff_field(v_x2_2460, 0);
          heff_take_n(v_x2_2460, 1ULL, 1);
          v_t_2462 = v_x_2461;
          break;
        }
        default: heff_nomatch(v_x2_2460);
        }
        return (g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277(v_st_240, v_m_2414, v_id_2441, v_t_2462));
      }
      default: return heff_nomatch(v_t_2444);
      }
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam2(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_2447 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2448);
  V f_ = v_k_2447;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam1(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2445;
  args[0] = v_hd_2446;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam2, 1, 2, (V[]){v_k_2447, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_entry, 2, 0};

V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_map_2edelete_24s805420727x38051515(heff_dup(v_f_244), heff_rfield(v_st_240, 2)));
    V v_t_247 = heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(heff_rfield(v_st_240, 0)), heff_dup(heff_rfield(v_st_240, 1)), v_t_246, heff_dup(heff_rfield(v_st_240, 3)), heff_dup(heff_rfield(v_st_240, 4)), heff_dup(heff_rfield(v_st_240, 5)), heff_dup(heff_rfield(v_st_240, 6))});
    V v_c_248 = (g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(v_t_247, heff_dup(v_f_244)));
    return heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam1, 2, 4, (V[]){v_c_248, v_st_240, heff_dup(v_f_244), heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414 = ({ V a_0 = v_x_2413; V a_1 = v_rest_245; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2414;
  heff_room[0] = v_hd_249;
  heff_room[1] = v_k_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412 = (g_heff_2elsp_2elsp_2edependentsOf(v_st_240, v_f_244));
  return ({ V a_0 = v_x_2411; V a_1 = v_t_2412; V a_2 = heff_dup(v_hd_249); V a_3 = heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam3, 1, 3, (V[]){v_rest_245, v_hd_249, v_k_2410}); V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
}
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_244 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam2, 1, 5, (V[]){v_st_240, v_f_244, v_hd_249, v_rest_245, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam0, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam2, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam5, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_entry, 3, 0};

V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099(V v_st_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(v_t_245, heff_dup(v_hd_241), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam1, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242}));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam0(V self, V *args) {
  V v_n_243 = args[0];
  return v_n_243;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  return v_x_2418;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099(v_x_2424, v_hd_241, v_k_242));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam5(V self, V *args) {
  V v_n_2425 = args[0];
  return v_n_2425;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam7(V self, V *args) {
  V v_q_2430 = args[0];
  V v_x_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433;
  switch (heff_tag_of(v_q_2430)) {
  case TAG_MkPair: {
    V v_y_2432 = heff_field(v_q_2430, 1);
    heff_take_n(v_q_2430, 2ULL, 2);
    v_t_2433 = v_y_2432;
    break;
  }
  default: heff_nomatch(v_q_2430);
  }
  return heff_intLe(v_t_2433, v_x_2428);
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam8(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099(v_x_2437, v_hd_241, v_k_242));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2429 = (g_map_2etoListOnto(heff_rfield(v_st_240, 2), NTAG(TAG_Nil)));
  V v_t_2434 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam7, 1, 1, (V[]){v_x_2428}), v_t_2429));
  V v_t_2435 = (g_list_2emap_24s1415906091x1371825187(v_t_2434));
  V v_c_2436 = ({ V a_0 = v_st_240; V a_1 = v_t_2435; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421(a_0, a_1)); heff_drop(v_t_2435); r_; });
  V f_ = v_c_2436;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam8, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Message: {
    V v_msg_2422 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    V v_c_2423 = (g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459(v_st_240, v_msg_2422));
    V f_ = v_c_2423;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam4, 1, 2, (V[]){v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Timeout: {
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam5_clo)})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    return (g_co_2eop_24s954557541x749476273(v_t_2427, heff_dup(v_hd_241), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam6, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242})));
  }
  case TAG_Closed: {
    heff_drop_rec(v_st_240, 7);
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){MK_INT(1LL)})});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    return (g_co_2eop_24s954557541x749476273(v_t_2439, v_hd_241, v_k_242));
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = (g_map_2etoListOnto(heff_rfield(v_st_240, 2), NTAG(TAG_Nil)));
  V v_t_248 = (g_list_2emap_24s366344330x1145113647(v_t_247));
  V v_ms_2415;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nil: {
    heff_drop(v_x_246);
    v_ms_2415 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_d_249 = heff_field(v_t_248, 0);
    V v_ds_2410 = heff_field(v_t_248, 1);
    heff_take_n(v_t_248, 3ULL, 2);
    V v_t_2411 = ({ V a_0 = v_d_249; V a_1 = v_ds_2410; V r_ = (g_list_2efoldl_24s361191175x1417189158(a_0, a_1)); heff_drop(v_ds_2410); r_; });
    V v_b_2412 = heff_intSub(v_t_2411, v_x_246);
    V v_t_2414;
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_b_2412))) {
      v_t_2414 = v_b_2412;
    } else {
      heff_drop(v_b_2412);
      v_t_2414 = MK_INT(0LL);
    }
    v_ms_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_t_2417;
  switch (heff_tag_of(v_ms_2415)) {
  case TAG_Nothing: {
    v_t_2417 = MK_INT(-1LL);
    break;
  }
  case TAG_Just: {
    V v_x_2416 = heff_field(v_ms_2415, 0);
    heff_take_n(v_ms_2415, 1ULL, 1);
    v_t_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_ms_2415);
  }
  V v_a_2419 = heff_tag_n(TAG_Await, 2, (V[]){v_t_2417, ((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam2_clo)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2419})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_hd_241), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1341487287x1391507099_lam3, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242})));
}