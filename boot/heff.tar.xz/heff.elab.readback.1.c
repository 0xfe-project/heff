// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLocal 28569
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_array_2eempty_get(void);
V g_heff_2eelab_2ereadback_2eappliedOnly(V);
V g_heff_2eelab_2ereadback_2eappliedOnly_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eappliedOnly_clo;
V g_heff_2eelab_2ereadback_2egoRT_24dps(V, V, V, V, V);
V g_heff_2eelab_2ereadback_2egoRT_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2egoRT_24dps_clo;
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591(V, V, V);
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_clo;
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps(V, V, V, V);
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps_clo;
HeffT2 g_heff_2eelab_2ereadback_2elocalArgs_24cpr(V);
V g_heff_2eelab_2ereadback_2ereadbBare(V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbBare_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbBare_clo;
V g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_clo;
V g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885_clo;
V g_heff_2eelab_2ereadback_2ereadbSpine(V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbSpine_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbSpine_clo;
V g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694_clo;
V g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24generate0(V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24generate0_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24map0(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24map0_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24map0(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24map0_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_clo;
V g_heff_2eelab_2ereadback_2eshownForcedRb(V);
V g_heff_2eelab_2ereadback_2eshownForcedRb_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownForcedRb_clo;
HeffT2 g_heff_2eelab_2ereadback_2eshownForcedRb_24cpr(V);
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1947501783x1475115781(V, V, V);
V g_list_2emap_24s1947501783x1475115781_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_clo;

HeffT2 g_heff_2eelab_2ereadback_2elocalArgs_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_SpApp: {
    V v_sp_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SpApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_VNeu: {
      V v_x121_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      heff_take_n(v_x12_242, 3ULL, 5);
      switch (heff_tag_of(v_x121_243)) {
      case TAG_HLocal: {
        V v_l_248 = heff_field(v_x121_243, 0);
        heff_take_n(v_x121_243, 1ULL, 1);
        switch (heff_tag_of(v_x122_244)) {
        case TAG_SpId: {
          HeffT2 v_t_249 = (g_heff_2eelab_2ereadback_2elocalArgs_24cpr(v_sp_241));
          {
            V v_field_2411 = v_t_249.f[1];
            int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
            if ((v_tag_2410 == ((int64_t)0ULL))) {
              V v_xs_2412 = v_field_2411;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24SpApp, TAG_Cons, 2, (V[]){v_l_248, v_xs_2412})}});
            } else {
              heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
              heff_drop(v_l_248);
              heff_drop(v_field_2411);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        case TAG_SpApp: {
          heff_take_n(v_x122_244, 0ULL, 2);
          heff_drop(v_sp_241);
          heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
          heff_drop(v_l_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SpProj: {
          heff_take_n(v_x122_244, 0ULL, 2);
          heff_drop(v_sp_241);
          heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
          heff_drop(v_l_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SpSpec: {
          heff_take_n(v_x122_244, 0ULL, 3);
          heff_drop(v_sp_241);
          heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
          heff_drop(v_l_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x122_244)}});
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_x121_243, 0ULL, 1);
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
        heff_drop(v_x122_244);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HMeta: {
        heff_take_n(v_x121_243, 0ULL, 1);
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
        heff_drop(v_x122_244);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HError: {
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
        heff_drop(v_x122_244);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x121_243)}});
      }
    }
    case TAG_VCode: {
      heff_take_n(v_x12_242, 0ULL, 1);
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VLam: {
      heff_take_n(v_x12_242, 0ULL, 2);
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VCons: {
      heff_take_n(v_x12_242, 0ULL, 1);
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VOpaque: {
      heff_drop(v_sp_241);
      heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
    }
  }
  case TAG_SpProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SpSpec: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2eelab_2ereadback_2ereadbSpine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbSpine_entry, 4, 0};

V g_heff_2eelab_2ereadback_2ereadbSpine(V v_r_240, V v_n_241, V v_x3_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SpId: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return v_t_243;
  }
  case TAG_SpApp: {
    V v_sp_244 = heff_field(v_x3_242, 0);
    V v_v_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24SpApp = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = (g_heff_2eelab_2ereadback_2ereadbSpine(heff_dup(v_r_240), heff_dup(v_n_241), v_sp_244, v_t_243));
    V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_n_241, v_v_245}));
    return heff_tag_at_n(v_ru_24x3_242_24SpApp, TAG_SApp, 2, (V[]){v_t_246, v_t_247});
  }
  case TAG_SpProj: {
    V v_sp_248 = heff_field(v_x3_242, 0);
    V v_x_249 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24SpProj = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2410 = (g_heff_2eelab_2ereadback_2ereadbSpine(v_r_240, v_n_241, v_sp_248, v_t_243));
    return heff_tag_at_n(v_ru_24x3_242_24SpProj, TAG_SProj, 2, (V[]){v_t_2410, v_x_249});
  }
  case TAG_SpSpec: {
    V v_sp_2411 = heff_field(v_x3_242, 0);
    V v_x_2412 = heff_field(v_x3_242, 1);
    V v_v_2413 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24SpSpec = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_2414 = (g_heff_2eelab_2ereadback_2ereadbSpine(heff_dup(v_r_240), heff_dup(v_n_241), v_sp_2411, v_t_243));
    V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_n_241, v_v_2413}));
    return heff_tag_at_n(v_ru_24x3_242_24SpSpec, TAG_SSpecialize, 3, (V[]){v_t_2414, v_x_2412, v_t_2415});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2ereadback_2ereadbSpine_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbSpine(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2ereadback_2ereadbBare_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbBare_entry, 4, 0};

V g_heff_2eelab_2ereadback_2ereadbBare(V v_r_240, V v_n_241, V v_h_242, V v_sp_243) {
top: ;
  switch (heff_tag_of(v_h_242)) {
  case TAG_HLocal: {
    V v_t_2410;
    switch (heff_tag_of(v_h_242)) {
    case TAG_HLocal: {
      V v_i_245 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HLocal = heff_take_reuse_n(v_h_242, 1ULL, 1);
      V v_t_246 = heff_intSub(heff_intSub_lent(v_n_241, v_i_245, 2), MK_INT(1LL));
      v_t_2410 = heff_tag_at_n(v_ru_24h_242_24HLocal, TAG_SLocal, 1, (V[]){v_t_246});
      break;
    }
    case TAG_HGlobal: {
      V v_x_247 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HGlobal = heff_take_reuse_n(v_h_242, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24h_242_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_247});
      break;
    }
    case TAG_HMeta: {
      V v_m_248 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HMeta = heff_take_reuse_n(v_h_242, 1ULL, 1);
      V v_t_249 = heff_tag_at_n(v_ru_24h_242_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2410 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_248, heff_dup(g_array_2eempty_get()), v_t_249});
      break;
    }
    case TAG_HError: {
      v_t_2410 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_242);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine(v_r_240, v_n_241, v_sp_243, v_t_2410);
  }
  case TAG_HGlobal: {
    V v_t_2417;
    switch (heff_tag_of(v_h_242)) {
    case TAG_HLocal: {
      V v_i_2412 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HLocal = heff_take_reuse_n(v_h_242, 1ULL, 1);
      V v_t_2413 = heff_intSub(heff_intSub_lent(v_n_241, v_i_2412, 2), MK_INT(1LL));
      v_t_2417 = heff_tag_at_n(v_ru_24h_242_24HLocal, TAG_SLocal, 1, (V[]){v_t_2413});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2414 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HGlobal = heff_take_reuse_n(v_h_242, 1ULL, 1);
      v_t_2417 = heff_tag_at_n(v_ru_24h_242_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2414});
      break;
    }
    case TAG_HMeta: {
      V v_m_2415 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HMeta = heff_take_reuse_n(v_h_242, 1ULL, 1);
      V v_t_2416 = heff_tag_at_n(v_ru_24h_242_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2417 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2415, heff_dup(g_array_2eempty_get()), v_t_2416});
      break;
    }
    case TAG_HError: {
      v_t_2417 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_242);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine(v_r_240, v_n_241, v_sp_243, v_t_2417);
  }
  case TAG_HMeta: {
    V v_m_2418 = heff_field(v_h_242, 0);
    V v_ru_24h_242_24HMeta = heff_take_reuse_n(v_h_242, 1ULL, 1);
    HeffT2 v_t_2419 = (g_heff_2eelab_2ereadback_2elocalArgs_24cpr(heff_dup(v_sp_243)));
    {
      V v_field_2421 = v_t_2419.f[1];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        heff_drop(v_r_240);
        heff_drop(v_sp_243);
        V v_idxs_2422 = v_field_2421;
        V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_idxs_2422));
        V v_t_2424 = (g_list_2emap_24s1947501783x1475115781(v_n_241, MK_INT(1LL), v_t_2423));
        V v_t_2425 = heff_tag_at_n(v_ru_24h_242_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
        return heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2418, heff_arrayFromList(v_t_2424), v_t_2425});
      } else {
        heff_drop(v_field_2421);
        V v_t_2426 = heff_tag_at_n(v_ru_24h_242_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
        HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine(v_r_240, v_n_241, v_sp_243, heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2418, heff_dup(g_array_2eempty_get()), v_t_2426}));
      }
    }
  }
  case TAG_HError: {
    V v_t_2432;
    switch (heff_tag_of(v_h_242)) {
    case TAG_HLocal: {
      V v_i_2427 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HLocal = heff_take_reuse_n(v_h_242, 1ULL, 1);
      V v_t_2428 = heff_intSub(heff_intSub_lent(v_n_241, v_i_2427, 2), MK_INT(1LL));
      v_t_2432 = heff_tag_at_n(v_ru_24h_242_24HLocal, TAG_SLocal, 1, (V[]){v_t_2428});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2429 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HGlobal = heff_take_reuse_n(v_h_242, 1ULL, 1);
      v_t_2432 = heff_tag_at_n(v_ru_24h_242_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2429});
      break;
    }
    case TAG_HMeta: {
      V v_m_2430 = heff_field(v_h_242, 0);
      V v_ru_24h_242_24HMeta = heff_take_reuse_n(v_h_242, 1ULL, 1);
      V v_t_2431 = heff_tag_at_n(v_ru_24h_242_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2432 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2430, heff_dup(g_array_2eempty_get()), v_t_2431});
      break;
    }
    case TAG_HError: {
      v_t_2432 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_242);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine(v_r_240, v_n_241, v_sp_243, v_t_2432);
  }
  default: return heff_nomatch(v_h_242);
  }
}
V g_heff_2eelab_2ereadback_2ereadbBare_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbBare(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2ereadback_2egoRT_24dps_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2egoRT_24dps_lam1(V self, V *args);
Clo g_heff_2eelab_2ereadback_2egoRT_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2egoRT_24dps_entry, 5, 0};

V g_heff_2eelab_2ereadback_2egoRT_24dps(V v_r_240, V v_i_241, V v_ls_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_241);
    heff_drop(v_ls_242);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_ls_242)}));
    switch (heff_tag_of(v_t_247)) {
    case TAG_MkField: {
      V v_ty_248 = heff_field(v_t_247, 0);
      V v_ru_24t_247_24MkField = heff_take_reuse_n(v_t_247, 1ULL, 2);
      V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_i_241), heff_dup(v_ty_248)}));
      V v_v_2412 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(v_i_241)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_24dps_lam0, 1, 1, (V[]){v_ty_248}), NTAG(TAG_Nothing)));
      V v_cell_2413 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2414 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2413);
      V t_0 = v_r_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_tag_at_n(v_ru_24t_247_24MkField, TAG_LSnoc, 2, (V[]){v_ls_242, heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_24dps_lam1, 1, 1, (V[]){v_v_2412})});
      V t_3 = v_rest_246;
      V t_4 = v_u_2414;
      v_r_240 = t_0;
      v_i_241 = t_1;
      v_ls_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2ereadback_2egoRT_24dps_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2ereadback_2egoRT_24dps(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2eelab_2ereadback_2egoRT_24dps_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_ty_248 = heff_env(self)[0];
  heff_drop(v_u_2411);
  heff_clo_take(self, 1);
  return v_ty_248;
}
V g_heff_2eelab_2ereadback_2egoRT_24dps_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2412 = heff_env(self)[0];
  heff_drop(v_u_2415);
  heff_clo_take(self, 1);
  return v_v_2412;
}
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_lam1(V self, V *args);
Clo g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_entry, 3, 0};

V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591(V v_i_240, V v_ls_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_ls_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_f_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(v_f_243, 1, (V[]){heff_dup(v_ls_241)}));
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkField: {
      V v_ty_246 = heff_field(v_t_245, 0);
      V v_ru_24t_245_24MkField = heff_take_reuse_n(v_t_245, 1ULL, 2);
      V v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_dup(v_i_240), heff_dup(v_ty_246)));
      V v_v_2410 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(v_i_240)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_lam0, 1, 1, (V[]){v_ty_246}), NTAG(TAG_Nothing)));
      V v_cell_2411 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2413 = (g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps(heff_intAdd(v_i_240, MK_INT(1LL)), heff_tag_at_n(v_ru_24t_245_24MkField, TAG_LSnoc, 2, (V[]){v_ls_241, heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_lam1, 1, 1, (V[]){v_v_2410})}), v_rest_244, v_cell_2411));
      heff_drop(v_u_2413);
      return v_cell_2411;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_lam0(V self, V *args) {
  V v_u_249 = args[0];
  V v_ty_246 = heff_env(self)[0];
  heff_drop(v_u_249);
  heff_clo_take(self, 1);
  return v_ty_246;
}
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_v_2410 = heff_env(self)[0];
  heff_drop(v_u_2412);
  heff_clo_take(self, 1);
  return v_v_2410;
}
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps_lam1(V self, V *args);
Clo g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps_entry, 4, 0};

V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps(V v_i_240, V v_ls_241, V v_x4_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_ls_241);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x4_242, 0);
    V v_rest_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(v_f_244, 1, (V[]){heff_dup(v_ls_241)}));
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkField: {
      V v_ty_247 = heff_field(v_t_246, 0);
      V v_ru_24t_246_24MkField = heff_take_reuse_n(v_t_246, 1ULL, 2);
      V v_t_249 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_dup(v_i_240), heff_dup(v_ty_247)));
      V v_v_2411 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(v_i_240)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps_lam0, 1, 1, (V[]){v_ty_247}), NTAG(TAG_Nothing)));
      V v_cell_2412 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2413 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2412);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = heff_tag_at_n(v_ru_24t_246_24MkField, TAG_LSnoc, 2, (V[]){v_ls_241, heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps_lam1, 1, 1, (V[]){v_v_2411})});
      V t_2 = v_rest_245;
      V t_3 = v_u_2413;
      v_i_240 = t_0;
      v_ls_241 = t_1;
      v_x4_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps_lam0(V self, V *args) {
  V v_u_2410 = args[0];
  V v_ty_247 = heff_env(self)[0];
  heff_drop(v_u_2410);
  heff_clo_take(self, 1);
  return v_ty_247;
}
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_24dps_lam1(V self, V *args) {
  V v_u_2414 = args[0];
  V v_v_2411 = heff_env(self)[0];
  heff_drop(v_u_2414);
  heff_clo_take(self, 1);
  return v_v_2411;
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_lam1(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_lam3(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_lam2(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps(V v_n_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_VU: {
    V v_u_243 = heff_field(v_x3_241, 0);
    heff_take_n(v_x3_241, 1ULL, 1);
    heff_drop(v_n_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(0LL), heff_tag_n(TAG_SU, 1, (V[]){v_u_243}));
  }
  case TAG_VDecode: {
    V v_h_244 = heff_field(v_x3_241, 0);
    V v_sp_245 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 5);
    V v_t_2414;
    switch (heff_tag_of(v_h_244)) {
    case TAG_HLocal: {
      V v_i_249 = heff_field(v_h_244, 0);
      V v_ru_24h_244_24HLocal = heff_take_reuse_n(v_h_244, 1ULL, 1);
      V v_t_2410 = heff_intSub(heff_intSub_lent(v_n_240, v_i_249, 2), MK_INT(1LL));
      v_t_2414 = heff_tag_at_n(v_ru_24h_244_24HLocal, TAG_SLocal, 1, (V[]){v_t_2410});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2411 = heff_field(v_h_244, 0);
      V v_ru_24h_244_24HGlobal = heff_take_reuse_n(v_h_244, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24h_244_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2411});
      break;
    }
    case TAG_HMeta: {
      V v_m_2412 = heff_field(v_h_244, 0);
      V v_ru_24h_244_24HMeta = heff_take_reuse_n(v_h_244, 1ULL, 1);
      V v_t_2413 = heff_tag_at_n(v_ru_24h_244_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2414 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2412, heff_dup(g_array_2eempty_get()), v_t_2413});
      break;
    }
    case TAG_HError: {
      v_t_2414 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_244);
    }
    V v_t_2415 = (g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_245, v_t_2414));
    return heff_setField(heff_dup(v_d_242), MK_INT(0LL), heff_tag_n(TAG_SDecode, 1, (V[]){v_t_2415}));
  }
  case TAG_VFunction: {
    V v_level_2416 = heff_field(v_x3_241, 0);
    V v_dom_2417 = heff_field(v_x3_241, 1);
    V v_cod_2418 = heff_field(v_x3_241, 2);
    V v_implicit_2419 = heff_field(v_x3_241, 3);
    V v_dflt_2420 = heff_field(v_x3_241, 4);
    heff_take_n(v_x3_241, 31ULL, 6);
    V v_t_2422 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_dup(v_n_240), heff_dup(v_dom_2417)));
    V v_n_2423 = v_n_240;
    V v_dom_2424 = v_dom_2417;
    V v_x4_2425 = v_cod_2418;
    V v_t_2445;
    switch (heff_tag_of(v_x4_2425)) {
    case TAG_MkClo: {
      V v_x_2426 = heff_field(v_x4_2425, 0);
      V v_l_2427 = heff_field(v_x4_2425, 1);
      V v_f_2428 = heff_field(v_x4_2425, 2);
      heff_take_n(v_x4_2425, 7ULL, 3);
      V v_n_2429 = heff_intAdd_lent(v_n_2423, MK_INT(1LL), 2);
      V v_v_2431 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_2423}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_lam0, 1, 1, (V[]){v_dom_2424}), NTAG(TAG_Nothing)));
      V v_x3_2433 = heff_tr(heff_call(v_f_2428, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_2427, heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_lam1, 1, 1, (V[]){v_v_2431})})}));
      V v_t_2438;
      switch (heff_tag_of(v_x3_2433)) {
      case TAG_Nom: {
        V v_a_2434 = heff_field(v_x3_2433, 0);
        heff_take_n(v_x3_2433, 1ULL, 1);
        v_t_2438 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_2429, v_a_2434));
        break;
      }
      case TAG_Describe: {
        V v_a_2435 = heff_field(v_x3_2433, 0);
        heff_take_n(v_x3_2433, 1ULL, 1);
        v_t_2438 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_2429, v_a_2435));
        break;
      }
      case TAG_Become: {
        V v_a_2436 = heff_field(v_x3_2433, 0);
        V v_ru_24x3_2433_24Become = heff_take_reuse_n(v_x3_2433, 1ULL, 1);
        V v_t_2437 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_2429, v_a_2436));
        v_t_2438 = heff_tag_at_n(v_ru_24x3_2433_24Become, TAG_SIsTy, 1, (V[]){v_t_2437});
        break;
      }
      default: heff_nomatch(v_x3_2433);
      }
      v_t_2445 = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2426, v_t_2438});
      break;
    }
    case TAG_CloConst: {
      V v_t_2439 = heff_field(v_x4_2425, 0);
      V v_ru_24x4_2425_24CloConst = heff_take_reuse_n(v_x4_2425, 1ULL, 1);
      heff_drop(v_dom_2424);
      V v_t_2444;
      switch (heff_tag_of(v_t_2439)) {
      case TAG_Nom: {
        V v_a_2440 = heff_field(v_t_2439, 0);
        heff_take_n(v_t_2439, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_2425_24CloConst, 1);
        v_t_2444 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_2423, v_a_2440));
        break;
      }
      case TAG_Describe: {
        V v_a_2441 = heff_field(v_t_2439, 0);
        heff_take_n(v_t_2439, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_2425_24CloConst, 1);
        v_t_2444 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_2423, v_a_2441));
        break;
      }
      case TAG_Become: {
        V v_a_2442 = heff_field(v_t_2439, 0);
        heff_take_n(v_t_2439, 1ULL, 1);
        V v_t_2443 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_2423, v_a_2442));
        v_t_2444 = heff_tag_at_n(v_ru_24x4_2425_24CloConst, TAG_SIsTy, 1, (V[]){v_t_2443});
        break;
      }
      default: heff_nomatch(v_t_2439);
      }
      v_t_2445 = heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2444});
      break;
    }
    default: heff_nomatch(v_x4_2425);
    }
    return heff_setField(heff_dup(v_d_242), MK_INT(0LL), heff_tag_n(TAG_SFunction, 5, (V[]){v_level_2416, v_t_2422, v_t_2445, v_implicit_2419, v_dflt_2420}));
  }
  case TAG_VRecord: {
    V v_level_2446 = heff_field(v_x3_241, 0);
    V v_capture_2447 = heff_field(v_x3_241, 1);
    V v_fieldTypes_2448 = heff_field(v_x3_241, 2);
    V v_defaults_2449 = heff_field(v_x3_241, 3);
    heff_take_n(v_x3_241, 15ULL, 4);
    V v_t_2450 = heff_arrayToList(heff_take_field(v_fieldTypes_2448, 2));
    V v_t_2451 = (g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591(v_n_240, v_capture_2447, v_t_2450));
    V v_t_2452 = ({ V rv_2 = heff_arrayFromList(v_t_2451); V rr_ = heff_rec_reuse_nf(v_fieldTypes_2448, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_setField(heff_dup(v_d_242), MK_INT(0LL), heff_tag_n(TAG_SRecord, 3, (V[]){v_level_2446, v_t_2452, v_defaults_2449}));
  }
  case TAG_VSum: {
    V v_st_2453 = heff_field(v_x3_241, 0);
    heff_take_n(v_x3_241, 1ULL, 1);
    V v_xs_2454 = heff_take_field(v_st_2453, 2);
    V v_t_2460 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2454, 0), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_lam2, 1, 2, (V[]){v_xs_2454, v_n_240}));
    V v_t_2461 = ({ V rv_2 = v_t_2460; V rr_ = heff_rec_reuse_nf(v_st_2453, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_setField(heff_dup(v_d_242), MK_INT(0LL), heff_tag_n(TAG_SSum, 1, (V[]){v_t_2461}));
  }
  case TAG_VPrimInt: {
    heff_drop(v_n_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(0LL), NTAG(TAG_SPrimInt));
  }
  case TAG_VPrimFloat: {
    heff_drop(v_n_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(0LL), NTAG(TAG_SPrimFloat));
  }
  case TAG_VPrimString: {
    heff_drop(v_n_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(0LL), NTAG(TAG_SPrimString));
  }
  case TAG_VPrimRune: {
    heff_drop(v_n_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(0LL), NTAG(TAG_SPrimRune));
  }
  case TAG_VPrimArray: {
    V v_a_2462 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VPrimArray = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_cell_2463 = heff_tag_at_n(v_ru_24x3_241_24VPrimArray, TAG_SPrimArray, 1, (V[]){heff_hole()});
    V v_u_2464 = heff_setFieldPeek(v_d_242, MK_INT(0LL), v_cell_2463);
    V t_0 = v_n_240;
    V t_1 = v_a_2462;
    V t_2 = v_u_2464;
    v_n_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_VFixed: {
    V v_w_2465 = heff_field(v_x3_241, 0);
    heff_take_n(v_x3_241, 1ULL, 1);
    heff_drop(v_n_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(0LL), heff_tag_n(TAG_SFixed, 1, (V[]){v_w_2465}));
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_lam0(V self, V *args) {
  V v_u_2430 = args[0];
  V v_dom_2424 = heff_env(self)[0];
  heff_drop(v_u_2430);
  heff_clo_take(self, 1);
  return v_dom_2424;
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_lam1(V self, V *args) {
  V v_u_2432 = args[0];
  V v_v_2431 = heff_env(self)[0];
  heff_drop(v_u_2432);
  heff_clo_take(self, 1);
  return v_v_2431;
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_lam3(V self, V *args) {
  V v_i_2457 = args[0];
  V v_xs_2456 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2458 = heff_arrayIndex(v_xs_2456, v_i_2457);
  V v_t_2459 = heff_tr(heff_call(v_t_2458, 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_240, v_t_2459));
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_lam2(V self, V *args) {
  V v_i_2455 = args[0];
  V v_xs_2454 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2456 = heff_arrayIndex(v_xs_2454, v_i_2455);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2456, 0), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_lam3, 1, 2, (V[]){v_xs_2456, v_n_240}));
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_lam1(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_lam2(V self, V *args); static Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_lam2, 1, 0};
Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry, 2, 0};

V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V v_n_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_VNeu: {
    V v_h_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 5);
    return (g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627(v_n_240, v_h_242, v_sp_243));
  }
  case TAG_VCode: {
    V v_a_247 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VCode = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_240, v_a_247));
    return heff_tag_at_n(v_ru_24x3_241_24VCode, TAG_SCode, 1, (V[]){v_t_248});
  }
  case TAG_VLam: {
    V v_fty_249 = heff_field(v_x3_241, 0);
    V v_body_2410 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24VLam = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_fty_249), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2412 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_dup(v_n_240), v_t_2411));
    V v_n_2413 = v_n_240;
    V v_t_2414 = heff_tr(heff_call(v_fty_249, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2415 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2414)));
    V v_dom_2427;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2415, 0ULL, 1);
      v_dom_2427 = v_t_2414;
      break;
    }
    case TAG_LikeFunction: {
      V v_dom_2418 = heff_field(v_t_2415, 1);
      heff_take_n(v_t_2415, 2ULL, 4);
      heff_drop(v_t_2414);
      v_dom_2427 = v_dom_2418;
      break;
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2415, 0ULL, 3);
      v_dom_2427 = v_t_2414;
      break;
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2415, 0ULL, 1);
      v_dom_2427 = v_t_2414;
      break;
    }
    case TAG_LikeInt: {
      v_dom_2427 = v_t_2414;
      break;
    }
    case TAG_LikeFloat: {
      v_dom_2427 = v_t_2414;
      break;
    }
    case TAG_LikeString: {
      v_dom_2427 = v_t_2414;
      break;
    }
    case TAG_LikeRune: {
      v_dom_2427 = v_t_2414;
      break;
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2415, 0ULL, 1);
      v_dom_2427 = v_t_2414;
      break;
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2415, 0ULL, 1);
      v_dom_2427 = v_t_2414;
      break;
    }
    case TAG_NoRules: {
      v_dom_2427 = v_t_2414;
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    V v_x4_2428 = v_body_2410;
    V v_t_2448;
    switch (heff_tag_of(v_x4_2428)) {
    case TAG_MkClo: {
      V v_x_2429 = heff_field(v_x4_2428, 0);
      V v_l_2430 = heff_field(v_x4_2428, 1);
      V v_f_2431 = heff_field(v_x4_2428, 2);
      heff_take_n(v_x4_2428, 7ULL, 3);
      V v_n_2432 = heff_intAdd_lent(v_n_2413, MK_INT(1LL), 2);
      V v_v_2434 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_2413}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_lam0, 1, 1, (V[]){v_dom_2427}), NTAG(TAG_Nothing)));
      V v_x3_2436 = heff_tr(heff_call(v_f_2431, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_2430, heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_lam1, 1, 1, (V[]){v_v_2434})})}));
      V v_t_2441;
      switch (heff_tag_of(v_x3_2436)) {
      case TAG_Nom: {
        V v_v_2437 = heff_field(v_x3_2436, 0);
        heff_take_n(v_x3_2436, 1ULL, 1);
        v_t_2441 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_2432, v_v_2437));
        break;
      }
      case TAG_Describe: {
        V v_v_2438 = heff_field(v_x3_2436, 0);
        heff_take_n(v_x3_2436, 1ULL, 1);
        v_t_2441 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_2432, v_v_2438));
        break;
      }
      case TAG_Become: {
        V v_v_2439 = heff_field(v_x3_2436, 0);
        V v_ru_24x3_2436_24Become = heff_take_reuse_n(v_x3_2436, 1ULL, 1);
        V v_t_2440 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_2432, v_v_2439));
        v_t_2441 = heff_tag_at_n(v_ru_24x3_2436_24Become, TAG_SIs, 1, (V[]){v_t_2440});
        break;
      }
      default: heff_nomatch(v_x3_2436);
      }
      v_t_2448 = heff_tag_at_n(v_ru_24x3_241_24VLam, TAG_MkAbs, 2, (V[]){v_x_2429, v_t_2441});
      break;
    }
    case TAG_CloConst: {
      V v_t_2442 = heff_field(v_x4_2428, 0);
      V v_ru_24x4_2428_24CloConst = heff_take_reuse_n(v_x4_2428, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24VLam, 2);
      heff_drop(v_dom_2427);
      V v_t_2447;
      switch (heff_tag_of(v_t_2442)) {
      case TAG_Nom: {
        V v_v_2443 = heff_field(v_t_2442, 0);
        heff_take_n(v_t_2442, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_2428_24CloConst, 1);
        v_t_2447 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_2413, v_v_2443));
        break;
      }
      case TAG_Describe: {
        V v_v_2444 = heff_field(v_t_2442, 0);
        heff_take_n(v_t_2442, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_2428_24CloConst, 1);
        v_t_2447 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_2413, v_v_2444));
        break;
      }
      case TAG_Become: {
        V v_v_2445 = heff_field(v_t_2442, 0);
        heff_take_n(v_t_2442, 1ULL, 1);
        V v_t_2446 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_2413, v_v_2445));
        v_t_2447 = heff_tag_at_n(v_ru_24x4_2428_24CloConst, TAG_SIs, 1, (V[]){v_t_2446});
        break;
      }
      default: heff_nomatch(v_t_2442);
      }
      v_t_2448 = heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2447});
      break;
    }
    default: heff_nomatch(v_x4_2428);
    }
    return heff_tag_n(TAG_SLam, 2, (V[]){v_t_2412, v_t_2448});
  }
  case TAG_VCons: {
    V v_d_2449 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VCons = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_xs_2450 = heff_take_field(v_d_2449, 2);
    V v_m_2451 = heff_arrayLength_lent(v_xs_2450, 0);
    V v_t_2460;
    if ((heff_peek_word(v_m_2451) <= ((int64_t)0ULL))) {
      heff_drop(v_n_240);
      heff_drop_cell(v_ru_24x3_241_24VCons, 1);
      heff_drop(v_xs_2450);
      v_t_2460 = heff_arrayGenerate(v_m_2451, ((V)&g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_lam2_clo));
    } else {
      V v_x3_2453 = heff_arrayIndex_lent(v_xs_2450, MK_INT(0LL), 2);
      V v_y_2458;
      switch (heff_tag_of(v_x3_2453)) {
      case TAG_Nom: {
        V v_v_2454 = heff_field(v_x3_2453, 0);
        heff_take_n(v_x3_2453, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24VCons, 1);
        v_y_2458 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_240), v_v_2454));
        break;
      }
      case TAG_Describe: {
        V v_v_2455 = heff_field(v_x3_2453, 0);
        heff_take_n(v_x3_2453, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24VCons, 1);
        v_y_2458 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_240), v_v_2455));
        break;
      }
      case TAG_Become: {
        V v_v_2456 = heff_field(v_x3_2453, 0);
        heff_take_n(v_x3_2453, 1ULL, 1);
        V v_t_2457 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_240), v_v_2456));
        v_y_2458 = heff_tag_at_n(v_ru_24x3_241_24VCons, TAG_SIs, 1, (V[]){v_t_2457});
        break;
      }
      default: heff_nomatch(v_x3_2453);
      }
      V v_t_2459 = heff_arrayKeepsAs_lent(v_xs_2450, v_y_2458, 0);
      if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
        heff_drop(v_m_2451);
        heff_drop(v_t_2459);
        v_t_2460 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24map0(v_n_240, MK_INT(1LL), heff_arraySet(v_xs_2450, MK_INT(0LL), v_y_2458)));
      } else {
        heff_drop(v_t_2459);
        v_t_2460 = ({ V a_0 = v_xs_2450; V a_1 = v_n_240; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2451, v_y_2458); V r_ = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24generate0(a_0, a_1, a_2, a_3)); heff_drop(v_xs_2450); r_; });
      }
    }
    V v_t_2461 = ({ V rv_2 = v_t_2460; V rr_ = heff_rec_reuse_nf(v_d_2449, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_SCons, 1, (V[]){v_t_2461});
  }
  case TAG_VOpaque: {
    heff_drop(v_n_240);
    return NTAG(TAG_SOpaque);
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(a[0], a[1]);
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_lam0(V self, V *args) {
  V v_u_2433 = args[0];
  V v_dom_2427 = heff_env(self)[0];
  heff_drop(v_u_2433);
  heff_clo_take(self, 1);
  return v_dom_2427;
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_lam1(V self, V *args) {
  V v_u_2435 = args[0];
  V v_v_2434 = heff_env(self)[0];
  heff_drop(v_u_2435);
  heff_clo_take(self, 1);
  return v_v_2434;
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_lam2(V self, V *args) {
  V v_u_2452 = args[0];
  heff_drop(v_u_2452);
  return heff_abandon();
}
Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24generate0_entry, 4, 0};

V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24generate0(V v_xs_240, V v_n_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_x3_244 = heff_arrayPeekIn(v_xs_240, heff_box_word(v_i_242));
      V v_t_249;
      switch (heff_tag_of(v_x3_244)) {
      case TAG_Nom: {
        V v_v_245 = heff_field(v_x3_244, 0);
        v_t_249 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_241), heff_dup(v_v_245)));
        break;
      }
      case TAG_Describe: {
        V v_v_246 = heff_field(v_x3_244, 0);
        v_t_249 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_241), heff_dup(v_v_246)));
        break;
      }
      case TAG_Become: {
        V v_v_247 = heff_field(v_x3_244, 0);
        V v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_241), heff_dup(v_v_247)));
        v_t_249 = heff_tag_n(TAG_SIs, 1, (V[]){v_t_248});
        break;
      }
      default: heff_nomatch(v_x3_244);
      }
      V t_0 = v_xs_240;
      V t_1 = v_n_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_249);
      v_xs_240 = t_0;
      v_n_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      heff_drop(v_n_241);
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_x3_244 = heff_arrayPeek(v_xs_240, heff_box_word(v_i_242));
    V v_t_249;
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nom: {
      V v_v_245 = heff_field(v_x3_244, 0);
      v_t_249 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_241), heff_dup(v_v_245)));
      break;
    }
    case TAG_Describe: {
      V v_v_246 = heff_field(v_x3_244, 0);
      v_t_249 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_241), heff_dup(v_v_246)));
      break;
    }
    case TAG_Become: {
      V v_v_247 = heff_field(v_x3_244, 0);
      V v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_241), heff_dup(v_v_247)));
      v_t_249 = heff_tag_n(TAG_SIs, 1, (V[]){v_t_248});
      break;
    }
    default: heff_nomatch(v_x3_244);
    }
    V t_0 = v_xs_240;
    V t_1 = v_n_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_249);
    v_xs_240 = t_0;
    v_n_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    heff_drop(v_n_241);
    return v_a_243;
  }
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24generate0(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24map0_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24map0(V v_n_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_x3_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_t_248;
      switch (heff_tag_of(v_x3_243)) {
      case TAG_Nom: {
        V v_v_244 = heff_field(v_x3_243, 0);
        heff_take_n(v_x3_243, 1ULL, 1);
        v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_240), v_v_244));
        break;
      }
      case TAG_Describe: {
        V v_v_245 = heff_field(v_x3_243, 0);
        heff_take_n(v_x3_243, 1ULL, 1);
        v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_240), v_v_245));
        break;
      }
      case TAG_Become: {
        V v_v_246 = heff_field(v_x3_243, 0);
        V v_ru_24x3_243_24Become = heff_take_reuse_n(v_x3_243, 1ULL, 1);
        V v_t_247 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_240), v_v_246));
        v_t_248 = heff_tag_at_n(v_ru_24x3_243_24Become, TAG_SIs, 1, (V[]){v_t_247});
        break;
      }
      default: heff_nomatch(v_x3_243);
      }
      V t_0 = v_n_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_248);
      v_n_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      heff_drop(v_n_240);
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_x3_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_t_248;
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nom: {
      V v_v_244 = heff_field(v_x3_243, 0);
      heff_take_n(v_x3_243, 1ULL, 1);
      v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_240), v_v_244));
      break;
    }
    case TAG_Describe: {
      V v_v_245 = heff_field(v_x3_243, 0);
      heff_take_n(v_x3_243, 1ULL, 1);
      v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_240), v_v_245));
      break;
    }
    case TAG_Become: {
      V v_v_246 = heff_field(v_x3_243, 0);
      V v_ru_24x3_243_24Become = heff_take_reuse_n(v_x3_243, 1ULL, 1);
      V v_t_247 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_dup(v_n_240), v_v_246));
      v_t_248 = heff_tag_at_n(v_ru_24x3_243_24Become, TAG_SIs, 1, (V[]){v_t_247});
      break;
    }
    default: heff_nomatch(v_x3_243);
    }
    V t_0 = v_n_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_248);
    v_n_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    heff_drop(v_n_240);
    return v_a_242;
  }
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24map0_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_24map0(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2ereadback_2eappliedOnly_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2eappliedOnly_entry, 1, 0};

V g_heff_2eelab_2ereadback_2eappliedOnly(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return NTAG(TAG_True);
  }
  case TAG_SpApp: {
    V v_sp_241 = heff_field(v_x1_240, 0);
    V t_0 = v_sp_241;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SpProj: {
    return NTAG(TAG_False);
  }
  case TAG_SpSpec: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2ereadback_2eappliedOnly_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2ereadback_2eappliedOnly(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2ereadback_2eshownForcedRb_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2eshownForcedRb_entry, 1, 0};

V g_heff_2eelab_2ereadback_2eshownForcedRb(V v_mc_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2ereadback_2eshownForcedRb_24cpr(v_mc_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_el__ty, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2eelab_2ereadback_2eshownForcedRb_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2ereadback_2eshownForcedRb(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885(V v_n_240, V v_h_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_HLocal: {
    V v_t_249;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_244 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_245 = heff_intSub(heff_intSub_lent(v_n_240, v_i_244, 2), MK_INT(1LL));
      v_t_249 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_245});
      break;
    }
    case TAG_HGlobal: {
      V v_x_246 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_249 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_246});
      break;
    }
    case TAG_HMeta: {
      V v_m_247 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_248 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_249 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_247, heff_dup(g_array_2eempty_get()), v_t_248});
      break;
    }
    case TAG_HError: {
      v_t_249 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001(v_n_240, v_sp_242, v_t_249);
  }
  case TAG_HGlobal: {
    V v_t_2416;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2411 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2412 = heff_intSub(heff_intSub_lent(v_n_240, v_i_2411, 2), MK_INT(1LL));
      v_t_2416 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2413 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2416 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2413});
      break;
    }
    case TAG_HMeta: {
      V v_m_2414 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2415 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2416 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2414, heff_dup(g_array_2eempty_get()), v_t_2415});
      break;
    }
    case TAG_HError: {
      v_t_2416 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001(v_n_240, v_sp_242, v_t_2416);
  }
  case TAG_HMeta: {
    V v_m_2417 = heff_field(v_h_241, 0);
    V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
    HeffT2 v_t_2418 = (g_heff_2eelab_2ereadback_2elocalArgs_24cpr(heff_dup(v_sp_242)));
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        heff_drop(v_sp_242);
        V v_idxs_2421 = v_field_2420;
        V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_idxs_2421));
        V v_t_2423 = (g_list_2emap_24s1947501783x1475115781(v_n_240, MK_INT(1LL), v_t_2422));
        V v_t_2424 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
        return heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_arrayFromList(v_t_2423), v_t_2424});
      } else {
        heff_drop(v_field_2420);
        V v_t_2425 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
        HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001(v_n_240, v_sp_242, heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_dup(g_array_2eempty_get()), v_t_2425}));
      }
    }
  }
  case TAG_HError: {
    V v_t_2431;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2426 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2427 = heff_intSub(heff_intSub_lent(v_n_240, v_i_2426, 2), MK_INT(1LL));
      v_t_2431 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2427});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2428 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2431 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2428});
      break;
    }
    case TAG_HMeta: {
      V v_m_2429 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2430 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2431 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2429, heff_dup(g_array_2eempty_get()), v_t_2430});
      break;
    }
    case TAG_HError: {
      v_t_2431 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001(v_n_240, v_sp_242, v_t_2431);
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24map0_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24map0(V v_n_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_x3_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_t_248;
      switch (heff_tag_of(v_x3_243)) {
      case TAG_Nom: {
        V v_v_244 = heff_field(v_x3_243, 0);
        heff_take_n(v_x3_243, 1ULL, 1);
        v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_240), v_v_244));
        break;
      }
      case TAG_Describe: {
        V v_v_245 = heff_field(v_x3_243, 0);
        heff_take_n(v_x3_243, 1ULL, 1);
        v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_240), v_v_245));
        break;
      }
      case TAG_Become: {
        V v_v_246 = heff_field(v_x3_243, 0);
        V v_ru_24x3_243_24Become = heff_take_reuse_n(v_x3_243, 1ULL, 1);
        V v_t_247 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_240), v_v_246));
        v_t_248 = heff_tag_at_n(v_ru_24x3_243_24Become, TAG_SIs, 1, (V[]){v_t_247});
        break;
      }
      default: heff_nomatch(v_x3_243);
      }
      V t_0 = v_n_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_248);
      v_n_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      heff_drop(v_n_240);
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_x3_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_t_248;
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nom: {
      V v_v_244 = heff_field(v_x3_243, 0);
      heff_take_n(v_x3_243, 1ULL, 1);
      v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_240), v_v_244));
      break;
    }
    case TAG_Describe: {
      V v_v_245 = heff_field(v_x3_243, 0);
      heff_take_n(v_x3_243, 1ULL, 1);
      v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_240), v_v_245));
      break;
    }
    case TAG_Become: {
      V v_v_246 = heff_field(v_x3_243, 0);
      V v_ru_24x3_243_24Become = heff_take_reuse_n(v_x3_243, 1ULL, 1);
      V v_t_247 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_240), v_v_246));
      v_t_248 = heff_tag_at_n(v_ru_24x3_243_24Become, TAG_SIs, 1, (V[]){v_t_247});
      break;
    }
    default: heff_nomatch(v_x3_243);
    }
    V t_0 = v_n_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_248);
    v_n_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    heff_drop(v_n_240);
    return v_a_242;
  }
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24map0_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24map0(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001(V v_n_240, V v_x3_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_SpId: {
    heff_drop(v_n_240);
    return v_t_242;
  }
  case TAG_SpApp: {
    V v_sp_243 = heff_field(v_x3_241, 0);
    V v_v_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24SpApp = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = (g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001(heff_dup(v_n_240), v_sp_243, v_t_242));
    V v_t_246 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(v_n_240, v_v_244));
    return heff_tag_at_n(v_ru_24x3_241_24SpApp, TAG_SApp, 2, (V[]){v_t_245, v_t_246});
  }
  case TAG_SpProj: {
    V v_sp_247 = heff_field(v_x3_241, 0);
    V v_x_248 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24SpProj = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_249 = (g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001(v_n_240, v_sp_247, v_t_242));
    return heff_tag_at_n(v_ru_24x3_241_24SpProj, TAG_SProj, 2, (V[]){v_t_249, v_x_248});
  }
  case TAG_SpSpec: {
    V v_sp_2410 = heff_field(v_x3_241, 0);
    V v_x_2411 = heff_field(v_x3_241, 1);
    V v_v_2412 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24SpSpec = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    V v_t_2413 = (g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001(heff_dup(v_n_240), v_sp_2410, v_t_242));
    V v_t_2414 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(v_n_240, v_v_2412));
    return heff_tag_at_n(v_ru_24x3_241_24SpSpec, TAG_SSpecialize, 3, (V[]){v_t_2413, v_x_2411, v_t_2414});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001(a[0], a[1], a[2]);
}