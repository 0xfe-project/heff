// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
HeffT2 g_json_2elocated_2epositionFrom_240_24cpr(V, V, V, V, V);

HeffT2 g_json_2elocated_2epositionFrom_240_24cpr(V v_i_240, V v_s_241, V v_box_24j_242, V v_l_243, V v_c_244) {
  int64_t v_j_242 = heff_unbox_word(v_box_24j_242);
top: ;
  if ((heff_intLe_c_lent(v_i_240, heff_box_word(v_j_242), 2) || (heff_unbox_word(heff_strLength_lent(v_s_241, 0)) <= v_j_242))) {
    heff_drop(v_i_240);
    return ((HeffT2){{v_l_243, v_c_244}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_241, heff_box_word(v_j_242), 2)) == ((int64_t)10ULL))) {
      heff_drop(v_c_244);
      V t_0 = v_i_240;
      V t_1 = v_s_241;
      int64_t t_2 = (v_j_242 + ((int64_t)1ULL));
      V t_3 = heff_intAdd(v_l_243, MK_INT(1LL));
      V t_4 = MK_INT(1LL);
      v_i_240 = t_0;
      v_s_241 = t_1;
      v_j_242 = t_2;
      v_l_243 = t_3;
      v_c_244 = t_4;
      goto top;
    } else {
      V v_b_245 = heff_strByteAt_lent(v_s_241, heff_box_word(v_j_242), 2);
      if (((((int64_t)128ULL) <= heff_peek_word(v_b_245)) && (heff_peek_word(v_b_245) < ((int64_t)192ULL)))) {
        heff_drop(v_b_245);
        V t_0 = v_i_240;
        V t_1 = v_s_241;
        int64_t t_2 = (v_j_242 + ((int64_t)1ULL));
        V t_3 = v_l_243;
        V t_4 = v_c_244;
        v_i_240 = t_0;
        v_s_241 = t_1;
        v_j_242 = t_2;
        v_l_243 = t_3;
        v_c_244 = t_4;
        goto top;
      } else {
        heff_drop(v_b_245);
        V t_0 = v_i_240;
        V t_1 = v_s_241;
        int64_t t_2 = (v_j_242 + ((int64_t)1ULL));
        V t_3 = v_l_243;
        V t_4 = heff_intAdd(v_c_244, MK_INT(1LL));
        v_i_240 = t_0;
        v_s_241 = t_1;
        v_j_242 = t_2;
        v_l_243 = t_3;
        v_c_244 = t_4;
        goto top;
      }
    }
  }
}