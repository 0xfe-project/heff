// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Large 60129
#define TAG_Small 51389
#define TAG_TopL 65516
#define LBL_end 310101
#define LBL_len 316559
#define LBL_names 305943394
#define LBL_start 311115900
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
Clo g_heff_2eelab_2eparams_2eeqLevel_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eparams_2eeqLevel_entry, 2, 0};

V g_heff_2eelab_2eparams_2eeqLevel(V v_a_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_a_240)) {
  case TAG_Small: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_Small: {
      return NTAG(TAG_True);
    }
    case TAG_Large: {
      switch (heff_tag_of(v_a_240)) {
      case TAG_Small: {
        return NTAG(TAG_False);
      }
      case TAG_Large: {
        return NTAG(TAG_True);
      }
      case TAG_TopL: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_a_240);
      }
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_a_240)) {
      case TAG_Small: {
        return NTAG(TAG_False);
      }
      case TAG_Large: {
        return NTAG(TAG_False);
      }
      case TAG_TopL: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_a_240);
      }
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  case TAG_Large: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_Small: {
      return NTAG(TAG_False);
    }
    case TAG_Large: {
      switch (heff_tag_of(v_b_241)) {
      case TAG_Small: {
        return NTAG(TAG_True);
      }
      case TAG_Large: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_True);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      case TAG_TopL: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_False);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_b_241)) {
      case TAG_Small: {
        return NTAG(TAG_True);
      }
      case TAG_Large: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_True);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      case TAG_TopL: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_False);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  case TAG_TopL: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_Small: {
      return NTAG(TAG_False);
    }
    case TAG_Large: {
      return NTAG(TAG_False);
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_b_241)) {
      case TAG_Small: {
        return NTAG(TAG_True);
      }
      case TAG_Large: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_True);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      case TAG_TopL: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_False);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  default: return heff_nomatch(v_a_240);
  }
}
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eparams_2eeqLevel(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_REC_LIT(g_heff_2eelab_2eparams_2enoSpan_lit0, 2, shape_start__end, MK_INT(0LL), MK_INT(0LL));

static V g_heff_2eelab_2eparams_2enoSpan_val;
static HEFF_ONCE g_heff_2eelab_2eparams_2enoSpan_st;
static V g_heff_2eelab_2eparams_2enoSpan_init(void) {
  return ((V)&g_heff_2eelab_2eparams_2enoSpan_lit0);
}
V g_heff_2eelab_2eparams_2enoSpan_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eparams_2enoSpan_st)) return g_heff_2eelab_2eparams_2enoSpan_val;
  return heff_global(&g_heff_2eelab_2eparams_2enoSpan_val, &g_heff_2eelab_2eparams_2enoSpan_st, g_heff_2eelab_2eparams_2enoSpan_init);
}
HEFF_REC_LIT(g_heff_2eelab_2eparams_2eemptyShape_lit0, 2, shape_len__names, MK_INT(0LL), NTAG(TAG_Nil));

static V g_heff_2eelab_2eparams_2eemptyShape_val;
static HEFF_ONCE g_heff_2eelab_2eparams_2eemptyShape_st;
static V g_heff_2eelab_2eparams_2eemptyShape_init(void) {
  return ((V)&g_heff_2eelab_2eparams_2eemptyShape_lit0);
}
V g_heff_2eelab_2eparams_2eemptyShape_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eparams_2eemptyShape_st)) return g_heff_2eelab_2eparams_2eemptyShape_val;
  return heff_global(&g_heff_2eelab_2eparams_2eemptyShape_val, &g_heff_2eelab_2eparams_2eemptyShape_st, g_heff_2eelab_2eparams_2eemptyShape_init);
}