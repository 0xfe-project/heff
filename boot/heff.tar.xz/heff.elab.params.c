// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_Describe 2650
#define TAG_Large 60129
#define TAG_Nom 25944
#define TAG_Small 51389
#define TAG_TopL 65516
#define LBL_byName 571997869
#define LBL_end 310101
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_names 305943394
#define LBL_start 311115900
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834(V);
V g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_clo;
Clo g_heff_2eelab_2eparams_2eeqLevel_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eparams_2eeqLevel_entry, 2, 0};

V g_heff_2eelab_2eparams_2eeqLevel(V v_a_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_a_240)) {
  case TAG_Small: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_Small: {
      return NTAG(TAG_True);
    }
    case TAG_Large: {
      switch (heff_tag_of(v_a_240)) {
      case TAG_Small: {
        return NTAG(TAG_False);
      }
      case TAG_Large: {
        return NTAG(TAG_True);
      }
      case TAG_TopL: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_a_240);
      }
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_a_240)) {
      case TAG_Small: {
        return NTAG(TAG_False);
      }
      case TAG_Large: {
        return NTAG(TAG_False);
      }
      case TAG_TopL: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_a_240);
      }
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  case TAG_Large: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_Small: {
      return NTAG(TAG_False);
    }
    case TAG_Large: {
      switch (heff_tag_of(v_b_241)) {
      case TAG_Small: {
        return NTAG(TAG_True);
      }
      case TAG_Large: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_True);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      case TAG_TopL: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_False);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_b_241)) {
      case TAG_Small: {
        return NTAG(TAG_True);
      }
      case TAG_Large: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_True);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      case TAG_TopL: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_False);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  case TAG_TopL: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_Small: {
      return NTAG(TAG_False);
    }
    case TAG_Large: {
      return NTAG(TAG_False);
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_b_241)) {
      case TAG_Small: {
        return NTAG(TAG_True);
      }
      case TAG_Large: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_True);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      case TAG_TopL: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_False);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  default: return heff_nomatch(v_a_240);
  }
}
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eparams_2eeqLevel(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

static V g_heff_2eelab_2eparams_2enoSpan_val;
static HEFF_ONCE g_heff_2eelab_2eparams_2enoSpan_st;
static V g_heff_2eelab_2eparams_2enoSpan_init(void) {
  return heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2eelab_2eparams_2enoSpan_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eparams_2enoSpan_st)) return g_heff_2eelab_2eparams_2enoSpan_val;
  return heff_global(&g_heff_2eelab_2eparams_2enoSpan_val, &g_heff_2eelab_2eparams_2enoSpan_st, g_heff_2eelab_2eparams_2enoSpan_init);
}

static V g_heff_2eelab_2eparams_2eemptyShape_val;
static HEFF_ONCE g_heff_2eelab_2eparams_2eemptyShape_st;
static V g_heff_2eelab_2eparams_2eemptyShape_init(void) {
  return heff_rec_n(2, shape_len__names, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2eparams_2eemptyShape_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eparams_2eemptyShape_st)) return g_heff_2eelab_2eparams_2eemptyShape_val;
  return heff_global(&g_heff_2eelab_2eparams_2eemptyShape_val, &g_heff_2eelab_2eparams_2eemptyShape_st, g_heff_2eelab_2eparams_2eemptyShape_init);
}
V g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_lam2(V self, V *args);
V g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_lam1(V self, V *args);
V g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_lam0(V self, V *args);
Clo g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_entry, 1, 0};

V g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834(V v_vs_240) {
top: ;
  V v_keys_241 = heff_take_field(v_vs_240, 0);
  V v_byName_242 = heff_take_field(v_vs_240, 1);
  V v_values_243 = heff_get_n(v_vs_240, 2, 3);
  V v_xs_244 = v_values_243;
  V v_t_2414 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_244, 0), heff_clo_n(g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_lam0, 1, 1, (V[]){v_xs_244}));
  return heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_241, v_byName_242, v_t_2414});
}
V g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834(a[0]);
}
V g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_lam2(V self, V *args) {
  V v_u2_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_249);
  V v_x1_2410 = heff_tr(heff_call(heff_get_n(v_m_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nom: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    return v_x_2411;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2410, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2413 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    return v_x_2413;
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
V g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_lam1(V self, V *args) {
  V v_i_247 = args[0];
  V v_xs_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_248 = heff_arrayIndex(v_xs_246, v_i_247);
  return heff_clo_n(g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_lam2, 1, 1, (V[]){v_m_248});
}
V g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_xs_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_246 = heff_arrayIndex(v_xs_244, v_i_245);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_246, 0), heff_clo_n(g_heff_2eelab_2eparams_2evariantsMap_24s1465188104x856893834_lam1, 1, 1, (V[]){v_xs_246}));
}