// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_MakeDirectory 16793
#define TAG_NotRun 12703
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_WorkingDir 28879
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_backend 2032133329
#define LBL_build 295453320
#define LBL_copies 592412158
#define LBL_effect 641056956
#define LBL_emits 297985818
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_files 298792593
#define LBL_groups 709681407
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_limit 304334805
#define LBL_mods 9852536
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_olds 9909235
#define LBL_out 319944
#define LBL_outcome 1272833429
#define LBL_own 320000
#define LBL_owner 307523277
#define LBL_pages 307784670
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_place 308106529
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_shipTo 1043811586
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
static uint32_t shape_ended__out__err[] = {LBL_ended, LBL_out, LBL_err};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_owner__place__outcome__next[] = {LBL_owner, LBL_place, LBL_outcome, LBL_next};
V g_co_2eop_24s11399370x647848365(V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s11399370x647848365_entry(V self, V *a);
extern Clo g_co_2eop_24s11399370x647848365_clo;
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s1105330941x1846751788(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s1105330941x1846751788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s1105330941x1846751788_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_clo;
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924_clo;
V g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_clo;
V g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_clo;
V g_heff_2ebuild_2ecommands_2ejsonGolden(V);
V g_heff_2ebuild_2ecommands_2ejsonGolden_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsonGolden_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_clo;
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(V);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_clo;
V g_heff_2ebuild_2ecommands_2eranOutcome(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eranOutcome_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranOutcome_clo;
V g_heff_2ebuild_2ecommands_2eranSubtests(V);
V g_heff_2ebuild_2ecommands_2eranSubtests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranSubtests_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_clo;
V g_heff_2ebuild_2ecommands_2esubtestJobs(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esubtestJobs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esubtestJobs_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_clo;
V g_heff_2ebuild_2ecommands_2ezigOf(V);
V g_heff_2ebuild_2ecommands_2ezigOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigOf_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eevaluate(V);
V g_heff_2ebuild_2edriver_2eevaluate_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevaluate_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V, V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
V g_list_2eany_24s469495312x865582084(V);
V g_list_2eany_24s469495312x865582084_entry(V self, V *a);
extern Clo g_list_2eany_24s469495312x865582084_clo;
V g_list_2eany_24s529567056x880977707(V, V, V);
V g_list_2eany_24s529567056x880977707_entry(V self, V *a);
extern Clo g_list_2eany_24s529567056x880977707_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24f1668687542x1574966783(V, V, V, V);
V g_list_2efilter_24f1668687542x1574966783_entry(V self, V *a);
extern Clo g_list_2efilter_24f1668687542x1574966783_clo;
V g_list_2efilter_24s794048906x2073543501(V, V);
V g_list_2efilter_24s794048906x2073543501_entry(V self, V *a);
extern Clo g_list_2efilter_24s794048906x2073543501_clo;
V g_list_2efoldl_24s477184376x1963488659(V, V);
V g_list_2efoldl_24s477184376x1963488659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s477184376x1963488659_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s86307863x1047527532(V, V);
V g_list_2efoldl_24s86307863x1047527532_entry(V self, V *a);
extern Clo g_list_2efoldl_24s86307863x1047527532_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enormalize(V, V);
V g_std_2epath_2enormalize_entry(V self, V *a);
extern Clo g_std_2epath_2enormalize_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str8, 1, "$");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_245 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_242, 0)), v_t_248)) {
      V v_t_2410 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_text_2412 = heff_dup(heff_rfield(v_p_242, 1));
      V v_t_2413 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str6); V a_1 = v_text_2412; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str7), v_text_2412, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_2412); r_; });
      V v_t_2414 = (g_list_2emap_24s732475005x1616712052(v_t_2413));
      V v_t_2415 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str8); V a_3 = v_t_2414; V r_ = (g_list_2efilter_24f1668687542x1574966783(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
      V v_t_2416 = ({ V a_0 = v_t_2411; V a_1 = v_t_2415; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2411); heff_drop(v_t_2415); r_; });
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_k_241);
        heff_drop(v_t_2416);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2416);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeaf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigOf_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigOf_str1, 8, "heff.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigOf_str2, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigOf_str3, 4, ".zig");
Clo g_heff_2ebuild_2ecommands_2ezigOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ezigOf(V v_outPath_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)1ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_241), heff_strLength_lent(v_outPath_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2ebuild_2ecommands_2ezigOf_str0))) {
    return heff_strAppend(v_outPath_240, ((V)&g_heff_2ebuild_2ecommands_2ezigOf_str1));
  } else {
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    V v_t_245 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_244), heff_strLength_lent(v_outPath_240, 0));
    V v_t_248;
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2ezigOf_str2))) {
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
      v_t_248 = heff_strSlice(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_247));
    } else {
      v_t_248 = v_outPath_240;
    }
    return heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2ezigOf_str3));
  }
}
V g_heff_2ebuild_2ecommands_2ezigOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigOf(a[0]);
}

static V g_heff_2ebuild_2ecommands_2enoRes_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2enoRes_st;
static V g_heff_2ebuild_2ecommands_2enoRes_init(void) {
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2ebuild_2ecommands_2enoRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2enoRes_st)) return g_heff_2ebuild_2ecommands_2enoRes_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2enoRes_val, &g_heff_2ebuild_2ecommands_2enoRes_st, g_heff_2ebuild_2ecommands_2enoRes_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str24, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str25, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str27, 0, "");
Clo g_heff_2ebuild_2ecommands_2ejsonGolden_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsonGolden_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ejsonGolden(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_JNull: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str0), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str1)});
  }
  case TAG_JBool: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str2), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str3)});
  }
  case TAG_JInt: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str4), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str5)});
  }
  case TAG_JFloat: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str6), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str7)});
  }
  case TAG_JString: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str8), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str9)});
  }
  case TAG_JArray: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str10), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str11)});
    }
    case TAG_Cons: {
      V v_n_246 = heff_field(v_x11_245, 0);
      V v_x112_247 = heff_field(v_x11_245, 1);
      switch (heff_tag_of(v_x112_247)) {
      case TAG_Nil: {
        return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str12), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str13)});
      }
      case TAG_Cons: {
        V v_t_248 = heff_field(v_x112_247, 0);
        V v_t_2416;
        switch (heff_tag_of(v_n_246)) {
        case TAG_JNull: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str14);
          break;
        }
        case TAG_JBool: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str15);
          break;
        }
        case TAG_JInt: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str16);
          break;
        }
        case TAG_JFloat: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str17);
          break;
        }
        case TAG_JString: {
          V v_t_2413 = heff_field(v_n_246, 0);
          v_t_2416 = heff_dup(v_t_2413);
          break;
        }
        case TAG_JArray: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str18);
          break;
        }
        case TAG_JObject: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str19);
          break;
        }
        default: heff_nomatch(v_n_246);
        }
        V v_t_2423;
        switch (heff_tag_of(v_t_248)) {
        case TAG_JNull: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str20);
          break;
        }
        case TAG_JBool: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str21);
          break;
        }
        case TAG_JInt: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str22);
          break;
        }
        case TAG_JFloat: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str23);
          break;
        }
        case TAG_JString: {
          V v_t_2420 = heff_field(v_t_248, 0);
          v_t_2423 = heff_dup(v_t_2420);
          break;
        }
        case TAG_JArray: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str24);
          break;
        }
        case TAG_JObject: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str25);
          break;
        }
        default: heff_nomatch(v_t_248);
        }
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_t_2423});
      }
      default: return heff_nomatch(v_x112_247);
      }
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  case TAG_JObject: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str26), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str27)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ejsonGolden_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ejsonGolden(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_sources_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484(heff_dup(v_sources_240), v_m_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_lam1, 2, 3, (V[]){v_c_246, v_sources_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_t_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669(v_sources_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_lam3, 1, 2, (V[]){v_x_249, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_str1, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_str2, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_str3, 8, "heff.zig");
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182(V v_bi_240, V v_dir_241, V v_zig_242, V v_id_243, V v_texts_244, V v_backs_245, V v_done_246, V v_out_247, V v_z_248, V v_z_249) {
top: ;
  V v_t_2431;
  if (heff_strEq_c_lent(v_id_243, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_str0), 2)) {
    heff_drop_rec(v_bi_240, 3);
    heff_drop(v_id_243);
    heff_drop(v_backs_245);
    v_t_2431 = v_done_246;
  } else {
    V v_ps_2411 = heff_dup(heff_rfield(v_bi_240, 0));
    V v_d_2412 = (g_std_2epath_2ejoin(heff_rfield(v_ps_2411, 5), heff_take_field(v_ps_2411, 0), ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_str1)));
    V v_path_2413 = ({ V b_0 = heff_get_n(v_ps_2411, 5, 6); V a_1 = v_d_2412; V a_2 = heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get()); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    v_t_2431 = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_lam0, 2, 7, (V[]){v_path_2413, heff_dup(v_texts_244), v_bi_240, heff_dup(v_out_247), v_id_243, v_backs_245, v_done_246});
  }
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_str3), v_zig_242}), heff_take_field(v_out_247, 0)});
  V v_t_2433 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2432, heff_get_n(v_out_247, 1, 5)});
  return (g_heff_2ebuild_2ecommands_2ewriteParts_24s611303179x1037039601(v_dir_241, v_t_2431, v_t_2433, v_z_248, v_z_249));
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7], a[8], a[9]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_lam1(V self, V *args) {
  V v_ok_2416 = args[0];
  return v_ok_2416;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_done_246 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2430);
  V f_ = v_done_246;
  heff_room[0] = v_hd_2414;
  heff_room[1] = v_k_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_texts_244 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_out_247 = heff_env(self)[2];
  V v_id_243 = heff_env(self)[3];
  V v_backs_245 = heff_env(self)[4];
  V v_hd_2414 = heff_env(self)[5];
  V v_done_246 = heff_env(self)[6];
  V v_k_2415 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2423);
  V v_t_2424 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_texts_244; V r_ = (g_list_2efoldl_24s86307863x1047527532(a_0, a_1)); heff_drop(v_texts_244); r_; });
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_str2), heff_take_field(v_bi_240, 2)});
  V v_t_2426 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s477184376x1963488659(a_0, a_1)); heff_drop_tag(v_t_2425, 2); r_; });
  V v_t_2427 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){heff_take_field(v_out_247, 2), heff_take_field(v_out_247, 3), heff_get_n(v_out_247, 4, 5), NTAG(TAG_Nil)});
  V v_t_2428 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_243, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2426, v_backs_245}), v_t_2427));
  V v_c_2429 = ({ V a_0 = heff_get_n(v_bi_240, 0, 3); V a_1 = v_t_2424; V a_2 = v_t_2428; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587(a_0, a_1, a_2)); heff_drop(v_t_2424); heff_drop(v_t_2428); r_; });
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_hd_2414);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_lam3, 1, 3, (V[]){v_done_246, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_path_2413 = heff_env(self)[0];
  V v_texts_244 = heff_env(self)[1];
  V v_bi_240 = heff_env(self)[2];
  V v_out_247 = heff_env(self)[3];
  V v_id_243 = heff_env(self)[4];
  V v_backs_245 = heff_env(self)[5];
  V v_done_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_2413, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_lam1_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_lam2, 1, 8, (V[]){v_texts_244, v_bi_240, v_out_247, v_id_243, v_backs_245, v_hd_2414, v_done_246, v_k_2415})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_str0, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_str1, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_str2, 3, " / ");
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021(V v_sel_240, V v_j_241, V v_dir_242, V v_ran_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_dir_242), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam1, 1, 6, (V[]){v_dir_242, v_hd_244, v_j_241, v_ran_243, heff_dup(v_sel_240), v_k_245})));
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam0(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam4(V self, V *args) {
  V v_ok_2423 = args[0];
  return v_ok_2423;
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_j_241 = heff_env(self)[0];
  V v_ran_243 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  V v_sel_240 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2431);
  V v_t_2432 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_str2), heff_dup(heff_rfield(v_j_241, 3)), heff_rfield(v_j_241, 4)));
  V v_t_2433 = (g_heff_2ebuild_2ecommands_2eranOutcome(v_t_2432, heff_dup(heff_rfield(v_j_241, 5)), v_ran_243, heff_dup(v_x_2422)));
  V v_t_2434 = ({ V a_0 = v_x_2422; V r_ = (g_heff_2ebuild_2ecommands_2eranSubtests(a_0)); heff_drop(v_x_2422); r_; });
  V v_t_2435 = ({ V a_0 = v_sel_240; V a_1 = heff_dup(v_j_241); V a_2 = MK_INT(0LL); V a_3 = v_t_2434; V r_ = (g_heff_2ebuild_2ecommands_2esubtestJobs(a_0, a_1, a_2, a_3)); heff_drop(v_sel_240); r_; });
  V v_x_2436 = heff_rec_n(4, shape_owner__place__outcome__next, (V[]){heff_take_field(v_j_241, 0), heff_get_n(v_j_241, 2, 6), v_t_2433, v_t_2435});
  V f_ = v_k_245;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_dir_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_j_241 = heff_env(self)[2];
  V v_ran_243 = heff_env(self)[3];
  V v_sel_240 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2424 = heff_tag_n(TAG_Remove, 2, (V[]){heff_strAppend(v_dir_242, ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_str1)), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam4_clo)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s495635622x733177935(v_t_2430, v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam5, 1, 5, (V[]){v_j_241, v_ran_243, v_x_2422, v_sel_240, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_dir_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_j_241 = heff_env(self)[2];
  V v_ran_243 = heff_env(self)[3];
  V v_sel_240 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2413);
  V v_t_2415 = heff_tag_n(TAG_ReadFile, 2, (V[]){heff_strAppend(heff_dup(v_dir_242), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_str0)), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam2_clo)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s495635622x733177935(v_t_2421, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_lam3, 1, 6, (V[]){v_dir_242, v_hd_244, v_j_241, v_ran_243, v_sel_240, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str3, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str4, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str5, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str6, 11, "ReleaseSafe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str7, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str8, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str9, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str10, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str11, 11, "ReleaseFast");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str12, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str15, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str16, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str17, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str18, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str19, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str20, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str21, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str22, 27, ": `zig cc` could not build ");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam7, 2, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498(V v_prog_240, V v_failed_241, V v_who_242, V v_st_243, V v_flags_244, V v_p_245, V v_dir_246, V v_out_247, V v_next_248, V v_hd_249, V v_k_2410) {
top: ;
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(v_dir_246), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam0_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam1, 1, 11, (V[]){heff_dup(v_st_243), v_dir_246, v_prog_240, v_p_245, v_hd_249, v_flags_244, v_out_247, v_next_248, v_k_2410, v_who_242, v_failed_241})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8], a[9], a[10]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam0(V self, V *args) {
  V v_ns_2411 = args[0];
  return v_ns_2411;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam2(V self, V *args) {
  V v_n_2422 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_st_243; V a_1 = v_dir_246; V a_2 = v_n_2422; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam3(V self, V *args) {
  V v_n_2427 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_st_243; V a_1 = v_dir_246; V a_2 = v_n_2427; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam4(V self, V *args) {
  V v_t_2432 = args[0];
  return v_t_2432;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam7(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  heff_drop(v_hd_2442);
  V v_t_2444 = heff_rec_n(3, shape_ended__out__err, (V[]){NTAG(TAG_NotRun), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str13), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str14)});
  V f_ = v_k_2443;
  args[0] = v_t_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam8(V self, V *args) {
  V v_r_2452 = args[0];
  return v_r_2452;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam12(V self, V *args) {
  V v_x_2479 = args[0];
  V v_who_242 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_failed_241 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2479);
  V v_t_2480 = heff_strAppend(v_who_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str22), v_out_247));
  V f_ = v_failed_241;
  heff_room[0] = v_t_2480;
  heff_room[1] = v_hd_249;
  heff_room[2] = v_k_2410;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam11(V self, V *args) {
  V v_x_2470 = args[0];
  V v_who_242 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_failed_241 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2470);
  V v_t_2471 = heff_strAppend(heff_dup(v_who_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str20), heff_dup(v_out_247)));
  V v_t_2472 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2471, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str21)), NTAG(TAG_MkUnit)});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2478}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam12, 1, 5, (V[]){v_who_242, v_out_247, v_failed_241, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam10(V self, V *args) {
  V v_x_2458 = args[0];
  V v_x_2455 = heff_env(self)[0];
  V v_next_248 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_who_242 = heff_env(self)[4];
  V v_out_247 = heff_env(self)[5];
  V v_failed_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2458);
  V v_t_2459 = heff_take_field(v_x_2455, 0);
  V v_t_2462;
  switch (heff_tag_of(v_t_2459)) {
  case TAG_Exited: {
    V v_n_2460 = heff_field(v_t_2459, 0);
    heff_take_n(v_t_2459, 1ULL, 1);
    v_t_2462 = heff_intEq(v_n_2460, MK_INT(0LL));
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2459, 0ULL, 1);
    v_t_2462 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2462 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2462 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2459);
  }
  if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2455, 3);
    heff_drop(v_who_242);
    heff_drop(v_out_247);
    heff_drop(v_failed_241);
    heff_drop(v_t_2462);
    V f_ = v_next_248;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_next_248);
    heff_drop(v_t_2462);
    V v_t_2463 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_x_2455, 2, 3), NTAG(TAG_MkUnit)});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2469}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam11, 1, 5, (V[]){v_who_242, v_out_247, v_hd_249, v_failed_241, v_k_2410})));
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam9(V self, V *args) {
  V v_x_2455 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_next_248 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  V v_who_242 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_failed_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2456 = heff_tag_n(TAG_End, 2, (V[]){v_x_2434, NTAG(TAG_MkUnit)});
  V v_t_2457 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2456}));
  return (g_co_2eop_24s495635622x733177935(v_t_2457, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam10, 1, 7, (V[]){v_x_2455, v_next_248, v_hd_249, v_k_2410, v_who_242, v_out_247, v_failed_241})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam6(V self, V *args) {
  V v_x_2441 = args[0];
  V v_out_247 = heff_env(self)[0];
  V v_x_2423 = heff_env(self)[1];
  V v_flags_244 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_x_2434 = heff_env(self)[4];
  V v_hd_249 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_failed_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2454;
  switch (heff_tag_of(v_x_2441)) {
  case TAG_Nothing: {
    heff_drop(v_x_2423);
    heff_drop(v_flags_244);
    v_c_2454 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam7_clo);
    break;
  }
  case TAG_Just: {
    V v_os_2445 = heff_field(v_x_2441, 0);
    heff_take_n(v_x_2441, 1ULL, 1);
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str15), NTAG(TAG_Nil)});
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str16), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_out_247), v_t_2446})});
    V v_t_2448 = (g_prelude_2e_2b_2b(v_os_2445, v_t_2447));
    V v_t_2449 = (g_prelude_2e_2b_2b(v_x_2423, v_t_2448));
    V v_t_2450 = (g_prelude_2e_2b_2b(v_flags_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str17), v_t_2449})));
    V v_as_2451 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str18), v_t_2450});
    V v_t_2453 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2434), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str19), v_as_2451, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam8_clo)})}));
    v_c_2454 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2453}));
    break;
  }
  default: heff_nomatch(v_x_2441);
  }
  V f_ = v_c_2454;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam9, 1, 8, (V[]){v_x_2434, v_prog_240, v_hd_249, v_next_248, v_k_2410, v_who_242, v_out_247, v_failed_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_flags_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_out_247 = heff_env(self)[4];
  V v_x_2423 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_failed_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2435 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str3); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2439;
  if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
    heff_drop(v_t_2435);
    v_t_2439 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str4);
  } else {
    heff_drop(v_t_2435);
    V v_t_2436 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str5); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop(v_t_2436);
      v_t_2439 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str6);
    } else {
      heff_drop(v_t_2436);
      V v_t_2437 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str7); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
      if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
        heff_drop(v_t_2437);
        v_t_2439 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str8);
      } else {
        heff_drop(v_t_2437);
        V v_t_2438 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str9); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str10); V a_2 = v_flags_244; V r_ = (g_list_2eany_24s529567056x880977707(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
          heff_drop(v_t_2438);
          v_t_2439 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str11);
        } else {
          heff_drop(v_t_2438);
          v_t_2439 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str12);
        }
      }
    }
  }
  V v_c_2440 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903(heff_dup(v_prog_240), heff_dup(v_x_2434), v_t_2439, v_x_2428, NTAG(TAG_Nil)));
  V f_ = v_c_2440;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam6, 1, 10, (V[]){v_out_247, v_x_2423, v_flags_244, v_prog_240, v_x_2434, v_hd_249, v_next_248, v_k_2410, v_who_242, v_failed_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_flags_244 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_k_2410 = heff_env(self)[8];
  V v_who_242 = heff_env(self)[9];
  V v_failed_241 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2420;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    v_t_2420 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2419 = heff_dup(heff_field(v_x_2418, 0));
    v_t_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V v_t_2421 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str0); V a_1 = v_t_2420; V r_ = (g_list_2efilter_24s794048906x2073543501(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2423 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam2, 1, 2, (V[]){heff_dup(v_st_243), heff_dup(v_dir_246)}), v_t_2421));
  V v_t_2425;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    v_t_2425 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2424 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    v_t_2425 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V v_t_2426 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str1); V a_1 = v_t_2425; V r_ = (g_list_2efilter_24s794048906x2073543501(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2428 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam3, 1, 2, (V[]){v_st_243, v_dir_246}), v_t_2426));
  V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2423));
  V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2428));
  V v_total_2431 = heff_intAdd(heff_intAdd(v_t_2429, v_t_2430), MK_INT(1LL));
  V v_t_2433 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_245, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_str2), v_total_2431, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam4_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2433, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_lam5, 1, 10, (V[]){v_flags_244, v_prog_240, v_x_2428, v_hd_249, v_out_247, v_x_2423, v_next_248, v_k_2410, v_who_242, v_failed_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_str1, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650(V v_bi_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_c_245, V v_available_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_lam0, 1, 1, (V[]){heff_dup(v_c_245)}), heff_dup(heff_rfield(v_c_245, 7))));
  V v_t_2417 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2416));
  V v_t_2418 = ({ V a_0 = v_t_2417; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2418));
  V v_t_2421 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_lam1, 1, 1, (V[]){heff_dup(v_available_246)}), v_t_2419));
  HeffT2 v_t_2422 = ({ V a_0 = v_t_2421; V a_1 = heff_dup(v_c_245); V a_2 = v_name_242; HeffT2 r_ = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; });
  {
    V v_field_2424 = v_t_2422.f[1];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    if ((v_tag_2423 == ((int64_t)0ULL))) {
      heff_drop(v_bi_240);
      heff_drop(v_outPath_243);
      heff_drop(v_done_244);
      heff_drop_rec(v_c_245, 14);
      heff_drop(v_available_246);
      V v_why_2426 = v_field_2424;
      V v_t_2427 = heff_strAppend(v_file_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_str0), v_why_2426));
      V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_str1), v_t_2427), ((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_str2));
      V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_lam2, 1, 2, (V[]){v_z_247, v_z_248})));
    } else {
      heff_drop(v_file_241);
      V v_r_2444 = v_field_2424;
      return (g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501(v_bi_240, v_outPath_243, v_done_244, v_c_245, v_available_246, v_r_2444, v_z_247, v_z_248));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7], a[8]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_lam0(V self, V *args) {
  V v_o_249 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2410 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_245, heff_rfield(v_o_249, 1)));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_eff_2414 = v_field_2412;
      V v_t_2415 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_249, 0), heff_get_n(v_o_249, 1, 2), v_eff_2414});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
    } else {
      heff_drop_rec(v_o_249, 2);
      heff_drop(v_field_2412);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_lam1(V self, V *args) {
  V v_k_2420 = args[0];
  V v_available_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_246; V a_1 = v_k_2420; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeaf(a_0, a_1)); heff_drop(v_available_246); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_lam2(V self, V *args) {
  V v_x_2436 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), v_z_247, v_z_248));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_str0, 16, " not formatted: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_str1, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374(V v_checkOnly_240, V v_f_241, V v_src_242, V v_fix_243, V v_z_244, V v_z_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_fix_243, heff_dup(v_src_242)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_src_242);
      V v_why_2410 = v_field_248;
      V v_t_2411 = heff_strAppend(v_f_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_str0), v_why_2410));
      V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_str1), v_t_2411), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_str2));
      V v_t_2413 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_lam0, 1, 1, (V[]){v_z_245})));
    } else {
      V v_out_2421 = v_field_248;
      if (heff_strEq_c_lent(v_out_2421, v_src_242, 2)) {
        heff_drop(v_f_241);
        heff_drop(v_z_244);
        heff_drop(v_out_2421);
        return heff_tail(v_z_245, 1, (V[]){MK_INT(0LL)});
      } else {
        if ((heff_dup(v_checkOnly_240) == NTAG(TAG_True))) {
          heff_drop(v_out_2421);
          V v_t_2423 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_f_241, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_str3)), NTAG(TAG_MkUnit)});
          V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
          V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
          V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
          V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
          V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
          V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
          return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_lam1, 1, 1, (V[]){v_z_245})));
        } else {
          V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_f_241, v_out_2421, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_lam2_clo)})});
          V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
          V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
          V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
          V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
          V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
          return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_lam3, 1, 1, (V[]){v_z_245})));
        }
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2420);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_lam1(V self, V *args) {
  V v_x_2430 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2430);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_lam2(V self, V *args) {
  V v_ok_2431 = args[0];
  return v_ok_2431;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374_lam3(V self, V *args) {
  V v_x_2438 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2438);
  V f_ = v_z_245;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_str0, 18, "heff: cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315(V v_checkOnly_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_lam1, 1, 4, (V[]){v_f_241, v_hd_242, v_k_243, heff_dup(v_checkOnly_240)})));
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_lam0(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2420);
  V f_ = v_k_243;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_src_2421 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2424 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2423, 0, 5)));
  return ({ V a_0 = v_checkOnly_240; V a_1 = v_f_241; V a_2 = v_src_2421; V a_3 = v_t_2424; V a_4 = v_hd_242; V a_5 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2efmtSrc_24s70721426x1807371374(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_checkOnly_240); r_; });
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_checkOnly_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    heff_drop(v_checkOnly_240);
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_str0), v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_str1));
    V v_t_2413 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_lam2, 1, 1, (V[]){v_k_243})));
  }
  case TAG_Just: {
    V v_src_2421 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    V v_c_2422 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(heff_dup(v_f_241)));
    V f_ = v_c_2422;
    heff_room[0] = heff_dup(v_hd_242);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1223729326x1078373315_lam3, 1, 5, (V[]){v_checkOnly_240, v_f_241, v_src_2421, v_hd_242, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2411);
  }
}
Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s1105330941x1846751788_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildEach_24s1105330941x1846751788_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildEach_24s1105330941x1846751788(V v_rep_240, V v_prog_241, V v_st_242, V v_t_243, V v_bp_244, V v_done_245, V v_x5_246) {
top: ;
  switch (heff_tag_of(v_x5_246)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_st_242);
    heff_drop(v_t_243);
    heff_drop(v_bp_244);
    return v_done_245;
  }
  case TAG_Cons: {
    V v_a_247 = heff_field(v_x5_246, 0);
    V v_rest_248 = heff_field(v_x5_246, 1);
    V v_t_249 = (g_heff_2ebuild_2ecommands_2ebuildEach_24s1105330941x1846751788(heff_dup(v_rep_240), heff_dup(v_prog_241), heff_dup(v_st_242), heff_dup(v_t_243), heff_dup(v_bp_244), v_done_245, v_rest_248));
    return (g_heff_2ebuild_2ecommands_2ebuildApp_24s754880438x1745970415(v_rep_240, v_prog_241, v_st_242, v_t_243, v_bp_244, heff_dup(heff_rfield(v_a_247, 0)), heff_dup(heff_rfield(v_a_247, 1)), v_t_249));
  }
  default: return heff_nomatch(v_x5_246);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildEach_24s1105330941x1846751788_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ebuildEach_24s1105330941x1846751788(a[0], a[1], a[2], a[3], a[4], a[5], a6); heff_drop(a6); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043_str1, 3, ".js");
Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043(V v_prog_240, V v_st_241, V v_t_242, V v_pl_243, V v_next_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_pl_243);
    return v_next_244;
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x5_245, 0);
    V v_rest_247 = heff_field(v_x5_245, 1);
    V v_t_248 = (g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043(heff_dup(v_prog_240), v_st_241, heff_dup(v_t_242), heff_dup(v_pl_243), v_next_244, v_rest_247));
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_a_246, 1)), 0, 3);
    V v_t_2413;
    if (heff_strEq_c(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043_str0))) {
      v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_a_246, 0))});
    } else {
      V v_t_2411 = heff_dup(heff_rfield(v_t_242, 3));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_t_2412 = heff_strAppend(heff_dup(heff_rfield(v_a_246, 0)), ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043_str1));
        v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
      } else {
        heff_drop(v_t_2411);
        v_t_2413 = NTAG(TAG_Nothing);
      }
    }
    return (g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975(v_prog_240, v_st_241, v_t_242, v_pl_243, v_t_248, heff_dup(heff_rfield(v_a_246, 0)), v_t_2413));
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eplaceAll_24s419741403x820190043(a[0], a1, a[2], a[3], a[4], a5); heff_drop(a1); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_str2, 17, "building programs");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212(V v_rep_240, V v_prog_241, V v_st_242, V v_t_243, V v_progs_244, V v_z_245, V v_z_246) {
top: ;
  V v_p_247 = (g_std_2epath_2ejoin(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_str0), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_str1)));
  V v_path_248 = (g_std_2epath_2ejoin(v_st_242, heff_dup(heff_rfield(v_t_243, 0)), v_p_247));
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_248, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam0_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam1, 1, 7, (V[]){v_progs_244, v_prog_241, v_z_245, v_st_242, v_t_243, v_rep_240, v_z_246})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam0(V self, V *args) {
  V v_ok_249 = args[0];
  return v_ok_249;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam2(V self, V *args) {
  V v_t_2418 = args[0];
  return v_t_2418;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam4(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_prog_241 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_t_243 = heff_env(self)[2];
  V v_t_2421 = heff_env(self)[3];
  V v_progs_244 = heff_env(self)[4];
  V v_t_2423 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_prog_241; V a_1 = v_st_242; V a_2 = v_t_243; V a_3 = v_t_2421; V a_4 = v_progs_244; V a_5 = heff_dup(v_hd_2424); V a_6 = v_k_2425; V a_7 = v_t_2423; V a_8 = v_hd_2424; V r_ = (g_co_2eop_24s11399370x647848365(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_st_242); heff_drop(v_progs_244); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_t_243 = heff_env(self)[2];
  V v_progs_244 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2421 = (g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380(heff_dup(v_prog_241), v_st_242, heff_dup(v_t_243), heff_dup(v_progs_244), heff_rfield(v_t_243, 4)));
  V v_t_2422 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2420), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2422}));
  V v_t_2426 = ({ V a_0 = v_rep_240; V a_1 = heff_dup(v_prog_241); V a_2 = heff_dup(v_st_242); V a_3 = heff_dup(v_t_243); V a_4 = v_x_2420; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam4, 2, 6, (V[]){v_prog_241, v_st_242, v_t_243, v_t_2421, heff_dup(v_progs_244), v_t_2423}); V a_6 = v_progs_244; V r_ = (g_heff_2ebuild_2ecommands_2ebuildEach_24s1105330941x1846751788(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_progs_244); r_; });
  V f_ = v_t_2426;
  heff_room[0] = v_z_245;
  heff_room[1] = v_z_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_progs_244 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_st_242 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2416);
  V v_total_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_244));
  V v_t_2419 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_str2), v_total_2417, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam2_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2419, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1079107355x1850131212_lam3, 1, 7, (V[]){v_prog_241, v_st_242, v_t_243, v_progs_244, v_rep_240, v_z_245, v_z_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_str2, 17, "building programs");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883(V v_rep_240, V v_prog_241, V v_st_242, V v_t_243, V v_done_244, V v_progs_245, V v_z_246, V v_z_247) {
top: ;
  V v_p_248 = (g_std_2epath_2ejoin(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_str0), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_str1)));
  V v_path_249 = (g_std_2epath_2ejoin(v_st_242, heff_dup(heff_rfield(v_t_243, 0)), v_p_248));
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_249, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam0_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam1, 1, 8, (V[]){v_progs_245, v_prog_241, v_z_246, v_st_242, v_t_243, v_done_244, v_rep_240, v_z_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam0(V self, V *args) {
  V v_ok_2410 = args[0];
  return v_ok_2410;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam2(V self, V *args) {
  V v_t_2419 = args[0];
  return v_t_2419;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam4(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_prog_241 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_t_243 = heff_env(self)[2];
  V v_t_2422 = heff_env(self)[3];
  V v_progs_245 = heff_env(self)[4];
  V v_t_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_prog_241; V a_1 = v_st_242; V a_2 = v_t_243; V a_3 = v_t_2422; V a_4 = v_progs_245; V a_5 = heff_dup(v_hd_2425); V a_6 = v_k_2426; V a_7 = v_t_2424; V a_8 = v_hd_2425; V r_ = (g_co_2eop_24s11399370x647848365(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_st_242); heff_drop(v_progs_245); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_t_243 = heff_env(self)[2];
  V v_done_244 = heff_env(self)[3];
  V v_progs_245 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2422 = (g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866(heff_dup(v_prog_241), v_st_242, heff_dup(v_t_243), v_done_244, heff_dup(v_progs_245), heff_rfield(v_t_243, 4)));
  V v_t_2423 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2421), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2423}));
  V v_t_2427 = ({ V a_0 = v_rep_240; V a_1 = heff_dup(v_prog_241); V a_2 = heff_dup(v_st_242); V a_3 = heff_dup(v_t_243); V a_4 = v_x_2421; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam4, 2, 6, (V[]){v_prog_241, v_st_242, v_t_243, v_t_2422, heff_dup(v_progs_245), v_t_2424}); V a_6 = v_progs_245; V r_ = (g_heff_2ebuild_2ecommands_2ebuildEach_24s1105330941x1846751788(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_progs_245); r_; });
  V f_ = v_t_2427;
  heff_room[0] = v_z_246;
  heff_room[1] = v_z_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_progs_245 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_st_242 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2417);
  V v_total_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_245));
  V v_t_2420 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_str2), v_total_2418, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam2_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2420, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1508715661x1051703883_lam3, 1, 8, (V[]){v_prog_241, v_st_242, v_t_243, v_done_244, v_progs_245, v_rep_240, v_z_246, v_z_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str0, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str2, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str5, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str6, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str7, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621(V v_st_240, V v_t_241, V v_home_242, V v_dir_243, V v_next_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WorkingDir, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s495635622x733177935(v_t_2414, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam1, 1, 7, (V[]){heff_dup(v_st_240), v_home_242, v_dir_243, v_hd_245, v_t_241, v_next_244, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam2(V self, V *args) {
  V v_ok_2420 = args[0];
  return v_ok_2420;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam4(V self, V *args) {
  V v_x_2437 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2437);
  V f_ = v_next_244;
  heff_room[0] = v_hd_245;
  heff_room[1] = v_k_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam5(V self, V *args) {
  V v_x_2448 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2448);
  V v_t_2449 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2455}), v_hd_245, v_k_246));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_next_244 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2427) == NTAG(TAG_True))) {
    heff_drop(v_x_2427);
    V v_path_2428 = ({ V a_0 = v_st_240; V a_1 = v_home_242; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str2); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
    V v_t_2429 = heff_strAppend(heff_get_n(v_t_241, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str3), v_path_2428));
    V v_t_2430 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str4)), NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam4, 1, 3, (V[]){v_next_244, v_hd_245, v_k_246})));
  } else {
    heff_drop(v_x_2427);
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_next_244);
    V v_t_2438 = ({ V a_0 = v_st_240; V a_1 = v_home_242; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str5); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
    V v_why_2439 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str6), v_t_2438);
    V v_t_2440 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str7), v_why_2439), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str8));
    V v_t_2441 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2440, NTAG(TAG_MkUnit)});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam5, 1, 2, (V[]){v_hd_245, v_k_246})));
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_dir_243 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_path_2416 = (g_std_2epath_2ejoin(v_st_240, heff_dup(v_home_242), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str0)));
  V v_t_2417 = (g_std_2epath_2ejoin(v_st_240, v_x_2415, v_dir_243));
  V v_t_2418 = (g_std_2epath_2enormalize(v_st_240, v_t_2417));
  V v_str_2419 = heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_str1));
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_2416, v_str_2419, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam2_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_lam3, 1, 6, (V[]){v_st_240, v_home_242, v_t_241, v_hd_245, v_next_244, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924(V v_rep_240, V v_badL_241, V v_cs_242, V v_z_243, V v_z_244) {
top: ;
  V v_c_245 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(v_rep_240, heff_dup(v_cs_242)));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924_lam0, 1, 4, (V[]){v_cs_242, v_z_243, heff_dup(v_badL_241), v_z_244})});
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_badL_241 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_cs_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_badL_241) == NTAG(TAG_True))) {
    heff_drop(v_x_2413);
    heff_drop(v_badL_241);
    heff_drop(v_cs_242);
    V v_t_2414 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_z_243, v_z_244));
  } else {
    heff_drop(v_badL_241);
    V v_t_2421 = ({ V a_0 = v_cs_242; V r_ = (g_list_2eany_24s469495312x865582084(a_0)); heff_drop(v_cs_242); r_; });
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_x_2413);
      heff_drop(v_t_2421);
      V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_z_243, v_z_244));
    } else {
      heff_drop(v_t_2421);
      if ((heff_dup(v_x_2413) == NTAG(TAG_True))) {
        heff_drop(v_x_2413);
        V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
        V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
        V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
        V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
        V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
        V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
        return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_z_243, v_z_244));
      } else {
        heff_drop(v_x_2413);
        heff_drop(v_z_243);
        V f_ = v_z_244;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_badL_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_246);
  HeffT2 v_t_247 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_242)));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_c_2411 = v_field_249;
      V v_t_2412 = (g_heff_2ebuild_2edriver_2eevaluate(v_c_2411));
      return (g_heff_2ebuild_2ecommands_2eprintEvals_24s1002441539x1771571072(v_t_2412, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eevalDiags_24s1595661040x660943924_lam1, 1, 4, (V[]){v_badL_241, v_z_243, v_z_244, v_cs_242})));
    } else {
      heff_drop(v_cs_242);
      heff_drop(v_badL_241);
      heff_drop(v_field_249);
      V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_z_243, v_z_244));
    }
  }
}