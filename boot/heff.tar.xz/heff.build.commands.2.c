// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_GetEnv 43934
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Move 53768
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_diags 296935042
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_files 298792593
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_jobs 9763101
#define LBL_keep 9783372
#define LBL_module 878357911
#define LBL_opt 319789
#define LBL_output 941629484
#define LBL_own 320000
#define LBL_pattern 1588251091
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_seed 10021688
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_text 10052084
#define LBL_timeout 1065429926
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_update 1108295668
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_seed__pattern__jobs__update[] = {LBL_seed, LBL_pattern, LBL_jobs, LBL_update};
V g_co_2eop_24s2004353512x124285792(V, V, V, V, V);
V g_co_2eop_24s2004353512x124285792_entry(V self, V *a);
extern Clo g_co_2eop_24s2004353512x124285792_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_clo;
V g_heff_2ebuild_2ecommands_2ejsonGolden(V);
V g_heff_2ebuild_2ecommands_2ejsonGolden_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsonGolden_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(V);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901(V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_clo;
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906(V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_clo;
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359(V);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961(V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_clo;
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389(V);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_clo;
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127(V, V);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_clo;
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_clo;
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_clo;
V g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_clo;
V g_heff_2ebuild_2ecommands_2ezigOf(V);
V g_heff_2ebuild_2ecommands_2ezigOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigOf_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_list_2efilter_24f1668687542x1574966783(V, V, V, V);
V g_list_2efilter_24f1668687542x1574966783_entry(V self, V *a);
extern Clo g_list_2efilter_24f1668687542x1574966783_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s370939663x1496042695(V, V);
V g_list_2emap_24s370939663x1496042695_entry(V self, V *a);
extern Clo g_list_2emap_24s370939663x1496042695_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str8, 1, "$");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_245 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_242, 0)), v_t_248)) {
      V v_t_2410 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_text_2412 = heff_dup(heff_rfield(v_p_242, 1));
      V v_t_2413 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str6); V a_1 = v_text_2412; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str7), v_text_2412, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_2412); r_; });
      V v_t_2414 = (g_list_2emap_24s732475005x1616712052(v_t_2413));
      V v_t_2415 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str8); V a_3 = v_t_2414; V r_ = (g_list_2efilter_24f1668687542x1574966783(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
      V v_t_2416 = ({ V a_0 = v_t_2411; V a_1 = v_t_2415; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2411); heff_drop(v_t_2415); r_; });
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_k_241);
        heff_drop(v_t_2416);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2416);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeaf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigOf_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigOf_str1, 8, "heff.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigOf_str2, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigOf_str3, 4, ".zig");
Clo g_heff_2ebuild_2ecommands_2ezigOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ezigOf(V v_outPath_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)1ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_241), heff_strLength_lent(v_outPath_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2ebuild_2ecommands_2ezigOf_str0))) {
    return heff_strAppend(v_outPath_240, ((V)&g_heff_2ebuild_2ecommands_2ezigOf_str1));
  } else {
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    V v_t_245 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_244), heff_strLength_lent(v_outPath_240, 0));
    V v_t_248;
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2ezigOf_str2))) {
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
      v_t_248 = heff_strSlice(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_247));
    } else {
      v_t_248 = v_outPath_240;
    }
    return heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2ezigOf_str3));
  }
}
V g_heff_2ebuild_2ecommands_2ezigOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigOf(a[0]);
}

static V g_heff_2ebuild_2ecommands_2enoRes_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2enoRes_st;
static V g_heff_2ebuild_2ecommands_2enoRes_init(void) {
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2ebuild_2ecommands_2enoRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2enoRes_st)) return g_heff_2ebuild_2ecommands_2enoRes_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2enoRes_val, &g_heff_2ebuild_2ecommands_2enoRes_st, g_heff_2ebuild_2ecommands_2enoRes_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str24, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str25, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str27, 0, "");
Clo g_heff_2ebuild_2ecommands_2ejsonGolden_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsonGolden_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ejsonGolden(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_JNull: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str0), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str1)});
  }
  case TAG_JBool: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str2), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str3)});
  }
  case TAG_JInt: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str4), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str5)});
  }
  case TAG_JFloat: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str6), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str7)});
  }
  case TAG_JString: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str8), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str9)});
  }
  case TAG_JArray: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str10), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str11)});
    }
    case TAG_Cons: {
      V v_n_246 = heff_field(v_x11_245, 0);
      V v_x112_247 = heff_field(v_x11_245, 1);
      switch (heff_tag_of(v_x112_247)) {
      case TAG_Nil: {
        return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str12), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str13)});
      }
      case TAG_Cons: {
        V v_t_248 = heff_field(v_x112_247, 0);
        V v_t_2416;
        switch (heff_tag_of(v_n_246)) {
        case TAG_JNull: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str14);
          break;
        }
        case TAG_JBool: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str15);
          break;
        }
        case TAG_JInt: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str16);
          break;
        }
        case TAG_JFloat: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str17);
          break;
        }
        case TAG_JString: {
          V v_t_2413 = heff_field(v_n_246, 0);
          v_t_2416 = heff_dup(v_t_2413);
          break;
        }
        case TAG_JArray: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str18);
          break;
        }
        case TAG_JObject: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str19);
          break;
        }
        default: heff_nomatch(v_n_246);
        }
        V v_t_2423;
        switch (heff_tag_of(v_t_248)) {
        case TAG_JNull: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str20);
          break;
        }
        case TAG_JBool: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str21);
          break;
        }
        case TAG_JInt: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str22);
          break;
        }
        case TAG_JFloat: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str23);
          break;
        }
        case TAG_JString: {
          V v_t_2420 = heff_field(v_t_248, 0);
          v_t_2423 = heff_dup(v_t_2420);
          break;
        }
        case TAG_JArray: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str24);
          break;
        }
        case TAG_JObject: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str25);
          break;
        }
        default: heff_nomatch(v_t_248);
        }
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_t_2423});
      }
      default: return heff_nomatch(v_x112_247);
      }
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  case TAG_JObject: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str26), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str27)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ejsonGolden_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ejsonGolden(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_str0, 8, "HEFF_LIB");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_str2, 3, "lib");
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_str0), ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s94900133x232571340(v_t_248, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  return v_s_2410;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam4(V self, V *args) {
  V v_s_2420 = args[0];
  return v_s_2420;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_st_2419 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2419, v_x_2427));
  V v_x_2429 = ({ V a_0 = v_st_2419; V a_1 = v_t_2428; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_str2); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2419); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_st_2419;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_str1))) {
    v_st_2419 = NTAG(TAG_Windows);
  } else {
    v_st_2419 = NTAG(TAG_Posix);
  }
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam4_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s94900133x232571340(v_t_2426, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam5, 1, 2, (V[]){v_st_2419, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam2_clo)})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s94900133x232571340(v_t_2416, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    V v_lib_2430 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_lib_2430;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_name_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      return (g_co_2eop_24s94900133x232571340(v_t_2414, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam1, 1, 6, (V[]){v_dir_240, v_name_246, v_p_242, v_text_247, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam2(V self, V *args) {
  V v_t_2419 = args[0];
  return v_t_2419;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2427) == NTAG(TAG_True))) {
    heff_drop(v_x_2427);
    return (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777(v_dir_240, v_rest_245, v_p_242, v_p_243));
  } else {
    heff_drop(v_x_2427);
    heff_drop(v_dir_240);
    heff_drop(v_rest_245);
    heff_drop(v_p_242);
    V f_ = v_p_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_2417 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_name_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2426 = ({ V a_0 = v_st_2417; V a_1 = heff_dup(v_dir_240); V a_2 = v_name_246; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2417); r_; });
  return (g_heff_2ebuild_2ecommands_2ewriteChanged_24s1337090067x1826518693(v_t_2426, v_text_247, v_x_2425, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam4, 1, 4, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243})));
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_name_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2417;
  if (heff_strEq_c(v_x_2415, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_str0))) {
    v_st_2417 = NTAG(TAG_Windows);
  } else {
    v_st_2417 = NTAG(TAG_Posix);
  }
  V v_path_2418 = (g_std_2epath_2ejoin(v_st_2417, heff_dup(v_dir_240), heff_dup(v_name_246)));
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2418, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam2_clo)})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1042280862x1246672777_lam3, 1, 7, (V[]){v_st_2417, v_dir_240, v_name_246, v_text_247, v_p_242, v_rest_245, v_p_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_str0, 4, "test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_str1, 68, "heff test: no test/ here: test at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_str2, 4, "test");
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam0, 2, 0};
Clo g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389(V v_given_240) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam0_clo);
  }
  case TAG_Cons: {
    V v_t_2430 = (g_list_2emap_24s1420651609x666245096(v_given_240));
    return (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127(v_t_2430, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389(a[0]);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam1(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2423);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam4, 1, 1, (V[]){v_k_242})));
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    V v_t_2410 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_str1), NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam3, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Just: {
    heff_take_n(v_x_249, 0ULL, 1);
    V v_t_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_str2)});
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127(v_t_2426, NTAG(TAG_Nil)));
    V f_ = v_t_2427;
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_str0), ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam1_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_248}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s1593611071x1022930389_lam2, 1, 2, (V[]){v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_str0, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_243, ((V)&g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_str0)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s2004353512x124285792(v_rest_244, heff_dup(v_p_241), v_p_242, heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359(V v_file_240) {
top: ;
  V v_c_241 = (g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(heff_dup(v_file_240)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_lam0, 2, 2, (V[]){v_c_241, v_file_240});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359(a[0]);
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_file_240; V b_1 = heff_intLt(MK_INT(0LL), v_x_245); V a_2 = heff_get_n(v_x_247, 0, 2); V a_3 = v_hd_242; V a_4 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(v_x_244));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_lam3, 1, 4, (V[]){v_file_240, v_x_245, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(((V)&g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_str0), heff_dup(heff_rfield(v_x_244, 1)), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_lam2, 1, 4, (V[]){v_x_244, v_hd_242, v_file_240, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s1106036646x72268359_lam1, 1, 3, (V[]){v_hd_242, v_file_240, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_str3, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_str4, 10, "heff build");
Clo g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716(V v_prog_240, V v_st_241, V v_t_242, V v_p_243, V v_x_244, V v_next_245) {
top: ;
  V v_t_246 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_str0), ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_str1)));
  V v_p_247 = (g_std_2epath_2ejoin(v_st_241, v_t_246, heff_dup(v_x_244)));
  V v_dir_248 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_242, 0)), v_p_247));
  V v_t_249 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_str2), ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_str3)));
  V v_p_2410 = (g_std_2epath_2ejoin(v_st_241, v_t_249, heff_dup(v_x_244)));
  V v_t_2411 = (g_std_2epath_2ejoin(v_st_241, heff_take_field(v_t_242, 0), v_p_2410));
  V v_out_2412 = (g_std_2epath_2ejoin(v_st_241, v_t_2411, v_x_244));
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_242, 5, 6), NTAG(TAG_Nil)});
  return heff_tail(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2062501108x742110643_clo), 9, (V[]){MK_INT(1LL), v_prog_240, ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_str4), v_st_241, v_t_2413, v_p_243, v_dir_248, v_out_2412, v_next_245});
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_str2, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_str3, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_str4, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058(V v_t_240, V v_fresh_241, V v_old_242, V v_to_243, V v_next_244, V v_x6_245, V v_p_246, V v_p_247) {
top: ;
  if ((heff_dup(v_x6_245) == NTAG(TAG_True))) {
    heff_drop(v_fresh_241);
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_old_242, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam0_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam1, 1, 5, (V[]){v_t_240, v_to_243, v_p_246, v_next_244, v_p_247})));
  } else {
    heff_drop_rec(v_t_240, 6);
    heff_drop(v_next_244);
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Move, 3, (V[]){v_old_242, heff_dup(v_to_243), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam3_clo)})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam4, 1, 4, (V[]){v_fresh_241, v_p_246, v_to_243, v_p_247})));
  }
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7]); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam0(V self, V *args) {
  V v_ok_248 = args[0];
  return v_ok_248;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2422);
  V f_ = v_next_244;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_next_244 = heff_env(self)[3];
  V v_p_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_strAppend(heff_get_n(v_t_240, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_str0), v_to_243));
  V v_t_2416 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_str1)), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam2, 1, 3, (V[]){v_next_244, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam3(V self, V *args) {
  V v_ok_2423 = args[0];
  return v_ok_2423;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam5(V self, V *args) {
  V v_ok_2430 = args[0];
  return v_ok_2430;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam7(V self, V *args) {
  V v_x_2445 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_p_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2445);
  V v_t_2446 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2451}), v_p_246, v_p_247));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_strAppend(v_fresh_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_str2), v_to_243));
  V v_t_2438 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_str3), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_str4), v_t_2437));
  V v_t_2439 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2438, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_str5)), NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam7, 1, 2, (V[]){v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_to_243 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2429);
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_fresh_241), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam5_clo)})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s1141697526x476662058_lam6, 1, 4, (V[]){v_fresh_241, v_to_243, v_p_246, v_p_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047(V v_lit_240, V v_lit_241, V v_lit_242, V v_f_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_f_243), ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_lam1, 1, 6, (V[]){v_f_243, v_hd_244, v_lit_240, v_lit_241, v_lit_242, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_lam0(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_f_243 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_rec_n(4, shape_seed__pattern__jobs__update, (V[]){v_lit_240, v_lit_241, v_lit_242, NTAG(TAG_False)});
  V v_src_2417;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    v_src_2417 = ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2416 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    v_src_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_j_2418 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_str1), v_src_2417, MK_INT(0LL), 5);
  V v_t_2420;
  if (heff_intLt_c_lent(v_j_2418, MK_INT(0LL), 2)) {
    heff_drop(v_j_2418);
    v_t_2420 = heff_strLength_lent(v_src_2417, 0);
  } else {
    v_t_2420 = v_j_2418;
  }
  V v_t_2421 = heff_strEq(heff_strSlice(v_src_2417, MK_INT(0LL), v_t_2420), heff_dup(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get()));
  return ({ V a_0 = v_t_2415; V a_1 = v_f_243; V a_2 = v_t_2421; V a_3 = v_x_2414; V a_4 = v_hd_244; V a_5 = v_k_245; V r_ = (g_heff_2ebuild_2ecommands_2etestLoaded_24s2115524712x495086430(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2421); r_; });
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_f_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2413 = (g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(heff_dup(v_f_243)));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_lam2, 1, 7, (V[]){v_lit_240, v_lit_241, v_lit_242, v_x_2412, v_f_243, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_str0, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_str5, 6, ": git ");
V g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418(V v_what_240, V v_as_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_str0), heff_dup(v_as_241), ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_str1), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s94900133x232571340(v_t_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_lam1, 1, 3, (V[]){v_as_241, v_what_240, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_lam0(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_as_241 = heff_env(self)[0];
  V v_what_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_take_field(v_x_2412, 0);
  V v_t_2416;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Exited: {
    V v_n_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    v_t_2416 = heff_intEq(v_n_2414, MK_INT(0LL));
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2413, 0ULL, 1);
    v_t_2416 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2416 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2416 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  V v_x_2427;
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2412, 3);
    heff_drop(v_as_241);
    heff_drop(v_what_240);
    heff_drop(v_t_2416);
    v_x_2427 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2416);
    V v_t_2419;
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_as_241, 0);
      V v_xs_2418 = heff_field(v_as_241, 1);
      heff_take_n(v_as_241, 3ULL, 2);
      v_t_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_str3); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_as_241);
    }
    V v_s_2420 = heff_get_n(v_x_2412, 2, 3);
    V v_t_2421 = (g_prelude_2eskipSpaces(v_s_2420, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2422 = (heff_unbox_word(heff_strLength_lent(v_s_2420, 0)) - ((int64_t)1ULL));
    V v_t_2423 = (g_prelude_2eskipSpaces(v_s_2420, heff_box_word(v_t_2422), MK_INT(-1LL)));
    V v_t_2424 = heff_strSlice(v_s_2420, v_t_2421, heff_intAdd(v_t_2423, MK_INT(1LL)));
    V v_t_2425 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_str4), v_t_2424));
    V v_t_2426 = heff_strAppend(v_what_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418_str5), v_t_2425));
    v_x_2427 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2426});
  }
  V f_ = v_k_243;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str2, 2, "-m");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str3, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str4, 2, "-a");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str5, 10, "not tagged");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str7, 4, "push");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str8, 6, "origin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str9, 18, "tagged, not pushed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str10, 7, ", tag v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str11, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str12, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str14, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str16, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str17, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961(V v_v_240, V v_pk_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str0), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str1), heff_dup(v_v_240)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str2), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str4), v_t_245})});
  HEFF_LAST return g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str5), v_t_246, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_lam0, 1, 4, (V[]){v_v_240, v_hd_242, v_pk_241, v_k_243}));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_pk_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_strAppend(heff_dup(v_v_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str10), v_v_240));
    V v_t_2412 = heff_strAppend(heff_get_n(v_pk_241, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str11), v_t_2411));
    V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str12), v_t_2412), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str13));
    V v_t_2414 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2413, NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), v_hd_242, v_k_243));
  }
  case TAG_Just: {
    V v_why_2420 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_241, 4);
    V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str14), v_why_2420), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str15));
    V v_t_2422 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2421, NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_lam2, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_lam3(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2443);
  V v_t_2444 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str6), heff_dup(v_v_240)), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str8), v_t_248})});
    return (g_heff_2ebuild_2ecommands_2egitOk_24s937234768x1517794418(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str9), v_t_249, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_lam1, 1, 4, (V[]){v_v_240, v_pk_241, v_hd_242, v_k_243})));
  }
  case TAG_Just: {
    V v_why_2435 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_241, 4);
    V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str16), v_why_2435), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_str17));
    V v_t_2437 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2436, NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag_at_n(v_ru_24x_247_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s1216367375x57090961_lam3, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_str0, 2, ": ");
V g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901(V v_x1_240, V v_bad_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_lam0, 2, 1, (V[]){v_bad_241});
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_t_246 = (g_list_2emap_24s152505078x225062837(heff_dup(heff_rfield(v_c_244, 7))));
    V v_c_247 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906(heff_dup(v_c_244), v_t_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_lam1, 2, 4, (V[]){v_c_247, heff_dup(v_c_244), heff_dup(v_rest_245), v_bad_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_bad_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_bad_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = ({ V a_0 = v_rest_245; V a_1 = heff_intAdd(v_bad_241, v_x_2412); V r_ = (g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2413;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = (g_list_2emap_24s370939663x1496042695(((V)&g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_str0), heff_take_field(v_c_244, 6)));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(heff_get_n(v_c_244, 0, 13), v_t_2411, MK_INT(0LL), heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_lam3, 1, 4, (V[]){v_rest_245, v_bad_241, v_hd_248, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s1340223059x802088901_lam2, 1, 5, (V[]){v_c_244, v_hd_248, v_rest_245, v_bad_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}