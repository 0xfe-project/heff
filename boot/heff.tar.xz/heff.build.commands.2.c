// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_backend 2032133329
#define LBL_bin 307073
#define LBL_bind 9519364
#define LBL_c 317
#define LBL_command 1182252425
#define LBL_copies 592412158
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_emits 297985818
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_file 9638467
#define LBL_files 298792593
#define LBL_globals 352931696
#define LBL_group 299987609
#define LBL_groups 709681407
#define LBL_hashes 722717031
#define LBL_implicit 319715269
#define LBL_input 301716452
#define LBL_jss 315076
#define LBL_keep 9783372
#define LBL_key 315609
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_limit 304334805
#define LBL_malg 9839318
#define LBL_mod 317820
#define LBL_mods 9852536
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_next 9873338
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_olds 9909235
#define LBL_out 319944
#define LBL_outPath 1272254166
#define LBL_outcome 1272833429
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_pending 1696753626
#define LBL_place 308106529
#define LBL_renames 1324191545
#define LBL_reports 1326460931
#define LBL_root 10001833
#define LBL_shown 310772011
#define LBL_skipped 231818613
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_text 10052084
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_units 312791945
#define LBL_update 1108295668
#define LBL_wrong 314763719
#define LBL_zig 330130
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
static uint32_t shape_module__named__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_named, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_owner__place__outcome__next[] = {LBL_owner, LBL_place, LBL_outcome, LBL_next};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
static uint32_t shape_units__copies[] = {LBL_units, LBL_copies};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s321980040x1154251472(V, V, V, V, V);
V g_co_2eop_24s321980040x1154251472_entry(V self, V *a);
extern Clo g_co_2eop_24s321980040x1154251472_clo;
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ecache_2ehashGo(V, V, V, V);
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ehashGo_clo;
V g_heff_2ebuild_2ecommands_2eaddRes(V, V);
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_clo;
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819(V, V);
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731(V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404_clo;
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478(V, V);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_clo;
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_clo;
V g_heff_2ebuild_2ecommands_2efailLines(V, V);
V g_heff_2ebuild_2ecommands_2efailLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLines_clo;
V g_heff_2ebuild_2ecommands_2efilesSaid(V);
V g_heff_2ebuild_2ecommands_2efilesSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efilesSaid_clo;
V g_heff_2ebuild_2ecommands_2efirstErrorOf(V);
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_clo;
V g_heff_2ebuild_2ecommands_2egoldenPath(V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenPath_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo;
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823(V);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_clo;
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_clo;
V g_heff_2ebuild_2ecommands_2ejsonGolden(V);
V g_heff_2ebuild_2ecommands_2ejsonGolden_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsonGolden_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2epassedOver(V, V);
V g_heff_2ebuild_2ecommands_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epassedOver_clo;
V g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_clo;
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738(V, V);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_clo;
V g_heff_2ebuild_2ecommands_2eranLine(V);
V g_heff_2ebuild_2ecommands_2eranLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranLine_clo;
V g_heff_2ebuild_2ecommands_2eranOutcome(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eranOutcome_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranOutcome_clo;
V g_heff_2ebuild_2ecommands_2eranSubtests(V);
V g_heff_2ebuild_2ecommands_2eranSubtests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranSubtests_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272(V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_clo;
V g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2ecommands_2esubtestJobs(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esubtestJobs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esubtestJobs_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_clo;
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_clo;
V g_heff_2ebuild_2ecommands_2etestsHeld(V, V, V);
V g_heff_2ebuild_2ecommands_2etestsHeld_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsHeld_clo;
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(V, V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138(V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_clo;
V g_heff_2ebuild_2ecommands_2ezigOf(V);
V g_heff_2ebuild_2ecommands_2ezigOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigOf_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl_24s1154189933x180352087(V, V);
V g_list_2efoldl_24s1154189933x180352087_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1154189933x180352087_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s47995487x1780857361(V, V);
V g_list_2efoldl_24s47995487x1780857361_entry(V self, V *a);
extern Clo g_list_2efoldl_24s47995487x1780857361_clo;
V g_list_2efoldl_24s591739608x1065283968(V, V);
V g_list_2efoldl_24s591739608x1065283968_entry(V self, V *a);
extern Clo g_list_2efoldl_24s591739608x1065283968_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s937655778x647278584(V, V);
V g_list_2efoldl_24s937655778x647278584_entry(V self, V *a);
extern Clo g_list_2efoldl_24s937655778x647278584_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24f428638463x2144521938(V, V, V, V);
V g_list_2ekeepIf_24f428638463x2144521938_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f428638463x2144521938_clo;
V g_list_2ekeepIf_24s742867582x682687968(V, V);
V g_list_2ekeepIf_24s742867582x682687968_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s742867582x682687968_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f310588246x1624488069(V, V, V, V);
V g_list_2emap_24f310588246x1624488069_entry(V self, V *a);
extern Clo g_list_2emap_24f310588246x1624488069_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1498757180x165099811(V);
V g_list_2emap_24s1498757180x165099811_entry(V self, V *a);
extern Clo g_list_2emap_24s1498757180x165099811_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2esortBy_24s196358923x1153659155(V);
V g_list_2esortBy_24s196358923x1153659155_entry(V self, V *a);
extern Clo g_list_2esortBy_24s196358923x1153659155_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(V);
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_clo;
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(V);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
V g_std_2efilesystem_2eremove_24s1441356369x419789784(V);
V g_std_2efilesystem_2eremove_24s1441356369x419789784_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eremove_24s1441356369x419789784_clo;
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(V, V);
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str8, 1, "$");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_module_244 = heff_dup(heff_rfield(v_p_242, 0));
    V v_text_245 = heff_dup(heff_rfield(v_p_242, 1));
    V v_t_246 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_247 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_246));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    if (heff_strEq_c(v_module_244, v_t_2410)) {
      V v_t_2411 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2412 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2411); r_; });
      V v_text_2413 = v_text_245;
      V v_t_2414 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str6); V a_1 = v_text_2413; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str7), v_text_2413, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_2413); r_; });
      V v_t_2415 = (g_list_2emap_24s732475005x1616712052(v_t_2414));
      V v_t_2416 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str8); V a_3 = v_t_2415; V r_ = (g_list_2ekeepIf_24f428638463x2144521938(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
      V v_t_2417 = ({ V a_0 = v_t_2412; V a_1 = v_t_2416; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2412); heff_drop(v_t_2416); r_; });
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop(v_k_241);
        heff_drop(v_t_2417);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2417);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      heff_drop(v_text_245);
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeaf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigOf_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigOf_str1, 8, "heff.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigOf_str2, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigOf_str3, 4, ".zig");
Clo g_heff_2ebuild_2ecommands_2ezigOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ezigOf(V v_outPath_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)1ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_241), heff_strLength_lent(v_outPath_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2ebuild_2ecommands_2ezigOf_str0))) {
    return heff_strAppend(v_outPath_240, ((V)&g_heff_2ebuild_2ecommands_2ezigOf_str1));
  } else {
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    V v_t_244 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_243), heff_strLength_lent(v_outPath_240, 0));
    V v_t_246;
    if (heff_strEq_c(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2ezigOf_str2))) {
      int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
      v_t_246 = heff_strSlice(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_245));
    } else {
      v_t_246 = v_outPath_240;
    }
    return heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2ezigOf_str3));
  }
}
V g_heff_2ebuild_2ecommands_2ezigOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigOf(a[0]);
}

static V g_heff_2ebuild_2ecommands_2enoRes_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2enoRes_st;
static V g_heff_2ebuild_2ecommands_2enoRes_init(void) {
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2ebuild_2ecommands_2enoRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2enoRes_st)) return g_heff_2ebuild_2ecommands_2enoRes_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2enoRes_val, &g_heff_2ebuild_2ecommands_2enoRes_st, g_heff_2ebuild_2ecommands_2enoRes_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenPath_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenPath_str1, 7, ".golden");
Clo g_heff_2ebuild_2ecommands_2egoldenPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenPath_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2egoldenPath(V v_st_240, V v_f_241, V v_name_242) {
top: ;
  int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
  V v_t_244 = heff_strSlice(heff_dup(v_f_241), heff_box_word(v_t_243), heff_strLength_lent(v_f_241, 0));
  V v_t_246;
  if (heff_strEq_c(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2egoldenPath_str0))) {
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
    v_t_246 = heff_strSlice(v_f_241, MK_INT(0LL), heff_box_word(v_t_245));
  } else {
    v_t_246 = v_f_241;
  }
  V v_t_247 = (g_std_2epath_2eparse(v_st_240, heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2egoldenPath_str1))));
  V v_t_248 = (g_std_2epath_2eparse(v_st_240, v_name_242));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  return ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
}
V g_heff_2ebuild_2ecommands_2egoldenPath_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldenPath(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str24, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str25, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonGolden_str27, 0, "");
Clo g_heff_2ebuild_2ecommands_2ejsonGolden_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsonGolden_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ejsonGolden(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_JNull: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str0), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str1)});
  }
  case TAG_JBool: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str2), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str3)});
  }
  case TAG_JInt: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str4), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str5)});
  }
  case TAG_JFloat: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str6), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str7)});
  }
  case TAG_JString: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str8), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str9)});
  }
  case TAG_JArray: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str10), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str11)});
    }
    case TAG_Cons: {
      V v_n_246 = heff_field(v_x11_245, 0);
      V v_x112_247 = heff_field(v_x11_245, 1);
      switch (heff_tag_of(v_x112_247)) {
      case TAG_Nil: {
        return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str12), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str13)});
      }
      case TAG_Cons: {
        V v_t_248 = heff_field(v_x112_247, 0);
        V v_t_2416;
        switch (heff_tag_of(v_n_246)) {
        case TAG_JNull: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str14);
          break;
        }
        case TAG_JBool: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str15);
          break;
        }
        case TAG_JInt: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str16);
          break;
        }
        case TAG_JFloat: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str17);
          break;
        }
        case TAG_JString: {
          V v_t_2413 = heff_field(v_n_246, 0);
          v_t_2416 = heff_dup(v_t_2413);
          break;
        }
        case TAG_JArray: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str18);
          break;
        }
        case TAG_JObject: {
          v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str19);
          break;
        }
        default: heff_nomatch(v_n_246);
        }
        V v_t_2423;
        switch (heff_tag_of(v_t_248)) {
        case TAG_JNull: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str20);
          break;
        }
        case TAG_JBool: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str21);
          break;
        }
        case TAG_JInt: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str22);
          break;
        }
        case TAG_JFloat: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str23);
          break;
        }
        case TAG_JString: {
          V v_t_2420 = heff_field(v_t_248, 0);
          v_t_2423 = heff_dup(v_t_2420);
          break;
        }
        case TAG_JArray: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str24);
          break;
        }
        case TAG_JObject: {
          v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str25);
          break;
        }
        default: heff_nomatch(v_t_248);
        }
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_t_2423});
      }
      default: return heff_nomatch(v_x112_247);
      }
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  case TAG_JObject: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str26), ((V)&g_heff_2ebuild_2ecommands_2ejsonGolden_str27)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ejsonGolden_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ejsonGolden(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_str1, 10, "package.hf");
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return v_s_242;
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_st_2412 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2414 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2412, v_x_2413));
  V v_t_2415 = (g_std_2epath_2eparse(v_st_2412, v_a_2414));
  V v_t_2416 = (g_std_2epath_2eparse(v_st_2412, ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_str1)));
  V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
  V v_x_2418 = ({ V a_0 = v_st_2412; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2412); heff_drop(v_t_2417); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_st_2412;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_str0))) {
    v_st_2412 = NTAG(TAG_Windows);
  } else {
    v_st_2412 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam2, 1, 2, (V[]){v_st_2412, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_str0), v_e_243), ((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_str1));
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_WriteErr, 2, (V[]){v_t_245, NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    return (g_co_2eop_24s321980040x1154251472(v_rest_244, heff_dup(v_p_241), v_p_242, heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327(V v_outPath_240, V v_bad_241, V v_o_242, V v_z_243, V v_z_244) {
top: ;
  V v_source_245 = heff_take_field(v_o_242, 0);
  V v_errors_246 = heff_get_n(v_o_242, 1, 2);
  V v_path_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_outPath_240; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_248 = ({ V a_0 = v_path_247; V a_1 = v_source_245; V r_ = (g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a_0, a_1)); heff_drop(v_path_247); r_; });
  V v_c_2412 = heff_tr(heff_call(v_c_248, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam0_clo)}));
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam1, 1, 4, (V[]){v_errors_246, v_z_243, v_z_244, heff_dup(v_bad_241)})});
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_2410 = args[1];
  V v_k_2411 = args[2];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_bad_241 = heff_env(self)[0];
  V v_errors_246 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2424);
  if (!(heff_dup(v_bad_241) == NTAG(TAG_True))) {
    heff_drop(v_bad_241);
    switch (heff_tag_of(v_errors_246)) {
    case TAG_Nil: {
      heff_drop(v_z_243);
      V f_ = v_z_244;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_ru_24errors_246_24Cons = heff_take_reuse_n(v_errors_246, 0ULL, 2);
      V v_t_2427 = heff_tag_at_n(v_ru_24errors_246_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_z_243, v_z_244));
    }
    default: return heff_nomatch(v_errors_246);
    }
  } else {
    heff_drop(v_bad_241);
    heff_drop(v_errors_246);
    V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), v_z_243, v_z_244));
  }
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_errors_246 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 0ULL, 1);
    heff_drop(v_bad_241);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1(v_ru_24x_2413_24Left, v_errors_246, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam2, 1, 2, (V[]){v_z_243, v_z_244})));
  }
  case TAG_Right: {
    V v_ru_24x_2413_24Right = heff_take_reuse_n(v_x_2413, 0ULL, 1);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1(v_ru_24x_2413_24Right, heff_dup(v_errors_246), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam3, 1, 4, (V[]){v_bad_241, v_errors_246, v_z_244, v_z_243})));
  }
  default: return heff_nomatch(v_x_2413);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_str0, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917(V v_ps_240, V v_b_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    top_TAG_Nothing: ;
    V v_t_243 = (g_heff_2ebuild_2ecache_2ehashGo(v_b_241, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    HEFF_LAST return g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819(v_ps_240, v_b_241, v_t_243);
  }
  case TAG_Just: {
    V v_kept_244 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_str0), v_kept_244, MK_INT(0LL), 5);
    if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
      heff_drop(v_kept_244);
      heff_drop(v_j_245);
      V t_0 = v_ps_240;
      V t_1 = v_b_241;
      V t_2 = NTAG(TAG_Nothing);
      v_ps_240 = t_0;
      v_b_241 = t_1;
      v_x3_242 = t_2;
      goto top_TAG_Nothing;
    } else {
      V v_t_246 = heff_intSub(heff_strLength_lent(v_kept_244, 0), heff_dup(v_j_245));
      if ((heff_intEq_c(heff_intSub(heff_dup(v_t_246), MK_INT(1LL)), heff_strLength_lent(v_b_241, 0)) && heff_strEq_c(heff_strSlice(heff_dup(v_kept_244), heff_intAdd(heff_dup(v_j_245), MK_INT(1LL)), heff_strLength_lent(v_kept_244, 0)), heff_dup(v_b_241)))) {
        heff_drop(v_ps_240);
        heff_drop(v_b_241);
        heff_drop(v_t_246);
        return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_lam0, 2, 2, (V[]){v_kept_244, v_j_245});
      } else {
        heff_drop(v_kept_244);
        heff_drop(v_j_245);
        heff_drop(v_t_246);
        V t_0 = v_ps_240;
        V t_1 = v_b_241;
        V t_2 = NTAG(TAG_Nothing);
        v_ps_240 = t_0;
        v_b_241 = t_1;
        v_x3_242 = t_2;
        goto top_TAG_Nothing;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_kept_244 = heff_env(self)[0];
  V v_j_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = heff_strSlice(v_kept_244, MK_INT(0LL), v_j_245);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_str1, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839(V v_ps_240, V v_olds_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam0_clo);
  }
  case TAG_Cons: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_m_247 = heff_field(v_x31_245, 0);
      V v_text_248 = heff_field(v_x31_245, 1);
      HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_olds_241, v_m_247));
      V v_t_2413;
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2411;
          v_t_2413 = v_x_2412;
        } else {
          heff_drop(v_field_2411);
          v_t_2413 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_str0);
        }
      }
      V v_c_2422;
      if (heff_strEq_c_lent(v_text_248, v_t_2413, 2)) {
        v_c_2422 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam1_clo);
      } else {
        V v_d_2416 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
        V v_st_2417 = heff_dup(heff_rfield(v_ps_240, 5));
        V v_t_2418 = (g_std_2epath_2eparse(v_st_2417, v_d_2416));
        V v_t_2419 = (g_std_2epath_2eparse(v_st_2417, heff_strAppend(heff_dup(v_m_247), ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_str1))));
        V v_t_2420 = (g_std_2epath_2ejoin(v_t_2418, v_t_2419));
        V v_t_2421 = ({ V a_0 = v_st_2417; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2420); r_; });
        v_c_2422 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138(v_t_2421, heff_dup(v_text_248)));
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam2, 2, 4, (V[]){v_c_2422, v_ps_240, heff_dup(v_olds_241), heff_dup(v_rest_246)});
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_olds_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2423 = heff_env(self)[3];
  V v_k_2424 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2425);
  V v_t_2426 = ({ V a_0 = v_ps_240; V a_1 = v_olds_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839(a_0, a_1, a_2)); heff_drop(v_olds_241); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2426;
  heff_room[0] = v_hd_2423;
  heff_room[1] = v_k_2424;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam2(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_olds_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam3, 1, 5, (V[]){v_ps_240, v_olds_241, v_rest_246, v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_entry, 12, 0};

V g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210(V v_bi_240, V v_dir_241, V v_rt_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_id_247, V v_texts_248, V v_backs_249, V v_z_2410, V v_z_2411) {
top: ;
  V v_key_2412 = heff_take_field(v_r_246, 0);
  V v_effect_2413 = heff_get_n(v_r_246, 1, 2);
  V v_zig_2414 = heff_take_field(v_rt_242, 1);
  V v_c_2415 = heff_get_n(v_rt_242, 0, 2);
  V v_t_2416 = heff_get_n(heff_get_n(v_c_244, 5, 14), 0, 9);
  V v_t_2417 = (g_std_2emap_2etoListOnto(v_backs_249, NTAG(TAG_Nil)));
  V v_bs_2418 = (g_list_2emap_24s1173914895x100384474(v_t_2417));
  V v_t_2419 = (g_list_2efoldl_24s47995487x1780857361(heff_dup(g_std_2emap_2eempty_get()), v_bs_2418));
  V v_t_2420 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2418; V r_ = (g_list_2efoldl_24s937655778x647278584(a_0, a_1)); heff_drop(v_bs_2418); r_; });
  V v_t_2421 = (g_std_2emap_2etoListOnto(v_backs_249, NTAG(TAG_Nil)));
  V v_bs_2422 = (g_list_2emap_24s1173914895x100384474(v_t_2421));
  V v_t_2423 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2422; V r_ = (g_list_2efoldl_24s1154189933x180352087(a_0, a_1)); heff_drop(v_bs_2422); r_; });
  V v_t_2424 = ({ V a_0 = v_c_2415; V a_1 = v_available_245; V a_2 = v_t_2416; V a_3 = v_key_2412; V a_4 = v_effect_2413; V a_5 = heff_dup(heff_rfield(v_bi_240, 1)); V a_6 = heff_rec_n(2, shape_units__copies, (V[]){v_t_2419, v_t_2420}); V a_7 = v_t_2423; V r_ = (g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2423); r_; });
  return (g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415(v_bi_240, v_dir_241, v_zig_2414, v_id_247, v_texts_248, v_backs_249, v_done_243, v_t_2424, v_z_2410, v_z_2411));
}
V g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_entry(V self, V *a) {
  (void)self;
  V a8 = a[8]; V r = g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a8, a[9], a[10], a[11]); heff_drop(a8); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661(V v_lit_240, V v_rep_241, V v_l_242, V v_name_243, V v_outPath_244, V v_file_245, V v_done_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_str0), heff_dup(heff_rfield(v_l_242, 1)), MK_INT(0LL), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam0, 1, 9, (V[]){v_l_242, v_hd_247, v_rep_241, v_lit_240, v_k_248, v_file_245, v_name_243, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam2(V self, V *args) {
  V v_c_2416 = args[0];
  V v_sources_2414 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2417 = (g_list_2efind_24s4435330x644005164_24cpr(heff_dup(v_c_2416), v_sources_2414));
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_s_2420 = v_field_2419;
      V v_t_2421 = (g_heff_2ebuild_2edriver_2erefusedIn(v_x_2415, v_s_2420));
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2416, v_t_2421));
    } else {
      heff_drop(v_x_2415);
      heff_drop(v_field_2419);
      return v_c_2416;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam4(V self, V *args) {
  V v_a_2444 = args[0];
  V v_z_2445 = args[1];
  V v_z_2446 = args[2];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_2444);
  V v_t_2447 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  return (g_co_2eop_24s847889387x1388281137(heff_tag_n(TAG_InR, 1, (V[]){v_t_2453}), v_z_2445, v_z_2446));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_done_2412 = heff_env(self)[5];
  V v_l_242 = heff_env(self)[6];
  V v_hashes_2413 = heff_env(self)[7];
  V v_file_245 = heff_env(self)[8];
  V v_name_243 = heff_env(self)[9];
  V v_outPath_244 = heff_env(self)[10];
  V v_done_246 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2424);
  if (heff_intLt_c(MK_INT(0LL), v_x_249)) {
    heff_drop(v_done_2412);
    heff_drop_rec(v_l_242, 5);
    heff_drop(v_hashes_2413);
    heff_drop(v_file_245);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_246);
    V v_x2_2425 = (g_heff_2ebuild_2ecommands_2efirstErrorOf(v_x_2422));
    heff_drop(v_x2_2425);
    V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
    return (g_co_2eop_24s847889387x1388281137(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_hd_247, v_k_248));
  } else {
    V v_t_2433 = (g_list_2eany_24s1740858080x874135214(v_x_2422));
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop(v_done_2412);
      heff_drop_rec(v_l_242, 5);
      heff_drop(v_hashes_2413);
      heff_drop(v_file_245);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_246);
      heff_drop(v_t_2433);
      V v_x2_2434 = (g_heff_2ebuild_2ecommands_2efirstErrorOf(v_x_2422));
      heff_drop(v_x2_2434);
      V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
      return (g_co_2eop_24s847889387x1388281137(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_hd_247, v_k_248));
    } else {
      heff_drop(v_t_2433);
      V v_t_2442 = (g_list_2emap_24s1698496827x1884878103(v_done_2412));
      V v_t_2443 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_l_242, 2), v_hashes_2413, v_t_2442});
      return (g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387(v_t_2443, heff_get_n(v_l_242, 0, 5), v_file_245, v_name_243, v_outPath_244, heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam4, 3, 1, (V[]){v_lit_240}), v_done_246, v_x_2422, v_hd_247, v_k_248));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_rep_241 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_file_245 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_done_2412 = heff_take_field(v_x_2411, 0);
  V v_hashes_2413 = heff_get_n(v_x_2411, 1, 2);
  V v_sources_2414 = heff_dup(heff_rfield(v_l_242, 0));
  V v_x_2415 = (g_list_2emap_24f310588246x1624488069(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_str2), heff_dup(v_sources_2414)));
  V v_x_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam2, 1, 2, (V[]){v_sources_2414, v_x_2415}), heff_dup(v_done_2412)));
  V v_c_2423 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(v_rep_241, heff_dup(v_x_2422)));
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam3, 1, 12, (V[]){v_x_249, v_x_2422, v_lit_240, v_hd_247, v_k_248, v_done_2412, v_l_242, v_hashes_2413, v_file_245, v_name_243, v_outPath_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_rep_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_file_245 = heff_env(self)[5];
  V v_name_243 = heff_env(self)[6];
  V v_outPath_244 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2410 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_l_242)));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_lam1, 1, 10, (V[]){v_l_242, v_rep_241, v_hd_247, v_x_249, v_lit_240, v_k_248, v_file_245, v_name_243, v_outPath_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_str0, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_str1, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_str2, 3, " / ");
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam5, 3, 0};
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759(V v_sel_240, V v_j_241, V v_dir_242, V v_ran_243) {
top: ;
  V v_path_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_242); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_245 = ({ V a_0 = v_path_244; V r_ = (g_std_2efilesystem_2eremove_24s1441356369x419789784(a_0)); heff_drop(v_path_244); r_; });
  V v_c_249 = heff_tr(heff_call(v_c_245, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam1, 2, 5, (V[]){v_c_249, v_dir_242, v_j_241, v_ran_243, heff_dup(v_sel_240)});
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_247 = args[1];
  V v_k_248 = args[2];
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_2416 = args[1];
  V v_k_2417 = args[2];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2426 = args[1];
  V v_k_2427 = args[2];
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_j_241 = heff_env(self)[0];
  V v_ran_243 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  V v_sel_240 = heff_env(self)[3];
  V v_k_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2429);
  V v_t_2430 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_str2), heff_dup(heff_rfield(v_j_241, 3)), heff_rfield(v_j_241, 4)));
  V v_t_2431 = (g_heff_2ebuild_2ecommands_2eranOutcome(v_t_2430, heff_dup(heff_rfield(v_j_241, 5)), v_ran_243, heff_dup(v_x_2422)));
  V v_t_2432 = ({ V a_0 = v_x_2422; V r_ = (g_heff_2ebuild_2ecommands_2eranSubtests(a_0)); heff_drop(v_x_2422); r_; });
  V v_t_2433 = ({ V a_0 = v_sel_240; V a_1 = heff_dup(v_j_241); V a_2 = MK_INT(0LL); V a_3 = v_t_2432; V r_ = (g_heff_2ebuild_2ecommands_2esubtestJobs(a_0, a_1, a_2, a_3)); heff_drop(v_sel_240); r_; });
  V v_x_2434 = heff_rec_n(4, shape_owner__place__outcome__next, (V[]){heff_take_field(v_j_241, 0), heff_get_n(v_j_241, 2, 6), v_t_2431, v_t_2433});
  V f_ = v_k_2411;
  args[0] = v_x_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_dir_242 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_j_241 = heff_env(self)[2];
  V v_ran_243 = heff_env(self)[3];
  V v_sel_240 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2422;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    heff_take_n(v_x_2419, 0ULL, 1);
    v_x_2422 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Right = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    v_x_2422 = heff_tag_at_n(v_ru_24x_2419_24Right, TAG_Just, 1, (V[]){v_y_2421});
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V v_path_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(v_dir_242, ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_str1)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2424 = ({ V a_0 = v_path_2423; V r_ = (g_std_2efilesystem_2eremove_24s1441356369x419789784(a_0)); heff_drop(v_path_2423); r_; });
  V v_c_2428 = heff_tr(heff_call(v_c_2424, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam5_clo)}));
  V f_ = v_c_2428;
  heff_room[0] = v_hd_2410;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam6, 1, 5, (V[]){v_j_241, v_ran_243, v_x_2422, v_sel_240, v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_dir_242 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_j_241 = heff_env(self)[2];
  V v_ran_243 = heff_env(self)[3];
  V v_sel_240 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2412);
  V v_path_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(heff_dup(v_dir_242), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_str0)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2414 = ({ V a_0 = v_path_2413; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2413); r_; });
  V v_c_2418 = heff_tr(heff_call(v_c_2414, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam3_clo)}));
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_2410);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam4, 1, 6, (V[]){v_dir_242, v_hd_2410, v_j_241, v_ran_243, v_sel_240, v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_dir_242 = heff_env(self)[1];
  V v_j_241 = heff_env(self)[2];
  V v_ran_243 = heff_env(self)[3];
  V v_sel_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_lam2, 1, 6, (V[]){v_dir_242, v_hd_2410, v_j_241, v_ran_243, v_sel_240, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str0, 3, "  (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str1, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str2, 8, "  skip  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str4, 8, "        ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam3, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_o_244, 2));
    V v_str_2410;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      v_str_2410 = (g_heff_2ebuild_2ecommands_2eranLine(heff_dup(v_o_244)));
      break;
    }
    case TAG_Just: {
      V v_why_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str0), heff_strAppend(v_why_247, ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str1)));
      V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_o_244, 0)), v_t_248);
      v_str_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str2), v_t_249);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam1, 2, 4, (V[]){v_str_2410, v_o_244, heff_dup(v_color_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam3(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_color_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2441);
  V v_t_2442 = ({ V a_0 = v_color_240; V a_1 = v_rest_245; V r_ = (g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738(a_0, a_1)); heff_drop(v_color_240); r_; });
  V f_ = v_t_2442;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_o_244 = heff_env(self)[0];
  V v_color_240 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_take_field(v_o_244, 1);
  V v_c_2440;
  if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
    heff_drop_rec(v_o_244, 12);
    heff_drop(v_t_2422);
    v_c_2440 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam3_clo);
  } else {
    heff_drop(v_t_2422);
    V v_t_2425 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str4), heff_take_field(v_o_244, 8)));
    V v_t_2426 = heff_get_n(v_o_244, 9, 12);
    V v_t_2428;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nothing: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_f_2427 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 1);
      v_t_2428 = (g_heff_2ebuild_2ecommands_2efailLines(v_color_240, v_f_2427));
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    V v_x2_2429 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2428));
    V v_str_2432;
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_Nil: {
      v_str_2432 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_xs_2431 = heff_field(v_x2_2429, 1);
      heff_take_n(v_x2_2429, 3ULL, 2);
      v_str_2432 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str6); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2429);
    }
    V v_t_2433 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2432, ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str7)), NTAG(TAG_MkUnit)});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
    v_c_2440 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})}));
  }
  V f_ = v_c_2440;
  heff_room[0] = heff_dup(v_hd_2411);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam4, 1, 4, (V[]){v_color_240, v_rest_245, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_str_2410 = heff_env(self)[0];
  V v_o_244 = heff_env(self)[1];
  V v_color_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2410, ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_str3)), NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2411, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})}));
  V f_ = heff_dup(heff_rfield(v_hd_2411, 1));
  args[0] = v_t_2420;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1663068441x666046738_lam2, 1, 5, (V[]){v_o_244, v_color_240, v_hd_2411, v_rest_245, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395(V v_rep_240, V v_opts_241, V v_done_242, V v_x3_243, V v_acc_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop_rec(v_opts_241, 4);
    heff_drop(v_done_242);
    heff_drop(v_z_245);
    return heff_tail(v_z_246, 1, (V[]){v_acc_244});
  }
  case TAG_Cons: {
    V v_r_247 = heff_field(v_x3_243, 0);
    V v_rest_248 = heff_field(v_x3_243, 1);
    V v_pending_249 = heff_dup(heff_rfield(v_r_247, 1));
    V v_at_2410 = heff_dup(heff_rfield(v_r_247, 0));
    V v_p_2411 = v_pending_249;
    V v_file_2412 = heff_take_field(v_p_2411, 0);
    V v_outcomes_2413 = heff_take_field(v_p_2411, 3);
    V v_wrong_2414 = heff_take_field(v_p_2411, 1);
    V v_reports_2415 = heff_get_n(v_p_2411, 2, 7);
    V v_t_2416 = (g_list_2ekeepIf_24s742867582x682687968(v_at_2410, heff_dup(v_done_242)));
    V v_t_2417 = (g_list_2esortBy_24s196358923x1153659155(v_t_2416));
    V v_more_2418 = (g_list_2emap_24s1498757180x165099811(v_t_2417));
    V v_t_2419 = (g_prelude_2e_2b_2b(v_outcomes_2413, v_more_2418));
    V v_c_2420 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(heff_rfield(v_opts_241, 3), heff_dup(v_file_2412), v_t_2419));
    V v_k_2423 = heff_clo_n(g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395_lam0, 1, 7, (V[]){v_acc_244, heff_dup(v_rep_240), heff_dup(v_opts_241), v_done_242, heff_dup(v_rest_248), heff_dup(v_z_245), v_z_246});
    return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395_lam1, 1, 7, (V[]){v_opts_241, v_k_2423, v_rep_240, v_file_2412, v_wrong_2414, v_reports_2415, v_z_245})});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395_lam0(V self, V *args) {
  V v_x_2421 = args[0];
  V v_acc_244 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_opts_241 = heff_env(self)[2];
  V v_done_242 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2422 = (g_heff_2ebuild_2ecommands_2eaddRes(v_acc_244, v_x_2421));
  return ({ V a_0 = v_rep_240; V a_1 = v_opts_241; V a_2 = v_done_242; V a_3 = v_rest_248; V a_4 = v_t_2422; V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rest_248); r_; });
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_file_2412 = heff_env(self)[3];
  V v_wrong_2414 = heff_env(self)[4];
  V v_reports_2415 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2425 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_241, heff_dup(v_x_2424)));
  if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
    heff_drop(v_x_2424);
    heff_drop(v_rep_240);
    heff_drop(v_file_2412);
    heff_drop(v_wrong_2414);
    heff_drop(v_reports_2415);
    heff_drop(v_z_245);
    heff_drop(v_t_2425);
    V f_ = v_k_2423;
    args[0] = heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get());
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_2425);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656(v_rep_240, v_file_2412, v_wrong_2414, v_reports_2415, v_x_2424, v_z_245, v_k_2423));
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str0, 40, "files that do not check as they should:\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str1, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str3, 1, "'");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str4, 27, "heff test: no tests match '");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str6, 18, " expectations hold");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str7, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam6, 2, 0};
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733(V v_opts_240, V v_acc_241, V v_p_242, V v_p_243) {
top: ;
  V v_ws_244 = heff_dup(heff_rfield(v_acc_241, 4));
  V v_t_2421;
  switch (heff_tag_of(v_ws_244)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam0_clo);
    break;
  }
  case TAG_Cons: {
    v_t_2421 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam1, 2, 1, (V[]){v_ws_244});
    break;
  }
  default: heff_nomatch(v_ws_244);
  }
  return heff_tail(v_t_2421, 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam3, 1, 4, (V[]){v_opts_240, v_acc_241, v_p_242, v_p_243})});
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ws_244 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2419);
  V v_t_2420 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str1), v_ws_244));
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(v_t_2420, v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_ws_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tag_n(TAG_Write, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str0), NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_249, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})}));
  V f_ = heff_dup(heff_rfield(v_hd_249, 1));
  args[0] = v_t_2418;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam2, 1, 3, (V[]){v_ws_244, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_2423 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_hd_2423, v_k_2424));
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_opts_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_strAppend(heff_get_n(v_opts_240, 1, 4), ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str3));
  V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str4), v_t_2425), ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str5));
  V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2426, NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2423, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})}));
  V f_ = heff_dup(heff_rfield(v_hd_2423, 1));
  args[0] = v_t_2434;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam5, 1, 2, (V[]){v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam6(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  heff_drop(v_hd_2443);
  V f_ = v_k_2444;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam8(V self, V *args) {
  V v_x_2462 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2462);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_241, 3)))) {
    heff_drop_rec(v_acc_241, 8);
    V v_t_2463 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2469}), v_p_242, v_p_243));
  } else {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_241, 6)))) {
      heff_drop_rec(v_acc_241, 8);
      V v_t_2470 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
      V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
      V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
      V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
      V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
      V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2476}), v_p_242, v_p_243));
    } else {
      V v_t_2477 = heff_get_n(v_acc_241, 4, 8);
      switch (heff_tag_of(v_t_2477)) {
      case TAG_Nil: {
        heff_drop_rec(v_p_242, 3);
        V f_ = v_p_243;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        V v_ru_24t_2477_24Cons = heff_take_reuse_n(v_t_2477, 0ULL, 2);
        V v_t_2480 = heff_tag_at_n(v_ru_24t_2477_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
        V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
        V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
        V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
        V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
        V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})});
        return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2486}), v_p_242, v_p_243));
      }
      default: return heff_nomatch(v_t_2477);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam7(V self, V *args) {
  V v_x_2446 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2446);
  V v_t_2447 = heff_intSub(heff_dup(heff_rfield(v_acc_241, 2)), heff_dup(heff_rfield(v_acc_241, 3)));
  V v_t_2448 = heff_intShow(heff_dup(heff_rfield(v_acc_241, 2)));
  V v_t_2449 = (g_heff_2ebuild_2ecommands_2etestsHeld(heff_dup(heff_rfield(v_acc_241, 5)), heff_dup(heff_rfield(v_acc_241, 6)), heff_dup(heff_rfield(v_acc_241, 7))));
  V v_t_2450 = (g_heff_2ebuild_2ecommands_2efilesSaid(heff_dup(v_acc_241)));
  V v_t_2451 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str6), heff_strAppend(v_t_2449, v_t_2450));
  V v_t_2452 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str7), heff_strAppend(v_t_2448, v_t_2451));
  V v_str_2453 = heff_strAppend(heff_intShow(v_t_2447), v_t_2452);
  V v_t_2454 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2453, ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str8)), NTAG(TAG_MkUnit)});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_242, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2460})}));
  V f_ = heff_dup(heff_rfield(v_p_242, 1));
  heff_room[0] = v_t_2461;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam8, 1, 3, (V[]){v_acc_241, v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2422);
  V v_t_2445;
  if ((heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 1)), ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_str2)) ? 0 : heff_intEq_c(heff_dup(heff_rfield(v_acc_241, 5)), MK_INT(0LL)))) {
    v_t_2445 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam4, 2, 1, (V[]){v_opts_240});
  } else {
    heff_drop_rec(v_opts_240, 4);
    v_t_2445 = ((V)&g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam6_clo);
  }
  V f_ = v_t_2445;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_lam7, 1, 3, (V[]){v_acc_241, v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_sources_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799(heff_dup(v_sources_240), v_m_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam1, 2, 3, (V[]){v_c_246, v_sources_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_t_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288(v_sources_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam3, 1, 2, (V[]){v_x_249, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855(V v_bi_240, V v_outPath_241, V v_id_242, V v_texts_243, V v_backs_244, V v_done_245, V v_out_246, V v_z_247, V v_z_248) {
top: ;
  V v_groups_249 = heff_take_field(v_out_246, 1);
  V v_copies_2410 = heff_take_field(v_out_246, 2);
  V v_jss_2411 = heff_take_field(v_out_246, 3);
  V v_output_2412 = heff_get_n(v_out_246, 0, 4);
  V v_paths_2413 = heff_take_field(v_bi_240, 0);
  V v_modules_2414 = heff_get_n(v_bi_240, 2, 3);
  V v_t_2431;
  if (heff_strEq_c_lent(v_id_242, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_str0), 2)) {
    heff_drop(v_id_242);
    heff_drop(v_backs_244);
    heff_drop(v_groups_249);
    heff_drop(v_copies_2410);
    heff_drop(v_jss_2411);
    heff_drop(v_paths_2413);
    heff_drop(v_modules_2414);
    v_t_2431 = v_done_245;
  } else {
    V v_s_2415 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_paths_2413)));
    V v_path_2416 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2415; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2417 = ({ V a_0 = v_path_2416; V r_ = (g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(a_0)); heff_drop(v_path_2416); r_; });
    V v_c_2421 = heff_tr(heff_call(v_c_2417, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam0_clo)}));
    v_t_2431 = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam1, 2, 10, (V[]){v_c_2421, heff_dup(v_texts_243), v_modules_2414, v_groups_249, v_copies_2410, v_jss_2411, v_id_242, v_backs_244, v_paths_2413, v_done_245});
  }
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(v_outPath_241, v_t_2431, v_output_2412, v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam0(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_2419 = args[1];
  V v_k_2420 = args[2];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_done_245 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2430);
  V f_ = v_done_245;
  heff_room[0] = v_hd_2422;
  heff_room[1] = v_k_2423;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_texts_243 = heff_env(self)[0];
  V v_modules_2414 = heff_env(self)[1];
  V v_groups_249 = heff_env(self)[2];
  V v_copies_2410 = heff_env(self)[3];
  V v_jss_2411 = heff_env(self)[4];
  V v_id_242 = heff_env(self)[5];
  V v_backs_244 = heff_env(self)[6];
  V v_paths_2413 = heff_env(self)[7];
  V v_hd_2422 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  V v_k_2423 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2424);
  V v_t_2425 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_texts_243; V r_ = (g_list_2efoldl_24s591739608x1065283968(a_0, a_1)); heff_drop(v_texts_243); r_; });
  V v_t_2426 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_str1), v_modules_2414}); V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2427 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_groups_249, v_copies_2410, NTAG(TAG_Nil), v_jss_2411});
  V v_t_2428 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_242, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2426, v_backs_244}), v_t_2427));
  V v_c_2429 = ({ V a_0 = v_paths_2413; V a_1 = v_t_2425; V a_2 = v_t_2428; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839(a_0, a_1, a_2)); heff_drop(v_t_2425); heff_drop(v_t_2428); r_; });
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_hd_2422);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam3, 1, 3, (V[]){v_done_245, v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam1(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_texts_243 = heff_env(self)[1];
  V v_modules_2414 = heff_env(self)[2];
  V v_groups_249 = heff_env(self)[3];
  V v_copies_2410 = heff_env(self)[4];
  V v_jss_2411 = heff_env(self)[5];
  V v_id_242 = heff_env(self)[6];
  V v_backs_244 = heff_env(self)[7];
  V v_paths_2413 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam2, 1, 11, (V[]){v_texts_243, v_modules_2414, v_groups_249, v_copies_2410, v_jss_2411, v_id_242, v_backs_244, v_paths_2413, v_hd_2422, v_done_245, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str0, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str1, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str2, 91, ": load it in a page with <script src=\"...\"> (it imports nothing: it opens from file:// too)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str4, 3, "esm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str5, 70, "heff compile: an ES module runs nothing: no --name with --backend=esm\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str6, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str7, 25, "heff compile: no backend ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str8, 16, ": esm, page or c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478(V v_rep_240, V v_o_241) {
top: ;
  V v_backend_242 = heff_take_field(v_o_241, 3);
  V v_outPath_243 = heff_take_field(v_o_241, 1);
  V v_name_244 = heff_take_field(v_o_241, 2);
  V v_file_245 = heff_get_n(v_o_241, 0, 4);
  if (heff_strEq_c_lent(v_backend_242, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str0), 2)) {
    heff_drop(v_backend_242);
    V v_outPath_246 = v_outPath_243;
    return ({ V a_0 = v_rep_240; V a_1 = v_name_244; V a_2 = heff_dup(v_outPath_246); V a_3 = v_file_245; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam0, 2, 1, (V[]){v_outPath_246}); V r_ = (g_heff_2ebuild_2ecommands_2ecompileThen_24s98061754x1001362404(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_name_244); r_; });
  } else {
    if (heff_strEq_c_lent(v_backend_242, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str4), 2)) {
      heff_drop(v_backend_242);
      switch (heff_tag_of(v_name_244)) {
      case TAG_Nothing: {
        return (g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s842117298x1202227731(v_rep_240, v_file_245, v_outPath_243));
      }
      case TAG_Just: {
        heff_take_n(v_name_244, 0ULL, 1);
        heff_drop(v_rep_240);
        heff_drop(v_outPath_243);
        heff_drop(v_file_245);
        return ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam1_clo);
      }
      default: return heff_nomatch(v_name_244);
      }
    } else {
      if (heff_strEq_c_lent(v_backend_242, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str6), 2)) {
        heff_drop(v_backend_242);
        return (g_heff_2ebuild_2ecommands_2ecCmd_24s1544311966x700227597(v_rep_240, v_name_244, v_outPath_243, v_file_245));
      } else {
        heff_drop(v_rep_240);
        heff_drop(v_outPath_243);
        heff_drop(v_name_244);
        heff_drop(v_file_245);
        return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam3, 2, 1, (V[]){v_backend_242});
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_outPath_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_249 = heff_take_field(v_hd_247, 1);
  V v_malg_2410 = heff_get_n(v_hd_247, 2, 3);
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str1), heff_strAppend(v_outPath_246, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str2)));
  V v_t_2412 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str3)), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(v_malg_2410, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})}));
  V f_ = v_bind_249;
  args[0] = v_t_2419;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam2(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_2421 = heff_env(self)[0];
  V v_k_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2431);
  V v_t_2432 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), v_hd_2421, v_k_2422));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam1(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str5), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2421, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})}));
  V f_ = heff_dup(heff_rfield(v_hd_2421, 1));
  args[0] = v_t_2430;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam2, 1, 2, (V[]){v_hd_2421, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam4(V self, V *args) {
  V v_x_2450 = args[0];
  V v_hd_2439 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2450);
  V v_t_2451 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), v_hd_2439, v_k_2440));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam3(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_backend_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str7), heff_strAppend(v_backend_242, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str8)));
  V v_t_2442 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2441, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_str9)), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2439, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})}));
  V f_ = heff_dup(heff_rfield(v_hd_2439, 1));
  args[0] = v_t_2449;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1803569799x1857253478_lam4, 1, 2, (V[]){v_hd_2439, v_k_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str0, 16, " not formatted: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str1, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam2, 3, 0};
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375(V v_checkOnly_240, V v_f_241, V v_src_242, V v_fix_243, V v_z_244, V v_z_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_fix_243, heff_dup(v_src_242)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_src_242);
      V v_why_249 = v_field_248;
      V v_t_2410 = heff_strAppend(v_f_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str0), v_why_249));
      V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str1), v_t_2410), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str2));
      V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2419, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam0, 1, 1, (V[]){v_z_245})});
    } else {
      V v_out_2421 = v_field_248;
      if (heff_strEq_c_lent(v_out_2421, v_src_242, 2)) {
        heff_drop(v_f_241);
        heff_drop_rec(v_z_244, 3);
        heff_drop(v_out_2421);
        return heff_tail(v_z_245, 1, (V[]){MK_INT(0LL)});
      } else {
        if ((heff_dup(v_checkOnly_240) == NTAG(TAG_True))) {
          heff_drop(v_out_2421);
          V v_t_2422 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_f_241, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str3)), NTAG(TAG_MkUnit)});
          V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
          V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
          V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
          V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
          V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
          V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
          V v_t_2429 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})}));
          return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2429, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam1, 1, 1, (V[]){v_z_245})});
        } else {
          V v_path_2431 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_f_241; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
          V v_c_2432 = ({ V a_0 = v_path_2431; V a_1 = v_out_2421; V r_ = (g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a_0, a_1)); heff_drop(v_path_2431); r_; });
          V v_c_2436 = heff_tr(heff_call(v_c_2432, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam2_clo)}));
          return heff_tail(v_c_2436, 2, (V[]){v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam3, 1, 1, (V[]){v_z_245})});
        }
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2420);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam1(V self, V *args) {
  V v_x_2430 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2430);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam2(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_2434 = args[1];
  V v_k_2435 = args[2];
  heff_drop(v_hd_2434);
  V f_ = v_k_2435;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam3(V self, V *args) {
  V v_x_2437 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2437);
  V f_ = v_z_245;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str0, 2, "--");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str1, 9, "^{commit}");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str2, 32, "--date=format-local:%Y%m%d%H%M%S");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str3, 15, "--format=%cd %H");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str4, 3, "log");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str5, 2, "-1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str6, 2, "TZ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str7, 4, "UTC0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str8, 3, "git");
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819(V v_dir_240, V v_rev_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_dir_240; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str0), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_rev_241, ((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str1)), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str3), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str5), v_t_245})});
  V v_t_247 = ({ V a_0 = v_t_242; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_242); r_; });
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str6), ((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str7)}), NTAG(TAG_Nil)});
  V v_t_249 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_str8), v_t_246, v_t_247, v_t_248, NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2411 = heff_tag_n(TAG_Run, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_lam1, 2, 1, (V[]){v_a_2411});
}
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ended_2424 = heff_take_field(v_x_2423, 0);
  V v_out_2425 = heff_get_n(v_x_2423, 1, 3);
  V v_x_2435;
  switch (heff_tag_of(v_ended_2424)) {
  case TAG_Exited: {
    V v_n_2426 = heff_field(v_ended_2424, 0);
    V v_ru_24ended_2424_24Exited = heff_take_reuse_n(v_ended_2424, 1ULL, 1);
    if (heff_intEq_c(v_n_2426, MK_INT(0LL))) {
      V v_x1_2427 = ({ V a_0 = v_out_2425; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewordsFrom(a_0, a_1, a_2, a_3)); heff_drop(v_out_2425); r_; });
      switch (heff_tag_of(v_x1_2427)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24ended_2424_24Exited, 1);
        v_x_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_time_2428 = heff_field(v_x1_2427, 0);
        V v_x12_2429 = heff_field(v_x1_2427, 1);
        heff_take_n(v_x1_2427, 3ULL, 2);
        switch (heff_tag_of(v_x12_2429)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24ended_2424_24Exited, 1);
          heff_drop(v_time_2428);
          v_x_2435 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_hash_2430 = heff_field(v_x12_2429, 0);
          V v_x122_2431 = heff_field(v_x12_2429, 1);
          heff_take_n(v_x12_2429, 3ULL, 2);
          switch (heff_tag_of(v_x122_2431)) {
          case TAG_Nil: {
            v_x_2435 = heff_tag_at_n(v_ru_24ended_2424_24Exited, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_time_2428, v_hash_2430})});
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x122_2431, 0ULL, 2);
            heff_drop_cell(v_ru_24ended_2424_24Exited, 1);
            heff_drop(v_time_2428);
            heff_drop(v_hash_2430);
            v_x_2435 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x122_2431);
          }
          break;
        }
        default: heff_nomatch(v_x12_2429);
        }
        break;
      }
      default: heff_nomatch(v_x1_2427);
      }
    } else {
      heff_drop(v_out_2425);
      heff_drop_cell(v_ru_24ended_2424_24Exited, 1);
      v_x_2435 = NTAG(TAG_Nothing);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2424, 0ULL, 1);
    heff_drop(v_out_2425);
    v_x_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_TimedOut: {
    heff_drop(v_out_2425);
    v_x_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_NotRun: {
    heff_drop(v_out_2425);
    v_x_2435 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_ended_2424);
  }
  V f_ = v_k_2413;
  args[0] = v_x_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_a_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2414 = heff_take_field(v_hd_2412, 1);
  V v_malg_2415 = heff_get_n(v_hd_2412, 2, 3);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(v_malg_2415, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})}));
  V f_ = v_bind_2414;
  args[0] = v_t_2422;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_lam2, 1, 1, (V[]){v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam4, 3, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823(V v_path_240) {
top: ;
  V v_path_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_path_240); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_242 = (g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(v_path_241));
  V v_c_247 = heff_tr(heff_call(v_c_242, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam2, 2, 2, (V[]){v_c_247, v_path_240});
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823(a[0]);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_x_244 = (g_list_2emap_24s219049803x1458391381(v_x_243));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam1, 2, 1, (V[]){v_x_244});
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2415 = args[1];
  V v_k_2416 = args[2];
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    heff_take_n(v_x_2418, 0ULL, 1);
    V f_ = v_k_249;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2418, 0ULL, 1);
    V f_ = v_k_249;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    heff_take_n(v_x_2410, 0ULL, 1);
    V v_path_2412 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2413 = ({ V a_0 = v_path_2412; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2412); r_; });
    V v_c_2417 = heff_tr(heff_call(v_c_2413, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam4_clo)}));
    V f_ = v_c_2417;
    heff_room[0] = v_hd_248;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam5, 1, 1, (V[]){v_k_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2410, 0ULL, 1);
    heff_drop(v_path_240);
    heff_drop(v_hd_248);
    V f_ = v_k_249;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam2(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam3, 1, 3, (V[]){v_path_240, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_str0, 24, "putting the programs in ");
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650(V v_prog_240, V v_st_241, V v_t_242, V v_next_243, V v_progs_244) {
top: ;
  V v_path_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(heff_rfield(v_t_242, 1)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_246 = ({ V a_0 = v_path_245; V r_ = (g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(a_0)); heff_drop(v_path_245); r_; });
  V v_c_2410 = heff_tr(heff_call(v_c_246, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam1, 2, 6, (V[]){v_c_2410, heff_dup(v_progs_244), v_t_242, v_prog_240, heff_dup(v_st_241), v_next_243});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650(a[0], a1, a[2], a[3], a4); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_248 = args[1];
  V v_k_249 = args[2];
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam3(V self, V *args) {
  V v_t_2416 = args[0];
  return v_t_2416;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_hd_2421 = heff_env(self)[1];
  V v_k_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2423);
  V f_ = v_next_243;
  heff_room[0] = v_hd_2421;
  heff_room[1] = v_k_2422;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_t_2420 = heff_env(self)[0];
  V v_next_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s615738393x1686646143(v_t_2420, heff_dup(v_hd_2421), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam6, 1, 3, (V[]){v_next_243, v_hd_2421, v_k_2422})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_next_243 = heff_env(self)[3];
  V v_progs_244 = heff_env(self)[4];
  V v_hd_2411 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2419 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2418), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2419}));
  V v_t_2424 = ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_x_2418; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam5, 2, 2, (V[]){v_t_2420, v_next_243}); V a_5 = v_progs_244; V r_ = (g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_241); heff_drop(v_progs_244); r_; });
  V f_ = v_t_2424;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_progs_244 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2413);
  V v_total_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_244));
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_str0), heff_dup(heff_rfield(v_t_242, 1)));
  V v_t_2417 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2415, v_total_2414, ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam3_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2417, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam4, 1, 7, (V[]){v_prog_240, v_st_241, v_t_242, v_next_243, v_progs_244, v_hd_2411, v_k_2412})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_progs_244 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_lam2, 1, 7, (V[]){v_progs_244, v_t_242, v_prog_240, v_hd_2411, v_st_241, v_next_243, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str0, 12, "cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str4, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str5, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str7, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str9, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str10, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str13, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str14, 3, "src");
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272(V v_before_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_before_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam0_clo);
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_path_246 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_path_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_247 = ({ V a_0 = v_path_246; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_246); r_; });
    V v_c_2411 = heff_tr(heff_call(v_c_247, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam1_clo)}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam2, 2, 4, (V[]){v_c_2411, v_path_244, v_before_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_249 = args[1];
  V v_k_2410 = args[2];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2434);
  V f_ = v_k_2413;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2425);
  V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_2412, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  heff_room[0] = v_t_2433;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam5, 1, 1, (V[]){v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam6(V self, V *args) {
  V v_s_2436 = args[0];
  return v_s_2436;
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam10(V self, V *args) {
  V v_i_2463 = args[0];
  V v_before_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2464 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_i_2463}));
  return ({ V a_0 = v_t_2464; V a_1 = v_before_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_before_240); r_; });
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam9(V self, V *args) {
  V v_x_2455 = args[0];
  V v_st_2446 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_lib_2449 = heff_env(self)[2];
  V v_mod_2450 = heff_env(self)[3];
  V v_cwd_2451 = heff_env(self)[4];
  V v_style_2452 = heff_env(self)[5];
  V v_before_240 = heff_env(self)[6];
  V v_y_2435 = heff_env(self)[7];
  V v_k_2413 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_m_2456 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str8), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str9), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str10), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str11), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str12), v_st_2446}), heff_dup(v_path_244)));
  V v_ps_2457 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str13), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str14), v_lib_2449, v_mod_2450, v_cwd_2451, v_style_2452});
  HeffT2 v_t_2458 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_2457), heff_get_n(v_ps_2457, 2, 6), heff_dup(v_path_244)));
  V v_library_2462;
  {
    V v_field_2460 = v_t_2458.f[1];
    int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
    v_library_2462 = heff_bool(((v_tag_2459 == ((int64_t)0ULL)) && ({ V v_x_2461 = heff_dup(v_field_2460); int c_ = 1; heff_drop(v_x_2461); c_; })));
    heff_drop(v_field_2460);
  }
  V v_t_2465 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam10, 1, 1, (V[]){v_before_240}), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get())));
  V v_t_2466 = heff_rec_n(8, shape_module__named__path__shown__source__renames__implicit__library, (V[]){heff_dup(v_m_2456), v_m_2456, heff_dup(v_path_244), v_path_244, v_y_2435, NTAG(TAG_Nil), v_t_2465, v_library_2462});
  V v_x_2467 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2466, v_x_2455});
  V f_ = v_k_2413;
  args[0] = v_x_2467;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam8(V self, V *args) {
  V v_x_2448 = args[0];
  V v_st_2446 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_hd_2412 = heff_env(self)[4];
  V v_y_2435 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_lib_2449 = heff_take_field(v_x_2448, 0);
  V v_mod_2450 = heff_take_field(v_x_2448, 1);
  V v_cwd_2451 = heff_take_field(v_x_2448, 2);
  V v_style_2452 = heff_get_n(v_x_2448, 3, 5);
  V v_t_2453 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str3), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str4), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str5), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str6), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str7), heff_dup(v_st_2446)}), heff_dup(v_path_244)));
  V v_c_2454 = (g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, heff_dup(v_before_240)}), v_rest_245));
  V f_ = v_c_2454;
  heff_room[0] = v_hd_2412;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam9, 1, 9, (V[]){v_st_2446, v_path_244, v_lib_2449, v_mod_2450, v_cwd_2451, v_style_2452, v_before_240, v_y_2435, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam7(V self, V *args) {
  V v_x_2445 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_y_2435 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2446;
  if (heff_strEq_c(v_x_2445, ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str2))) {
    v_st_2446 = NTAG(TAG_Windows);
  } else {
    v_st_2446 = NTAG(TAG_Posix);
  }
  V v_c_2447 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo);
  V f_ = v_c_2447;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam8, 1, 7, (V[]){v_st_2446, v_path_244, v_before_240, v_rest_245, v_hd_2412, v_y_2435, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  V v_before_240 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 0ULL, 1);
    heff_drop(v_before_240);
    heff_drop(v_rest_245);
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str0), v_path_244), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str1));
    V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_at_n(v_ru_24x_2414_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})}));
    V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
    heff_room[0] = v_t_2424;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam4, 1, 2, (V[]){v_hd_2412, v_k_2413});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2435 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Right = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    V v_t_2437 = heff_tag_at_n(v_ru_24x_2414_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam6_clo)})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){v_t_2443}));
    V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
    heff_room[0] = v_t_2444;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam7, 1, 6, (V[]){v_hd_2412, v_path_244, v_before_240, v_rest_245, v_y_2435, v_k_2413});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam3, 1, 5, (V[]){v_path_244, v_hd_2412, v_k_2413, v_before_240, v_rest_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}