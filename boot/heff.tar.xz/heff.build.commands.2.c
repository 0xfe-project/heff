// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MkDir 57961
#define TAG_Move 53768
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Windows 49101
#define TAG_WorkingDir 28879
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_build 295453320
#define LBL_copies 592412158
#define LBL_cwd 308458
#define LBL_done 9584713
#define LBL_emits 297985818
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_files 298792593
#define LBL_groups 709681407
#define LBL_heff 9694020
#define LBL_jss 315076
#define LBL_lib 316671
#define LBL_mod 317820
#define LBL_mods 9852536
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_olds 9909235
#define LBL_output 941629484
#define LBL_package 1572278921
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_text 10052084
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_version 583465758
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_lib__mod__cwd__style__heff[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style, LBL_heff};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957(V, V, V);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_clo;
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_clo;
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_get(void);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo;
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914(V, V, V);
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_clo;
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(V);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334(V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655(V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_clo;
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_clo;
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321(V);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_clo;
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115(V);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_clo;
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258(V, V, V);
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_clo;
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410(V);
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_clo;
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(V, V);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(V, V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_clo;
V g_heff_2ebuild_2eproject_2emajorMismatch(V, V);
V g_heff_2ebuild_2eproject_2emajorMismatch_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2emajorMismatch_clo;
V g_heff_2ebuild_2eproject_2epackageLit(V);
V g_heff_2ebuild_2eproject_2epackageLit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageLit_clo;
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
V g_heff_2ebuild_2eproject_2ewithPackage(V, V);
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ewithPackage_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2esyntax_2eformat_2eformat(V);
V g_heff_2esyntax_2eformat_2eformat_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eformat_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1875112453x1656618700(V, V);
V g_list_2eany_24s1875112453x1656618700_entry(V self, V *a);
extern Clo g_list_2eany_24s1875112453x1656618700_clo;
V g_list_2eany_24s1996724342x1838336560(V);
V g_list_2eany_24s1996724342x1838336560_entry(V self, V *a);
extern Clo g_list_2eany_24s1996724342x1838336560_clo;
V g_list_2eany_24s332527547x6651279(V, V);
V g_list_2eany_24s332527547x6651279_entry(V self, V *a);
extern Clo g_list_2eany_24s332527547x6651279_clo;
V g_list_2efilter_24f1668687542x1574966783(V, V, V, V);
V g_list_2efilter_24f1668687542x1574966783_entry(V self, V *a);
extern Clo g_list_2efilter_24f1668687542x1574966783_clo;
V g_list_2efilter_24s2101000672x961294372(V, V, V, V);
V g_list_2efilter_24s2101000672x961294372_entry(V self, V *a);
extern Clo g_list_2efilter_24s2101000672x961294372_clo;
V g_list_2efoldl_24f556306710x2087456230(V, V, V, V);
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a);
extern Clo g_list_2efoldl_24f556306710x2087456230_clo;
V g_list_2efoldl_24s1002907040x997927369(V, V);
V g_list_2efoldl_24s1002907040x997927369_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1002907040x997927369_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2040448920x1981923787(V, V);
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2040448920x1981923787_clo;
V g_list_2efoldl_24s489050722x1368997552(V, V);
V g_list_2efoldl_24s489050722x1368997552_entry(V self, V *a);
extern Clo g_list_2efoldl_24s489050722x1368997552_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s1814289659x520383890(V, V, V);
V g_list_2emap_24s1814289659x520383890_entry(V self, V *a);
extern Clo g_list_2emap_24s1814289659x520383890_clo;
V g_list_2emap_24s2029274225x672412636(V, V, V, V);
V g_list_2emap_24s2029274225x672412636_entry(V self, V *a);
extern Clo g_list_2emap_24s2029274225x672412636_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2esortBy_24s492793466x2081132734(V);
V g_list_2esortBy_24s492793466x2081132734_entry(V self, V *a);
extern Clo g_list_2esortBy_24s492793466x2081132734_clo;
V g_map_2eempty_get(void);
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2estrFind(V, V, V);
V g_prelude_2estrFind_entry(V self, V *a);
extern Clo g_prelude_2estrFind_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enormalize(V, V);
V g_std_2epath_2enormalize_entry(V self, V *a);
extern Clo g_std_2epath_2enormalize_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str8, 1, "$");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0), heff_dup(v_k_241), MK_INT(0LL)));
    V v_t_245 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1), heff_dup(v_k_241), MK_INT(0LL), v_t_244, NTAG(TAG_Nil)));
    V v_x2_246 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_245));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_242, 0)), v_t_249)) {
      V v_t_2411 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4), heff_dup(v_k_241), MK_INT(0LL)));
      V v_t_2412 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5), heff_dup(v_k_241), MK_INT(0LL), v_t_2411, NTAG(TAG_Nil)));
      V v_t_2413 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2412; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2412); r_; });
      V v_text_2414 = heff_dup(heff_rfield(v_p_242, 1));
      V v_t_2415 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str6), heff_dup(v_text_2414), MK_INT(0LL)));
      V v_t_2416 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str7), v_text_2414, MK_INT(0LL), v_t_2415, NTAG(TAG_Nil)));
      V v_t_2417 = (g_list_2emap_24s732475005x1616712052(v_t_2416));
      V v_t_2418 = (g_list_2efilter_24f1668687542x1574966783(MK_INT(0LL), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str8), v_t_2417));
      V v_t_2419 = ({ V a_0 = v_t_2413; V a_1 = v_t_2418; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2418); r_; });
      if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
        heff_drop(v_k_241);
        heff_drop(v_t_2419);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2419);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeaf(a0, a[1]); heff_drop(a0); return r;
}

static V g_heff_2ebuild_2ecommands_2enoRes_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2enoRes_st;
static V g_heff_2ebuild_2ecommands_2enoRes_init(void) {
  return heff_rec_n(7, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2ebuild_2ecommands_2enoRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2enoRes_st)) return g_heff_2ebuild_2ecommands_2enoRes_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2enoRes_val, &g_heff_2ebuild_2ecommands_2enoRes_st, g_heff_2ebuild_2ecommands_2enoRes_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_str1, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_str2, 6, "source");
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam2(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam4(V self, V *args) {
  V v_s_249 = args[0];
  return v_s_249;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam6(V self, V *args) {
  V v_s_2416 = args[0];
  return v_s_2416;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam9(V self, V *args) {
  V v_t_2424 = args[0];
  return v_t_2424;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam11(V self, V *args) {
  V v_t_2430 = args[0];
  return v_t_2430;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam12(V self, V *args) {
  V v_x_2434 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_248 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2435 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2415, v_x_2420));
  V v_t_2436 = ({ V a_0 = v_x_2428; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_x_2428); r_; });
  V v_t_2437 = ({ V a_0 = v_x_2434; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_x_2434); r_; });
  V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2436, v_t_2437));
  V v_x_2439 = heff_rec_n(5, shape_lib__mod__cwd__style__heff, (V[]){v_x_242, v_x_243, v_x_248, v_st_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_t_2438})});
  V f_ = v_k_241;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam10(V self, V *args) {
  V v_x_2428 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_x_243 = heff_env(self)[5];
  V v_x_248 = heff_env(self)[6];
  V v_k_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_path_2429 = (g_std_2epath_2ejoin(v_st_2415, v_x_2421, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_str2)));
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2429, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam11_clo)})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s954557541x749476273(v_t_2433, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam12, 1, 7, (V[]){v_st_2415, v_x_2420, v_x_2428, v_x_242, v_x_243, v_x_248, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam8(V self, V *args) {
  V v_x_2421 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_248 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_home_2422 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2415, heff_dup(v_x_2420)));
  V v_path_2423 = (g_std_2epath_2ejoin(v_st_2415, v_home_2422, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_str1)));
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2423, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam9_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s954557541x749476273(v_t_2427, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam10, 1, 8, (V[]){v_st_2415, v_x_2421, v_hd_240, v_x_2420, v_x_242, v_x_243, v_x_248, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam7(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_st_2415 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_k_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam8, 1, 7, (V[]){v_st_2415, v_x_2420, v_hd_240, v_x_242, v_x_243, v_x_248, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_k_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2415;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_str0))) {
    v_st_2415 = NTAG(TAG_Windows);
  } else {
    v_st_2415 = NTAG(TAG_Posix);
  }
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam6_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam7, 1, 6, (V[]){v_hd_240, v_st_2415, v_x_242, v_x_243, v_x_248, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam4_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam5, 1, 5, (V[]){v_hd_240, v_x_242, v_x_243, v_x_248, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WorkingDir, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam2_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_247}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam3, 1, 4, (V[]){v_hd_240, v_x_242, v_x_243, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam1, 1, 3, (V[]){v_hd_240, v_x_242, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_str1, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_str2, 8, "compiler");
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(V v_ps_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_246}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_ps_240}));
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam2(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam4(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_b_2413 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2422 = (g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613(v_ps_240, v_b_2413, v_x_2421));
  V f_ = v_t_2422;
  heff_room[0] = v_hd_241;
  heff_room[1] = v_k_242;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_str0);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_b_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Just = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_d_2414 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_str1)));
    V v_d_2415 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_2414, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
    V v_path_2416 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_2415, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_str2)));
    V v_t_2418 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2416, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam4_clo)})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s954557541x749476273(v_t_2420, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam5, 1, 4, (V[]){v_ps_240, v_b_2413, v_hd_241, v_k_242})));
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_x_247, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam2_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s954557541x749476273(v_t_2411, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam3, 1, 3, (V[]){v_k_242, v_ps_240, v_hd_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_str1, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_d_246 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_str0)));
    V v_d_247 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_246, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
    V v_path_248 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_247, heff_strAppend(heff_dup(v_m_244), ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_str1))));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam1, 2, 4, (V[]){v_path_248, v_ps_240, v_rest_245, v_m_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam2(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    heff_drop(v_m_244);
    v_t_2419 = v_x_2417;
    break;
  }
  case TAG_Just: {
    V v_text_2418 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_244, v_text_2418}), v_x_2417});
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V f_ = v_k_2410;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_m_244 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2416 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(v_ps_240, v_rest_245));
  V f_ = v_c_2416;
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam4, 1, 3, (V[]){v_x_2415, v_m_244, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_path_248 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_m_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_248, ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam3, 1, 5, (V[]){v_ps_240, v_rest_245, v_hd_249, v_m_244, v_k_2410})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_str0, 4, "test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_str1, 68, "heff test: no test/ here: test at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_str2, 4, "test");
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam0, 2, 0};
Clo g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410(V v_given_240) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam0_clo);
  }
  case TAG_Cons: {
    V v_t_2424 = (g_list_2emap_24s1420651609x666245096(v_given_240));
    return (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(v_t_2424, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410(a[0]);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam1(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2417);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2412);
  V v_t_2413 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s954557541x749476273(v_t_2416, v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam4, 1, 1, (V[]){v_k_242})));
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_str1), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam3, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Just: {
    heff_take_n(v_x_247, 0ULL, 1);
    V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_str2)});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
    V v_t_2421 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(v_t_2420, NTAG(TAG_Nil)));
    V f_ = v_t_2421;
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_str0), ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam1_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  return (g_co_2eop_24s954557541x749476273(v_t_246, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam2, 1, 2, (V[]){v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321(V v_file_240) {
top: ;
  V v_c_241 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_file_240)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam0, 2, 2, (V[]){v_c_241, v_file_240});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321(a[0]);
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_file_240; V b_1 = heff_intLt(MK_INT(0LL), v_x_245); V a_2 = heff_get_n(v_x_247, 0, 2); V a_3 = v_hd_242; V a_4 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(v_x_244));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam3, 1, 4, (V[]){v_file_240, v_x_245, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_str0), heff_dup(heff_rfield(v_x_244, 1)), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam2, 1, 4, (V[]){v_x_244, v_hd_242, v_file_240, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam1, 1, 3, (V[]){v_hd_242, v_file_240, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_str1, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_str2, 1, "_");
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251(V v_bi_240, V v_outPath_241, V v_id_242, V v_texts_243, V v_backs_244, V v_done_245, V v_out_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_2427;
  if (heff_strEq_c_lent(v_id_242, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_str0), 2)) {
    heff_drop_rec(v_bi_240, 3);
    heff_drop(v_id_242);
    heff_drop(v_backs_244);
    v_t_2427 = v_done_245;
  } else {
    V v_ps_2410 = heff_dup(heff_rfield(v_bi_240, 0));
    V v_d_2411 = (g_std_2epath_2ejoin(heff_rfield(v_ps_2410, 5), heff_take_field(v_ps_2410, 0), ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_str1)));
    V v_path_2412 = ({ V b_0 = heff_get_n(v_ps_2410, 5, 6); V a_1 = v_d_2411; V a_2 = heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get()); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    v_t_2427 = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_lam0, 2, 7, (V[]){v_path_2412, heff_dup(v_texts_243), v_bi_240, heff_dup(v_out_246), v_id_242, v_backs_244, v_done_245});
  }
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463(v_outPath_241, v_t_2427, heff_get_n(v_out_246, 0, 4), v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_lam1(V self, V *args) {
  V v_ok_2415 = args[0];
  return v_ok_2415;
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_done_245 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2426);
  V f_ = v_done_245;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_texts_243 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_out_246 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  V v_backs_244 = heff_env(self)[4];
  V v_hd_2413 = heff_env(self)[5];
  V v_done_245 = heff_env(self)[6];
  V v_k_2414 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2419);
  V v_t_2420 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_texts_243; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_texts_243); r_; });
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_str2), heff_take_field(v_bi_240, 2)});
  V v_t_2422 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop_tag(v_t_2421, 2); r_; });
  V v_t_2423 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){heff_take_field(v_out_246, 1), heff_take_field(v_out_246, 2), NTAG(TAG_Nil), heff_get_n(v_out_246, 3, 4)});
  V v_t_2424 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_242, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2422, v_backs_244}), v_t_2423));
  V v_c_2425 = ({ V a_0 = heff_get_n(v_bi_240, 0, 3); V a_1 = v_t_2420; V a_2 = v_t_2424; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(a_0, a_1, a_2)); heff_drop(v_t_2420); heff_drop(v_t_2424); r_; });
  V f_ = v_c_2425;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_lam3, 1, 3, (V[]){v_done_245, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_path_2412 = heff_env(self)[0];
  V v_texts_243 = heff_env(self)[1];
  V v_bi_240 = heff_env(self)[2];
  V v_out_246 = heff_env(self)[3];
  V v_id_242 = heff_env(self)[4];
  V v_backs_244 = heff_env(self)[5];
  V v_done_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_2412, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_lam1_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s954557541x749476273(v_t_2418, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1345049552x43512251_lam2, 1, 8, (V[]){v_texts_243, v_bi_240, v_out_246, v_id_242, v_backs_244, v_hd_2413, v_done_245, v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str3, 62, "heff get: package.hf does not read: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str4, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str7, 11, "the project");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str8, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str9, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str14, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str15, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str19, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str20, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str21, 32, "heff get: cannot write heff.sum\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str22, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str23, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str24, 27, " packages, heff.sum written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str25, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str26, 1, "\012");
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam11, 2, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam0(V self, V *args);

static V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_st;
static V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_init(void) {
  V v_c_240 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam0, 2, 1, (V[]){v_c_240});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_st)) return g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_val, &g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_st, g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_init);
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam3(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s954557541x749476273(v_t_2426, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam7(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  return (g_co_2eop_24s954557541x749476273(v_t_2440, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam8(V self, V *args) {
  V v_by_2445 = args[0];
  V v_path_2446 = args[1];
  V v_v_2447 = args[2];
  V v_x_245 = heff_env(self)[0];
  V v_root_2427 = heff_env(self)[1];
  V v_sums_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020(v_x_245, v_root_2427, v_sums_2441, v_by_2445, v_path_2446, v_v_2447));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam11(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  heff_drop(v_hd_2461);
  V f_ = v_k_2462;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam12(V self, V *args) {
  V v_ok_2468 = args[0];
  return v_ok_2468;
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam15(V self, V *args) {
  V v_x_2488 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2488);
  V v_t_2489 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  return (g_co_2eop_24s954557541x749476273(v_t_2492, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam18(V self, V *args) {
  V v_x_24105 = args[0];
  V v_seen_24103 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24105; V a_1 = v_seen_24103; V r_ = (g_list_2efoldl_24s1002907040x997927369(a_0, a_1)); heff_drop(v_seen_24103); r_; });
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam17(V self, V *args) {
  V v_x_2495 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2449 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_intLt_c(MK_INT(0LL), v_x_2495)) {
    heff_drop(v_x_2449);
    V v_t_2497 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
    return (g_co_2eop_24s954557541x749476273(v_t_24100, v_hd_241, v_k_242));
  } else {
    V v_seen_24103;
    switch (heff_tag_of(v_x_2449)) {
    case TAG_MkPair: {
      V v_x_24101 = heff_field(v_x_2449, 0);
      heff_take_n(v_x_2449, 1ULL, 2);
      v_seen_24103 = v_x_24101;
      break;
    }
    default: heff_nomatch(v_x_2449);
    }
    V v_t_24104 = (g_list_2efoldl_24s489050722x1368997552(NTAG(TAG_Nil), heff_dup(v_seen_24103)));
    V v_t_24106 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam18, 1, 1, (V[]){v_seen_24103}); V a_3 = v_t_24104; V r_ = (g_list_2efoldl_24f556306710x2087456230(a_0, a_1, a_2, a_3)); heff_drop(v_t_24104); r_; });
    V v_t_24107 = heff_strAppend(heff_intShow(v_t_24106), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str24));
    V v_str_24108 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str25), v_t_24107);
    V v_t_24109 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_24108, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str26)), NTAG(TAG_MkUnit)});
    V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
    V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
    V v_t_24112 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
    return (g_co_2eop_24s954557541x749476273(v_t_24112, v_hd_241, v_k_242));
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam16(V self, V *args) {
  V v_x_2494 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2449 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str23), heff_get_n(v_x_2494, 1, 5), MK_INT(0LL), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam17, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2449})));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam14(V self, V *args) {
  V v_x_2477 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2473 = heff_env(self)[2];
  V v_x_2449 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_intLt_c(MK_INT(0LL), v_x_2477)) {
    heff_drop(v_x_2473);
    heff_drop(v_x_2449);
    V v_t_2479 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
    return (g_co_2eop_24s954557541x749476273(v_t_2482, v_hd_241, v_k_242));
  } else {
    V v_t_2483 = heff_bool(!(heff_dup(v_x_2473) == NTAG(TAG_True)));
    heff_drop(v_x_2473);
    if ((heff_dup(v_t_2483) == NTAG(TAG_True))) {
      heff_drop(v_x_2449);
      heff_drop(v_t_2483);
      V v_t_2484 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str21), NTAG(TAG_MkUnit)});
      V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
      V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
      V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
      return (g_co_2eop_24s954557541x749476273(v_t_2487, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam15, 1, 2, (V[]){v_hd_241, v_k_242})));
    } else {
      heff_drop(v_t_2483);
      V v_c_2493 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str22)));
      V f_ = v_c_2493;
      heff_room[0] = heff_dup(v_hd_241);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam16, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2449});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam13(V self, V *args) {
  V v_x_2473 = args[0];
  V v_x_2449 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2476;
  switch (heff_tag_of(v_x_2449)) {
  case TAG_MkPair: {
    V v_y_2475 = heff_dup(heff_field(v_x_2449, 1));
    v_t_2476 = v_y_2475;
    break;
  }
  default: heff_nomatch(v_x_2449);
  }
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str20), v_t_2476, MK_INT(0LL), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam14, 1, 4, (V[]){v_hd_241, v_k_242, v_x_2473, v_x_2449})));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam10(V self, V *args) {
  V v_x_2454 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_x_2449 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2455 = (g_list_2esortBy_24s492793466x2081132734(heff_dup(v_x_2454)));
  V v_x2_2456 = (g_list_2emap_24s2029274225x672412636(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str8), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str9), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str10), v_t_2455));
  V v_t_2459;
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_Nil: {
    v_t_2459 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str11);
    break;
  }
  case TAG_Cons: {
    V v_x_2457 = heff_field(v_x2_2456, 0);
    V v_xs_2458 = heff_field(v_x2_2456, 1);
    heff_take_n(v_x2_2456, 3ULL, 2);
    v_t_2459 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str12); V a_1 = v_x_2457; V a_2 = v_xs_2458; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2456);
  }
  V v_c_2472;
  if (heff_strEq_c(v_t_2459, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str13))) {
    heff_drop(v_x_2454);
    v_c_2472 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam11_clo);
  } else {
    V v_t_2463 = (g_list_2esortBy_24s492793466x2081132734(v_x_2454));
    V v_x2_2464 = (g_list_2emap_24s2029274225x672412636(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str14), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str15), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str16), v_t_2463));
    V v_str_2467;
    switch (heff_tag_of(v_x2_2464)) {
    case TAG_Nil: {
      v_str_2467 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str17);
      break;
    }
    case TAG_Cons: {
      V v_x_2465 = heff_field(v_x2_2464, 0);
      V v_xs_2466 = heff_field(v_x2_2464, 1);
      heff_take_n(v_x2_2464, 3ULL, 2);
      v_str_2467 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str18); V a_1 = v_x_2465; V a_2 = v_xs_2466; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2466); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2464);
    }
    V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str19), v_str_2467, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam12_clo)})});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    v_c_2472 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2471}));
  }
  V f_ = v_c_2472;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam13, 1, 3, (V[]){v_x_2449, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam9(V self, V *args) {
  V v_x_2449 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_root_2427 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2452;
  switch (heff_tag_of(v_x_2449)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_dup(heff_field(v_x_2449, 0));
    v_t_2452 = v_x_2450;
    break;
  }
  default: heff_nomatch(v_x_2449);
  }
  V v_c_2453 = (g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258(v_x_245, v_root_2427, v_t_2452));
  V f_ = v_c_2453;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam10, 1, 3, (V[]){v_hd_241, v_x_2449, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_root_2427 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    V v_why_2430 = heff_field(v_x_2429, 0);
    V v_ru_24x_2429_24Left = heff_take_reuse_n(v_x_2429, 1ULL, 1);
    heff_drop_rec(v_root_2427, 4);
    heff_drop(v_x_245);
    V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str4), v_why_2430), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str5));
    V v_t_2432 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2431, NTAG(TAG_MkUnit)});
    V v_t_2433 = heff_tag_at_n(v_ru_24x_2429_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    return (g_co_2eop_24s954557541x749476273(v_t_2435, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam7, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Right: {
    V v_sums_2441 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 1);
    V v_t_2443;
    if (heff_strEq_c(heff_dup(heff_rfield(v_root_2427, 0)), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str6))) {
      v_t_2443 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str7);
    } else {
      v_t_2443 = heff_dup(heff_rfield(v_root_2427, 0));
    }
    V v_t_2444 = (g_list_2emap_24s675147852x248982264(v_t_2443, heff_dup(heff_rfield(v_root_2427, 2))));
    V v_c_2448 = (g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam8, 3, 3, (V[]){heff_dup(v_x_245), heff_dup(v_root_2427), v_sums_2441}), heff_dup(heff_rfield(v_root_2427, 0)), v_t_2444, NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V f_ = v_c_2448;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam9, 1, 4, (V[]){v_x_245, v_root_2427, v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    v_t_2412 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_x1_2413 = (g_heff_2ebuild_2eproject_2epackageLit(v_t_2412));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Left: {
    V v_p_2414 = heff_field(v_x1_2413, 0);
    V v_ru_24x1_2413_24Left = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
    v_t_2416 = heff_tag_at_n(v_ru_24x1_2413_24Left, TAG_Left, 1, (V[]){v_p_2414});
    break;
  }
  case TAG_Right: {
    V v_x_2415 = heff_field(v_x1_2413, 0);
    heff_take_n(v_x1_2413, 1ULL, 1);
    v_t_2416 = ({ V a_0 = v_x_2415; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2415); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2413);
  }
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Left: {
    V v_ru_24t_2416_24Left = heff_take_reuse_n(v_t_2416, 0ULL, 1);
    heff_drop(v_x_245);
    V v_t_2418 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str3), NTAG(TAG_MkUnit)});
    V v_t_2419 = heff_tag_at_n(v_ru_24t_2416_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    return (g_co_2eop_24s954557541x749476273(v_t_2421, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam5, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Right: {
    V v_root_2427 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    V v_c_2428 = (g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(heff_dup(v_x_245)));
    V f_ = v_c_2428;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam6, 1, 4, (V[]){v_hd_241, v_k_242, v_root_2427, v_x_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str1), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam3_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam4, 1, 3, (V[]){v_hd_241, v_k_242, v_x_245})));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244 = (g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(v_x_243, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str0)));
  V f_ = v_c_244;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam2, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_240;
  args[0] = heff_dup(v_hd_241);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam1, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str0, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str2, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str3, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str5, 27, "` is required already: add ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str6, 30, " to package.hf by another name");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str7, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str8, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str10, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str11, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str12, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str13, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str14, 30, "heff get: package.hf requires ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str16, 34, "heff get: cannot write package.hf\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str17, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str18, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str19, 1, "\012");
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam14(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246(V v_ps_240, V v_text_241, V v_pk_242, V v_path_243, V v_v_244) {
top: ;
  V v_t_245 = (g_heff_2ebuild_2eproject_2emajorMismatch(heff_dup(v_path_243), heff_dup(v_v_244)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_c_246 = (g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam0, 2, 6, (V[]){v_c_246, v_ps_240, v_path_243, v_v_244, v_pk_242, v_text_241});
  }
  case TAG_Just: {
    V v_why_2486 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_text_241);
    heff_drop_rec(v_pk_242, 4);
    heff_drop(v_v_244);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam14, 2, 2, (V[]){v_path_243, v_why_2486});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2421);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(v_t_2420, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam3, 1, 1, (V[]){v_k_248})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2437);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2432);
  V v_t_2433 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s954557541x749476273(v_t_2436, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam6, 1, 1, (V[]){v_k_248})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam8(V self, V *args) {
  V v_x_2453 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2453);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam7(V self, V *args) {
  V v_x_2448 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2448);
  V v_t_2449 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  return (g_co_2eop_24s954557541x749476273(v_t_2452, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam8, 1, 1, (V[]){v_k_248})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam9(V self, V *args) {
  V v_ok_2464 = args[0];
  return v_ok_2464;
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam11(V self, V *args) {
  V v_x_2475 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2475);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam13(V self, V *args) {
  V v_x_2485 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2485);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam12(V self, V *args) {
  V v_x_2480 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2480);
  V v_t_2481 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  return (g_co_2eop_24s954557541x749476273(v_t_2484, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam13, 1, 1, (V[]){v_k_248})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam10(V self, V *args) {
  V v_x_2468 = args[0];
  V v_path_243 = heff_env(self)[0];
  V v_v_244 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2468) == NTAG(TAG_True))) {
    heff_drop(v_x_2468);
    V v_t_2469 = heff_strAppend(v_path_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str13), v_v_244));
    V v_t_2470 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str14), v_t_2469), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str15));
    V v_t_2471 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2470, NTAG(TAG_MkUnit)});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    return (g_co_2eop_24s954557541x749476273(v_t_2474, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam11, 1, 1, (V[]){v_k_248})));
  } else {
    heff_drop(v_x_2468);
    heff_drop(v_path_243);
    heff_drop(v_v_244);
    V v_t_2476 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str16), NTAG(TAG_MkUnit)});
    V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    return (g_co_2eop_24s954557541x749476273(v_t_2479, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam12, 1, 2, (V[]){v_hd_247, v_k_248})));
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  V v_pk_242 = heff_env(self)[3];
  V v_v_244 = heff_env(self)[4];
  V v_text_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    V v_why_2426 = heff_field(v_x_2425, 0);
    V v_ru_24x_2425_24Left = heff_take_reuse_n(v_x_2425, 1ULL, 1);
    heff_drop(v_path_243);
    heff_drop_rec(v_pk_242, 4);
    heff_drop(v_v_244);
    heff_drop(v_text_241);
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str3), v_why_2426), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str4));
    V v_t_2428 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2427, NTAG(TAG_MkUnit)});
    V v_t_2429 = heff_tag_at_n(v_ru_24x_2425_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s954557541x749476273(v_t_2431, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam5, 1, 2, (V[]){v_hd_247, v_k_248})));
  }
  case TAG_Right: {
    V v_name_2438 = heff_field(v_x_2425, 0);
    V v_ru_24x_2425_24Right = heff_take_reuse_n(v_x_2425, 1ULL, 1);
    V v_x1_2439 = (g_list_2eany_24s1875112453x1656618700(heff_dup(v_path_243), heff_rfield(v_pk_242, 2)));
    V v_t_2440;
    if ((heff_dup(v_x1_2439) == NTAG(TAG_True))) {
      heff_drop(v_x1_2439);
      v_t_2440 = NTAG(TAG_False);
    } else {
      heff_drop(v_x1_2439);
      v_t_2440 = (g_list_2eany_24s332527547x6651279(heff_dup(v_name_2438), heff_rfield(v_pk_242, 2)));
    }
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop_rec(v_pk_242, 4);
      heff_drop(v_v_244);
      heff_drop(v_text_241);
      heff_drop(v_t_2440);
      V v_t_2441 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str5), heff_strAppend(v_path_243, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str6)));
      V v_t_2442 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str7), heff_strAppend(v_name_2438, v_t_2441));
      V v_t_2443 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str8), v_t_2442), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str9));
      V v_t_2444 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2443, NTAG(TAG_MkUnit)});
      V v_t_2445 = heff_tag_at_n(v_ru_24x_2425_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
      V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
      V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
      return (g_co_2eop_24s954557541x749476273(v_t_2447, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam7, 1, 2, (V[]){v_hd_247, v_k_248})));
    } else {
      heff_drop(v_t_2440);
      V v_t_2454 = (g_list_2eany_24s1875112453x1656618700(heff_dup(v_path_243), heff_rfield(v_pk_242, 2)));
      V v_t_2456;
      if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
        heff_drop(v_name_2438);
        heff_drop(v_t_2454);
        v_t_2456 = (g_list_2emap_24s1814289659x520383890(heff_dup(v_path_243), heff_dup(v_v_244), heff_dup(heff_rfield(v_pk_242, 2))));
      } else {
        heff_drop(v_t_2454);
        V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__path__version, (V[]){v_name_2438, heff_dup(v_path_243), heff_dup(v_v_244)}), NTAG(TAG_Nil)});
        v_t_2456 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_pk_242, 2)), v_t_2455));
      }
      V v_t_2457 = ({ V rv_2 = v_t_2456; V rr_ = heff_rec_reuse_nf(v_pk_242, 11ULL, 4, shape_module__heff__require__replace, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_text_2458 = (g_heff_2ebuild_2eproject_2ewithPackage(v_text_241, v_t_2457));
      V v_str_2463;
      if (heff_strEq_c(heff_strSlice(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str10), MK_INT(7LL), MK_INT(10LL)), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str11))) {
        V v_t_2460 = (g_heff_2esyntax_2eformat_2eformat(heff_dup(v_text_2458)));
        switch (heff_tag_of(v_t_2460)) {
        case TAG_Left: {
          heff_take_n(v_t_2460, 0ULL, 1);
          v_str_2463 = v_text_2458;
          break;
        }
        case TAG_Right: {
          V v_out_2462 = heff_field(v_t_2460, 0);
          heff_take_n(v_t_2460, 1ULL, 1);
          heff_drop(v_text_2458);
          v_str_2463 = v_out_2462;
          break;
        }
        default: heff_nomatch(v_t_2460);
        }
      } else {
        v_str_2463 = v_text_2458;
      }
      V v_t_2465 = heff_tag_at_n(v_ru_24x_2425_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str12), v_str_2463, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam9_clo)})});
      V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
      V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
      return (g_co_2eop_24s954557541x749476273(v_t_2467, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam10, 1, 4, (V[]){v_path_243, v_v_244, v_hd_247, v_k_248})));
    }
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_path_243 = heff_env(self)[3];
  V v_v_244 = heff_env(self)[4];
  V v_pk_242 = heff_env(self)[5];
  V v_text_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    V v_why_2410 = heff_field(v_x_249, 0);
    V v_ru_24x_249_24Left = heff_take_reuse_n(v_x_249, 1ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_path_243);
    heff_drop(v_v_244);
    heff_drop_rec(v_pk_242, 4);
    heff_drop(v_text_241);
    V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str0), v_why_2410), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str1));
    V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_at_n(v_ru_24x_249_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s954557541x749476273(v_t_2415, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam2, 1, 2, (V[]){v_hd_247, v_k_248})));
  }
  case TAG_Right: {
    heff_take_n(v_x_249, 0ULL, 1);
    V v_t_2423 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
    V v_t_2424 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str2)));
    return (g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(v_ps_240, v_t_2424, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam4, 1, 6, (V[]){v_hd_247, v_k_248, v_path_243, v_pk_242, v_v_244, v_text_241})));
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  V v_v_244 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  V v_text_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam1, 1, 7, (V[]){v_hd_247, v_k_248, v_ps_240, v_path_243, v_v_244, v_pk_242, v_text_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam16(V self, V *args) {
  V v_x_24100 = args[0];
  V v_k_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24100);
  V f_ = v_k_2488;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam15(V self, V *args) {
  V v_x_2495 = args[0];
  V v_hd_2487 = heff_env(self)[0];
  V v_k_2488 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2495);
  V v_t_2496 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  return (g_co_2eop_24s954557541x749476273(v_t_2499, v_hd_2487, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam16, 1, 1, (V[]){v_k_2488})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam14(V self, V *args) {
  V v_hd_2487 = args[0];
  V v_k_2488 = args[1];
  V v_path_243 = heff_env(self)[0];
  V v_why_2486 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2489 = heff_strAppend(v_path_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str17), v_why_2486));
  V v_t_2490 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str18), v_t_2489), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str19));
  V v_t_2491 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2490, NTAG(TAG_MkUnit)});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  return (g_co_2eop_24s954557541x749476273(v_t_2494, heff_dup(v_hd_2487), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam15, 1, 2, (V[]){v_hd_2487, v_k_2488})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_str2, 5, "win32");
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam1, 2, 3, (V[]){v_p_245, v_rest_246, v_acc_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam2(V self, V *args) {
  V v_ns_249 = args[0];
  return v_ns_249;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam4(V self, V *args) {
  V v_s_2420 = args[0];
  return v_s_2420;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam6(V self, V *args) {
  V v_n_2426 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428;
  if (heff_strEq_c(v_x_2424, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_str2))) {
    v_t_2428 = NTAG(TAG_Windows);
  } else {
    v_t_2428 = NTAG(TAG_Posix);
  }
  return ({ V a_0 = v_t_2428; V a_1 = v_p_245; V a_2 = v_n_2426; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2428); r_; });
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_ns_2419 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2425 = (g_list_2efilter_24s2101000672x961294372(MK_INT(0LL), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_str1), v_ns_2419));
  V v_t_2429 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_246, heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam6, 1, 2, (V[]){v_x_2424, v_p_245}), v_t_2425));
  V v_t_2430 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(v_t_2429, v_acc_241));
  V f_ = v_t_2430;
  heff_room[0] = v_hd_247;
  heff_room[1] = v_k_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    V v_t_2414 = heff_intSub(heff_strLength_lent(v_p_245, 0), MK_INT(3LL));
    V v_t_2415 = heff_strSlice(heff_dup(v_p_245), v_t_2414, heff_strLength_lent(v_p_245, 0));
    if (heff_strEq_c(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_str0))) {
      V v_t_2417 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(v_rest_246, heff_tag_n(TAG_Cons, 2, (V[]){v_p_245, v_acc_241})));
      V f_ = v_t_2417;
      heff_room[0] = v_hd_247;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_245);
      V v_t_2418 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(v_rest_246, v_acc_241));
      V f_ = v_t_2418;
      heff_room[0] = v_hd_247;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Just: {
    V v_ns_2419 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Just = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    V v_t_2421 = heff_tag_at_n(v_ru_24x_2413_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam4_clo)})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam5, 1, 6, (V[]){v_ns_2419, v_rest_246, v_p_245, v_acc_241, v_hd_247, v_k_248})));
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(v_p_245), ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam2_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s954557541x749476273(v_t_2412, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam3, 1, 5, (V[]){v_p_245, v_rest_246, v_acc_241, v_hd_247, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655(V v_st_240, V v_t_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_t_241, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam0_clo);
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 0)), heff_dup(v_n_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam1, 2, 5, (V[]){v_t_247, heff_dup(v_st_240), v_t_241, v_rest_246, v_n_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_n_245 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413;
  if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_2410);
    heff_drop(v_n_245);
    v_t_2413 = v_x_2412;
  } else {
    heff_drop(v_x_2410);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_245, v_x_2412});
  }
  V f_ = v_k_249;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2411 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam3, 1, 3, (V[]){v_x_2410, v_n_245, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_t_247 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914(v_t_247, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam2, 1, 6, (V[]){v_st_240, v_t_241, v_rest_246, v_hd_248, v_n_245, v_k_249})));
}
Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114(V v_st_240, V v_t_241, V v_bp_242, V v_done_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_bp_242);
    return v_done_243;
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_bp_242), v_done_243, v_rest_246));
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_clo), 6, (V[]){v_st_240, v_t_241, v_bp_242, heff_dup(heff_rfield(v_a_245, 0)), heff_dup(heff_rfield(v_a_245, 1)), v_t_247});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str2, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str3, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str4, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963(V v_t_240, V v_fresh_241, V v_old_242, V v_to_243, V v_next_244, V v_x6_245, V v_p_246, V v_p_247) {
top: ;
  if ((heff_dup(v_x6_245) == NTAG(TAG_True))) {
    heff_drop(v_fresh_241);
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_old_242, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam0_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam1, 1, 5, (V[]){v_t_240, v_to_243, v_p_246, v_next_244, v_p_247})));
  } else {
    heff_drop_rec(v_t_240, 6);
    heff_drop(v_next_244);
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Move, 3, (V[]){v_old_242, heff_dup(v_to_243), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam3_clo)})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    return (g_co_2eop_24s954557541x749476273(v_t_2422, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam4, 1, 4, (V[]){v_fresh_241, v_p_246, v_to_243, v_p_247})));
  }
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7]); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam0(V self, V *args) {
  V v_ok_248 = args[0];
  return v_ok_248;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2418);
  V f_ = v_next_244;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_next_244 = heff_env(self)[3];
  V v_p_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2412);
  V v_t_2413 = heff_strAppend(heff_get_n(v_t_240, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str0), v_to_243));
  V v_t_2414 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str1)), NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s954557541x749476273(v_t_2417, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam2, 1, 3, (V[]){v_next_244, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam3(V self, V *args) {
  V v_ok_2419 = args[0];
  return v_ok_2419;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam5(V self, V *args) {
  V v_ok_2424 = args[0];
  return v_ok_2424;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam7(V self, V *args) {
  V v_x_2435 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_p_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s954557541x749476273(v_t_2439, v_p_246, v_p_247));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_strAppend(v_fresh_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str2), v_to_243));
  V v_t_2430 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str3), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str4), v_t_2429));
  V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2430, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str5)), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  return (g_co_2eop_24s954557541x749476273(v_t_2434, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam7, 1, 2, (V[]){v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_to_243 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2423);
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_fresh_241), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam5_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s954557541x749476273(v_t_2427, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam6, 1, 4, (V[]){v_fresh_241, v_to_243, v_p_246, v_p_247})));
}
Clo g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(V v_st_240, V v_t_241, V v_home_242, V v_sh_243, V v_next_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_home_242);
    heff_drop(v_sh_243);
    return v_next_244;
  }
  case TAG_Cons: {
    V v_n_246 = heff_field(v_x6_245, 0);
    V v_rest_247 = heff_field(v_x6_245, 1);
    V v_t_248 = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_home_242), heff_dup(v_sh_243), v_next_244, v_rest_247));
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_clo), 6, (V[]){v_st_240, v_t_241, v_home_242, v_sh_243, v_t_248, heff_dup(v_n_246)});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str0, 4, "PATH");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str3, 1, ";");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str7, 14, "heff install: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str8, 60, " is not on the PATH: add it there to run them by their names");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544(V v_st_240, V v_bin_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_247}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam1, 1, 4, (V[]){v_hd_242, heff_dup(v_st_240), v_bin_241, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam2(V self, V *args) {
  V v_v_249 = args[0];
  return v_v_249;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam4(V self, V *args) {
  V v_d_2421 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bin_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = (g_std_2epath_2ejoin(v_st_240, v_d_2421, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str5)));
  V v_t_2423 = ({ V a_0 = v_st_240; V a_1 = v_bin_241; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str6); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  return heff_strEq(v_t_2422, v_t_2423);
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_2415;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    v_path_2415 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    v_path_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_sep_2417;
  if (heff_strEq_c(v_x_248, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str2))) {
    v_sep_2417 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str3);
  } else {
    v_sep_2417 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str4);
  }
  V v_t_2420;
  if (heff_intEq_c(heff_strLength_lent(v_sep_2417, 0), MK_INT(0LL))) {
    heff_drop(v_sep_2417);
    v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_path_2415, NTAG(TAG_Nil)});
  } else {
    V v_t_2419 = (g_prelude_2estrFind(heff_dup(v_sep_2417), heff_dup(v_path_2415), MK_INT(0LL)));
    v_t_2420 = (g_prelude_2esplitFrom(v_sep_2417, v_path_2415, MK_INT(0LL), v_t_2419, NTAG(TAG_Nil)));
  }
  V v_t_2424 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam4, 1, 2, (V[]){v_st_240, heff_dup(v_bin_241)}); V a_1 = v_t_2420; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2420); r_; });
  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
    heff_drop(v_bin_241);
    heff_drop(v_hd_242);
    heff_drop(v_t_2424);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_2424);
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str7), heff_strAppend(v_bin_241, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str8)));
    V v_t_2426 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str9)), NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s954557541x749476273(v_t_2429, v_hd_242, v_k_243));
  }
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str0), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam2_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam3, 1, 5, (V[]){v_x_248, v_st_240, v_bin_241, v_k_243, v_hd_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str0, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str2, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str5, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str6, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str7, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599(V v_st_240, V v_t_241, V v_home_242, V v_dir_243, V v_next_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WorkingDir, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam1, 1, 7, (V[]){heff_dup(v_st_240), v_home_242, v_dir_243, v_hd_245, v_t_241, v_next_244, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam2(V self, V *args) {
  V v_ok_2416 = args[0];
  return v_ok_2416;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2427);
  V f_ = v_next_244;
  heff_room[0] = v_hd_245;
  heff_room[1] = v_k_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s954557541x749476273(v_t_2439, v_hd_245, v_k_246));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_next_244 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2420) == NTAG(TAG_True))) {
    heff_drop(v_x_2420);
    V v_path_2421 = ({ V a_0 = v_st_240; V a_1 = v_home_242; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str2); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
    V v_t_2422 = heff_strAppend(heff_get_n(v_t_241, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str3), v_path_2421));
    V v_t_2423 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str4)), NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    return (g_co_2eop_24s954557541x749476273(v_t_2426, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam4, 1, 3, (V[]){v_next_244, v_hd_245, v_k_246})));
  } else {
    heff_drop(v_x_2420);
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_next_244);
    V v_t_2428 = ({ V a_0 = v_st_240; V a_1 = v_home_242; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str5); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
    V v_why_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str6), v_t_2428);
    V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str7), v_why_2429), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str8));
    V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2430, NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s954557541x749476273(v_t_2434, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam5, 1, 2, (V[]){v_hd_245, v_k_246})));
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_dir_243 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_path_2412 = (g_std_2epath_2ejoin(v_st_240, heff_dup(v_home_242), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str0)));
  V v_t_2413 = (g_std_2epath_2ejoin(v_st_240, v_x_2411, v_dir_243));
  V v_t_2414 = (g_std_2epath_2enormalize(v_st_240, v_t_2413));
  V v_str_2415 = heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str1));
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_2412, v_str_2415, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam2_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s954557541x749476273(v_t_2419, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam3, 1, 6, (V[]){v_st_240, v_home_242, v_t_241, v_hd_245, v_next_244, v_k_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str1, 22, "` is no version: a.b.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str2, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str4, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str5, 64, "heff publish: no package.hf here: publish at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str6, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str7, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str8, 39, "heff publish: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str9, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str10, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115(V v_v_240) {
top: ;
  V v_t_241 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(v_v_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    return heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam0, 2, 1, (V[]){v_v_240});
  }
  case TAG_Just: {
    heff_take_n(v_t_241, 0ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam2, 2, 1, (V[]){v_v_240});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115(a[0]);
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2410);
  V v_t_2411 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s954557541x749476273(v_t_2414, v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str0), heff_strAppend(v_v_240, ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str1)));
  V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str2), v_t_244), ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str3));
  V v_t_246 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_245, NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam1, 1, 2, (V[]){v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam3(V self, V *args) {
  V v_t_2418 = args[0];
  return v_t_2418;
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s954557541x749476273(v_t_2431, v_hd_2416, v_k_2417));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam10(V self, V *args) {
  V v_x_2445 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2445);
  V v_t_2446 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  return (g_co_2eop_24s954557541x749476273(v_t_2449, v_hd_2416, v_k_2417));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam11(V self, V *args) {
  V v_x_2456 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2456);
  V v_t_2457 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  return (g_co_2eop_24s954557541x749476273(v_t_2460, v_hd_2416, v_k_2417));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam12(V self, V *args) {
  V v_x_2466 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2466);
  V v_t_2467 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  return (g_co_2eop_24s954557541x749476273(v_t_2470, v_hd_2416, v_k_2417));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam9(V self, V *args) {
  V v_x_2439 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_hd_2416 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_cs_2438 = heff_env(self)[4];
  V v_v_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2439);
  V v_t_2440 = heff_dup(heff_rfield(v_x_2434, 3));
  switch (heff_tag_of(v_t_2440)) {
  case TAG_Nothing: {
    heff_drop_rec(v_x_2434, 5);
    heff_drop(v_x_2435);
    heff_drop(v_cs_2438);
    heff_drop(v_v_240);
    V v_t_2441 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str8), NTAG(TAG_MkUnit)});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    return (g_co_2eop_24s954557541x749476273(v_t_2444, heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam10, 1, 2, (V[]){v_hd_2416, v_k_2417})));
  }
  case TAG_Just: {
    V v_pk_2450 = heff_field(v_t_2440, 0);
    V v_ru_24t_2440_24Just = heff_take_reuse_n(v_t_2440, 1ULL, 1);
    if (heff_intLt_c(MK_INT(0LL), v_x_2435)) {
      heff_drop_rec(v_x_2434, 5);
      heff_drop(v_cs_2438);
      heff_drop(v_v_240);
      heff_drop(v_pk_2450);
      V v_t_2452 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str9), NTAG(TAG_MkUnit)});
      V v_t_2453 = heff_tag_at_n(v_ru_24t_2440_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
      V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
      V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
      return (g_co_2eop_24s954557541x749476273(v_t_2455, heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam11, 1, 2, (V[]){v_hd_2416, v_k_2417})));
    } else {
      V v_t_2461 = ({ V a_0 = v_cs_2438; V r_ = (g_list_2eany_24s1996724342x1838336560(a_0)); heff_drop(v_cs_2438); r_; });
      if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_2434, 5);
        heff_drop(v_v_240);
        heff_drop(v_pk_2450);
        heff_drop(v_t_2461);
        V v_t_2462 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str10), NTAG(TAG_MkUnit)});
        V v_t_2463 = heff_tag_at_n(v_ru_24t_2440_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
        V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
        V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
        return (g_co_2eop_24s954557541x749476273(v_t_2465, heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam12, 1, 2, (V[]){v_hd_2416, v_k_2417})));
      } else {
        heff_drop_cell(v_ru_24t_2440_24Just, 1);
        heff_drop(v_t_2461);
        return (g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085(v_v_240, v_x_2434, v_pk_2450, v_hd_2416, v_k_2417));
      }
    }
  }
  default: return heff_nomatch(v_t_2440);
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam8(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  V v_x_2434 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_v_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_cs_2438 = heff_get_n(v_x_2437, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_2438), heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam9, 1, 6, (V[]){v_x_2434, v_hd_2416, v_k_2417, v_x_2435, v_cs_2438, v_v_240})));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam7(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_hd_2416 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2436 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(heff_dup(v_x_2434)));
  V f_ = v_c_2436;
  heff_room[0] = heff_dup(v_hd_2416);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam8, 1, 5, (V[]){v_hd_2416, v_x_2434, v_k_2417, v_x_2435, v_v_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str7), heff_dup(heff_rfield(v_x_2434, 1)), MK_INT(0LL), heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam7, 1, 4, (V[]){v_x_2434, v_hd_2416, v_k_2417, v_v_240})));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    heff_drop(v_v_240);
    V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str5), NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    return (g_co_2eop_24s954557541x749476273(v_t_2426, heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam5, 1, 2, (V[]){v_hd_2416, v_k_2417})));
  }
  case TAG_Just: {
    heff_take_n(v_x_2422, 0ULL, 1);
    V v_c_2433 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str6)));
    V f_ = v_c_2433;
    heff_room[0] = heff_dup(v_hd_2416);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam6, 1, 3, (V[]){v_hd_2416, v_k_2417, v_v_240});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str4), ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam3_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s954557541x749476273(v_t_2421, heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam4, 1, 3, (V[]){v_hd_2416, v_k_2417, v_v_240})));
}