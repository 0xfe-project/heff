// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_apps 9496377
#define LBL_at 9882
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_c 317
#define LBL_cmt 308164
#define LBL_copies 592412158
#define LBL_cwd 308458
#define LBL_defs 9574869
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_emits 297985818
#define LBL_ems 310085
#define LBL_end 310101
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_facts 298546081
#define LBL_first 298798794
#define LBL_fresh 299054408
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_hashes 722717031
#define LBL_i 323
#define LBL_implicit 319715269
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_lowered 588863906
#define LBL_malg 9839318
#define LBL_mod 317820
#define LBL_mods 9852536
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_named 305943379
#define LBL_olds 9909235
#define LBL_output 941629484
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_prefix 967031229
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_s 333
#define LBL_ships 310766033
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_top 324559
#define LBL_units 312791945
#define LBL_watches 1357821955
#define LBL_zig 330130
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_ems__s__fresh[] = {LBL_ems, LBL_s, LBL_fresh};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_lowered__groups__copies[] = {LBL_lowered, LBL_groups, LBL_copies};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
static uint32_t shape_module__named__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_named, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_parts__errors__groups__copies__emits[] = {LBL_parts, LBL_errors, LBL_groups, LBL_copies, LBL_emits};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
static uint32_t shape_units__copies[] = {LBL_units, LBL_copies};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1531911654x724325922(V, V, V);
V g_co_2eop_24s1531911654x724325922_entry(V self, V *a);
extern Clo g_co_2eop_24s1531911654x724325922_clo;
V g_co_2eop_24s1772383553x418719539(V, V, V);
V g_co_2eop_24s1772383553x418719539_entry(V self, V *a);
extern Clo g_co_2eop_24s1772383553x418719539_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s321980040x1154251472(V, V, V, V, V);
V g_co_2eop_24s321980040x1154251472_entry(V self, V *a);
extern Clo g_co_2eop_24s321980040x1154251472_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_co_2eop_24s907744994x1234676051(V, V);
V g_co_2eop_24s907744994x1234676051_entry(V self, V *a);
extern Clo g_co_2eop_24s907744994x1234676051_clo;
V g_co_2eop_24s91617614x2132230022(V, V, V, V);
V g_co_2eop_24s91617614x2132230022_entry(V self, V *a);
extern Clo g_co_2eop_24s91617614x2132230022_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ecache_2ehashGo(V, V, V, V);
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ehashGo_clo;
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_clo;
V g_heff_2ebuild_2ecommands_2efirstErrorOf(V);
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo;
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823(V);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_clo;
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_clo;
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376(V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272(V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138(V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2eproject_2ebuildOf(V);
V g_heff_2ebuild_2eproject_2ebuildOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ebuildOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2edeclsGo_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ecompile_2eemitc_2eceOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eceOf_clo;
V g_heff_2ecompile_2eemitc_2eemitAt(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eemitAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eemitAt_clo;
V g_heff_2ecompile_2eemitc_2eemitVer(V, V, V);
V g_heff_2ecompile_2eemitc_2eemitVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eemitVer_clo;
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void);
V g_heff_2ecompile_2eemitc_2epartsWith(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsWith_clo;
V g_heff_2ecompile_2eemitc_2erunEnd(V, V);
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erunEnd_clo;
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2elower_2efusedOf(V, V);
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedOf_clo;
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337(V, V, V);
V g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337_clo;
HeffT4 g_heff_2ecompile_2elower_2elowerProgramKept_24cpr(V, V, V, V);
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2eany_24s762674996x1009180162(V);
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a);
extern Clo g_list_2eany_24s762674996x1009180162_clo;
V g_list_2eascending_24s927649470x204705998(V, V, V);
V g_list_2eascending_24s927649470x204705998_entry(V self, V *a);
extern Clo g_list_2eascending_24s927649470x204705998_clo;
V g_list_2edescending_24s630739678x585974040(V, V, V);
V g_list_2edescending_24s630739678x585974040_entry(V self, V *a);
extern Clo g_list_2edescending_24s630739678x585974040_clo;
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f409057300x985797598(V, V);
V g_list_2efoldl_24f409057300x985797598_entry(V self, V *a);
extern Clo g_list_2efoldl_24f409057300x985797598_clo;
V g_list_2efoldl_24s1149369025x804005338(V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1149369025x804005338_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1149369025x804005338_clo;
V g_list_2efoldl_24s1272156913x1766532544(V, V);
V g_list_2efoldl_24s1272156913x1766532544_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1272156913x1766532544_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1707192740x1747748619(V, V);
V g_list_2efoldl_24s1707192740x1747748619_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1707192740x1747748619_clo;
V g_list_2efoldl_24s552376067x1255995125(V, V);
V g_list_2efoldl_24s552376067x1255995125_entry(V self, V *a);
extern Clo g_list_2efoldl_24s552376067x1255995125_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s744304057x1932700078(V, V);
V g_list_2efoldl_24s744304057x1932700078_entry(V self, V *a);
extern Clo g_list_2efoldl_24s744304057x1932700078_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24f428638463x2144521938(V, V, V, V);
V g_list_2ekeepIf_24f428638463x2144521938_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f428638463x2144521938_clo;
V g_list_2ekeepIf_24s1228038992x175493858(V, V, V, V, V, V);
V g_list_2ekeepIf_24s1228038992x175493858_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1228038992x175493858_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1524014098x1956473147(V, V, V, V);
V g_list_2emap_24f1524014098x1956473147_entry(V self, V *a);
extern Clo g_list_2emap_24f1524014098x1956473147_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s1532989807x150355682(V, V);
V g_list_2emergeRuns_24s1532989807x150355682_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s1532989807x150355682_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);

HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_module_244 = heff_dup(heff_rfield(v_s_242, 0));
    V v_path_245 = heff_dup(heff_rfield(v_s_242, 2));
    if (heff_strEq_c_lent(v_module_244, v_m_241, 1)) {
      V v_f_246 = v_path_245;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      heff_drop(v_path_245);
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str8, 1, "$");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_module_244 = heff_dup(heff_rfield(v_p_242, 0));
    V v_text_245 = heff_dup(heff_rfield(v_p_242, 1));
    V v_t_246 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_247 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_246));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    if (heff_strEq_c(v_module_244, v_t_2410)) {
      V v_t_2411 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2412 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2411); r_; });
      V v_text_2413 = v_text_245;
      V v_t_2414 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str6); V a_1 = v_text_2413; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str7), v_text_2413, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_2413); r_; });
      V v_t_2415 = (g_list_2emap_24s732475005x1616712052(v_t_2414));
      V v_t_2416 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str8); V a_3 = v_t_2415; V r_ = (g_list_2ekeepIf_24f428638463x2144521938(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
      V v_t_2417 = ({ V a_0 = v_t_2412; V a_1 = v_t_2416; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2412); heff_drop(v_t_2416); r_; });
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop(v_k_241);
        heff_drop(v_t_2417);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2417);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      heff_drop(v_text_245);
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeaf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_str1, 10, "package.hf");
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return v_s_242;
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_st_2412 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2414 = (g_heff_2ebuild_2ecommands_2eownRoot(heff_dup(v_st_2412), v_x_2413));
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_2412), v_a_2414));
  V v_t_2416 = (g_std_2epath_2eparse(heff_dup(v_st_2412), ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_str1)));
  V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
  V v_x_2418 = ({ V a_0 = v_st_2412; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2412); heff_drop(v_t_2417); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_st_2412;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_str0))) {
    v_st_2412 = NTAG(TAG_Windows);
  } else {
    v_st_2412 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_lam2, 1, 2, (V[]){v_st_2412, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_str0, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819(V v_ps_240, V v_b_241, V v_id_242, V v_z_243, V v_z_244) {
top: ;
  V v_s_245 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
  V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_245));
  V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_246); r_; });
  V v_a_249 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam0_clo)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  V v_c_2422 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam1_clo)));
  return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam3, 1, 5, (V[]){v_ps_240, v_id_242, v_b_241, v_z_243, v_z_244})});
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam0(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_err_2417 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    V v_t_2418 = heff_tag_at_n(v_ru_24x_2416_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2417})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2418));
  }
  case TAG_Right: {
    V v_x_2419 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam2, 2, 1, (V[]){v_x_2419});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2432);
  V f_ = v_z_244;
  args[0] = v_id_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_b_241 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2423);
  V v_d_2424 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
  V v_st_2425 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2426 = (g_std_2epath_2eparse(heff_dup(v_st_2425), v_d_2424));
  V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_2425), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_str0)));
  V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
  V v_t_2429 = ({ V a_0 = v_st_2425; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2425); heff_drop(v_t_2428); r_; });
  V v_t_2430 = heff_strAppend(heff_strAppend(heff_dup(v_id_242), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_str1)), v_b_241);
  V v_c_2431 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138(v_t_2429, v_t_2430));
  V f_ = v_c_2431;
  heff_room[0] = v_z_243;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_lam4, 1, 2, (V[]){v_z_244, v_id_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_str0, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917(V v_ps_240, V v_b_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_245 = (g_heff_2ebuild_2ecache_2ehashGo(v_b_241, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    HEFF_LAST return g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819(v_ps_240, v_b_241, v_t_245, v_z_243, v_z_244);
  }
  case TAG_Just: {
    V v_kept_246 = heff_field(v_x3_242, 0);
    V v_j_247 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_str0), v_kept_246, MK_INT(0LL), 5);
    if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
      heff_drop(v_j_247);
      V v_t_248 = (g_heff_2ebuild_2ecache_2ehashGo(v_b_241, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
      HEFF_LAST return g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819(v_ps_240, v_b_241, v_t_248, v_z_243, v_z_244);
    } else {
      V v_t_249 = heff_intSub(heff_strLength_lent(v_kept_246, 0), heff_dup(v_j_247));
      if ((heff_intEq_c(heff_intSub(heff_dup(v_t_249), MK_INT(1LL)), heff_strLength_lent(v_b_241, 0)) && heff_strEq_c(heff_strSlice(heff_dup(v_kept_246), heff_intAdd(heff_dup(v_j_247), MK_INT(1LL)), heff_strLength_lent(v_kept_246, 0)), heff_dup(v_b_241)))) {
        heff_drop(v_ps_240);
        heff_drop(v_b_241);
        heff_drop(v_z_243);
        heff_drop(v_t_249);
        return heff_tail(v_z_244, 1, (V[]){heff_strSlice_lent(v_kept_246, MK_INT(0LL), v_j_247, 6)});
      } else {
        heff_drop(v_j_247);
        heff_drop(v_t_249);
        V v_t_2410 = (g_heff_2ebuild_2ecache_2ehashGo(v_b_241, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
        HEFF_LAST return g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819(v_ps_240, v_b_241, v_t_2410, v_z_243, v_z_244);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_str0), v_e_243), ((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_str1));
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_WriteErr, 2, (V[]){v_t_245, NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    return (g_co_2eop_24s321980040x1154251472(v_rest_244, heff_dup(v_p_241), v_p_242, heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_str1, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839(V v_ps_240, V v_olds_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam0_clo);
  }
  case TAG_Cons: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_m_247 = heff_field(v_x31_245, 0);
      V v_text_248 = heff_field(v_x31_245, 1);
      HeffT2 v_t_249 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_olds_241, v_m_247));
      V v_t_2413;
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2411;
          v_t_2413 = v_x_2412;
        } else {
          heff_drop(v_field_2411);
          v_t_2413 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_str0);
        }
      }
      V v_c_2422;
      if (heff_strEq_c_lent(v_text_248, v_t_2413, 2)) {
        v_c_2422 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam1_clo);
      } else {
        V v_d_2416 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
        V v_st_2417 = heff_dup(heff_rfield(v_ps_240, 5));
        V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2417), v_d_2416));
        V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2417), heff_strAppend(heff_dup(v_m_247), ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_str1))));
        V v_t_2420 = (g_std_2epath_2ejoin(v_t_2418, v_t_2419));
        V v_t_2421 = ({ V a_0 = v_st_2417; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2420); r_; });
        v_c_2422 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138(v_t_2421, heff_dup(v_text_248)));
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam2, 2, 4, (V[]){v_c_2422, v_ps_240, heff_dup(v_olds_241), heff_dup(v_rest_246)});
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_olds_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2423 = heff_env(self)[3];
  V v_k_2424 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2425);
  V v_t_2426 = ({ V a_0 = v_ps_240; V a_1 = v_olds_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839(a_0, a_1, a_2)); heff_drop(v_olds_241); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2426;
  heff_room[0] = v_hd_2423;
  heff_room[1] = v_k_2424;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam2(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_olds_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_lam3, 1, 5, (V[]){v_ps_240, v_olds_241, v_rest_246, v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_entry, 12, 0};

V g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210(V v_bi_240, V v_dir_241, V v_rt_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_id_247, V v_texts_248, V v_backs_249, V v_z_2410, V v_z_2411) {
top: ;
  V v_key_2412 = heff_take_field(v_r_246, 0);
  V v_effect_2413 = heff_get_n(v_r_246, 1, 2);
  V v_zig_2414 = heff_take_field(v_rt_242, 1);
  V v_c_2415 = heff_get_n(v_rt_242, 0, 2);
  V v_runtime_2416 = v_c_2415;
  V v_provs_2417 = v_available_245;
  V v_g_2418 = heff_get_n(heff_get_n(v_c_244, 5, 14), 0, 10);
  V v_key_2419 = v_key_2412;
  V v_eff_2420 = v_effect_2413;
  V v_vers_2421 = heff_dup(heff_rfield(v_bi_240, 1));
  V v_t_2422 = (g_std_2eordmap_2etoListOnto(v_backs_249, NTAG(TAG_Nil)));
  V v_bs_2423 = (g_list_2emap_24s1173914895x100384474(v_t_2422));
  V v_t_2424 = (g_list_2efoldl_24s1707192740x1747748619(heff_dup(g_std_2eordmap_2eempty_get()), v_bs_2423));
  V v_t_2425 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2423; V r_ = (g_list_2efoldl_24s552376067x1255995125(a_0, a_1)); heff_drop(v_bs_2423); r_; });
  V v_ks_2426 = heff_rec_n(2, shape_units__copies, (V[]){v_t_2424, v_t_2425});
  V v_t_2427 = (g_std_2eordmap_2etoListOnto(v_backs_249, NTAG(TAG_Nil)));
  V v_bs_2428 = (g_list_2emap_24s1173914895x100384474(v_t_2427));
  V v_kept_2429 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2428; V r_ = (g_list_2efoldl_24s1272156913x1766532544(a_0, a_1)); heff_drop(v_bs_2428); r_; });
  V v_runtime_2430 = v_runtime_2416;
  V v_provs_2431 = v_provs_2417;
  V v_eff_2432 = v_eff_2420;
  V v_kept_2433 = v_kept_2429;
  HeffT4 v_t_2434 = (g_heff_2ecompile_2elower_2elowerProgramKept_24cpr(v_g_2418, v_key_2419, v_vers_2421, v_ks_2426));
  V v_lk_2444;
  {
    V v_field_2435 = v_t_2434.f[0];
    V v_field_2436 = v_t_2434.f[1];
    V v_field_2437 = v_t_2434.f[2];
    V v_field_2438 = v_t_2434.f[3];
    V v_si_2439 = v_field_2435;
    V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
    V v_t_2442 = (g_heff_2ecompile_2elower_2efusedOf(v_t_2441, v_si_2439));
    V v_t_2443 = (g_heff_2ecompile_2elower_2efusedWith_24s1193547903x2119508337(v_t_2440, v_field_2436, v_t_2442));
    v_lk_2444 = heff_rec_n(3, shape_lowered__groups__copies, (V[]){v_t_2443, v_field_2437, v_field_2438});
  }
  V v_runtime_2445 = v_runtime_2430;
  V v_provs_2446 = heff_dup(v_provs_2431);
  V v_t_2447 = (g_list_2eany_24s762674996x1009180162(v_provs_2431));
  V v_t_2448;
  if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
    heff_drop(v_t_2447);
    v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2ethreadsLine_get()), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_2447);
    v_t_2448 = NTAG(TAG_Nil);
  }
  V v_t_2449 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2erunEnd_clo), 1, (V[]){v_eff_2432}));
  V v_ending_2450 = heff_rec_n(2, shape_prefix__end, (V[]){v_t_2448, v_t_2449});
  V v_kept_2451 = v_kept_2433;
  V v_lk_2452 = heff_dup(v_lk_2444);
  V v_lowered_2453 = heff_take_field(v_lk_2452, 0);
  V v_groups_2454 = heff_take_field(v_lk_2452, 1);
  V v_copies_2455 = heff_get_n(v_lk_2452, 2, 3);
  V v_t_2456 = heff_get_n(heff_dup(heff_rfield(v_lk_2444, 0)), 1, 3);
  V v_t_2457 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_2458 = heff_get_n(heff_get_n(v_lk_2444, 0, 3), 0, 3);
  V v_t_2459 = (g_list_2efoldl_24f409057300x985797598(NTAG(TAG_Nil), v_t_2458));
  V v_t_2460 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2457, v_t_2459));
  V v_ce_2461 = ({ V a_0 = v_provs_2431; V a_1 = v_t_2456; V a_2 = v_t_2460; V r_ = (g_heff_2ecompile_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_t_2460); r_; });
  V v_ce_2462 = heff_dup(v_ce_2461);
  V v_kept_2463 = v_kept_2451;
  V v_defs_2464 = heff_dup(heff_rfield(v_lowered_2453, 0));
  V v_t_2465 = heff_rec_n(3, shape_ems__s__fresh, (V[]){NTAG(TAG_Nil), heff_dup(g_heff_2ecompile_2eemitc_2eemptyCS_get()), NTAG(TAG_Nil)});
  V v_acc_2473 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_lam0, 2, 2, (V[]){v_ce_2462, v_kept_2463}); V a_1 = v_t_2465; V a_2 = v_defs_2464; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_defs_2464); r_; });
  V v_ems_2474 = heff_take_field(v_acc_2473, 0);
  V v_s_2475 = heff_take_field(v_acc_2473, 1);
  V v_fresh_2476 = heff_get_n(v_acc_2473, 2, 3);
  V v_t_2477 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ems_2474));
  V v_t_2478 = (g_heff_2ecompile_2eemitc_2epartsWith(v_runtime_2445, v_provs_2446, v_ending_2450, heff_take_field(v_lowered_2453, 0), v_ce_2461, heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2477, v_s_2475})));
  V v_t_2479 = heff_rec_n(5, shape_parts__errors__groups__copies__emits, (V[]){v_t_2478, heff_get_n(v_lowered_2453, 2, 3), v_groups_2454, v_copies_2455, v_fresh_2476});
  return (g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415(v_bi_240, v_dir_241, v_zig_2414, v_id_247, v_texts_248, v_backs_249, v_done_243, v_t_2479, v_z_2410, v_z_2411));
}
V g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_entry(V self, V *a) {
  (void)self;
  V a8 = a[8]; V r = g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a8, a[9], a[10], a[11]); heff_drop(a8); return r;
}
V g_heff_2ebuild_2ecommands_2ekeptWith_24s241100974x1897310210_lam0(V self, V *args) {
  V v_acc_2466 = args[0];
  V v_d_2467 = args[1];
  V v_ce_2462 = heff_env(self)[0];
  V v_kept_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_own_2468 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL), heff_dup(heff_rfield(v_d_2467, 2))));
  V v_t_2471;
  switch (heff_tag_of(v_own_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_dup(heff_field(v_own_2468, 0));
    v_t_2471 = v_x_2469;
    break;
  }
  default: heff_nomatch(v_own_2468);
  }
  V v_t_2472 = (g_heff_2ecompile_2eemitc_2eemitVer(heff_dup(v_ce_2462), heff_dup(heff_rfield(v_d_2467, 0)), v_t_2471));
  return ({ V a_0 = v_ce_2462; V a_1 = v_kept_2463; V a_2 = v_acc_2466; V a_3 = v_d_2467; V a_4 = v_own_2468; V a_5 = v_t_2472; V r_ = (g_heff_2ecompile_2eemitc_2eemitAt(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_kept_2463); heff_drop(v_own_2468); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555(V v_lit_240, V v_lit_241, V v_l_242, V v_outPath_243, V v_file_244, V v_done_245, V v_hd_246, V v_k_247) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_str0), heff_dup(heff_rfield(v_l_242, 1)), MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam0, 1, 8, (V[]){v_l_242, v_hd_246, v_lit_240, v_k_247, v_lit_241, v_file_244, v_outPath_243, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam2(V self, V *args) {
  V v_c_2415 = args[0];
  V v_sources_2413 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2416 = ({ V a_0 = heff_dup(v_c_2415); V a_1 = v_sources_2413; HeffT2 r_ = (g_list_2efind_24s4435330x644005164_24cpr(a_0, a_1)); heff_drop(v_sources_2413); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_s_2419 = v_field_2418;
      V v_t_2420 = ({ V a_0 = v_x_2414; V a_1 = v_s_2419; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2414); r_; });
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2415, v_t_2420));
    } else {
      heff_drop(v_x_2414);
      heff_drop(v_field_2418);
      return v_c_2415;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam4(V self, V *args) {
  V v_a_2428 = args[0];
  V v_z_2429 = args[1];
  V v_z_2430 = args[2];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_2428);
  return (g_co_2eop_24s1772383553x418719539(v_lit_240, v_z_2429, v_z_2430));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_done_2411 = heff_env(self)[5];
  V v_l_242 = heff_env(self)[6];
  V v_hashes_2412 = heff_env(self)[7];
  V v_lit_241 = heff_env(self)[8];
  V v_file_244 = heff_env(self)[9];
  V v_outPath_243 = heff_env(self)[10];
  V v_done_245 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2422);
  if (heff_intLt_c(MK_INT(0LL), v_x_248)) {
    heff_drop(v_done_2411);
    heff_drop_rec(v_l_242, 5);
    heff_drop(v_hashes_2412);
    heff_drop(v_lit_241);
    heff_drop(v_file_244);
    heff_drop(v_outPath_243);
    heff_drop(v_done_245);
    V v_x2_2423 = ({ V a_0 = v_x_2421; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_x_2421); r_; });
    heff_drop(v_x2_2423);
    return (g_co_2eop_24s1772383553x418719539(v_lit_240, v_hd_246, v_k_247));
  } else {
    V v_t_2424 = (g_list_2eany_24s1740858080x874135214(v_x_2421));
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop(v_done_2411);
      heff_drop_rec(v_l_242, 5);
      heff_drop(v_hashes_2412);
      heff_drop(v_lit_241);
      heff_drop(v_file_244);
      heff_drop(v_outPath_243);
      heff_drop(v_done_245);
      heff_drop(v_t_2424);
      V v_x2_2425 = ({ V a_0 = v_x_2421; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_x_2421); r_; });
      heff_drop(v_x2_2425);
      return (g_co_2eop_24s1772383553x418719539(v_lit_240, v_hd_246, v_k_247));
    } else {
      heff_drop(v_t_2424);
      V v_t_2426 = (g_list_2emap_24s1698496827x1884878103(v_done_2411));
      V v_t_2427 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_l_242, 2), v_hashes_2412, v_t_2426});
      return ({ V a_0 = v_lit_241; V a_1 = v_t_2427; V b_2 = heff_get_n(v_l_242, 0, 5); V a_3 = v_file_244; V a_4 = v_outPath_243; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam4, 3, 1, (V[]){v_lit_240}); V a_6 = v_done_245; V a_7 = v_x_2421; V a_8 = v_hd_246; V a_9 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560(a_0, a_1, b_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(b_2); heff_drop(v_x_2421); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_file_244 = heff_env(self)[6];
  V v_outPath_243 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_done_2411 = heff_take_field(v_x_2410, 0);
  V v_hashes_2412 = heff_get_n(v_x_2410, 1, 2);
  V v_sources_2413 = heff_dup(heff_rfield(v_l_242, 0));
  V v_x_2414 = (g_list_2emap_24f1524014098x1956473147(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_str2), heff_dup(v_sources_2413)));
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam2, 1, 2, (V[]){v_sources_2413, v_x_2414}), heff_dup(v_done_2411)));
  return ({ V a_0 = v_x_2421; V a_1 = heff_dup(v_hd_246); V a_2 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam3, 1, 12, (V[]){v_x_248, heff_dup(v_x_2421), v_lit_240, v_hd_246, v_k_247, v_done_2411, v_l_242, v_hashes_2412, v_lit_241, v_file_244, v_outPath_243, v_done_245}); V r_ = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(a_0, a_1, a_2)); heff_drop(v_x_2421); r_; });
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_file_244 = heff_env(self)[5];
  V v_outPath_243 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_249 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_l_242)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s491015023x1729044555_lam1, 1, 9, (V[]){v_l_242, v_hd_246, v_x_248, v_lit_240, v_k_247, v_lit_241, v_file_244, v_outPath_243, v_done_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327(V v_outPath_240, V v_bad_241, V v_o_242, V v_z_243, V v_z_244) {
top: ;
  V v_source_245 = heff_take_field(v_o_242, 0);
  V v_errors_246 = heff_get_n(v_o_242, 1, 2);
  V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_outPath_240));
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
  V v_a_2410 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_248, v_source_245, ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam0_clo)});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_c_2423 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam1_clo)));
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam3, 1, 4, (V[]){v_errors_246, v_z_243, v_z_244, heff_dup(v_bad_241)})});
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam0(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_err_2418 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Left = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    V v_t_2419 = heff_tag_at_n(v_ru_24x_2417_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2418})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2419));
  }
  case TAG_Right: {
    V v_x_2420 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam2, 2, 1, (V[]){v_x_2420});
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_bad_241 = heff_env(self)[0];
  V v_errors_246 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2428);
  if (!(heff_dup(v_bad_241) == NTAG(TAG_True))) {
    heff_drop(v_bad_241);
    switch (heff_tag_of(v_errors_246)) {
    case TAG_Nil: {
      heff_drop(v_z_243);
      V f_ = v_z_244;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_ru_24errors_246_24Cons = heff_take_reuse_n(v_errors_246, 0ULL, 2);
      return (g_co_2eop_24s40508559x1835373952_24tok2(v_ru_24errors_246_24Cons, MK_INT(1LL), v_z_243, v_z_244));
    }
    default: return heff_nomatch(v_errors_246);
    }
  } else {
    heff_drop(v_bad_241);
    heff_drop(v_errors_246);
    return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_243, v_z_244));
  }
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_errors_246 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    V v_ru_24x_2424_24Left = heff_take_reuse_n(v_x_2424, 0ULL, 1);
    heff_drop(v_bad_241);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1(v_ru_24x_2424_24Left, v_errors_246, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam4, 1, 2, (V[]){v_z_243, v_z_244})));
  }
  case TAG_Right: {
    V v_ru_24x_2424_24Right = heff_take_reuse_n(v_x_2424, 0ULL, 1);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1(v_ru_24x_2424_24Right, heff_dup(v_errors_246), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_lam5, 1, 4, (V[]){v_bad_241, v_errors_246, v_z_244, v_z_243})));
  }
  default: return heff_nomatch(v_x_2424);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_str0, 5, "-- | ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_str1, 3, "-- ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297(V v_file_240, V v_badL_241, V v_cs_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(v_cs_242, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam0, 1, 5, (V[]){heff_dup(v_cs_242), heff_dup(v_badL_241), v_hd_243, v_k_244, v_file_240})));
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam1(V self, V *args) {
  V v_r_2425 = args[0];
  return v_r_2425;
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam3(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_x_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam2(V self, V *args) {
  V v_x_2433 = args[0];
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    V v_err_2434 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Left = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    V v_t_2435 = heff_tag_at_n(v_ru_24x_2433_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2434})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2435));
  }
  case TAG_Right: {
    V v_x_2436 = heff_field(v_x_2433, 0);
    heff_take_n(v_x_2433, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam3, 2, 1, (V[]){v_x_2436});
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Left: {
    V v_ru_24x_2440_24Left = heff_take_reuse_n(v_x_2440, 0ULL, 1);
    return (g_co_2eop_24s40508559x1835373952_24tok1(v_ru_24x_2440_24Left, MK_INT(1LL), v_hd_243, v_k_244));
  }
  case TAG_Right: {
    heff_take_n(v_x_2440, 0ULL, 1);
    heff_drop(v_hd_243);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2440);
  }
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_badL_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_file_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_245);
  HeffT2 v_t_246 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_242));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_c_249 = v_field_248;
      if ((heff_dup(v_badL_241) == NTAG(TAG_True))) {
        heff_drop(v_cs_242);
        heff_drop(v_badL_241);
        heff_drop(v_file_240);
        heff_drop_rec(v_c_249, 14);
        return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_243, v_k_244));
      } else {
        heff_drop(v_badL_241);
        V v_t_2410 = ({ V a_0 = v_cs_242; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_242); r_; });
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_file_240);
          heff_drop_rec(v_c_249, 14);
          heff_drop(v_t_2410);
          return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_243, v_k_244));
        } else {
          heff_drop(v_t_2410);
          V v_path_2411 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_file_240));
          V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_c_249, 5)), 4, 10);
          V v_x2_2413 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_249), v_t_2412));
          V v_t_2422;
          switch (heff_tag_of(v_x2_2413)) {
          case TAG_Nil: {
            v_t_2422 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_x_2414 = heff_field(v_x2_2413, 0);
            V v_xs_2415 = heff_field(v_x2_2413, 1);
            V v_ru_24x2_2413_24Cons = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
            V v_t_2421;
            switch (heff_tag_of(v_xs_2415)) {
            case TAG_Nil: {
              V v_t_2416 = heff_tag_at_n(v_ru_24x2_2413_24Cons, TAG_Cons, 2, (V[]){v_x_2414, NTAG(TAG_Nil)});
              v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
              break;
            }
            case TAG_Cons: {
              V v_y_2417 = heff_field(v_xs_2415, 0);
              V v_ys_2418 = heff_field(v_xs_2415, 1);
              V v_ru_24xs_2415_24Cons = heff_take_reuse_n(v_xs_2415, 3ULL, 2);
              if (heff_intLe_c(heff_dup(heff_rfield(v_y_2417, 0)), heff_dup(heff_rfield(v_x_2414, 0)))) {
                V v_t_2419 = heff_tag_at_n(v_ru_24x2_2413_24Cons, TAG_Cons, 2, (V[]){v_x_2414, NTAG(TAG_Nil)});
                v_t_2421 = (g_list_2eascending_24s927649470x204705998(heff_dup(v_y_2417), heff_tag_at_n(v_ru_24xs_2415_24Cons, TAG_Cons, 2, (V[]){v_y_2417, v_t_2419}), v_ys_2418));
              } else {
                V v_t_2420 = heff_tag_at_n(v_ru_24x2_2413_24Cons, TAG_Cons, 2, (V[]){v_x_2414, NTAG(TAG_Nil)});
                v_t_2421 = (g_list_2edescending_24s630739678x585974040(heff_dup(v_y_2417), heff_tag_at_n(v_ru_24xs_2415_24Cons, TAG_Cons, 2, (V[]){v_y_2417, v_t_2420}), v_ys_2418));
              }
              break;
            }
            default: heff_nomatch(v_xs_2415);
            }
            v_t_2422 = (g_list_2emergeRuns_24s1532989807x150355682(NTAG(TAG_Nil), v_t_2421));
            break;
          }
          default: heff_nomatch(v_x2_2413);
          }
          V v_text_2423 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_str0); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_str1); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_str2); V a_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_str3); V b_5 = MK_INT(0LL); V a_6 = heff_get_n(v_c_249, 3, 14); V a_7 = v_t_2422; V r_ = (g_list_2efoldl_24s1149369025x804005338(a_0, a_1, b_2, a_3, b_4, b_5, a_6, a_7)); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(v_t_2422); r_; });
          V v_t_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2411; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2411); r_; });
          V v_a_2426 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2424, v_text_2423, ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam1_clo)});
          V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2426})});
          V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
          V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
          V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
          V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
          V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
          V v_c_2439 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam2_clo)));
          V f_ = v_c_2439;
          heff_room[0] = heff_dup(v_hd_243);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1707465062x1822584297_lam4, 1, 2, (V[]){v_hd_243, v_k_244});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      }
    } else {
      heff_drop(v_cs_242);
      heff_drop(v_badL_241);
      heff_drop(v_file_240);
      heff_drop(v_field_248);
      return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_243, v_k_244));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1276590844x294544799(v_sources_240, v_m_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam1, 2, 3, (V[]){v_c_246, heff_dup(v_sources_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_t_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = ({ V a_0 = v_sources_240; V a_1 = v_rest_245; V r_ = (g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288(a_0, a_1)); heff_drop(v_sources_240); r_; });
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam3, 1, 2, (V[]){v_x_249, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855(V v_bi_240, V v_outPath_241, V v_id_242, V v_texts_243, V v_backs_244, V v_done_245, V v_out_246, V v_z_247, V v_z_248) {
top: ;
  V v_groups_249 = heff_take_field(v_out_246, 1);
  V v_copies_2410 = heff_take_field(v_out_246, 2);
  V v_jss_2411 = heff_take_field(v_out_246, 3);
  V v_output_2412 = heff_get_n(v_out_246, 0, 4);
  V v_paths_2413 = heff_take_field(v_bi_240, 0);
  V v_modules_2414 = heff_get_n(v_bi_240, 2, 3);
  V v_t_2443;
  if (heff_strEq_c_lent(v_id_242, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_str0), 2)) {
    heff_drop(v_id_242);
    heff_drop(v_backs_244);
    heff_drop(v_groups_249);
    heff_drop(v_copies_2410);
    heff_drop(v_jss_2411);
    heff_drop(v_paths_2413);
    heff_drop(v_modules_2414);
    v_t_2443 = v_done_245;
  } else {
    V v_s_2415 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_paths_2413)));
    V v_path_2416 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2415));
    V v_t_2417 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2416; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2416); r_; });
    V v_a_2419 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam0_clo)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    V v_c_2432 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam1_clo)));
    v_t_2443 = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam3, 2, 10, (V[]){v_c_2432, heff_dup(v_texts_243), v_modules_2414, v_groups_249, v_copies_2410, v_jss_2411, v_id_242, v_backs_244, v_paths_2413, v_done_245});
  }
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(v_outPath_241, v_t_2443, v_output_2412, v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam0(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam2(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_x_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    V v_err_2427 = heff_field(v_x_2426, 0);
    V v_ru_24x_2426_24Left = heff_take_reuse_n(v_x_2426, 1ULL, 1);
    V v_t_2428 = heff_tag_at_n(v_ru_24x_2426_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2427})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2428));
  }
  case TAG_Right: {
    V v_x_2429 = heff_field(v_x_2426, 0);
    heff_take_n(v_x_2426, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam2, 2, 1, (V[]){v_x_2429});
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam5(V self, V *args) {
  V v_x_2442 = args[0];
  V v_done_245 = heff_env(self)[0];
  V v_hd_2433 = heff_env(self)[1];
  V v_k_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2442);
  V f_ = v_done_245;
  heff_room[0] = v_hd_2433;
  heff_room[1] = v_k_2434;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_texts_243 = heff_env(self)[0];
  V v_modules_2414 = heff_env(self)[1];
  V v_groups_249 = heff_env(self)[2];
  V v_copies_2410 = heff_env(self)[3];
  V v_jss_2411 = heff_env(self)[4];
  V v_id_242 = heff_env(self)[5];
  V v_backs_244 = heff_env(self)[6];
  V v_paths_2413 = heff_env(self)[7];
  V v_hd_2433 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  V v_k_2434 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2435);
  V v_t_2436 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_texts_243; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_texts_243); r_; });
  V v_t_2437 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_str1), NTAG(TAG_MkUnit)));
  V v_t_2438 = ({ V a_0 = v_t_2437; V a_1 = v_modules_2414; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_modules_2414); r_; });
  V v_t_2439 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_groups_249, v_copies_2410, NTAG(TAG_Nil), v_jss_2411});
  V v_t_2440 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_242, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2438, v_backs_244}), v_t_2439));
  V v_c_2441 = ({ V a_0 = v_paths_2413; V a_1 = v_t_2436; V a_2 = v_t_2440; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839(a_0, a_1, a_2)); heff_drop(v_t_2436); heff_drop(v_t_2440); r_; });
  V f_ = v_c_2441;
  heff_room[0] = heff_dup(v_hd_2433);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam5, 1, 3, (V[]){v_done_245, v_hd_2433, v_k_2434});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam3(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_c_2432 = heff_env(self)[0];
  V v_texts_243 = heff_env(self)[1];
  V v_modules_2414 = heff_env(self)[2];
  V v_groups_249 = heff_env(self)[3];
  V v_copies_2410 = heff_env(self)[4];
  V v_jss_2411 = heff_env(self)[5];
  V v_id_242 = heff_env(self)[6];
  V v_backs_244 = heff_env(self)[7];
  V v_paths_2413 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2432;
  args[0] = heff_dup(v_hd_2433);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_lam4, 1, 11, (V[]){v_texts_243, v_modules_2414, v_groups_249, v_copies_2410, v_jss_2411, v_id_242, v_backs_244, v_paths_2413, v_hd_2433, v_done_245, v_k_2434});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str6, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str7, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_cs_246, V v_z_247, V v_z_248) {
top: ;
  HeffT2 v_t_249 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_246));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_c_2412 = v_field_2411;
      V v_t_2413 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2412)));
      V v_t_2414 = ({ V a_0 = v_t_2413; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2413); r_; });
      V v_t_2415 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2414));
      V v_xs_2416 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str2); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str3); V a_6 = v_t_2415; V r_ = (g_list_2emap_24s803586165x1676441765(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2417 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2416));
      V v_c_2418 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s2024024779x889379288(v_sources_241, v_t_2417));
      return heff_tail(v_c_2418, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam0, 1, 8, (V[]){v_bi_240, v_file_242, heff_dup(v_name_243), v_outPath_244, v_done_245, v_c_2412, v_z_247, v_z_248})});
    } else {
      heff_drop(v_bi_240);
      heff_drop(v_file_242);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      heff_drop(v_field_2411);
      V v_t_2421 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str7), NTAG(TAG_MkUnit)});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_247, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})}));
      return heff_tail(heff_dup(heff_rfield(v_z_247, 1)), 2, (V[]){v_t_2428, heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam1, 1, 2, (V[]){v_z_247, v_z_248})});
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674(a[0], a1, a[2], a3, a[4], a[5], a6, a[7], a[8]); heff_drop(a1); heff_drop(a3); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam0(V self, V *args) {
  V v_x_2419 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_outPath_244 = heff_env(self)[3];
  V v_done_245 = heff_env(self)[4];
  V v_c_2412 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  V v_z_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2420 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str4); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str5); V b_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_str6); V a_5 = v_x_2419; V r_ = (g_list_2ekeepIf_24s1228038992x175493858(b_0, a_1, b_2, b_3, b_4, a_5)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); heff_drop(b_4); r_; });
  return ({ V a_0 = v_bi_240; V a_1 = v_file_242; V a_2 = v_name_243; V a_3 = v_outPath_244; V a_4 = v_done_245; V a_5 = v_c_2412; V a_6 = v_t_2420; V a_7 = v_z_247; V a_8 = v_z_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_name_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s2135926233x1586298674_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_247, v_z_248));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str0, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str1, 16, " not formatted: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375(V v_checkOnly_240, V v_f_241, V v_src_242, V v_fix_243, V v_z_244, V v_z_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_fix_243, heff_dup(v_src_242)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_src_242);
      V v_why_249 = v_field_248;
      V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str0), v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str1));
      V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, v_why_249), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str2));
      V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2419, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam0, 1, 1, (V[]){v_z_245})});
    } else {
      V v_out_2421 = v_field_248;
      if (heff_strEq_c_lent(v_out_2421, v_src_242, 2)) {
        heff_drop(v_f_241);
        heff_drop_rec(v_z_244, 3);
        heff_drop(v_out_2421);
        return heff_tail(v_z_245, 1, (V[]){MK_INT(0LL)});
      } else {
        if ((heff_dup(v_checkOnly_240) == NTAG(TAG_True))) {
          heff_drop(v_out_2421);
          V v_t_2422 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_f_241, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_str3)), NTAG(TAG_MkUnit)});
          V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
          V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
          V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
          V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
          V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
          V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
          V v_t_2429 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})}));
          return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2429, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam1, 1, 1, (V[]){v_z_245})});
        } else {
          V v_path_2431 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_f_241));
          V v_t_2432 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2431; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2431); r_; });
          V v_a_2434 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2432, v_out_2421, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam2_clo)});
          V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2434})});
          V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
          V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
          V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
          V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
          V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
          V v_c_2447 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam3_clo)));
          return heff_tail(v_c_2447, 2, (V[]){v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam5, 1, 1, (V[]){v_z_245})});
        }
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2420);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam1(V self, V *args) {
  V v_x_2430 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2430);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam2(V self, V *args) {
  V v_r_2433 = args[0];
  return v_r_2433;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam4(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_x_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2445);
  V f_ = v_k_2446;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2444});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam3(V self, V *args) {
  V v_x_2441 = args[0];
  switch (heff_tag_of(v_x_2441)) {
  case TAG_Left: {
    V v_err_2442 = heff_field(v_x_2441, 0);
    V v_ru_24x_2441_24Left = heff_take_reuse_n(v_x_2441, 1ULL, 1);
    V v_t_2443 = heff_tag_at_n(v_ru_24x_2441_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2442})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2443));
  }
  case TAG_Right: {
    V v_x_2444 = heff_field(v_x_2441, 0);
    heff_take_n(v_x_2441, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam4, 2, 1, (V[]){v_x_2444});
  }
  default: return heff_nomatch(v_x_2441);
  }
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s438232623x1848665375_lam5(V self, V *args) {
  V v_x_2448 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2448);
  V f_ = v_z_245;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823(V v_path_240) {
top: ;
  V v_path_241 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_240)));
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_241; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_244 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_242, ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam0_clo)});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  V v_c_2428 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam1, 3, 1, (V[]){v_path_241})));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam5, 2, 2, (V[]){v_c_2428, v_path_240});
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823(a[0]);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam0(V self, V *args) {
  V v_r_243 = args[0];
  return v_r_243;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam3(V self, V *args) {
  V v_n_2419 = args[0];
  V v_path_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2419));
  return (g_std_2epath_2ejoin(v_path_241, v_t_2420));
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_z_2417 = args[1];
  V v_z_2418 = args[2];
  V v_path_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2417);
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam3, 1, 1, (V[]){v_path_241}), v_x_2416));
  V v_x_2422 = (g_list_2emap_24s219049803x1458391381(v_x_2421));
  V f_ = v_z_2418;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam4(V self, V *args) {
  V v_n_2424 = args[0];
  V v_path_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2424));
  return (g_std_2epath_2ejoin(v_path_241, v_t_2425));
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_2412 = args[1];
  V v_z_2413 = args[2];
  V v_path_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Left = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2411_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2414})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2415, heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam2, 3, 1, (V[]){v_path_241}), v_z_2412, v_z_2413));
  }
  case TAG_Right: {
    V v_x_2423 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    heff_drop(v_z_2412);
    V v_x_2426 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam4, 1, 1, (V[]){v_path_241}), v_x_2423));
    V v_x_2427 = (g_list_2emap_24s219049803x1458391381(v_x_2426));
    V f_ = v_z_2413;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2427});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam7(V self, V *args) {
  V v_r_2435 = args[0];
  return v_r_2435;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam9(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_x_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2447);
  V f_ = v_k_2448;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2446});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam8(V self, V *args) {
  V v_x_2443 = args[0];
  switch (heff_tag_of(v_x_2443)) {
  case TAG_Left: {
    V v_err_2444 = heff_field(v_x_2443, 0);
    V v_ru_24x_2443_24Left = heff_take_reuse_n(v_x_2443, 1ULL, 1);
    V v_t_2445 = heff_tag_at_n(v_ru_24x_2443_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2444})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2445));
  }
  case TAG_Right: {
    V v_x_2446 = heff_field(v_x_2443, 0);
    heff_take_n(v_x_2443, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam9, 2, 1, (V[]){v_x_2446});
  }
  default: return heff_nomatch(v_x_2443);
  }
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam10(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2450)) {
  case TAG_Left: {
    heff_take_n(v_x_2450, 0ULL, 1);
    V f_ = v_k_2430;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2450, 0ULL, 1);
    V f_ = v_k_2430;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2450);
  }
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_2429 = heff_env(self)[1];
  V v_k_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Left: {
    V v_ru_24x_2431_24Left = heff_take_reuse_n(v_x_2431, 0ULL, 1);
    V v_path_2433 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_240));
    V v_t_2434 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2433; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2433); r_; });
    V v_a_2436 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam7_clo)});
    V v_t_2437 = heff_tag_at_n(v_ru_24x_2431_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
    V v_c_2449 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam8_clo)));
    V f_ = v_c_2449;
    heff_room[0] = v_hd_2429;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam10, 1, 1, (V[]){v_k_2430});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2431, 0ULL, 1);
    heff_drop(v_path_240);
    heff_drop(v_hd_2429);
    V f_ = v_k_2430;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2431);
  }
}
V g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam5(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2428;
  args[0] = heff_dup(v_hd_2429);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s816862592x525580823_lam6, 1, 3, (V[]){v_path_240, v_hd_2429, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_str2, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_x_243);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Just: {
    V v_text_247 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24Just = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    V v_src_248 = heff_dup(v_text_247);
    V v_t_249 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    HeffT3 v_t_2410 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(heff_dup(v_src_248), v_t_249, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V v_t_2429;
    {
      V v_field_2412 = v_t_2410.f[1];
      heff_drop(v_t_2410.f[0]);
      heff_drop(v_t_2410.f[2]);
      switch (heff_tag_of(v_field_2412)) {
      case TAG_Nil: {
        V v_t_2414 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        HeffT3 v_t_2415 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_248, v_t_2414, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
        V v_t_2419;
        {
          V v_field_2416 = v_t_2415.f[0];
          heff_drop(v_t_2415.f[1]);
          heff_drop(v_t_2415.f[2]);
          v_t_2419 = v_field_2416;
        }
        HeffT2 v_t_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_str0); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_str1); V b_2 = heff_arrayFromList(v_t_2419); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_Nothing); HeffT2 r_ = (g_heff_2ebuild_2eproject_2edeclsGo_24cpr(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
        {
          V v_field_2422 = v_t_2420.f[1];
          int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
          if ((v_tag_2421 == ((int64_t)0ULL))) {
            V v_p_2423 = v_field_2422;
            v_t_2429 = heff_tag_at_n(v_ru_24x5_244_24Just, TAG_Left, 1, (V[]){v_p_2423});
          } else {
            heff_drop_cell(v_ru_24x5_244_24Just, 1);
            V v_x_2424 = v_field_2422;
            v_t_2429 = ({ V a_0 = v_x_2424; V r_ = (g_heff_2ebuild_2eproject_2ebuildOf(a_0)); heff_drop(v_x_2424); r_; });
          }
        }
        break;
      }
      case TAG_Cons: {
        V v_e_2425 = heff_field(v_field_2412, 0);
        heff_take_n(v_field_2412, 1ULL, 2);
        heff_drop(v_src_248);
        V v_start_2427 = heff_take_field(v_e_2425, 0);
        V v_msg_2428 = heff_get_n(v_e_2425, 2, 3);
        v_t_2429 = heff_tag_at_n(v_ru_24x5_244_24Just, TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_start_2427, v_msg_2428})});
        break;
      }
      default: heff_nomatch(v_field_2412);
      }
    }
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Left: {
      V v_p_2430 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      V v_t_2431 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_240, v_t_241, v_x_243, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_str2)));
      V v_str_2432 = ({ V a_0 = v_t_2431; V a_1 = v_text_247; V a_2 = v_p_2430; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_text_247); r_; });
      return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam1, 2, 2, (V[]){v_str_2432, v_acc_242});
    }
    case TAG_Right: {
      V v_a_2448 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      heff_drop(v_text_247);
      V v_c_2449 = (g_heff_2ebuild_2ecommands_2enotInProject_24s111977055x2098273376(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(heff_rfield(v_a_2448, 2))));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam3, 2, 6, (V[]){v_c_2449, v_st_240, v_t_241, v_acc_242, v_x_243, v_a_2448});
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam2(V self, V *args) {
  V v_x_2445 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_k_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2445);
  V v_t_2446 = heff_intAdd(heff_take_field(v_acc_242, 1), MK_INT(1LL));
  V v_t_2447 = ({ V rv_1 = v_t_2446; V rr_ = heff_rec_reuse_nf(v_acc_242, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2434;
  args[0] = v_t_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam1(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_str_2432 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2435 = heff_take_field(v_hd_2433, 1);
  V v_malg_2436 = heff_get_n(v_hd_2433, 2, 3);
  V v_t_2437 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2432, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_str3)), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tr(heff_call(v_malg_2436, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})}));
  V f_ = v_bind_2435;
  args[0] = v_t_2444;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam2, 1, 2, (V[]){v_acc_242, v_k_2434});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam4(V self, V *args) {
  V v_x_2452 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_a_2448 = heff_env(self)[4];
  V v_hd_2450 = heff_env(self)[5];
  V v_k_2451 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422(v_st_240, v_t_241, v_acc_242, v_x_243, v_a_2448, v_x_2452, v_hd_2450, v_k_2451));
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam3(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_c_2449 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_a_2448 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2449;
  args[0] = heff_dup(v_hd_2450);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_lam4, 1, 7, (V[]){v_st_240, v_t_241, v_acc_242, v_x_243, v_a_2448, v_hd_2450, v_k_2451});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_str0, 24, "putting the programs in ");
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417(V v_st_240, V v_t_241, V v_next_242, V v_progs_243) {
top: ;
  V v_path_244 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(heff_rfield(v_t_241, 1))));
  V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_244; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_244); r_; });
  V v_a_247 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_245, ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam0_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  V v_c_2420 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam1_clo)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam3, 2, 5, (V[]){v_c_2420, heff_dup(v_progs_243), v_t_241, v_st_240, v_next_242});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_err_2415 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_tag_at_n(v_ru_24x_2414_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2415})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2416));
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam2, 2, 1, (V[]){v_x_2417});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam5(V self, V *args) {
  V v_t_2426 = args[0];
  return v_t_2426;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam8(V self, V *args) {
  V v_x_2433 = args[0];
  V v_next_242 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2433);
  V f_ = v_next_242;
  heff_room[0] = v_hd_2431;
  heff_room[1] = v_k_2432;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam7(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_x_2430 = heff_env(self)[0];
  V v_next_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s1531911654x724325922(v_x_2430, heff_dup(v_hd_2431), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam8, 1, 3, (V[]){v_next_242, v_hd_2431, v_k_2432})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_next_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_hd_2421 = heff_env(self)[4];
  V v_k_2422 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2434 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = heff_dup(v_x_2430); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam7, 2, 2, (V[]){v_x_2430, v_next_242}); V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2434;
  heff_room[0] = v_hd_2421;
  heff_room[1] = v_k_2422;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_hd_2421 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_next_242 = heff_env(self)[4];
  V v_k_2422 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2423);
  V v_total_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_243));
  V v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_str0), heff_dup(heff_rfield(v_t_241, 1)));
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2425, v_total_2424, ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam5_clo)})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2421, 2)), 1, (V[]){v_t_2428}));
  V f_ = heff_dup(heff_rfield(v_hd_2421, 1));
  heff_room[0] = v_t_2429;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam6, 1, 6, (V[]){v_st_240, v_t_241, v_next_242, v_progs_243, v_hd_2421, v_k_2422});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_progs_243 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_next_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2420;
  args[0] = heff_dup(v_hd_2421);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_lam4, 1, 6, (V[]){v_progs_243, v_t_241, v_hd_2421, v_st_240, v_next_242, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str0, 12, "cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str4, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str5, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str7, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str9, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str10, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str13, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str14, 3, "src");
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272(V v_before_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_before_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam0_clo);
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_244)));
    V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_246); r_; });
    V v_a_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_ReadFile, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam1_clo)});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    V v_c_2422 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam2_clo)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam4, 2, 4, (V[]){v_c_2422, v_path_244, v_before_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam1(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_err_2417 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    V v_t_2418 = heff_tag_at_n(v_ru_24x_2416_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2417})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2418));
  }
  case TAG_Right: {
    V v_x_2419 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam3, 2, 1, (V[]){v_x_2419});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam7(V self, V *args) {
  V v_x_2445 = args[0];
  V v_k_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2445);
  V f_ = v_k_2424;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_2423 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tr(heff_call(heff_take_field(v_hd_2423, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})}));
  V f_ = heff_get_n(v_hd_2423, 1, 3);
  heff_room[0] = v_t_2444;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam7, 1, 1, (V[]){v_k_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam8(V self, V *args) {
  V v_s_2447 = args[0];
  return v_s_2447;
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam12(V self, V *args) {
  V v_i_2474 = args[0];
  V v_before_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2475 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_i_2474}));
  return ({ V a_0 = v_t_2475; V a_1 = v_before_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_before_240); r_; });
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam11(V self, V *args) {
  V v_x_2466 = args[0];
  V v_st_2457 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_lib_2460 = heff_env(self)[2];
  V v_mod_2461 = heff_env(self)[3];
  V v_cwd_2462 = heff_env(self)[4];
  V v_style_2463 = heff_env(self)[5];
  V v_before_240 = heff_env(self)[6];
  V v_y_2446 = heff_env(self)[7];
  V v_k_2424 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_m_2467 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str8), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str9), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str10), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str11), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str12), v_st_2457}), heff_dup(v_path_244)));
  V v_ps_2468 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str13), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str14), v_lib_2460, v_mod_2461, v_cwd_2462, v_style_2463});
  HeffT2 v_t_2469 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_2468), heff_get_n(v_ps_2468, 2, 6), heff_dup(v_path_244)));
  V v_library_2473;
  {
    V v_field_2471 = v_t_2469.f[1];
    int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
    v_library_2473 = heff_bool(((v_tag_2470 == ((int64_t)0ULL)) && ({ V v_x_2472 = heff_dup(v_field_2471); int c_ = 1; heff_drop(v_x_2472); c_; })));
    heff_drop(v_field_2471);
  }
  V v_t_2476 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam12, 1, 1, (V[]){v_before_240}), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get())));
  V v_t_2477 = heff_rec_n(8, shape_module__named__path__shown__source__renames__implicit__library, (V[]){heff_dup(v_m_2467), v_m_2467, heff_dup(v_path_244), v_path_244, v_y_2446, NTAG(TAG_Nil), v_t_2476, v_library_2473});
  V v_x_2478 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, v_x_2466});
  V f_ = v_k_2424;
  args[0] = v_x_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam10(V self, V *args) {
  V v_x_2459 = args[0];
  V v_st_2457 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_hd_2423 = heff_env(self)[4];
  V v_y_2446 = heff_env(self)[5];
  V v_k_2424 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_lib_2460 = heff_take_field(v_x_2459, 0);
  V v_mod_2461 = heff_take_field(v_x_2459, 1);
  V v_cwd_2462 = heff_take_field(v_x_2459, 2);
  V v_style_2463 = heff_get_n(v_x_2459, 3, 5);
  V v_t_2464 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str3), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str4), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str5), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str6), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str7), heff_dup(v_st_2457)}), heff_dup(v_path_244)));
  V v_c_2465 = (g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, heff_dup(v_before_240)}), v_rest_245));
  V f_ = v_c_2465;
  heff_room[0] = v_hd_2423;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam11, 1, 9, (V[]){v_st_2457, v_path_244, v_lib_2460, v_mod_2461, v_cwd_2462, v_style_2463, v_before_240, v_y_2446, v_k_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam9(V self, V *args) {
  V v_x_2456 = args[0];
  V v_hd_2423 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_y_2446 = heff_env(self)[4];
  V v_k_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2457;
  if (heff_strEq_c(v_x_2456, ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str2))) {
    v_st_2457 = NTAG(TAG_Windows);
  } else {
    v_st_2457 = NTAG(TAG_Posix);
  }
  V v_c_2458 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo);
  V f_ = v_c_2458;
  heff_room[0] = heff_dup(v_hd_2423);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam10, 1, 7, (V[]){v_st_2457, v_path_244, v_before_240, v_rest_245, v_hd_2423, v_y_2446, v_k_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_hd_2423 = heff_env(self)[1];
  V v_k_2424 = heff_env(self)[2];
  V v_before_240 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    V v_ru_24x_2425_24Left = heff_take_reuse_n(v_x_2425, 0ULL, 1);
    heff_drop(v_before_240);
    heff_drop(v_rest_245);
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str0), v_path_244), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_str1));
    V v_t_2428 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2427, NTAG(TAG_MkUnit)});
    V v_t_2429 = heff_tag_at_n(v_ru_24x_2425_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2423, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})}));
    V f_ = heff_dup(heff_rfield(v_hd_2423, 1));
    heff_room[0] = v_t_2435;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam6, 1, 2, (V[]){v_hd_2423, v_k_2424});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2446 = heff_field(v_x_2425, 0);
    V v_ru_24x_2425_24Right = heff_take_reuse_n(v_x_2425, 1ULL, 1);
    V v_t_2448 = heff_tag_at_n(v_ru_24x_2425_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam8_clo)})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2423, 2)), 1, (V[]){v_t_2454}));
    V f_ = heff_dup(heff_rfield(v_hd_2423, 1));
    heff_room[0] = v_t_2455;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam9, 1, 6, (V[]){v_hd_2423, v_path_244, v_before_240, v_rest_245, v_y_2446, v_k_2424});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s662342493x341470272_lam5, 1, 5, (V[]){v_path_244, v_hd_2423, v_k_2424, v_before_240, v_rest_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}