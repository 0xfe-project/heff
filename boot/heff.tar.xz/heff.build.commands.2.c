// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_backend 2032133329
#define LBL_bin 307073
#define LBL_c 317
#define LBL_done 9584713
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_hashes 722717031
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_opt 319789
#define LBL_own 320000
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_shipTo 1043811586
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_zig 330130
static uint32_t shape_c__zig[] = {LBL_c, LBL_zig};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_clo;
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897_clo;
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502(V, V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879(V, V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_clo;
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646(V, V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_clo;
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457(V, V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_clo;
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2erunProgram(V, V);
V g_heff_2ebuild_2ecommands_2erunProgram_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunProgram_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853(V, V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemitc_2echeckOut(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckOut_clo;
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
V g_heff_2ecompile_2eglue_2ejusts(V);
V g_heff_2ecompile_2eglue_2ejusts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ejusts_clo;
V g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929(V, V);
V g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2eutil_2ehostpath_2enormalize(V, V);
V g_heff_2eutil_2ehostpath_2enormalize_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2enormalize_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2ekeepIf_24f428638463x2144521938(V, V, V, V);
V g_list_2ekeepIf_24f428638463x2144521938_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f428638463x2144521938_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1176765648x1638512070(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1176765648x1638512070_entry(V self, V *a);
extern Clo g_list_2emap_24f1176765648x1638512070_clo;
V g_list_2emap_24f1524014098x1956473147(V, V, V, V);
V g_list_2emap_24f1524014098x1956473147_entry(V self, V *a);
extern Clo g_list_2emap_24f1524014098x1956473147_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1435185561x202019164(V);
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_clo;
V g_list_2emap_24s164225955x66209884(V, V, V);
V g_list_2emap_24s164225955x66209884_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2emap_24s89148281x951607804(V, V, V, V, V, V, V);
V g_list_2emap_24s89148281x951607804_entry(V self, V *a);
extern Clo g_list_2emap_24s89148281x951607804_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(V, V, V);
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);

HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_module_244 = heff_dup(heff_rfield(v_s_242, 0));
    V v_path_245 = heff_dup(heff_rfield(v_s_242, 2));
    if (heff_strEq_c_lent(v_module_244, v_m_241, 1)) {
      V v_f_246 = v_path_245;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      heff_drop(v_path_245);
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str8, 1, "$");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_module_244 = heff_dup(heff_rfield(v_p_242, 0));
    V v_text_245 = heff_dup(heff_rfield(v_p_242, 1));
    V v_t_246 = ({ V a_0 = v_k_241; V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
    V v_x2_247 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_246));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    if (heff_strEq_c(v_module_244, v_t_2410)) {
      V v_t_2411 = ({ V a_0 = v_k_241; V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
      V v_t_2412 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2411); r_; });
      V v_text_2413 = v_text_245;
      V v_t_2414 = ({ V a_0 = v_text_2413; V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str6); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str7), v_text_2413, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_text_2413); heff_drop(b_1); r_; });
      V v_t_2415 = (g_list_2emap_24s732475005x1616712052(v_t_2414));
      V v_t_2416 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str8); V a_3 = v_t_2415; V r_ = (g_list_2ekeepIf_24f428638463x2144521938(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
      V v_t_2417 = ({ V a_0 = v_t_2412; V a_1 = v_t_2416; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2412); heff_drop(v_t_2416); r_; });
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop(v_k_241);
        heff_drop(v_t_2417);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2417);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      heff_drop(v_text_245);
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeaf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str0, 13, "HEFF_MODCACHE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str5, 6, ".cache");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str6, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str7, 3, "mod");
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str0), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2410, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam1, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam0(V self, V *args) {
  V v_v_243 = args[0];
  return v_v_243;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam2(V self, V *args) {
  V v_v_2412 = args[0];
  return v_v_2412;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam4(V self, V *args) {
  V v_v_2421 = args[0];
  return v_v_2421;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam6(V self, V *args) {
  V v_s_2430 = args[0];
  return v_s_2430;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2439;
  if (heff_strEq_c(v_x_2438, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str3))) {
    v_st_2439 = NTAG(TAG_Windows);
  } else {
    v_st_2439 = NTAG(TAG_Posix);
  }
  V v_x_2455;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    V v_t_2442;
    switch (heff_tag_of(v_x_2420)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2429)) {
      case TAG_Nothing: {
        v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2440 = heff_field(v_x_2429, 0);
        heff_take_n(v_x_2429, 1ULL, 1);
        v_t_2442 = v_x_2440;
        break;
      }
      default: heff_nomatch(v_x_2429);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2441 = heff_field(v_x_2420, 0);
      heff_take_n(v_x_2420, 1ULL, 1);
      heff_drop(v_x_2429);
      v_t_2442 = v_x_2441;
      break;
    }
    default: heff_nomatch(v_x_2420);
    }
    V v_t_2443 = (g_std_2epath_2eparse(heff_dup(v_st_2439), v_t_2442));
    V v_t_2444 = (g_std_2epath_2eparse(heff_dup(v_st_2439), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str5)));
    V v_t_2445 = (g_std_2epath_2ejoin(v_t_2443, v_t_2444));
    V v_a_2446 = ({ V a_0 = v_st_2439; V a_1 = v_t_2445; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2445); r_; });
    V v_t_2447 = (g_std_2epath_2eparse(heff_dup(v_st_2439), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str6)));
    V v_t_2448 = (g_std_2epath_2eparse(heff_dup(v_st_2439), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str7)));
    V v_t_2449 = (g_std_2epath_2ejoin(v_t_2447, v_t_2448));
    V v_b_2450 = ({ V a_0 = v_st_2439; V a_1 = v_t_2449; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2449); r_; });
    V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_2439), v_a_2446));
    V v_t_2452 = (g_std_2epath_2eparse(heff_dup(v_st_2439), v_b_2450));
    V v_t_2453 = (g_std_2epath_2ejoin(v_t_2451, v_t_2452));
    v_x_2455 = ({ V a_0 = v_st_2439; V a_1 = v_t_2453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2439); heff_drop(v_t_2453); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2454 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    heff_drop(v_x_2420);
    heff_drop(v_x_2429);
    heff_drop(v_st_2439);
    v_x_2455 = v_d_2454;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V f_ = v_k_242;
  args[0] = v_x_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam6_clo)})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2437, v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam7, 1, 4, (V[]){v_x_2411, v_x_2420, v_x_2429, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str2), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam4_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2428, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam5, 1, 5, (V[]){v_e_240, v_hd_241, v_x_2411, v_x_2420, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_str1), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2419, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s2028780416x108727457_lam3, 1, 4, (V[]){v_e_240, v_hd_241, v_x_2411, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_str0, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_str2, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_str3, 8, "heff run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_str4, 4, "main");
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684(V v_e_240, V v_file_241, V v_progArgs_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), heff_dup(v_file_241), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam0, 1, 5, (V[]){v_file_241, v_e_240, v_hd_243, v_progArgs_242, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam1(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam3(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam5(V self, V *args) {
  V v_why_2420 = args[0];
  V v_z_2421 = args[1];
  V v_z_2422 = args[2];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_why_2420);
  V v_t_2423 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_z_2421, v_z_2422));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_cmd_2418 = heff_env(self)[0];
  V v_progArgs_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_2430 = heff_env(self)[3];
  V v_k_2431 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_Exec, 3, (V[]){v_cmd_2418, v_progArgs_242, NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_hd_2430, v_k_2431));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam6(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_x_249 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_cmd_2418 = heff_env(self)[2];
  V v_progArgs_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2432 = heff_tag_n(TAG_End, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), heff_dup(v_hd_2430), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam7, 1, 5, (V[]){v_cmd_2418, v_progArgs_242, v_e_240, v_hd_2430, v_k_2431})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam8(V self, V *args) {
  V v_why_2443 = args[0];
  V v_z_2444 = args[1];
  V v_z_2445 = args[2];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_why_2443);
  V v_t_2446 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), v_z_2444, v_z_2445));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam10(V self, V *args) {
  V v_x_2457 = args[0];
  V v_next_2442 = heff_env(self)[0];
  V v_hd_2453 = heff_env(self)[1];
  V v_k_2454 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2457);
  V f_ = v_next_2442;
  heff_room[0] = v_hd_2453;
  heff_room[1] = v_k_2454;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam9(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k_2454 = args[1];
  V v_x_2413 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_next_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2455 = heff_tag_n(TAG_End, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2456}), heff_dup(v_hd_2453), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam10, 1, 3, (V[]){v_next_2442, v_hd_2453, v_k_2454})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_progArgs_242 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_245, 2)), heff_dup(v_file_241)));
  V v_outPath_2415 = heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_str1));
  V v_dir_2416 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_245, 2)), heff_dup(v_file_241)));
  V v_out_2417 = (g_heff_2ebuild_2ecommands_2erunProgram(heff_dup(heff_rfield(v_x_245, 2)), heff_dup(v_file_241)));
  V v_cmd_2418 = (g_heff_2ebuild_2ecommands_2erunProgram(heff_dup(heff_rfield(v_x_245, 2)), heff_dup(v_file_241)));
  V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_x_245, 2)), 5, 6);
  V v_next_2442 = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263(((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_str2), heff_dup(v_e_240), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam5, 3, 1, (V[]){heff_dup(v_e_240)}), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_str3), v_t_2419, heff_dup(v_x_249), v_dir_2416, v_out_2417, heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam6, 2, 4, (V[]){v_x_249, heff_dup(v_e_240), v_cmd_2418, v_progArgs_242})));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1353924785x1419907547(((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_str4), heff_dup(v_e_240), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam8, 3, 1, (V[]){heff_dup(v_e_240)}), v_x_245, v_outPath_2415, v_file_241, heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam9, 2, 3, (V[]){v_x_2413, v_e_240, v_next_2442}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_file_241 = heff_env(self)[3];
  V v_progArgs_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_249), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam3_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2412, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam4, 1, 7, (V[]){v_x_245, v_file_241, v_e_240, v_x_249, v_progArgs_242, v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_progArgs_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_dup(v_file_241), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam1_clo)})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_248, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_lam2, 1, 6, (V[]){v_e_240, v_hd_243, v_x_245, v_file_241, v_progArgs_242, v_k_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str4, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str5, 11, "runtime.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str6, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str7, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str8, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str9, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str10, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str12, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str13, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str14, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str15, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str17, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str18, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str19, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam7(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393(V v_e_240, V v_bi_241, V v_sources_242, V v_file_243, V v_name_244, V v_outPath_245, V v_failed_246, V v_done_247, V v_cs_248, V v_z_249, V v_z_2410) {
top: ;
  HeffT2 v_t_2411 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_248));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_c_2414 = v_field_2413;
      V v_t_2415 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2414)));
      V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2415); r_; });
      V v_t_2417 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2416));
      V v_xs_2418 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str2); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str3); V a_6 = v_t_2417; V r_ = (g_list_2emap_24s89148281x951607804(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2419 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2418));
      V v_c_2420 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742(heff_dup(v_e_240), v_sources_242, v_t_2419));
      return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam0, 1, 10, (V[]){v_e_240, v_z_249, v_name_244, v_outPath_245, v_c_2414, v_z_2410, v_file_243, v_failed_246, v_bi_241, v_done_247})});
    } else {
      heff_drop(v_bi_241);
      heff_drop(v_sources_242);
      heff_drop(v_file_243);
      heff_drop(v_name_244);
      heff_drop(v_outPath_245);
      heff_drop(v_failed_246);
      heff_drop(v_done_247);
      heff_drop(v_field_2413);
      V v_t_2489 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str19), NTAG(TAG_MkUnit)});
      V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
      V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
      V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
      V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
      V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
      V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2495}), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam7, 1, 3, (V[]){v_e_240, v_z_249, v_z_2410})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_entry(V self, V *a) {
  (void)self;
  V a8 = a[8]; V r = g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a8, a[9], a[10]); heff_drop(a8); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_2432 = args[1];
  V v_k_2433 = args[2];
  heff_drop(v_hd_2432);
  V f_ = v_k_2433;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam5(V self, V *args) {
  V v_x_2449 = args[0];
  V v_c_2414 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_outPath_245 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_z_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2449);
  V v_exports_2450 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str12); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = heff_take_field(v_c_2414, 7); V r_ = (g_list_2emap_24f1176765648x1638512070(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
  V v_roots_2451 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_exports_2450)));
  V v_t_2452 = heff_get_n(heff_get_n(v_c_2414, 5, 14), 0, 10);
  V v_t_2453 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_t_2452));
  V v_t_2454 = (g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929(v_roots_2451, v_t_2453));
  V v_t_2455 = (g_heff_2ecompile_2eemitc_2echeckOut(v_x_2422, v_exports_2450, v_t_2454));
  return ({ V a_0 = v_e_240; V a_1 = v_outPath_245; V b_2 = NTAG(TAG_True); V a_3 = v_t_2455; V a_4 = v_z_249; V a_5 = v_z_2410; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_outPath_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_249 = heff_env(self)[2];
  V v_c_2414 = heff_env(self)[3];
  V v_x_2422 = heff_env(self)[4];
  V v_z_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2435)) {
  case TAG_Left: {
    V v_ru_24x_2435_24Left = heff_take_reuse_n(v_x_2435, 0ULL, 1);
    int64_t v_t_2437 = (heff_unbox_word(heff_strLength_lent(v_outPath_245, 0)) - ((int64_t)2ULL));
    V v_t_2438 = heff_strSlice(heff_dup(v_outPath_245), heff_box_word(v_t_2437), heff_strLength_lent(v_outPath_245, 0));
    V v_t_2440;
    if (heff_strEq_c(v_t_2438, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str8))) {
      int64_t v_t_2439 = (heff_unbox_word(heff_strLength_lent(v_outPath_245, 0)) - ((int64_t)2ULL));
      v_t_2440 = heff_strSlice_lent(v_outPath_245, MK_INT(0LL), heff_box_word(v_t_2439), 6);
    } else {
      v_t_2440 = heff_dup(v_outPath_245);
    }
    V v_t_2441 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str9), heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str10)));
    V v_t_2442 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2441, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str11)), NTAG(TAG_MkUnit)});
    V v_t_2443 = heff_tag_at_n(v_ru_24x_2435_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam5, 1, 6, (V[]){v_c_2414, v_x_2422, v_e_240, v_outPath_245, v_z_249, v_z_2410})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2435, 0ULL, 1);
    V v_exports_2457 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str13); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = heff_take_field(v_c_2414, 7); V r_ = (g_list_2emap_24f1176765648x1638512070(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
    V v_roots_2458 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_exports_2457)));
    V v_t_2459 = heff_get_n(heff_get_n(v_c_2414, 5, 14), 0, 10);
    V v_t_2460 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_t_2459));
    V v_t_2461 = (g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929(v_roots_2458, v_t_2460));
    V v_t_2462 = (g_heff_2ecompile_2eemitc_2echeckOut(v_x_2422, v_exports_2457, v_t_2461));
    return ({ V a_0 = v_e_240; V a_1 = v_outPath_245; V b_2 = NTAG(TAG_False); V a_3 = v_t_2462; V a_4 = v_z_249; V a_5 = v_z_2410; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(b_2); r_; });
  }
  default: return heff_nomatch(v_x_2435);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam6(V self, V *args) {
  V v_x_2483 = args[0];
  V v_file_243 = heff_env(self)[0];
  V v_failed_246 = heff_env(self)[1];
  V v_why_2473 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_z_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2483);
  V v_t_2484 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str17), v_file_243), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str18));
  V f_ = v_failed_246;
  heff_room[0] = heff_strAppend(v_t_2484, v_why_2473);
  heff_room[1] = v_z_249;
  heff_room[2] = v_z_2410;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_name_244 = heff_env(self)[0];
  V v_outPath_245 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_c_2414 = heff_env(self)[4];
  V v_x_2422 = heff_env(self)[5];
  V v_z_2410 = heff_env(self)[6];
  V v_x_2421 = heff_env(self)[7];
  V v_file_243 = heff_env(self)[8];
  V v_failed_246 = heff_env(self)[9];
  V v_bi_241 = heff_env(self)[10];
  V v_done_247 = heff_env(self)[11];
  heff_clo_take(self, 12);
  switch (heff_tag_of(v_name_244)) {
  case TAG_Nothing: {
    heff_drop(v_x_2421);
    heff_drop(v_file_243);
    heff_drop(v_failed_246);
    heff_drop(v_bi_241);
    heff_drop(v_done_247);
    int64_t v_t_2424 = (heff_unbox_word(heff_strLength_lent(v_outPath_245, 0)) - ((int64_t)2ULL));
    V v_t_2425 = heff_strSlice(heff_dup(v_outPath_245), heff_box_word(v_t_2424), heff_strLength_lent(v_outPath_245, 0));
    V v_t_2427;
    if (heff_strEq_c(v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str6))) {
      int64_t v_t_2426 = (heff_unbox_word(heff_strLength_lent(v_outPath_245, 0)) - ((int64_t)2ULL));
      v_t_2427 = heff_strSlice_lent(v_outPath_245, MK_INT(0LL), heff_box_word(v_t_2426), 6);
    } else {
      v_t_2427 = heff_dup(v_outPath_245);
    }
    V v_path_2428 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str7))));
    V v_c_2429 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2428; V a_2 = v_x_2423; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2428); r_; });
    V v_t_2430 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2434 = heff_tr(heff_call(v_c_2429, 2, (V[]){v_t_2430, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam3_clo)}));
    V f_ = v_c_2434;
    heff_room[0] = heff_dup(v_z_249);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam4, 1, 6, (V[]){v_outPath_245, v_e_240, v_z_249, v_c_2414, v_x_2422, v_z_2410});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_t_2464 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2414)));
    V v_t_2465 = ({ V a_0 = v_t_2464; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2464); r_; });
    V v_leaves_2466 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2465));
    V v_t_2467 = heff_get_n(heff_dup(heff_rfield(v_c_2414, 5)), 0, 10);
    V v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo), 1, (V[]){heff_dup(v_x_2421)}));
    V v_t_2469 = (g_list_2emap_24s164225955x66209884(v_t_2467, v_t_2468, v_leaves_2466));
    HeffT2 v_t_2470 = (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2469));
    {
      V v_field_2472 = v_t_2470.f[1];
      int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
      if ((v_tag_2471 == ((int64_t)0ULL))) {
        heff_drop(v_x_2423);
        heff_drop_tag(v_name_244, 1);
        heff_drop(v_outPath_245);
        heff_drop_rec(v_c_2414, 14);
        heff_drop(v_x_2422);
        heff_drop(v_x_2421);
        heff_drop(v_bi_241);
        heff_drop(v_done_247);
        V v_why_2473 = v_field_2472;
        V v_t_2474 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str14), heff_dup(v_file_243)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str15));
        V v_t_2475 = heff_strAppend(heff_strAppend(v_t_2474, heff_dup(v_why_2473)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str16));
        V v_t_2476 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2475, NTAG(TAG_MkUnit)});
        V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
        V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
        V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
        V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
        V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
        V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
        return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2482}), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam6, 1, 5, (V[]){v_file_243, v_failed_246, v_why_2473, v_z_249, v_z_2410})));
      } else {
        V v_ms_2485 = v_field_2472;
        V v_glues_2486 = (g_heff_2ecompile_2eglue_2ejusts(v_ms_2485));
        V v_t_2487 = (g_list_2emap_24s1435185561x202019164(v_glues_2486));
        V v_t_2488 = (g_prelude_2e_2b_2b(v_x_2421, v_t_2487));
        return ({ V a_0 = v_e_240; V a_1 = v_bi_241; V a_2 = v_file_243; V a_3 = v_name_244; V a_4 = v_outPath_245; V a_5 = heff_rec_n(2, shape_c__zig, (V[]){v_x_2422, v_x_2423}); V a_6 = v_failed_246; V a_7 = v_done_247; V a_8 = v_c_2414; V a_9 = v_t_2488; V a_10 = v_z_249; V a_11 = v_z_2410; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop_tag(v_name_244, 1); r_; });
      }
    }
  }
  default: return heff_nomatch(v_name_244);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  V v_name_244 = heff_env(self)[2];
  V v_outPath_245 = heff_env(self)[3];
  V v_c_2414 = heff_env(self)[4];
  V v_z_2410 = heff_env(self)[5];
  V v_x_2421 = heff_env(self)[6];
  V v_file_243 = heff_env(self)[7];
  V v_failed_246 = heff_env(self)[8];
  V v_bi_241 = heff_env(self)[9];
  V v_done_247 = heff_env(self)[10];
  heff_clo_take(self, 11);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str5), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam2, 1, 12, (V[]){v_name_244, v_outPath_245, v_e_240, v_z_249, v_c_2414, v_x_2422, v_z_2410, v_x_2421, v_file_243, v_failed_246, v_bi_241, v_done_247})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam0(V self, V *args) {
  V v_x_2421 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  V v_name_244 = heff_env(self)[2];
  V v_outPath_245 = heff_env(self)[3];
  V v_c_2414 = heff_env(self)[4];
  V v_z_2410 = heff_env(self)[5];
  V v_file_243 = heff_env(self)[6];
  V v_failed_246 = heff_env(self)[7];
  V v_bi_241 = heff_env(self)[8];
  V v_done_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_str4), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam1, 1, 11, (V[]){v_e_240, v_z_249, v_name_244, v_outPath_245, v_c_2414, v_z_2410, v_x_2421, v_file_243, v_failed_246, v_bi_241, v_done_247})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393_lam7(V self, V *args) {
  V v_x_2496 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  V v_z_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2496);
  V v_t_2497 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
  V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24102})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24103}), v_z_249, v_z_2410));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_str3, 19, ": it does not check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_str4, 19, ": it does not check");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474(V v_e_240, V v_failed_241, V v_l_242, V v_name_243, V v_outPath_244, V v_file_245, V v_done_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_str0), heff_dup(heff_rfield(v_l_242, 1)), MK_INT(0LL), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_lam0, 1, 9, (V[]){v_e_240, v_l_242, v_hd_247, v_file_245, v_failed_241, v_k_248, v_name_243, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_lam2(V self, V *args) {
  V v_c_2416 = args[0];
  V v_sources_2414 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2417 = ({ V a_0 = heff_dup(v_c_2416); V a_1 = v_sources_2414; HeffT2 r_ = (g_list_2efind_24s4435330x644005164_24cpr(a_0, a_1)); heff_drop(v_sources_2414); r_; });
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_s_2420 = v_field_2419;
      V v_t_2421 = ({ V a_0 = v_x_2415; V a_1 = v_s_2420; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2415); r_; });
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2416, v_t_2421));
    } else {
      heff_drop(v_x_2415);
      heff_drop(v_field_2419);
      return v_c_2416;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  V v_file_245 = heff_env(self)[2];
  V v_failed_241 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_done_2412 = heff_env(self)[6];
  V v_l_242 = heff_env(self)[7];
  V v_hashes_2413 = heff_env(self)[8];
  V v_e_240 = heff_env(self)[9];
  V v_name_243 = heff_env(self)[10];
  V v_outPath_244 = heff_env(self)[11];
  V v_done_246 = heff_env(self)[12];
  heff_clo_take(self, 13);
  heff_drop(v_x_2423);
  if (heff_intLt_c(MK_INT(0LL), v_x_249)) {
    heff_drop(v_done_2412);
    heff_drop_rec(v_l_242, 5);
    heff_drop(v_hashes_2413);
    heff_drop(v_e_240);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_246);
    HeffT2 v_t_2424 = ({ V a_0 = v_x_2422; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(a_0)); heff_drop(v_x_2422); r_; });
    V v_t_2428;
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      if ((v_tag_2425 == ((int64_t)0ULL))) {
        heff_drop(v_file_245);
        V v_x_2427 = v_field_2426;
        v_t_2428 = v_x_2427;
      } else {
        heff_drop(v_field_2426);
        v_t_2428 = heff_strAppend(v_file_245, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_str3));
      }
    }
    V f_ = v_failed_241;
    heff_room[0] = v_t_2428;
    heff_room[1] = v_hd_247;
    heff_room[2] = v_k_248;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    V v_t_2429 = (g_list_2eany_24s1740858080x874135214(v_x_2422));
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop(v_done_2412);
      heff_drop_rec(v_l_242, 5);
      heff_drop(v_hashes_2413);
      heff_drop(v_e_240);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_246);
      heff_drop(v_t_2429);
      HeffT2 v_t_2430 = ({ V a_0 = v_x_2422; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(a_0)); heff_drop(v_x_2422); r_; });
      V v_t_2434;
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          heff_drop(v_file_245);
          V v_x_2433 = v_field_2432;
          v_t_2434 = v_x_2433;
        } else {
          heff_drop(v_field_2432);
          v_t_2434 = heff_strAppend(v_file_245, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_str4));
        }
      }
      V f_ = v_failed_241;
      heff_room[0] = v_t_2434;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    } else {
      heff_drop(v_t_2429);
      V v_t_2435 = (g_list_2emap_24s1698496827x1884878103(v_done_2412));
      V v_t_2436 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_l_242, 2), v_hashes_2413, v_t_2435});
      return ({ V a_0 = v_e_240; V a_1 = v_t_2436; V a_2 = heff_get_n(v_l_242, 0, 5); V a_3 = v_file_245; V a_4 = v_name_243; V a_5 = v_outPath_244; V a_6 = v_failed_241; V a_7 = v_done_246; V a_8 = v_x_2422; V a_9 = v_hd_247; V a_10 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLastC_24s1999958868x273665393(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_x_2422); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_file_245 = heff_env(self)[4];
  V v_failed_241 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_done_2412 = heff_take_field(v_x_2411, 0);
  V v_hashes_2413 = heff_get_n(v_x_2411, 1, 2);
  V v_sources_2414 = heff_dup(heff_rfield(v_l_242, 0));
  V v_x_2415 = (g_list_2emap_24f1524014098x1956473147(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_str2), heff_dup(v_sources_2414)));
  V v_x_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_lam2, 1, 2, (V[]){v_sources_2414, v_x_2415}), heff_dup(v_done_2412)));
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(heff_dup(v_e_240), heff_dup(v_x_2422), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_lam3, 1, 13, (V[]){v_x_249, v_x_2422, v_file_245, v_failed_241, v_hd_247, v_k_248, v_done_2412, v_l_242, v_hashes_2413, v_e_240, v_name_243, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_l_242 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_file_245 = heff_env(self)[3];
  V v_failed_241 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_name_243 = heff_env(self)[6];
  V v_outPath_244 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2410 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_240), heff_dup(v_l_242)));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_lam1, 1, 10, (V[]){v_l_242, v_e_240, v_hd_247, v_x_249, v_file_245, v_failed_241, v_k_248, v_name_243, v_outPath_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str1, 11, ".provider.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str2, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str3, 12, ".provider.js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str4, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str5, 12, ".provider.js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam5, 3, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853(V v_e_240, V v_host_241, V v_s_242) {
top: ;
  V v_p_243 = heff_dup(heff_rfield(v_s_242, 2));
  int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_p_243, 0)) - ((int64_t)3ULL));
  V v_t_245 = heff_strSlice(heff_dup(v_p_243), heff_box_word(v_t_244), heff_strLength_lent(v_p_243, 0));
  V v_t_247;
  if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str0))) {
    int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_p_243, 0)) - ((int64_t)3ULL));
    v_t_247 = heff_strSlice(v_p_243, MK_INT(0LL), heff_box_word(v_t_246));
  } else {
    v_t_247 = v_p_243;
  }
  V v_s_248 = heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str1));
  V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_248));
  V v_c_2410 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_249; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_249); r_; });
  V v_t_2411 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2415 = heff_tr(heff_call(v_c_2410, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam1, 2, 4, (V[]){v_c_2415, v_s_242, v_e_240, heff_dup(v_host_241)});
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_2413 = args[1];
  V v_k_2414 = args[2];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2430 = args[1];
  V v_k_2431 = args[2];
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    heff_take_n(v_x_2433, 0ULL, 1);
    V f_ = v_k_2417;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2433, 0ULL, 1);
    V f_ = v_k_2417;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam5(V self, V *args) {
  V v_x_2446 = args[0];
  V v_hd_2447 = args[1];
  V v_k_2448 = args[2];
  heff_drop(v_hd_2447);
  V f_ = v_k_2448;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2446});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam6(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_host_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2450)) {
  case TAG_Left: {
    heff_take_n(v_x_2450, 0ULL, 1);
    heff_drop(v_host_241);
    V f_ = v_k_2417;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2452 = heff_field(v_x_2450, 0);
    heff_take_n(v_x_2450, 1ULL, 1);
    V v_t_2453 = ({ V a_0 = v_y_2452; V b_1 = ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str6); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str7), v_y_2452, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_y_2452); heff_drop(b_1); r_; });
    V v_t_2454 = (g_list_2emap_24s649333309x1802289391(v_t_2453));
    V v_x1_2455 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2454));
    V v_t_2458;
    switch (heff_tag_of(v_x1_2455)) {
    case TAG_Nil: {
      heff_drop(v_host_241);
      v_t_2458 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x_2456 = heff_field(v_x1_2455, 0);
      heff_take_n(v_x1_2455, 1ULL, 2);
      v_t_2458 = heff_bool(!heff_strEq_c_lent(v_x_2456, v_host_241, 0));
      heff_drop(v_host_241);
      heff_drop(v_x_2456);
      break;
    }
    default: heff_nomatch(v_x1_2455);
    }
    V f_ = v_k_2417;
    args[0] = v_t_2458;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2450);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_s_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2416 = heff_env(self)[2];
  V v_k_2417 = heff_env(self)[3];
  V v_host_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    heff_take_n(v_x_2418, 0ULL, 1);
    heff_drop(v_host_241);
    V v_p_2420 = heff_get_n(v_s_242, 2, 8);
    int64_t v_t_2421 = (heff_unbox_word(heff_strLength_lent(v_p_2420, 0)) - ((int64_t)3ULL));
    V v_t_2422 = heff_strSlice(heff_dup(v_p_2420), heff_box_word(v_t_2421), heff_strLength_lent(v_p_2420, 0));
    V v_t_2424;
    if (heff_strEq_c(v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str2))) {
      int64_t v_t_2423 = (heff_unbox_word(heff_strLength_lent(v_p_2420, 0)) - ((int64_t)3ULL));
      v_t_2424 = heff_strSlice(v_p_2420, MK_INT(0LL), heff_box_word(v_t_2423));
    } else {
      v_t_2424 = v_p_2420;
    }
    V v_s_2425 = heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str3));
    V v_path_2426 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2425));
    V v_c_2427 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2426; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2426); r_; });
    V v_t_2428 = (g_exception_2eattempted(v_e_240));
    V v_c_2432 = heff_tr(heff_call(v_c_2427, 2, (V[]){v_t_2428, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam3_clo)}));
    V f_ = v_c_2432;
    heff_room[0] = v_hd_2416;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam4, 1, 1, (V[]){v_k_2417});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2418, 0ULL, 1);
    V v_p_2437 = heff_get_n(v_s_242, 2, 8);
    int64_t v_t_2438 = (heff_unbox_word(heff_strLength_lent(v_p_2437, 0)) - ((int64_t)3ULL));
    V v_t_2439 = heff_strSlice(heff_dup(v_p_2437), heff_box_word(v_t_2438), heff_strLength_lent(v_p_2437, 0));
    V v_t_2441;
    if (heff_strEq_c(v_t_2439, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str4))) {
      int64_t v_t_2440 = (heff_unbox_word(heff_strLength_lent(v_p_2437, 0)) - ((int64_t)3ULL));
      v_t_2441 = heff_strSlice(v_p_2437, MK_INT(0LL), heff_box_word(v_t_2440));
    } else {
      v_t_2441 = v_p_2437;
    }
    V v_s_2442 = heff_strAppend(v_t_2441, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_str5));
    V v_path_2443 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2442));
    V v_c_2444 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2443; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2443); r_; });
    V v_t_2445 = (g_exception_2eattempted(v_e_240));
    V v_c_2449 = heff_tr(heff_call(v_c_2444, 2, (V[]){v_t_2445, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam5_clo)}));
    V f_ = v_c_2449;
    heff_room[0] = v_hd_2416;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam6, 1, 2, (V[]){v_k_2417, v_host_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_s_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_host_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_lam2, 1, 5, (V[]){v_s_242, v_e_240, v_hd_2416, v_k_2417, v_host_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_str0, 3, "esm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_str1, 70, "heff compile: an ES module runs nothing: no --name with --backend=esm\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_str2, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_str3, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_str4, 25, "heff compile: no backend ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_str5, 16, ": esm, page or c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291(V v_e_240, V v_o_241, V v_p_242, V v_p_243) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_o_241, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_str0))) {
    V v_t_244 = heff_dup(heff_rfield(v_o_241, 2));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897(v_e_240, v_o_241, v_p_242, v_p_243);
    }
    case TAG_Just: {
      V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_o_241, 4);
      V v_t_246 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_str1), NTAG(TAG_MkUnit)});
      V v_t_247 = heff_tag_at_n(v_ru_24t_244_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
      V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
      V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
      HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_lam0, 1, 3, (V[]){v_e_240, v_p_242, v_p_243}));
    }
    default: return heff_nomatch(v_t_244);
    }
  } else {
    if ((heff_strEq_c(heff_dup(heff_rfield(v_o_241, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_str2)) || heff_strEq_c(heff_dup(heff_rfield(v_o_241, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_str3)))) {
      HEFF_LAST return g_heff_2ebuild_2ecommands_2ecompileThere_24s98588414x1503746897(v_e_240, v_o_241, v_p_242, v_p_243);
    } else {
      V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_str4), heff_get_n(v_o_241, 3, 4));
      V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_str5)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_str6));
      V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2422, NTAG(TAG_MkUnit)});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
      HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_lam1, 1, 3, (V[]){v_e_240, v_p_242, v_p_243}));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2413);
  V v_t_2414 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_p_242, v_p_243));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_lam1(V self, V *args) {
  V v_x_2430 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_p_242, v_p_243));
}
Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673(V v_e_240, V v_st_241, V v_t_242, V v_home_243, V v_sh_244, V v_next_245, V v_x6_246) {
top: ;
  switch (heff_tag_of(v_x6_246)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    heff_drop(v_t_242);
    heff_drop(v_home_243);
    heff_drop(v_sh_244);
    return v_next_245;
  }
  case TAG_Cons: {
    V v_n_247 = heff_field(v_x6_246, 0);
    V v_rest_248 = heff_field(v_x6_246, 1);
    V v_t_249 = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_t_242), heff_dup(v_home_243), heff_dup(v_sh_244), v_next_245, v_rest_248));
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_clo), 7, (V[]){v_e_240, v_st_241, v_t_242, v_home_243, v_sh_244, v_t_249, heff_dup(v_n_247)});
  }
  default: return heff_nomatch(v_x6_246);
  }
}
V g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673(a[0], a[1], a[2], a[3], a[4], a[5], a6); heff_drop(a6); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str0, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str2, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str3, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str4, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str6, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str7, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082(V v_e_240, V v_st_241, V v_t_242, V v_home_243, V v_dir_244, V v_next_245, V v_hd_246, V v_k_247) {
top: ;
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502(heff_dup(v_e_240), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam0, 1, 8, (V[]){v_st_241, v_home_243, v_dir_244, v_e_240, v_hd_246, v_k_247, v_t_242, v_next_245})));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2423 = args[1];
  V v_k_2424 = args[2];
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam3(V self, V *args) {
  V v_x_2441 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam4(V self, V *args) {
  V v_x_2463 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2463);
  V f_ = v_next_245;
  heff_room[0] = v_hd_246;
  heff_room[1] = v_k_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    V v_ru_24x_2426_24Left = heff_take_reuse_n(v_x_2426, 0ULL, 1);
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_next_245);
    V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_home_243));
    V v_t_2429 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str2)));
    V v_t_2430 = (g_std_2epath_2ejoin(v_t_2428, v_t_2429));
    V v_t_2431 = ({ V a_0 = v_st_241; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2430); r_; });
    V v_why_2432 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str3), v_t_2431);
    V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str4), v_why_2432), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str5));
    V v_t_2434 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2433, NTAG(TAG_MkUnit)});
    V v_t_2435 = heff_tag_at_n(v_ru_24x_2426_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam3, 1, 3, (V[]){v_e_240, v_hd_246, v_k_247})));
  }
  case TAG_Right: {
    V v_ru_24x_2426_24Right = heff_take_reuse_n(v_x_2426, 0ULL, 1);
    V v_t_2450 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_home_243));
    V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str6)));
    V v_t_2452 = (g_std_2epath_2ejoin(v_t_2450, v_t_2451));
    V v_path_2453 = ({ V a_0 = v_st_241; V a_1 = v_t_2452; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2452); r_; });
    V v_t_2454 = heff_strAppend(heff_get_n(v_t_242, 2, 6), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str7));
    V v_t_2455 = heff_strAppend(heff_strAppend(v_t_2454, v_path_2453), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str8));
    V v_t_2456 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2455, NTAG(TAG_MkUnit)});
    V v_t_2457 = heff_tag_at_n(v_ru_24x_2426_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2462}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam4, 1, 3, (V[]){v_next_245, v_hd_246, v_k_247})));
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_dir_244 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  V v_next_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_home_243)));
  V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str0)));
  V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
  V v_s_2412 = ({ V a_0 = v_st_241; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V v_path_2413 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2412));
  V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_x_248));
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_dir_244));
  V v_t_2416 = (g_std_2epath_2ejoin(v_t_2414, v_t_2415));
  V v_t_2417 = ({ V a_0 = v_st_241; V a_1 = v_t_2416; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2416); r_; });
  V v_t_2418 = (g_heff_2eutil_2ehostpath_2enormalize(heff_dup(v_st_241), v_t_2417));
  V v_text_2419 = heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_str1));
  V v_c_2420 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2413; V a_2 = v_text_2419; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2413); r_; });
  V v_t_2421 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2425 = heff_tr(heff_call(v_c_2420, 2, (V[]){v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam1_clo)}));
  V f_ = v_c_2425;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_lam2, 1, 7, (V[]){v_st_241, v_home_243, v_e_240, v_hd_246, v_k_247, v_t_242, v_next_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str2, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str3, 9, "installed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str4, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str5, 31, "heff install: no package.hf in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str7, 7, "install");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str8, 29, "heff install: no programs in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str9, 41, ": app/X/ with a build.hf is the program X");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646(V v_e_240, V v_dir_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2411, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam1, 1, 4, (V[]){v_e_240, v_hd_242, v_dir_241, v_k_243}));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2423 = args[1];
  V v_k_2424 = args[2];
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam5(V self, V *args) {
  V v_x_2443 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2443);
  V v_t_2444 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam7(V self, V *args) {
  V v_x_2475 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2465 = heff_env(self)[1];
  V v_k_2466 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2475);
  V v_t_2476 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2482}), v_hd_2465, v_k_2466));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam6(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k_2466 = args[1];
  V v_dir_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2467 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str8), v_dir_241), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str9));
  V v_t_2468 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2467, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str10)), NTAG(TAG_MkUnit)});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2474}), heff_dup(v_hd_2465), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam7, 1, 3, (V[]){v_e_240, v_hd_2465, v_k_2466})));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_st_2413 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  V v_k_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2429;
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    heff_take_n(v_x_2426, 0ULL, 1);
    v_x_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2428 = heff_field(v_x_2426, 0);
    V v_ru_24x_2426_24Right = heff_take_reuse_n(v_x_2426, 1ULL, 1);
    v_x_2429 = heff_tag_at_n(v_ru_24x_2426_24Right, TAG_Just, 1, (V[]){v_y_2428});
    break;
  }
  default: heff_nomatch(v_x_2426);
  }
  V v_t_2430 = (g_std_2epath_2eparse(heff_dup(v_st_2413), heff_dup(v_x_2414)));
  V v_t_2431 = (g_std_2epath_2eparse(heff_dup(v_st_2413), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str2)));
  V v_t_2432 = (g_std_2epath_2ejoin(v_t_2430, v_t_2431));
  V v_t_2433 = ({ V a_0 = v_st_2413; V a_1 = v_t_2432; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2432); r_; });
  V v_x_2434 = heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){heff_dup(v_dir_241), v_t_2433, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str3), NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2414)}), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str4)});
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Nothing: {
    heff_drop(v_st_2413);
    heff_drop(v_x_2414);
    heff_drop_rec(v_x_2434, 6);
    V v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str5), v_dir_241), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str6));
    V v_t_2436 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2435, NTAG(TAG_MkUnit)});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam5, 1, 3, (V[]){v_e_240, v_hd_242, v_k_243})));
  }
  case TAG_Just: {
    V v_t_2464;
    switch (heff_tag_of(v_x_2429)) {
    case TAG_Nothing: {
      heff_drop(v_x_2414);
      v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_clo), 3, (V[]){heff_dup(v_e_240), heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2434, 1))}));
      break;
    }
    case TAG_Just: {
      V v_text_2452 = heff_field(v_x_2429, 0);
      heff_take_n(v_x_2429, 1ULL, 1);
      HeffT2 v_t_2453 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_text_2452));
      {
        V v_field_2455 = v_t_2453.f[1];
        int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
        if ((v_tag_2454 == ((int64_t)0ULL))) {
          heff_drop(v_x_2414);
          V v_p_2456 = v_field_2455;
          heff_drop(v_p_2456);
          v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_clo), 3, (V[]){heff_dup(v_e_240), heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2434, 1))}));
        } else {
          V v_x_2457 = v_field_2455;
          HeffT2 v_t_2458 = ({ V a_0 = v_x_2457; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2457); r_; });
          {
            V v_field_2460 = v_t_2458.f[1];
            int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
            if ((v_tag_2459 == ((int64_t)0ULL))) {
              heff_drop(v_x_2414);
              V v_x11_2461 = v_field_2460;
              heff_drop(v_x11_2461);
              v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_clo), 3, (V[]){heff_dup(v_e_240), heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2434, 1))}));
            } else {
              V v_pk_2462 = v_field_2460;
              if (heff_strEq_c(heff_get_n(v_pk_2462, 0, 4), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
                V v_t_2463 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_clo), 3, (V[]){heff_dup(v_e_240), heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2434, 1))}));
                v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s911907262x345669082_clo), 6, (V[]){heff_dup(v_e_240), heff_dup(v_st_2413), heff_dup(v_x_2434), v_x_2414, heff_dup(v_dir_241), v_t_2463}));
              } else {
                heff_drop(v_x_2414);
                v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_clo), 3, (V[]){heff_dup(v_e_240), heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2434, 1))}));
              }
            }
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x_2429);
    }
    return (g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077(heff_dup(v_e_240), v_st_2413, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str7), v_x_2434, heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam6, 2, 2, (V[]){v_dir_241, v_e_240}), v_t_2464, v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_st_2413 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_2413), heff_dup(v_dir_241)));
  V v_t_2416 = (g_std_2epath_2eparse(heff_dup(v_st_2413), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str1)));
  V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
  V v_s_2418 = ({ V a_0 = v_st_2413; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_path_2419 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2418));
  V v_c_2420 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2419; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2419); r_; });
  V v_t_2421 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2425 = heff_tr(heff_call(v_c_2420, 2, (V[]){v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam3_clo)}));
  V f_ = v_c_2425;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam4, 1, 6, (V[]){v_st_2413, v_x_2414, v_dir_241, v_e_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2413;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_str0))) {
    v_st_2413 = NTAG(TAG_Windows);
  } else {
    v_st_2413 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879(heff_dup(v_e_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_lam2, 1, 5, (V[]){v_st_2413, v_dir_241, v_e_240, v_hd_242, v_k_243})));
}