// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2edriver_2eimportsOfSource_lam0(V self, V *args);
Clo g_heff_2edriver_2eimportsOfSource_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eimportsOfSource_entry, 1, 0};

V g_heff_2edriver_2eimportsOfSource(V v_s_240) {
top: ;
  V v_imps_241 = (g_heff_2eimport_2eimportsOf(heff_get(heff_dup(v_s_240), LBL_module), heff_get(heff_dup(v_s_240), LBL_source)));
  V v_t_244 = (g_prelude_2emap(heff_clo(g_heff_2edriver_2eimportsOfSource_lam0, 1, 1, (V[]){v_s_240}), heff_get(heff_dup(v_imps_241), LBL_imports)));
  return heff_rec(2, shape_130_321, (V[]){v_t_244, heff_get(v_imps_241, LBL_text)});
}
V g_heff_2edriver_2eimportsOfSource_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eimportsOfSource(a[0]);
}
V g_heff_2edriver_2eimportsOfSource_lam0(V self, V *args) {
  V v_i_242 = args[0];
  V v_s_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_name_243 = ({ V b_0 = heff_get(v_s_240, LBL_renames); V a_1 = heff_get(heff_dup(v_i_242), LBL_name); V r_ = (g_heff_2eimport_2erenameTo(b_0, a_1)); heff_drop(b_0); r_; });
  return heff_rec(3, shape_190_3_299, (V[]){v_name_243, heff_get(heff_dup(v_i_242), LBL_alias), heff_get(v_i_242, LBL_span)});
}
Clo g_heff_2edriver_2eappendD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eappendD_entry, 2, 0};

V g_heff_2edriver_2eappendD(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2edriver_2eappendD(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2eappendD_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eappendD(a[0], a[1]);
}
V g_heff_2edriver_2enubStrD_lam0(V self, V *args);
Clo g_heff_2edriver_2enubStrD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2enubStrD_entry, 1, 0};

V g_heff_2edriver_2enubStrD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2edriver_2enubStrD_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2edriver_2enubStrD(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2enubStrD_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2enubStrD(a[0]);
}
V g_heff_2edriver_2enubStrD_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = heff_strEq(v_y_243, v_x_241);
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_t_244);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
Clo g_heff_2edriver_2efindChecked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2efindChecked_entry, 2, 0};

V g_heff_2edriver_2efindChecked(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_m_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_strEq(heff_get(heff_dup(v_c_242), LBL_module), heff_dup(v_m_241));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_m_241);
      heff_drop(v_t_244);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_c_242)});
    }
    case TAG_False: {
      heff_drop(v_t_244);
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2efindChecked_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2efindChecked(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2edriver_2eclosureGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eclosureGo_entry, 3, 0};

V g_heff_2edriver_2eclosureGo(V v_done_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x3_242);
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x3_242, 0);
    V v_ms_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse(v_x3_242, 3ULL);
    V v_t_245 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_m_243)}));
    V v_t_246 = (g_prelude_2eany(v_t_245, v_seen_241));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_m_243);
      heff_drop(v_ru_24x3_242_24Cons);
      heff_drop(v_t_246);
      V t_0 = v_done_240;
      V t_1 = v_seen_241;
      V t_2 = v_ms_244;
      v_done_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_t_246);
      V v_t_247 = (g_heff_2edriver_2efindChecked(v_done_240, heff_dup(v_m_243)));
      V v_t_249;
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        heff_drop(v_t_247);
        v_t_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_c_248 = heff_field(v_t_247, 0);
        heff_take(v_t_247, 1ULL);
        v_t_249 = heff_get(v_c_248, LBL_deps);
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      V v_t_2410 = (g_heff_2edriver_2eappendD(v_ms_244, v_t_249));
      V t_0 = v_done_240;
      V t_1 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_m_243, v_seen_241});
      V t_2 = v_t_2410;
      v_done_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2edriver_2eclosureGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eclosureGo(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eenvOne_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {35}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2edriver_2eenvOne_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {35, 84}};
V g_heff_2edriver_2eenvOne_lam0(V self, V *args);
Clo g_heff_2edriver_2eenvOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eenvOne_entry, 2, 0};

V g_heff_2edriver_2eenvOne(V v_c_240, V v_g_241) {
top: ;
  V v_k_242 = heff_strAppend(heff_get(heff_dup(v_c_240), LBL_module), ((V)&g_heff_2edriver_2eenvOne_str0));
  V v_k_243 = heff_strAppend(heff_get(heff_dup(v_c_240), LBL_module), ((V)&g_heff_2edriver_2eenvOne_str1));
  V v_t_244 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_globals);
  V v_t_245 = ({ V b_0 = heff_get(v_t_244, LBL_broken); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_246 = (g_prelude_2emap_24s5(v_t_245));
  V v_t_247 = ({ V a_0 = v_g_241; V a_1 = v_t_246; V r_ = (g_prelude_2efoldl_24s496(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_g_2414 = ({ V a_0 = heff_clo(g_heff_2edriver_2eenvOne_lam0, 2, 1, (V[]){heff_dup(v_c_240)}); V a_1 = v_t_247; V b_2 = heff_get(heff_dup(v_c_240), LBL_own); V r_ = (g_prelude_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2415 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_globals);
  V v_t_2416 = (g_heff_2eglobals_2elookupEntry(v_t_2415, heff_dup(v_k_243)));
  V v_g_2418;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Nothing: {
    heff_drop(v_k_243);
    heff_drop(v_t_2416);
    v_g_2418 = v_g_2414;
    break;
  }
  case TAG_Just: {
    V v_e_2417 = heff_field(v_t_2416, 0);
    heff_take(v_t_2416, 1ULL);
    v_g_2418 = (g_heff_2eglobals_2eaddEntry(v_k_243, v_e_2417, v_g_2414));
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_t_2419 = heff_get(heff_get(v_c_240, LBL_top), LBL_globals);
  V v_t_2420 = (g_heff_2eglobals_2elookupEntry(v_t_2419, heff_dup(v_k_242)));
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Nothing: {
    heff_drop(v_k_242);
    heff_drop(v_t_2420);
    return v_g_2418;
  }
  case TAG_Just: {
    V v_e_2421 = heff_field(v_t_2420, 0);
    heff_take(v_t_2420, 1ULL);
    return (g_heff_2eglobals_2eaddEntry(v_k_242, v_e_2421, v_g_2418));
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2edriver_2eenvOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eenvOne(a[0], a[1]);
}
V g_heff_2edriver_2eenvOne_lam0(V self, V *args) {
  V v_g2_248 = args[0];
  V v_o_249 = args[1];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_k_2410 = heff_get(v_o_249, LBL_key);
  V v_t_2411 = heff_get(heff_get(v_c_240, LBL_top), LBL_globals);
  V v_t_2412 = (g_heff_2eglobals_2elookupEntry(v_t_2411, heff_dup(v_k_2410)));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    heff_drop(v_k_2410);
    heff_drop(v_t_2412);
    return v_g2_248;
  }
  case TAG_Just: {
    V v_e_2413 = heff_field(v_t_2412, 0);
    heff_take(v_t_2412, 1ULL);
    return (g_heff_2eglobals_2eaddEntry(v_k_2410, v_e_2413, v_g2_248));
  }
  default: return heff_nomatch(v_t_2412);
  }
}
Clo g_heff_2edriver_2ecatMaybesD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ecatMaybesD_entry, 1, 0};

V g_heff_2edriver_2ecatMaybesD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_x11_241);
      heff_drop(v_ru_24x1_240_24Cons);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take(v_x11_241, 1ULL);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2edriver_2ecatMaybesD(v_xs_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2ecatMaybesD_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2ecatMaybesD(a[0]);
}
Clo g_heff_2edriver_2eanyD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eanyD_entry, 2, 0};

V g_heff_2edriver_2eanyD(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2edriver_2eanyD_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eanyD(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2edriver_2ewithoutGiven_lam1(V self, V *args);
V g_heff_2edriver_2ewithoutGiven_lam0(V self, V *args);
Clo g_heff_2edriver_2ewithoutGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ewithoutGiven_entry, 1, 0};

V g_heff_2edriver_2ewithoutGiven(V v_all_240) {
top: ;
  return (g_prelude_2efilter(heff_clo(g_heff_2edriver_2ewithoutGiven_lam0, 1, 1, (V[]){heff_dup(v_all_240)}), v_all_240));
}
V g_heff_2edriver_2ewithoutGiven_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2ewithoutGiven(a[0]);
}
V g_heff_2edriver_2ewithoutGiven_lam1(V self, V *args) {
  V v_p_243 = args[0];
  V v_o_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = heff_strEq(heff_get(heff_dup(v_p_243), LBL_name), heff_get(v_o_241, LBL_name));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    V v_t_245 = heff_strEq(heff_get(v_p_243, LBL_module), heff_dup(g_heff_2eimport_2ebuiltinModule_get()));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_245);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_False: {
    heff_drop(v_p_243);
    heff_drop(v_t_244);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2edriver_2ewithoutGiven_lam0(V self, V *args) {
  V v_o_241 = args[0];
  V v_all_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_242 = heff_strEq(heff_get(heff_dup(v_o_241), LBL_module), heff_dup(g_heff_2eimport_2ebuiltinModule_get()));
  V v_x1_246;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_t_242);
    v_x1_246 = ({ V a_0 = heff_clo(g_heff_2edriver_2ewithoutGiven_lam1, 1, 1, (V[]){v_o_241}); V a_1 = v_all_240; V r_ = (g_heff_2edriver_2eanyD(a_0, a_1)); heff_drop(v_all_240); r_; });
    break;
  }
  case TAG_False: {
    heff_drop(v_o_241);
    heff_drop(v_all_240);
    heff_drop(v_t_242);
    v_x1_246 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  switch (heff_tag_of(v_x1_246)) {
  case TAG_True: {
    heff_drop(v_x1_246);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_x1_246);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2edriver_2econcatMapD_24s498_lam0(V self, V *args);
Clo g_heff_2edriver_2econcatMapD_24s498_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2econcatMapD_24s498_entry, 1, 0};

V g_heff_2edriver_2econcatMapD_24s498(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_prelude_2emap(heff_clo(g_heff_2edriver_2econcatMapD_24s498_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), heff_get(heff_dup(v_x_241), LBL_own)));
    V v_t_245 = (g_heff_2edriver_2econcatMapD_24s498(v_xs_242));
    return (g_heff_2edriver_2eappendD(v_t_244, v_t_245));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2edriver_2econcatMapD_24s498_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2econcatMapD_24s498(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2edriver_2econcatMapD_24s498_lam0(V self, V *args) {
  V v_o_243 = args[0];
  V v_x_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_rec(3, shape_190_145_184, (V[]){heff_get(heff_dup(v_o_243), LBL_name), heff_get(v_o_243, LBL_key), heff_get(v_x_241, LBL_module)});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2ebrokenIn_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
V g_heff_2edriver_2ebrokenIn_lam0(V self, V *args);
Clo g_heff_2edriver_2ebrokenIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ebrokenIn_entry, 1, 0};

V g_heff_2edriver_2ebrokenIn(V v_c_240) {
top: ;
  V v_t_241 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_globals);
  V v_t_242 = ({ V b_0 = heff_get(v_t_241, LBL_broken); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_243 = (g_prelude_2emap_24s5(v_t_242));
  V v_t_2411 = (g_prelude_2emap(heff_clo(g_heff_2edriver_2ebrokenIn_lam0, 1, 1, (V[]){v_c_240}), v_t_243));
  return (g_heff_2edriver_2ecatMaybesD(v_t_2411));
}
V g_heff_2edriver_2ebrokenIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2ebrokenIn(a[0]);
}
V g_heff_2edriver_2ebrokenIn_lam0(V self, V *args) {
  V v_k_244 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_prefix_245 = heff_strAppend(heff_get(heff_dup(v_c_240), LBL_module), ((V)&g_heff_2edriver_2ebrokenIn_str0));
  V v_t_246 = heff_strSlice(heff_dup(v_k_244), MK_INT(0LL), heff_strLength(heff_dup(v_prefix_245)));
  V v_t_247 = heff_strEq(v_t_246, v_prefix_245);
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_t_247);
    V v_t_248 = heff_strLength(heff_get(heff_dup(v_c_240), LBL_module));
    V v_t_249 = heff_strSlice(heff_dup(v_k_244), heff_intAdd(v_t_248, MK_INT(1LL)), heff_strLength(heff_dup(v_k_244)));
    V v_t_2410 = heff_rec(3, shape_190_145_184, (V[]){v_t_249, v_k_244, heff_get(v_c_240, LBL_module)});
    return heff_tag(TAG_Just, 1, (V[]){v_t_2410});
  }
  case TAG_False: {
    heff_drop(v_k_244);
    heff_drop(v_c_240);
    heff_drop(v_t_247);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2edriver_2enubByName_lam0(V self, V *args);
Clo g_heff_2edriver_2enubByName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2enubByName_entry, 1, 0};

V g_heff_2edriver_2enubByName(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2edriver_2enubByName_lam0, 1, 1, (V[]){heff_dup(v_o_241)}), v_rest_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_o_241, (g_heff_2edriver_2enubByName(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2enubByName_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2enubByName(a[0]);
}
V g_heff_2edriver_2enubByName_lam0(V self, V *args) {
  V v_p_243 = args[0];
  V v_o_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = heff_strEq(heff_get(v_p_243, LBL_name), heff_get(v_o_241, LBL_name));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_t_244);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
Clo g_heff_2edriver_2eclashMap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eclashMap_entry, 2, 0};

V g_heff_2edriver_2eclashMap(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return v_m_240;
  }
  case TAG_Cons: {
    V v_o_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse(v_x2_241, 3ULL);
    V v_it_244 = (g_map_2elookup_24s8(heff_get(heff_dup(v_o_242), LBL_name), v_m_240));
    V v_t_2411;
    switch (heff_tag_of(v_it_244)) {
    case TAG_Nothing: {
      heff_drop(v_it_244);
      V v_t_245 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_o_242), LBL_key), NTAG(TAG_False)});
      v_t_2411 = (g_map_2einsert_24s7(heff_get(v_o_242, LBL_name), v_t_245, v_m_240));
      break;
    }
    case TAG_Just: {
      V v_it1_246 = heff_field(v_it_244, 0);
      heff_take(v_it_244, 1ULL);
      switch (heff_tag_of(v_it1_246)) {
      case TAG_MkPair: {
        V v_k_247 = heff_field(v_it1_246, 0);
        V v_c_248 = heff_field(v_it1_246, 1);
        heff_take(v_it1_246, 3ULL);
        switch (heff_tag_of(v_c_248)) {
        case TAG_True: {
          heff_drop(v_o_242);
          heff_drop(v_ru_24x2_241_24Cons);
          heff_drop(v_k_247);
          heff_drop(v_c_248);
          v_t_2411 = v_m_240;
          break;
        }
        case TAG_False: {
          heff_drop(v_c_248);
          V v_t_249 = heff_strEq(heff_dup(v_k_247), heff_get(heff_dup(v_o_242), LBL_key));
          switch (heff_tag_of(v_t_249)) {
          case TAG_True: {
            heff_drop(v_o_242);
            heff_drop(v_ru_24x2_241_24Cons);
            heff_drop(v_k_247);
            heff_drop(v_t_249);
            v_t_2411 = v_m_240;
            break;
          }
          case TAG_False: {
            heff_drop(v_t_249);
            V v_t_2410 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_k_247, NTAG(TAG_True)});
            v_t_2411 = (g_map_2einsert_24s7(heff_get(v_o_242, LBL_name), v_t_2410, v_m_240));
            break;
          }
          default: heff_nomatch(v_t_249);
          }
          break;
        }
        default: heff_nomatch(v_c_248);
        }
        break;
      }
      default: heff_nomatch(v_it1_246);
      }
      break;
    }
    default: heff_nomatch(v_it_244);
    }
    V t_0 = v_t_2411;
    V t_1 = v_rest_243;
    v_m_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2edriver_2eclashMap_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eclashMap(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2ejoinComma_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2edriver_2ejoinComma_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
Clo g_heff_2edriver_2ejoinComma_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ejoinComma_entry, 1, 0};

V g_heff_2edriver_2ejoinComma(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2edriver_2ejoinComma_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2edriver_2ejoinComma_str1), (g_heff_2edriver_2ejoinComma(v_x12_242))));
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2ejoinComma_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2ejoinComma(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eclashDiag_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2edriver_2eclashDiag_str1 = {{0x80000000u, K_STR, 0}, 47, 47, {96, 32, 105, 115, 32, 100, 101, 102, 105, 110, 101, 100, 32, 98, 121, 32, 109, 111, 114, 101, 32, 116, 104, 97, 110, 32, 111, 110, 101, 32, 109, 111, 100, 117, 108, 101, 32, 105, 109, 112, 111, 114, 116, 101, 100, 58, 32}};
V g_heff_2edriver_2eclashDiag_lam0(V self, V *args);
Clo g_heff_2edriver_2eclashDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eclashDiag_entry, 2, 0};

V g_heff_2edriver_2eclashDiag(V v_imported_240, V v_o_241) {
top: ;
  V v_t_243 = (g_prelude_2efilter(heff_clo(g_heff_2edriver_2eclashDiag_lam0, 1, 1, (V[]){heff_dup(v_o_241)}), v_imported_240));
  V v_t_244 = (g_prelude_2emap_24s499(v_t_243));
  V v_t_245 = (g_heff_2edriver_2enubStrD(v_t_244));
  V v_t_246 = heff_strAppend(((V)&g_heff_2edriver_2eclashDiag_str0), heff_strAppend(heff_get(v_o_241, LBL_name), heff_strAppend(((V)&g_heff_2edriver_2eclashDiag_str1), ({ V a_0 = v_t_245; V r_ = (g_heff_2edriver_2ejoinComma(a_0)); heff_drop(v_t_245); r_; }))));
  return heff_rec(5, shape_44_284_185_299_197, (V[]){MK_INT(330LL), NTAG(TAG_SError), v_t_246, heff_dup(g_heff_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
}
V g_heff_2edriver_2eclashDiag_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eclashDiag(a[0], a[1]);
}
V g_heff_2edriver_2eclashDiag_lam0(V self, V *args) {
  V v_p_242 = args[0];
  V v_o_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_p_242, LBL_name), heff_get(v_o_241, LBL_name));
}
V g_heff_2edriver_2ealiasOpen_lam0(V self, V *args);
Clo g_heff_2edriver_2ealiasOpen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ealiasOpen_entry, 3, 0};

V g_heff_2edriver_2ealiasOpen(V v_clashes_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_g_241;
  }
  case TAG_Cons: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_strEq(heff_get(heff_dup(v_o_243), LBL_key), heff_get(heff_dup(v_o_243), LBL_name));
    V v_t_249;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_245);
      v_t_249 = v_g_241;
      break;
    }
    case TAG_False: {
      heff_drop(v_t_245);
      V v_t_247 = (g_heff_2edriver_2eanyD(heff_clo(g_heff_2edriver_2ealiasOpen_lam0, 1, 1, (V[]){heff_dup(v_o_243)}), v_clashes_240));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_t_247);
        v_t_249 = v_g_241;
        break;
      }
      case TAG_False: {
        heff_drop(v_t_247);
        V v_t_248 = (g_map_2einsert_24s7(heff_get(heff_dup(v_o_243), LBL_name), heff_get(heff_dup(v_o_243), LBL_key), heff_get(heff_dup(v_g_241), LBL_aliases)));
        v_t_249 = heff_rec(4, shape_213_80_4_29, (V[]){heff_get(heff_dup(v_g_241), LBL_order), heff_get(heff_dup(v_g_241), LBL_entries), v_t_248, heff_get(v_g_241, LBL_broken)});
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V t_0 = v_clashes_240;
    V t_1 = v_t_249;
    V t_2 = v_rest_244;
    v_clashes_240 = t_0;
    v_g_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2edriver_2ealiasOpen_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2ealiasOpen(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[2]); return r;
}
V g_heff_2edriver_2ealiasOpen_lam0(V self, V *args) {
  V v_cl_246 = args[0];
  V v_o_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_cl_246, LBL_name), heff_get(v_o_243, LBL_name));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2ealiasQOne_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {35}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2ealiasQOne_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
V g_heff_2edriver_2ealiasQOne_lam0(V self, V *args);
V g_heff_2edriver_2ealiasQOne_lam1(V self, V *args);
Clo g_heff_2edriver_2ealiasQOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ealiasQOne_entry, 3, 0};

V g_heff_2edriver_2ealiasQOne(V v_done_240, V v_g_241, V v_q_242) {
top: ;
  V v_t_243 = (g_heff_2edriver_2efindChecked(v_done_240, heff_get(heff_dup(v_q_242), LBL_module)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_q_242);
    heff_drop(v_t_243);
    return v_g_241;
  }
  case TAG_Just: {
    V v_c_244 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    V v_t_245 = heff_strAppend(heff_get(heff_dup(v_q_242), LBL_module), ((V)&g_heff_2edriver_2ealiasQOne_str0));
    V v_t_246 = (g_map_2einsert_24s7(heff_get(heff_dup(v_q_242), LBL_alias), v_t_245, heff_get(heff_dup(v_g_241), LBL_aliases)));
    V v_t_247 = heff_rec(4, shape_213_80_4_29, (V[]){heff_get(heff_dup(v_g_241), LBL_order), heff_get(heff_dup(v_g_241), LBL_entries), v_t_246, heff_get(v_g_241, LBL_broken)});
    V v_t_249 = (g_prelude_2emap(heff_clo(g_heff_2edriver_2ealiasQOne_lam0, 1, 1, (V[]){heff_dup(v_c_244)}), heff_get(heff_dup(v_c_244), LBL_own)));
    V v_t_2410 = (g_heff_2edriver_2ebrokenIn(v_c_244));
    V v_t_2411 = (g_heff_2edriver_2eappendD(v_t_249, v_t_2410));
    return ({ V a_0 = heff_clo(g_heff_2edriver_2ealiasQOne_lam1, 2, 1, (V[]){v_q_242}); V a_1 = v_t_247; V a_2 = v_t_2411; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2edriver_2ealiasQOne_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2ealiasQOne(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2edriver_2ealiasQOne_lam0(V self, V *args) {
  V v_o_248 = args[0];
  V v_c_244 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_rec(3, shape_190_145_184, (V[]){heff_get(heff_dup(v_o_248), LBL_name), heff_get(v_o_248, LBL_key), heff_get(v_c_244, LBL_module)});
}
V g_heff_2edriver_2ealiasQOne_lam1(V self, V *args) {
  V v_g2_2412 = args[0];
  V v_o_2413 = args[1];
  V v_q_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2414 = heff_strAppend(heff_get(v_q_242, LBL_alias), heff_strAppend(((V)&g_heff_2edriver_2ealiasQOne_str1), heff_get(heff_dup(v_o_2413), LBL_name)));
  V v_t_2415 = (g_map_2einsert_24s7(v_t_2414, heff_get(v_o_2413, LBL_key), heff_get(heff_dup(v_g2_2412), LBL_aliases)));
  return heff_rec(4, shape_213_80_4_29, (V[]){heff_get(heff_dup(v_g2_2412), LBL_order), heff_get(heff_dup(v_g2_2412), LBL_entries), v_t_2415, heff_get(v_g2_2412, LBL_broken)});
}
Clo g_heff_2edriver_2ealiasQualified_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ealiasQualified_entry, 3, 0};

V g_heff_2edriver_2ealiasQualified(V v_done_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_g_241;
  }
  case TAG_Cons: {
    V v_q_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2edriver_2ealiasQOne(v_done_240, v_g_241, heff_dup(v_q_243)));
    V t_0 = v_done_240;
    V t_1 = v_t_245;
    V t_2 = v_rest_244;
    v_done_240 = t_0;
    v_g_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2edriver_2ealiasQualified_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2ealiasQualified(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[2]); return r;
}
Clo g_heff_2edriver_2ewithParseBroken_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ewithParseBroken_entry, 3, 0};

V g_heff_2edriver_2ewithParseBroken(V v_key_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_key_240);
    return v_g_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_k_245 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_dup(v_x_243)}));
    V v_key_246 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_dup(v_x_243)}));
    V v_t_247 = (g_map_2einsert_24s7(heff_dup(v_x_243), v_key_246, heff_get(heff_dup(v_g_241), LBL_aliases)));
    V v_g_248 = heff_rec(4, shape_213_80_4_29, (V[]){heff_get(heff_dup(v_g_241), LBL_order), heff_get(heff_dup(v_g_241), LBL_entries), v_t_247, heff_get(v_g_241, LBL_broken)});
    V v_t_249 = (g_map_2einsert_24s7(v_k_245, NTAG(TAG_MkUnit), heff_get(heff_dup(v_g_248), LBL_broken)));
    V v_t_2410 = heff_rec(4, shape_213_80_4_29, (V[]){heff_get(heff_dup(v_g_248), LBL_order), heff_get(heff_dup(v_g_248), LBL_entries), heff_get(v_g_248, LBL_aliases), v_t_249});
    V t_0 = v_key_240;
    V t_1 = v_t_2410;
    V t_2 = v_rest_244;
    v_key_240 = t_0;
    v_g_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2edriver_2ewithParseBroken_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2ewithParseBroken(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eownOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
V g_heff_2edriver_2eownOf_lam0(V self, V *args);
Clo g_heff_2edriver_2eownOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eownOf_entry, 2, 0};

V g_heff_2edriver_2eownOf(V v_modName_240, V v_keys_241) {
top: ;
  return (g_prelude_2emap(heff_clo(g_heff_2edriver_2eownOf_lam0, 1, 1, (V[]){v_modName_240}), v_keys_241));
}
V g_heff_2edriver_2eownOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eownOf(a[0], a[1]);
}
V g_heff_2edriver_2eownOf_lam0(V self, V *args) {
  V v_k_242 = args[0];
  V v_modName_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_prefix_243 = heff_strAppend(heff_dup(v_modName_240), ((V)&g_heff_2edriver_2eownOf_str0));
  V v_t_244 = heff_strSlice(heff_dup(v_k_242), MK_INT(0LL), heff_strLength(heff_dup(v_prefix_243)));
  V v_t_245 = heff_strEq(v_t_244, v_prefix_243);
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_t_245);
    V v_t_246 = heff_intAdd(heff_strLength(v_modName_240), MK_INT(1LL));
    V v_t_247 = heff_strSlice(heff_dup(v_k_242), v_t_246, heff_strLength(heff_dup(v_k_242)));
    return heff_rec(2, shape_190_145, (V[]){v_t_247, v_k_242});
  }
  case TAG_False: {
    heff_drop(v_modName_240);
    heff_drop(v_t_245);
    return heff_rec(2, shape_190_145, (V[]){heff_dup(v_k_242), v_k_242});
  }
  default: return heff_nomatch(v_t_245);
  }
}
Clo g_heff_2edriver_2eopenNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eopenNames_entry, 1, 0};

V g_heff_2edriver_2eopenNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_243 = heff_get(heff_dup(v_i_241), LBL_alias);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_t_243);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_i_241, LBL_name), (g_heff_2edriver_2eopenNames(v_rest_242))});
    }
    case TAG_Just: {
      heff_take(v_t_243, 0ULL);
      heff_drop(v_i_241);
      heff_drop(v_ru_24x1_240_24Cons);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2eopenNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eopenNames(a[0]);
}
Clo g_heff_2edriver_2ealiasPairs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ealiasPairs_entry, 1, 0};

V g_heff_2edriver_2ealiasPairs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_243 = heff_get(heff_dup(v_i_241), LBL_alias);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_i_241);
      heff_drop(v_ru_24x1_240_24Cons);
      heff_drop(v_t_243);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_a_244 = heff_field(v_t_243, 0);
      heff_take(v_t_243, 1ULL);
      V v_t_245 = heff_rec(2, shape_184_3, (V[]){heff_get(v_i_241, LBL_name), v_a_244});
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_heff_2edriver_2ealiasPairs(v_rest_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2ealiasPairs_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2ealiasPairs(a[0]);
}
Clo g_heff_2edriver_2estructIdxGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2estructIdxGo_entry, 3, 0};

V g_heff_2edriver_2estructIdxGo(V v_i_240, V v_x2_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return v_m_242;
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_map_2einsert_24s7(heff_get(heff_dup(v_r_243), LBL_key), heff_dup(v_i_240), v_m_242));
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_rest_244;
    V t_2 = v_t_245;
    v_i_240 = t_0;
    v_x2_241 = t_1;
    v_m_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2edriver_2estructIdxGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2estructIdxGo(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
Clo g_heff_2edriver_2ecloseFieldsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ecloseFieldsGo_entry, 5, 0};

V g_heff_2edriver_2ecloseFieldsGo(V v_r_240, V v_i_241, V v_depth_242, V v_j_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    heff_drop(v_i_241);
    heff_drop(v_depth_242);
    heff_drop(v_j_243);
    heff_drop(v_x5_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse(v_x5_244, 3ULL);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x51_245, 0);
      V v_t_248 = heff_field(v_x51_245, 1);
      heff_take(v_x51_245, 3ULL);
      V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 3, (V[]){heff_dup(v_i_241), heff_intAdd(heff_dup(v_depth_242), heff_dup(v_j_243)), v_t_248}));
      return heff_tag_at(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_247, v_t_249}), (g_heff_2edriver_2ecloseFieldsGo(v_r_240, v_i_241, v_depth_242, heff_intAdd(v_j_243, MK_INT(1LL)), v_rest_246))});
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2edriver_2ecloseFieldsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2ecloseFieldsGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2edriver_2ecloseTypeF_lam1(V self, V *args);
V g_heff_2edriver_2ecloseTypeF_lam0(V self, V *args);
Clo g_heff_2edriver_2ecloseTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ecloseTypeF_entry, 5, 0};

V g_heff_2edriver_2ecloseTypeF(V v_r_240, V v_idx_241, V v_i_242, V v_depth_243, V v_t_244) {
top: ;
  switch (heff_tag_of(v_t_244)) {
  case TAG_SU: {
    heff_drop(v_r_240);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SDecode: {
    V v_e_246 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SDecode = heff_take_reuse(v_t_244, 1ULL);
    V v_t_247 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 3, (V[]){v_i_242, v_depth_243, v_e_246}));
    return heff_tag_at(v_ru_24t_244_24SDecode, TAG_SDecode, 1, (V[]){v_t_247});
  }
  case TAG_SFunction: {
    V v_level_248 = heff_field(v_t_244, 0);
    V v_dom_249 = heff_field(v_t_244, 1);
    V v_cod_2410 = heff_field(v_t_244, 2);
    V v_implicit_2411 = heff_field(v_t_244, 3);
    V v_ru_24t_244_24SFunction = heff_take_reuse(v_t_244, 15ULL);
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_dom_249}));
    V v_t_2418;
    switch (heff_tag_of(v_cod_2410)) {
    case TAG_MkAbs: {
      V v_x_2413 = heff_field(v_cod_2410, 0);
      V v_t_2414 = heff_field(v_cod_2410, 1);
      V v_ru_24cod_2410_24MkAbs = heff_take_reuse(v_cod_2410, 3ULL);
      V v_t_2415 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, MK_INT(1LL)), v_t_2414}));
      v_t_2418 = heff_tag_at(v_ru_24cod_2410_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2413, v_t_2415});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2416 = heff_field(v_cod_2410, 0);
      V v_ru_24cod_2410_24AbsConst = heff_take_reuse(v_cod_2410, 1ULL);
      V v_t_2417 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 3, (V[]){v_i_242, v_depth_243, v_t_2416}));
      v_t_2418 = heff_tag_at(v_ru_24cod_2410_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2417});
      break;
    }
    default: heff_nomatch(v_cod_2410);
    }
    return heff_tag_at(v_ru_24t_244_24SFunction, TAG_SFunction, 4, (V[]){v_level_248, v_t_2412, v_t_2418, v_implicit_2411});
  }
  case TAG_SRecord: {
    V v_level_2419 = heff_field(v_t_244, 0);
    V v_fs_2420 = heff_field(v_t_244, 1);
    V v_ru_24t_244_24SRecord = heff_take_reuse(v_t_244, 3ULL);
    V v_t_2421 = heff_arrayToList(heff_get(heff_dup(v_fs_2420), LBL_keys));
    V v_t_2422 = heff_arrayToList(heff_get(v_fs_2420, LBL_values));
    V v_t_2423 = (g_heff_2edict_2ezipKV(v_t_2421, v_t_2422));
    V v_pairs_2424 = (g_heff_2edriver_2ecloseFieldsGo(v_r_240, v_i_242, v_depth_243, MK_INT(0LL), v_t_2423));
    V v_t_2425 = (g_prelude_2emap_24s5(heff_dup(v_pairs_2424)));
    V v_t_2426 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_pairs_2424));
    V v_t_2427 = (g_prelude_2emap_24s6(v_pairs_2424));
    V v_t_2428 = heff_rec(3, shape_146_32_353, (V[]){heff_arrayFromList(v_t_2425), v_t_2426, heff_arrayFromList(v_t_2427)});
    return heff_tag_at(v_ru_24t_244_24SRecord, TAG_SRecord, 2, (V[]){v_level_2419, v_t_2428});
  }
  case TAG_SSum: {
    V v_vs_2429 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SSum = heff_take_reuse(v_t_244, 1ULL);
    V v_xs_2430 = heff_get(heff_dup(v_vs_2429), LBL_values);
    V v_t_2435 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2430)), heff_clo(g_heff_2edriver_2ecloseTypeF_lam0, 1, 4, (V[]){v_xs_2430, v_r_240, v_i_242, v_depth_243}));
    V v_t_2436 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_vs_2429), LBL_keys), heff_get(v_vs_2429, LBL_byName), v_t_2435});
    return heff_tag_at(v_ru_24t_244_24SSum, TAG_SSum, 1, (V[]){v_t_2436});
  }
  case TAG_SIsTy: {
    V v_t2_2437 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SIsTy = heff_take_reuse(v_t_244, 1ULL);
    V v_t_2438 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 3, (V[]){v_i_242, v_depth_243, v_t2_2437}));
    return heff_tag_at(v_ru_24t_244_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2438});
  }
  case TAG_SPrimInt: {
    heff_drop(v_r_240);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimFloat: {
    heff_drop(v_r_240);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimString: {
    heff_drop(v_r_240);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimArray: {
    V v_t2_2439 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SPrimArray = heff_take_reuse(v_t_244, 1ULL);
    V v_t_2440 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 3, (V[]){v_i_242, v_depth_243, v_t2_2439}));
    return heff_tag_at(v_ru_24t_244_24SPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2440});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2edriver_2ecloseTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2ecloseTypeF(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2edriver_2ecloseTypeF_lam1(V self, V *args) {
  V v_i_2433 = args[0];
  V v_xs_2432 = heff_dup(heff_env(self)[0]);
  V v_r_240 = heff_dup(heff_env(self)[1]);
  V v_i_242 = heff_dup(heff_env(self)[2]);
  V v_depth_243 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t2_2434 = heff_arrayIndex(v_xs_2432, v_i_2433);
  return heff_tail(heff_get(v_r_240, LBL_ty), 3, (V[]){v_i_242, v_depth_243, v_t2_2434});
}
V g_heff_2edriver_2ecloseTypeF_lam0(V self, V *args) {
  V v_i_2431 = args[0];
  V v_xs_2430 = heff_dup(heff_env(self)[0]);
  V v_r_240 = heff_dup(heff_env(self)[1]);
  V v_i_242 = heff_dup(heff_env(self)[2]);
  V v_depth_243 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_xs_2432 = heff_arrayIndex(v_xs_2430, v_i_2431);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2432)), heff_clo(g_heff_2edriver_2ecloseTypeF_lam1, 1, 4, (V[]){v_xs_2432, v_r_240, v_i_242, v_depth_243}));
}
V g_heff_2edriver_2ecloseTermF_lam0(V self, V *args);
V g_heff_2edriver_2ecloseTermF_lam1(V self, V *args);
V g_heff_2edriver_2ecloseTermF_lam2(V self, V *args);
Clo g_heff_2edriver_2ecloseTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ecloseTermF_entry, 5, 0};

V g_heff_2edriver_2ecloseTermF(V v_r_240, V v_idx_241, V v_i_242, V v_depth_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_SLocal: {
    heff_drop(v_r_240);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SGlobal: {
    V v_k_246 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SGlobal = heff_take_reuse(v_e_244, 1ULL);
    heff_drop(v_r_240);
    V v_t_247 = (g_map_2elookup_24s8(heff_dup(v_k_246), v_idx_241));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop(v_i_242);
      heff_drop(v_depth_243);
      heff_drop(v_t_247);
      return heff_tag_at(v_ru_24e_244_24SGlobal, TAG_SGlobal, 1, (V[]){v_k_246});
    }
    case TAG_Just: {
      V v_j_248 = heff_field(v_t_247, 0);
      heff_take(v_t_247, 1ULL);
      V v_t_249 = heff_intLt(heff_dup(v_j_248), heff_dup(v_i_242));
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        heff_drop(v_k_246);
        heff_drop(v_t_249);
        V v_t_2410 = heff_intSub(heff_intSub(v_i_242, MK_INT(1LL)), v_j_248);
        return heff_tag_at(v_ru_24e_244_24SGlobal, TAG_SLocal, 1, (V[]){heff_intAdd(v_depth_243, v_t_2410)});
      }
      case TAG_False: {
        heff_drop(v_i_242);
        heff_drop(v_depth_243);
        heff_drop(v_j_248);
        heff_drop(v_t_249);
        return heff_tag_at(v_ru_24e_244_24SGlobal, TAG_SGlobal, 1, (V[]){v_k_246});
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_SCode: {
    V v_t_2411 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SCode = heff_take_reuse(v_e_244, 1ULL);
    V v_t_2412 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 3, (V[]){v_i_242, v_depth_243, v_t_2411}));
    return heff_tag_at(v_ru_24e_244_24SCode, TAG_SCode, 1, (V[]){v_t_2412});
  }
  case TAG_SApp: {
    V v_f_2413 = heff_field(v_e_244, 0);
    V v_a2_2414 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SApp = heff_take_reuse(v_e_244, 3ULL);
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_f_2413}));
    V v_t_2416 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 3, (V[]){v_i_242, v_depth_243, v_a2_2414}));
    return heff_tag_at(v_ru_24e_244_24SApp, TAG_SApp, 2, (V[]){v_t_2415, v_t_2416});
  }
  case TAG_SLam: {
    V v_t_2417 = heff_field(v_e_244, 0);
    V v_b_2418 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SLam = heff_take_reuse(v_e_244, 3ULL);
    V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_t_2417}));
    V v_t_2425;
    switch (heff_tag_of(v_b_2418)) {
    case TAG_MkAbs: {
      V v_x_2420 = heff_field(v_b_2418, 0);
      V v_t_2421 = heff_field(v_b_2418, 1);
      heff_take(v_b_2418, 3ULL);
      V v_t_2422 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, MK_INT(1LL)), v_t_2421}));
      v_t_2425 = heff_tag_at(v_ru_24e_244_24SLam, TAG_MkAbs, 2, (V[]){v_x_2420, v_t_2422});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2423 = heff_field(v_b_2418, 0);
      V v_ru_24b_2418_24AbsConst = heff_take_reuse(v_b_2418, 1ULL);
      heff_drop(v_ru_24e_244_24SLam);
      V v_t_2424 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 3, (V[]){v_i_242, v_depth_243, v_t_2423}));
      v_t_2425 = heff_tag_at(v_ru_24b_2418_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2424});
      break;
    }
    default: heff_nomatch(v_b_2418);
    }
    return heff_tag(TAG_SLam, 2, (V[]){v_t_2419, v_t_2425});
  }
  case TAG_SCons: {
    V v_d_2426 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SCons = heff_take_reuse(v_e_244, 1ULL);
    V v_xs_2427 = heff_get(heff_dup(v_d_2426), LBL_values);
    V v_t_2430 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2427)), heff_clo(g_heff_2edriver_2ecloseTermF_lam0, 1, 4, (V[]){v_xs_2427, v_r_240, v_i_242, v_depth_243}));
    V v_t_2431 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_d_2426), LBL_keys), heff_get(v_d_2426, LBL_byName), v_t_2430});
    return heff_tag_at(v_ru_24e_244_24SCons, TAG_SCons, 1, (V[]){v_t_2431});
  }
  case TAG_SProj: {
    V v_e2_2432 = heff_field(v_e_244, 0);
    V v_l_2433 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SProj = heff_take_reuse(v_e_244, 3ULL);
    V v_t_2434 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 3, (V[]){v_i_242, v_depth_243, v_e2_2432}));
    return heff_tag_at(v_ru_24e_244_24SProj, TAG_SProj, 2, (V[]){v_t_2434, v_l_2433});
  }
  case TAG_STag: {
    V v_t_2435 = heff_field(v_e_244, 0);
    V v_as_2436 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24STag = heff_take_reuse(v_e_244, 3ULL);
    V v_t_2438 = (g_prelude_2emap(heff_clo(g_heff_2edriver_2ecloseTermF_lam1, 1, 3, (V[]){v_r_240, v_i_242, v_depth_243}), heff_arrayToList(v_as_2436)));
    return heff_tag_at(v_ru_24e_244_24STag, TAG_STag, 2, (V[]){v_t_2435, heff_arrayFromList(v_t_2438)});
  }
  case TAG_SMatch: {
    V v_e2_2439 = heff_field(v_e_244, 0);
    V v_cs_2440 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SMatch = heff_take_reuse(v_e_244, 3ULL);
    V v_t_2441 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_e2_2439}));
    V v_xs_2442 = heff_get(heff_dup(v_cs_2440), LBL_values);
    V v_t_2449 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2442)), heff_clo(g_heff_2edriver_2ecloseTermF_lam2, 1, 4, (V[]){v_xs_2442, v_r_240, v_i_242, v_depth_243}));
    V v_t_2450 = heff_rec(3, shape_146_32_353, (V[]){heff_get(heff_dup(v_cs_2440), LBL_keys), heff_get(v_cs_2440, LBL_byName), v_t_2449});
    return heff_tag_at(v_ru_24e_244_24SMatch, TAG_SMatch, 2, (V[]){v_t_2441, v_t_2450});
  }
  case TAG_SSpecialize: {
    V v_e2_2451 = heff_field(v_e_244, 0);
    V v_l_2452 = heff_field(v_e_244, 1);
    V v_v_2453 = heff_field(v_e_244, 2);
    V v_ru_24e_244_24SSpecialize = heff_take_reuse(v_e_244, 7ULL);
    V v_t_2454 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_el), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_e2_2451}));
    V v_t_2455 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 3, (V[]){v_i_242, v_depth_243, v_v_2453}));
    return heff_tag_at(v_ru_24e_244_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2454, v_l_2452, v_t_2455});
  }
  case TAG_SIs: {
    V v_e2_2456 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SIs = heff_take_reuse(v_e_244, 1ULL);
    V v_t_2457 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 3, (V[]){v_i_242, v_depth_243, v_e2_2456}));
    return heff_tag_at(v_ru_24e_244_24SIs, TAG_SIs, 1, (V[]){v_t_2457});
  }
  case TAG_SOpaque: {
    heff_drop(v_r_240);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SAbandon: {
    heff_drop(v_r_240);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SRec: {
    V v_e2_2458 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SRec = heff_take_reuse(v_e_244, 1ULL);
    V v_t_2459 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 3, (V[]){v_i_242, v_depth_243, v_e2_2458}));
    return heff_tag_at(v_ru_24e_244_24SRec, TAG_SRec, 1, (V[]){v_t_2459});
  }
  case TAG_SFix: {
    V v_t_2460 = heff_field(v_e_244, 0);
    V v_b_2461 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SFix = heff_take_reuse(v_e_244, 3ULL);
    V v_t_2462 = heff_tr(heff_apply(heff_get(heff_dup(v_r_240), LBL_ty), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_t_2460}));
    V v_t_2468;
    switch (heff_tag_of(v_b_2461)) {
    case TAG_MkAbs: {
      V v_x_2463 = heff_field(v_b_2461, 0);
      V v_t_2464 = heff_field(v_b_2461, 1);
      heff_take(v_b_2461, 3ULL);
      V v_t_2465 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, MK_INT(1LL)), v_t_2464}));
      v_t_2468 = heff_tag_at(v_ru_24e_244_24SFix, TAG_MkAbs, 2, (V[]){v_x_2463, v_t_2465});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2466 = heff_field(v_b_2461, 0);
      V v_ru_24b_2461_24AbsConst = heff_take_reuse(v_b_2461, 1ULL);
      heff_drop(v_ru_24e_244_24SFix);
      V v_t_2467 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 3, (V[]){v_i_242, v_depth_243, v_t_2466}));
      v_t_2468 = heff_tag_at(v_ru_24b_2461_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2467});
      break;
    }
    default: heff_nomatch(v_b_2461);
    }
    return heff_tag(TAG_SFix, 2, (V[]){v_t_2462, v_t_2468});
  }
  case TAG_SImplicit: {
    V v_x_2469 = heff_field(v_e_244, 0);
    V v_e2_2470 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SImplicit = heff_take_reuse(v_e_244, 3ULL);
    V v_t_2471 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 3, (V[]){v_i_242, v_depth_243, v_e2_2470}));
    return heff_tag_at(v_ru_24e_244_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2469, v_t_2471});
  }
  case TAG_SPrim: {
    heff_drop(v_r_240);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SMetaApp: {
    V v_m_2473 = heff_field(v_e_244, 0);
    V v_xs_2474 = heff_field(v_e_244, 1);
    V v_t_2475 = heff_field(v_e_244, 2);
    V v_ru_24e_244_24SMetaApp = heff_take_reuse(v_e_244, 7ULL);
    V v_t_2476 = heff_tr(heff_apply(heff_get(v_r_240, LBL_ty), 3, (V[]){v_i_242, v_depth_243, v_t_2475}));
    return heff_tag_at(v_ru_24e_244_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2473, v_xs_2474, v_t_2476});
  }
  case TAG_SLitInt: {
    heff_drop(v_r_240);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitFloat: {
    heff_drop(v_r_240);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitString: {
    heff_drop(v_r_240);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2edriver_2ecloseTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2ecloseTermF(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2edriver_2ecloseTermF_lam0(V self, V *args) {
  V v_i_2428 = args[0];
  V v_xs_2427 = heff_dup(heff_env(self)[0]);
  V v_r_240 = heff_dup(heff_env(self)[1]);
  V v_i_242 = heff_dup(heff_env(self)[2]);
  V v_depth_243 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_e2_2429 = heff_arrayIndex(v_xs_2427, v_i_2428);
  return heff_tail(heff_get(v_r_240, LBL_el), 3, (V[]){v_i_242, v_depth_243, v_e2_2429});
}
V g_heff_2edriver_2ecloseTermF_lam1(V self, V *args) {
  V v_e2_2437 = args[0];
  V v_r_240 = heff_dup(heff_env(self)[0]);
  V v_i_242 = heff_dup(heff_env(self)[1]);
  V v_depth_243 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(heff_get(v_r_240, LBL_el), 3, (V[]){v_i_242, v_depth_243, v_e2_2437});
}
V g_heff_2edriver_2ecloseTermF_lam2(V self, V *args) {
  V v_i_2443 = args[0];
  V v_xs_2442 = heff_dup(heff_env(self)[0]);
  V v_r_240 = heff_dup(heff_env(self)[1]);
  V v_i_242 = heff_dup(heff_env(self)[2]);
  V v_depth_243 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_p_2444 = heff_arrayIndex(v_xs_2442, v_i_2443);
  switch (heff_tag_of(v_p_2444)) {
  case TAG_MkPair: {
    V v_xs_2445 = heff_field(v_p_2444, 0);
    V v_b_2446 = heff_field(v_p_2444, 1);
    V v_ru_24p_2444_24MkPair = heff_take_reuse(v_p_2444, 3ULL);
    V v_t_2447 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_arrayToList(heff_dup(v_xs_2445)); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2448 = heff_tr(heff_apply(heff_get(v_r_240, LBL_el), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, v_t_2447), v_b_2446}));
    return heff_tag_at(v_ru_24p_2444_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2445, v_t_2448});
  }
  default: return heff_nomatch(v_p_2444);
  }
}
V g_heff_2edriver_2eckOf_lam0(V self, V *args);
V g_heff_2edriver_2eckOf_lam1(V self, V *args);
Clo g_heff_2edriver_2eckOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eckOf_entry, 1, 0};

V g_heff_2edriver_2eckOf(V v_idx_240) {
top: ;
  return heff_rec(2, shape_336_75, (V[]){heff_clo(g_heff_2edriver_2eckOf_lam0, 3, 1, (V[]){heff_dup(v_idx_240)}), heff_clo(g_heff_2edriver_2eckOf_lam1, 3, 1, (V[]){heff_dup(v_idx_240)})});
}
V g_heff_2edriver_2eckOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eckOf(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2edriver_2eckOf_lam0(V self, V *args) {
  V v_i_241 = args[0];
  V v_depth_242 = args[1];
  V v_t_243 = args[2];
  V v_idx_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = (g_heff_2edriver_2eckOf(v_idx_240));
  return ({ V a_0 = v_t_244; V a_1 = v_idx_240; V a_2 = v_i_241; V a_3 = v_depth_242; V a_4 = v_t_243; V r_ = (g_heff_2edriver_2ecloseTypeF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_idx_240); r_; });
}
V g_heff_2edriver_2eckOf_lam1(V self, V *args) {
  V v_i_245 = args[0];
  V v_depth_246 = args[1];
  V v_e_247 = args[2];
  V v_idx_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_248 = (g_heff_2edriver_2eckOf(v_idx_240));
  return ({ V a_0 = v_t_248; V a_1 = v_idx_240; V a_2 = v_i_245; V a_3 = v_depth_246; V a_4 = v_e_247; V r_ = (g_heff_2edriver_2ecloseTermF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_idx_240); r_; });
}
Clo g_heff_2edriver_2estructFieldsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2estructFieldsGo_entry, 3, 0};

V g_heff_2edriver_2estructFieldsGo(V v_idx_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse(v_x3_242, 3ULL);
    V v_t_245 = (g_heff_2edriver_2eckOf(v_idx_240));
    V v_t_246 = heff_tr(heff_apply(heff_get(v_t_245, LBL_ty), 3, (V[]){heff_dup(v_i_241), MK_INT(0LL), heff_get(heff_dup(v_r_243), LBL_ty)}));
    V v_t_247 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_MkPair, 2, (V[]){heff_get(v_r_243, LBL_name), v_t_246});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_247, (g_heff_2edriver_2estructFieldsGo(v_idx_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_rest_244))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2edriver_2estructFieldsGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2estructFieldsGo(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2estructBody_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {35}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2edriver_2estructBody_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {35, 84}};
Clo g_heff_2edriver_2estructBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2estructBody_entry, 3, 0};

V g_heff_2edriver_2estructBody(V v_mkey_240, V v_es_241, V v_g_27_242) {
top: ;
  V v_k_243 = heff_strAppend(heff_dup(v_mkey_240), ((V)&g_heff_2edriver_2estructBody_str0));
  V v_t_244 = heff_tag(TAG_SGlobal, 1, (V[]){heff_strAppend(v_mkey_240, ((V)&g_heff_2edriver_2estructBody_str1))});
  V v_tyStx_245 = heff_tag(TAG_SDecode, 1, (V[]){v_t_244});
  V v_pairs_246 = (g_prelude_2emap_24s501(v_es_241));
  V v_t_247 = (g_prelude_2emap_24s5(heff_dup(v_pairs_246)));
  V v_t_248 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_pairs_246));
  V v_t_249 = (g_prelude_2emap_24s6(v_pairs_246));
  V v_t_2410 = heff_rec(3, shape_146_32_353, (V[]){heff_arrayFromList(v_t_247), v_t_248, heff_arrayFromList(v_t_249)});
  V v_bodyStx_2411 = heff_tag(TAG_SCons, 1, (V[]){v_t_2410});
  V v_t_2412 = (g_heff_2etop_2evalueOf(heff_dup(v_g_27_242), heff_dup(v_k_243), heff_dup(v_tyStx_245), heff_dup(v_bodyStx_2411)));
  V v_x1_2413 = (g_heff_2eeval_2eevalTypeF_24s15(heff_dup(v_g_27_242), NTAG(TAG_N), heff_dup(v_tyStx_245), NTAG(TAG_LNil)));
  V v_t_2417;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Nom: {
    V v_x_2414 = heff_field(v_x1_2413, 0);
    heff_take(v_x1_2413, 1ULL);
    v_t_2417 = v_x_2414;
    break;
  }
  case TAG_Describe: {
    heff_take(v_x1_2413, 0ULL);
    v_t_2417 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2416 = heff_field(v_x1_2413, 0);
    heff_take(v_x1_2413, 1ULL);
    v_t_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x1_2413);
  }
  return (g_heff_2eglobals_2eaddEntry(v_k_243, heff_rec(4, shape_314_337_352_340, (V[]){v_bodyStx_2411, v_tyStx_245, v_t_2412, v_t_2417}), v_g_27_242));
}
V g_heff_2edriver_2estructBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2estructBody(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2edriver_2estructAdd_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {35, 84}};
Clo g_heff_2edriver_2estructAdd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2estructAdd_entry, 4, 0};

V g_heff_2edriver_2estructAdd(V v_mkey_240, V v_g_241, V v_es_242, V v_idx_243) {
top: ;
  V v_k_244 = heff_strAppend(heff_dup(v_mkey_240), ((V)&g_heff_2edriver_2estructAdd_str0));
  V v_t_245 = (g_prelude_2efoldl_24s500(NTAG(TAG_Small), v_es_242));
  V v_t_246 = ({ V a_0 = v_t_245; V b_1 = NTAG(TAG_Large); V r_ = (g_heff_2eparams_2eeqLevel(a_0, b_1)); heff_drop(v_t_245); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_t_246);
    v_t_247 = NTAG(TAG_LargeU);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_246);
    v_t_247 = NTAG(TAG_SmallU);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_tyStx_248 = heff_tag(TAG_SU, 1, (V[]){v_t_247});
  V v_t_249 = (g_prelude_2efoldl_24s500(NTAG(TAG_Small), v_es_242));
  V v_pairs_2410 = (g_heff_2edriver_2estructFieldsGo(v_idx_243, MK_INT(0LL), heff_dup(v_es_242)));
  V v_t_2411 = (g_prelude_2emap_24s5(heff_dup(v_pairs_2410)));
  V v_t_2412 = (g_heff_2edict_2eindexed(MK_INT(0LL), v_pairs_2410));
  V v_t_2413 = (g_prelude_2emap_24s6(v_pairs_2410));
  V v_t_2414 = heff_rec(3, shape_146_32_353, (V[]){heff_arrayFromList(v_t_2411), v_t_2412, heff_arrayFromList(v_t_2413)});
  V v_bodyStx_2415 = heff_tag(TAG_SCode, 1, (V[]){heff_tag(TAG_SRecord, 2, (V[]){v_t_249, v_t_2414})});
  V v_t_2416 = (g_heff_2etop_2evalueOf(heff_dup(v_g_241), heff_dup(v_k_244), heff_dup(v_tyStx_248), heff_dup(v_bodyStx_2415)));
  V v_x1_2417 = (g_heff_2eeval_2eevalTypeF_24s15(heff_dup(v_g_241), NTAG(TAG_N), heff_dup(v_tyStx_248), NTAG(TAG_LNil)));
  V v_t_2421;
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nom: {
    V v_x_2418 = heff_field(v_x1_2417, 0);
    heff_take(v_x1_2417, 1ULL);
    v_t_2421 = v_x_2418;
    break;
  }
  case TAG_Describe: {
    heff_take(v_x1_2417, 0ULL);
    v_t_2421 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2420 = heff_field(v_x1_2417, 0);
    heff_take(v_x1_2417, 1ULL);
    v_t_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x1_2417);
  }
  V v_t_2422 = (g_heff_2eglobals_2eaddEntry(v_k_244, heff_rec(4, shape_314_337_352_340, (V[]){v_bodyStx_2415, v_tyStx_248, v_t_2416, v_t_2421}), v_g_241));
  return (g_heff_2edriver_2estructBody(v_mkey_240, v_es_242, v_t_2422));
}
V g_heff_2edriver_2estructAdd_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2estructAdd(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2edriver_2emoduleStruct_lam0(V self, V *args);
Clo g_heff_2edriver_2emoduleStruct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2emoduleStruct_entry, 3, 0};

V g_heff_2edriver_2emoduleStruct(V v_mkey_240, V v_own_241, V v_g_242) {
top: ;
  V v_t_248 = (g_prelude_2emap(heff_clo(g_heff_2edriver_2emoduleStruct_lam0, 1, 1, (V[]){heff_dup(v_g_242)}), v_own_241));
  V v_es_249 = (g_heff_2edriver_2ecatMaybesD(v_t_248));
  switch (heff_tag_of(v_es_249)) {
  case TAG_Nil: {
    heff_drop(v_mkey_240);
    heff_drop(v_es_249);
    return v_g_242;
  }
  case TAG_Cons: {
    V v_t_2412 = (g_prelude_2efoldl_24s500(NTAG(TAG_Small), v_es_249));
    V v_t_2413 = ({ V a_0 = v_t_2412; V b_1 = NTAG(TAG_TopL); V r_ = (g_heff_2eparams_2eeqLevel(a_0, b_1)); heff_drop(v_t_2412); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      heff_drop(v_mkey_240);
      heff_drop(v_es_249);
      heff_drop(v_t_2413);
      return v_g_242;
    }
    case TAG_False: {
      heff_drop(v_t_2413);
      V v_t_2414 = (g_heff_2edriver_2estructIdxGo(MK_INT(0LL), v_es_249, heff_dup(g_map_2eempty_get())));
      return ({ V a_0 = v_mkey_240; V a_1 = v_g_242; V a_2 = v_es_249; V a_3 = v_t_2414; V r_ = (g_heff_2edriver_2estructAdd(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_es_249);
  }
}
V g_heff_2edriver_2emoduleStruct_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2emoduleStruct(a[0], a[1], a[2]);
}
V g_heff_2edriver_2emoduleStruct_lam0(V self, V *args) {
  V v_o_243 = args[0];
  V v_g_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = (g_heff_2eglobals_2elookupEntry(v_g_242, heff_get(heff_dup(v_o_243), LBL_key)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_o_243);
    heff_drop(v_t_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse(v_t_244, 1ULL);
    V v_t_246 = ({ V b_0 = heff_get(heff_dup(v_e_245), LBL_type_5f); V r_ = (g_heff_2evalue_2elevelOf(b_0)); heff_drop(b_0); r_; });
    V v_t_247 = heff_rec(4, shape_190_145_336_165, (V[]){heff_get(heff_dup(v_o_243), LBL_name), heff_get(v_o_243, LBL_key), heff_get(v_e_245, LBL_tySyntax), v_t_246});
    return heff_tag_at(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){v_t_247});
  }
  default: return heff_nomatch(v_t_244);
  }
}
Clo g_heff_2edriver_2efixOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2efixOf_entry, 2, 0};

V g_heff_2edriver_2efixOf(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_m_241);
    return heff_dup(g_heff_2efixity_2eemptyFixities_get());
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x11_242, 0);
      V v_f_245 = heff_field(v_x11_242, 1);
      V v_t_246 = heff_strEq(heff_dup(v_n_244), heff_dup(v_m_241));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_m_241);
        heff_drop(v_t_246);
        return heff_dup(v_f_245);
      }
      case TAG_False: {
        heff_drop(v_t_246);
        V t_0 = v_rest_243;
        V t_1 = v_m_241;
        v_x1_240 = t_0;
        v_m_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2efixOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2efixOf(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2edriver_2eimportedFix_lam0(V self, V *args);
Clo g_heff_2edriver_2eimportedFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eimportedFix_entry, 2, 0};

V g_heff_2edriver_2eimportedFix(V v_done_240, V v_imps_241) {
top: ;
  return ({ V a_0 = heff_clo(g_heff_2edriver_2eimportedFix_lam0, 2, 1, (V[]){heff_dup(v_done_240)}); V a_1 = heff_dup(g_heff_2efixity_2eemptyFixities_get()); V b_2 = heff_get(v_imps_241, LBL_imports); V r_ = (g_prelude_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2edriver_2eimportedFix_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eimportedFix(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2edriver_2eimportedFix_lam0(V self, V *args) {
  V v_f_242 = args[0];
  V v_i_243 = args[1];
  V v_done_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_b_244 = ({ V a_0 = v_done_240; V a_1 = heff_get(v_i_243, LBL_name); V r_ = (g_heff_2edriver_2efixOf(a_0, a_1)); heff_drop(v_done_240); r_; });
  V v_t_245 = (g_heff_2efixity_2eappendF(heff_get(heff_dup(v_f_242), LBL_groups), heff_get(heff_dup(v_b_244), LBL_groups)));
  V v_t_246 = (g_heff_2efixity_2enubByG(v_t_245));
  V v_t_247 = (g_heff_2efixity_2eappendF(heff_get(v_f_242, LBL_above), heff_get(v_b_244, LBL_above)));
  V v_t_248 = (g_heff_2efixity_2enubByE(v_t_247));
  return heff_rec(2, shape_113_0, (V[]){v_t_246, v_t_248});
}
Clo g_heff_2edriver_2eownFixOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eownFixOf_entry, 2, 0};

V g_heff_2edriver_2eownFixOf(V v_done_240, V v_imps_241) {
top: ;
  V v_imported_242 = (g_heff_2edriver_2eimportedFix(v_done_240, heff_dup(v_imps_241)));
  V v_t_243 = heff_rec(7, shape_123_167_168_96_325_83_42, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_244 = (g_heff_2efmt_2elex_2elexGo(heff_get(v_imps_241, LBL_text), v_t_243, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_ts_245 = heff_arrayFromList(heff_get(v_t_244, LBL_tokens));
  V v_t_246 = (g_heff_2esurface_2efixDecls(v_ts_245, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_247 = (g_heff_2esurface_2efixityFrom(v_imported_242, v_t_246));
  return heff_get(v_t_247, LBL_fixities);
}
V g_heff_2edriver_2eownFixOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eownFixOf(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2edriver_2efixitiesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2efixitiesGo_entry, 2, 0};

V g_heff_2edriver_2efixitiesGo(V v_done_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_done_240);
    heff_drop(v_x2_241);
    return heff_dup(g_heff_2efixity_2eemptyFixities_get());
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse(v_x2_241, 3ULL);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_x22_243);
      heff_drop(v_ru_24x2_241_24Cons);
      V v_t_244 = (g_heff_2edriver_2eimportsOfSource(heff_dup(v_s_242)));
      V v_a_245 = (g_heff_2edriver_2eimportedFix(v_done_240, v_t_244));
      V v_t_246 = (g_heff_2edriver_2eimportsOfSource(v_s_242));
      V v_b_247 = ({ V a_0 = v_done_240; V a_1 = v_t_246; V r_ = (g_heff_2edriver_2eownFixOf(a_0, a_1)); heff_drop(v_done_240); r_; });
      V v_t_248 = (g_heff_2efixity_2eappendF(heff_get(heff_dup(v_a_245), LBL_groups), heff_get(heff_dup(v_b_247), LBL_groups)));
      V v_t_249 = (g_heff_2efixity_2enubByG(v_t_248));
      V v_t_2410 = (g_heff_2efixity_2eappendF(heff_get(v_a_245, LBL_above), heff_get(v_b_247, LBL_above)));
      V v_t_2411 = (g_heff_2efixity_2enubByE(v_t_2410));
      return heff_rec(2, shape_113_0, (V[]){v_t_249, v_t_2411});
    }
    case TAG_Cons: {
      V v_t_2414 = (g_heff_2edriver_2eimportsOfSource(heff_dup(v_s_242)));
      V v_t_2415 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){heff_get(v_s_242, LBL_module), (g_heff_2edriver_2eownFixOf(v_done_240, v_t_2414))});
      V t_0 = heff_tag(TAG_Cons, 2, (V[]){v_t_2415, v_done_240});
      V t_1 = v_x22_243;
      v_done_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2edriver_2efixitiesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2efixitiesGo(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[62]; } g_heff_2edriver_2ehint_str0 = {{0x80000000u, K_STR, 0}, 62, 62, {105, 102, 32, 116, 104, 105, 115, 32, 105, 115, 32, 97, 32, 114, 101, 99, 117, 114, 115, 105, 118, 101, 32, 99, 97, 108, 108, 44, 32, 103, 117, 97, 114, 100, 32, 116, 104, 101, 32, 119, 104, 111, 108, 101, 32, 99, 97, 108, 108, 58, 32, 114, 101, 99, 32, 40, 102, 32, 46, 46, 46, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[115]; } g_heff_2edriver_2ehint_str1 = {{0x80000000u, K_STR, 0}, 115, 115, {110, 97, 109, 101, 32, 116, 104, 101, 32, 116, 121, 112, 101, 58, 32, 96, 116, 121, 112, 101, 32, 84, 32, 61, 32, 46, 46, 46, 96, 32, 97, 116, 32, 116, 111, 112, 32, 108, 101, 118, 101, 108, 44, 32, 111, 114, 32, 97, 32, 116, 121, 112, 101, 32, 102, 105, 101, 108, 100, 32, 111, 102, 32, 116, 104, 101, 32, 115, 116, 114, 117, 99, 116, 32, 105, 116, 32, 105, 115, 32, 105, 110, 32, 40, 96, 116, 32, 61, 32, 123, 32, 46, 46, 46, 32, 125, 96, 44, 32, 116, 104, 101, 110, 32, 96, 109, 46, 116, 96, 32, 104, 101, 114, 101, 41}};
Clo g_heff_2edriver_2ehint_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ehint_entry, 1, 0};

V g_heff_2edriver_2ehint(V v_d_240) {
top: ;
  V v_t_241 = heff_get(heff_dup(v_d_240), LBL_note);
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    V v_t_242 = heff_intEq(heff_get(heff_dup(v_d_240), LBL_code), MK_INT(319LL));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_t_242);
      return heff_rec(5, shape_44_284_185_299_197, (V[]){heff_get(heff_dup(v_d_240), LBL_code), heff_get(heff_dup(v_d_240), LBL_severity), heff_get(heff_dup(v_d_240), LBL_msg), heff_get(v_d_240, LBL_span), heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2edriver_2ehint_str0)})});
    }
    case TAG_False: {
      heff_drop(v_t_242);
      V v_t_243 = heff_intEq(heff_get(heff_dup(v_d_240), LBL_code), MK_INT(204LL));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_t_243);
        return heff_rec(5, shape_44_284_185_299_197, (V[]){heff_get(heff_dup(v_d_240), LBL_code), heff_get(heff_dup(v_d_240), LBL_severity), heff_get(heff_dup(v_d_240), LBL_msg), heff_get(v_d_240, LBL_span), heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2edriver_2ehint_str1)})});
      }
      case TAG_False: {
        heff_drop(v_t_243);
        return v_d_240;
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_Just: {
    heff_take(v_t_241, 0ULL);
    return v_d_240;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2edriver_2ehint_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2ehint(a[0]);
}
Clo g_heff_2edriver_2ethawedChecked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ethawedChecked_entry, 4, 0};

V g_heff_2edriver_2ethawedChecked(V v_s_240, V v_imps_241, V v_th_242, V v_t_243) {
top: ;
  V v_own_244 = (g_heff_2edriver_2eownOf(heff_get(heff_dup(v_s_240), LBL_module), heff_get(heff_dup(v_t_243), LBL_keys)));
  V v_globals_245 = (g_heff_2edriver_2emoduleStruct(heff_get(heff_dup(v_s_240), LBL_module), v_own_244, heff_get(heff_dup(v_t_243), LBL_globals)));
  V v_top_246 = heff_rec(9, shape_110_58_146_29_359_319_300_133_331, (V[]){v_globals_245, heff_get(heff_dup(v_t_243), LBL_diags), heff_get(heff_dup(v_t_243), LBL_keys), heff_get(heff_dup(v_t_243), LBL_broken), heff_get(heff_dup(v_t_243), LBL_watches), heff_get(heff_dup(v_t_243), LBL_tests), heff_get(heff_dup(v_t_243), LBL_spans), heff_get(heff_dup(v_t_243), LBL_infos), heff_get(heff_dup(v_t_243), LBL_trace)});
  V v_own_247 = (g_heff_2edriver_2eownOf(heff_get(heff_dup(v_s_240), LBL_module), heff_get(v_t_243, LBL_keys)));
  V v_t_248 = (g_prelude_2emap_24s451(heff_get(heff_dup(v_imps_241), LBL_imports)));
  V v_deps_249 = (g_heff_2edriver_2enubStrD(v_t_248));
  V v_opens_2410 = (g_heff_2edriver_2eopenNames(heff_get(heff_dup(v_imps_241), LBL_imports)));
  V v_aliases_2411 = (g_heff_2edriver_2ealiasPairs(heff_get(v_imps_241, LBL_imports)));
  return heff_rec(12, shape_184_228_296_52_329_58_216_56_208_4_98_34, (V[]){heff_get(heff_dup(v_s_240), LBL_module), heff_get(heff_dup(v_s_240), LBL_path), heff_get(v_s_240, LBL_source), NTAG(TAG_Nil), v_top_246, NTAG(TAG_Nil), v_own_247, v_deps_249, v_opens_2410, v_aliases_2411, heff_get(v_th_242, LBL_fixities), NTAG(TAG_True)});
}
V g_heff_2edriver_2ethawedChecked_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2ethawedChecked(a[0], a[1], a[2], a[3]);
}
V g_heff_2edriver_2eelabTop_lam0(V self, V *args);
Clo g_heff_2edriver_2eelabTop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eelabTop_entry, 5, 0};

V g_heff_2edriver_2eelabTop(V v_s_240, V v_imps_241, V v_direct_242, V v_r_243, V v_t_244) {
top: ;
  V v_own_245 = (g_heff_2edriver_2eownOf(heff_get(heff_dup(v_s_240), LBL_module), heff_get(heff_dup(v_t_244), LBL_keys)));
  V v_globals_246 = (g_heff_2edriver_2emoduleStruct(heff_get(heff_dup(v_s_240), LBL_module), v_own_245, heff_get(heff_dup(v_t_244), LBL_globals)));
  V v_top_247 = heff_rec(9, shape_110_58_146_29_359_319_300_133_331, (V[]){v_globals_246, heff_get(heff_dup(v_t_244), LBL_diags), heff_get(heff_dup(v_t_244), LBL_keys), heff_get(heff_dup(v_t_244), LBL_broken), heff_get(heff_dup(v_t_244), LBL_watches), heff_get(heff_dup(v_t_244), LBL_tests), heff_get(heff_dup(v_t_244), LBL_spans), heff_get(heff_dup(v_t_244), LBL_infos), heff_get(heff_dup(v_t_244), LBL_trace)});
  V v_t_248 = (g_heff_2edriver_2econcatMapD_24s498(v_direct_242));
  V v_t_249 = (g_heff_2edriver_2ewithoutGiven(v_t_248));
  V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2edriver_2eclashDiag_clo), 1, (V[]){v_t_249}));
  V v_t_2411 = (g_heff_2edriver_2econcatMapD_24s498(v_direct_242));
  V v_imported_2412 = (g_heff_2edriver_2ewithoutGiven(v_t_2411));
  V v_m_2413 = (g_heff_2edriver_2eclashMap(heff_dup(g_map_2eempty_get()), heff_dup(v_imported_2412)));
  V v_t_2419 = (g_prelude_2efilter(heff_clo(g_heff_2edriver_2eelabTop_lam0, 1, 1, (V[]){v_m_2413}), v_imported_2412));
  V v_t_2420 = (g_heff_2edriver_2enubByName(v_t_2419));
  V v_t_2421 = (g_prelude_2emap(v_t_2410, v_t_2420));
  V v_t_2422 = (g_heff_2edriver_2eappendD(heff_get(heff_dup(v_r_243), LBL_diags), heff_get(heff_dup(v_t_244), LBL_diags)));
  V v_t_2423 = (g_prelude_2emap_24s503(v_t_2422));
  V v_diags_2424 = (g_heff_2edriver_2eappendD(v_t_2421, v_t_2423));
  V v_own_2425 = (g_heff_2edriver_2eownOf(heff_get(heff_dup(v_s_240), LBL_module), heff_get(v_t_244, LBL_keys)));
  V v_t_2426 = (g_prelude_2emap_24s451(heff_get(heff_dup(v_imps_241), LBL_imports)));
  V v_deps_2427 = (g_heff_2edriver_2enubStrD(v_t_2426));
  V v_opens_2428 = (g_heff_2edriver_2eopenNames(heff_get(heff_dup(v_imps_241), LBL_imports)));
  V v_aliases_2429 = (g_heff_2edriver_2ealiasPairs(heff_get(v_imps_241, LBL_imports)));
  return heff_rec(12, shape_184_228_296_52_329_58_216_56_208_4_98_34, (V[]){heff_get(heff_dup(v_s_240), LBL_module), heff_get(heff_dup(v_s_240), LBL_path), heff_get(v_s_240, LBL_source), heff_get(heff_dup(v_r_243), LBL_decls), v_top_247, v_diags_2424, v_own_2425, v_deps_2427, v_opens_2428, v_aliases_2429, heff_get(v_r_243, LBL_fixities), NTAG(TAG_False)});
}
V g_heff_2edriver_2eelabTop_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eelabTop(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2edriver_2eelabTop_lam0(V self, V *args) {
  V v_o_2414 = args[0];
  V v_m_2413 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_it_2415 = ({ V a_0 = heff_get(v_o_2414, LBL_name); V a_1 = v_m_2413; V r_ = (g_map_2elookup_24s8(a_0, a_1)); heff_drop(v_m_2413); r_; });
  switch (heff_tag_of(v_it_2415)) {
  case TAG_Nothing: {
    heff_drop(v_it_2415);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_it1_2416 = heff_field(v_it_2415, 0);
    heff_take(v_it_2415, 1ULL);
    switch (heff_tag_of(v_it1_2416)) {
    case TAG_MkPair: {
      V v_c_2418 = heff_field(v_it1_2416, 1);
      heff_take(v_it1_2416, 2ULL);
      return v_c_2418;
    }
    default: return heff_nomatch(v_it1_2416);
    }
  }
  default: return heff_nomatch(v_it_2415);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eelabRead_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eelabRead_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
V g_heff_2edriver_2eelabRead_lam0(V self, V *args);
V g_heff_2edriver_2eelabRead_lam1(V self, V *args);
Clo g_heff_2edriver_2eelabRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eelabRead_entry, 6, 0};

V g_heff_2edriver_2eelabRead(V v_done_240, V v_s_241, V v_imps_242, V v_direct_243, V v_g0_244, V v_r_245) {
top: ;
  V v_g0_247 = ({ V a_0 = heff_clo(g_heff_2edriver_2eelabRead_lam0, 1, 1, (V[]){heff_dup(v_s_241)}); V a_1 = v_g0_244; V b_2 = heff_get(heff_dup(v_r_245), LBL_broken); V r_ = (g_heff_2edriver_2ewithParseBroken(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_248 = heff_rec(9, shape_110_58_146_29_359_319_300_133_331, (V[]){v_g0_247, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_249 = (g_prelude_2emap(heff_dup(g_heff_2epresyntax_2eclassify_get()), heff_get(heff_dup(v_r_245), LBL_decls)));
  V v_t_2411 = ({ V a_0 = heff_clo(g_heff_2edriver_2eelabRead_lam1, 1, 1, (V[]){heff_dup(v_s_241)}); V a_1 = v_t_248; V a_2 = v_t_249; V r_ = (g_heff_2etoplevel_2etopGo(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
  return (g_heff_2edriver_2eelabTop(v_s_241, v_imps_242, v_direct_243, v_r_245, v_t_2411));
}
V g_heff_2edriver_2eelabRead_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eelabRead(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); heff_drop(a[3]); return r;
}
V g_heff_2edriver_2eelabRead_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_s_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strAppend(heff_get(v_s_241, LBL_module), heff_strAppend(((V)&g_heff_2edriver_2eelabRead_str0), v_x_246));
}
V g_heff_2edriver_2eelabRead_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_s_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strAppend(heff_get(v_s_241, LBL_module), heff_strAppend(((V)&g_heff_2edriver_2eelabRead_str1), v_x_2410));
}
V g_heff_2edriver_2eelabFrom_lam0(V self, V *args);
Clo g_heff_2edriver_2eelabFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eelabFrom_entry, 6, 0};

V g_heff_2edriver_2eelabFrom(V v_done_240, V v_s_241, V v_imps_242, V v_x4_243, V v_direct_244, V v_g0_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_246 = (g_prelude_2efoldl_24s502(heff_dup(g_heff_2efixity_2eemptyFixities_get()), v_direct_244));
    V v_t_2410 = heff_rec(3, shape_149_98_161, (V[]){heff_clo(g_heff_2edriver_2eelabFrom_lam0, 1, 1, (V[]){heff_dup(v_g0_245)}), v_t_246, NTAG(TAG_False)});
    V v_t_2411 = (g_heff_2esurface_2ereadProgramWith(v_t_2410, heff_get(heff_dup(v_imps_242), LBL_text)));
    return (g_heff_2edriver_2eelabRead(v_done_240, v_s_241, v_imps_242, v_direct_244, v_g0_245, v_t_2411));
  }
  case TAG_Just: {
    V v_th_2412 = heff_field(v_x4_243, 0);
    V v_t_2413 = heff_rec(9, shape_110_58_146_29_359_319_300_133_331, (V[]){v_g0_245, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2414 = ({ V a_0 = v_t_2413; V b_1 = heff_get(heff_dup(v_th_2412), LBL_defs); V r_ = (g_prelude_2efoldl_24s495(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2415 = (g_heff_2etoplevel_2ethawDone(v_t_2414));
    return (g_heff_2edriver_2ethawedChecked(v_s_241, v_imps_242, heff_dup(v_th_2412), v_t_2415));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2edriver_2eelabFrom_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eelabFrom(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); heff_drop(a[3]); heff_drop(a[4]); return r;
}
V g_heff_2edriver_2eelabFrom_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_g0_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_248 = (g_heff_2eglobals_2elookupEntry(v_g0_245, v_x_247));
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop(v_t_248);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take(v_t_248, 0ULL);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_248);
  }
}
Clo g_heff_2edriver_2econcatMapD_24s504_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2econcatMapD_24s504_entry, 1, 0};

V g_heff_2edriver_2econcatMapD_24s504(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2edriver_2ebrokenIn(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2edriver_2econcatMapD_24s504(v_xs_242));
    return (g_heff_2edriver_2eappendD(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2edriver_2econcatMapD_24s504_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2econcatMapD_24s504(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2edriver_2eelabAliased_lam0(V self, V *args);
Clo g_heff_2edriver_2eelabAliased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eelabAliased_entry, 7, 0};

V g_heff_2edriver_2eelabAliased(V v_done_240, V v_s_241, V v_imps_242, V v_thaw_243, V v_direct_244, V v_needed_245, V v_imported_246) {
top: ;
  V v_m_247 = (g_heff_2edriver_2eclashMap(heff_dup(g_map_2eempty_get()), heff_dup(v_imported_246)));
  V v_t_2413 = (g_prelude_2efilter(heff_clo(g_heff_2edriver_2eelabAliased_lam0, 1, 1, (V[]){v_m_247}), heff_dup(v_imported_246)));
  V v_clashes_2414 = (g_heff_2edriver_2enubByName(v_t_2413));
  V v_t_2415 = (g_prelude_2efoldl_24s497(heff_dup(g_heff_2eglobals_2eemptyGlobals_get()), v_needed_245));
  V v_t_2416 = ({ V a_0 = v_clashes_2414; V a_1 = v_t_2415; V a_2 = v_imported_246; V r_ = (g_heff_2edriver_2ealiasOpen(a_0, a_1, a_2)); heff_drop(v_imported_246); r_; });
  V v_t_2417 = (g_heff_2edriver_2econcatMapD_24s504(v_direct_244));
  V v_t_2418 = ({ V a_0 = v_clashes_2414; V a_1 = v_t_2416; V a_2 = v_t_2417; V r_ = (g_heff_2edriver_2ealiasOpen(a_0, a_1, a_2)); heff_drop(v_clashes_2414); heff_drop(v_t_2417); r_; });
  V v_t_2419 = (g_heff_2edriver_2ealiasPairs(heff_get(heff_dup(v_imps_242), LBL_imports)));
  V v_t_2420 = ({ V a_0 = v_done_240; V a_1 = v_t_2418; V a_2 = v_t_2419; V r_ = (g_heff_2edriver_2ealiasQualified(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
  return (g_heff_2edriver_2eelabFrom(v_done_240, v_s_241, v_imps_242, v_thaw_243, v_direct_244, v_t_2420));
}
V g_heff_2edriver_2eelabAliased_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eelabAliased(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[0]); heff_drop(a[3]); heff_drop(a[4]); heff_drop(a[5]); return r;
}
V g_heff_2edriver_2eelabAliased_lam0(V self, V *args) {
  V v_o_248 = args[0];
  V v_m_247 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_it_249 = ({ V a_0 = heff_get(v_o_248, LBL_name); V a_1 = v_m_247; V r_ = (g_map_2elookup_24s8(a_0, a_1)); heff_drop(v_m_247); r_; });
  switch (heff_tag_of(v_it_249)) {
  case TAG_Nothing: {
    heff_drop(v_it_249);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_it1_2410 = heff_field(v_it_249, 0);
    heff_take(v_it_249, 1ULL);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_MkPair: {
      V v_c_2412 = heff_field(v_it1_2410, 1);
      heff_take(v_it1_2410, 2ULL);
      return v_c_2412;
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  default: return heff_nomatch(v_it_249);
  }
}
V g_heff_2edriver_2eelabNeeding_lam0(V self, V *args);
V g_heff_2edriver_2eelabNeeding_lam1(V self, V *args);
Clo g_heff_2edriver_2eelabNeeding_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eelabNeeding_entry, 5, 0};

V g_heff_2edriver_2eelabNeeding(V v_done_240, V v_s_241, V v_imps_242, V v_thaw_243, V v_reached_244) {
top: ;
  V v_direct_248 = (g_prelude_2efilter(heff_clo(g_heff_2edriver_2eelabNeeding_lam0, 1, 1, (V[]){heff_dup(v_imps_242)}), heff_dup(v_done_240)));
  V v_needed_2411 = (g_prelude_2efilter(heff_clo(g_heff_2edriver_2eelabNeeding_lam1, 1, 1, (V[]){heff_dup(v_reached_244)}), heff_dup(v_done_240)));
  V v_t_2412 = (g_heff_2edriver_2econcatMapD_24s498(v_direct_248));
  V v_t_2413 = (g_heff_2edriver_2ewithoutGiven(v_t_2412));
  return ({ V a_0 = v_done_240; V a_1 = v_s_241; V a_2 = v_imps_242; V a_3 = v_thaw_243; V a_4 = v_direct_248; V a_5 = v_needed_2411; V a_6 = v_t_2413; V r_ = (g_heff_2edriver_2eelabAliased(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_done_240); heff_drop(v_direct_248); heff_drop(v_needed_2411); r_; });
}
V g_heff_2edriver_2eelabNeeding_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eelabNeeding(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); heff_drop(a[4]); return r;
}
V g_heff_2edriver_2eelabNeeding_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_imps_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_xs_246 = (g_heff_2edriver_2eopenNames(heff_get(v_imps_242, LBL_imports)));
  V v_t_247 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_c_245, LBL_module)}));
  return ({ V a_0 = v_t_247; V a_1 = v_xs_246; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_xs_246); r_; });
}
V g_heff_2edriver_2eelabNeeding_lam1(V self, V *args) {
  V v_c_249 = args[0];
  V v_reached_244 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2410 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_c_249, LBL_module)}));
  return ({ V a_0 = v_t_2410; V a_1 = v_reached_244; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_reached_244); r_; });
}
Clo g_heff_2edriver_2elean_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2elean_entry, 1, 0};

V g_heff_2edriver_2elean(V v_c_240) {
top: ;
  V v_t_241 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_infos);
  V v_infos_242 = (g_prelude_2emap_24s506(v_t_241));
  V v_t_243 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_globals);
  V v_t_244 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_diags);
  V v_t_245 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_keys);
  V v_t_246 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_broken);
  V v_t_247 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_watches);
  V v_t_248 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_tests);
  V v_t_249 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_spans);
  V v_top_2410 = heff_rec(9, shape_110_58_146_29_359_319_300_133_331, (V[]){v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_t_248, v_t_249, v_infos_242, NTAG(TAG_Nil)});
  return heff_rec(12, shape_184_228_296_52_329_58_216_56_208_4_98_34, (V[]){heff_get(heff_dup(v_c_240), LBL_module), heff_get(heff_dup(v_c_240), LBL_path), heff_get(heff_dup(v_c_240), LBL_source), heff_get(heff_dup(v_c_240), LBL_decls), v_top_2410, heff_get(heff_dup(v_c_240), LBL_diags), heff_get(heff_dup(v_c_240), LBL_own), heff_get(heff_dup(v_c_240), LBL_deps), heff_get(heff_dup(v_c_240), LBL_opens), heff_get(heff_dup(v_c_240), LBL_aliases), heff_get(heff_dup(v_c_240), LBL_fixities), heff_get(v_c_240, LBL_cached)});
}
V g_heff_2edriver_2elean_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2elean(a[0]);
}
Clo g_heff_2edriver_2etraceless_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2etraceless_entry, 1, 0};

V g_heff_2edriver_2etraceless(V v_c_240) {
top: ;
  V v_t_241 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_globals);
  V v_t_242 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_diags);
  V v_t_243 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_keys);
  V v_t_244 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_broken);
  V v_t_245 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_watches);
  V v_t_246 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_tests);
  V v_t_247 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_spans);
  V v_t_248 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_infos);
  V v_t_249 = heff_rec(9, shape_110_58_146_29_359_319_300_133_331, (V[]){v_t_241, v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_t_248, NTAG(TAG_Nil)});
  return heff_rec(12, shape_184_228_296_52_329_58_216_56_208_4_98_34, (V[]){heff_get(heff_dup(v_c_240), LBL_module), heff_get(heff_dup(v_c_240), LBL_path), heff_get(heff_dup(v_c_240), LBL_source), heff_get(heff_dup(v_c_240), LBL_decls), v_t_249, heff_get(heff_dup(v_c_240), LBL_diags), heff_get(heff_dup(v_c_240), LBL_own), heff_get(heff_dup(v_c_240), LBL_deps), heff_get(heff_dup(v_c_240), LBL_opens), heff_get(heff_dup(v_c_240), LBL_aliases), heff_get(heff_dup(v_c_240), LBL_fixities), heff_get(v_c_240, LBL_cached)});
}
V g_heff_2edriver_2etraceless_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2etraceless(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str10 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str11 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str12 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str13 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str14 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str15 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str16 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2edriver_2edefKind_str17 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 114, 105, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str18 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str19 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str20 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edefKind_str21 = {{0x80000000u, K_STR, 0}, 5, 5, {112, 108, 97, 105, 110}};
Clo g_heff_2edriver_2edefKind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2edefKind_entry, 2, 0};

V g_heff_2edriver_2edefKind(V v_c_240, V v_k_241) {
top: ;
  V v_t_242 = heff_get(heff_get(v_c_240, LBL_top), LBL_globals);
  V v_t_243 = (g_heff_2eglobals_2elookupEntry(v_t_242, v_k_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_t_243);
    return ((V)&g_heff_2edriver_2edefKind_str0);
  }
  case TAG_Just: {
    V v_e_244 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    V v_t_245 = heff_get(v_e_244, LBL_syntax);
    switch (heff_tag_of(v_t_245)) {
    case TAG_SLocal: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str1);
    }
    case TAG_SGlobal: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str2);
    }
    case TAG_SCode: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str3);
    }
    case TAG_SApp: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str4);
    }
    case TAG_SLam: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str5);
    }
    case TAG_SCons: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str6);
    }
    case TAG_SProj: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str7);
    }
    case TAG_STag: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str8);
    }
    case TAG_SMatch: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str9);
    }
    case TAG_SSpecialize: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str10);
    }
    case TAG_SIs: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str11);
    }
    case TAG_SOpaque: {
      heff_drop(v_t_245);
      return ((V)&g_heff_2edriver_2edefKind_str12);
    }
    case TAG_SAbandon: {
      heff_drop(v_t_245);
      return ((V)&g_heff_2edriver_2edefKind_str13);
    }
    case TAG_SRec: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str14);
    }
    case TAG_SFix: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str15);
    }
    case TAG_SImplicit: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str16);
    }
    case TAG_SPrim: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str17);
    }
    case TAG_SMetaApp: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str18);
    }
    case TAG_SLitInt: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str19);
    }
    case TAG_SLitFloat: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str20);
    }
    case TAG_SLitString: {
      heff_take(v_t_245, 0ULL);
      return ((V)&g_heff_2edriver_2edefKind_str21);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2edriver_2edefKind_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2edefKind(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2edumpLines_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {61, 100, 101, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2edumpLines_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2edriver_2edumpLines_str2 = {{0x80000000u, K_STR, 0}, 20, 20, {60, 110, 111, 32, 115, 117, 99, 104, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2edriver_2edumpLines_str3 = {{0x80000000u, K_STR, 0}, 20, 20, {60, 110, 111, 32, 115, 117, 99, 104, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2edriver_2edumpLines_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {61, 98, 111, 100, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2edriver_2edumpLines_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {61, 116, 121, 32}};
Clo g_heff_2edriver_2edumpLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2edumpLines_entry, 2, 0};

V g_heff_2edriver_2edumpLines(V v_c_240, V v_k_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2edriver_2edumpLines_str0), heff_strAppend(heff_dup(v_k_241), heff_strAppend(((V)&g_heff_2edriver_2edumpLines_str1), (g_heff_2edriver_2edefKind(heff_dup(v_c_240), heff_dup(v_k_241))))));
  V v_t_243 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_globals);
  V v_t_244 = (g_heff_2eglobals_2elookupEntry(v_t_243, heff_dup(v_k_241)));
  V v_t_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_t_244);
    v_t_246 = ((V)&g_heff_2edriver_2edumpLines_str2);
    break;
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    heff_take(v_t_244, 1ULL);
    v_t_246 = ({ V b_0 = heff_get(v_e_245, LBL_tySyntax); V r_ = (g_heff_2eprint_2eshowTypeF_24s447(b_0)); heff_drop(b_0); r_; });
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_247 = heff_get(heff_get(v_c_240, LBL_top), LBL_globals);
  V v_t_248 = (g_heff_2eglobals_2elookupEntry(v_t_247, v_k_241));
  V v_t_2410;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop(v_t_248);
    v_t_2410 = ((V)&g_heff_2edriver_2edumpLines_str3);
    break;
  }
  case TAG_Just: {
    V v_e_249 = heff_field(v_t_248, 0);
    heff_take(v_t_248, 1ULL);
    v_t_2410 = ({ V b_0 = heff_get(v_e_249, LBL_syntax); V r_ = (g_heff_2eprint_2eshowTermF_24s443(b_0)); heff_drop(b_0); r_; });
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2edriver_2edumpLines_str4), v_t_2410), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2edriver_2edumpLines_str5), v_t_246), v_t_2411});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_2412});
}
V g_heff_2edriver_2edumpLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2edumpLines(a[0], a[1]);
}
Clo g_heff_2edriver_2elastChecked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2elastChecked_entry, 1, 0};

V g_heff_2edriver_2elastChecked(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_c_241)});
    }
    case TAG_Cons: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2elastChecked_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2elastChecked(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2edriver_2eshowTySx_lam0(V self, V *args);
Clo g_heff_2edriver_2eshowTySx_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eshowTySx_entry, 2, 0};

V g_heff_2edriver_2eshowTySx(V v_g_240, V v_t_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_get(v_g_240, LBL_aliases); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_m_243 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_242; V r_ = (g_prelude_2efoldl_24s510(a_0, a_1)); heff_drop(v_t_242); r_; });
  V v_r_248 = heff_clo(g_heff_2edriver_2eshowTySx_lam0, 1, 1, (V[]){v_m_243});
  V v_t_249 = (g_heff_2erename_2erkOf(v_r_248));
  V v_t_2410 = heff_tr(heff_apply(heff_get(v_t_249, LBL_ty), 1, (V[]){v_t_241}));
  return ({ V a_0 = MK_INT(0LL); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2410; V r_ = (g_heff_2epsurface_2etyF_24s96_24s317(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
}
V g_heff_2edriver_2eshowTySx_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eshowTySx(a[0], a[1]);
}
V g_heff_2edriver_2eshowTySx_lam0(V self, V *args) {
  V v_k_244 = args[0];
  V v_m_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_d_245 = (g_heff_2erename_2edescribeKey(heff_dup(v_k_244)));
  V v_x2_246 = ({ V a_0 = v_k_244; V a_1 = v_m_243; V r_ = (g_map_2elookup_24s8(a_0, a_1)); heff_drop(v_m_243); r_; });
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nothing: {
    heff_drop(v_x2_246);
    return v_d_245;
  }
  case TAG_Just: {
    V v_x_247 = heff_field(v_x2_246, 0);
    heff_take(v_x2_246, 1ULL);
    heff_drop(v_d_245);
    return v_x_247;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2edriver_2eexpectLineAt_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2edriver_2eexpectLineAt_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {45, 45, 32, 62, 62, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eexpectLineAt_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2edriver_2eexpectLineAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eexpectLineAt_entry, 3, 0};

V g_heff_2edriver_2eexpectLineAt(V v_src_240, V v_i_241, V v_line_242) {
top: ;
  V v_t_243 = heff_intLt(v_i_241, heff_strLength(v_src_240));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_t_243);
    V v_t_244 = heff_strEq(heff_strSlice(heff_dup(v_line_242), MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2edriver_2eexpectLineAt_str0));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_t_244);
      V v_t_245 = heff_strEq(heff_strSlice(heff_dup(v_line_242), MK_INT(0LL), MK_INT(6LL)), ((V)&g_heff_2edriver_2eexpectLineAt_str1));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_line_242);
        heff_drop(v_t_245);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        heff_drop(v_t_245);
        V v_s_246 = heff_strSlice(heff_dup(v_line_242), MK_INT(2LL), heff_strLength(heff_dup(v_line_242)));
        V v_t_247 = (g_prelude_2eskipSpaces(heff_dup(v_s_246), MK_INT(0LL), MK_INT(1LL)));
        V v_t_248 = heff_intSub(heff_strLength(heff_dup(v_s_246)), MK_INT(1LL));
        V v_t_249 = (g_prelude_2eskipSpaces(heff_dup(v_s_246), v_t_248, MK_INT(-1LL)));
        V v_t_2410 = heff_strSlice(v_s_246, v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
        V v_x1_2411 = heff_strEq(v_t_2410, ((V)&g_heff_2edriver_2eexpectLineAt_str2));
        switch (heff_tag_of(v_x1_2411)) {
        case TAG_True: {
          heff_drop(v_line_242);
          heff_drop(v_x1_2411);
          return NTAG(TAG_Nothing);
        }
        case TAG_False: {
          heff_drop(v_x1_2411);
          V v_s_2412 = heff_strSlice(heff_dup(v_line_242), MK_INT(2LL), heff_strLength(v_line_242));
          V v_t_2413 = (g_prelude_2eskipSpaces(heff_dup(v_s_2412), MK_INT(0LL), MK_INT(1LL)));
          V v_t_2414 = heff_intSub(heff_strLength(heff_dup(v_s_2412)), MK_INT(1LL));
          V v_t_2415 = (g_prelude_2eskipSpaces(heff_dup(v_s_2412), v_t_2414, MK_INT(-1LL)));
          V v_t_2416 = heff_strSlice(v_s_2412, v_t_2413, heff_intAdd(v_t_2415, MK_INT(1LL)));
          return heff_tag(TAG_Just, 1, (V[]){v_t_2416});
        }
        default: return heff_nomatch(v_x1_2411);
        }
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    case TAG_False: {
      heff_drop(v_line_242);
      heff_drop(v_t_244);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_False: {
    heff_drop(v_line_242);
    heff_drop(v_t_243);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2edriver_2eexpectLineAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eexpectLineAt(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eexpectLine_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2edriver_2eexpectLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eexpectLine_entry, 2, 0};

V g_heff_2edriver_2eexpectLine(V v_src_240, V v_i_241) {
top: ;
  V v_t_242 = (g_prelude_2eindexFrom(((V)&g_heff_2edriver_2eexpectLine_str0), heff_dup(v_src_240), heff_dup(v_i_241)));
  V v_t_244;
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_t_242);
    v_t_244 = heff_strLength(heff_dup(v_src_240));
    break;
  }
  case TAG_Just: {
    V v_j_243 = heff_field(v_t_242, 0);
    heff_take(v_t_242, 1ULL);
    v_t_244 = v_j_243;
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_s_245 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), v_t_244);
  V v_t_246 = (g_prelude_2eskipSpaces(heff_dup(v_s_245), MK_INT(0LL), MK_INT(1LL)));
  V v_t_247 = heff_intSub(heff_strLength(heff_dup(v_s_245)), MK_INT(1LL));
  V v_t_248 = (g_prelude_2eskipSpaces(heff_dup(v_s_245), v_t_247, MK_INT(-1LL)));
  V v_t_249 = heff_strSlice(v_s_245, v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
  return (g_heff_2edriver_2eexpectLineAt(v_src_240, v_i_241, v_t_249));
}
V g_heff_2edriver_2eexpectLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eexpectLine(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eexpectGo_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2edriver_2eexpectGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eexpectGo_entry, 3, 0};

V g_heff_2edriver_2eexpectGo(V v_src_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = (g_heff_2edriver_2eexpectLine(heff_dup(v_src_240), heff_dup(v_i_241)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_src_240);
    heff_drop(v_t_243);
    return heff_rec(2, shape_169_309, (V[]){v_acc_242, v_i_241});
  }
  case TAG_Just: {
    V v_l_244 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    V v_a_245 = heff_strLength(heff_dup(v_src_240));
    V v_t_246 = (g_prelude_2eindexFrom(((V)&g_heff_2edriver_2eexpectGo_str0), heff_dup(v_src_240), v_i_241));
    V v_t_248;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop(v_t_246);
      v_t_248 = heff_strLength(heff_dup(v_src_240));
      break;
    }
    case TAG_Just: {
      V v_j_247 = heff_field(v_t_246, 0);
      heff_take(v_t_246, 1ULL);
      v_t_248 = v_j_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_b_249 = heff_intAdd(v_t_248, MK_INT(1LL));
    V v_t_2410 = heff_intLe(heff_dup(v_a_245), heff_dup(v_b_249));
    V v_t_2411;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      heff_drop(v_b_249);
      heff_drop(v_t_2410);
      v_t_2411 = v_a_245;
      break;
    }
    case TAG_False: {
      heff_drop(v_a_245);
      heff_drop(v_t_2410);
      v_t_2411 = v_b_249;
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_l_244, NTAG(TAG_Nil)});
    V v_t_2413 = (g_prelude_2econcatList(v_acc_242, v_t_2412));
    V t_0 = v_src_240;
    V t_1 = v_t_2411;
    V t_2 = v_t_2413;
    v_src_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2edriver_2eexpectGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eexpectGo(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eexpectation_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eexpectation_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eexpectation_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2edriver_2eexpectation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eexpectation_entry, 2, 0};

V g_heff_2edriver_2eexpectation(V v_src_240, V v_end_241) {
top: ;
  V v_a_242 = heff_strLength(heff_dup(v_src_240));
  V v_t_243 = (g_prelude_2eindexFrom(((V)&g_heff_2edriver_2eexpectation_str0), heff_dup(v_src_240), heff_dup(v_end_241)));
  V v_t_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_t_243);
    v_t_245 = heff_strLength(heff_dup(v_src_240));
    break;
  }
  case TAG_Just: {
    V v_j_244 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    v_t_245 = v_j_244;
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_b_246 = heff_intAdd(v_t_245, MK_INT(1LL));
  V v_t_247 = heff_intLe(heff_dup(v_a_242), heff_dup(v_b_246));
  V v_start_248;
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_b_246);
    heff_drop(v_t_247);
    v_start_248 = v_a_242;
    break;
  }
  case TAG_False: {
    heff_drop(v_a_242);
    heff_drop(v_t_247);
    v_start_248 = v_b_246;
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_a_249 = heff_strLength(heff_dup(v_src_240));
  V v_t_2410 = (g_prelude_2eindexFrom(((V)&g_heff_2edriver_2eexpectation_str1), heff_dup(v_src_240), v_end_241));
  V v_t_2412;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    heff_drop(v_t_2410);
    v_t_2412 = heff_strLength(heff_dup(v_src_240));
    break;
  }
  case TAG_Just: {
    V v_j_2411 = heff_field(v_t_2410, 0);
    heff_take(v_t_2410, 1ULL);
    v_t_2412 = v_j_2411;
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_b_2413 = heff_intAdd(v_t_2412, MK_INT(1LL));
  V v_t_2414 = heff_intLe(heff_dup(v_a_249), heff_dup(v_b_2413));
  V v_t_2415;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    heff_drop(v_b_2413);
    heff_drop(v_t_2414);
    v_t_2415 = v_a_249;
    break;
  }
  case TAG_False: {
    heff_drop(v_a_249);
    heff_drop(v_t_2414);
    v_t_2415 = v_b_2413;
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_r_2416 = (g_heff_2edriver_2eexpectGo(v_src_240, v_t_2415, NTAG(TAG_Nil)));
  V v_t_2417 = heff_get(heff_dup(v_r_2416), LBL_lines);
  V v_t_2424;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nil: {
    heff_drop(v_t_2417);
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    heff_take(v_t_2417, 0ULL);
    V v_t_2420 = heff_get(heff_dup(v_r_2416), LBL_lines);
    V v_t_2423;
    switch (heff_tag_of(v_t_2420)) {
    case TAG_Nil: {
      heff_drop(v_t_2420);
      v_t_2423 = ((V)&g_heff_2edriver_2eexpectation_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_t_2420, 0);
      V v_xs_2422 = heff_field(v_t_2420, 1);
      heff_take(v_t_2420, 3ULL);
      v_t_2423 = ({ V a_0 = v_x_2421; V a_1 = v_xs_2422; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_t_2420);
    }
    v_t_2424 = heff_tag(TAG_Just, 1, (V[]){v_t_2423});
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  return heff_rec(3, shape_87_102_324, (V[]){v_t_2424, v_start_248, heff_get(v_r_2416, LBL_stop)});
}
V g_heff_2edriver_2eexpectation_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eexpectation(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eevalWatch_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2edriver_2eevalWatch_str1 = {{0x80000000u, K_STR, 0}, 11, 11, {60, 97, 98, 97, 110, 100, 111, 110, 101, 100, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2edriver_2eevalWatch_str2 = {{0x80000000u, K_STR, 0}, 10, 10, {60, 100, 105, 118, 101, 114, 103, 101, 100, 62}};
V g_heff_2edriver_2eevalWatch_lam0(V self, V *args);
V g_heff_2edriver_2eevalWatch_lam1(V self, V *args);
Clo g_heff_2edriver_2eevalWatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eevalWatch_entry, 2, 0};

V g_heff_2edriver_2eevalWatch(V v_name_240, V v_g_241) {
top: ;
  V v_t_246 = ({ V a_0 = heff_clo(g_heff_2edriver_2eevalWatch_lam0, 2, 1, (V[]){heff_dup(v_g_241)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get(v_g_241, LBL_order); V r_ = (g_prelude_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_it_248 = (g_heff_2einterp_2eevalGlobalsGo(heff_clo(g_heff_2edriver_2eevalWatch_lam1, 1, 1, (V[]){v_name_240}), heff_dup(g_map_2eempty_get()), v_t_246, NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_248)) {
  case TAG_Nil: {
    heff_drop(v_it_248);
    return ((V)&g_heff_2edriver_2eevalWatch_str0);
  }
  case TAG_Cons: {
    V v_it1_249 = heff_field(v_it_248, 0);
    heff_take(v_it_248, 1ULL);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_MkPair: {
      V v_res_2412 = heff_field(v_it1_249, 1);
      heff_take(v_it1_249, 2ULL);
      switch (heff_tag_of(v_res_2412)) {
      case TAG_RSucceeded: {
        V v_v_2413 = heff_field(v_res_2412, 0);
        heff_take(v_res_2412, 1ULL);
        return ({ V b_0 = NTAG(TAG_False); V a_1 = v_v_2413; V r_ = (g_heff_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); heff_drop(v_v_2413); r_; });
      }
      case TAG_RAbandoned: {
        heff_drop(v_res_2412);
        return ((V)&g_heff_2edriver_2eevalWatch_str1);
      }
      case TAG_RDiverged: {
        heff_drop(v_res_2412);
        return ((V)&g_heff_2edriver_2eevalWatch_str2);
      }
      default: return heff_nomatch(v_res_2412);
      }
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  default: return heff_nomatch(v_it_248);
  }
}
V g_heff_2edriver_2eevalWatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eevalWatch(a[0], a[1]);
}
V g_heff_2edriver_2eevalWatch_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_k_243 = args[1];
  V v_g_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = ({ V a_0 = heff_dup(v_k_243); V b_1 = heff_get(v_g_241, LBL_entries); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_k_243);
    heff_drop(v_t_244);
    return v_acc_242;
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    heff_take(v_t_244, 1ULL);
    return heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_k_243, v_e_245}), v_acc_242});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2edriver_2eevalWatch_lam1(V self, V *args) {
  V v_k_247 = args[0];
  V v_name_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(v_k_247, v_name_240);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2edriver_2ereadExpRead_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {62, 32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2edriver_2ereadExpRead_str1 = {{0x80000000u, K_STR, 0}, 13, 13, {62, 32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110}};
Clo g_heff_2edriver_2ereadExpRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ereadExpRead_entry, 2, 0};

V g_heff_2edriver_2ereadExpRead(V v_g_240, V v_r_241) {
top: ;
  V v_t_242 = heff_get(heff_dup(v_r_241), LBL_diags);
  V v_x1_245;
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    heff_drop(v_t_242);
    v_x1_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take(v_t_242, 0ULL);
    v_x1_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_246;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_True: {
    heff_drop(v_x1_245);
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    heff_drop(v_x1_245);
    v_t_246 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_g_240);
    heff_drop(v_r_241);
    heff_drop(v_t_246);
    return NTAG(TAG_Nothing);
  }
  case TAG_False: {
    heff_drop(v_t_246);
    V v_t_247 = heff_rec(9, shape_110_58_146_29_359_319_300_133_331, (V[]){heff_dup(v_g_240), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2emap(heff_dup(g_heff_2epresyntax_2eclassify_get()), heff_get(v_r_241, LBL_decls)));
    V v_t_249 = ({ V a_0 = v_t_247; V a_1 = v_t_248; V r_ = (g_heff_2etoplevel_2etopGo_24s488(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_t_2410 = heff_get(heff_dup(v_t_249), LBL_diags);
    V v_x1_2413;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nil: {
      heff_drop(v_t_2410);
      v_x1_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      heff_take(v_t_2410, 0ULL);
      v_x1_2413 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_True: {
      heff_drop(v_x1_2413);
      V v_t_2414 = heff_get(v_t_249, LBL_watches);
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nil: {
        heff_drop(v_g_240);
        heff_drop(v_t_2414);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_t_2414, 0);
        heff_take(v_t_2414, 1ULL);
        V v_t_2417 = (g_heff_2eglobals_2eaddEntry(((V)&g_heff_2edriver_2ereadExpRead_str0), heff_get(v_x_2415, LBL_entry), v_g_240));
        return heff_tag(TAG_Just, 1, (V[]){(g_heff_2edriver_2eevalWatch(((V)&g_heff_2edriver_2ereadExpRead_str1), v_t_2417))});
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    case TAG_False: {
      heff_drop(v_g_240);
      heff_drop(v_t_249);
      heff_drop(v_x1_2413);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x1_2413);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2edriver_2ereadExpRead_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2ereadExpRead(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2edriver_2eholdsOf_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {45, 45, 32, 62, 62, 62, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2edriver_2eholdsOf_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2edriver_2eholdsOf_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 10}};
V g_heff_2edriver_2eholdsOf_lam0(V self, V *args);
Clo g_heff_2edriver_2eholdsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eholdsOf_entry, 4, 0};

V g_heff_2edriver_2eholdsOf(V v_g_240, V v_ty_241, V v_value_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_g_240);
    heff_drop(v_ty_241);
    heff_drop(v_value_242);
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_t_245 = heff_strEq(heff_dup(v_e_244), heff_dup(v_value_242));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_g_240);
      heff_drop(v_ty_241);
      heff_drop(v_value_242);
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      heff_drop(v_t_245);
      V v_t_249 = heff_rec(3, shape_149_98_161, (V[]){heff_clo(g_heff_2edriver_2eholdsOf_lam0, 1, 1, (V[]){heff_dup(v_g_240)}), heff_dup(g_heff_2efixity_2eemptyFixities_get()), NTAG(TAG_False)});
      V v_t_2410 = heff_strAppend(((V)&g_heff_2edriver_2eholdsOf_str0), heff_strAppend(heff_dup(v_e_244), heff_strAppend(((V)&g_heff_2edriver_2eholdsOf_str1), heff_strAppend(v_ty_241, ((V)&g_heff_2edriver_2eholdsOf_str2)))));
      V v_t_2411 = (g_heff_2esurface_2ereadProgramWith(v_t_249, v_t_2410));
      V v_t_2412 = (g_heff_2edriver_2ereadExpRead(v_g_240, v_t_2411));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nothing: {
        heff_drop(v_value_242);
        heff_drop(v_t_2412);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_v_2413 = heff_field(v_t_2412, 0);
        heff_take(v_t_2412, 1ULL);
        return heff_strEq(v_v_2413, v_value_242);
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2edriver_2eholdsOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eholdsOf(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2edriver_2eholdsOf_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_247 = (g_heff_2eglobals_2elookupEntry(v_g_240, v_x_246));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_t_247);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take(v_t_247, 0ULL);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2edriver_2emkWatchInfo_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {45, 45, 32, 62, 62, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2emkWatchInfo_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2edriver_2emkWatchInfo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2emkWatchInfo_entry, 5, 0};

V g_heff_2edriver_2emkWatchInfo(V v_c_240, V v_w_241, V v_value_242, V v_ex_243, V v_ty_244) {
top: ;
  V v_t_245 = heff_get(heff_get(heff_dup(v_w_241), LBL_span), LBL_start);
  V v_t_246 = heff_get(heff_get(heff_dup(v_w_241), LBL_span), LBL_end);
  V v_t_247 = heff_get(heff_get(heff_dup(v_w_241), LBL_span), LBL_start);
  V v_t_248 = heff_get(heff_get(v_w_241, LBL_span), LBL_end);
  V v_s_249 = heff_strSlice(heff_get(heff_dup(v_c_240), LBL_source), v_t_247, v_t_248);
  V v_t_2410 = (g_prelude_2eskipSpaces(heff_dup(v_s_249), MK_INT(0LL), MK_INT(1LL)));
  V v_t_2411 = heff_intSub(heff_strLength(heff_dup(v_s_249)), MK_INT(1LL));
  V v_t_2412 = (g_prelude_2eskipSpaces(heff_dup(v_s_249), v_t_2411, MK_INT(-1LL)));
  V v_s_2413 = heff_strSlice(v_s_249, v_t_2410, heff_intAdd(v_t_2412, MK_INT(1LL)));
  V v_t_2414 = heff_strEq(heff_strSlice(heff_dup(v_s_2413), MK_INT(0LL), MK_INT(6LL)), ((V)&g_heff_2edriver_2emkWatchInfo_str0));
  V v_s_2415;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    heff_drop(v_t_2414);
    v_s_2415 = heff_strSlice(heff_dup(v_s_2413), MK_INT(6LL), heff_strLength(v_s_2413));
    break;
  }
  case TAG_False: {
    heff_drop(v_s_2413);
    heff_drop(v_t_2414);
    v_s_2415 = ((V)&g_heff_2edriver_2emkWatchInfo_str1);
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_t_2416 = (g_prelude_2eskipSpaces(heff_dup(v_s_2415), MK_INT(0LL), MK_INT(1LL)));
  V v_t_2417 = heff_intSub(heff_strLength(heff_dup(v_s_2415)), MK_INT(1LL));
  V v_t_2418 = (g_prelude_2eskipSpaces(heff_dup(v_s_2415), v_t_2417, MK_INT(-1LL)));
  V v_t_2419 = heff_strSlice(v_s_2415, v_t_2416, heff_intAdd(v_t_2418, MK_INT(1LL)));
  V v_t_2420 = heff_get(heff_get(v_c_240, LBL_top), LBL_globals);
  V v_t_2421 = ({ V a_0 = v_t_2420; V a_1 = heff_dup(v_ty_244); V a_2 = heff_dup(v_value_242); V b_3 = heff_get(heff_dup(v_ex_243), LBL_expected); V r_ = (g_heff_2edriver_2eholdsOf(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  return heff_rec(9, shape_102_324_89_336_352_87_122_85_86, (V[]){v_t_245, v_t_246, v_t_2419, v_ty_244, v_value_242, heff_get(heff_dup(v_ex_243), LBL_expected), v_t_2421, heff_get(heff_dup(v_ex_243), LBL_from), heff_get(v_ex_243, LBL_to)});
}
V g_heff_2edriver_2emkWatchInfo_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2emkWatchInfo(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2edriver_2ewatchInfo_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2edriver_2ewatchInfo_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {62, 32}};
Clo g_heff_2edriver_2ewatchInfo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ewatchInfo_entry, 3, 0};

V g_heff_2edriver_2ewatchInfo(V v_c_240, V v_i_241, V v_w_242) {
top: ;
  V v_t_243 = heff_strAppend(((V)&g_heff_2edriver_2ewatchInfo_str0), heff_intShow(heff_dup(v_i_241)));
  V v_t_244 = heff_strAppend(((V)&g_heff_2edriver_2ewatchInfo_str1), heff_intShow(v_i_241));
  V v_t_245 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_globals);
  V v_t_246 = (g_heff_2eglobals_2eaddEntry(v_t_244, heff_get(heff_dup(v_w_242), LBL_entry), v_t_245));
  V v_t_247 = (g_heff_2edriver_2eevalWatch(v_t_243, v_t_246));
  V v_t_248 = heff_get(heff_get(heff_dup(v_w_242), LBL_span), LBL_end);
  V v_t_249 = (g_heff_2edriver_2eexpectation(heff_get(heff_dup(v_c_240), LBL_source), v_t_248));
  V v_t_2410 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_globals);
  V v_t_2411 = heff_get(heff_get(heff_dup(v_w_242), LBL_entry), LBL_type_5f);
  V v_t_2412 = (g_heff_2ereadback_2ereadbTypeF_24s197(MK_INT(0LL), v_t_2411));
  V v_t_2413 = (g_heff_2edriver_2eshowTySx(v_t_2410, v_t_2412));
  return (g_heff_2edriver_2emkWatchInfo(v_c_240, v_w_242, v_t_247, v_t_249, v_t_2413));
}
V g_heff_2edriver_2ewatchInfo_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2ewatchInfo(a[0], a[1], a[2]);
}
Clo g_heff_2edriver_2ewatchesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ewatchesGo_entry, 3, 0};

V g_heff_2edriver_2ewatchesGo(V v_c_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_i_241);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_w_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse(v_x3_242, 3ULL);
    V v_t_245 = (g_heff_2edriver_2ewatchInfo(heff_dup(v_c_240), heff_dup(v_i_241), v_w_243));
    return heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_heff_2edriver_2ewatchesGo(v_c_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_rest_244))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2edriver_2ewatchesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2ewatchesGo(a[0], a[1], a[2]);
}
V g_heff_2edriver_2eownerOf_lam1(V self, V *args);
V g_heff_2edriver_2eownerOf_lam0(V self, V *args);
Clo g_heff_2edriver_2eownerOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eownerOf_entry, 2, 0};

V g_heff_2edriver_2eownerOf(V v_c_240, V v_from_241) {
top: ;
  V v_t_242 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_tests);
  V v_xs_2412 = (g_prelude_2efilter(heff_clo(g_heff_2edriver_2eownerOf_lam0, 1, 2, (V[]){v_from_241, v_c_240}), v_t_242));
  V v_x1_2413 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2412));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Nil: {
    heff_drop(v_x1_2413);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x1_2413, 0);
    heff_take(v_x1_2413, 1ULL);
    return heff_tag(TAG_Just, 1, (V[]){heff_get(v_x_2414, LBL_name)});
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_heff_2edriver_2eownerOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eownerOf(a[0], a[1]);
}
V g_heff_2edriver_2eownerOf_lam1(V self, V *args) {
  V v_p_248 = args[0];
  V v_m_243 = heff_dup(heff_env(self)[0]);
  V v_from_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_249 = heff_get(heff_get(v_m_243, LBL_span), LBL_start);
  V v_t_2410 = heff_intLt(v_t_249, heff_dup(v_p_248));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_t_2410);
    return heff_intLt(v_p_248, v_from_241);
  }
  case TAG_False: {
    heff_drop(v_p_248);
    heff_drop(v_from_241);
    heff_drop(v_t_2410);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2edriver_2eownerOf_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_from_241 = heff_dup(heff_env(self)[0]);
  V v_c_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_244 = heff_get(heff_get(heff_dup(v_m_243), LBL_span), LBL_start);
  V v_t_245 = heff_intLt(v_t_244, heff_dup(v_from_241));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_t_245);
    V v_t_246 = heff_get(heff_get(v_c_240, LBL_top), LBL_spans);
    V v_t_247 = (g_prelude_2emap_24s511(v_t_246));
    V v_x1_2411 = ({ V a_0 = heff_clo(g_heff_2edriver_2eownerOf_lam1, 1, 2, (V[]){v_m_243, v_from_241}); V a_1 = v_t_247; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_t_247); r_; });
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_True: {
      heff_drop(v_x1_2411);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      heff_drop(v_x1_2411);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
  case TAG_False: {
    heff_drop(v_m_243);
    heff_drop(v_from_241);
    heff_drop(v_c_240);
    heff_drop(v_t_245);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_245);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eevalPick_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eevalPick_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2edriver_2eevalPick_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {60, 97, 98, 97, 110, 100, 111, 110, 101, 100, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2edriver_2eevalPick_str3 = {{0x80000000u, K_STR, 0}, 10, 10, {60, 100, 105, 118, 101, 114, 103, 101, 100, 62}};
Clo g_heff_2edriver_2eevalPick_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eevalPick_entry, 2, 0};

V g_heff_2edriver_2eevalPick(V v_results_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse(v_x2_241, 3ULL);
    V v_t_244 = (g_prelude_2elookupBy(heff_dup(g_strEq_get()), heff_get(heff_dup(v_o_242), LBL_key), v_results_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_o_242);
      heff_drop(v_ru_24x2_241_24Cons);
      heff_drop(v_t_244);
      V t_0 = v_results_240;
      V t_1 = v_rest_243;
      v_results_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_r_245 = heff_field(v_t_244, 0);
      heff_take(v_t_244, 1ULL);
      V v_x_246 = heff_get(v_o_242, LBL_name);
      V v_t_247 = (g_heff_2epsurface_2eisOperator(heff_dup(v_x_246)));
      V v_t_248;
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_t_247);
        v_t_248 = heff_strAppend(((V)&g_heff_2edriver_2eevalPick_str0), heff_strAppend(v_x_246, ((V)&g_heff_2edriver_2eevalPick_str1)));
        break;
      }
      case TAG_False: {
        heff_drop(v_t_247);
        v_t_248 = v_x_246;
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      V v_t_2410;
      switch (heff_tag_of(v_r_245)) {
      case TAG_RSucceeded: {
        V v_v_249 = heff_field(v_r_245, 0);
        heff_take(v_r_245, 1ULL);
        v_t_2410 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_v_249; V r_ = (g_heff_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); heff_drop(v_v_249); r_; });
        break;
      }
      case TAG_RAbandoned: {
        heff_drop(v_r_245);
        v_t_2410 = ((V)&g_heff_2edriver_2eevalPick_str2);
        break;
      }
      case TAG_RDiverged: {
        heff_drop(v_r_245);
        v_t_2410 = ((V)&g_heff_2edriver_2eevalPick_str3);
        break;
      }
      default: heff_nomatch(v_r_245);
      }
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec(2, shape_190_352, (V[]){v_t_248, v_t_2410}), (g_heff_2edriver_2eevalPick(v_results_240, v_rest_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2edriver_2eevalPick_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eevalPick(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2edriver_2eevaluate_lam0(V self, V *args);
V g_heff_2edriver_2eevaluate_lam1(V self, V *args);
Clo g_heff_2edriver_2eevaluate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eevaluate_entry, 1, 0};

V g_heff_2edriver_2eevaluate(V v_c_240) {
top: ;
  V v_gs_241 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_globals);
  V v_t_246 = ({ V a_0 = heff_clo(g_heff_2edriver_2eevaluate_lam0, 2, 1, (V[]){heff_dup(v_gs_241)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get(v_gs_241, LBL_order); V r_ = (g_prelude_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2410 = (g_heff_2einterp_2eevalGlobalsGo(heff_clo(g_heff_2edriver_2eevaluate_lam1, 1, 1, (V[]){heff_dup(v_c_240)}), heff_dup(g_map_2eempty_get()), v_t_246, NTAG(TAG_Nil)));
  return ({ V a_0 = v_t_2410; V a_1 = heff_get(v_c_240, LBL_own); V r_ = (g_heff_2edriver_2eevalPick(a_0, a_1)); heff_drop(v_t_2410); r_; });
}
V g_heff_2edriver_2eevaluate_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eevaluate(a[0]);
}
V g_heff_2edriver_2eevaluate_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_k_243 = args[1];
  V v_gs_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = ({ V a_0 = heff_dup(v_k_243); V b_1 = heff_get(v_gs_241, LBL_entries); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_k_243);
    heff_drop(v_t_244);
    return v_acc_242;
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    heff_take(v_t_244, 1ULL);
    return heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_k_243, v_e_245}), v_acc_242});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2edriver_2eevaluate_lam1(V self, V *args) {
  V v_k_247 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_xs_248 = (g_prelude_2emap_24s508(heff_get(v_c_240, LBL_own)));
  V v_t_249 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){v_k_247}));
  return ({ V a_0 = v_t_249; V a_1 = v_xs_248; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_xs_248); r_; });
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2epromoteAt_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2epromoteAt_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2epromoteAt_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2epromoteAt_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2epromoteAt_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2epromoteAt_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2edriver_2epromoteAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2epromoteAt_entry, 4, 0};

V g_heff_2edriver_2epromoteAt(V v_s_240, V v_from_241, V v_to_242, V v_lines_243) {
top: ;
  V v_t_244 = heff_strEq(heff_strSlice(heff_dup(v_s_240), MK_INT(0LL), heff_dup(v_from_241)), ((V)&g_heff_2edriver_2epromoteAt_str0));
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    v_t_247 = ((V)&g_heff_2edriver_2epromoteAt_str1);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_244);
    V v_t_245 = heff_strSlice(heff_dup(v_s_240), heff_intSub(heff_dup(v_from_241), MK_INT(1LL)), heff_dup(v_from_241));
    V v_t_246 = heff_strEq(v_t_245, ((V)&g_heff_2edriver_2epromoteAt_str2));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_t_246);
      v_t_247 = ((V)&g_heff_2edriver_2epromoteAt_str3);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_246);
      v_t_247 = ((V)&g_heff_2edriver_2epromoteAt_str4);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_x2_248 = (g_prelude_2emap_24s512(v_lines_243));
  V v_t_2411;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    heff_drop(v_x2_248);
    v_t_2411 = ((V)&g_heff_2edriver_2epromoteAt_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    heff_take(v_x2_248, 3ULL);
    v_t_2411 = ({ V a_0 = v_x_249; V a_1 = v_xs_2410; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2410); r_; });
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  V v_t_2412 = heff_strSlice(heff_dup(v_s_240), v_to_242, heff_strLength(heff_dup(v_s_240)));
  return heff_strAppend(heff_strSlice(v_s_240, MK_INT(0LL), v_from_241), heff_strAppend(v_t_247, heff_strAppend(v_t_2411, v_t_2412)));
}
V g_heff_2edriver_2epromoteAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2epromoteAt(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2edriver_2eisTestTy_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {99, 104, 101, 99, 107, 46, 84, 101, 115, 116}};
Clo g_heff_2edriver_2eisTestTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eisTestTy_entry, 1, 0};

V g_heff_2edriver_2eisTestTy(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SU: {
    return NTAG(TAG_False);
  }
  case TAG_SDecode: {
    V v_t_242 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_t_242)) {
    case TAG_SLocal: {
      return NTAG(TAG_False);
    }
    case TAG_SGlobal: {
      V v_k_244 = heff_field(v_t_242, 0);
      return heff_strEq(heff_dup(v_k_244), ((V)&g_heff_2edriver_2eisTestTy_str0));
    }
    case TAG_SCode: {
      return NTAG(TAG_False);
    }
    case TAG_SApp: {
      return NTAG(TAG_False);
    }
    case TAG_SLam: {
      return NTAG(TAG_False);
    }
    case TAG_SCons: {
      return NTAG(TAG_False);
    }
    case TAG_SProj: {
      return NTAG(TAG_False);
    }
    case TAG_STag: {
      return NTAG(TAG_False);
    }
    case TAG_SMatch: {
      return NTAG(TAG_False);
    }
    case TAG_SSpecialize: {
      return NTAG(TAG_False);
    }
    case TAG_SIs: {
      return NTAG(TAG_False);
    }
    case TAG_SOpaque: {
      return NTAG(TAG_False);
    }
    case TAG_SAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      return NTAG(TAG_False);
    }
    case TAG_SFix: {
      return NTAG(TAG_False);
    }
    case TAG_SImplicit: {
      return NTAG(TAG_False);
    }
    case TAG_SPrim: {
      return NTAG(TAG_False);
    }
    case TAG_SMetaApp: {
      return NTAG(TAG_False);
    }
    case TAG_SLitInt: {
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SLitString: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_SFunction: {
    return NTAG(TAG_False);
  }
  case TAG_SRecord: {
    return NTAG(TAG_False);
  }
  case TAG_SSum: {
    return NTAG(TAG_False);
  }
  case TAG_SIsTy: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimInt: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimString: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimArray: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2eisTestTy_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eisTestTy(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2edriver_2efieldV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2efieldV_entry, 2, 0};

V g_heff_2edriver_2efieldV(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  case TAG_VCons: {
    V v_fs_243 = heff_field(v_x1_240, 0);
    V v_t_244 = ({ V a_0 = v_x_241; V b_1 = heff_get(heff_dup(v_fs_243), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_t_244);
      return NTAG(TAG_VErased);
    }
    case TAG_Just: {
      V v_i_245 = heff_field(v_t_244, 0);
      heff_take(v_t_244, 1ULL);
      V v_xs_246 = heff_get(heff_dup(v_fs_243), LBL_values);
      V v_t_247 = heff_intLe(MK_INT(0LL), heff_dup(v_i_245));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_t_247);
        V v_t_248 = heff_intLt(heff_dup(v_i_245), heff_arrayLength(heff_dup(v_xs_246)));
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          heff_drop(v_t_248);
          V v_v_249 = heff_arrayIndex(v_xs_246, v_i_245);
          return v_v_249;
        }
        case TAG_False: {
          heff_drop(v_i_245);
          heff_drop(v_xs_246);
          heff_drop(v_t_248);
          return NTAG(TAG_VErased);
        }
        default: return heff_nomatch(v_t_248);
        }
      }
      case TAG_False: {
        heff_drop(v_i_245);
        heff_drop(v_xs_246);
        heff_drop(v_t_247);
        return NTAG(TAG_VErased);
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_VTag: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  case TAG_VInt: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  case TAG_VFloat: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  case TAG_VStr: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  case TAG_VArr: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  case TAG_VErased: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2efieldV_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2efieldV(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2elistOfV_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2elistOfV_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2elistOfV_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2elistOfV_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2elistOfV_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2elistOfV_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2elistOfV_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2edriver_2elistOfV_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {67, 111, 110, 115}};
Clo g_heff_2edriver_2elistOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2elistOfV_entry, 1, 0};

V g_heff_2edriver_2elistOfV(V v_v_240) {
top: ;
  V v_t_249;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_249 = ((V)&g_heff_2edriver_2elistOfV_str0);
    break;
  }
  case TAG_VCons: {
    v_t_249 = ((V)&g_heff_2edriver_2elistOfV_str1);
    break;
  }
  case TAG_VTag: {
    V v_x_243 = heff_dup(heff_field(v_v_240, 0));
    v_t_249 = v_x_243;
    break;
  }
  case TAG_VInt: {
    v_t_249 = ((V)&g_heff_2edriver_2elistOfV_str2);
    break;
  }
  case TAG_VFloat: {
    v_t_249 = ((V)&g_heff_2edriver_2elistOfV_str3);
    break;
  }
  case TAG_VStr: {
    v_t_249 = ((V)&g_heff_2edriver_2elistOfV_str4);
    break;
  }
  case TAG_VArr: {
    v_t_249 = ((V)&g_heff_2edriver_2elistOfV_str5);
    break;
  }
  case TAG_VErased: {
    v_t_249 = ((V)&g_heff_2edriver_2elistOfV_str6);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  V v_t_2410 = heff_strEq(v_t_249, ((V)&g_heff_2edriver_2elistOfV_str7));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_t_2410);
    V v_t_2419;
    switch (heff_tag_of(v_v_240)) {
    case TAG_VFun: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2414 = heff_dup(heff_field(v_v_240, 1));
      v_t_2419 = v_vs_2414;
      break;
    }
    case TAG_VInt: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_240);
    }
    V v_x1_2420 = (g_prelude_2edrop(MK_INT(0LL), v_t_2419));
    V v_x2_2423;
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nil: {
      heff_drop(v_x1_2420);
      v_x2_2423 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x1_2420, 0);
      heff_take(v_x1_2420, 1ULL);
      v_x2_2423 = heff_tag(TAG_Just, 1, (V[]){v_x_2421});
      break;
    }
    default: heff_nomatch(v_x1_2420);
    }
    V v_t_2425;
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_Nothing: {
      heff_drop(v_x2_2423);
      v_t_2425 = NTAG(TAG_VErased);
      break;
    }
    case TAG_Just: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      heff_take(v_x2_2423, 1ULL);
      v_t_2425 = v_x_2424;
      break;
    }
    default: heff_nomatch(v_x2_2423);
    }
    V v_t_2434;
    switch (heff_tag_of(v_v_240)) {
    case TAG_VFun: {
      heff_take(v_v_240, 0ULL);
      v_t_2434 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      heff_take(v_v_240, 0ULL);
      v_t_2434 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2429 = heff_field(v_v_240, 1);
      heff_take(v_v_240, 2ULL);
      v_t_2434 = v_vs_2429;
      break;
    }
    case TAG_VInt: {
      heff_take(v_v_240, 0ULL);
      v_t_2434 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      heff_take(v_v_240, 0ULL);
      v_t_2434 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      heff_take(v_v_240, 0ULL);
      v_t_2434 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      heff_take(v_v_240, 0ULL);
      v_t_2434 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      heff_drop(v_v_240);
      v_t_2434 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_240);
    }
    V v_x1_2435 = (g_prelude_2edrop(MK_INT(1LL), v_t_2434));
    V v_x2_2438;
    switch (heff_tag_of(v_x1_2435)) {
    case TAG_Nil: {
      heff_drop(v_x1_2435);
      v_x2_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2436 = heff_field(v_x1_2435, 0);
      heff_take(v_x1_2435, 1ULL);
      v_x2_2438 = heff_tag(TAG_Just, 1, (V[]){v_x_2436});
      break;
    }
    default: heff_nomatch(v_x1_2435);
    }
    V v_t_2440;
    switch (heff_tag_of(v_x2_2438)) {
    case TAG_Nothing: {
      heff_drop(v_x2_2438);
      v_t_2440 = NTAG(TAG_VErased);
      break;
    }
    case TAG_Just: {
      V v_x_2439 = heff_field(v_x2_2438, 0);
      heff_take(v_x2_2438, 1ULL);
      v_t_2440 = v_x_2439;
      break;
    }
    default: heff_nomatch(v_x2_2438);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2425, (g_heff_2edriver_2elistOfV(v_t_2440))});
  }
  case TAG_False: {
    heff_drop(v_v_240);
    heff_drop(v_t_2410);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2edriver_2elistOfV_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2elistOfV(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2elabelOfV_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2elabelOfV_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2elabelOfV_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2elabelOfV_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2elabelOfV_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2elabelOfV_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2elabelOfV_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2edriver_2elabelOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2elabelOfV_entry, 1, 0};

V g_heff_2edriver_2elabelOfV(V v_v_240) {
top: ;
  V v_t_249;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VCons: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VTag: {
    V v_vs_244 = heff_field(v_v_240, 1);
    v_t_249 = heff_dup(v_vs_244);
    break;
  }
  case TAG_VInt: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VStr: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VArr: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VErased: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  V v_x1_2410 = (g_prelude_2edrop(MK_INT(0LL), v_t_249));
  V v_x2_2413;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nil: {
    heff_drop(v_x1_2410);
    v_x2_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take(v_x1_2410, 1ULL);
    v_x2_2413 = heff_tag(TAG_Just, 1, (V[]){v_x_2411});
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  V v_x1_2415;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nothing: {
    heff_drop(v_x2_2413);
    v_x1_2415 = NTAG(TAG_VErased);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    heff_take(v_x2_2413, 1ULL);
    v_x1_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  V v_t_2424;
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_VFun: {
    heff_take(v_x1_2415, 0ULL);
    v_t_2424 = ((V)&g_heff_2edriver_2elabelOfV_str0);
    break;
  }
  case TAG_VCons: {
    heff_take(v_x1_2415, 0ULL);
    v_t_2424 = ((V)&g_heff_2edriver_2elabelOfV_str1);
    break;
  }
  case TAG_VTag: {
    heff_take(v_x1_2415, 0ULL);
    v_t_2424 = ((V)&g_heff_2edriver_2elabelOfV_str2);
    break;
  }
  case TAG_VInt: {
    heff_take(v_x1_2415, 0ULL);
    v_t_2424 = ((V)&g_heff_2edriver_2elabelOfV_str3);
    break;
  }
  case TAG_VFloat: {
    heff_take(v_x1_2415, 0ULL);
    v_t_2424 = ((V)&g_heff_2edriver_2elabelOfV_str4);
    break;
  }
  case TAG_VStr: {
    V v_s_2422 = heff_field(v_x1_2415, 0);
    heff_take(v_x1_2415, 1ULL);
    v_t_2424 = v_s_2422;
    break;
  }
  case TAG_VArr: {
    heff_take(v_x1_2415, 0ULL);
    v_t_2424 = ((V)&g_heff_2edriver_2elabelOfV_str5);
    break;
  }
  case TAG_VErased: {
    heff_drop(v_x1_2415);
    v_t_2424 = ((V)&g_heff_2edriver_2elabelOfV_str6);
    break;
  }
  default: heff_nomatch(v_x1_2415);
  }
  V v_t_2433;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2433 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VCons: {
    v_t_2433 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VTag: {
    V v_vs_2428 = heff_field(v_v_240, 1);
    v_t_2433 = heff_dup(v_vs_2428);
    break;
  }
  case TAG_VInt: {
    v_t_2433 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat: {
    v_t_2433 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VStr: {
    v_t_2433 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VArr: {
    v_t_2433 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VErased: {
    v_t_2433 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  V v_x1_2434 = (g_prelude_2edrop(MK_INT(1LL), v_t_2433));
  V v_x2_2437;
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nil: {
    heff_drop(v_x1_2434);
    v_x2_2437 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2435 = heff_field(v_x1_2434, 0);
    heff_take(v_x1_2434, 1ULL);
    v_x2_2437 = heff_tag(TAG_Just, 1, (V[]){v_x_2435});
    break;
  }
  default: heff_nomatch(v_x1_2434);
  }
  V v_x1_2439;
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_Nothing: {
    heff_drop(v_x2_2437);
    v_x1_2439 = NTAG(TAG_VErased);
    break;
  }
  case TAG_Just: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    heff_take(v_x2_2437, 1ULL);
    v_x1_2439 = v_x_2438;
    break;
  }
  default: heff_nomatch(v_x2_2437);
  }
  V v_t_2448;
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_VFun: {
    heff_take(v_x1_2439, 0ULL);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take(v_x1_2439, 0ULL);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take(v_x1_2439, 0ULL);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_2444 = heff_field(v_x1_2439, 0);
    heff_take(v_x1_2439, 1ULL);
    v_t_2448 = v_i_2444;
    break;
  }
  case TAG_VFloat: {
    heff_take(v_x1_2439, 0ULL);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take(v_x1_2439, 0ULL);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take(v_x1_2439, 0ULL);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    heff_drop(v_x1_2439);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_2439);
  }
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_2424, v_t_2448});
}
V g_heff_2edriver_2elabelOfV_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2elabelOfV(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2edriver_2efailureOfV_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {74, 117, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2edriver_2efailureOfV_str15 = {{0x80000000u, K_STR, 0}, 6, 6, {68, 105, 102, 102, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str17 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str18 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str19 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str20 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str21 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str23 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str24 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str25 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str26 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str27 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str28 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str29 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str30 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str31 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str32 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str33 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str34 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str35 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efailureOfV_str36 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2edriver_2efailureOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2efailureOfV_entry, 1, 0};

V g_heff_2edriver_2efailureOfV(V v_v_240) {
top: ;
  V v_t_249;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_249 = ((V)&g_heff_2edriver_2efailureOfV_str0);
    break;
  }
  case TAG_VCons: {
    v_t_249 = ((V)&g_heff_2edriver_2efailureOfV_str1);
    break;
  }
  case TAG_VTag: {
    V v_x_243 = heff_field(v_v_240, 0);
    v_t_249 = heff_dup(v_x_243);
    break;
  }
  case TAG_VInt: {
    v_t_249 = ((V)&g_heff_2edriver_2efailureOfV_str2);
    break;
  }
  case TAG_VFloat: {
    v_t_249 = ((V)&g_heff_2edriver_2efailureOfV_str3);
    break;
  }
  case TAG_VStr: {
    v_t_249 = ((V)&g_heff_2edriver_2efailureOfV_str4);
    break;
  }
  case TAG_VArr: {
    v_t_249 = ((V)&g_heff_2edriver_2efailureOfV_str5);
    break;
  }
  case TAG_VErased: {
    v_t_249 = ((V)&g_heff_2edriver_2efailureOfV_str6);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  V v_t_2410 = heff_strEq(v_t_249, ((V)&g_heff_2edriver_2efailureOfV_str7));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_t_2410);
    V v_t_2419;
    switch (heff_tag_of(v_v_240)) {
    case TAG_VFun: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2414 = heff_field(v_v_240, 1);
      v_t_2419 = heff_dup(v_vs_2414);
      break;
    }
    case TAG_VInt: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_240);
    }
    V v_x1_2420 = (g_prelude_2edrop(MK_INT(0LL), v_t_2419));
    V v_x2_2423;
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nil: {
      heff_drop(v_x1_2420);
      v_x2_2423 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x1_2420, 0);
      heff_take(v_x1_2420, 1ULL);
      v_x2_2423 = heff_tag(TAG_Just, 1, (V[]){v_x_2421});
      break;
    }
    default: heff_nomatch(v_x1_2420);
    }
    V v_x1_2425;
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_Nothing: {
      heff_drop(v_x2_2423);
      v_x1_2425 = NTAG(TAG_VErased);
      break;
    }
    case TAG_Just: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      heff_take(v_x2_2423, 1ULL);
      v_x1_2425 = v_x_2424;
      break;
    }
    default: heff_nomatch(v_x2_2423);
    }
    V v_t_2434;
    switch (heff_tag_of(v_x1_2425)) {
    case TAG_VFun: {
      heff_take(v_x1_2425, 0ULL);
      v_t_2434 = ((V)&g_heff_2edriver_2efailureOfV_str8);
      break;
    }
    case TAG_VCons: {
      heff_take(v_x1_2425, 0ULL);
      v_t_2434 = ((V)&g_heff_2edriver_2efailureOfV_str9);
      break;
    }
    case TAG_VTag: {
      V v_x_2428 = heff_field(v_x1_2425, 0);
      heff_take(v_x1_2425, 1ULL);
      v_t_2434 = v_x_2428;
      break;
    }
    case TAG_VInt: {
      heff_take(v_x1_2425, 0ULL);
      v_t_2434 = ((V)&g_heff_2edriver_2efailureOfV_str10);
      break;
    }
    case TAG_VFloat: {
      heff_take(v_x1_2425, 0ULL);
      v_t_2434 = ((V)&g_heff_2edriver_2efailureOfV_str11);
      break;
    }
    case TAG_VStr: {
      heff_take(v_x1_2425, 0ULL);
      v_t_2434 = ((V)&g_heff_2edriver_2efailureOfV_str12);
      break;
    }
    case TAG_VArr: {
      heff_take(v_x1_2425, 0ULL);
      v_t_2434 = ((V)&g_heff_2edriver_2efailureOfV_str13);
      break;
    }
    case TAG_VErased: {
      heff_drop(v_x1_2425);
      v_t_2434 = ((V)&g_heff_2edriver_2efailureOfV_str14);
      break;
    }
    default: heff_nomatch(v_x1_2425);
    }
    V v_t_2435 = heff_strEq(v_t_2434, ((V)&g_heff_2edriver_2efailureOfV_str15));
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      heff_drop(v_t_2435);
      V v_t_2444;
      switch (heff_tag_of(v_v_240)) {
      case TAG_VFun: {
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_2439 = heff_field(v_v_240, 1);
        v_t_2444 = heff_dup(v_vs_2439);
        break;
      }
      case TAG_VInt: {
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_240);
      }
      V v_x1_2445 = (g_prelude_2edrop(MK_INT(0LL), v_t_2444));
      V v_x2_2448;
      switch (heff_tag_of(v_x1_2445)) {
      case TAG_Nil: {
        heff_drop(v_x1_2445);
        v_x2_2448 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2446 = heff_field(v_x1_2445, 0);
        heff_take(v_x1_2445, 1ULL);
        v_x2_2448 = heff_tag(TAG_Just, 1, (V[]){v_x_2446});
        break;
      }
      default: heff_nomatch(v_x1_2445);
      }
      V v_v_2450;
      switch (heff_tag_of(v_x2_2448)) {
      case TAG_Nothing: {
        heff_drop(v_x2_2448);
        v_v_2450 = NTAG(TAG_VErased);
        break;
      }
      case TAG_Just: {
        V v_x_2449 = heff_field(v_x2_2448, 0);
        heff_take(v_x2_2448, 1ULL);
        v_v_2450 = v_x_2449;
        break;
      }
      default: heff_nomatch(v_x2_2448);
      }
      V v_t_2459;
      switch (heff_tag_of(v_v_2450)) {
      case TAG_VFun: {
        heff_take(v_v_2450, 0ULL);
        v_t_2459 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        heff_take(v_v_2450, 0ULL);
        v_t_2459 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_2454 = heff_field(v_v_2450, 1);
        heff_take(v_v_2450, 2ULL);
        v_t_2459 = v_vs_2454;
        break;
      }
      case TAG_VInt: {
        heff_take(v_v_2450, 0ULL);
        v_t_2459 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        heff_take(v_v_2450, 0ULL);
        v_t_2459 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        heff_take(v_v_2450, 0ULL);
        v_t_2459 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        heff_take(v_v_2450, 0ULL);
        v_t_2459 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        heff_drop(v_v_2450);
        v_t_2459 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_2450);
      }
      V v_x1_2460 = (g_prelude_2edrop(MK_INT(0LL), v_t_2459));
      V v_x2_2463;
      switch (heff_tag_of(v_x1_2460)) {
      case TAG_Nil: {
        heff_drop(v_x1_2460);
        v_x2_2463 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2461 = heff_field(v_x1_2460, 0);
        heff_take(v_x1_2460, 1ULL);
        v_x2_2463 = heff_tag(TAG_Just, 1, (V[]){v_x_2461});
        break;
      }
      default: heff_nomatch(v_x1_2460);
      }
      V v_x1_2465;
      switch (heff_tag_of(v_x2_2463)) {
      case TAG_Nothing: {
        heff_drop(v_x2_2463);
        v_x1_2465 = NTAG(TAG_VErased);
        break;
      }
      case TAG_Just: {
        V v_x_2464 = heff_field(v_x2_2463, 0);
        heff_take(v_x2_2463, 1ULL);
        v_x1_2465 = v_x_2464;
        break;
      }
      default: heff_nomatch(v_x2_2463);
      }
      V v_t_2474;
      switch (heff_tag_of(v_x1_2465)) {
      case TAG_VFun: {
        heff_take(v_x1_2465, 0ULL);
        v_t_2474 = ((V)&g_heff_2edriver_2efailureOfV_str16);
        break;
      }
      case TAG_VCons: {
        heff_take(v_x1_2465, 0ULL);
        v_t_2474 = ((V)&g_heff_2edriver_2efailureOfV_str17);
        break;
      }
      case TAG_VTag: {
        heff_take(v_x1_2465, 0ULL);
        v_t_2474 = ((V)&g_heff_2edriver_2efailureOfV_str18);
        break;
      }
      case TAG_VInt: {
        heff_take(v_x1_2465, 0ULL);
        v_t_2474 = ((V)&g_heff_2edriver_2efailureOfV_str19);
        break;
      }
      case TAG_VFloat: {
        heff_take(v_x1_2465, 0ULL);
        v_t_2474 = ((V)&g_heff_2edriver_2efailureOfV_str20);
        break;
      }
      case TAG_VStr: {
        V v_s_2472 = heff_field(v_x1_2465, 0);
        heff_take(v_x1_2465, 1ULL);
        v_t_2474 = v_s_2472;
        break;
      }
      case TAG_VArr: {
        heff_take(v_x1_2465, 0ULL);
        v_t_2474 = ((V)&g_heff_2edriver_2efailureOfV_str21);
        break;
      }
      case TAG_VErased: {
        heff_drop(v_x1_2465);
        v_t_2474 = ((V)&g_heff_2edriver_2efailureOfV_str22);
        break;
      }
      default: heff_nomatch(v_x1_2465);
      }
      V v_t_2483;
      switch (heff_tag_of(v_v_240)) {
      case TAG_VFun: {
        v_t_2483 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        v_t_2483 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_2478 = heff_field(v_v_240, 1);
        v_t_2483 = heff_dup(v_vs_2478);
        break;
      }
      case TAG_VInt: {
        v_t_2483 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        v_t_2483 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        v_t_2483 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        v_t_2483 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_2483 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_240);
      }
      V v_x1_2484 = (g_prelude_2edrop(MK_INT(0LL), v_t_2483));
      V v_x2_2487;
      switch (heff_tag_of(v_x1_2484)) {
      case TAG_Nil: {
        heff_drop(v_x1_2484);
        v_x2_2487 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2485 = heff_field(v_x1_2484, 0);
        heff_take(v_x1_2484, 1ULL);
        v_x2_2487 = heff_tag(TAG_Just, 1, (V[]){v_x_2485});
        break;
      }
      default: heff_nomatch(v_x1_2484);
      }
      V v_v_2489;
      switch (heff_tag_of(v_x2_2487)) {
      case TAG_Nothing: {
        heff_drop(v_x2_2487);
        v_v_2489 = NTAG(TAG_VErased);
        break;
      }
      case TAG_Just: {
        V v_x_2488 = heff_field(v_x2_2487, 0);
        heff_take(v_x2_2487, 1ULL);
        v_v_2489 = v_x_2488;
        break;
      }
      default: heff_nomatch(v_x2_2487);
      }
      V v_t_2498;
      switch (heff_tag_of(v_v_2489)) {
      case TAG_VFun: {
        heff_take(v_v_2489, 0ULL);
        v_t_2498 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        heff_take(v_v_2489, 0ULL);
        v_t_2498 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_2493 = heff_field(v_v_2489, 1);
        heff_take(v_v_2489, 2ULL);
        v_t_2498 = v_vs_2493;
        break;
      }
      case TAG_VInt: {
        heff_take(v_v_2489, 0ULL);
        v_t_2498 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        heff_take(v_v_2489, 0ULL);
        v_t_2498 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        heff_take(v_v_2489, 0ULL);
        v_t_2498 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        heff_take(v_v_2489, 0ULL);
        v_t_2498 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        heff_drop(v_v_2489);
        v_t_2498 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_2489);
      }
      V v_x1_2499 = (g_prelude_2edrop(MK_INT(1LL), v_t_2498));
      V v_x2_24102;
      switch (heff_tag_of(v_x1_2499)) {
      case TAG_Nil: {
        heff_drop(v_x1_2499);
        v_x2_24102 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_24100 = heff_field(v_x1_2499, 0);
        heff_take(v_x1_2499, 1ULL);
        v_x2_24102 = heff_tag(TAG_Just, 1, (V[]){v_x_24100});
        break;
      }
      default: heff_nomatch(v_x1_2499);
      }
      V v_x1_24104;
      switch (heff_tag_of(v_x2_24102)) {
      case TAG_Nothing: {
        heff_drop(v_x2_24102);
        v_x1_24104 = NTAG(TAG_VErased);
        break;
      }
      case TAG_Just: {
        V v_x_24103 = heff_field(v_x2_24102, 0);
        heff_take(v_x2_24102, 1ULL);
        v_x1_24104 = v_x_24103;
        break;
      }
      default: heff_nomatch(v_x2_24102);
      }
      V v_t_24113;
      switch (heff_tag_of(v_x1_24104)) {
      case TAG_VFun: {
        heff_take(v_x1_24104, 0ULL);
        v_t_24113 = ((V)&g_heff_2edriver_2efailureOfV_str23);
        break;
      }
      case TAG_VCons: {
        heff_take(v_x1_24104, 0ULL);
        v_t_24113 = ((V)&g_heff_2edriver_2efailureOfV_str24);
        break;
      }
      case TAG_VTag: {
        heff_take(v_x1_24104, 0ULL);
        v_t_24113 = ((V)&g_heff_2edriver_2efailureOfV_str25);
        break;
      }
      case TAG_VInt: {
        heff_take(v_x1_24104, 0ULL);
        v_t_24113 = ((V)&g_heff_2edriver_2efailureOfV_str26);
        break;
      }
      case TAG_VFloat: {
        heff_take(v_x1_24104, 0ULL);
        v_t_24113 = ((V)&g_heff_2edriver_2efailureOfV_str27);
        break;
      }
      case TAG_VStr: {
        V v_s_24111 = heff_field(v_x1_24104, 0);
        heff_take(v_x1_24104, 1ULL);
        v_t_24113 = v_s_24111;
        break;
      }
      case TAG_VArr: {
        heff_take(v_x1_24104, 0ULL);
        v_t_24113 = ((V)&g_heff_2edriver_2efailureOfV_str28);
        break;
      }
      case TAG_VErased: {
        heff_drop(v_x1_24104);
        v_t_24113 = ((V)&g_heff_2edriver_2efailureOfV_str29);
        break;
      }
      default: heff_nomatch(v_x1_24104);
      }
      return heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_FailDiffer, 2, (V[]){v_t_2474, v_t_24113})});
    }
    case TAG_False: {
      heff_drop(v_t_2435);
      V v_t_24122;
      switch (heff_tag_of(v_v_240)) {
      case TAG_VFun: {
        v_t_24122 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        v_t_24122 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_24117 = heff_field(v_v_240, 1);
        v_t_24122 = heff_dup(v_vs_24117);
        break;
      }
      case TAG_VInt: {
        v_t_24122 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        v_t_24122 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        v_t_24122 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        v_t_24122 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_24122 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_240);
      }
      V v_x1_24123 = (g_prelude_2edrop(MK_INT(0LL), v_t_24122));
      V v_x2_24126;
      switch (heff_tag_of(v_x1_24123)) {
      case TAG_Nil: {
        heff_drop(v_x1_24123);
        v_x2_24126 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_24124 = heff_field(v_x1_24123, 0);
        heff_take(v_x1_24123, 1ULL);
        v_x2_24126 = heff_tag(TAG_Just, 1, (V[]){v_x_24124});
        break;
      }
      default: heff_nomatch(v_x1_24123);
      }
      V v_v_24128;
      switch (heff_tag_of(v_x2_24126)) {
      case TAG_Nothing: {
        heff_drop(v_x2_24126);
        v_v_24128 = NTAG(TAG_VErased);
        break;
      }
      case TAG_Just: {
        V v_x_24127 = heff_field(v_x2_24126, 0);
        heff_take(v_x2_24126, 1ULL);
        v_v_24128 = v_x_24127;
        break;
      }
      default: heff_nomatch(v_x2_24126);
      }
      V v_t_24137;
      switch (heff_tag_of(v_v_24128)) {
      case TAG_VFun: {
        heff_take(v_v_24128, 0ULL);
        v_t_24137 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        heff_take(v_v_24128, 0ULL);
        v_t_24137 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_24132 = heff_field(v_v_24128, 1);
        heff_take(v_v_24128, 2ULL);
        v_t_24137 = v_vs_24132;
        break;
      }
      case TAG_VInt: {
        heff_take(v_v_24128, 0ULL);
        v_t_24137 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        heff_take(v_v_24128, 0ULL);
        v_t_24137 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        heff_take(v_v_24128, 0ULL);
        v_t_24137 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        heff_take(v_v_24128, 0ULL);
        v_t_24137 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        heff_drop(v_v_24128);
        v_t_24137 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_24128);
      }
      V v_x1_24138 = (g_prelude_2edrop(MK_INT(0LL), v_t_24137));
      V v_x2_24141;
      switch (heff_tag_of(v_x1_24138)) {
      case TAG_Nil: {
        heff_drop(v_x1_24138);
        v_x2_24141 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_24139 = heff_field(v_x1_24138, 0);
        heff_take(v_x1_24138, 1ULL);
        v_x2_24141 = heff_tag(TAG_Just, 1, (V[]){v_x_24139});
        break;
      }
      default: heff_nomatch(v_x1_24138);
      }
      V v_x1_24143;
      switch (heff_tag_of(v_x2_24141)) {
      case TAG_Nothing: {
        heff_drop(v_x2_24141);
        v_x1_24143 = NTAG(TAG_VErased);
        break;
      }
      case TAG_Just: {
        V v_x_24142 = heff_field(v_x2_24141, 0);
        heff_take(v_x2_24141, 1ULL);
        v_x1_24143 = v_x_24142;
        break;
      }
      default: heff_nomatch(v_x2_24141);
      }
      V v_t_24152;
      switch (heff_tag_of(v_x1_24143)) {
      case TAG_VFun: {
        heff_take(v_x1_24143, 0ULL);
        v_t_24152 = ((V)&g_heff_2edriver_2efailureOfV_str30);
        break;
      }
      case TAG_VCons: {
        heff_take(v_x1_24143, 0ULL);
        v_t_24152 = ((V)&g_heff_2edriver_2efailureOfV_str31);
        break;
      }
      case TAG_VTag: {
        heff_take(v_x1_24143, 0ULL);
        v_t_24152 = ((V)&g_heff_2edriver_2efailureOfV_str32);
        break;
      }
      case TAG_VInt: {
        heff_take(v_x1_24143, 0ULL);
        v_t_24152 = ((V)&g_heff_2edriver_2efailureOfV_str33);
        break;
      }
      case TAG_VFloat: {
        heff_take(v_x1_24143, 0ULL);
        v_t_24152 = ((V)&g_heff_2edriver_2efailureOfV_str34);
        break;
      }
      case TAG_VStr: {
        V v_s_24150 = heff_field(v_x1_24143, 0);
        heff_take(v_x1_24143, 1ULL);
        v_t_24152 = v_s_24150;
        break;
      }
      case TAG_VArr: {
        heff_take(v_x1_24143, 0ULL);
        v_t_24152 = ((V)&g_heff_2edriver_2efailureOfV_str35);
        break;
      }
      case TAG_VErased: {
        heff_drop(v_x1_24143);
        v_t_24152 = ((V)&g_heff_2edriver_2efailureOfV_str36);
        break;
      }
      default: heff_nomatch(v_x1_24143);
      }
      return heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_FailBecause, 1, (V[]){v_t_24152})});
    }
    default: return heff_nomatch(v_t_2435);
    }
  }
  case TAG_False: {
    heff_drop(v_t_2410);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2edriver_2efailureOfV_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2efailureOfV(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2edriver_2eoutcomeOfV_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2edriver_2eoutcomeOfV_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {111, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str15 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2edriver_2eoutcomeOfV_str16 = {{0x80000000u, K_STR, 0}, 8, 8, {112, 114, 111, 112, 101, 114, 116, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str17 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str18 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str19 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str20 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str21 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomeOfV_str23 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2edriver_2eoutcomeOfV_str24 = {{0x80000000u, K_STR, 0}, 4, 4, {114, 117, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2edriver_2eoutcomeOfV_str25 = {{0x80000000u, K_STR, 0}, 9, 9, {100, 105, 115, 99, 97, 114, 100, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2edriver_2eoutcomeOfV_str26 = {{0x80000000u, K_STR, 0}, 7, 7, {115, 104, 114, 105, 110, 107, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2edriver_2eoutcomeOfV_str27 = {{0x80000000u, K_STR, 0}, 6, 6, {108, 97, 98, 101, 108, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2eoutcomeOfV_str28 = {{0x80000000u, K_STR, 0}, 5, 5, {110, 111, 116, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2edriver_2eoutcomeOfV_str29 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 97, 105, 108, 117, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2edriver_2eoutcomeOfV_str30 = {{0x80000000u, K_STR, 0}, 4, 4, {115, 101, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2edriver_2eoutcomeOfV_str31 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2edriver_2eoutcomeOfV_str32 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
Clo g_heff_2edriver_2eoutcomeOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eoutcomeOfV_entry, 1, 0};

V g_heff_2edriver_2eoutcomeOfV(V v_v_240) {
top: ;
  V v_x1_241 = (g_heff_2edriver_2efieldV(v_v_240, ((V)&g_heff_2edriver_2eoutcomeOfV_str0)));
  V v_t_2410;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_VFun: {
    heff_take(v_x1_241, 0ULL);
    v_t_2410 = ((V)&g_heff_2edriver_2eoutcomeOfV_str1);
    break;
  }
  case TAG_VCons: {
    heff_take(v_x1_241, 0ULL);
    v_t_2410 = ((V)&g_heff_2edriver_2eoutcomeOfV_str2);
    break;
  }
  case TAG_VTag: {
    heff_take(v_x1_241, 0ULL);
    v_t_2410 = ((V)&g_heff_2edriver_2eoutcomeOfV_str3);
    break;
  }
  case TAG_VInt: {
    heff_take(v_x1_241, 0ULL);
    v_t_2410 = ((V)&g_heff_2edriver_2eoutcomeOfV_str4);
    break;
  }
  case TAG_VFloat: {
    heff_take(v_x1_241, 0ULL);
    v_t_2410 = ((V)&g_heff_2edriver_2eoutcomeOfV_str5);
    break;
  }
  case TAG_VStr: {
    V v_s_248 = heff_field(v_x1_241, 0);
    heff_take(v_x1_241, 1ULL);
    v_t_2410 = v_s_248;
    break;
  }
  case TAG_VArr: {
    heff_take(v_x1_241, 0ULL);
    v_t_2410 = ((V)&g_heff_2edriver_2eoutcomeOfV_str6);
    break;
  }
  case TAG_VErased: {
    heff_drop(v_x1_241);
    v_t_2410 = ((V)&g_heff_2edriver_2eoutcomeOfV_str7);
    break;
  }
  default: heff_nomatch(v_x1_241);
  }
  V v_x1_2411 = (g_heff_2edriver_2efieldV(v_v_240, ((V)&g_heff_2edriver_2eoutcomeOfV_str8)));
  V v_t_2420;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_VFun: {
    heff_take(v_x1_2411, 0ULL);
    v_t_2420 = ((V)&g_heff_2edriver_2eoutcomeOfV_str9);
    break;
  }
  case TAG_VCons: {
    heff_take(v_x1_2411, 0ULL);
    v_t_2420 = ((V)&g_heff_2edriver_2eoutcomeOfV_str10);
    break;
  }
  case TAG_VTag: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take(v_x1_2411, 1ULL);
    v_t_2420 = v_x_2414;
    break;
  }
  case TAG_VInt: {
    heff_take(v_x1_2411, 0ULL);
    v_t_2420 = ((V)&g_heff_2edriver_2eoutcomeOfV_str11);
    break;
  }
  case TAG_VFloat: {
    heff_take(v_x1_2411, 0ULL);
    v_t_2420 = ((V)&g_heff_2edriver_2eoutcomeOfV_str12);
    break;
  }
  case TAG_VStr: {
    heff_take(v_x1_2411, 0ULL);
    v_t_2420 = ((V)&g_heff_2edriver_2eoutcomeOfV_str13);
    break;
  }
  case TAG_VArr: {
    heff_take(v_x1_2411, 0ULL);
    v_t_2420 = ((V)&g_heff_2edriver_2eoutcomeOfV_str14);
    break;
  }
  case TAG_VErased: {
    heff_drop(v_x1_2411);
    v_t_2420 = ((V)&g_heff_2edriver_2eoutcomeOfV_str15);
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  V v_x1_2421 = (g_heff_2edriver_2efieldV(v_v_240, ((V)&g_heff_2edriver_2eoutcomeOfV_str16)));
  V v_t_2430;
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_VFun: {
    heff_take(v_x1_2421, 0ULL);
    v_t_2430 = ((V)&g_heff_2edriver_2eoutcomeOfV_str17);
    break;
  }
  case TAG_VCons: {
    heff_take(v_x1_2421, 0ULL);
    v_t_2430 = ((V)&g_heff_2edriver_2eoutcomeOfV_str18);
    break;
  }
  case TAG_VTag: {
    V v_x_2424 = heff_field(v_x1_2421, 0);
    heff_take(v_x1_2421, 1ULL);
    v_t_2430 = v_x_2424;
    break;
  }
  case TAG_VInt: {
    heff_take(v_x1_2421, 0ULL);
    v_t_2430 = ((V)&g_heff_2edriver_2eoutcomeOfV_str19);
    break;
  }
  case TAG_VFloat: {
    heff_take(v_x1_2421, 0ULL);
    v_t_2430 = ((V)&g_heff_2edriver_2eoutcomeOfV_str20);
    break;
  }
  case TAG_VStr: {
    heff_take(v_x1_2421, 0ULL);
    v_t_2430 = ((V)&g_heff_2edriver_2eoutcomeOfV_str21);
    break;
  }
  case TAG_VArr: {
    heff_take(v_x1_2421, 0ULL);
    v_t_2430 = ((V)&g_heff_2edriver_2eoutcomeOfV_str22);
    break;
  }
  case TAG_VErased: {
    heff_drop(v_x1_2421);
    v_t_2430 = ((V)&g_heff_2edriver_2eoutcomeOfV_str23);
    break;
  }
  default: heff_nomatch(v_x1_2421);
  }
  V v_x1_2431 = (g_heff_2edriver_2efieldV(v_v_240, ((V)&g_heff_2edriver_2eoutcomeOfV_str24)));
  V v_t_2440;
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_VFun: {
    heff_take(v_x1_2431, 0ULL);
    v_t_2440 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take(v_x1_2431, 0ULL);
    v_t_2440 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take(v_x1_2431, 0ULL);
    v_t_2440 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_2436 = heff_field(v_x1_2431, 0);
    heff_take(v_x1_2431, 1ULL);
    v_t_2440 = v_i_2436;
    break;
  }
  case TAG_VFloat: {
    heff_take(v_x1_2431, 0ULL);
    v_t_2440 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take(v_x1_2431, 0ULL);
    v_t_2440 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take(v_x1_2431, 0ULL);
    v_t_2440 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    heff_drop(v_x1_2431);
    v_t_2440 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_2431);
  }
  V v_x1_2441 = (g_heff_2edriver_2efieldV(v_v_240, ((V)&g_heff_2edriver_2eoutcomeOfV_str25)));
  V v_t_2450;
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_VFun: {
    heff_take(v_x1_2441, 0ULL);
    v_t_2450 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take(v_x1_2441, 0ULL);
    v_t_2450 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take(v_x1_2441, 0ULL);
    v_t_2450 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_2446 = heff_field(v_x1_2441, 0);
    heff_take(v_x1_2441, 1ULL);
    v_t_2450 = v_i_2446;
    break;
  }
  case TAG_VFloat: {
    heff_take(v_x1_2441, 0ULL);
    v_t_2450 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take(v_x1_2441, 0ULL);
    v_t_2450 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take(v_x1_2441, 0ULL);
    v_t_2450 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    heff_drop(v_x1_2441);
    v_t_2450 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_2441);
  }
  V v_x1_2451 = (g_heff_2edriver_2efieldV(v_v_240, ((V)&g_heff_2edriver_2eoutcomeOfV_str26)));
  V v_t_2460;
  switch (heff_tag_of(v_x1_2451)) {
  case TAG_VFun: {
    heff_take(v_x1_2451, 0ULL);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take(v_x1_2451, 0ULL);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take(v_x1_2451, 0ULL);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_2456 = heff_field(v_x1_2451, 0);
    heff_take(v_x1_2451, 1ULL);
    v_t_2460 = v_i_2456;
    break;
  }
  case TAG_VFloat: {
    heff_take(v_x1_2451, 0ULL);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take(v_x1_2451, 0ULL);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take(v_x1_2451, 0ULL);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    heff_drop(v_x1_2451);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_2451);
  }
  V v_t_2461 = (g_heff_2edriver_2efieldV(v_v_240, ((V)&g_heff_2edriver_2eoutcomeOfV_str27)));
  V v_t_2462 = (g_heff_2edriver_2elistOfV(v_t_2461));
  V v_t_2463 = (g_prelude_2emap_24s515(v_t_2462));
  V v_t_2464 = (g_heff_2edriver_2efieldV(v_v_240, ((V)&g_heff_2edriver_2eoutcomeOfV_str28)));
  V v_t_2465 = (g_heff_2edriver_2elistOfV(v_t_2464));
  V v_t_2466 = (g_prelude_2emap_24s516(v_t_2465));
  V v_t_2467 = (g_heff_2edriver_2efieldV(v_v_240, ((V)&g_heff_2edriver_2eoutcomeOfV_str29)));
  V v_t_2468 = ({ V a_0 = v_t_2467; V r_ = (g_heff_2edriver_2efailureOfV(a_0)); heff_drop(v_t_2467); r_; });
  V v_x1_2469 = (g_heff_2edriver_2efieldV(v_v_240, ((V)&g_heff_2edriver_2eoutcomeOfV_str30)));
  V v_t_2478;
  switch (heff_tag_of(v_x1_2469)) {
  case TAG_VFun: {
    heff_take(v_x1_2469, 0ULL);
    v_t_2478 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take(v_x1_2469, 0ULL);
    v_t_2478 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take(v_x1_2469, 0ULL);
    v_t_2478 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_2474 = heff_field(v_x1_2469, 0);
    heff_take(v_x1_2469, 1ULL);
    v_t_2478 = v_i_2474;
    break;
  }
  case TAG_VFloat: {
    heff_take(v_x1_2469, 0ULL);
    v_t_2478 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take(v_x1_2469, 0ULL);
    v_t_2478 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take(v_x1_2469, 0ULL);
    v_t_2478 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    heff_drop(v_x1_2469);
    v_t_2478 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_2469);
  }
  return heff_rec(10, shape_190_203_249_274_61_290_151_198_92_279, (V[]){v_t_2410, heff_strEq(v_t_2420, ((V)&g_heff_2edriver_2eoutcomeOfV_str31)), heff_strEq(v_t_2430, ((V)&g_heff_2edriver_2eoutcomeOfV_str32)), v_t_2440, v_t_2450, v_t_2460, v_t_2463, v_t_2466, v_t_2468, v_t_2478});
}
V g_heff_2edriver_2eoutcomeOfV_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eoutcomeOfV(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomesOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomesOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2edriver_2eoutcomesOf_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {60, 97, 98, 97, 110, 100, 111, 110, 101, 100, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2edriver_2eoutcomesOf_str3 = {{0x80000000u, K_STR, 0}, 10, 10, {60, 100, 105, 118, 101, 114, 103, 101, 100, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomesOf_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eoutcomesOf_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2edriver_2eoutcomesOf_str6 = {{0x80000000u, K_STR, 0}, 11, 11, {60, 97, 98, 97, 110, 100, 111, 110, 101, 100, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2edriver_2eoutcomesOf_str7 = {{0x80000000u, K_STR, 0}, 10, 10, {60, 100, 105, 118, 101, 114, 103, 101, 100, 62}};
Clo g_heff_2edriver_2eoutcomesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eoutcomesOf_entry, 3, 0};

V g_heff_2edriver_2eoutcomesOf(V v_o_240, V v_seed_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_RSucceeded: {
    V v_v_243 = heff_field(v_r_242, 0);
    heff_drop(v_o_240);
    heff_drop(v_seed_241);
    V v_t_244 = (g_heff_2edriver_2elistOfV(heff_dup(v_v_243)));
    return (g_prelude_2emap_24s517(v_t_244));
  }
  case TAG_RAbandoned: {
    V v_x_245 = heff_get(v_o_240, LBL_name);
    V v_t_246 = (g_heff_2epsurface_2eisOperator(heff_dup(v_x_245)));
    V v_name_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_t_246);
      v_name_247 = heff_strAppend(((V)&g_heff_2edriver_2eoutcomesOf_str0), heff_strAppend(v_x_245, ((V)&g_heff_2edriver_2eoutcomesOf_str1)));
      break;
    }
    case TAG_False: {
      heff_drop(v_t_246);
      v_name_247 = v_x_245;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_why_249;
    switch (heff_tag_of(v_r_242)) {
    case TAG_RSucceeded: {
      V v_v_248 = heff_field(v_r_242, 0);
      v_why_249 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_v_248; V r_ = (g_heff_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
      break;
    }
    case TAG_RAbandoned: {
      v_why_249 = ((V)&g_heff_2edriver_2eoutcomesOf_str2);
      break;
    }
    case TAG_RDiverged: {
      v_why_249 = ((V)&g_heff_2edriver_2eoutcomesOf_str3);
      break;
    }
    default: heff_nomatch(v_r_242);
    }
    V v_t_2410 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_FailBecause, 1, (V[]){v_why_249})});
    V v_t_2411 = heff_rec(10, shape_190_203_249_274_61_290_151_198_92_279, (V[]){v_name_247, NTAG(TAG_False), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2410, v_seed_241});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  }
  case TAG_RDiverged: {
    V v_x_2412 = heff_get(v_o_240, LBL_name);
    V v_t_2413 = (g_heff_2epsurface_2eisOperator(heff_dup(v_x_2412)));
    V v_name_2414;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      heff_drop(v_t_2413);
      v_name_2414 = heff_strAppend(((V)&g_heff_2edriver_2eoutcomesOf_str4), heff_strAppend(v_x_2412, ((V)&g_heff_2edriver_2eoutcomesOf_str5)));
      break;
    }
    case TAG_False: {
      heff_drop(v_t_2413);
      v_name_2414 = v_x_2412;
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    V v_why_2416;
    switch (heff_tag_of(v_r_242)) {
    case TAG_RSucceeded: {
      V v_v_2415 = heff_field(v_r_242, 0);
      v_why_2416 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_v_2415; V r_ = (g_heff_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
      break;
    }
    case TAG_RAbandoned: {
      v_why_2416 = ((V)&g_heff_2edriver_2eoutcomesOf_str6);
      break;
    }
    case TAG_RDiverged: {
      v_why_2416 = ((V)&g_heff_2edriver_2eoutcomesOf_str7);
      break;
    }
    default: heff_nomatch(v_r_242);
    }
    V v_t_2417 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_FailBecause, 1, (V[]){v_why_2416})});
    V v_t_2418 = heff_rec(10, shape_190_203_249_274_61_290_151_198_92_279, (V[]){v_name_2414, NTAG(TAG_False), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2417, v_seed_241});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2edriver_2eoutcomesOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eoutcomesOf(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2edriver_2eaddTests_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {62, 32, 116, 101, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2edriver_2eaddTests_str1 = {{0x80000000u, K_STR, 0}, 13, 13, {99, 104, 101, 99, 107, 46, 114, 117, 110, 84, 101, 115, 116}};
Clo g_heff_2edriver_2eaddTests_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eaddTests_entry, 4, 0};

V g_heff_2edriver_2eaddTests(V v_seed_240, V v_i_241, V v_x3_242, V v_g_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seed_240);
    heff_drop(v_i_241);
    heff_drop(v_x3_242);
    return v_g_243;
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse(v_x3_242, 3ULL);
    V v_t_246 = heff_strAppend(((V)&g_heff_2edriver_2eaddTests_str0), heff_intShow(heff_dup(v_i_241)));
    V v_t_247 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_SApp, 2, (V[]){heff_tag(TAG_SGlobal, 1, (V[]){((V)&g_heff_2edriver_2eaddTests_str1)}), heff_tag(TAG_SLitInt, 1, (V[]){heff_dup(v_seed_240)})});
    V v_t_248 = heff_tag(TAG_SGlobal, 1, (V[]){heff_get(v_o_244, LBL_key)});
    V v_t_249 = heff_rec(4, shape_314_337_352_340, (V[]){heff_tag(TAG_SApp, 2, (V[]){v_t_247, v_t_248}), NTAG(TAG_SPrimInt), NTAG(TAG_VOpaque), NTAG(TAG_VPrimInt)});
    V v_t_2410 = (g_heff_2eglobals_2eaddEntry(v_t_246, v_t_249, v_g_243));
    V t_0 = v_seed_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_rest_245;
    V t_3 = v_t_2410;
    v_seed_240 = t_0;
    v_i_241 = t_1;
    v_x3_242 = t_2;
    v_g_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2edriver_2eaddTests_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eaddTests(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2edriver_2epickOutcomes_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {62, 32, 116, 101, 115, 116, 32}};
Clo g_heff_2edriver_2epickOutcomes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2epickOutcomes_entry, 4, 0};

V g_heff_2edriver_2epickOutcomes(V v_seed_240, V v_rs_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_seed_240);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_t_246 = heff_strAppend(((V)&g_heff_2edriver_2epickOutcomes_str0), heff_intShow(heff_dup(v_i_242)));
    V v_t_247 = (g_prelude_2elookupBy(heff_dup(g_strEq_get()), v_t_246, v_rs_241));
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop(v_t_247);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_r_248 = heff_field(v_t_247, 0);
      heff_take(v_t_247, 1ULL);
      v_t_249 = ({ V a_0 = heff_dup(v_o_244); V a_1 = heff_dup(v_seed_240); V a_2 = v_r_248; V r_ = (g_heff_2edriver_2eoutcomesOf(a_0, a_1, a_2)); heff_drop(v_r_248); r_; });
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2410 = (g_heff_2edriver_2epickOutcomes(v_seed_240, v_rs_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_rest_245));
    return (g_prelude_2econcatList(v_t_249, v_t_2410));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2edriver_2epickOutcomes_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2epickOutcomes(a[0], a[1], a[2], a[3]); heff_drop(a[1]); heff_drop(a[3]); return r;
}
V g_heff_2edriver_2erunTests_lam0(V self, V *args);
V g_heff_2edriver_2erunTests_lam1(V self, V *args);
V g_heff_2edriver_2erunTests_lam2(V self, V *args);
V g_heff_2edriver_2erunTests_lam3(V self, V *args);
Clo g_heff_2edriver_2erunTests_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2erunTests_entry, 2, 0};

V g_heff_2edriver_2erunTests(V v_seed_240, V v_c_241) {
top: ;
  V v_x1_246 = (g_prelude_2efilter(heff_clo(g_heff_2edriver_2erunTests_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), heff_get(heff_dup(v_c_241), LBL_own)));
  V v_t_249;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Nil: {
    heff_drop(v_x1_246);
    v_t_249 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take(v_x1_246, 0ULL);
    v_t_249 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    heff_drop(v_seed_240);
    heff_drop(v_c_241);
    heff_drop(v_t_249);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    heff_drop(v_t_249);
    V v_t_2414 = (g_prelude_2efilter(heff_clo(g_heff_2edriver_2erunTests_lam1, 1, 1, (V[]){heff_dup(v_c_241)}), heff_get(heff_dup(v_c_241), LBL_own)));
    V v_t_2415 = heff_get(heff_get(heff_dup(v_c_241), LBL_top), LBL_globals);
    V v_gs_2416 = (g_heff_2edriver_2eaddTests(heff_dup(v_seed_240), MK_INT(0LL), v_t_2414, v_t_2415));
    V v_t_2421 = ({ V a_0 = heff_clo(g_heff_2edriver_2erunTests_lam2, 2, 1, (V[]){heff_dup(v_gs_2416)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get(v_gs_2416, LBL_order); V r_ = (g_prelude_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2422 = (g_heff_2einterp_2eevalGlobalsGo_24s518(heff_dup(g_map_2eempty_get()), v_t_2421, NTAG(TAG_Nil)));
    V v_t_2427 = (g_prelude_2efilter(heff_clo(g_heff_2edriver_2erunTests_lam3, 1, 1, (V[]){heff_dup(v_c_241)}), heff_get(v_c_241, LBL_own)));
    return ({ V a_0 = v_seed_240; V a_1 = v_t_2422; V a_2 = MK_INT(0LL); V a_3 = v_t_2427; V r_ = (g_heff_2edriver_2epickOutcomes(a_0, a_1, a_2, a_3)); heff_drop(v_t_2422); heff_drop(v_t_2427); r_; });
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2edriver_2erunTests_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2erunTests(a[0], a[1]);
}
V g_heff_2edriver_2erunTests_lam0(V self, V *args) {
  V v_o_242 = args[0];
  V v_c_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_243 = heff_get(heff_get(v_c_241, LBL_top), LBL_globals);
  V v_t_244 = (g_heff_2eglobals_2elookupEntry(v_t_243, heff_get(v_o_242, LBL_key)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_t_244);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    heff_take(v_t_244, 1ULL);
    return ({ V b_0 = heff_get(v_e_245, LBL_tySyntax); V r_ = (g_heff_2edriver_2eisTestTy(b_0)); heff_drop(b_0); r_; });
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2edriver_2erunTests_lam1(V self, V *args) {
  V v_o_2410 = args[0];
  V v_c_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2411 = heff_get(heff_get(v_c_241, LBL_top), LBL_globals);
  V v_t_2412 = (g_heff_2eglobals_2elookupEntry(v_t_2411, heff_get(v_o_2410, LBL_key)));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    heff_drop(v_t_2412);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_e_2413 = heff_field(v_t_2412, 0);
    heff_take(v_t_2412, 1ULL);
    return ({ V b_0 = heff_get(v_e_2413, LBL_tySyntax); V r_ = (g_heff_2edriver_2eisTestTy(b_0)); heff_drop(b_0); r_; });
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2edriver_2erunTests_lam2(V self, V *args) {
  V v_acc_2417 = args[0];
  V v_k_2418 = args[1];
  V v_gs_2416 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2419 = ({ V a_0 = heff_dup(v_k_2418); V b_1 = heff_get(v_gs_2416, LBL_entries); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Nothing: {
    heff_drop(v_k_2418);
    heff_drop(v_t_2419);
    return v_acc_2417;
  }
  case TAG_Just: {
    V v_e_2420 = heff_field(v_t_2419, 0);
    heff_take(v_t_2419, 1ULL);
    return heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_k_2418, v_e_2420}), v_acc_2417});
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2edriver_2erunTests_lam3(V self, V *args) {
  V v_o_2423 = args[0];
  V v_c_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2424 = heff_get(heff_get(v_c_241, LBL_top), LBL_globals);
  V v_t_2425 = (g_heff_2eglobals_2elookupEntry(v_t_2424, heff_get(v_o_2423, LBL_key)));
  switch (heff_tag_of(v_t_2425)) {
  case TAG_Nothing: {
    heff_drop(v_t_2425);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_e_2426 = heff_field(v_t_2425, 0);
    heff_take(v_t_2425, 1ULL);
    return ({ V b_0 = heff_get(v_e_2426, LBL_tySyntax); V r_ = (g_heff_2edriver_2eisTestTy(b_0)); heff_drop(b_0); r_; });
  }
  default: return heff_nomatch(v_t_2425);
  }
}
Clo g_heff_2edriver_2eearlierGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eearlierGo_entry, 4, 0};

V g_heff_2edriver_2eearlierGo(V v_x1_240, V v_i_241, V v_x_242, V v_j_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_x_242);
    heff_drop(v_j_243);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_g_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_t_246 = heff_strEq(heff_get(heff_dup(v_g_244), LBL_id), heff_dup(v_x_242));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_x_242);
      heff_drop(v_t_246);
      return heff_intLt(v_j_243, v_i_241);
    }
    case TAG_False: {
      heff_drop(v_t_246);
      V t_0 = v_rest_245;
      V t_1 = v_i_241;
      V t_2 = v_x_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      v_x_242 = t_2;
      v_j_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2eearlierGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2eearlierGo(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2edriver_2efixityLine_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 102, 105, 120, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2edriver_2efixityLine_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 102, 105, 120, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2edriver_2efixityLine_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 102, 105, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efixityLine_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efixityLine_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efixityLine_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2edriver_2efixityLine_str6 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 97, 98, 111, 118, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efixityLine_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efixityLine_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2edriver_2efixityLine_str9 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 98, 101, 108, 111, 119, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efixityLine_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efixityLine_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2edriver_2efixityLine_lam0(V self, V *args);
V g_heff_2edriver_2efixityLine_lam1(V self, V *args);
Clo g_heff_2edriver_2efixityLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2efixityLine_entry, 3, 0};

V g_heff_2edriver_2efixityLine(V v_fx_240, V v_i_241, V v_g_242) {
top: ;
  V v_t_243 = heff_get(heff_dup(v_g_242), LBL_assoc);
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_AssocLeft: {
    heff_drop(v_t_243);
    v_t_244 = ((V)&g_heff_2edriver_2efixityLine_str0);
    break;
  }
  case TAG_AssocRight: {
    heff_drop(v_t_243);
    v_t_244 = ((V)&g_heff_2edriver_2efixityLine_str1);
    break;
  }
  case TAG_AssocNone: {
    heff_drop(v_t_243);
    v_t_244 = ((V)&g_heff_2edriver_2efixityLine_str2);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_get(heff_dup(v_g_242), LBL_ops);
  V v_t_248;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nil: {
    heff_drop(v_t_245);
    v_t_248 = ((V)&g_heff_2edriver_2efixityLine_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_t_245, 0);
    V v_xs_247 = heff_field(v_t_245, 1);
    heff_take(v_t_245, 3ULL);
    v_t_248 = ({ V a_0 = v_x_246; V a_1 = v_xs_247; V r_ = (g_prelude_2efoldl_24s4(a_0, a_1)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_2412 = (g_prelude_2emap(heff_clo(g_heff_2edriver_2efixityLine_lam0, 1, 3, (V[]){heff_dup(v_g_242), heff_dup(v_fx_240), heff_dup(v_i_241)}), heff_get(heff_dup(v_fx_240), LBL_above)));
  V v_t_2413 = (g_heff_2edriver_2ecatMaybesD(v_t_2412));
  V v_ops_2414 = (g_heff_2edriver_2enubStrD(v_t_2413));
  V v_t_2420;
  switch (heff_tag_of(v_ops_2414)) {
  case TAG_Nil: {
    heff_drop(v_ops_2414);
    v_t_2420 = ((V)&g_heff_2edriver_2efixityLine_str4);
    break;
  }
  case TAG_Cons: {
    V v_t_2419;
    switch (heff_tag_of(v_ops_2414)) {
    case TAG_Nil: {
      heff_drop(v_ops_2414);
      v_t_2419 = ((V)&g_heff_2edriver_2efixityLine_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_ops_2414, 0);
      V v_xs_2418 = heff_field(v_ops_2414, 1);
      heff_take(v_ops_2414, 3ULL);
      v_t_2419 = ({ V a_0 = v_x_2417; V a_1 = v_xs_2418; V r_ = (g_prelude_2efoldl_24s4(a_0, a_1)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_ops_2414);
    }
    v_t_2420 = heff_strAppend(((V)&g_heff_2edriver_2efixityLine_str6), v_t_2419);
    break;
  }
  default: heff_nomatch(v_ops_2414);
  }
  V v_t_2424 = (g_prelude_2emap(heff_clo(g_heff_2edriver_2efixityLine_lam1, 1, 3, (V[]){v_g_242, heff_dup(v_fx_240), v_i_241}), heff_get(v_fx_240, LBL_above)));
  V v_t_2425 = (g_heff_2edriver_2ecatMaybesD(v_t_2424));
  V v_ops_2426 = (g_heff_2edriver_2enubStrD(v_t_2425));
  V v_t_2432;
  switch (heff_tag_of(v_ops_2426)) {
  case TAG_Nil: {
    heff_drop(v_ops_2426);
    v_t_2432 = ((V)&g_heff_2edriver_2efixityLine_str7);
    break;
  }
  case TAG_Cons: {
    V v_t_2431;
    switch (heff_tag_of(v_ops_2426)) {
    case TAG_Nil: {
      heff_drop(v_ops_2426);
      v_t_2431 = ((V)&g_heff_2edriver_2efixityLine_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2429 = heff_field(v_ops_2426, 0);
      V v_xs_2430 = heff_field(v_ops_2426, 1);
      heff_take(v_ops_2426, 3ULL);
      v_t_2431 = ({ V a_0 = v_x_2429; V a_1 = v_xs_2430; V r_ = (g_prelude_2efoldl_24s4(a_0, a_1)); heff_drop(v_xs_2430); r_; });
      break;
    }
    default: heff_nomatch(v_ops_2426);
    }
    v_t_2432 = heff_strAppend(((V)&g_heff_2edriver_2efixityLine_str9), v_t_2431);
    break;
  }
  default: heff_nomatch(v_ops_2426);
  }
  return heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2edriver_2efixityLine_str10), heff_strAppend(v_t_248, heff_strAppend(v_t_2420, heff_strAppend(v_t_2432, ((V)&g_heff_2edriver_2efixityLine_str11))))));
}
V g_heff_2edriver_2efixityLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2efixityLine(a[0], a[1], a[2]);
}
V g_heff_2edriver_2efixityLine_lam0(V self, V *args) {
  V v_e_249 = args[0];
  V v_g_242 = heff_dup(heff_env(self)[0]);
  V v_fx_240 = heff_dup(heff_env(self)[1]);
  V v_i_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2410 = heff_strEq(heff_get(heff_dup(v_e_249), LBL_tighter), heff_get(v_g_242, LBL_id));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_t_2410);
    V v_t_2411 = ({ V b_0 = heff_get(v_fx_240, LBL_groups); V a_1 = v_i_241; V a_2 = heff_get(heff_dup(v_e_249), LBL_looser); V a_3 = MK_INT(0LL); V r_ = (g_heff_2edriver_2eearlierGo(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      heff_drop(v_t_2411);
      return heff_tag(TAG_Just, 1, (V[]){heff_get(v_e_249, LBL_looser)});
    }
    case TAG_False: {
      heff_drop(v_e_249);
      heff_drop(v_t_2411);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_False: {
    heff_drop(v_e_249);
    heff_drop(v_fx_240);
    heff_drop(v_i_241);
    heff_drop(v_t_2410);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2edriver_2efixityLine_lam1(V self, V *args) {
  V v_e_2421 = args[0];
  V v_g_242 = heff_dup(heff_env(self)[0]);
  V v_fx_240 = heff_dup(heff_env(self)[1]);
  V v_i_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2422 = heff_strEq(heff_get(heff_dup(v_e_2421), LBL_looser), heff_get(v_g_242, LBL_id));
  switch (heff_tag_of(v_t_2422)) {
  case TAG_True: {
    heff_drop(v_t_2422);
    V v_t_2423 = ({ V b_0 = heff_get(v_fx_240, LBL_groups); V a_1 = v_i_241; V a_2 = heff_get(heff_dup(v_e_2421), LBL_tighter); V a_3 = MK_INT(0LL); V r_ = (g_heff_2edriver_2eearlierGo(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      heff_drop(v_t_2423);
      return heff_tag(TAG_Just, 1, (V[]){heff_get(v_e_2421, LBL_tighter)});
    }
    case TAG_False: {
      heff_drop(v_e_2421);
      heff_drop(v_t_2423);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  case TAG_False: {
    heff_drop(v_e_2421);
    heff_drop(v_fx_240);
    heff_drop(v_i_241);
    heff_drop(v_t_2422);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_2422);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efixityLines_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2edriver_2efixityLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2efixityLines_entry, 3, 0};

V g_heff_2edriver_2efixityLines(V v_fx_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_fx_240);
    heff_drop(v_i_241);
    return ((V)&g_heff_2edriver_2efixityLines_str0);
  }
  case TAG_Cons: {
    V v_g_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2edriver_2efixityLine(heff_dup(v_fx_240), heff_dup(v_i_241), heff_dup(v_g_243)));
    return heff_strAppend(v_t_245, (g_heff_2edriver_2efixityLines(v_fx_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_rest_244)));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2edriver_2efixityLines_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2efixityLines(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eglueOne_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eglueOne_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eglueOne_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eglueOne_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eglueOne_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2eglueOne_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2edriver_2eglueOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eglueOne_entry, 2, 0};

V g_heff_2edriver_2eglueOne(V v_acc_240, V v_d_241) {
top: ;
  V v_t_242 = heff_get(heff_dup(v_acc_240), LBL_first);
  V v_t_247;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_t_242);
    v_t_247 = ((V)&g_heff_2edriver_2eglueOne_str0);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_242);
    V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_d_241)), MK_INT(1LL));
    V v_x3_244 = (g_prelude_2eindexFrom(((V)&g_heff_2edriver_2eglueOne_str1), heff_strSlice(heff_dup(v_d_241), MK_INT(0LL), v_t_243), MK_INT(0LL)));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      heff_drop(v_x3_244);
      V v_t_245 = heff_get(heff_dup(v_acc_240), LBL_multi);
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_t_245);
        v_t_247 = ((V)&g_heff_2edriver_2eglueOne_str2);
        break;
      }
      case TAG_False: {
        heff_drop(v_t_245);
        v_t_247 = ((V)&g_heff_2edriver_2eglueOne_str3);
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      break;
    }
    case TAG_Just: {
      heff_take(v_x3_244, 0ULL);
      v_t_247 = ((V)&g_heff_2edriver_2eglueOne_str4);
      break;
    }
    default: heff_nomatch(v_x3_244);
    }
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_248 = heff_strAppend(heff_get(v_acc_240, LBL_out), heff_strAppend(v_t_247, heff_dup(v_d_241)));
  V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_d_241)), MK_INT(1LL));
  V v_x3_2410 = (g_prelude_2eindexFrom(((V)&g_heff_2edriver_2eglueOne_str5), heff_strSlice(v_d_241, MK_INT(0LL), v_t_249), MK_INT(0LL)));
  V v_t_2412;
  switch (heff_tag_of(v_x3_2410)) {
  case TAG_Nothing: {
    heff_drop(v_x3_2410);
    v_t_2412 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take(v_x3_2410, 0ULL);
    v_t_2412 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_2410);
  }
  return heff_rec(3, shape_214_188_96, (V[]){v_t_248, v_t_2412, NTAG(TAG_False)});
}
V g_heff_2edriver_2eglueOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eglueOne(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2esigEntry_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2esigEntry_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2edriver_2esigEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2esigEntry_entry, 3, 0};

V g_heff_2edriver_2esigEntry(V v_c_240, V v_ln_241, V v_o_242) {
top: ;
  V v_t_243 = heff_get(heff_get(v_c_240, LBL_top), LBL_globals);
  V v_t_244 = (g_heff_2eglobals_2elookupEntry(v_t_243, heff_get(heff_dup(v_o_242), LBL_key)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_ln_241);
    heff_drop(v_o_242);
    heff_drop(v_t_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse(v_t_244, 1ULL);
    V v_x_246 = heff_get(heff_dup(v_o_242), LBL_name);
    V v_t_247 = (g_heff_2epsurface_2eisOperator(heff_dup(v_x_246)));
    V v_t_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_t_247);
      v_t_248 = heff_strAppend(((V)&g_heff_2edriver_2esigEntry_str0), heff_strAppend(v_x_246, ((V)&g_heff_2edriver_2esigEntry_str1)));
      break;
    }
    case TAG_False: {
      heff_drop(v_t_247);
      v_t_248 = v_x_246;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_249 = (g_heff_2erename_2erkOf(heff_dup(v_ln_241)));
    V v_t_2410 = heff_tr(heff_apply(heff_get(v_t_249, LBL_ty), 1, (V[]){heff_get(heff_dup(v_e_245), LBL_tySyntax)}));
    V v_t_2411 = (g_heff_2erename_2erkOf(v_ln_241));
    V v_t_2412 = heff_tr(heff_apply(heff_get(v_t_2411, LBL_el), 1, (V[]){heff_get(v_e_245, LBL_syntax)}));
    return heff_tag_at(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){(g_heff_2epsurface_2eprintSig_24s520(heff_get(v_o_242, LBL_name), v_t_248, v_t_2410, v_t_2412))});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2edriver_2esigEntry_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2esigEntry(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2einterface_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2einterface_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2einterface_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2einterface_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2edriver_2einterface_lam1(V self, V *args);
V g_heff_2edriver_2einterface_lam0(V self, V *args);
Clo g_heff_2edriver_2einterface_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2einterface_entry, 1, 0};

V g_heff_2edriver_2einterface(V v_c_240) {
top: ;
  V v_t_241 = (g_prelude_2efilter_24s525(heff_get(heff_dup(v_c_240), LBL_opens)));
  V v_x2_242 = (g_prelude_2emap_24s524(v_t_241));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_x2_242);
    v_t_245 = ((V)&g_heff_2edriver_2einterface_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take(v_x2_242, 3ULL);
    v_t_245 = ({ V a_0 = v_x_243; V a_1 = v_xs_244; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_x2_246 = (g_prelude_2emap_24s526(heff_get(heff_dup(v_c_240), LBL_aliases)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_x2_246);
    v_t_249 = ((V)&g_heff_2edriver_2einterface_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take(v_x2_246, 3ULL);
    v_t_249 = ({ V a_0 = v_x_247; V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = heff_get(heff_get(heff_dup(v_c_240), LBL_fixities), LBL_groups);
  V v_t_2411 = ({ V a_0 = heff_get(heff_dup(v_c_240), LBL_fixities); V a_1 = MK_INT(0LL); V a_2 = v_t_2410; V r_ = (g_heff_2edriver_2efixityLines(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = heff_rec(3, shape_214_188_96, (V[]){((V)&g_heff_2edriver_2einterface_str2), NTAG(TAG_False), NTAG(TAG_True)});
  V v_t_2421 = (g_prelude_2emap(heff_clo(g_heff_2edriver_2einterface_lam0, 1, 1, (V[]){heff_dup(v_c_240)}), heff_get(v_c_240, LBL_own)));
  V v_t_2422 = (g_heff_2edriver_2ecatMaybesD(v_t_2421));
  V v_t_2423 = ({ V a_0 = v_t_2412; V a_1 = v_t_2422; V r_ = (g_prelude_2efoldl_24s528(a_0, a_1)); heff_drop(v_t_2422); r_; });
  V v_t_2424 = heff_tag(TAG_Cons, 2, (V[]){heff_get(v_t_2423, LBL_out), NTAG(TAG_Nil)});
  V v_t_2425 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_245, v_t_249), heff_tag(TAG_Cons, 2, (V[]){v_t_2411, v_t_2424})});
  V v_x2_2426 = (g_prelude_2efilter_24s527(v_t_2425));
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_Nil: {
    heff_drop(v_x2_2426);
    return ((V)&g_heff_2edriver_2einterface_str3);
  }
  case TAG_Cons: {
    V v_x_2427 = heff_field(v_x2_2426, 0);
    V v_xs_2428 = heff_field(v_x2_2426, 1);
    heff_take(v_x2_2426, 3ULL);
    return ({ V a_0 = v_x_2427; V a_1 = v_xs_2428; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2428); r_; });
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2edriver_2einterface_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2einterface(a[0]);
}
V g_heff_2edriver_2einterface_lam1(V self, V *args) {
  V v_k_2417 = args[0];
  V v_m_2416 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_d_2418 = (g_heff_2erename_2edescribeKey(heff_dup(v_k_2417)));
  V v_x2_2419 = ({ V a_0 = v_k_2417; V a_1 = v_m_2416; V r_ = (g_map_2elookup_24s8(a_0, a_1)); heff_drop(v_m_2416); r_; });
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Nothing: {
    heff_drop(v_x2_2419);
    return v_d_2418;
  }
  case TAG_Just: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    heff_take(v_x2_2419, 1ULL);
    heff_drop(v_d_2418);
    return v_x_2420;
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2edriver_2einterface_lam0(V self, V *args) {
  V v_o_2413 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2414 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_globals);
  V v_t_2415 = ({ V b_0 = heff_get(v_t_2414, LBL_aliases); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_m_2416 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2415; V r_ = (g_prelude_2efoldl_24s510(a_0, a_1)); heff_drop(v_t_2415); r_; });
  return (g_heff_2edriver_2esigEntry(v_c_240, heff_clo(g_heff_2edriver_2einterface_lam1, 1, 1, (V[]){v_m_2416}), v_o_2413));
}
V g_heff_2edriver_2ecandidatesOf_lam0(V self, V *args);
Clo g_heff_2edriver_2ecandidatesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ecandidatesOf_entry, 1, 0};

V g_heff_2edriver_2ecandidatesOf(V v_c_240) {
top: ;
  V v_t_2410 = (g_prelude_2emap(heff_clo(g_heff_2edriver_2ecandidatesOf_lam0, 1, 1, (V[]){heff_dup(v_c_240)}), heff_get(v_c_240, LBL_own)));
  return (g_heff_2edriver_2ecatMaybesD(v_t_2410));
}
V g_heff_2edriver_2ecandidatesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2ecandidatesOf(a[0]);
}
V g_heff_2edriver_2ecandidatesOf_lam0(V self, V *args) {
  V v_o_241 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_242 = heff_get(heff_get(heff_dup(v_c_240), LBL_top), LBL_globals);
  V v_t_243 = (g_heff_2eglobals_2elookupEntry(v_t_242, heff_get(heff_dup(v_o_241), LBL_key)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_o_241);
    heff_drop(v_c_240);
    heff_drop(v_t_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_e_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse(v_t_243, 1ULL);
    V v_t_245 = heff_get(heff_get(v_c_240, LBL_top), LBL_globals);
    V v_t_246 = (g_heff_2ereadback_2ereadbTypeF_24s197(MK_INT(0LL), heff_get(v_e_244, LBL_type_5f)));
    V v_t_247 = ({ V a_0 = v_t_245; V a_1 = v_t_246; V r_ = (g_heff_2eeffect_2ecomputationEffect(a_0, a_1)); heff_drop(v_t_246); r_; });
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop(v_o_241);
      heff_drop(v_ru_24t_243_24Just);
      heff_drop(v_t_247);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_eff_248 = heff_field(v_t_247, 0);
      heff_take(v_t_247, 1ULL);
      V v_t_249 = heff_rec(3, shape_190_145_74, (V[]){heff_get(heff_dup(v_o_241), LBL_name), heff_get(v_o_241, LBL_key), v_eff_248});
      return heff_tag_at(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){v_t_249});
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
Clo g_heff_2edriver_2eappendLv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2eappendLv_entry, 2, 0};

V g_heff_2edriver_2eappendLv(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2edriver_2eappendLv(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2eappendLv_entry(V self, V *a) {
  (void)self;
  return g_heff_2edriver_2eappendLv(a[0], a[1]);
}
Clo g_heff_2edriver_2ecandLeaves_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2ecandLeaves_entry, 1, 0};

V g_heff_2edriver_2ecandLeaves(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = ({ V b_0 = heff_get(heff_dup(v_r_241), LBL_effect); V r_ = (g_heff_2eeffect_2eleaves(b_0)); heff_drop(b_0); r_; });
    V v_t_244 = (g_heff_2edriver_2ecandLeaves(v_rest_242));
    return (g_heff_2edriver_2eappendLv(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2edriver_2ecandLeaves_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2ecandLeaves(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2edriver_2efits_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2edriver_2efits_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 104, 97, 115, 32, 116, 104, 101, 32, 101, 102, 102, 101, 99, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[142]; } g_heff_2edriver_2efits_str2 = {{0x80000000u, K_STR, 0}, 142, 142, {44, 32, 119, 104, 105, 99, 104, 32, 105, 115, 32, 110, 111, 116, 32, 112, 114, 111, 118, 105, 100, 101, 100, 32, 104, 101, 114, 101, 32, 40, 97, 32, 109, 111, 100, 117, 108, 101, 32, 77, 32, 112, 114, 111, 118, 105, 100, 101, 115, 32, 105, 116, 115, 32, 101, 102, 102, 101, 99, 116, 32, 105, 110, 32, 77, 46, 112, 114, 111, 118, 105, 100, 101, 114, 46, 106, 115, 44, 32, 111, 114, 32, 77, 46, 112, 114, 111, 118, 105, 100, 101, 114, 46, 99, 32, 102, 111, 114, 32, 67, 44, 32, 98, 101, 115, 105, 100, 101, 32, 77, 46, 104, 102, 59, 32, 96, 36, 104, 111, 115, 116, 96, 32, 115, 97, 121, 115, 32, 119, 104, 101, 114, 101, 32, 105, 116, 32, 114, 117, 110, 115, 41}};
V g_heff_2edriver_2efits_lam0(V self, V *args);
Clo g_heff_2edriver_2efits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2efits_entry, 2, 0};

V g_heff_2edriver_2efits(V v_handled_240, V v_r_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_get(heff_dup(v_r_241), LBL_effect); V r_ = (g_heff_2eeffect_2eleaves(b_0)); heff_drop(b_0); r_; });
  V v_t_246 = (g_prelude_2efilter(heff_clo(g_heff_2edriver_2efits_lam0, 1, 1, (V[]){heff_dup(v_handled_240)}), v_t_242));
  V v_ms_247 = (g_heff_2edriver_2enubStrD(v_t_246));
  switch (heff_tag_of(v_ms_247)) {
  case TAG_Nil: {
    heff_drop(v_ms_247);
    V v_t_248 = heff_rec(2, shape_145_74, (V[]){heff_get(heff_dup(v_r_241), LBL_key), heff_get(v_r_241, LBL_effect)});
    return heff_tag(TAG_Right, 1, (V[]){v_t_248});
  }
  case TAG_Cons: {
    V v_t_2413;
    switch (heff_tag_of(v_ms_247)) {
    case TAG_Nil: {
      heff_drop(v_ms_247);
      v_t_2413 = ((V)&g_heff_2edriver_2efits_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_ms_247, 0);
      V v_xs_2412 = heff_field(v_ms_247, 1);
      heff_take(v_ms_247, 3ULL);
      v_t_2413 = ({ V a_0 = v_x_2411; V a_1 = v_xs_2412; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_ms_247);
    }
    V v_t_2414 = heff_strAppend(heff_get(v_r_241, LBL_name), heff_strAppend(((V)&g_heff_2edriver_2efits_str1), heff_strAppend(v_t_2413, ((V)&g_heff_2edriver_2efits_str2))));
    return heff_tag(TAG_Left, 1, (V[]){v_t_2414});
  }
  default: return heff_nomatch(v_ms_247);
  }
}
V g_heff_2edriver_2efits_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2efits(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2edriver_2efits_lam0(V self, V *args) {
  V v_l_243 = args[0];
  V v_handled_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_244 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){v_l_243}));
  V v_x1_245 = ({ V a_0 = v_t_244; V a_1 = v_handled_240; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_handled_240); r_; });
  switch (heff_tag_of(v_x1_245)) {
  case TAG_True: {
    heff_drop(v_x1_245);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_x1_245);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_245);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2edriver_2efindNamed_str0 = {{0x80000000u, K_STR, 0}, 31, 31, {32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 99, 111, 109, 112, 117, 116, 97, 116, 105, 111, 110, 44, 32, 96, 67, 111, 32, 104, 32, 97, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2edriver_2efindNamed_str1 = {{0x80000000u, K_STR, 0}, 31, 31, {32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 99, 111, 109, 112, 117, 116, 97, 116, 105, 111, 110, 44, 32, 96, 67, 111, 32, 104, 32, 97, 96}};
Clo g_heff_2edriver_2efindNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2efindNamed_entry, 4, 0};

V g_heff_2edriver_2efindNamed(V v_handled_240, V v_c_241, V v_x_242, V v_o_243) {
top: ;
  V v_t_244 = heff_get(heff_get(heff_dup(v_c_241), LBL_top), LBL_globals);
  V v_t_245 = (g_heff_2eglobals_2elookupEntry(v_t_244, heff_get(heff_dup(v_o_243), LBL_key)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_c_241);
    heff_drop(v_o_243);
    heff_drop(v_t_245);
    return heff_tag(TAG_Left, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2edriver_2efindNamed_str0))});
  }
  case TAG_Just: {
    V v_e_246 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse(v_t_245, 1ULL);
    V v_t_247 = heff_get(heff_get(v_c_241, LBL_top), LBL_globals);
    V v_t_248 = (g_heff_2ereadback_2ereadbTypeF_24s197(MK_INT(0LL), heff_get(v_e_246, LBL_type_5f)));
    V v_t_249 = ({ V a_0 = v_t_247; V a_1 = v_t_248; V r_ = (g_heff_2eeffect_2ecomputationEffect(a_0, a_1)); heff_drop(v_t_248); r_; });
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop(v_o_243);
      heff_drop(v_t_249);
      return heff_tag_at(v_ru_24t_245_24Just, TAG_Left, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2edriver_2efindNamed_str1))});
    }
    case TAG_Just: {
      V v_eff_2410 = heff_field(v_t_249, 0);
      heff_take(v_t_249, 1ULL);
      heff_drop(v_ru_24t_245_24Just);
      V v_t_2411 = heff_rec(3, shape_190_145_74, (V[]){v_x_242, heff_get(v_o_243, LBL_key), v_eff_2410});
      return (g_heff_2edriver_2efits(v_handled_240, v_t_2411));
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2edriver_2efindNamed_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2efindNamed(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_heff_2edriver_2efindFirst_str0 = {{0x80000000u, K_STR, 0}, 32, 32, {110, 111, 32, 99, 111, 109, 112, 117, 116, 97, 116, 105, 111, 110, 44, 32, 96, 67, 111, 32, 104, 32, 97, 96, 44, 32, 116, 111, 32, 114, 117, 110}};
V g_heff_2edriver_2efindFirst_lam1(V self, V *args);
V g_heff_2edriver_2efindFirst_lam0(V self, V *args);
Clo g_heff_2edriver_2efindFirst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2efindFirst_entry, 2, 0};

V g_heff_2edriver_2efindFirst(V v_handled_240, V v_cands_241) {
top: ;
  V v_t_2411 = (g_prelude_2efind(heff_clo(g_heff_2edriver_2efindFirst_lam0, 1, 1, (V[]){heff_dup(v_handled_240)}), v_cands_241));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    heff_drop(v_t_2411);
    switch (heff_tag_of(v_cands_241)) {
    case TAG_Nil: {
      return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2edriver_2efindFirst_str0)});
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_cands_241, 0);
      return (g_heff_2edriver_2efits(v_handled_240, heff_dup(v_x_2412)));
    }
    default: return heff_nomatch(v_cands_241);
    }
  }
  case TAG_Just: {
    V v_r_2414 = heff_field(v_t_2411, 0);
    V v_ru_24t_2411_24Just = heff_take_reuse(v_t_2411, 1ULL);
    V v_t_2415 = heff_rec(2, shape_145_74, (V[]){heff_get(heff_dup(v_r_2414), LBL_key), heff_get(v_r_2414, LBL_effect)});
    return heff_tag_at(v_ru_24t_2411_24Just, TAG_Right, 1, (V[]){v_t_2415});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2edriver_2efindFirst_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2efindFirst(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2edriver_2efindFirst_lam1(V self, V *args) {
  V v_l_244 = args[0];
  V v_handled_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_245 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){v_l_244}));
  V v_x1_246 = ({ V a_0 = v_t_245; V a_1 = v_handled_240; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_handled_240); r_; });
  switch (heff_tag_of(v_x1_246)) {
  case TAG_True: {
    heff_drop(v_x1_246);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_x1_246);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2edriver_2efindFirst_lam0(V self, V *args) {
  V v_r_242 = args[0];
  V v_handled_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_243 = ({ V b_0 = heff_get(v_r_242, LBL_effect); V r_ = (g_heff_2eeffect_2eleaves(b_0)); heff_drop(b_0); r_; });
  V v_t_247 = (g_prelude_2efilter(heff_clo(g_heff_2edriver_2efindFirst_lam1, 1, 1, (V[]){v_handled_240}), v_t_243));
  V v_x1_248 = (g_heff_2edriver_2enubStrD(v_t_247));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nil: {
    heff_drop(v_x1_248);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    heff_take(v_x1_248, 0ULL);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_248);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2edriver_2efindRunnable_str0 = {{0x80000000u, K_STR, 0}, 14, 14, {110, 111, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 32}};
V g_heff_2edriver_2efindRunnable_lam0(V self, V *args);
Clo g_heff_2edriver_2efindRunnable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2edriver_2efindRunnable_entry, 3, 0};

V g_heff_2edriver_2efindRunnable(V v_handled_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_x3_242);
    V v_t_243 = (g_heff_2edriver_2ecandidatesOf(v_c_241));
    return ({ V a_0 = v_handled_240; V a_1 = v_t_243; V r_ = (g_heff_2edriver_2efindFirst(a_0, a_1)); heff_drop(v_t_243); r_; });
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse(v_x3_242, 1ULL);
    V v_t_246 = ({ V a_0 = heff_clo(g_heff_2edriver_2efindRunnable_lam0, 1, 1, (V[]){heff_dup(v_x_244)}); V b_1 = heff_get(heff_dup(v_c_241), LBL_own); V r_ = (g_prelude_2efind(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop(v_c_241);
      heff_drop(v_t_246);
      return heff_tag_at(v_ru_24x3_242_24Just, TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2edriver_2efindRunnable_str0), v_x_244)});
    }
    case TAG_Just: {
      V v_o_247 = heff_field(v_t_246, 0);
      heff_take(v_t_246, 1ULL);
      heff_drop(v_ru_24x3_242_24Just);
      return (g_heff_2edriver_2efindNamed(v_handled_240, v_c_241, v_x_244, v_o_247));
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2edriver_2efindRunnable_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2edriver_2efindRunnable(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2edriver_2efindRunnable_lam0(V self, V *args) {
  V v_o_245 = args[0];
  V v_x_244 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_o_245, LBL_name), v_x_244);
}