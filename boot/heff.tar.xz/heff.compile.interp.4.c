// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_Ok 9325
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_syntax 1059664654
V g_heff_2ecompile_2einterp_2ebitsRead(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsRead_clo;
V g_heff_2ecompile_2einterp_2ebitwise_24s412137238x677449340(V, V, V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitwise_24s412137238x677449340_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitwise_24s412137238x677449340_clo;
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s510231599x1873844631(V, V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s510231599x1873844631_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s510231599x1873844631_clo;
V g_heff_2ecompile_2einterp_2efixThunk(V, V, V);
V g_heff_2ecompile_2einterp_2efixThunk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixThunk_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get(void);
V g_heff_2ecompile_2einterp_2efmix64(V);
V g_heff_2ecompile_2einterp_2efmix64_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efmix64_clo;
V g_heff_2ecompile_2einterp_2egenGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2egenGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2egenGo_clo;
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get(void);
V g_heff_2ecompile_2einterp_2eintAtV(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintAtV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintAtV_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_clo;
V g_heff_2ecompile_2einterp_2elittleInGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2elittleInGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elittleInGo_clo;
V g_heff_2ecompile_2einterp_2elittleOutGo(V, V, V, V);
V g_heff_2ecompile_2einterp_2elittleOutGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elittleOutGo_clo;
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotARune_get(void);
V g_heff_2ecompile_2einterp_2enotAnArray_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
HeffT2 g_heff_2ecompile_2einterp_2enthV_24cpr(V, V);
V g_heff_2ecompile_2einterp_2erune2(V);
V g_heff_2ecompile_2einterp_2erune2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2erune2_clo;
V g_heff_2ecompile_2einterp_2etoListV(V);
V g_heff_2ecompile_2einterp_2etoListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(V, V, V);
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_clo;
V g_heff_2ecompile_2einterp_2etwoTo(V);
V g_heff_2ecompile_2einterp_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoTo_clo;
V g_heff_2ecompile_2einterp_2eword64_get(void);
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_std_2eordmap_2einsert_24s772458816x1205354502(V, V, V);
V g_std_2eordmap_2einsert_24s772458816x1205354502_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s772458816x1205354502_clo;
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAnArray_str0, 38, "a primitive given what is not an array");

static V g_heff_2ecompile_2einterp_2enotAnArray_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAnArray_st;
static V g_heff_2ecompile_2einterp_2enotAnArray_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAnArray_str0)});
}
V g_heff_2ecompile_2einterp_2enotAnArray_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAnArray_st)) return g_heff_2ecompile_2einterp_2enotAnArray_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAnArray_val, &g_heff_2ecompile_2einterp_2enotAnArray_st, g_heff_2ecompile_2einterp_2enotAnArray_init);
}
V g_heff_2ecompile_2einterp_2erune2_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2erune2_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2erune2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2erune2_entry, 1, 0};

V g_heff_2ecompile_2einterp_2erune2(V v_f_240) {
top: ;
  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2erune2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2ecompile_2einterp_2erune2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2erune2(a[0]);
}
V g_heff_2ecompile_2einterp_2erune2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Ok = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      V v_f_249 = v_f_240;
      V v_x2_2410 = v_v_246;
      V v_x3_2411 = v_v_248;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_VFun: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VCons: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VTag: {
        heff_take_n(v_x2_2410, 0ULL, 2);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VInt: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VStr: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VRune: {
        V v_a_2420 = heff_field(v_x2_2410, 0);
        heff_take_n(v_x2_2410, 1ULL, 1);
        switch (heff_tag_of(v_x3_2411)) {
        case TAG_VFun: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2420);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VCons: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2420);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VTag: {
          heff_take_n(v_x3_2411, 0ULL, 2);
          heff_drop(v_f_249);
          heff_drop(v_a_2420);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VInt: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2420);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2420);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2420);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VStr: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2420);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VRune: {
          V v_b_2429 = heff_field(v_x3_2411, 0);
          heff_take_n(v_x3_2411, 1ULL, 1);
          V f_ = v_f_249;
          args[0] = v_a_2420;
          args[1] = v_b_2429;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VArr: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2420);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2420);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VBits: {
          heff_take_n(v_x3_2411, 0ULL, 2);
          heff_drop(v_f_249);
          heff_drop(v_a_2420);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VErased: {
          heff_drop(v_f_249);
          heff_drop(v_a_2420);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        default: return heff_nomatch(v_x3_2411);
        }
      }
      case TAG_VArr: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VBits: {
        heff_take_n(v_x2_2410, 0ULL, 2);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VErased: {
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      default: return heff_nomatch(v_x2_2410);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2438 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return heff_tag_at_n(v_ru_24x1_245_24Ok, TAG_Bug, 1, (V[]){v_what_2438});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2439 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Bug = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return heff_tag_at_n(v_ru_24x1_245_24Bug, TAG_Bug, 1, (V[]){v_what_2439});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2einterp_2erune2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2erune2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
Clo g_heff_2ecompile_2einterp_2elittleOutGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2elittleOutGo_entry, 4, 0};

V g_heff_2ecompile_2einterp_2elittleOutGo(V v_u_240, V v_box_24k_241, V v_box_24i_242, V v_w_243) {
  int64_t v_k_241 = heff_unbox_word(v_box_24k_241);
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
top: ;
  if ((v_k_241 <= v_i_242)) {
    heff_drop(v_u_240);
    return v_w_243;
  } else {
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((((int64_t)8ULL) * v_i_242))));
    V v_t_245 = heff_intMod(heff_intDiv(heff_dup(v_u_240), v_t_244), MK_INT(256LL));
    V v_t_246 = heff_intAdd(heff_intMul(v_w_243, MK_INT(256LL)), v_t_245);
    V t_0 = v_u_240;
    int64_t t_1 = v_k_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = v_t_246;
    v_u_240 = t_0;
    v_k_241 = t_1;
    v_i_242 = t_2;
    v_w_243 = t_3;
    goto top;
  }
}
V g_heff_2ecompile_2einterp_2elittleOutGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2elittleOutGo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2einterp_2eintAtV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eintAtV_entry, 5, 0};

V g_heff_2ecompile_2einterp_2eintAtV(V v_s_240, V v_limit_241, V v_o_242, V v_n_243, V v_f_244) {
top: ;
  if ((heff_intLt_c_lent(v_o_242, MK_INT(0LL), 2) || (heff_intLt_c_lent(v_n_243, MK_INT(0LL), 2) || (heff_intLt_c_lent(MK_INT(64LL), v_n_243, 1) || heff_intLt_c(heff_dup(v_limit_241), heff_intAdd(heff_dup(v_o_242), heff_dup(v_n_243))))))) {
    heff_drop(v_limit_241);
    heff_drop(v_o_242);
    heff_drop(v_n_243);
    heff_drop(v_f_244);
    return NTAG(TAG_Abn);
  } else {
    heff_drop(v_limit_241);
    if ((heff_unbox_word(heff_intMod(heff_dup(v_f_244), MK_INT(2LL))) == ((int64_t)1ULL))) {
      V v_w_245 = (g_heff_2ecompile_2einterp_2ebitsRead(v_s_240, v_o_242, heff_dup(v_n_243), MK_INT(0LL)));
      V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_n_243) % ((int64_t)8ULL)))));
      int64_t v_t_247 = (((int64_t)8ULL) * (heff_peek_word(v_n_243) / ((int64_t)8ULL)));
      V v_t_248 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word(v_t_247)));
      V v_t_249 = heff_intMul(heff_intMod(heff_dup(v_w_245), v_t_246), v_t_248);
      V v_u_2410 = (g_heff_2ecompile_2einterp_2elittleInGo(v_w_245, heff_dup(v_n_243), heff_box_word((heff_peek_word(v_n_243) / ((int64_t)8ULL))), MK_INT(0LL), v_t_249));
      V v_t_2411 = heff_intMod(heff_intDiv(v_f_244, MK_INT(2LL)), MK_INT(2LL));
      V v_t_2414;
      if ((heff_unbox_word(v_t_2411) == ((int64_t)1ULL))) {
        if ((((int64_t)0ULL) < heff_peek_word(v_n_243))) {
          V v_y_2412 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_n_243) - ((int64_t)1ULL)))));
          if (heff_intLe_c_lent(v_y_2412, v_u_2410, 1)) {
            V v_t_2413 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_243));
            v_t_2414 = heff_intSub(v_u_2410, v_t_2413);
          } else {
            heff_drop(v_n_243);
            v_t_2414 = v_u_2410;
          }
        } else {
          heff_drop(v_n_243);
          v_t_2414 = v_u_2410;
        }
      } else {
        heff_drop(v_n_243);
        v_t_2414 = v_u_2410;
      }
      return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2414})});
    } else {
      V v_u_2415 = (g_heff_2ecompile_2einterp_2ebitsRead(v_s_240, v_o_242, heff_dup(v_n_243), MK_INT(0LL)));
      V v_t_2416 = heff_intMod(heff_intDiv(v_f_244, MK_INT(2LL)), MK_INT(2LL));
      V v_t_2419;
      if ((heff_unbox_word(v_t_2416) == ((int64_t)1ULL))) {
        if ((((int64_t)0ULL) < heff_peek_word(v_n_243))) {
          V v_y_2417 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_n_243) - ((int64_t)1ULL)))));
          if (heff_intLe_c_lent(v_y_2417, v_u_2415, 1)) {
            V v_t_2418 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_243));
            v_t_2419 = heff_intSub(v_u_2415, v_t_2418);
          } else {
            heff_drop(v_n_243);
            v_t_2419 = v_u_2415;
          }
        } else {
          heff_drop(v_n_243);
          v_t_2419 = v_u_2415;
        }
      } else {
        heff_drop(v_n_243);
        v_t_2419 = v_u_2415;
      }
      return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2419})});
    }
  }
}
V g_heff_2ecompile_2einterp_2eintAtV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2eintAtV(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str0, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str1, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str2, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str3, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str4, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str5, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str6, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str7, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str8, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str9, 30, "applied what is not a function");
V g_heff_2ecompile_2einterp_2egenGo_lam0(V self, V *args);
V g_heff_2ecompile_2einterp_2egenGo_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2egenGo_lam2(V self, V *args);
Clo g_heff_2ecompile_2einterp_2egenGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2egenGo_entry, 5, 0};

V g_heff_2ecompile_2einterp_2egenGo(V v_d_240, V v_j_241, V v_n_242, V v_f_243, V v_k_244) {
top: ;
  if (heff_intLe_c_lent(v_n_242, v_j_241, 0)) {
    heff_drop(v_d_240);
    heff_drop(v_j_241);
    heff_drop(v_n_242);
    heff_drop(v_f_243);
    return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_Nil)});
  } else {
    switch (heff_tag_of(v_f_243)) {
    case TAG_VFun: {
      V v_f_245 = heff_dup(heff_field(v_f_243, 0));
      V v_x1_247 = heff_tr(heff_call(v_f_245, 2, (V[]){heff_dup(v_d_240), heff_clo_n(g_heff_2ecompile_2einterp_2egenGo_lam0, 1, 1, (V[]){heff_dup(v_j_241)})}));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Ok: {
        V v_v_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V t_0 = v_d_240;
        V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
        V t_2 = v_n_242;
        V t_3 = v_f_243;
        V t_4 = heff_clo_n(g_heff_2ecompile_2einterp_2egenGo_lam1, 1, 2, (V[]){v_k_244, v_v_248});
        v_d_240 = t_0;
        v_j_241 = t_1;
        v_n_242 = t_2;
        v_f_243 = t_3;
        v_k_244 = t_4;
        goto top;
      }
      case TAG_Abn: {
        heff_drop(v_d_240);
        heff_drop(v_j_241);
        heff_drop(v_n_242);
        heff_drop_tag(v_f_243, 1);
        heff_drop(v_k_244);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_d_240);
        heff_drop(v_j_241);
        heff_drop(v_n_242);
        heff_drop_tag(v_f_243, 1);
        heff_drop(v_k_244);
        return NTAG(TAG_Div);
      }
      case TAG_Bug: {
        V v_what_2410 = heff_field(v_x1_247, 0);
        V v_ru_24x1_247_24Bug = heff_take_reuse_n(v_x1_247, 1ULL, 1);
        heff_drop(v_d_240);
        heff_drop(v_j_241);
        heff_drop(v_n_242);
        heff_drop_tag(v_f_243, 1);
        heff_drop(v_k_244);
        return heff_tag_at_n(v_ru_24x1_247_24Bug, TAG_Bug, 1, (V[]){v_what_2410});
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    case TAG_VCons: {
      V v_ru_24f_243_24VCons = heff_take_reuse_n(v_f_243, 0ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_k_244);
      return heff_tag_at_n(v_ru_24f_243_24VCons, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str0)});
    }
    case TAG_VTag: {
      heff_take_n(v_f_243, 0ULL, 2);
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_k_244);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str1)});
    }
    case TAG_VInt: {
      V v_ru_24f_243_24VInt = heff_take_reuse_n(v_f_243, 0ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_k_244);
      return heff_tag_at_n(v_ru_24f_243_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str2)});
    }
    case TAG_VFloat: {
      V v_ru_24f_243_24VFloat = heff_take_reuse_na(v_f_243, 0ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_k_244);
      return heff_tag_at_n(v_ru_24f_243_24VFloat, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str3)});
    }
    case TAG_VFloat32: {
      V v_ru_24f_243_24VFloat32 = heff_take_reuse_n(v_f_243, 0ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_k_244);
      return heff_tag_at_n(v_ru_24f_243_24VFloat32, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str4)});
    }
    case TAG_VStr: {
      V v_ru_24f_243_24VStr = heff_take_reuse_n(v_f_243, 0ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_k_244);
      return heff_tag_at_n(v_ru_24f_243_24VStr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str5)});
    }
    case TAG_VRune: {
      V v_ru_24f_243_24VRune = heff_take_reuse_n(v_f_243, 0ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_k_244);
      return heff_tag_at_n(v_ru_24f_243_24VRune, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str6)});
    }
    case TAG_VArr: {
      V v_ru_24f_243_24VArr = heff_take_reuse_n(v_f_243, 0ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_k_244);
      return heff_tag_at_n(v_ru_24f_243_24VArr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str7)});
    }
    case TAG_VBytes: {
      V v_ru_24f_243_24VBytes = heff_take_reuse_n(v_f_243, 0ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_k_244);
      return heff_tag_at_n(v_ru_24f_243_24VBytes, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str8)});
    }
    case TAG_VBits: {
      heff_take_n(v_f_243, 0ULL, 2);
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_k_244);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str9)});
    }
    case TAG_VErased: {
      V v_t_2423 = NTAG(TAG_VErased);
      V t_0 = v_d_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      V t_2 = v_n_242;
      V t_3 = v_f_243;
      V t_4 = heff_clo_n(g_heff_2ecompile_2einterp_2egenGo_lam2, 1, 2, (V[]){v_k_244, v_t_2423});
      v_d_240 = t_0;
      v_j_241 = t_1;
      v_n_242 = t_2;
      v_f_243 = t_3;
      v_k_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_f_243);
    }
  }
}
V g_heff_2ecompile_2einterp_2egenGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2egenGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2einterp_2egenGo_lam0(V self, V *args) {
  V v_d_246 = args[0];
  V v_j_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_246);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_j_241})});
}
V g_heff_2ecompile_2einterp_2egenGo_lam1(V self, V *args) {
  V v_vs_249 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_v_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_v_248, v_vs_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2einterp_2egenGo_lam2(V self, V *args) {
  V v_vs_2424 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_t_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_vs_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2etoListV_str0, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2einterp_2etoListV_str1, 4, "Cons");
Clo g_heff_2ecompile_2einterp_2etoListV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2etoListV_entry, 1, 0};

V g_heff_2ecompile_2einterp_2etoListV(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2etoListV_str0), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2einterp_2etoListV(v_xs_242));
    V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2etoListV_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, v_t_244})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2etoListV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2etoListV(a[0]);
}

HeffT2 g_heff_2ecompile_2einterp_2enthV_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_xs_243;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2einterp_2efmix64_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efmix64_entry, 1, 0};

V g_heff_2ecompile_2einterp_2efmix64(V v_h_240) {
top: ;
  V v_t_241 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(33LL)));
  V v_b_242 = heff_intDiv(heff_dup(v_h_240), v_t_241);
  V v_t_243 = (g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(MK_INT(2LL), v_h_240, v_b_242));
  V v_h_244 = heff_intMod(heff_intMul(v_t_243, HEFF_BIG("18397679294719823053")), heff_dup(g_heff_2ecompile_2einterp_2eword64_get()));
  V v_t_245 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(33LL)));
  V v_b_246 = heff_intDiv(heff_dup(v_h_244), v_t_245);
  V v_t_247 = (g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(MK_INT(2LL), v_h_244, v_b_246));
  V v_h_248 = heff_intMod(heff_intMul(v_t_247, HEFF_BIG("14181476777654086739")), heff_dup(g_heff_2ecompile_2einterp_2eword64_get()));
  V v_t_249 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(33LL)));
  V v_b_2410 = heff_intDiv(heff_dup(v_h_248), v_t_249);
  return (g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(MK_INT(2LL), v_h_248, v_b_2410));
}
V g_heff_2ecompile_2einterp_2efmix64_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efmix64(a[0]);
}
Clo g_heff_2ecompile_2einterp_2ebitwise_24s412137238x677449340_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitwise_24s412137238x677449340_entry, 6, 0};

V g_heff_2ecompile_2einterp_2ebitwise_24s412137238x677449340(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24n_243, V v_a_244, V v_b_245) {
  int64_t v_n_243 = heff_unbox_word(v_box_24n_243);
top: ;
  if ((v_n_243 == ((int64_t)0ULL))) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_a_244);
    heff_drop(v_b_245);
    return MK_INT(0LL);
  } else {
    int64_t v_t_246 = (heff_unbox_word(heff_intMod(heff_dup(v_a_244), MK_INT(2LL))) + heff_unbox_word(heff_intMod(heff_dup(v_b_245), MK_INT(2LL))));
    V v_t_247;
    if ((heff_peek_word(v_lit_240) < v_t_246)) {
      v_t_247 = heff_dup(v_lit_241);
    } else {
      v_t_247 = heff_dup(v_lit_242);
    }
    V v_t_248 = (g_heff_2ecompile_2einterp_2ebitwise_24s412137238x677449340(v_lit_240, v_lit_241, v_lit_242, heff_box_word((v_n_243 - ((int64_t)1ULL))), heff_intDiv(v_a_244, MK_INT(2LL)), heff_intDiv(v_b_245, MK_INT(2LL))));
    return heff_intAdd(v_t_247, heff_intMul(MK_INT(2LL), v_t_248));
  }
}
V g_heff_2ecompile_2einterp_2ebitwise_24s412137238x677449340_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitwise_24s412137238x677449340(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_st;
static V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_st)) return g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_val, &g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_st, g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_init);
}
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VInt, 1, (V[]){heff_intSub(v_a_2412, v_b_2417)});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam1, 2, 1, (V[]){v_a_241})})});
}
Clo g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(V v_a_240, V v_b_241) {
top: ;
  if (((heff_intEq_c_lent(v_a_240, MK_INT(0LL), 2) || heff_intEq_c_lent(v_a_240, MK_INT(-1LL), 2)) && (heff_intEq_c_lent(v_b_241, MK_INT(0LL), 2) || heff_intEq_c_lent(v_b_241, MK_INT(-1LL), 2)))) {
    int64_t v_t_242 = (heff_unbox_word(heff_intMod(v_a_240, MK_INT(2LL))) * heff_unbox_word(heff_intMod(v_b_241, MK_INT(2LL))));
    return heff_box_word((((int64_t)0ULL) - v_t_242));
  } else {
    int64_t v_t_243 = (heff_unbox_word(heff_intMod(heff_dup(v_a_240), MK_INT(2LL))) * heff_unbox_word(heff_intMod(heff_dup(v_b_241), MK_INT(2LL))));
    V v_t_244 = (g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(heff_intDiv(v_a_240, MK_INT(2LL)), heff_intDiv(v_b_241, MK_INT(2LL))));
    return heff_intAdd(heff_box_word(v_t_243), heff_intMul(MK_INT(2LL), v_t_244));
  }
}
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_st;
static V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_st)) return g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_val;
  return heff_global(&g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_val, &g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_st, g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_init);
}
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VFloat: {
        double v_a_2413 = heff_tflat_f64(v_v_245, 0);
        heff_take_na(v_v_245, 0ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VFloat: {
          double v_b_2419 = heff_tflat_f64(v_v_247, 0);
          heff_take_na(v_v_247, 0ULL, 1);
          V v_t_2420 = heff_tag_at_nf(v_ru_24x1_246_24Ok, TAG_VFloat, 1, 1u, (V[]){heff_word_f64((v_a_2413 / v_b_2419))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam1, 2, 1, (V[]){v_a_241})})});
}
Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s510231599x1873844631_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s510231599x1873844631_entry, 6, 0};

V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s510231599x1873844631(V v_lit_240, V v_lit_241, V v_lit_242, V v_ge_243, V v_x3_244, V v_acc_245) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_ge_243);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_245));
  }
  case TAG_Cons: {
    V v_x31_246 = heff_field(v_x3_244, 0);
    V v_rest_247 = heff_field(v_x3_244, 1);
    V v_ru_24x3_244_24Cons = heff_take_reuse_n(v_x3_244, 3ULL, 2);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x31_246, 0);
      V v_entry_249 = heff_field(v_x31_246, 1);
      V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
      V v_r_2410 = heff_tr(g_heff_2ecompile_2einterp_2efixThunk(heff_dup(v_ge_243), heff_get_n(v_entry_249, 0, 4), MK_INT(0LL)));
      V v_t_2411 = (g_std_2eordmap_2einsert_24s772458816x1205354502(heff_dup(v_r_2410), v_ge_243, heff_dup(v_x_248)));
      V v_t_2415;
      if (heff_strEq_c(heff_strSlice_lent(v_x_248, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
        V v_t_2414;
        switch (heff_tag_of(v_r_2410)) {
        case TAG_Ok: {
          V v_v_2412 = heff_field(v_r_2410, 0);
          V v_ru_24r_2410_24Ok = heff_take_reuse_n(v_r_2410, 1ULL, 1);
          v_t_2414 = heff_tag_at_n(v_ru_24r_2410_24Ok, TAG_RSucceeded, 1, (V[]){v_v_2412});
          break;
        }
        case TAG_Abn: {
          v_t_2414 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          v_t_2414 = NTAG(TAG_RDiverged);
          break;
        }
        case TAG_Bug: {
          V v_what_2413 = heff_field(v_r_2410, 0);
          V v_ru_24r_2410_24Bug = heff_take_reuse_n(v_r_2410, 1ULL, 1);
          v_t_2414 = heff_tag_at_n(v_ru_24r_2410_24Bug, TAG_RBug, 1, (V[]){v_what_2413});
          break;
        }
        default: heff_nomatch(v_r_2410);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24x3_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_248, v_t_2414}), v_acc_245});
      } else {
        heff_drop_cell(v_ru_24x3_244_24Cons, 2);
        heff_drop(v_x_248);
        heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
        heff_drop(v_r_2410);
        v_t_2415 = v_acc_245;
      }
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_t_2411;
      V t_4 = v_rest_247;
      V t_5 = v_t_2415;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_ge_243 = t_3;
      v_x3_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s510231599x1873844631_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s510231599x1873844631(a0, a1, a2, a[3], a[4], a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_str0, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_str1, 4, "Cons");
Clo g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_entry, 3, 0};

V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(V v_lit_240, V v_box_24a_241, V v_b_242) {
  int64_t v_a_241 = heff_unbox_word(v_box_24a_241);
top: ;
  if ((heff_peek_word(v_b_242) < v_a_241)) {
    heff_drop(v_b_242);
    return heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_str0), NTAG(TAG_Nil)});
  } else {
    V v_x_243 = heff_tag_n(TAG_VInt, 1, (V[]){heff_strByteAt_lent(v_lit_240, heff_box_word(v_a_241), 2)});
    V v_t_244 = (g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(v_lit_240, heff_box_word((v_a_241 + ((int64_t)1ULL))), v_b_242));
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_t_245})});
  }
}
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(a0, a[1], a[2]); heff_drop(a0); return r;
}