// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_EProject 35489
#define TAG_ERecord 5518
#define TAG_ESpec 56652
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ImplicitParam 51130
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Large 60129
#define TAG_Many 40086
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_None 17785
#define TAG_Ok 9325
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_PAs 26446
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PSelf 48502
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_Rest 61983
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SGlobal 8650
#define TAG_SWarning 44190
#define TAG_SetField 47531
#define TAG_Small 51389
#define TAG_Some 35657
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define TAG_Text 56194
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VCons 11629
#define TAG_VErased 42634
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_alias 294261354
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_arg 306384
#define LBL_arity 294440695
#define LBL_assoc 294479919
#define LBL_at 9882
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_blank 295177582
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_build 295453320
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_copies 592412158
#define LBL_detail 611917692
#define LBL_diags 296935042
#define LBL_dir 308999
#define LBL_doc 309170
#define LBL_el 9998
#define LBL_emits 297985818
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectFrom 460383968
#define LBL_expectTo 956903013
#define LBL_field 298786068
#define LBL_first 298798794
#define LBL_fixed 298804110
#define LBL_fixities 357800079
#define LBL_from 9647217
#define LBL_global 704121550
#define LBL_groups 709681407
#define LBL_hash 9690581
#define LBL_holds 300818350
#define LBL_id 10114
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_item 9738202
#define LBL_js 10160
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_label 304085774
#define LBL_level 304224158
#define LBL_line 9817275
#define LBL_local 304503685
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_member 869372357
#define LBL_meta 9843404
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ok 10307
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_owner 307523277
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_places 961367927
#define LBL_post 9942375
#define LBL_pre 320797
#define LBL_protos 967342774
#define LBL_refs 9991943
#define LBL_renames 1324191545
#define LBL_severity 75955546
#define LBL_ships 310766033
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_sol 323594
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_syntax 1059664654
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_tok 324554
#define LBL_ty 10476
#define LBL_units 312791945
#define LBL_use 325633
#define LBL_uses 10094739
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_ver 326173
#define LBL_version 583465758
#define LBL_watch 314261737
static uint32_t shape_arg__pre__post[] = {LBL_arg, LBL_pre, LBL_post};
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_js__env[] = {LBL_js, LBL_env};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_local__global[] = {LBL_local, LBL_global};
static uint32_t shape_name__field__use[] = {LBL_name, LBL_field, LBL_use};
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_name__kind__span[] = {LBL_name, LBL_kind, LBL_span};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eclosureGo(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclosureGo_clo;
V g_heff_2ebuild_2edriver_2eelabNeeding(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabNeeding_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNeeding_clo;
V g_heff_2ebuild_2edriver_2eenvOne(V, V);
V g_heff_2ebuild_2edriver_2eenvOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eenvOne_clo;
V g_heff_2ebuild_2edriver_2eglueOne(V, V);
V g_heff_2ebuild_2edriver_2eglueOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eglueOne_clo;
V g_heff_2ebuild_2edriver_2ehint(V);
V g_heff_2ebuild_2edriver_2ehint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ehint_clo;
V g_heff_2ebuild_2edriver_2elabelOfV(V);
V g_heff_2ebuild_2edriver_2elabelOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elabelOfV_clo;
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2eoutcomeOfV(V);
V g_heff_2ebuild_2edriver_2eoutcomeOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eoutcomeOfV_clo;
V g_heff_2ebuild_2edriver_2epromoteAt(V, V, V, V);
V g_heff_2ebuild_2edriver_2epromoteAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2epromoteAt_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2enewerGo(V, V);
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerGo_clo;
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2eproject_2esumBefore(V, V);
V g_heff_2ebuild_2eproject_2esumBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2esumBefore_clo;
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
V g_heff_2ebuild_2equery_2edocMdStep(V, V);
V g_heff_2ebuild_2equery_2edocMdStep_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMdStep_clo;
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(V);
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ebuild_2equery_2eprimitiveName(V, V);
V g_heff_2ebuild_2equery_2eprimitiveName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eprimitiveName_clo;
V g_heff_2ecompile_2earity_2earityOne(V, V);
V g_heff_2ecompile_2earity_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earity_2earityOne_clo;
V g_heff_2ecompile_2ecallarity_2earityOne(V, V);
V g_heff_2ecompile_2ecallarity_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2earityOne_clo;
V g_heff_2ecompile_2ecallarity_2eunused_get(void);
V g_heff_2ecompile_2eemit_2ebindName(V, V);
V g_heff_2ecompile_2eemit_2ebindName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebindName_clo;
V g_heff_2ecompile_2eemit_2eexportNameOf(V);
V g_heff_2ecompile_2eemit_2eexportNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eexportNameOf_clo;
V g_heff_2ecompile_2eemit_2ehostLineOf(V);
V g_heff_2ecompile_2eemit_2ehostLineOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehostLineOf_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2eprimUses(V, V);
V g_heff_2ecompile_2eemit_2eprimUses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimUses_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeRes(V);
V g_heff_2ecompile_2eemit_2esafeRes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeRes_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eemit_2etailApp(V);
V g_heff_2ecompile_2eemit_2etailApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etailApp_clo;
V g_heff_2ecompile_2eemit_2etailGlobals(V);
V g_heff_2ecompile_2eemit_2etailGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etailGlobals_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemit_2evalueRefs(V);
V g_heff_2ecompile_2eemit_2evalueRefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalueRefs_clo;
V g_heff_2ecompile_2eemitc_2earityOne(V, V);
V g_heff_2ecompile_2eemitc_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earityOne_clo;
V g_heff_2ecompile_2eemitc_2eborAll(V, V);
V g_heff_2ecompile_2eemitc_2eborAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eborAll_clo;
V g_heff_2ecompile_2eemitc_2eborDef(V, V);
V g_heff_2ecompile_2eemitc_2eborDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eborDef_clo;
V g_heff_2ecompile_2eemitc_2ebuildsSize(V, V);
V g_heff_2ecompile_2eemitc_2ebuildsSize_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ebuildsSize_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2efreeOf(V, V);
V g_heff_2ecompile_2eemitc_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efreeOf_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2elastDotGo(V, V, V);
V g_heff_2ecompile_2eemitc_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elastDotGo_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2enamesInGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2enamesInGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesInGo_clo;
V g_heff_2ecompile_2eemitc_2eprimCloDef(V);
V g_heff_2ecompile_2eemitc_2eprimCloDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimCloDef_clo;
V g_heff_2ecompile_2eemitc_2epubLine(V);
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epubLine_clo;
V g_heff_2ecompile_2eemitc_2eshapeDef(V);
V g_heff_2ecompile_2eemitc_2eshapeDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeDef_clo;
V g_heff_2ecompile_2eemitc_2etagsLbls(V);
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo;
V g_heff_2ecompile_2eemitc_2ewithKnown(V, V, V);
V g_heff_2ecompile_2eemitc_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewithKnown_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2eir_2efreshBindOne(V, V);
V g_heff_2ecompile_2eir_2efreshBindOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshBindOne_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2elift_2eliftGo_24s1117140028x479981506(V, V, V);
V g_heff_2ecompile_2elift_2eliftGo_24s1117140028x479981506_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eliftGo_24s1117140028x479981506_clo;
V g_heff_2ecompile_2eprims_2efixedImpl(V);
V g_heff_2ecompile_2eprims_2efixedImpl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2efixedImpl_clo;
V g_heff_2ecompile_2esimplify_2eflat(V);
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eflat_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2esimplify_2esgFlat(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgFlat_clo;
V g_heff_2ecompile_2esimplify_2esgItem(V, V);
V g_heff_2ecompile_2esimplify_2esgItem_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgItem_clo;
V g_heff_2ecompile_2espec_2ebindOne(V, V);
V g_heff_2ecompile_2espec_2ebindOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ebindOne_clo;
V g_heff_2ecompile_2espec_2ekeyGo(V, V);
V g_heff_2ecompile_2espec_2ekeyGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ekeyGo_clo;
V g_heff_2eelab_2eclauses_2erenamer(V, V);
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamer_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2efixed_2efloat32Ops_get(void);
V g_heff_2eelab_2efixed_2eintOps_get(void);
V g_heff_2eelab_2elocals_2edeclaration(V);
V g_heff_2eelab_2elocals_2edeclaration_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclaration_clo;
V g_heff_2eelab_2elocals_2epatternBinders(V);
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_clo;
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(V);
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_clo;
V g_heff_2eelab_2eprint_2ecommaSep(V);
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2ecommaSep_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2epr_get(void);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo;
V g_heff_2eelab_2etoplevel_2ethawOne(V, V);
V g_heff_2eelab_2etoplevel_2ethawOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawOne_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_heff_2esyntax_2efmt_2eimports_2espacesOf(V);
V g_heff_2esyntax_2efmt_2eimports_2espacesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2espacesOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2eimport_2eimplicitImports_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_heff_2esyntax_2eimport_2espaces(V);
V g_heff_2esyntax_2eimport_2espaces_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2espaces_clo;
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V);
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo;
V g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164(V);
V g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(V);
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985(V);
V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985(V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629(V);
V g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381(V);
V g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381_clo;
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_heff_2esyntax_2esurface_2eidentOf(V);
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eidentOf_clo;
V g_heff_2eutil_2ejson_2eescapeGo(V, V, V);
V g_heff_2eutil_2ejson_2eescapeGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2eescapeGo_clo;
V g_heff_2eutil_2ejson_2estringify(V);
V g_heff_2eutil_2ejson_2estringify_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2estringify_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s107199714x217634386(V, V, V);
V g_list_2eall_24s107199714x217634386_entry(V self, V *a);
extern Clo g_list_2eall_24s107199714x217634386_clo;
V g_list_2eall_24s1703554932x1387778930(V);
V g_list_2eall_24s1703554932x1387778930_entry(V self, V *a);
extern Clo g_list_2eall_24s1703554932x1387778930_clo;
V g_list_2eall_24s1821787051x863686734(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eall_24s1821787051x863686734_entry(V self, V *a);
extern Clo g_list_2eall_24s1821787051x863686734_clo;
V g_list_2eall_24s455618083x1946283732(V, V);
V g_list_2eall_24s455618083x1946283732_entry(V self, V *a);
extern Clo g_list_2eall_24s455618083x1946283732_clo;
V g_list_2eall_24s607638492x847921129(V);
V g_list_2eall_24s607638492x847921129_entry(V self, V *a);
extern Clo g_list_2eall_24s607638492x847921129_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1107779796x153132813(V);
V g_list_2eany_24s1107779796x153132813_entry(V self, V *a);
extern Clo g_list_2eany_24s1107779796x153132813_clo;
V g_list_2eany_24s1225534391x2032069000(V, V, V, V, V, V);
V g_list_2eany_24s1225534391x2032069000_entry(V self, V *a);
extern Clo g_list_2eany_24s1225534391x2032069000_clo;
V g_list_2eany_24s141450647x925029990(V);
V g_list_2eany_24s141450647x925029990_entry(V self, V *a);
extern Clo g_list_2eany_24s141450647x925029990_clo;
V g_list_2eany_24s1859615565x1399458702(V);
V g_list_2eany_24s1859615565x1399458702_entry(V self, V *a);
extern Clo g_list_2eany_24s1859615565x1399458702_clo;
V g_list_2eany_24s1925868661x1054952755(V, V, V, V);
V g_list_2eany_24s1925868661x1054952755_entry(V self, V *a);
extern Clo g_list_2eany_24s1925868661x1054952755_clo;
V g_list_2eany_24s203425463x2138315205(V, V, V, V);
V g_list_2eany_24s203425463x2138315205_entry(V self, V *a);
extern Clo g_list_2eany_24s203425463x2138315205_clo;
V g_list_2eany_24s2118781542x1794344985(V);
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a);
extern Clo g_list_2eany_24s2118781542x1794344985_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2eany_24s261760131x1433598489(V);
V g_list_2eany_24s261760131x1433598489_entry(V self, V *a);
extern Clo g_list_2eany_24s261760131x1433598489_clo;
V g_list_2eany_24s577543654x765608923(V);
V g_list_2eany_24s577543654x765608923_entry(V self, V *a);
extern Clo g_list_2eany_24s577543654x765608923_clo;
V g_list_2eany_24s651308273x925219243(V);
V g_list_2eany_24s651308273x925219243_entry(V self, V *a);
extern Clo g_list_2eany_24s651308273x925219243_clo;
V g_list_2eany_24s762674996x1009180162(V);
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a);
extern Clo g_list_2eany_24s762674996x1009180162_clo;
V g_list_2eany_24s851022240x390352190(V, V);
V g_list_2eany_24s851022240x390352190_entry(V self, V *a);
extern Clo g_list_2eany_24s851022240x390352190_clo;
V g_list_2eany_24s910662703x1730636603(V);
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a);
extern Clo g_list_2eany_24s910662703x1730636603_clo;
V g_list_2eany_24s976871491x582277361(V);
V g_list_2eany_24s976871491x582277361_entry(V self, V *a);
extern Clo g_list_2eany_24s976871491x582277361_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1018181017x1541469354(V);
V g_list_2efilter_24s1018181017x1541469354_entry(V self, V *a);
extern Clo g_list_2efilter_24s1018181017x1541469354_clo;
V g_list_2efilter_24s1214006305x787928862(V);
V g_list_2efilter_24s1214006305x787928862_entry(V self, V *a);
extern Clo g_list_2efilter_24s1214006305x787928862_clo;
V g_list_2efilter_24s1725367856x1498536808(V);
V g_list_2efilter_24s1725367856x1498536808_entry(V self, V *a);
extern Clo g_list_2efilter_24s1725367856x1498536808_clo;
V g_list_2efilter_24s1727592350x8580145(V);
V g_list_2efilter_24s1727592350x8580145_entry(V self, V *a);
extern Clo g_list_2efilter_24s1727592350x8580145_clo;
V g_list_2efilter_24s1765650963x934927761(V);
V g_list_2efilter_24s1765650963x934927761_entry(V self, V *a);
extern Clo g_list_2efilter_24s1765650963x934927761_clo;
V g_list_2efilter_24s1923635572x1866981478(V);
V g_list_2efilter_24s1923635572x1866981478_entry(V self, V *a);
extern Clo g_list_2efilter_24s1923635572x1866981478_clo;
V g_list_2efilter_24s1951626341x2001490815(V);
V g_list_2efilter_24s1951626341x2001490815_entry(V self, V *a);
extern Clo g_list_2efilter_24s1951626341x2001490815_clo;
V g_list_2efilter_24s1956506708x1796911658(V);
V g_list_2efilter_24s1956506708x1796911658_entry(V self, V *a);
extern Clo g_list_2efilter_24s1956506708x1796911658_clo;
V g_list_2efilter_24s1966237873x2134891024(V, V, V);
V g_list_2efilter_24s1966237873x2134891024_entry(V self, V *a);
extern Clo g_list_2efilter_24s1966237873x2134891024_clo;
V g_list_2efilter_24s1967523567x64647275(V);
V g_list_2efilter_24s1967523567x64647275_entry(V self, V *a);
extern Clo g_list_2efilter_24s1967523567x64647275_clo;
V g_list_2efilter_24s2048945121x1749617505(V, V);
V g_list_2efilter_24s2048945121x1749617505_entry(V self, V *a);
extern Clo g_list_2efilter_24s2048945121x1749617505_clo;
V g_list_2efilter_24s2056490818x625949248(V, V);
V g_list_2efilter_24s2056490818x625949248_entry(V self, V *a);
extern Clo g_list_2efilter_24s2056490818x625949248_clo;
V g_list_2efilter_24s2077266661x1618908611(V);
V g_list_2efilter_24s2077266661x1618908611_entry(V self, V *a);
extern Clo g_list_2efilter_24s2077266661x1618908611_clo;
V g_list_2efilter_24s328645370x374613117(V);
V g_list_2efilter_24s328645370x374613117_entry(V self, V *a);
extern Clo g_list_2efilter_24s328645370x374613117_clo;
V g_list_2efilter_24s34002769x154977349(V);
V g_list_2efilter_24s34002769x154977349_entry(V self, V *a);
extern Clo g_list_2efilter_24s34002769x154977349_clo;
V g_list_2efilter_24s354018555x112012799(V);
V g_list_2efilter_24s354018555x112012799_entry(V self, V *a);
extern Clo g_list_2efilter_24s354018555x112012799_clo;
V g_list_2efilter_24s413142873x1263311264(V, V);
V g_list_2efilter_24s413142873x1263311264_entry(V self, V *a);
extern Clo g_list_2efilter_24s413142873x1263311264_clo;
V g_list_2efilter_24s413688307x112671032(V, V, V, V);
V g_list_2efilter_24s413688307x112671032_entry(V self, V *a);
extern Clo g_list_2efilter_24s413688307x112671032_clo;
V g_list_2efilter_24s446928887x1941604070(V, V, V, V);
V g_list_2efilter_24s446928887x1941604070_entry(V self, V *a);
extern Clo g_list_2efilter_24s446928887x1941604070_clo;
V g_list_2efilter_24s645966254x607857854(V);
V g_list_2efilter_24s645966254x607857854_entry(V self, V *a);
extern Clo g_list_2efilter_24s645966254x607857854_clo;
V g_list_2efilter_24s835571418x868029304(V);
V g_list_2efilter_24s835571418x868029304_entry(V self, V *a);
extern Clo g_list_2efilter_24s835571418x868029304_clo;
V g_list_2efilter_24s926921591x156811372(V, V, V, V);
V g_list_2efilter_24s926921591x156811372_entry(V self, V *a);
extern Clo g_list_2efilter_24s926921591x156811372_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efind_24s1364769258x905208224(V);
V g_list_2efind_24s1364769258x905208224_entry(V self, V *a);
extern Clo g_list_2efind_24s1364769258x905208224_clo;
V g_list_2efind_24s913819130x636901392(V, V);
V g_list_2efind_24s913819130x636901392_entry(V self, V *a);
extern Clo g_list_2efind_24s913819130x636901392_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1048046132x95752937(V, V);
V g_list_2efoldl_24s1048046132x95752937_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1048046132x95752937_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s114050048x1903860601(V, V);
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a);
extern Clo g_list_2efoldl_24s114050048x1903860601_clo;
V g_list_2efoldl_24s1196401404x611901340(V, V);
V g_list_2efoldl_24s1196401404x611901340_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1196401404x611901340_clo;
V g_list_2efoldl_24s1221316612x1915668835(V, V);
V g_list_2efoldl_24s1221316612x1915668835_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1221316612x1915668835_clo;
V g_list_2efoldl_24s125569247x179592613(V, V);
V g_list_2efoldl_24s125569247x179592613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s125569247x179592613_clo;
V g_list_2efoldl_24s1261443129x1682844402(V, V);
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1261443129x1682844402_clo;
V g_list_2efoldl_24s1278324331x1671175048(V, V);
V g_list_2efoldl_24s1278324331x1671175048_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1278324331x1671175048_clo;
V g_list_2efoldl_24s1301054807x1042293437(V, V);
V g_list_2efoldl_24s1301054807x1042293437_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1301054807x1042293437_clo;
V g_list_2efoldl_24s132236332x1381264820(V, V);
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a);
extern Clo g_list_2efoldl_24s132236332x1381264820_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1370710786x897780937(V, V, V, V);
V g_list_2efoldl_24s1370710786x897780937_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370710786x897780937_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1410418896x1853739899(V, V);
V g_list_2efoldl_24s1410418896x1853739899_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1410418896x1853739899_clo;
V g_list_2efoldl_24s1430359702x555202731(V, V);
V g_list_2efoldl_24s1430359702x555202731_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1430359702x555202731_clo;
V g_list_2efoldl_24s1472875662x470242985(V, V);
V g_list_2efoldl_24s1472875662x470242985_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1472875662x470242985_clo;
V g_list_2efoldl_24s1530401830x609500251(V, V);
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530401830x609500251_clo;
V g_list_2efoldl_24s153144783x1331291624(V, V);
V g_list_2efoldl_24s153144783x1331291624_entry(V self, V *a);
extern Clo g_list_2efoldl_24s153144783x1331291624_clo;
V g_list_2efoldl_24s1602746644x1116868967(V, V);
V g_list_2efoldl_24s1602746644x1116868967_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1602746644x1116868967_clo;
V g_list_2efoldl_24s1606891938x229778616(V, V);
V g_list_2efoldl_24s1606891938x229778616_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1606891938x229778616_clo;
V g_list_2efoldl_24s1620243413x998711352(V, V);
V g_list_2efoldl_24s1620243413x998711352_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1620243413x998711352_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1659066958x125973700(V, V);
V g_list_2efoldl_24s1659066958x125973700_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659066958x125973700_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1685809585x983762522(V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1685809585x983762522_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1685809585x983762522_clo;
V g_list_2efoldl_24s1728910418x1456517756(V, V);
V g_list_2efoldl_24s1728910418x1456517756_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1728910418x1456517756_clo;
V g_list_2efoldl_24s1751327013x555271812(V, V);
V g_list_2efoldl_24s1751327013x555271812_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1751327013x555271812_clo;
V g_list_2efoldl_24s175567250x489918591(V, V);
V g_list_2efoldl_24s175567250x489918591_entry(V self, V *a);
extern Clo g_list_2efoldl_24s175567250x489918591_clo;
V g_list_2efoldl_24s1759289969x319536741(V, V);
V g_list_2efoldl_24s1759289969x319536741_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1759289969x319536741_clo;
V g_list_2efoldl_24s1761834913x283136918(V, V);
V g_list_2efoldl_24s1761834913x283136918_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1761834913x283136918_clo;
V g_list_2efoldl_24s1777264376x185554286(V, V);
V g_list_2efoldl_24s1777264376x185554286_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1777264376x185554286_clo;
V g_list_2efoldl_24s1777318809x1106245647(V, V);
V g_list_2efoldl_24s1777318809x1106245647_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1777318809x1106245647_clo;
V g_list_2efoldl_24s1787334480x145092089(V, V);
V g_list_2efoldl_24s1787334480x145092089_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1787334480x145092089_clo;
V g_list_2efoldl_24s1798985515x221942800(V, V);
V g_list_2efoldl_24s1798985515x221942800_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1798985515x221942800_clo;
V g_list_2efoldl_24s1819302915x1539612842(V, V, V);
V g_list_2efoldl_24s1819302915x1539612842_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1819302915x1539612842_clo;
V g_list_2efoldl_24s1854884545x892082821(V, V);
V g_list_2efoldl_24s1854884545x892082821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1854884545x892082821_clo;
V g_list_2efoldl_24s1880194630x798487332(V, V);
V g_list_2efoldl_24s1880194630x798487332_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1880194630x798487332_clo;
V g_list_2efoldl_24s189033563x26633104(V, V);
V g_list_2efoldl_24s189033563x26633104_entry(V self, V *a);
extern Clo g_list_2efoldl_24s189033563x26633104_clo;
V g_list_2efoldl_24s1891821040x773772203(V, V);
V g_list_2efoldl_24s1891821040x773772203_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1891821040x773772203_clo;
V g_list_2efoldl_24s1915639815x253536901(V, V);
V g_list_2efoldl_24s1915639815x253536901_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1915639815x253536901_clo;
V g_list_2efoldl_24s1936649287x1723798793(V, V);
V g_list_2efoldl_24s1936649287x1723798793_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1936649287x1723798793_clo;
V g_list_2efoldl_24s1938129198x1830848254(V, V, V);
V g_list_2efoldl_24s1938129198x1830848254_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1938129198x1830848254_clo;
V g_list_2efoldl_24s1948306825x2028893715(V, V);
V g_list_2efoldl_24s1948306825x2028893715_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1948306825x2028893715_clo;
V g_list_2efoldl_24s196488697x1402130510(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s196488697x1402130510_entry(V self, V *a);
extern Clo g_list_2efoldl_24s196488697x1402130510_clo;
V g_list_2efoldl_24s1975553568x1034350329(V, V);
V g_list_2efoldl_24s1975553568x1034350329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1975553568x1034350329_clo;
V g_list_2efoldl_24s1986349154x480814480(V, V, V);
V g_list_2efoldl_24s1986349154x480814480_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1986349154x480814480_clo;
V g_list_2efoldl_24s1994057367x1686730046(V, V);
V g_list_2efoldl_24s1994057367x1686730046_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1994057367x1686730046_clo;
V g_list_2efoldl_24s2024565375x57673182(V, V, V);
V g_list_2efoldl_24s2024565375x57673182_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2024565375x57673182_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s2040448920x1981923787(V, V);
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2040448920x1981923787_clo;
V g_list_2efoldl_24s2070597502x591087275(V, V);
V g_list_2efoldl_24s2070597502x591087275_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2070597502x591087275_clo;
V g_list_2efoldl_24s2093480427x456774456(V, V, V, V);
V g_list_2efoldl_24s2093480427x456774456_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2093480427x456774456_clo;
V g_list_2efoldl_24s2126981320x1580482478(V, V);
V g_list_2efoldl_24s2126981320x1580482478_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2126981320x1580482478_clo;
V g_list_2efoldl_24s2134067310x2049132013(V, V);
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2134067310x2049132013_clo;
V g_list_2efoldl_24s215617195x1240120008(V, V);
V g_list_2efoldl_24s215617195x1240120008_entry(V self, V *a);
extern Clo g_list_2efoldl_24s215617195x1240120008_clo;
V g_list_2efoldl_24s230517345x1163337657(V, V);
V g_list_2efoldl_24s230517345x1163337657_entry(V self, V *a);
extern Clo g_list_2efoldl_24s230517345x1163337657_clo;
V g_list_2efoldl_24s282854995x1837067020(V, V);
V g_list_2efoldl_24s282854995x1837067020_entry(V self, V *a);
extern Clo g_list_2efoldl_24s282854995x1837067020_clo;
V g_list_2efoldl_24s302194196x751324068(V, V);
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a);
extern Clo g_list_2efoldl_24s302194196x751324068_clo;
V g_list_2efoldl_24s310383131x1909826775(V, V);
V g_list_2efoldl_24s310383131x1909826775_entry(V self, V *a);
extern Clo g_list_2efoldl_24s310383131x1909826775_clo;
V g_list_2efoldl_24s321107625x1130584089(V, V);
V g_list_2efoldl_24s321107625x1130584089_entry(V self, V *a);
extern Clo g_list_2efoldl_24s321107625x1130584089_clo;
V g_list_2efoldl_24s332826144x1500818670(V, V);
V g_list_2efoldl_24s332826144x1500818670_entry(V self, V *a);
extern Clo g_list_2efoldl_24s332826144x1500818670_clo;
V g_list_2efoldl_24s337463599x663364213(V, V);
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a);
extern Clo g_list_2efoldl_24s337463599x663364213_clo;
V g_list_2efoldl_24s348322209x75032364(V, V);
V g_list_2efoldl_24s348322209x75032364_entry(V self, V *a);
extern Clo g_list_2efoldl_24s348322209x75032364_clo;
V g_list_2efoldl_24s361191175x1417189158(V, V);
V g_list_2efoldl_24s361191175x1417189158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s361191175x1417189158_clo;
V g_list_2efoldl_24s371903670x1850896738(V, V);
V g_list_2efoldl_24s371903670x1850896738_entry(V self, V *a);
extern Clo g_list_2efoldl_24s371903670x1850896738_clo;
V g_list_2efoldl_24s407249128x802036125(V, V);
V g_list_2efoldl_24s407249128x802036125_entry(V self, V *a);
extern Clo g_list_2efoldl_24s407249128x802036125_clo;
V g_list_2efoldl_24s410120642x105714730(V, V);
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a);
extern Clo g_list_2efoldl_24s410120642x105714730_clo;
V g_list_2efoldl_24s426392081x749835614(V, V);
V g_list_2efoldl_24s426392081x749835614_entry(V self, V *a);
extern Clo g_list_2efoldl_24s426392081x749835614_clo;
V g_list_2efoldl_24s445268946x679229867(V, V);
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a);
extern Clo g_list_2efoldl_24s445268946x679229867_clo;
V g_list_2efoldl_24s449727021x365548005(V, V);
V g_list_2efoldl_24s449727021x365548005_entry(V self, V *a);
extern Clo g_list_2efoldl_24s449727021x365548005_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2efoldl_24s491023592x445693380(V, V);
V g_list_2efoldl_24s491023592x445693380_entry(V self, V *a);
extern Clo g_list_2efoldl_24s491023592x445693380_clo;
V g_list_2efoldl_24s491084544x100802329(V, V);
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s491084544x100802329_clo;
V g_list_2efoldl_24s496727651x1448898893(V, V);
V g_list_2efoldl_24s496727651x1448898893_entry(V self, V *a);
extern Clo g_list_2efoldl_24s496727651x1448898893_clo;
V g_list_2efoldl_24s522807745x1556762248(V, V);
V g_list_2efoldl_24s522807745x1556762248_entry(V self, V *a);
extern Clo g_list_2efoldl_24s522807745x1556762248_clo;
V g_list_2efoldl_24s54159557x1528472185(V, V);
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s54159557x1528472185_clo;
V g_list_2efoldl_24s554524976x621147349(V, V);
V g_list_2efoldl_24s554524976x621147349_entry(V self, V *a);
extern Clo g_list_2efoldl_24s554524976x621147349_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s620173997x1959585086(V, V);
V g_list_2efoldl_24s620173997x1959585086_entry(V self, V *a);
extern Clo g_list_2efoldl_24s620173997x1959585086_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s682444417x1397580212(V, V, V, V, V, V);
V g_list_2efoldl_24s682444417x1397580212_entry(V self, V *a);
extern Clo g_list_2efoldl_24s682444417x1397580212_clo;
V g_list_2efoldl_24s690313412x1307839513(V, V);
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690313412x1307839513_clo;
V g_list_2efoldl_24s690408737x127625622(V, V);
V g_list_2efoldl_24s690408737x127625622_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690408737x127625622_clo;
V g_list_2efoldl_24s775969440x1318400394(V, V, V);
V g_list_2efoldl_24s775969440x1318400394_entry(V self, V *a);
extern Clo g_list_2efoldl_24s775969440x1318400394_clo;
V g_list_2efoldl_24s776813750x121415612(V, V);
V g_list_2efoldl_24s776813750x121415612_entry(V self, V *a);
extern Clo g_list_2efoldl_24s776813750x121415612_clo;
V g_list_2efoldl_24s781320710x1613941343(V, V);
V g_list_2efoldl_24s781320710x1613941343_entry(V self, V *a);
extern Clo g_list_2efoldl_24s781320710x1613941343_clo;
V g_list_2efoldl_24s797527640x986490519(V, V);
V g_list_2efoldl_24s797527640x986490519_entry(V self, V *a);
extern Clo g_list_2efoldl_24s797527640x986490519_clo;
V g_list_2efoldl_24s844754919x2100408598(V, V, V, V);
V g_list_2efoldl_24s844754919x2100408598_entry(V self, V *a);
extern Clo g_list_2efoldl_24s844754919x2100408598_clo;
V g_list_2efoldl_24s847493210x796325999(V, V);
V g_list_2efoldl_24s847493210x796325999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s847493210x796325999_clo;
V g_list_2efoldl_24s85178867x1278479365(V, V, V, V, V);
V g_list_2efoldl_24s85178867x1278479365_entry(V self, V *a);
extern Clo g_list_2efoldl_24s85178867x1278479365_clo;
V g_list_2efoldl_24s865198748x12535471(V, V);
V g_list_2efoldl_24s865198748x12535471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s865198748x12535471_clo;
V g_list_2efoldl_24s868530262x539343671(V, V);
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a);
extern Clo g_list_2efoldl_24s868530262x539343671_clo;
V g_list_2efoldl_24s873517001x1016672031(V, V);
V g_list_2efoldl_24s873517001x1016672031_entry(V self, V *a);
extern Clo g_list_2efoldl_24s873517001x1016672031_clo;
V g_list_2efoldl_24s883914537x614975039(V, V);
V g_list_2efoldl_24s883914537x614975039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s883914537x614975039_clo;
V g_list_2efoldl_24s895450532x1092988905(V, V);
V g_list_2efoldl_24s895450532x1092988905_entry(V self, V *a);
extern Clo g_list_2efoldl_24s895450532x1092988905_clo;
V g_list_2efoldl_24s905606722x2129703274(V, V, V);
V g_list_2efoldl_24s905606722x2129703274_entry(V self, V *a);
extern Clo g_list_2efoldl_24s905606722x2129703274_clo;
V g_list_2efoldl_24s907092709x2006193176(V, V);
V g_list_2efoldl_24s907092709x2006193176_entry(V self, V *a);
extern Clo g_list_2efoldl_24s907092709x2006193176_clo;
V g_list_2efoldl_24s91733047x1482905949(V, V);
V g_list_2efoldl_24s91733047x1482905949_entry(V self, V *a);
extern Clo g_list_2efoldl_24s91733047x1482905949_clo;
V g_list_2efoldl_24s947555161x768980202(V, V);
V g_list_2efoldl_24s947555161x768980202_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947555161x768980202_clo;
V g_list_2efoldl_24s96775841x2127473534(V, V);
V g_list_2efoldl_24s96775841x2127473534_entry(V self, V *a);
extern Clo g_list_2efoldl_24s96775841x2127473534_clo;
V g_list_2efoldl_24s978059622x523571930(V, V);
V g_list_2efoldl_24s978059622x523571930_entry(V self, V *a);
extern Clo g_list_2efoldl_24s978059622x523571930_clo;
V g_list_2efoldl_24s9956384x694087549(V, V);
V g_list_2efoldl_24s9956384x694087549_entry(V self, V *a);
extern Clo g_list_2efoldl_24s9956384x694087549_clo;
V g_list_2efoldl_24s999799596x1949685079(V, V);
V g_list_2efoldl_24s999799596x1949685079_entry(V self, V *a);
extern Clo g_list_2efoldl_24s999799596x1949685079_clo;
V g_list_2elookupBy(V, V, V);
V g_list_2elookupBy_entry(V self, V *a);
extern Clo g_list_2elookupBy_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1006477676x1816442814(V, V, V);
V g_list_2emap_24s1006477676x1816442814_entry(V self, V *a);
extern Clo g_list_2emap_24s1006477676x1816442814_clo;
V g_list_2emap_24s1009200955x251267316(V);
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_list_2emap_24s1052938345x548264065(V, V, V, V, V);
V g_list_2emap_24s1052938345x548264065_entry(V self, V *a);
extern Clo g_list_2emap_24s1052938345x548264065_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s1115633485x729040294(V);
V g_list_2emap_24s1115633485x729040294_entry(V self, V *a);
extern Clo g_list_2emap_24s1115633485x729040294_clo;
V g_list_2emap_24s1120421688x983574011(V);
V g_list_2emap_24s1120421688x983574011_entry(V self, V *a);
extern Clo g_list_2emap_24s1120421688x983574011_clo;
V g_list_2emap_24s1123370502x1982532655(V);
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_clo;
V g_list_2emap_24s1150457979x1978067071(V);
V g_list_2emap_24s1150457979x1978067071_entry(V self, V *a);
extern Clo g_list_2emap_24s1150457979x1978067071_clo;
V g_list_2emap_24s117049731x163598814(V);
V g_list_2emap_24s117049731x163598814_entry(V self, V *a);
extern Clo g_list_2emap_24s117049731x163598814_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1176007509x671449441(V, V, V, V, V);
V g_list_2emap_24s1176007509x671449441_entry(V self, V *a);
extern Clo g_list_2emap_24s1176007509x671449441_clo;
V g_list_2emap_24s1181937096x2120532116(V);
V g_list_2emap_24s1181937096x2120532116_entry(V self, V *a);
extern Clo g_list_2emap_24s1181937096x2120532116_clo;
V g_list_2emap_24s1195846327x230486685(V, V, V, V, V, V, V);
V g_list_2emap_24s1195846327x230486685_entry(V self, V *a);
extern Clo g_list_2emap_24s1195846327x230486685_clo;
V g_list_2emap_24s1196049889x1646679775(V, V, V, V, V, V, V);
V g_list_2emap_24s1196049889x1646679775_entry(V self, V *a);
extern Clo g_list_2emap_24s1196049889x1646679775_clo;
V g_list_2emap_24s1198759183x473355350(V);
V g_list_2emap_24s1198759183x473355350_entry(V self, V *a);
extern Clo g_list_2emap_24s1198759183x473355350_clo;
V g_list_2emap_24s1201815197x1377530874(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1201815197x1377530874_entry(V self, V *a);
extern Clo g_list_2emap_24s1201815197x1377530874_clo;
V g_list_2emap_24s1221903513x233153387(V);
V g_list_2emap_24s1221903513x233153387_entry(V self, V *a);
extern Clo g_list_2emap_24s1221903513x233153387_clo;
V g_list_2emap_24s1224798844x1489231098(V);
V g_list_2emap_24s1224798844x1489231098_entry(V self, V *a);
extern Clo g_list_2emap_24s1224798844x1489231098_clo;
V g_list_2emap_24s1230413390x1744519585(V, V);
V g_list_2emap_24s1230413390x1744519585_entry(V self, V *a);
extern Clo g_list_2emap_24s1230413390x1744519585_clo;
V g_list_2emap_24s1230969749x2018313496(V);
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_clo;
V g_list_2emap_24s1253308387x88241051(V);
V g_list_2emap_24s1253308387x88241051_entry(V self, V *a);
extern Clo g_list_2emap_24s1253308387x88241051_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s1288527083x146849530(V);
V g_list_2emap_24s1288527083x146849530_entry(V self, V *a);
extern Clo g_list_2emap_24s1288527083x146849530_clo;
V g_list_2emap_24s1328195927x21044528(V, V);
V g_list_2emap_24s1328195927x21044528_entry(V self, V *a);
extern Clo g_list_2emap_24s1328195927x21044528_clo;
V g_list_2emap_24s1354894546x482665166(V, V, V, V);
V g_list_2emap_24s1354894546x482665166_entry(V self, V *a);
extern Clo g_list_2emap_24s1354894546x482665166_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2emap_24s1374235278x875430684(V);
V g_list_2emap_24s1374235278x875430684_entry(V self, V *a);
extern Clo g_list_2emap_24s1374235278x875430684_clo;
V g_list_2emap_24s1378753456x1787722089(V, V, V, V);
V g_list_2emap_24s1378753456x1787722089_entry(V self, V *a);
extern Clo g_list_2emap_24s1378753456x1787722089_clo;
V g_list_2emap_24s1381986540x1952410492(V);
V g_list_2emap_24s1381986540x1952410492_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_clo;
V g_list_2emap_24s1397104144x44544585(V);
V g_list_2emap_24s1397104144x44544585_entry(V self, V *a);
extern Clo g_list_2emap_24s1397104144x44544585_clo;
V g_list_2emap_24s1397747289x2145601499(V);
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1416288597x2006619516(V);
V g_list_2emap_24s1416288597x2006619516_entry(V self, V *a);
extern Clo g_list_2emap_24s1416288597x2006619516_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s1431621018x139529971(V, V);
V g_list_2emap_24s1431621018x139529971_entry(V self, V *a);
extern Clo g_list_2emap_24s1431621018x139529971_clo;
V g_list_2emap_24s1445534224x744280941(V, V);
V g_list_2emap_24s1445534224x744280941_entry(V self, V *a);
extern Clo g_list_2emap_24s1445534224x744280941_clo;
V g_list_2emap_24s1462590149x1582455373(V);
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_clo;
V g_list_2emap_24s1488470534x1183628153(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1488470534x1183628153_entry(V self, V *a);
extern Clo g_list_2emap_24s1488470534x1183628153_clo;
V g_list_2emap_24s1490052334x152035327(V);
V g_list_2emap_24s1490052334x152035327_entry(V self, V *a);
extern Clo g_list_2emap_24s1490052334x152035327_clo;
V g_list_2emap_24s1501986216x12661735(V, V, V, V);
V g_list_2emap_24s1501986216x12661735_entry(V self, V *a);
extern Clo g_list_2emap_24s1501986216x12661735_clo;
V g_list_2emap_24s1522665373x570032865(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1522665373x570032865_entry(V self, V *a);
extern Clo g_list_2emap_24s1522665373x570032865_clo;
V g_list_2emap_24s1533895818x411093629(V);
V g_list_2emap_24s1533895818x411093629_entry(V self, V *a);
extern Clo g_list_2emap_24s1533895818x411093629_clo;
V g_list_2emap_24s1534167768x1221742344(V);
V g_list_2emap_24s1534167768x1221742344_entry(V self, V *a);
extern Clo g_list_2emap_24s1534167768x1221742344_clo;
V g_list_2emap_24s1535007417x1587061701(V);
V g_list_2emap_24s1535007417x1587061701_entry(V self, V *a);
extern Clo g_list_2emap_24s1535007417x1587061701_clo;
V g_list_2emap_24s1543151117x629172256(V);
V g_list_2emap_24s1543151117x629172256_entry(V self, V *a);
extern Clo g_list_2emap_24s1543151117x629172256_clo;
V g_list_2emap_24s1548004359x911871967(V);
V g_list_2emap_24s1548004359x911871967_entry(V self, V *a);
extern Clo g_list_2emap_24s1548004359x911871967_clo;
V g_list_2emap_24s1561756891x1126436879(V);
V g_list_2emap_24s1561756891x1126436879_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_clo;
V g_list_2emap_24s1573559022x513331157(V, V, V);
V g_list_2emap_24s1573559022x513331157_entry(V self, V *a);
extern Clo g_list_2emap_24s1573559022x513331157_clo;
V g_list_2emap_24s158244903x55062455(V);
V g_list_2emap_24s158244903x55062455_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_clo;
V g_list_2emap_24s1601949456x759540121(V, V, V, V);
V g_list_2emap_24s1601949456x759540121_entry(V self, V *a);
extern Clo g_list_2emap_24s1601949456x759540121_clo;
V g_list_2emap_24s1602529591x1809288035(V);
V g_list_2emap_24s1602529591x1809288035_entry(V self, V *a);
extern Clo g_list_2emap_24s1602529591x1809288035_clo;
V g_list_2emap_24s1624059865x1140896478(V);
V g_list_2emap_24s1624059865x1140896478_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_clo;
V g_list_2emap_24s1626183354x549349049(V);
V g_list_2emap_24s1626183354x549349049_entry(V self, V *a);
extern Clo g_list_2emap_24s1626183354x549349049_clo;
V g_list_2emap_24s1646944445x1684083181(V, V, V, V, V, V, V);
V g_list_2emap_24s1646944445x1684083181_entry(V self, V *a);
extern Clo g_list_2emap_24s1646944445x1684083181_clo;
V g_list_2emap_24s1654555371x977048649(V, V, V, V, V, V);
V g_list_2emap_24s1654555371x977048649_entry(V self, V *a);
extern Clo g_list_2emap_24s1654555371x977048649_clo;
V g_list_2emap_24s1665123230x1905625068(V, V, V, V, V, V);
V g_list_2emap_24s1665123230x1905625068_entry(V self, V *a);
extern Clo g_list_2emap_24s1665123230x1905625068_clo;
V g_list_2emap_24s1675313341x192238134(V);
V g_list_2emap_24s1675313341x192238134_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_clo;
V g_list_2emap_24s1687022268x1975813520(V);
V g_list_2emap_24s1687022268x1975813520_entry(V self, V *a);
extern Clo g_list_2emap_24s1687022268x1975813520_clo;
V g_list_2emap_24s1688457226x2006118782(V);
V g_list_2emap_24s1688457226x2006118782_entry(V self, V *a);
extern Clo g_list_2emap_24s1688457226x2006118782_clo;
V g_list_2emap_24s1691650970x173345163(V);
V g_list_2emap_24s1691650970x173345163_entry(V self, V *a);
extern Clo g_list_2emap_24s1691650970x173345163_clo;
V g_list_2emap_24s1729787689x465380098(V);
V g_list_2emap_24s1729787689x465380098_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_clo;
V g_list_2emap_24s1733204117x1102777152(V);
V g_list_2emap_24s1733204117x1102777152_entry(V self, V *a);
extern Clo g_list_2emap_24s1733204117x1102777152_clo;
V g_list_2emap_24s173442543x1801751270(V);
V g_list_2emap_24s173442543x1801751270_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_clo;
V g_list_2emap_24s1753874608x910016727(V);
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_clo;
V g_list_2emap_24s1782778565x402128078(V);
V g_list_2emap_24s1782778565x402128078_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_clo;
V g_list_2emap_24s1784220752x1516752412(V);
V g_list_2emap_24s1784220752x1516752412_entry(V self, V *a);
extern Clo g_list_2emap_24s1784220752x1516752412_clo;
V g_list_2emap_24s1785262601x1752264566(V, V, V, V);
V g_list_2emap_24s1785262601x1752264566_entry(V self, V *a);
extern Clo g_list_2emap_24s1785262601x1752264566_clo;
V g_list_2emap_24s1801850472x1352108398(V);
V g_list_2emap_24s1801850472x1352108398_entry(V self, V *a);
extern Clo g_list_2emap_24s1801850472x1352108398_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_list_2emap_24s1844509821x2028168277(V);
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_clo;
V g_list_2emap_24s1845612977x612508518(V);
V g_list_2emap_24s1845612977x612508518_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_clo;
V g_list_2emap_24s1887874170x1747433177(V);
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_clo;
V g_list_2emap_24s1895313378x47656836(V);
V g_list_2emap_24s1895313378x47656836_entry(V self, V *a);
extern Clo g_list_2emap_24s1895313378x47656836_clo;
V g_list_2emap_24s1898144261x1783169347(V);
V g_list_2emap_24s1898144261x1783169347_entry(V self, V *a);
extern Clo g_list_2emap_24s1898144261x1783169347_clo;
V g_list_2emap_24s1899163131x287513996(V);
V g_list_2emap_24s1899163131x287513996_entry(V self, V *a);
extern Clo g_list_2emap_24s1899163131x287513996_clo;
V g_list_2emap_24s1900047848x1273517071(V);
V g_list_2emap_24s1900047848x1273517071_entry(V self, V *a);
extern Clo g_list_2emap_24s1900047848x1273517071_clo;
V g_list_2emap_24s1917746138x1825516092(V);
V g_list_2emap_24s1917746138x1825516092_entry(V self, V *a);
extern Clo g_list_2emap_24s1917746138x1825516092_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1942298441x202086805(V);
V g_list_2emap_24s1942298441x202086805_entry(V self, V *a);
extern Clo g_list_2emap_24s1942298441x202086805_clo;
V g_list_2emap_24s1970234737x1062111588(V);
V g_list_2emap_24s1970234737x1062111588_entry(V self, V *a);
extern Clo g_list_2emap_24s1970234737x1062111588_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s2000102784x314586828(V);
V g_list_2emap_24s2000102784x314586828_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_clo;
V g_list_2emap_24s201309086x301344224(V);
V g_list_2emap_24s201309086x301344224_entry(V self, V *a);
extern Clo g_list_2emap_24s201309086x301344224_clo;
V g_list_2emap_24s2029999044x514618413(V);
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_clo;
V g_list_2emap_24s2047942056x1956366232(V);
V g_list_2emap_24s2047942056x1956366232_entry(V self, V *a);
extern Clo g_list_2emap_24s2047942056x1956366232_clo;
V g_list_2emap_24s2063150796x1704946690(V);
V g_list_2emap_24s2063150796x1704946690_entry(V self, V *a);
extern Clo g_list_2emap_24s2063150796x1704946690_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24s2073083146x1445066245(V);
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_clo;
V g_list_2emap_24s2081626528x1476576812(V);
V g_list_2emap_24s2081626528x1476576812_entry(V self, V *a);
extern Clo g_list_2emap_24s2081626528x1476576812_clo;
V g_list_2emap_24s2086294444x1195805373(V, V);
V g_list_2emap_24s2086294444x1195805373_entry(V self, V *a);
extern Clo g_list_2emap_24s2086294444x1195805373_clo;
V g_list_2emap_24s2103553821x564582624(V, V);
V g_list_2emap_24s2103553821x564582624_entry(V self, V *a);
extern Clo g_list_2emap_24s2103553821x564582624_clo;
V g_list_2emap_24s2141157620x437287316(V);
V g_list_2emap_24s2141157620x437287316_entry(V self, V *a);
extern Clo g_list_2emap_24s2141157620x437287316_clo;
V g_list_2emap_24s214260857x938990544(V);
V g_list_2emap_24s214260857x938990544_entry(V self, V *a);
extern Clo g_list_2emap_24s214260857x938990544_clo;
V g_list_2emap_24s218655275x981659442(V);
V g_list_2emap_24s218655275x981659442_entry(V self, V *a);
extern Clo g_list_2emap_24s218655275x981659442_clo;
V g_list_2emap_24s244350250x1728178626(V);
V g_list_2emap_24s244350250x1728178626_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_clo;
V g_list_2emap_24s249042484x1701682908(V);
V g_list_2emap_24s249042484x1701682908_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_clo;
V g_list_2emap_24s268264395x330149387(V, V, V, V);
V g_list_2emap_24s268264395x330149387_entry(V self, V *a);
extern Clo g_list_2emap_24s268264395x330149387_clo;
V g_list_2emap_24s278643433x636689823(V);
V g_list_2emap_24s278643433x636689823_entry(V self, V *a);
extern Clo g_list_2emap_24s278643433x636689823_clo;
V g_list_2emap_24s336317878x1053990440(V);
V g_list_2emap_24s336317878x1053990440_entry(V self, V *a);
extern Clo g_list_2emap_24s336317878x1053990440_clo;
V g_list_2emap_24s338694954x1326523169(V);
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_clo;
V g_list_2emap_24s357242026x384251201(V);
V g_list_2emap_24s357242026x384251201_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s374365348x2042978339(V, V);
V g_list_2emap_24s374365348x2042978339_entry(V self, V *a);
extern Clo g_list_2emap_24s374365348x2042978339_clo;
V g_list_2emap_24s379119719x1394241001(V);
V g_list_2emap_24s379119719x1394241001_entry(V self, V *a);
extern Clo g_list_2emap_24s379119719x1394241001_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s381963598x1143766061(V, V);
V g_list_2emap_24s381963598x1143766061_entry(V self, V *a);
extern Clo g_list_2emap_24s381963598x1143766061_clo;
V g_list_2emap_24s386875578x1005587669(V);
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_clo;
V g_list_2emap_24s391931963x434308123(V);
V g_list_2emap_24s391931963x434308123_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_clo;
V g_list_2emap_24s394088139x1521650250(V);
V g_list_2emap_24s394088139x1521650250_entry(V self, V *a);
extern Clo g_list_2emap_24s394088139x1521650250_clo;
V g_list_2emap_24s404123879x745642248(V);
V g_list_2emap_24s404123879x745642248_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_clo;
V g_list_2emap_24s405944583x1077136121(V);
V g_list_2emap_24s405944583x1077136121_entry(V self, V *a);
extern Clo g_list_2emap_24s405944583x1077136121_clo;
V g_list_2emap_24s419146097x822538985(V);
V g_list_2emap_24s419146097x822538985_entry(V self, V *a);
extern Clo g_list_2emap_24s419146097x822538985_clo;
V g_list_2emap_24s4199228x1154005405(V);
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_clo;
V g_list_2emap_24s420582357x1720502382(V);
V g_list_2emap_24s420582357x1720502382_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_clo;
V g_list_2emap_24s422923909x1655406376(V);
V g_list_2emap_24s422923909x1655406376_entry(V self, V *a);
extern Clo g_list_2emap_24s422923909x1655406376_clo;
V g_list_2emap_24s424270175x1918189508(V);
V g_list_2emap_24s424270175x1918189508_entry(V self, V *a);
extern Clo g_list_2emap_24s424270175x1918189508_clo;
V g_list_2emap_24s424921060x1532378(V, V, V, V, V, V, V);
V g_list_2emap_24s424921060x1532378_entry(V self, V *a);
extern Clo g_list_2emap_24s424921060x1532378_clo;
V g_list_2emap_24s434052990x93204247(V);
V g_list_2emap_24s434052990x93204247_entry(V self, V *a);
extern Clo g_list_2emap_24s434052990x93204247_clo;
V g_list_2emap_24s467999193x422550880(V, V, V, V);
V g_list_2emap_24s467999193x422550880_entry(V self, V *a);
extern Clo g_list_2emap_24s467999193x422550880_clo;
V g_list_2emap_24s474585387x1072098790(V);
V g_list_2emap_24s474585387x1072098790_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_clo;
V g_list_2emap_24s478220879x497030774(V);
V g_list_2emap_24s478220879x497030774_entry(V self, V *a);
extern Clo g_list_2emap_24s478220879x497030774_clo;
V g_list_2emap_24s499977176x606563528(V, V, V);
V g_list_2emap_24s499977176x606563528_entry(V self, V *a);
extern Clo g_list_2emap_24s499977176x606563528_clo;
V g_list_2emap_24s500158289x1934493753(V, V, V, V, V, V, V);
V g_list_2emap_24s500158289x1934493753_entry(V self, V *a);
extern Clo g_list_2emap_24s500158289x1934493753_clo;
V g_list_2emap_24s503326960x1200444853(V);
V g_list_2emap_24s503326960x1200444853_entry(V self, V *a);
extern Clo g_list_2emap_24s503326960x1200444853_clo;
V g_list_2emap_24s513391942x823299088(V);
V g_list_2emap_24s513391942x823299088_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_clo;
V g_list_2emap_24s520719551x1264915833(V);
V g_list_2emap_24s520719551x1264915833_entry(V self, V *a);
extern Clo g_list_2emap_24s520719551x1264915833_clo;
V g_list_2emap_24s53115558x1845817090(V);
V g_list_2emap_24s53115558x1845817090_entry(V self, V *a);
extern Clo g_list_2emap_24s53115558x1845817090_clo;
V g_list_2emap_24s539093115x379698116(V);
V g_list_2emap_24s539093115x379698116_entry(V self, V *a);
extern Clo g_list_2emap_24s539093115x379698116_clo;
V g_list_2emap_24s546447922x1671206170(V, V);
V g_list_2emap_24s546447922x1671206170_entry(V self, V *a);
extern Clo g_list_2emap_24s546447922x1671206170_clo;
V g_list_2emap_24s565104239x2094869705(V);
V g_list_2emap_24s565104239x2094869705_entry(V self, V *a);
extern Clo g_list_2emap_24s565104239x2094869705_clo;
V g_list_2emap_24s570241860x1995261629(V);
V g_list_2emap_24s570241860x1995261629_entry(V self, V *a);
extern Clo g_list_2emap_24s570241860x1995261629_clo;
V g_list_2emap_24s570961906x1112476114(V);
V g_list_2emap_24s570961906x1112476114_entry(V self, V *a);
extern Clo g_list_2emap_24s570961906x1112476114_clo;
V g_list_2emap_24s580953129x420589622(V);
V g_list_2emap_24s580953129x420589622_entry(V self, V *a);
extern Clo g_list_2emap_24s580953129x420589622_clo;
V g_list_2emap_24s584454411x1006678865(V);
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24s617071700x1606310602(V, V, V, V, V, V);
V g_list_2emap_24s617071700x1606310602_entry(V self, V *a);
extern Clo g_list_2emap_24s617071700x1606310602_clo;
V g_list_2emap_24s634984521x2042558081(V);
V g_list_2emap_24s634984521x2042558081_entry(V self, V *a);
extern Clo g_list_2emap_24s634984521x2042558081_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s651008657x1962905215(V);
V g_list_2emap_24s651008657x1962905215_entry(V self, V *a);
extern Clo g_list_2emap_24s651008657x1962905215_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2emap_24s73473062x206541869(V);
V g_list_2emap_24s73473062x206541869_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_clo;
V g_list_2emap_24s738510110x679538579(V, V);
V g_list_2emap_24s738510110x679538579_entry(V self, V *a);
extern Clo g_list_2emap_24s738510110x679538579_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2emap_24s76631343x1276310171(V);
V g_list_2emap_24s76631343x1276310171_entry(V self, V *a);
extern Clo g_list_2emap_24s76631343x1276310171_clo;
V g_list_2emap_24s79542405x478516404(V);
V g_list_2emap_24s79542405x478516404_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_clo;
V g_list_2emap_24s846355817x1552148381(V, V, V, V, V, V, V);
V g_list_2emap_24s846355817x1552148381_entry(V self, V *a);
extern Clo g_list_2emap_24s846355817x1552148381_clo;
V g_list_2emap_24s864521685x1610969087(V);
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a);
extern Clo g_list_2emap_24s864521685x1610969087_clo;
V g_list_2emap_24s871082722x1690249882(V);
V g_list_2emap_24s871082722x1690249882_entry(V self, V *a);
extern Clo g_list_2emap_24s871082722x1690249882_clo;
V g_list_2emap_24s876522837x2005194065(V, V, V, V);
V g_list_2emap_24s876522837x2005194065_entry(V self, V *a);
extern Clo g_list_2emap_24s876522837x2005194065_clo;
V g_list_2emap_24s878634257x1677201747(V);
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_clo;
V g_list_2emap_24s891258639x530975267(V, V);
V g_list_2emap_24s891258639x530975267_entry(V self, V *a);
extern Clo g_list_2emap_24s891258639x530975267_clo;
V g_list_2emap_24s914137198x2013970988(V, V, V, V, V, V);
V g_list_2emap_24s914137198x2013970988_entry(V self, V *a);
extern Clo g_list_2emap_24s914137198x2013970988_clo;
V g_list_2emap_24s921302063x1242134775(V);
V g_list_2emap_24s921302063x1242134775_entry(V self, V *a);
extern Clo g_list_2emap_24s921302063x1242134775_clo;
V g_list_2emap_24s944722006x358970142(V);
V g_list_2emap_24s944722006x358970142_entry(V self, V *a);
extern Clo g_list_2emap_24s944722006x358970142_clo;
V g_list_2emap_24s953916415x1126219438(V, V);
V g_list_2emap_24s953916415x1126219438_entry(V self, V *a);
extern Clo g_list_2emap_24s953916415x1126219438_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emerge_24s1199840358x829708481(V, V);
V g_list_2emerge_24s1199840358x829708481_entry(V self, V *a);
extern Clo g_list_2emerge_24s1199840358x829708481_clo;
V g_list_2emerge_24s132798885x1165759438(V, V);
V g_list_2emerge_24s132798885x1165759438_entry(V self, V *a);
extern Clo g_list_2emerge_24s132798885x1165759438_clo;
V g_list_2emerge_24s1347843181x1368204458(V, V);
V g_list_2emerge_24s1347843181x1368204458_entry(V self, V *a);
extern Clo g_list_2emerge_24s1347843181x1368204458_clo;
V g_list_2emerge_24s1795243648x793343406(V, V);
V g_list_2emerge_24s1795243648x793343406_entry(V self, V *a);
extern Clo g_list_2emerge_24s1795243648x793343406_clo;
V g_list_2emerge_24s179604802x978393081(V, V);
V g_list_2emerge_24s179604802x978393081_entry(V self, V *a);
extern Clo g_list_2emerge_24s179604802x978393081_clo;
V g_list_2emerge_24s184369168x2028177428(V, V);
V g_list_2emerge_24s184369168x2028177428_entry(V self, V *a);
extern Clo g_list_2emerge_24s184369168x2028177428_clo;
V g_list_2emerge_24s293607948x301101025(V, V);
V g_list_2emerge_24s293607948x301101025_entry(V self, V *a);
extern Clo g_list_2emerge_24s293607948x301101025_clo;
V g_list_2emerge_24s601132804x1969384800(V, V);
V g_list_2emerge_24s601132804x1969384800_entry(V self, V *a);
extern Clo g_list_2emerge_24s601132804x1969384800_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2esortBy(V, V);
V g_list_2esortBy_entry(V self, V *a);
extern Clo g_list_2esortBy_clo;
V g_list_2esortBy_24s1802715880x492507304(V);
V g_list_2esortBy_24s1802715880x492507304_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1802715880x492507304_clo;
V g_list_2esortBy_24s231284928x1216253427(V);
V g_list_2esortBy_24s231284928x1216253427_entry(V self, V *a);
extern Clo g_list_2esortBy_24s231284928x1216253427_clo;
V g_list_2esortBy_24s45117555x207111745(V);
V g_list_2esortBy_24s45117555x207111745_entry(V self, V *a);
extern Clo g_list_2esortBy_24s45117555x207111745_clo;
V g_list_2esortBy_24s492793466x2081132734(V);
V g_list_2esortBy_24s492793466x2081132734_entry(V self, V *a);
extern Clo g_list_2esortBy_24s492793466x2081132734_clo;
V g_list_2esortBy_24s727161593x858225784(V);
V g_list_2esortBy_24s727161593x858225784_entry(V self, V *a);
extern Clo g_list_2esortBy_24s727161593x858225784_clo;
V g_list_2esortBy_24s746560702x1620060712(V);
V g_list_2esortBy_24s746560702x1620060712_entry(V self, V *a);
extern Clo g_list_2esortBy_24s746560702x1620060712_clo;
V g_list_2esortBy_24s851943868x104872707(V);
V g_list_2esortBy_24s851943868x104872707_entry(V self, V *a);
extern Clo g_list_2esortBy_24s851943868x104872707_clo;
V g_list_2esortBy_24s88152486x2058486153(V);
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a);
extern Clo g_list_2esortBy_24s88152486x2058486153_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s1610853704x1401907306(V, V, V);
V g_list_2ezipWith_24s1610853704x1401907306_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1610853704x1401907306_clo;
V g_list_2ezipWith_24s1814128165x1680687847(V, V, V, V, V);
V g_list_2ezipWith_24s1814128165x1680687847_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1814128165x1680687847_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s203264781x503274820(V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s203264781x503274820_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s203264781x503274820_clo;
V g_list_2ezipWith_24s2039753704x2095677241(V, V, V, V, V);
V g_list_2ezipWith_24s2039753704x2095677241_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s2039753704x2095677241_clo;
V g_list_2ezipWith_24s237481877x1031762735(V, V, V);
V g_list_2ezipWith_24s237481877x1031762735_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s237481877x1031762735_clo;
V g_list_2ezipWith_24s31176117x1618486040(V, V);
V g_list_2ezipWith_24s31176117x1618486040_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s31176117x1618486040_clo;
V g_list_2ezipWith_24s568889179x755145155(V, V);
V g_list_2ezipWith_24s568889179x755145155_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s568889179x755145155_clo;
V g_list_2ezipWith_24s738847920x410598254(V, V);
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_clo;
V g_list_2ezipWith_24s763642811x1204809256(V, V);
V g_list_2ezipWith_24s763642811x1204809256_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s763642811x1204809256_clo;
V g_list_2ezipWith_24s868949484x1127836054(V, V);
V g_list_2ezipWith_24s868949484x1127836054_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s868949484x1127836054_clo;
V g_list_2ezipWith_24s924458827x719285517(V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s924458827x719285517_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s924458827x719285517_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2ecli_2eflagLine(V);
V g_std_2ecli_2eflagLine_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagLine_clo;
V g_std_2ecli_2eflagWord(V);
V g_std_2ecli_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagWord_clo;
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ehardline_get(void);
Clo g_list_2emap_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_entry, 2, 0};

V g_list_2emap(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap(v_f_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_entry(V self, V *a) {
  (void)self;
  return g_list_2emap(a[0], a[1]);
}
Clo g_list_2efoldl_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_entry, 3, 0};

V g_list_2efoldl(V v_f_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_z_241, heff_dup(v_x_243)}));
    V t_0 = v_f_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_f_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s1370882877x364361272_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1370882877x364361272_entry, 2, 0};

V g_list_2efoldl_24s1370882877x364361272(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V t_0 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1370882877x364361272(a[0], a[1]);
}
Clo g_list_2efilter_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_entry, 2, 0};

V g_list_2efilter(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2efilter(v_p_240, v_xs_243))});
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter(a[0], a[1]);
}
Clo g_list_2efoldl_24s1116451536x2100070357_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1116451536x2100070357_entry, 3, 0};

V g_list_2efoldl_24s1116451536x2100070357(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x3_242, 1);
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1116451536x2100070357(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2etake_clo = {{0x80000000u, K_CLO, 0}, g_list_2etake_entry, 2, 0};

V g_list_2etake(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2etake(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243))});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2etake_entry(V self, V *a) {
  (void)self;
  return g_list_2etake(a[0], a[1]);
}
Clo g_list_2edrop_clo = {{0x80000000u, K_CLO, 0}, g_list_2edrop_entry, 2, 0};

V g_list_2edrop(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2edrop_entry(V self, V *a) {
  (void)self;
  return g_list_2edrop(a[0], a[1]);
}
Clo g_list_2ezipWith_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_entry, 3, 0};

V g_list_2ezipWith(V v_f_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_ys_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_f_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_x_243, v_y_245}));
      return heff_tag_at_n(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_list_2ezipWith(v_f_240, v_xs2_244, v_ys2_246))});
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2ezipWith_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith(a[0], a[1], a[2]);
}
Clo g_list_2eany_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_entry, 2, 0};

V g_list_2eany(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eall_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_entry, 2, 0};

V g_list_2eall(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_p_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efind_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_entry, 2, 0};

V g_list_2efind(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2elookupBy_clo = {{0x80000000u, K_CLO, 0}, g_list_2elookupBy_entry, 3, 0};

V g_list_2elookupBy(V v_eq_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_eq_240);
    heff_drop(v_k_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_k_27_245 = heff_field(v_x31_243, 0);
      V v_v_246 = heff_field(v_x31_243, 1);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_eq_240), 2, (V[]){heff_dup(v_k_241), heff_dup(v_k_27_245)}));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_eq_240);
        heff_drop(v_k_241);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_246)});
      }
      case TAG_False: {
        V t_0 = v_eq_240;
        V t_1 = v_k_241;
        V t_2 = v_rest_244;
        v_eq_240 = t_0;
        v_k_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2elookupBy_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2elookupBy(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s114050048x1903860601_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s114050048x1903860601_entry, 2, 0};

V g_list_2efoldl_24s114050048x1903860601(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V t_0 = heff_intAdd(v_z_240, heff_dup(v_x_242));
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s114050048x1903860601(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2erange_clo = {{0x80000000u, K_CLO, 0}, g_list_2erange_entry, 2, 0};

V g_list_2erange(V v_a_240, V v_b_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_241), heff_dup(v_a_240))) {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    return NTAG(TAG_Nil);
  } else {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_240), (g_list_2erange(heff_intAdd(v_a_240, MK_INT(1LL)), v_b_241))});
  }
}
V g_list_2erange_entry(V self, V *a) {
  (void)self;
  return g_list_2erange(a[0], a[1]);
}
Clo g_list_2ereplicate_clo = {{0x80000000u, K_CLO, 0}, g_list_2ereplicate_entry, 2, 0};

V g_list_2ereplicate(V v_n_240, V v_x_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_x_241);
    return NTAG(TAG_Nil);
  } else {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), (g_list_2ereplicate(heff_intSub(v_n_240, MK_INT(1LL)), v_x_241))});
  }
}
V g_list_2ereplicate_entry(V self, V *a) {
  (void)self;
  return g_list_2ereplicate(a[0], a[1]);
}
Clo g_list_2emerge_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_entry, 3, 0};

V g_list_2emerge(V v_le_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      return v_xs_241;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      V v_ru_24ys_242_24Cons = heff_take_reuse_n(v_ys_242, 3ULL, 2);
      heff_drop_tag(v_xs_241, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){heff_dup(v_x_243), heff_dup(v_y_245)}));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        return heff_tag_at_n(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_list_2emerge(v_le_240, v_xs2_244, heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246})))});
      }
      case TAG_False: {
        return heff_tag_at_n(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_y_245, (g_list_2emerge(v_le_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs2_244}), v_ys2_246))});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2emerge_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge(a[0], a[1], a[2]);
}
Clo g_list_2esortBy_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_entry, 2, 0};

V g_list_2esortBy(V v_le_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_xs2_243)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop_tag(v_xs_241, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_243, 0ULL, 2);
      heff_drop(v_x_242);
      V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_247 = heff_intDiv(v_t_246, MK_INT(2LL));
      V v_t_248 = (g_list_2etake(v_t_247, heff_dup(v_xs_241)));
      V v_t_249 = (g_list_2esortBy(heff_dup(v_le_240), v_t_248));
      V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_2411 = heff_intDiv(v_t_2410, MK_INT(2LL));
      V v_t_2412 = (g_list_2edrop(v_t_2411, v_xs_241));
      V v_t_2413 = (g_list_2esortBy(heff_dup(v_le_240), v_t_2412));
      return (g_list_2emerge(v_le_240, v_t_249, v_t_2413));
    }
    default: return heff_nomatch(v_xs2_243);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2esortBy_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy(a[0], a[1]);
}
Clo g_list_2emap_24s1415906091x1371825187_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1415906091x1371825187_entry, 1, 0};

V g_list_2emap_24s1415906091x1371825187(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1415906091x1371825187(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1415906091x1371825187(a[0]);
}
Clo g_list_2emap_24s366344330x1145113647_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366344330x1145113647_entry, 1, 0};

V g_list_2emap_24s366344330x1145113647(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s366344330x1145113647(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366344330x1145113647(a[0]);
}
Clo g_list_2emap_24s1937570095x2110149801_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1937570095x2110149801_entry, 1, 0};

V g_list_2emap_24s1937570095x2110149801(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1937570095x2110149801(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1937570095x2110149801(a[0]);
}
Clo g_list_2emap_24s1173914895x100384474_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1173914895x100384474_entry, 1, 0};

V g_list_2emap_24s1173914895x100384474(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_y_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1173914895x100384474(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1173914895x100384474(a[0]);
}
V g_list_2efoldl_24s371903670x1850896738_lam0(V self, V *args);
Clo g_list_2efoldl_24s371903670x1850896738_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s371903670x1850896738_entry, 2, 0};

V g_list_2efoldl_24s371903670x1850896738(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244;
    switch (heff_tag_of(v_x_242)) {
    case TAG_I8: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I16: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I32: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I64: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U8: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U16: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U32: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U64: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_F32: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2efloat32Ops_get());
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_246 = (g_list_2emap(heff_clo_n(g_list_2efoldl_24s371903670x1850896738_lam0, 1, 1, (V[]){heff_dup(v_x_242)}), v_t_244));
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s371903670x1850896738_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s371903670x1850896738(a[0], a1); heff_drop(a1); return r;
}
V g_list_2efoldl_24s371903670x1850896738_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_rec_n(2, shape_fixed__op, (V[]){v_x_242, v_a_245});
}
Clo g_list_2efoldl_24s690313412x1307839513_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s690313412x1307839513_entry, 2, 0};

V g_list_2efoldl_24s690313412x1307839513(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eir_2efreshBindOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s690313412x1307839513(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1044393341x1523302351_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1044393341x1523302351_entry, 1, 0};

V g_list_2emap_24s1044393341x1523302351(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = ({ V a_0 = v_a_244; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_a_244); r_; });
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1044393341x1523302351(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1044393341x1523302351(a[0]);
}
Clo g_list_2emap_24s584454411x1006678865_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s584454411x1006678865_entry, 1, 0};

V g_list_2emap_24s584454411x1006678865(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s584454411x1006678865(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s584454411x1006678865(a[0]);
}
Clo g_list_2emap_24s1942298441x202086805_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1942298441x202086805_entry, 1, 0};

V g_list_2emap_24s1942298441x202086805(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 5), (g_list_2emap_24s1942298441x202086805(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1942298441x202086805_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1942298441x202086805(a[0]);
}
Clo g_list_2efilter_24s354018555x112012799_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s354018555x112012799_entry, 1, 0};

V g_list_2efilter_24s354018555x112012799(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 3));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s354018555x112012799(v_xs_242))});
    }
    case TAG_False: {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s354018555x112012799_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s354018555x112012799(a[0]);
}
Clo g_list_2emap_24s921302063x1242134775_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s921302063x1242134775_entry, 1, 0};

V g_list_2emap_24s921302063x1242134775(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 2), (g_list_2emap_24s921302063x1242134775(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s921302063x1242134775_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s921302063x1242134775(a[0]);
}
Clo g_list_2efilter_24s2056490818x625949248_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2056490818x625949248_entry, 2, 0};

V g_list_2efilter_24s2056490818x625949248(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLt_c(heff_dup(v_lit_240), heff_strLength(heff_dup(v_x_242)))) {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2efilter_24s2056490818x625949248(v_lit_240, v_xs_243))});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s2056490818x625949248_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2056490818x625949248(a[0], a[1]);
}
Clo g_list_2efoldl_24s1759289969x319536741_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1759289969x319536741_entry, 2, 0};

V g_list_2efoldl_24s1759289969x319536741(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_247 = (g_heff_2esyntax_2efmt_2eimports_2espacesOf(heff_intSub(v_t_245, v_t_246)));
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2);
    V v_t_249 = heff_strSlice(heff_dup(v_z_240), v_t_248, heff_strLength(heff_dup(v_z_240)));
    V v_t_2410 = heff_strAppend(heff_strSlice(v_z_240, MK_INT(0LL), v_t_244), heff_strAppend(v_t_247, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1759289969x319536741_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1759289969x319536741(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emerge_24s1347843181x1368204458_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1347843181x1368204458_entry, 2, 0};

V g_list_2emerge_24s1347843181x1368204458(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 7);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_242, 2)), heff_dup(heff_rfield(v_y_244, 2)))) {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s1347843181x1368204458(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      } else {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s1347843181x1368204458(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1347843181x1368204458_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1347843181x1368204458(a[0], a[1]);
}
Clo g_list_2esortBy_24s88152486x2058486153_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s88152486x2058486153_entry, 1, 0};

V g_list_2esortBy_24s88152486x2058486153(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s88152486x2058486153(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s88152486x2058486153(v_t_2411));
      return (g_list_2emerge_24s1347843181x1368204458(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s88152486x2058486153(a[0]);
}
HEFF_LIT(g_list_2emap_24s1845612977x612508518_str0, 6, "import");
HEFF_LIT(g_list_2emap_24s1845612977x612508518_str1, 0, "");
Clo g_list_2emap_24s1845612977x612508518_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1845612977x612508518_entry, 1, 0};

V g_list_2emap_24s1845612977x612508518(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 2)), 0, 2);
    V v_t_244 = heff_get_n(heff_get_n(v_x_241, 2, 3), 1, 2);
    V v_t_245 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_list_2emap_24s1845612977x612508518_str0), ((V)&g_list_2emap_24s1845612977x612508518_str1), v_t_243, v_t_244, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True)});
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1845612977x612508518(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1845612977x612508518_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1845612977x612508518(a[0]);
}
Clo g_list_2emerge_24s179604802x978393081_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s179604802x978393081_entry, 2, 0};

V g_list_2emerge_24s179604802x978393081(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 6);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_y_244, 0)))) {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s179604802x978393081(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      } else {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s179604802x978393081(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s179604802x978393081_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s179604802x978393081(a[0], a[1]);
}
Clo g_list_2esortBy_24s746560702x1620060712_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s746560702x1620060712_entry, 1, 0};

V g_list_2esortBy_24s746560702x1620060712(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s746560702x1620060712(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s746560702x1620060712(v_t_2411));
      return (g_list_2emerge_24s179604802x978393081(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s746560702x1620060712_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s746560702x1620060712(a[0]);
}
HEFF_LIT(g_list_2emap_24s1898144261x1783169347_str0, 0, "");
Clo g_list_2emap_24s1898144261x1783169347_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1898144261x1783169347_entry, 1, 0};

V g_list_2emap_24s1898144261x1783169347(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_dup(heff_rfield(v_x_241, 2)), heff_dup(heff_rfield(v_x_241, 3)), heff_tag_n(TAG_Just, 1, (V[]){v_x_241}), ((V)&g_list_2emap_24s1898144261x1783169347_str0), MK_INT(0LL), MK_INT(0LL)});
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1898144261x1783169347(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1898144261x1783169347_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1898144261x1783169347(a[0]);
}
Clo g_list_2emap_24s520719551x1264915833_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s520719551x1264915833_entry, 1, 0};

V g_list_2emap_24s520719551x1264915833(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_take_field(v_x_241, 0), heff_take_field(v_x_241, 1), NTAG(TAG_Nothing), heff_get_n(v_x_241, 2, 3), MK_INT(0LL), MK_INT(0LL)});
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s520719551x1264915833(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s520719551x1264915833_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s520719551x1264915833(a[0]);
}
Clo g_list_2emap_24s1688457226x2006118782_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1688457226x2006118782_entry, 1, 0};

V g_list_2emap_24s1688457226x2006118782(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1688457226x2006118782(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1688457226x2006118782_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1688457226x2006118782(a[0]);
}
Clo g_list_2emap_24s1844509821x2028168277_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1844509821x2028168277_entry, 1, 0};

V g_list_2emap_24s1844509821x2028168277(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_x_241));
    V v_t_2413;
    switch (heff_tag_of(v_a_243)) {
    case TAG_IsInferable: {
      V v_a_244 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_247;
      switch (heff_tag_of(v_a_244)) {
      case TAG_At: {
        V v_a_246 = heff_dup(heff_field(v_a_244, 1));
        v_t_247 = v_a_246;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_244}), v_t_247});
      break;
    }
    case TAG_IsCheckable: {
      V v_a_248 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2413 = v_a_248;
      break;
    }
    case TAG_IsType: {
      V v_a_249 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_a_249)) {
      case TAG_At: {
        V v_a_2411 = heff_dup(heff_field(v_a_249, 1));
        v_t_2412 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_a_249);
      }
      v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_249}), v_t_2412});
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, (g_list_2emap_24s1844509821x2028168277(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1844509821x2028168277(a[0]);
}
Clo g_list_2emap_24s1253308387x88241051_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1253308387x88241051_entry, 1, 0};

V g_list_2emap_24s1253308387x88241051(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1253308387x88241051(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1253308387x88241051_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1253308387x88241051(a[0]);
}
Clo g_list_2emap_24s1887874170x1747433177_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1887874170x1747433177_entry, 1, 0};

V g_list_2emap_24s1887874170x1747433177(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_x_241));
    V v_t_2413;
    switch (heff_tag_of(v_a_243)) {
    case TAG_IsInferable: {
      V v_a_244 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_247;
      switch (heff_tag_of(v_a_244)) {
      case TAG_At: {
        V v_a_246 = heff_dup(heff_field(v_a_244, 1));
        v_t_247 = v_a_246;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_a_244}), v_t_247});
      break;
    }
    case TAG_IsCheckable: {
      V v_a_248 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_a_248)) {
      case TAG_At: {
        V v_a_2410 = heff_dup(heff_field(v_a_248, 1));
        v_t_2411 = v_a_2410;
        break;
      }
      default: heff_nomatch(v_a_248);
      }
      v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_a_248}), v_t_2411});
      break;
    }
    case TAG_IsType: {
      V v_a_2412 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2413 = v_a_2412;
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, (g_list_2emap_24s1887874170x1747433177(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1887874170x1747433177(a[0]);
}
Clo g_list_2emap_24s503326960x1200444853_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s503326960x1200444853_entry, 1, 0};

V g_list_2emap_24s503326960x1200444853(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s503326960x1200444853(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s503326960x1200444853_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s503326960x1200444853(a[0]);
}
Clo g_list_2emap_24s1374235278x875430684_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1374235278x875430684_entry, 1, 0};

V g_list_2emap_24s1374235278x875430684(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1374235278x875430684(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1374235278x875430684_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1374235278x875430684(a[0]);
}
Clo g_list_2emap_24s1230969749x2018313496_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230969749x2018313496_entry, 1, 0};

V g_list_2emap_24s1230969749x2018313496(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1230969749x2018313496(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1230969749x2018313496(a[0]);
}
Clo g_list_2emap_24s2081626528x1476576812_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2081626528x1476576812_entry, 1, 0};

V g_list_2emap_24s2081626528x1476576812(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s2081626528x1476576812(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2081626528x1476576812_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2081626528x1476576812(a[0]);
}
Clo g_list_2emap_24s539093115x379698116_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s539093115x379698116_entry, 1, 0};

V g_list_2emap_24s539093115x379698116(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s539093115x379698116(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s539093115x379698116_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s539093115x379698116(a[0]);
}
Clo g_list_2emap_24s1150457979x1978067071_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1150457979x1978067071_entry, 1, 0};

V g_list_2emap_24s1150457979x1978067071(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_ArgExplicit: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24ArgExplicit = heff_take_reuse_n(v_a_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        V v_t_249;
        switch (heff_tag_of(v_a_245)) {
        case TAG_At: {
          V v_a_246 = heff_field(v_a_245, 0);
          V v_a_247 = heff_field(v_a_245, 1);
          heff_take_n(v_a_245, 3ULL, 2);
          V v_t_248 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_246));
          v_t_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_248, v_a_247});
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_249});
        break;
      }
      case TAG_ArgProject: {
        V v_a_2410 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24ArgProject = heff_take_reuse_n(v_a_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ArgProject, TAG_ArgProject, 1, (V[]){v_a_2410});
        break;
      }
      case TAG_ArgNamed: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_a_2412 = heff_field(v_a_243, 1);
        heff_take_n(v_a_243, 3ULL, 2);
        V v_t_2416;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          V v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2413));
          v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2415, v_a_2414});
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x_241_24At, TAG_ArgNamed, 2, (V[]){v_a_2411, v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, (g_list_2emap_24s1150457979x1978067071(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1150457979x1978067071_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1150457979x1978067071(a[0]);
}
Clo g_list_2emap_24s1992667171x110340492_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1992667171x110340492_entry, 1, 0};

V g_list_2emap_24s1992667171x110340492(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(v_a_243));
      v_t_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s1992667171x110340492(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1992667171x110340492(a[0]);
}
Clo g_list_2emap_24s158244903x55062455_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s158244903x55062455_entry, 1, 0};

V g_list_2emap_24s158244903x55062455(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      v_t_245 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_244, v_a_243));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s158244903x55062455(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s158244903x55062455_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s158244903x55062455(a[0]);
}
Clo g_list_2emap_24s513391942x823299088_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513391942x823299088_entry, 1, 0};

V g_list_2emap_24s513391942x823299088(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_a_243)) {
      case TAG_TagVariant: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24TagVariant = heff_take_reuse_n(v_a_243, 7ULL, 3);
        v_t_2412 = heff_tag_at_n(v_ru_24a_243_24TagVariant, TAG_TagVariant, 3, (V[]){v_a_245, v_a_246, (g_list_2emap_24s158244903x55062455(v_a_247))});
        break;
      }
      case TAG_BadVariant: {
        V v_a_248 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadVariant = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          v_t_2411 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_2410, v_a_249));
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2412 = heff_tag_at_n(v_ru_24a_243_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2411});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2412, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, (g_list_2emap_24s513391942x823299088(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513391942x823299088_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s513391942x823299088(a[0]);
}
Clo g_list_2emap_24s79542405x478516404_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s79542405x478516404_entry, 1, 0};

V g_list_2emap_24s79542405x478516404(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_243));
      v_t_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s79542405x478516404(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s79542405x478516404_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s79542405x478516404(a[0]);
}
Clo g_list_2emap_24s1729787689x465380098_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1729787689x465380098_entry, 1, 0};

V g_list_2emap_24s1729787689x465380098(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_SetField: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24SetField = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2411;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          V v_t_2410 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_248));
          v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2410, v_a_249});
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24SetField, TAG_SetField, 3, (V[]){v_a_245, v_a_246, v_t_2411});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2412 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadFieldSet = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          V v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2413));
          v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2415, v_a_2414});
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, (g_list_2emap_24s1729787689x465380098(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1729787689x465380098_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1729787689x465380098(a[0]);
}
Clo g_list_2emap_24s244350250x1728178626_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s244350250x1728178626_entry, 1, 0};

V g_list_2emap_24s244350250x1728178626(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        heff_take_n(v_a_243, 3ULL, 2);
        V v_t_2410;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_field(v_a_246, 0);
          V v_a_248 = heff_field(v_a_246, 1);
          heff_take_n(v_a_246, 3ULL, 2);
          V v_t_249 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_247));
          v_t_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_249, v_a_248});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2411 = heff_tag_at_n(v_ru_24x_241_24At, TAG_MkAlt, 2, (V[]){v_a_245, v_t_2410});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, (g_list_2emap_24s244350250x1728178626(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s244350250x1728178626_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s244350250x1728178626(a[0]);
}
Clo g_list_2emap_24s1782778565x402128078_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1782778565x402128078_entry, 1, 0};

V g_list_2emap_24s1782778565x402128078(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_248 = heff_field(v_a_243, 3);
        V v_ru_24a_243_24MkEquation = heff_take_reuse_n(v_a_243, 15ULL, 4);
        V v_t_2412;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          V v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_249));
          v_t_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2411, v_a_2410});
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2413 = heff_tag_at_n(v_ru_24a_243_24MkEquation, TAG_MkEquation, 4, (V[]){v_a_245, v_a_246, v_a_247, v_t_2412});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2414 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2413, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, (g_list_2emap_24s1782778565x402128078(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1782778565x402128078_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1782778565x402128078(a[0]);
}
Clo g_list_2emap_24s474585387x1072098790_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s474585387x1072098790_entry, 1, 0};

V g_list_2emap_24s474585387x1072098790(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_ExplicitParam: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24ExplicitParam = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_249, v_a_248));
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_a_245, v_a_246, v_t_2410});
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_a_2412 = heff_field(v_a_243, 1);
        V v_a_2413 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24ImplicitParam = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2416;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_2415, v_a_2414));
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_a_2411, v_a_2412, v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, (g_list_2emap_24s474585387x1072098790(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s474585387x1072098790_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s474585387x1072098790(a[0]);
}
Clo g_list_2emap_24s386875578x1005587669_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s386875578x1005587669_entry, 1, 0};

V g_list_2emap_24s386875578x1005587669(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(v_a_243));
      v_t_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s386875578x1005587669(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s386875578x1005587669(a[0]);
}
Clo g_list_2emap_24s249042484x1701682908_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s249042484x1701682908_entry, 1, 0};

V g_list_2emap_24s249042484x1701682908(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_2415;
      switch (heff_tag_of(v_a_243)) {
      case TAG_SetField: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24SetField = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          v_t_2410 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_249, v_a_248));
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24a_243_24SetField, TAG_SetField, 3, (V[]){v_a_245, v_a_246, v_t_2410});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadFieldSet = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_a_2411)) {
        case TAG_At: {
          V v_a_2412 = heff_field(v_a_2411, 0);
          V v_a_2413 = heff_field(v_a_2411, 1);
          heff_take_n(v_a_2411, 3ULL, 2);
          v_t_2414 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_2413, v_a_2412));
          break;
        }
        default: heff_nomatch(v_a_2411);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24a_243_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2414});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2415, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, (g_list_2emap_24s249042484x1701682908(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s249042484x1701682908_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s249042484x1701682908(a[0]);
}
Clo g_list_2emap_24s878634257x1677201747_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s878634257x1677201747_entry, 1, 0};

V g_list_2emap_24s878634257x1677201747(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2esyntax_2esurface_2eidentOf(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s878634257x1677201747(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s878634257x1677201747(a[0]);
}
Clo g_list_2emap_24s1624059865x1140896478_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1624059865x1140896478_entry, 1, 0};

V g_list_2emap_24s1624059865x1140896478(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2esurface_2easNameE(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1624059865x1140896478(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1624059865x1140896478_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1624059865x1140896478(a[0]);
}
Clo g_list_2emap_24s651008657x1962905215_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s651008657x1962905215_entry, 1, 0};

V g_list_2emap_24s651008657x1962905215(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Whole, 1, (V[]){v_x_241}), (g_list_2emap_24s651008657x1962905215(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s651008657x1962905215_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s651008657x1962905215(a[0]);
}
HEFF_LIT(g_list_2emap_24s1115633485x729040294_str0, 137, "a doc test is of the definition right under its doc comment, no blank line between: there is none here, so it is checked here, as a watch");
HEFF_LIT(g_list_2emap_24s1115633485x729040294_str1, 100, "write it as a watch, `-- >>> e`, or move it into the doc comment right above the definition it is of");
Clo g_list_2emap_24s1115633485x729040294_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1115633485x729040294_entry, 1, 0};

V g_list_2emap_24s1115633485x729040294(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_s_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_s_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(151LL), NTAG(TAG_SWarning), ((V)&g_list_2emap_24s1115633485x729040294_str0), v_t_245, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_list_2emap_24s1115633485x729040294_str1)})});
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s1115633485x729040294(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1115633485x729040294_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1115633485x729040294(a[0]);
}
Clo g_list_2emap_24s1970234737x1062111588_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1970234737x1062111588_entry, 1, 0};

V g_list_2emap_24s1970234737x1062111588(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_EProject, 1, (V[]){heff_take_field(v_x_241, 1)});
    V v_t_244 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_241, 3), heff_get_n(v_x_241, 4, 9)});
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_243, v_t_244}), (g_list_2emap_24s1970234737x1062111588(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1970234737x1062111588_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1970234737x1062111588(a[0]);
}
Clo g_list_2efoldl_24s1986349154x480814480_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1986349154x480814480_entry, 3, 0};

V g_list_2efoldl_24s1986349154x480814480(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_SetField: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_249 = heff_field(v_a_245, 2);
        heff_take_n(v_a_245, 5ULL, 3);
        V v_a_2412;
        switch (heff_tag_of(v_z_241)) {
        case TAG_At: {
          V v_a_2411 = heff_dup(heff_field(v_z_241, 1));
          v_a_2412 = v_a_2411;
          break;
        }
        default: heff_nomatch(v_z_241);
        }
        V v_t_2413 = ({ V rv_1 = heff_dup(heff_rfield(v_a_246, 1)); V rr_ = heff_rec_reuse_n(v_a_2412, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_ESpec, 4, (V[]){v_z_241, v_a_247, v_a_246, v_a_249}), v_t_2413});
        break;
      }
      case TAG_BadFieldSet: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_z_241);
        v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(v_lit_240)}), v_a_246});
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2415;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1986349154x480814480_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1986349154x480814480(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1059370217x1267747283_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1059370217x1267747283_entry, 1, 0};

V g_list_2emap_24s1059370217x1267747283(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_ExplicitParam: {
        V v_x_245 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_245;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_248 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, (g_list_2emap_24s1059370217x1267747283(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1059370217x1267747283(a[0]);
}
Clo g_list_2emap_24s1687022268x1975813520_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1687022268x1975813520_entry, 1, 0};

V g_list_2emap_24s1687022268x1975813520(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 7), (g_list_2emap_24s1687022268x1975813520(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1687022268x1975813520_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1687022268x1975813520(a[0]);
}
Clo g_list_2emap_24s1501986216x12661735_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1501986216x12661735_entry, 4, 0};

V g_list_2emap_24s1501986216x12661735(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_242)));
    V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 2), heff_get_n(v_x_244, 3, 7)});
    V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), v_t_246, v_t_247, NTAG(TAG_Nothing)});
    return heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_list_2emap_24s1501986216x12661735(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1501986216x12661735_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1501986216x12661735(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efilter_24s2077266661x1618908611_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2077266661x1618908611_entry, 1, 0};

V g_list_2efilter_24s2077266661x1618908611(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_x_241, 1))}));
    V v_t_244 = ({ V a_0 = v_t_243; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s2077266661x1618908611(v_xs_242))});
    }
    case TAG_False: {
      heff_drop_rec(v_x_241, 7);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s2077266661x1618908611_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2077266661x1618908611(a[0]);
}
Clo g_list_2efilter_24s446928887x1941604070_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s446928887x1941604070_entry, 4, 0};

V g_list_2efilter_24s446928887x1941604070(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_rfield(v_x_244, 1)));
    if (heff_intEq_c(v_t_246, heff_dup(v_lit_242))) {
      heff_drop_rec(v_x_244, 8);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      return heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, (g_list_2efilter_24s446928887x1941604070(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s446928887x1941604070_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s446928887x1941604070(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s338694954x1326523169_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s338694954x1326523169_entry, 1, 0};

V g_list_2emap_24s338694954x1326523169(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_241, 0), heff_take_field(v_x_241, 1)});
    V v_t_244 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_get_n(v_x_241, 2, 3), v_t_243, NTAG(TAG_Nothing)});
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s338694954x1326523169(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s338694954x1326523169(a[0]);
}
Clo g_list_2emap_24s1543151117x629172256_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1543151117x629172256_entry, 1, 0};

V g_list_2emap_24s1543151117x629172256(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eprims_2efixedImpl(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1543151117x629172256(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1543151117x629172256_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1543151117x629172256(a[0]);
}
Clo g_list_2efoldl_24s1048046132x95752937_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1048046132x95752937_entry, 2, 0};

V g_list_2efoldl_24s1048046132x95752937(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2espec_2ebindOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1048046132x95752937_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1048046132x95752937(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s60612435x257154841_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s60612435x257154841_entry, 1, 0};

V g_list_2emap_24s60612435x257154841(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_b_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 4ULL, 3);
      v_t_246 = v_b_245;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s60612435x257154841(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s60612435x257154841_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s60612435x257154841(a[0]);
}
Clo g_list_2efoldl_24s1948306825x2028893715_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1948306825x2028893715_entry, 2, 0};

V g_list_2efoldl_24s1948306825x2028893715(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2eflat(heff_dup(heff_rfield(v_x_242, 2))));
    V v_t_245 = ({ V a_0 = v_z_240; V a_1 = heff_dup(heff_rfield(v_x_242, 0)); V a_2 = v_t_244; V r_ = (g_heff_2ecompile_2esimplify_2esgFlat(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1948306825x2028893715_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1948306825x2028893715(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s379119719x1394241001_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s379119719x1394241001_entry, 1, 0};

V g_list_2emap_24s379119719x1394241001(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2433;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2433, (g_list_2emap_24s379119719x1394241001(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s379119719x1394241001_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s379119719x1394241001(a[0]);
}
Clo g_list_2efoldl_24s2040448920x1981923787_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2040448920x1981923787_entry, 2, 0};

V g_list_2efoldl_24s2040448920x1981923787(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2040448920x1981923787(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s85178867x1278479365_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s85178867x1278479365_entry, 5, 0};

V g_list_2efoldl_24s85178867x1278479365(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_ru_24x3_244_24Cons = heff_take_reuse_n(v_x3_244, 2ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_z_243)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_z_243, 0);
      V v_a_248 = heff_field(v_z_243, 1);
      heff_take_n(v_z_243, 3ULL, 2);
      V v_t_249 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), heff_intShow(heff_dup(v_a_248))));
      v_t_2410 = heff_tag_at_n(v_ru_24x3_244_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_a_247}), heff_intAdd(v_a_248, heff_dup(v_lit_242))});
      break;
    }
    default: heff_nomatch(v_z_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_2410;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24s85178867x1278479365_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s85178867x1278479365(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s1809017761x1063871171_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1809017761x1063871171_entry, 1, 0};

V g_list_2emap_24s1809017761x1063871171(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_241}), (g_list_2emap_24s1809017761x1063871171(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1809017761x1063871171(a[0]);
}
Clo g_list_2emap_24s73473062x206541869_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s73473062x206541869_entry, 1, 0};

V g_list_2emap_24s73473062x206541869(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), (g_list_2emap_24s73473062x206541869(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s73473062x206541869_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s73473062x206541869(a[0]);
}
Clo g_list_2ezipWith_24s237481877x1031762735_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s237481877x1031762735_entry, 3, 0};

V g_list_2ezipWith_24s237481877x1031762735(V v_lit_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ys_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_247;
      switch (heff_tag_of(v_x_243)) {
      case TAG_True: {
        v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_y_245; V r_ = (g_heff_2ecompile_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_y_245); r_; });
        break;
      }
      case TAG_False: {
        heff_drop(v_y_245);
        v_t_247 = heff_dup(v_lit_240);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      return heff_tag_at_n(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_list_2ezipWith_24s237481877x1031762735(v_lit_240, v_xs2_244, v_ys2_246))});
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2ezipWith_24s237481877x1031762735_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s237481877x1031762735(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s361191175x1417189158_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s361191175x1417189158_entry, 2, 0};

V g_list_2efoldl_24s361191175x1417189158(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_245;
    if (heff_intLe_c(heff_dup(v_z_240), heff_dup(v_x_242))) {
      v_t_245 = v_z_240;
    } else {
      heff_drop(v_z_240);
      v_t_245 = heff_dup(v_x_242);
    }
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s361191175x1417189158_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s361191175x1417189158(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1347985788x1836008258_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1347985788x1836008258_entry, 2, 0};

V g_list_2efoldl_24s1347985788x1836008258(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_242)));
    V v_t_245 = (g_heff_2ecompile_2eir_2enubI(v_t_244));
    V v_t_246 = (g_prelude_2e_2b_2b(v_t_245, v_z_240));
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1347985788x1836008258(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1123370502x1982532655_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1123370502x1982532655_entry, 1, 0};

V g_list_2emap_24s1123370502x1982532655(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_241}), (g_list_2emap_24s1123370502x1982532655(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1123370502x1982532655(a[0]);
}
Clo g_list_2eany_24s228396297x1310020012_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s228396297x1310020012_entry, 1, 0};

V g_list_2eany_24s228396297x1310020012(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s228396297x1310020012(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s905606722x2129703274_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s905606722x2129703274_entry, 3, 0};

V g_list_2efoldl_24s905606722x2129703274(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2435;
    switch (heff_tag_of(v_x_243)) {
    case TAG_EVar: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2438;
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      v_t_2438 = v_z_241;
      break;
    }
    case TAG_False: {
      V v_t_2436 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      V v_t_2437 = (g_heff_2ecompile_2eir_2esizeW(heff_dup(v_lit_240), v_t_2436));
      v_t_2438 = heff_intAdd(v_z_241, v_t_2437);
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2438;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s905606722x2129703274_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s905606722x2129703274(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s2067043448x720245267_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2067043448x720245267_entry, 1, 0};

V g_list_2emap_24s2067043448x720245267(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2epushable(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s2067043448x720245267(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2067043448x720245267(a[0]);
}
Clo g_list_2eany_24s1107779796x153132813_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1107779796x153132813_entry, 1, 0};

V g_list_2eany_24s1107779796x153132813(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2436;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_x13_245 = heff_field(v_x_241, 2);
      switch (heff_tag_of(v_x13_245)) {
      case TAG_EVar: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2436 = NTAG(TAG_True);
        break;
      }
      case TAG_EMatch: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x13_245);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2436)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_2436);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1107779796x153132813_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1107779796x153132813(a0); heff_drop(a0); return r;
}
Clo g_list_2eall_24s455618083x1946283732_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s455618083x1946283732_entry, 2, 0};

V g_list_2eall_24s455618083x1946283732(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c(v_t_246, heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return NTAG(TAG_False);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s455618083x1946283732_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall_24s455618083x1946283732(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s91733047x1482905949_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s91733047x1482905949_entry, 2, 0};

V g_list_2efoldl_24s91733047x1482905949(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 2)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s91733047x1482905949_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s91733047x1482905949(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2070597502x591087275_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2070597502x591087275_entry, 2, 0};

V g_list_2efoldl_24s2070597502x591087275(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2esgItem(v_z_240, v_x_242));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2070597502x591087275_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2070597502x591087275(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s1029292936x211450510_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1029292936x211450510_entry, 2, 0};

V g_list_2ezipWith_24s1029292936x211450510(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_246 = heff_field(v_x_242, 0);
        heff_take_n(v_x_242, 1ULL, 2);
        v_t_248 = v_a_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      return heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_y_244}), (g_list_2ezipWith_24s1029292936x211450510(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1029292936x211450510(a[0], a[1]);
}
Clo g_list_2efoldl_24s1915639815x253536901_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1915639815x253536901_entry, 2, 0};

V g_list_2efoldl_24s1915639815x253536901(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2earity_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1915639815x253536901_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1915639815x253536901(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s847493210x796325999_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s847493210x796325999_entry, 2, 0};

V g_list_2efoldl_24s847493210x796325999(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_242), heff_dup(g_heff_2ecompile_2ecallarity_2eunused_get()), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s847493210x796325999_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s847493210x796325999(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s445268946x679229867_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s445268946x679229867_entry, 2, 0};

V g_list_2efoldl_24s445268946x679229867(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2ecallarity_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s445268946x679229867(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1367796012x2117543847_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1367796012x2117543847_entry, 2, 0};

V g_list_2emap_24s1367796012x2117543847(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_242), (g_list_2emap_24s1367796012x2117543847(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1367796012x2117543847(a[0], a[1]);
}
Clo g_list_2efoldl_24s895450532x1092988905_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s895450532x1092988905_entry, 2, 0};

V g_list_2efoldl_24s895450532x1092988905(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s895450532x1092988905_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s895450532x1092988905(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s868530262x539343671_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s868530262x539343671_entry, 2, 0};

V g_list_2efoldl_24s868530262x539343671(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_i_244 = heff_field(v_x_242, 0);
      V v_x22_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_x22_245)) {
      case TAG_PVar: {
        V v_l_246 = heff_field(v_x22_245, 0);
        v_t_247 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(v_l_246), heff_dup(v_i_244), v_z_240));
        break;
      }
      case TAG_PSelf: {
        v_t_247 = v_z_240;
        break;
      }
      default: heff_nomatch(v_x22_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s868530262x539343671(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s410120642x105714730_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s410120642x105714730_entry, 2, 0};

V g_list_2efoldl_24s410120642x105714730(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_take_field(v_x_242, 1);
    V v_t_247;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_rec_n(2, shape_name__span, (V[]){heff_take_field(v_x_242, 4), heff_get_n(v_x_242, 5, 6)});
      v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_z_240});
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_x_242, 6);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_247 = v_z_240;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s410120642x105714730(a[0], a[1]);
}
Clo g_list_2eany_24s141450647x925029990_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s141450647x925029990_entry, 1, 0};

V g_list_2eany_24s141450647x925029990(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_a_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s141450647x925029990_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s141450647x925029990(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_str0, 1, "\"");
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_str1, 1, "\"");
Clo g_list_2emap_24s1397747289x2145601499_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1397747289x2145601499_entry, 1, 0};

V g_list_2emap_24s1397747289x2145601499(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eelab_2eprint_2eescFrom(v_x_241, MK_INT(0LL)));
    V v_t_244 = heff_strAppend(((V)&g_list_2emap_24s1397747289x2145601499_str0), heff_strAppend(v_t_243, ((V)&g_list_2emap_24s1397747289x2145601499_str1)));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s1397747289x2145601499(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1397747289x2145601499_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1397747289x2145601499(a[0]);
}
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_str0, 5, "(0 - ");
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_str1, 1, ")");
Clo g_list_2emap_24s1181937096x2120532116_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1181937096x2120532116_entry, 1, 0};

V g_list_2emap_24s1181937096x2120532116(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    if (heff_intLt_c(heff_dup(v_x_241), MK_INT(0LL))) {
      V v_t_244 = heff_intShow(heff_intSub(MK_INT(0LL), v_x_241));
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s1181937096x2120532116_str0), heff_strAppend(v_t_244, ((V)&g_list_2emap_24s1181937096x2120532116_str1)));
    } else {
      v_t_245 = heff_intShow(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1181937096x2120532116(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1181937096x2120532116_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1181937096x2120532116(a[0]);
}
Clo g_list_2emap_24s1646944445x1684083181_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1646944445x1684083181_entry, 7, 0};

V g_list_2emap_24s1646944445x1684083181(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2eelab_2eprint_2eescFrom(v_a_249, heff_dup(v_lit_242)));
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(a_0)); heff_drop(v_a_2410); r_; });
      v_t_2414 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)))));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2414, (g_list_2emap_24s1646944445x1684083181(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s1646944445x1684083181_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1646944445x1684083181(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s846355817x1552148381_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s846355817x1552148381_entry, 7, 0};

V g_list_2emap_24s846355817x1552148381(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2eelab_2eprint_2eescFrom(v_a_249, heff_dup(v_lit_242)));
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(a_0)); heff_drop(v_a_2410); r_; });
      v_t_2414 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)))));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2414, (g_list_2emap_24s846355817x1552148381(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s846355817x1552148381_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s846355817x1552148381(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s1201815197x1377530874_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1201815197x1377530874_entry, 11, 0};

V g_list_2emap_24s1201815197x1377530874(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_x2_2410) {
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24Cons = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2421;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_MkPair: {
      V v_a_2413 = heff_field(v_x_2411, 0);
      V v_a_2414 = heff_field(v_x_2411, 1);
      heff_take_n(v_x_2411, 3ULL, 2);
      V v_t_2415 = (g_heff_2eelab_2eprint_2eescFrom(v_a_2413, heff_dup(v_lit_242)));
      V v_t_2416 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2415, heff_dup(v_lit_243)));
      V v_a_2417 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 1)), heff_arrayToList(v_a_2414)));
      V v_t_2418 = ({ V a_0 = v_a_2417; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_a_2417); r_; });
      V v_t_2419 = heff_strAppend(heff_dup(v_lit_246), heff_strAppend(v_t_2418, heff_dup(v_lit_247)));
      V v_t_2420 = heff_strAppend(heff_dup(v_lit_245), heff_strAppend(v_t_2419, heff_dup(v_lit_248)));
      v_t_2421 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2416, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2420, heff_dup(v_lit_249)))));
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    return heff_tag_at_n(v_ru_24x2_2410_24Cons, TAG_Cons, 2, (V[]){v_t_2421, (g_list_2emap_24s1201815197x1377530874(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_249, v_xs_2412))});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_list_2emap_24s1201815197x1377530874_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1201815197x1377530874(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
Clo g_list_2emap_24s500158289x1934493753_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s500158289x1934493753_entry, 7, 0};

V g_list_2emap_24s500158289x1934493753(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2eelab_2eprint_2eescFrom(v_a_249, heff_dup(v_lit_242)));
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(a_0)); heff_drop(v_a_2410); r_; });
      v_t_2414 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)))));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2414, (g_list_2emap_24s500158289x1934493753(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s500158289x1934493753_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s500158289x1934493753(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2efoldl_24s978059622x523571930_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s978059622x523571930_entry, 2, 0};

V g_list_2efoldl_24s978059622x523571930(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s978059622x523571930_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s978059622x523571930(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1606891938x229778616_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1606891938x229778616_entry, 2, 0};

V g_list_2efoldl_24s1606891938x229778616(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1606891938x229778616_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1606891938x229778616(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1880194630x798487332_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1880194630x798487332_entry, 2, 0};

V g_list_2efoldl_24s1880194630x798487332(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1880194630x798487332_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1880194630x798487332(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s797527640x986490519_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s797527640x986490519_entry, 2, 0};

V g_list_2efoldl_24s797527640x986490519(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_arrayToList(heff_dup(v_a_245))));
      v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s1880194630x798487332(a_0, a_1)); heff_drop(v_t_246); r_; });
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s797527640x986490519_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s797527640x986490519(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s865198748x12535471_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s865198748x12535471_entry, 2, 0};

V g_list_2efoldl_24s865198748x12535471(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s865198748x12535471_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s865198748x12535471(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s522807745x1556762248_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s522807745x1556762248_entry, 2, 0};

V g_list_2efoldl_24s522807745x1556762248(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_a_245)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_a_245, 1);
        v_t_248 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_a_247));
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s522807745x1556762248_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s522807745x1556762248(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s76631343x1276310171_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s76631343x1276310171_entry, 1, 0};

V g_list_2emap_24s76631343x1276310171(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), (g_list_2emap_24s76631343x1276310171(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s76631343x1276310171_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s76631343x1276310171(a[0]);
}
Clo g_list_2efilter_24s328645370x374613117_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s328645370x374613117_entry, 1, 0};

V g_list_2efilter_24s328645370x374613117(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_True: {
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s328645370x374613117(v_xs_242))});
    }
    case TAG_False: {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s328645370x374613117_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s328645370x374613117(a[0]);
}
Clo g_list_2emap_24s1224798844x1489231098_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1224798844x1489231098_entry, 1, 0};

V g_list_2emap_24s1224798844x1489231098(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_x_241, 0)), heff_get_n(v_x_241, 2, 5)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1224798844x1489231098(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1224798844x1489231098_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1224798844x1489231098(a[0]);
}
Clo g_list_2emap_24s2141157620x437287316_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2141157620x437287316_entry, 1, 0};

V g_list_2emap_24s2141157620x437287316(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), (g_list_2emap_24s2141157620x437287316(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2141157620x437287316_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2141157620x437287316(a[0]);
}
Clo g_list_2emap_24s1445534224x744280941_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1445534224x744280941_entry, 2, 0};

V g_list_2emap_24s1445534224x744280941(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_240), (g_list_2emap_24s1445534224x744280941(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1445534224x744280941_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1445534224x744280941(a[0], a[1]);
}
Clo g_list_2emap_24s1990719097x1419059608_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1990719097x1419059608_entry, 1, 0};

V g_list_2emap_24s1990719097x1419059608(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tr(heff_call(v_x_241, 1, (V[]){NTAG(TAG_MkUnit)}));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1990719097x1419059608(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1990719097x1419059608(a[0]);
}
Clo g_list_2ezipWith_24s738847920x410598254_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s738847920x410598254_entry, 2, 0};

V g_list_2ezipWith_24s738847920x410598254(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkArm: {
        V v_a_246 = heff_dup(heff_field(v_x_242, 0));
        v_t_249 = v_a_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_t_2413;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkArm: {
        V v_a_2411 = heff_field(v_x_242, 1);
        heff_take_n(v_x_242, 2ULL, 3);
        v_t_2413 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      return heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_249, v_t_2413, v_y_244}), (g_list_2ezipWith_24s738847920x410598254(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s738847920x410598254(a[0], a[1]);
}
Clo g_list_2efoldl_24s1938129198x1830848254_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1938129198x1830848254_entry, 3, 0};

V g_list_2efoldl_24s1938129198x1830848254(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2elift_2eliftGo_24s1117140028x479981506(heff_dup(v_lit_240), heff_dup(v_x_243), heff_dup(heff_rfield(v_x_243, 2))));
    V v_t_249;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_t_245, 0);
      V v_a_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      V v_t_248 = ({ V rv_2 = v_a_246; V rr_ = heff_rec_reuse_n(v_x_243, 3ULL, 3, shape_key__name__body); heff_rfield(rr_, 2) = rv_2; rr_; });
      v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_a_247, 0, 2)))});
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2410 = (g_prelude_2e_2b_2b(v_t_249, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_2410;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1938129198x1830848254_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1938129198x1830848254(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s781320710x1613941343_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s781320710x1613941343_entry, 2, 0};

V g_list_2efoldl_24s781320710x1613941343(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s781320710x1613941343_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s781320710x1613941343(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1899163131x287513996_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1899163131x287513996_entry, 1, 0};

V g_list_2emap_24s1899163131x287513996(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 3, 5), (g_list_2emap_24s1899163131x287513996(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1899163131x287513996_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1899163131x287513996(a[0]);
}
Clo g_list_2efoldl_24s282854995x1837067020_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s282854995x1837067020_entry, 2, 0};

V g_list_2efoldl_24s282854995x1837067020(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_x_242, 4)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s282854995x1837067020_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s282854995x1837067020(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1278324331x1671175048_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1278324331x1671175048_entry, 2, 0};

V g_list_2efoldl_24s1278324331x1671175048(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eemit_2evalueRefs(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1278324331x1671175048_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1278324331x1671175048(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1994057367x1686730046_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1994057367x1686730046_entry, 2, 0};

V g_list_2efoldl_24s1994057367x1686730046(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2ecompile_2eemit_2evalueRefs(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1994057367x1686730046_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1994057367x1686730046(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s153144783x1331291624_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s153144783x1331291624_entry, 2, 0};

V g_list_2efoldl_24s153144783x1331291624(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2ecompile_2eemit_2evalueRefs(a_0)); heff_drop(v_t_247); r_; });
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s153144783x1331291624_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s153144783x1331291624(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1859615565x1399458702_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1859615565x1399458702_entry, 1, 0};

V g_list_2eany_24s1859615565x1399458702(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2ecompile_2eemit_2etailApp(a_0)); heff_drop(v_t_246); r_; });
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1859615565x1399458702_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1859615565x1399458702(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s175567250x489918591_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s175567250x489918591_entry, 2, 0};

V g_list_2efoldl_24s175567250x489918591(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_heff_2ecompile_2eemit_2etailGlobals(v_t_247));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s175567250x489918591_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s175567250x489918591(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1430359702x555202731_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1430359702x555202731_entry, 2, 0};

V g_list_2efoldl_24s1430359702x555202731(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2ecompile_2eemit_2ebindName(heff_take_field(v_z_240, 1), v_x_242));
    V v_t_245 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_a_244, 0)), NTAG(TAG_Nil)});
    V v_t_246 = (g_prelude_2e_2b_2b(heff_get_n(v_z_240, 0, 2), v_t_245));
    V v_t_247 = ({ V rv_0 = v_t_246; V rr_ = heff_rec_reuse_n(v_a_244, 2ULL, 2, shape_js__env); heff_rfield(rr_, 0) = rv_0; rr_; });
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1430359702x555202731_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1430359702x555202731(a[0], a[1]);
}
Clo g_list_2emap_24s357242026x384251201_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s357242026x384251201_entry, 1, 0};

V g_list_2emap_24s357242026x384251201(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), (g_list_2emap_24s357242026x384251201(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s357242026x384251201_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s357242026x384251201(a[0]);
}
Clo g_list_2emap_24s499977176x606563528_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s499977176x606563528_entry, 3, 0};

V g_list_2emap_24s499977176x606563528(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_x_243, heff_dup(v_lit_241)));
    return heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s499977176x606563528(v_lit_240, v_lit_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s499977176x606563528_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s499977176x606563528(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s374365348x2042978339_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s374365348x2042978339_entry, 2, 0};

V g_list_2emap_24s374365348x2042978339(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_242, heff_dup(v_lit_240)), (g_list_2emap_24s374365348x2042978339(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s374365348x2042978339_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s374365348x2042978339(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1610853704x1401907306_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1610853704x1401907306_entry, 3, 0};

V g_list_2ezipWith_24s1610853704x1401907306(V v_lit_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ys_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_247 = heff_strAppend(v_x_243, heff_strAppend(heff_dup(v_lit_240), v_y_245));
      return heff_tag_at_n(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_list_2ezipWith_24s1610853704x1401907306(v_lit_240, v_xs2_244, v_ys2_246))});
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2ezipWith_24s1610853704x1401907306_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1610853704x1401907306(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s776813750x121415612_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s776813750x121415612_entry, 2, 0};

V g_list_2efoldl_24s776813750x121415612(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = ({ V a_0 = v_z_240; V a_1 = v_t_246; V r_ = (g_heff_2ecompile_2eemit_2eprimUses(a_0, a_1)); heff_drop(v_t_246); r_; });
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s776813750x121415612_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s776813750x121415612(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s426392081x749835614_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s426392081x749835614_entry, 2, 0};

V g_list_2efoldl_24s426392081x749835614(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = ({ V a_0 = v_z_240; V a_1 = v_t_247; V r_ = (g_heff_2ecompile_2eemit_2eprimUses(a_0, a_1)); heff_drop(v_t_247); r_; });
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s426392081x749835614_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s426392081x749835614(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s554524976x621147349_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s554524976x621147349_entry, 2, 0};

V g_list_2efoldl_24s554524976x621147349(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eemit_2eprimUses(v_z_240, heff_rfield(v_x_242, 2)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s554524976x621147349_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s554524976x621147349(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1488470534x1183628153_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1488470534x1183628153_entry, 8, 0};

V g_list_2emap_24s1488470534x1183628153(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_a_2410 = heff_get_n(v_x_248, 0, 3);
    V v_a_2411 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_a_2410), heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_a_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_2411));
    V v_a_2415;
    switch (heff_tag_of(v_a_2412)) {
    case TAG_Nil: {
      v_a_2415 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_a_2413 = heff_field(v_a_2412, 0);
      heff_take_n(v_a_2412, 1ULL, 2);
      v_a_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_a_2413});
      break;
    }
    default: heff_nomatch(v_a_2412);
    }
    V v_a_2417;
    switch (heff_tag_of(v_a_2415)) {
    case TAG_Nothing: {
      v_a_2417 = v_a_2410;
      break;
    }
    case TAG_Just: {
      V v_a_2416 = heff_field(v_a_2415, 0);
      heff_take_n(v_a_2415, 1ULL, 1);
      heff_drop(v_a_2410);
      v_a_2417 = v_a_2416;
      break;
    }
    default: heff_nomatch(v_a_2415);
    }
    V v_t_2418 = heff_intSub(heff_strLength(heff_dup(v_a_2417)), heff_dup(v_lit_242));
    V v_t_2419 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_a_2417), v_t_2418));
    V v_t_2420 = (g_heff_2ecompile_2eemit_2espellAt(v_a_2417, v_t_2419));
    V v_a_2421 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_2420, heff_dup(v_lit_243), heff_dup(v_lit_244)));
    V v_t_2423;
    if (heff_strEq_c(heff_dup(v_a_2421), heff_dup(v_lit_245))) {
      heff_drop(v_a_2421);
      v_t_2423 = heff_dup(v_lit_246);
    } else {
      v_t_2423 = v_a_2421;
    }
    V v_t_2424 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_2423));
    return heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_t_2424, (g_list_2emap_24s1488470534x1183628153(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_249))});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s1488470534x1183628153_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1488470534x1183628153(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2efoldl_24s657006386x1833506039_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s657006386x1833506039_entry, 2, 0};

V g_list_2efoldl_24s657006386x1833506039(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s657006386x1833506039(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1787334480x145092089_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1787334480x145092089_entry, 2, 0};

V g_list_2efoldl_24s1787334480x145092089(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eemit_2evalueRefs(heff_rfield(v_x_242, 2)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1787334480x145092089_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1787334480x145092089(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s413688307x112671032_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s413688307x112671032_entry, 4, 0};

V g_list_2efilter_24s413688307x112671032(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242))) {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      return heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, (g_list_2efilter_24s413688307x112671032(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s413688307x112671032_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s413688307x112671032(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s732475005x1616712052_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s732475005x1616712052_entry, 1, 0};

V g_list_2emap_24s732475005x1616712052(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemit_2eexportNameOf(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s732475005x1616712052(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s732475005x1616712052(a[0]);
}
Clo g_list_2emap_24s649333309x1802289391_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s649333309x1802289391_entry, 1, 0};

V g_list_2emap_24s649333309x1802289391(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemit_2ehostLineOf(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s649333309x1802289391(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s649333309x1802289391(a[0]);
}
Clo g_list_2emap_24s1654555371x977048649_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1654555371x977048649_entry, 6, 0};

V g_list_2emap_24s1654555371x977048649(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_2410;
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_246), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242))) {
      V v_t_249 = heff_strSlice(heff_dup(v_x_246), heff_dup(v_lit_244), heff_strLength(v_x_246));
      v_t_2410 = heff_strAppend(heff_dup(v_lit_243), v_t_249);
    } else {
      v_t_2410 = v_x_246;
    }
    return heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_list_2emap_24s1654555371x977048649(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247))});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s1654555371x977048649_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1654555371x977048649(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s1917746138x1825516092_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1917746138x1825516092_entry, 1, 0};

V g_list_2emap_24s1917746138x1825516092(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 2), (g_list_2emap_24s1917746138x1825516092(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1917746138x1825516092_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1917746138x1825516092(a[0]);
}
Clo g_list_2emap_24s1052938345x548264065_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1052938345x548264065_entry, 5, 0};

V g_list_2emap_24s1052938345x548264065(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), v_x_245, heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_a_248 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_247));
    V v_t_2411;
    switch (heff_tag_of(v_a_248)) {
    case TAG_Nil: {
      v_t_2411 = heff_dup(v_lit_242);
      break;
    }
    case TAG_Cons: {
      V v_a_249 = heff_field(v_a_248, 0);
      V v_a_2410 = heff_field(v_a_248, 1);
      heff_take_n(v_a_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = heff_dup(v_lit_243); V a_1 = v_a_249; V a_2 = v_a_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2410); r_; });
      break;
    }
    default: heff_nomatch(v_a_248);
    }
    return heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2411, (g_list_2emap_24s1052938345x548264065(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246))});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s1052938345x548264065_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1052938345x548264065(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efilter_24s926921591x156811372_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s926921591x156811372_entry, 4, 0};

V g_list_2efilter_24s926921591x156811372(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242))) {
      return heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, (g_list_2efilter_24s926921591x156811372(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s926921591x156811372_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s926921591x156811372(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eany_24s651308273x925219243_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s651308273x925219243_entry, 1, 0};

V g_list_2eany_24s651308273x925219243(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if (heff_strEq_c(heff_dup(v_x_241), heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s651308273x925219243_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s651308273x925219243(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s634984521x2042558081_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s634984521x2042558081_entry, 1, 0};

V g_list_2emap_24s634984521x2042558081(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 2), (g_list_2emap_24s634984521x2042558081(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s634984521x2042558081_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s634984521x2042558081(a[0]);
}
Clo g_list_2emap_24s565104239x2094869705_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s565104239x2094869705_entry, 1, 0};

V g_list_2emap_24s565104239x2094869705(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = heff_rec_n(2, shape_name__key, (V[]){heff_dup(v_a_243), v_a_243});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s565104239x2094869705(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s565104239x2094869705_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s565104239x2094869705(a[0]);
}
Clo g_list_2emap_24s1009200955x251267316_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1009200955x251267316_entry, 1, 0};

V g_list_2emap_24s1009200955x251267316(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_t_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 3);
      v_t_246 = v_t_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s1009200955x251267316(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1009200955x251267316(a[0]);
}
Clo g_list_2efoldl_24s1659194469x1936830512_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1659194469x1936830512_entry, 2, 0};

V g_list_2efoldl_24s1659194469x1936830512(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2ecompile_2eemitc_2etagsLbls(v_x_242));
    V v_t_2410;
    switch (heff_tag_of(v_a_244)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_a_244, 0);
      V v_a_246 = heff_field(v_a_244, 1);
      heff_take_n(v_a_244, 3ULL, 2);
      switch (heff_tag_of(v_z_240)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_z_240, 0);
        V v_a_248 = heff_field(v_z_240, 1);
        heff_take_n(v_z_240, 3ULL, 2);
        V v_t_249 = (g_prelude_2e_2b_2b(v_a_245, v_a_247));
        v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_249, (g_prelude_2e_2b_2b(v_a_246, v_a_248))});
        break;
      }
      default: heff_nomatch(v_z_240);
      }
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1659194469x1936830512(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s420582357x1720502382_str0, 0, "");
Clo g_list_2emap_24s420582357x1720502382_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s420582357x1720502382_entry, 1, 0};

V g_list_2emap_24s420582357x1720502382(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_list_2emap_24s420582357x1720502382_str0)));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s420582357x1720502382(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s420582357x1720502382_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s420582357x1720502382(a[0]);
}
Clo g_list_2efoldl_24s1530401830x609500251_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1530401830x609500251_entry, 2, 0};

V g_list_2efoldl_24s1530401830x609500251(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1530401830x609500251(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s321107625x1130584089_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s321107625x1130584089_entry, 2, 0};

V g_list_2efoldl_24s321107625x1130584089(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_heff_2ecompile_2eemitc_2ewithKnown(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s321107625x1130584089_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s321107625x1130584089(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s873517001x1016672031_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s873517001x1016672031_entry, 2, 0};

V g_list_2efoldl_24s873517001x1016672031(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s873517001x1016672031_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s873517001x1016672031(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1196049889x1646679775_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1196049889x1646679775_entry, 7, 0};

V g_list_2emap_24s1196049889x1646679775(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strAppend(heff_dup(v_lit_241), (g_heff_2ecompile_2eemitc_2emangleW(v_x_247, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244))));
    V v_t_2410 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_249, heff_dup(v_lit_245)));
    return heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_list_2emap_24s1196049889x1646679775(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s1196049889x1646679775_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1196049889x1646679775(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2eall_24s607638492x847921129_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s607638492x847921129_entry, 1, 0};

V g_list_2eall_24s607638492x847921129(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nil: {
      V v_t_244 = heff_dup(heff_rfield(v_x_241, 2));
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nil: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_Cons: {
        heff_take_n(v_t_244, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_t_243, 0ULL, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s607638492x847921129_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s607638492x847921129(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1198759183x473355350_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1198759183x473355350_entry, 1, 0};

V g_list_2emap_24s1198759183x473355350(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), (g_list_2emap_24s1198759183x473355350(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1198759183x473355350_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1198759183x473355350(a[0]);
}
HEFF_LIT(g_list_2ezipWith_24s763642811x1204809256_str0, 2, "a_");
HEFF_LIT(g_list_2ezipWith_24s763642811x1204809256_str1, 4, "V a_");
HEFF_LIT(g_list_2ezipWith_24s763642811x1204809256_str2, 3, " = ");
HEFF_LIT(g_list_2ezipWith_24s763642811x1204809256_str3, 1, ";");
Clo g_list_2ezipWith_24s763642811x1204809256_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s763642811x1204809256_entry, 2, 0};

V g_list_2ezipWith_24s763642811x1204809256(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 3);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_dup(heff_rfield(v_x_242, 1));
      V v_t_2412;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        V v_t_247 = heff_strAppend(((V)&g_list_2ezipWith_24s763642811x1204809256_str0), heff_intShow(heff_dup(v_y_244)));
        V v_t_248 = heff_strAppend(((V)&g_list_2ezipWith_24s763642811x1204809256_str1), heff_strAppend(heff_intShow(v_y_244), heff_strAppend(((V)&g_list_2ezipWith_24s763642811x1204809256_str2), heff_strAppend(heff_dup(heff_rfield(v_x_242, 0)), ((V)&g_list_2ezipWith_24s763642811x1204809256_str3)))));
        V v_t_249 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
        v_t_2412 = ({ V rv_0 = v_t_247; V rv_1 = v_t_249; V rr_ = heff_rec_reuse_n(v_x_242, 4ULL, 3, shape_arg__pre__post); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_246, 0ULL, 2);
        heff_drop_cell(v_ru_24xs_240_24Cons, 2);
        heff_drop(v_y_244);
        v_t_2412 = v_x_242;
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_list_2ezipWith_24s763642811x1204809256(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s763642811x1204809256_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s763642811x1204809256(a[0], a[1]);
}
Clo g_list_2efoldl_24s348322209x75032364_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s348322209x75032364_entry, 2, 0};

V g_list_2efoldl_24s348322209x75032364(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 1)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s348322209x75032364_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s348322209x75032364(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s449727021x365548005_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s449727021x365548005_entry, 2, 0};

V g_list_2efoldl_24s449727021x365548005(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 2)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s449727021x365548005_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s449727021x365548005(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s203264781x503274820_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s203264781x503274820_entry, 9, 0};

V g_list_2ezipWith_24s203264781x503274820(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_xs_247, V v_ys_248) {
top: ;
  switch (heff_tag_of(v_xs_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_ys_248);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_xs_247, 0);
    V v_xs2_2410 = heff_field(v_xs_247, 1);
    V v_ru_24xs_247_24Cons = heff_take_reuse_n(v_xs_247, 3ULL, 2);
    switch (heff_tag_of(v_ys_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_249);
      heff_drop(v_xs2_2410);
      heff_drop_cell(v_ru_24xs_247_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_2411 = heff_field(v_ys_248, 0);
      V v_ys2_2412 = heff_field(v_ys_248, 1);
      heff_take_n(v_ys_248, 3ULL, 2);
      V v_t_2413 = heff_strAppend(heff_dup(v_lit_241), (g_heff_2ecompile_2eemitc_2emangleW(v_x_249, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244))));
      V v_t_2414 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2413, heff_strAppend(heff_dup(v_lit_245), heff_strAppend(heff_intShow(v_y_2411), heff_dup(v_lit_246)))));
      return heff_tag_at_n(v_ru_24xs_247_24Cons, TAG_Cons, 2, (V[]){v_t_2414, (g_list_2ezipWith_24s203264781x503274820(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs2_2410, v_ys2_2412))});
    }
    default: return heff_nomatch(v_ys_248);
    }
  }
  default: return heff_nomatch(v_xs_247);
  }
}
V g_list_2ezipWith_24s203264781x503274820_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s203264781x503274820(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_list_2emap_24s1490052334x152035327_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1490052334x152035327_entry, 1, 0};

V g_list_2emap_24s1490052334x152035327(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_a_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_a_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2411;
    switch (heff_tag_of(v_a_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_a_248, 1);
      heff_take_n(v_a_248, 2ULL, 2);
      v_t_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_a_248);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_2411}), (g_list_2emap_24s1490052334x152035327(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1490052334x152035327_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1490052334x152035327(a[0]);
}
Clo g_list_2ezipWith_24s1876717925x1404326288_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1876717925x1404326288_entry, 2, 0};

V g_list_2ezipWith_24s1876717925x1404326288(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_list_2ezipWith_24s1876717925x1404326288(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1876717925x1404326288(a[0], a[1]);
}
Clo g_list_2ezipWith_24s2039753704x2095677241_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s2039753704x2095677241_entry, 5, 0};

V g_list_2ezipWith_24s2039753704x2095677241(V v_lit_240, V v_lit_241, V v_lit_242, V v_xs_243, V v_ys_244) {
top: ;
  switch (heff_tag_of(v_xs_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_ys_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_xs_243, 0);
    V v_xs2_246 = heff_field(v_xs_243, 1);
    V v_ru_24xs_243_24Cons = heff_take_reuse_n(v_xs_243, 3ULL, 2);
    switch (heff_tag_of(v_ys_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_245);
      heff_drop(v_xs2_246);
      heff_drop_cell(v_ru_24xs_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_ys_244, 0);
      V v_ys2_248 = heff_field(v_ys_244, 1);
      heff_take_n(v_ys_244, 3ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_y_247)) {
      case TAG_MkPair: {
        V v_a_249 = heff_field(v_y_247, 0);
        heff_take_n(v_y_247, 1ULL, 2);
        v_t_2411 = v_a_249;
        break;
      }
      default: heff_nomatch(v_y_247);
      }
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(v_t_2411), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_x_245, heff_dup(v_lit_242)))));
      return heff_tag_at_n(v_ru_24xs_243_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_list_2ezipWith_24s2039753704x2095677241(v_lit_240, v_lit_241, v_lit_242, v_xs2_246, v_ys2_248))});
    }
    default: return heff_nomatch(v_ys_244);
    }
  }
  default: return heff_nomatch(v_xs_243);
  }
}
V g_list_2ezipWith_24s2039753704x2095677241_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s2039753704x2095677241(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s1601949456x759540121_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1601949456x759540121_entry, 4, 0};

V g_list_2emap_24s1601949456x759540121(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_244, 0));
      v_t_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_244, 0);
      heff_take_n(v_x_244, 1ULL, 2);
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2412 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(v_t_248), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_intShow(v_t_2411), heff_dup(v_lit_242)))));
    return heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_list_2emap_24s1601949456x759540121(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1601949456x759540121_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1601949456x759540121(a[0], a[1], a[2], a[3]);
}
Clo g_list_2ezipWith_24s1814128165x1680687847_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1814128165x1680687847_entry, 5, 0};

V g_list_2ezipWith_24s1814128165x1680687847(V v_lit_240, V v_lit_241, V v_lit_242, V v_xs_243, V v_ys_244) {
top: ;
  switch (heff_tag_of(v_xs_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_ys_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_xs_243, 0);
    V v_xs2_246 = heff_field(v_xs_243, 1);
    V v_ru_24xs_243_24Cons = heff_take_reuse_n(v_xs_243, 3ULL, 2);
    switch (heff_tag_of(v_ys_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_245);
      heff_drop(v_xs2_246);
      heff_drop_cell(v_ru_24xs_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_ys_244, 0);
      V v_ys2_248 = heff_field(v_ys_244, 1);
      heff_take_n(v_ys_244, 3ULL, 2);
      V v_t_249 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(v_y_247), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_x_245, heff_dup(v_lit_242)))));
      return heff_tag_at_n(v_ru_24xs_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_list_2ezipWith_24s1814128165x1680687847(v_lit_240, v_lit_241, v_lit_242, v_xs2_246, v_ys2_248))});
    }
    default: return heff_nomatch(v_ys_244);
    }
  }
  default: return heff_nomatch(v_xs_243);
  }
}
V g_list_2ezipWith_24s1814128165x1680687847_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1814128165x1680687847(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2ezipWith_24s924458827x719285517_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s924458827x719285517_entry, 8, 0};

V g_list_2ezipWith_24s924458827x719285517(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_xs_246, V v_ys_247) {
top: ;
  switch (heff_tag_of(v_xs_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_ys_247);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_xs_246, 0);
    V v_xs2_249 = heff_field(v_xs_246, 1);
    V v_ru_24xs_246_24Cons = heff_take_reuse_n(v_xs_246, 3ULL, 2);
    switch (heff_tag_of(v_ys_247)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_x_248);
      heff_drop(v_xs2_249);
      heff_drop_cell(v_ru_24xs_246_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_2410 = heff_field(v_ys_247, 0);
      V v_ys2_2411 = heff_field(v_ys_247, 1);
      heff_take_n(v_ys_247, 3ULL, 2);
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_240), (g_heff_2ecompile_2eemitc_2emangleW(v_x_248, heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243))));
      V v_t_2413 = heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(heff_intShow(v_y_2410), heff_dup(v_lit_245))));
      return heff_tag_at_n(v_ru_24xs_246_24Cons, TAG_Cons, 2, (V[]){v_t_2413, (g_list_2ezipWith_24s924458827x719285517(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs2_249, v_ys2_2411))});
    }
    default: return heff_nomatch(v_ys_247);
    }
  }
  default: return heff_nomatch(v_xs_246);
  }
}
V g_list_2ezipWith_24s924458827x719285517_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s924458827x719285517(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2emap_24s1006477676x1816442814_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1006477676x1816442814_entry, 3, 0};

V g_list_2emap_24s1006477676x1816442814(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(v_x_243), heff_dup(v_lit_241)));
    return heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1006477676x1816442814(v_lit_240, v_lit_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1006477676x1816442814_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1006477676x1816442814(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s910662703x1730636603_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s910662703x1730636603_entry, 1, 0};

V g_list_2eany_24s910662703x1730636603(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_x_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s910662703x1730636603(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2eall_24s1703554932x1387778930_str0, 4, "True");
HEFF_LIT(g_list_2eall_24s1703554932x1387778930_str1, 5, "False");
Clo g_list_2eall_24s1703554932x1387778930_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1703554932x1387778930_entry, 1, 0};

V g_list_2eall_24s1703554932x1387778930(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_t_243 = heff_field(v_x_241, 0);
      V v_vs_244 = heff_field(v_x_241, 1);
      switch (heff_tag_of(v_vs_244)) {
      case TAG_Nil: {
        if (heff_strEq_c(heff_dup(v_t_243), ((V)&g_list_2eall_24s1703554932x1387778930_str0))) {
          v_t_249 = NTAG(TAG_True);
        } else {
          v_t_249 = heff_strEq(heff_dup(v_t_243), ((V)&g_list_2eall_24s1703554932x1387778930_str1));
        }
        break;
      }
      case TAG_Cons: {
        v_t_249 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_vs_244);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1703554932x1387778930_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1703554932x1387778930(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1651310864x859456474_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1651310864x859456474_entry, 2, 0};

V g_list_2efoldl_24s1651310864x859456474(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1651310864x859456474(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s617071700x1606310602_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s617071700x1606310602_entry, 6, 0};

V g_list_2emap_24s617071700x1606310602(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), (g_heff_2ecompile_2eemitc_2emangleW(v_x_246, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)))));
    return heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_list_2emap_24s617071700x1606310602(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247))});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s617071700x1606310602_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s617071700x1606310602(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s1785262601x1752264566_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1785262601x1752264566_entry, 4, 0};

V g_list_2emap_24s1785262601x1752264566(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(heff_dup(v_x_244)), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_intShow(v_x_244), heff_dup(v_lit_242)))));
    return heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s1785262601x1752264566(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1785262601x1752264566_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1785262601x1752264566(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1378753456x1787722089_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1378753456x1787722089_entry, 4, 0};

V g_list_2emap_24s1378753456x1787722089(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_244, 1));
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_244, 0);
      heff_take_n(v_x_244, 1ULL, 2);
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2412 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(v_t_248), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_242)))));
    return heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_list_2emap_24s1378753456x1787722089(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1378753456x1787722089_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1378753456x1787722089(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eany_24s261760131x1433598489_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s261760131x1433598489_entry, 1, 0};

V g_list_2eany_24s261760131x1433598489(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_vs_244 = heff_field(v_x_241, 1);
      V v_b_245 = heff_field(v_x_241, 2);
      V v_x1_248;
      switch (heff_tag_of(v_vs_244)) {
      case TAG_Nil: {
        v_x1_248 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        v_x1_248 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_vs_244);
      }
      switch (heff_tag_of(v_x1_248)) {
      case TAG_True: {
        v_t_2410 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_244));
        v_t_2410 = (g_heff_2ecompile_2eemitc_2ebuildsSize(v_t_249, heff_dup(v_b_245)));
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s261760131x1433598489_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s261760131x1433598489(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1573559022x513331157_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1573559022x513331157_entry, 3, 0};

V g_list_2emap_24s1573559022x513331157(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_a_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_a_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_248 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_a_247; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_a_247); r_; });
    return heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_list_2emap_24s1573559022x513331157(v_lit_240, v_lit_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1573559022x513331157_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1573559022x513331157(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1891821040x773772203_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1891821040x773772203_entry, 2, 0};

V g_list_2efoldl_24s1891821040x773772203(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eborDef(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1891821040x773772203_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1891821040x773772203(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s96775841x2127473534_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s96775841x2127473534_entry, 2, 0};

V g_list_2efoldl_24s96775841x2127473534(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eborAll(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s96775841x2127473534_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s96775841x2127473534(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s424921060x1532378_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s424921060x1532378_entry, 7, 0};

V g_list_2emap_24s424921060x1532378(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_a_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_dup(heff_field(v_x_247, 0));
      v_a_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), (g_heff_2ecompile_2eemitc_2emangleW(v_a_2411, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244))));
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2416 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_245), heff_intShow(v_t_2415))));
    return heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2416, (g_list_2emap_24s424921060x1532378(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s424921060x1532378_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s424921060x1532378(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2efilter_24s1018181017x1541469354_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1018181017x1541469354_entry, 1, 0};

V g_list_2efilter_24s1018181017x1541469354(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_a_246 = ({ V a_0 = v_t_245; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_a_246)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1018181017x1541469354(v_xs_242))});
    }
    default: return heff_nomatch(v_a_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1018181017x1541469354_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1018181017x1541469354(a[0]);
}
Clo g_list_2emap_24s2073083146x1445066245_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2073083146x1445066245_entry, 1, 0};

V g_list_2emap_24s2073083146x1445066245(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2eshapeDef(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s2073083146x1445066245(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2073083146x1445066245(a[0]);
}
Clo g_list_2efoldl_24s690408737x127625622_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s690408737x127625622_entry, 2, 0};

V g_list_2efoldl_24s690408737x127625622(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 0)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s690408737x127625622_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s690408737x127625622(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s125569247x179592613_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s125569247x179592613_entry, 2, 0};

V g_list_2efoldl_24s125569247x179592613(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eprimCloDef(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s125569247x179592613_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s125569247x179592613(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1761834913x283136918_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1761834913x283136918_entry, 2, 0};

V g_list_2efoldl_24s1761834913x283136918(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 1)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1761834913x283136918_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1761834913x283136918(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1967523567x64647275_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1967523567x64647275_entry, 1, 0};

V g_list_2efilter_24s1967523567x64647275(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = ({ V a_0 = heff_dup(v_x_241); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_a_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1967523567x64647275(v_xs_242))});
    }
    default: return heff_nomatch(v_a_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1967523567x64647275_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1967523567x64647275(a[0]);
}
Clo g_list_2efoldl_24s2093480427x456774456_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2093480427x456774456_entry, 4, 0};

V g_list_2efoldl_24s2093480427x456774456(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_heff_2ecompile_2eemitc_2enamesInGo(heff_dup(v_lit_240), heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_242));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_247;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s2093480427x456774456_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24s2093480427x456774456(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s1196401404x611901340_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1196401404x611901340_entry, 2, 0};

V g_list_2efoldl_24s1196401404x611901340(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1196401404x611901340_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1196401404x611901340(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s132236332x1381264820_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s132236332x1381264820_entry, 2, 0};

V g_list_2efoldl_24s132236332x1381264820(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 1));
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_2413 = (g_map_2elookup_24s1546226666x2146984184(v_t_2412, v_z_240));
    V v_t_2415;
    switch (heff_tag_of(v_a_2413)) {
    case TAG_Nothing: {
      v_t_2415 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_a_2414 = heff_field(v_a_2413, 0);
      heff_take_n(v_a_2413, 1ULL, 1);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_a_2413);
    }
    V v_t_2416 = (g_map_2einsert_24s1341440536x470972936(v_t_246, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2415}), v_z_240));
    V t_0 = v_t_2416;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s132236332x1381264820(a[0], a[1]);
}
Clo g_list_2emap_24s380834591x871125279_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s380834591x871125279_entry, 1, 0};

V g_list_2emap_24s380834591x871125279(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2epubLine(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s380834591x871125279(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s380834591x871125279_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s380834591x871125279(a[0]);
}
Clo g_list_2emap_24s1328195927x21044528_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1328195927x21044528_entry, 2, 0};

V g_list_2emap_24s1328195927x21044528(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strSlice(heff_dup(v_x_242), heff_dup(v_lit_240), heff_strLength(v_x_242));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s1328195927x21044528(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1328195927x21044528_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1328195927x21044528(a[0], a[1]);
}
HEFF_LIT(g_list_2efilter_24s1727592350x8580145_str0, 13, "static Clo g_");
Clo g_list_2efilter_24s1727592350x8580145_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1727592350x8580145_entry, 1, 0};

V g_list_2efilter_24s1727592350x8580145(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), MK_INT(13LL)), ((V)&g_list_2efilter_24s1727592350x8580145_str0))) {
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1727592350x8580145(v_xs_242))});
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1727592350x8580145_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1727592350x8580145(a[0]);
}
Clo g_list_2efoldl_24s1685809585x983762522_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1685809585x983762522_entry, 10, 0};

V g_list_2efoldl_24s1685809585x983762522(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_z_248, V v_x3_249) {
top: ;
  switch (heff_tag_of(v_x3_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    return v_z_248;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x3_249, 0);
    V v_xs_2411 = heff_field(v_x3_249, 1);
    V v_ru_24x3_249_24Cons = heff_take_reuse_n(v_x3_249, 3ULL, 2);
    V v_a_2414;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_a_2412 = heff_dup(heff_field(v_x_2410, 0));
      v_a_2414 = heff_get_n(v_a_2412, 0, 3);
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_a_2415 = (g_heff_2ecompile_2eemitc_2elastDotGo(heff_dup(v_a_2414), heff_dup(v_lit_240), heff_dup(v_lit_241)));
    V v_t_2417;
    if (heff_intLt_c(heff_dup(v_a_2415), heff_dup(v_lit_242))) {
      heff_drop(v_a_2415);
      v_t_2417 = v_a_2414;
    } else {
      v_t_2417 = heff_strSlice(v_a_2414, heff_dup(v_lit_243), v_a_2415);
    }
    V v_a_2420;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_a_2418 = heff_dup(heff_field(v_x_2410, 0));
      v_a_2420 = heff_get_n(v_a_2418, 0, 3);
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_a_2421 = (g_heff_2ecompile_2eemitc_2elastDotGo(heff_dup(v_a_2420), heff_dup(v_lit_244), heff_dup(v_lit_245)));
    V v_t_2423;
    if (heff_intLt_c(heff_dup(v_a_2421), heff_dup(v_lit_246))) {
      heff_drop(v_a_2421);
      v_t_2423 = v_a_2420;
    } else {
      v_t_2423 = heff_strSlice(v_a_2420, heff_dup(v_lit_247), v_a_2421);
    }
    V v_a_2424 = (g_map_2elookup_24s1546226666x2146984184(v_t_2423, v_z_248));
    V v_t_2426;
    switch (heff_tag_of(v_a_2424)) {
    case TAG_Nothing: {
      v_t_2426 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_a_2425 = heff_field(v_a_2424, 0);
      heff_take_n(v_a_2424, 1ULL, 1);
      v_t_2426 = v_a_2425;
      break;
    }
    default: heff_nomatch(v_a_2424);
    }
    V v_t_2427 = (g_map_2einsert_24s1341440536x470972936(v_t_2417, heff_tag_at_n(v_ru_24x3_249_24Cons, TAG_Cons, 2, (V[]){v_x_2410, v_t_2426}), v_z_248));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_t_2427;
    V t_9 = v_xs_2411;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_z_248 = t_8;
    v_x3_249 = t_9;
    goto top;
  }
  default: return heff_nomatch(v_x3_249);
  }
}
V g_list_2efoldl_24s1685809585x983762522_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1685809585x983762522(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2emap_24s1691650970x173345163_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1691650970x173345163_entry, 1, 0};

V g_list_2emap_24s1691650970x173345163(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_t_245, 2, 3), (g_list_2emap_24s1691650970x173345163(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1691650970x173345163_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1691650970x173345163(a[0]);
}
Clo g_list_2efoldl_24s907092709x2006193176_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s907092709x2006193176_entry, 2, 0};

V g_list_2efoldl_24s907092709x2006193176(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      V v_t_246 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_take_field(v_a_244, 2)));
      v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_a_244, 0, 3), (g_heff_2ecompile_2eir_2enubI(v_t_246))});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s907092709x2006193176_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s907092709x2006193176(a[0], a[1]);
}
Clo g_list_2emap_24s1801850472x1352108398_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1801850472x1352108398_entry, 1, 0};

V g_list_2emap_24s1801850472x1352108398(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 3), (g_list_2emap_24s1801850472x1352108398(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1801850472x1352108398_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1801850472x1352108398(a[0]);
}
Clo g_list_2eany_24s203425463x2138315205_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s203425463x2138315205_entry, 4, 0};

V g_list_2eany_24s203425463x2138315205(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_strLength(heff_dup(v_lit_241)));
    if (heff_strEq_c(v_t_246, heff_dup(v_lit_242))) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s203425463x2138315205_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2eany_24s203425463x2138315205(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str0, 1, "\012");
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str1, 20, "#define HEFF_THREADS");
HEFF_LIT(g_list_2eany_24s762674996x1009180162_str2, 20, "#define HEFF_THREADS");
Clo g_list_2eany_24s762674996x1009180162_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s762674996x1009180162_entry, 1, 0};

V g_list_2eany_24s762674996x1009180162(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_prelude_2esplitFrom(((V)&g_list_2eany_24s762674996x1009180162_str0), heff_dup(heff_rfield(v_x_241, 1)), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_244 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_list_2eany_24s762674996x1009180162_str1); V a_2 = ((V)&g_list_2eany_24s762674996x1009180162_str2); V a_3 = v_t_243; V r_ = (g_list_2eany_24s203425463x2138315205(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s762674996x1009180162(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1665123230x1905625068_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1665123230x1905625068_entry, 6, 0};

V g_list_2emap_24s1665123230x1905625068(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_strSlice(heff_dup(v_x_246), heff_dup(v_lit_240), heff_strLength(heff_dup(v_lit_241)));
    V v_t_2410;
    if (heff_strEq_c(v_t_248, heff_dup(v_lit_242))) {
      v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){(g_heff_2ecompile_2eemitc_2eidentAt(v_x_246, heff_dup(v_lit_243), heff_dup(v_lit_244)))});
    } else {
      heff_drop(v_x_246);
      v_t_2410 = NTAG(TAG_Nothing);
    }
    return heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_list_2emap_24s1665123230x1905625068(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247))});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s1665123230x1905625068_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1665123230x1905625068(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_list_2emap_24s2047942056x1956366232_str0, 1, ":");
Clo g_list_2emap_24s2047942056x1956366232_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2047942056x1956366232_entry, 1, 0};

V g_list_2emap_24s2047942056x1956366232(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_intShow(heff_strLength(heff_dup(v_x_241)));
    V v_t_244 = heff_strAppend(v_t_243, heff_strAppend(((V)&g_list_2emap_24s2047942056x1956366232_str0), v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s2047942056x1956366232(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2047942056x1956366232_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2047942056x1956366232(a[0]);
}
Clo g_list_2efoldl_24s1410418896x1853739899_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1410418896x1853739899_entry, 2, 0};

V g_list_2efoldl_24s1410418896x1853739899(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_242, 0));
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_t_249, 1, 3), (g_list_2emap_24s1937570095x2110149801(heff_get_n(v_t_2412, 2, 3)))});
    V v_t_2414 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_t_246, 0, 3), v_t_2413, v_z_240));
    V t_0 = v_t_2414;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1410418896x1853739899_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1410418896x1853739899(a[0], a[1]);
}
Clo g_list_2efoldl_24s1301054807x1042293437_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1301054807x1042293437_entry, 2, 0};

V g_list_2efoldl_24s1301054807x1042293437(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s1410418896x1853739899(v_z_240, heff_dup(heff_rfield(v_x_242, 0))));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1301054807x1042293437_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1301054807x1042293437(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2126981320x1580482478_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2126981320x1580482478_entry, 2, 0};

V g_list_2efoldl_24s2126981320x1580482478(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_a_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_a_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_a_246, 0);
      heff_take_n(v_a_246, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_a_246);
    }
    V v_a_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      v_a_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2415;
    switch (heff_tag_of(v_a_2412)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_a_2412, 1);
      heff_take_n(v_a_2412, 2ULL, 2);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_a_2412);
    }
    V v_t_2416 = (g_map_2einsert_24s1341440536x470972936(v_t_249, v_t_2415, v_z_240));
    V t_0 = v_t_2416;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2126981320x1580482478_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2126981320x1580482478(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1751327013x555271812_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1751327013x555271812_entry, 2, 0};

V g_list_2efoldl_24s1751327013x555271812(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s2126981320x1580482478(v_z_240, heff_rfield(v_x_242, 1)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1751327013x555271812_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1751327013x555271812(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s310383131x1909826775_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s310383131x1909826775_entry, 2, 0};

V g_list_2efoldl_24s310383131x1909826775(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s2126981320x1580482478(v_z_240, heff_rfield(v_x_242, 2)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s310383131x1909826775_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s310383131x1909826775(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s883914537x614975039_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s883914537x614975039_entry, 2, 0};

V g_list_2efoldl_24s883914537x614975039(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_t_246, 0, 3), v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s883914537x614975039_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s883914537x614975039(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s332826144x1500818670_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s332826144x1500818670_entry, 2, 0};

V g_list_2efoldl_24s332826144x1500818670(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_a_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_a_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_a_246, 0);
      heff_take_n(v_a_246, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_a_246);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_242, 1);
      v_t_2412 = heff_dup(v_a_2411);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_map_2einsert_24s1341440536x470972936(v_t_249, v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s332826144x1500818670_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s332826144x1500818670(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s947555161x768980202_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s947555161x768980202_entry, 2, 0};

V g_list_2efoldl_24s947555161x768980202(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_247 = (g_heff_2esyntax_2eimport_2espaces(heff_intSub(v_t_245, v_t_246)));
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2);
    V v_t_249 = heff_strSlice(heff_dup(v_z_240), v_t_248, heff_strLength(heff_dup(v_z_240)));
    V v_t_2410 = heff_strAppend(heff_strSlice(v_z_240, MK_INT(0LL), v_t_244), heff_strAppend(v_t_247, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s947555161x768980202_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s947555161x768980202(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s424270175x1918189508_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s424270175x1918189508_entry, 1, 0};

V g_list_2emap_24s424270175x1918189508(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), (g_list_2emap_24s424270175x1918189508(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s424270175x1918189508_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s424270175x1918189508(a[0]);
}
V g_list_2efoldl_24s1728910418x1456517756_lam0(V self, V *args);
Clo g_list_2efoldl_24s1728910418x1456517756_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1728910418x1456517756_entry, 2, 0};

V g_list_2efoldl_24s1728910418x1456517756(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_245 = (g_list_2efilter(heff_clo_n(g_list_2efoldl_24s1728910418x1456517756_lam0, 1, 1, (V[]){heff_dup(v_x_242)}), heff_dup(g_heff_2esyntax_2eimport_2eimplicitImports_get())));
    V v_t_246 = (g_prelude_2e_2b_2b(v_t_245, v_z_240));
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1728910418x1456517756_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1728910418x1456517756(a[0], a1); heff_drop(a1); return r;
}
V g_list_2efoldl_24s1728910418x1456517756_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_a_244, 0, 3), v_x_242);
}
Clo g_list_2emap_24s580953129x420589622_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s580953129x420589622_entry, 1, 0};

V g_list_2emap_24s580953129x420589622(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_VRune, 1, (V[]){heff_runeToInt(v_x_241)});
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s580953129x420589622(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s580953129x420589622_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s580953129x420589622(a[0]);
}
V g_list_2efoldl_24s1602746644x1116868967_lam0(V self, V *args);
Clo g_list_2efoldl_24s1602746644x1116868967_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1602746644x1116868967_entry, 2, 0};

V g_list_2efoldl_24s1602746644x1116868967(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_clo_n(g_list_2efoldl_24s1602746644x1116868967_lam0, 1, 1, (V[]){v_x_242}), heff_dup(heff_rfield(v_z_240, 0))});
    V v_t_246 = ({ V rv_0 = v_t_245; V rr_ = heff_rec_reuse_n(v_z_240, 2ULL, 2, shape_local__global); heff_rfield(rr_, 0) = rv_0; rr_; });
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1602746644x1116868967_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1602746644x1116868967(a[0], a[1]);
}
V g_list_2efoldl_24s1602746644x1116868967_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_244);
  return heff_tag_n(TAG_Ok, 1, (V[]){v_x_242});
}
Clo g_list_2emap_24s891258639x530975267_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s891258639x530975267_entry, 2, 0};

V g_list_2emap_24s891258639x530975267(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = heff_strAppend(v_t_246, heff_strAppend(heff_dup(v_lit_240), ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; })));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_list_2emap_24s891258639x530975267(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s891258639x530975267_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s891258639x530975267(a[0], a[1]);
}
Clo g_list_2emap_24s2086294444x1195805373_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2086294444x1195805373_entry, 2, 0};

V g_list_2emap_24s2086294444x1195805373(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_dup(v_lit_240), ({ V b_0 = NTAG(TAG_True); V a_1 = v_x_242; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; }));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s2086294444x1195805373(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2086294444x1195805373_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2086294444x1195805373(a[0], a[1]);
}
Clo g_list_2emap_24s391931963x434308123_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s391931963x434308123_entry, 1, 0};

V g_list_2emap_24s391931963x434308123(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_x_241; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s391931963x434308123(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s391931963x434308123_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s391931963x434308123(a[0]);
}
Clo g_list_2emap_24s2103553821x564582624_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2103553821x564582624_entry, 2, 0};

V g_list_2emap_24s2103553821x564582624(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){heff_dup(v_lit_240)}), (g_list_2emap_24s2103553821x564582624(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2103553821x564582624_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2103553821x564582624(a[0], a[1]);
}
Clo g_list_2efoldl_24s1819302915x1539612842_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1819302915x1539612842_entry, 3, 0};

V g_list_2efoldl_24s1819302915x1539612842(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_2419;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      switch (heff_tag_of(v_a_246)) {
      case TAG_PVar: {
        V v_a_247 = heff_field(v_a_246, 0);
        if (heff_strEq_c(heff_dup(v_a_247), heff_dup(v_lit_240))) {
          v_t_2419 = v_z_241;
        } else {
          if (heff_strEq_c(heff_dup(v_a_247), heff_dup(v_a_245))) {
            v_t_2419 = v_z_241;
          } else {
            V v_t_2410 = (g_heff_2eelab_2eclauses_2erenamer(heff_dup(v_a_247), heff_dup(v_a_245)));
            v_t_2419 = heff_tr(heff_call(heff_get_n(v_t_2410, 3, 5), 1, (V[]){v_z_241}));
          }
        }
        break;
      }
      case TAG_PTag: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PLit: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PRec: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PAs: {
        v_t_2419 = v_z_241;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2419;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1819302915x1539612842_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1819302915x1539612842(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s337463599x663364213_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s337463599x663364213_entry, 2, 0};

V g_list_2efoldl_24s337463599x663364213(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2etoplevel_2ethawOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s337463599x663364213(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s215617195x1240120008_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s215617195x1240120008_entry, 2, 0};

V g_list_2efoldl_24s215617195x1240120008(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_242), NTAG(TAG_MkUnit), heff_take_field(v_z_240, 3)));
    V v_t_245 = ({ V rv_3 = v_t_244; V rr_ = heff_rec_reuse_n(v_z_240, 55ULL, 6, shape_order__entries__aliases__broken__ambiguous__places); heff_rfield(rr_, 3) = rv_3; rr_; });
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s215617195x1240120008_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s215617195x1240120008(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1261443129x1682844402_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1261443129x1682844402_entry, 2, 0};

V g_list_2efoldl_24s1261443129x1682844402(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2edriver_2eenvOne(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1261443129x1682844402(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s999799596x1949685079_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s999799596x1949685079_entry, 2, 0};

V g_list_2efoldl_24s999799596x1949685079(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 3));
    V v_t_245;
    switch (heff_tag_of(v_z_240)) {
    case TAG_Small: {
      v_t_245 = v_a_244;
      break;
    }
    case TAG_Large: {
      switch (heff_tag_of(v_a_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_a_244;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_a_244;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_a_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_a_244;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s999799596x1949685079_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s999799596x1949685079(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s478220879x497030774_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s478220879x497030774_entry, 1, 0};

V g_list_2emap_24s478220879x497030774(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_SGlobal, 1, (V[]){heff_take_field(v_x_241, 1)});
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_x_241, 0, 4), v_t_243});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s478220879x497030774(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s478220879x497030774_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s478220879x497030774(a[0]);
}
Clo g_list_2efoldl_24s1659066958x125973700_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1659066958x125973700_entry, 2, 0};

V g_list_2efoldl_24s1659066958x125973700(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 11));
    V v_t_245 = (g_heff_2esyntax_2efixity_2eappendF(heff_take_field(v_z_240, 0), heff_take_field(v_a_244, 0)));
    V v_t_246 = (g_heff_2esyntax_2efixity_2enubByG(v_t_245));
    V v_t_247 = (g_heff_2esyntax_2efixity_2eappendF(heff_get_n(v_z_240, 1, 2), heff_get_n(v_a_244, 1, 2)));
    V v_t_248 = (g_heff_2esyntax_2efixity_2enubByE(v_t_247));
    V t_0 = heff_rec_n(2, shape_groups__above, (V[]){v_t_246, v_t_248});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1659066958x125973700_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1659066958x125973700(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s864521685x1610969087_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s864521685x1610969087_entry, 1, 0};

V g_list_2emap_24s864521685x1610969087(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2edriver_2ehint(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s864521685x1610969087(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s864521685x1610969087(a[0]);
}
HEFF_LIT(g_list_2emap_24s1534167768x1221742344_str0, 56, "only the library that goes with heff declares primitives");
Clo g_list_2emap_24s1534167768x1221742344_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1534167768x1221742344_entry, 1, 0};

V g_list_2emap_24s1534167768x1221742344(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(335LL), NTAG(TAG_SError), ((V)&g_list_2emap_24s1534167768x1221742344_str0), v_sp_244, NTAG(TAG_Nothing)});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1534167768x1221742344(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1534167768x1221742344_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1534167768x1221742344(a[0]);
}
Clo g_list_2emap_24s1535007417x1587061701_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1535007417x1587061701_entry, 1, 0};

V g_list_2emap_24s1535007417x1587061701(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2424;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_243, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_243, 0ULL, 5);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_243, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2418 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){v_x_2418, v_sp_244})});
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, (g_list_2emap_24s1535007417x1587061701(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1535007417x1587061701_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1535007417x1587061701(a[0]);
}
Clo g_list_2efilter_24s1725367856x1498536808_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1725367856x1498536808_entry, 1, 0};

V g_list_2efilter_24s1725367856x1498536808(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2424;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_dup(heff_field(v_x_241, 0));
      V v_sp_244 = heff_dup(heff_field(v_x_241, 1));
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_243, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_243, 0ULL, 5);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_243, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2418 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){v_x_2418, v_sp_244})});
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nothing: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1725367856x1498536808(v_xs_242))});
    }
    case TAG_Just: {
      heff_take_n(v_t_2424, 0ULL, 1);
      heff_drop(v_x_241);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1725367856x1498536808_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1725367856x1498536808(a[0]);
}
Clo g_list_2efoldl_24s1777264376x185554286_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1777264376x185554286_entry, 2, 0};

V g_list_2efoldl_24s1777264376x185554286(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_x_242, 5)), heff_dup(heff_rfield(v_x_242, 3))));
    V v_a_245 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_x_242, 4), v_t_244));
    V v_t_246 = (g_list_2emap_24s424270175x1918189508(heff_dup(heff_rfield(v_a_245, 0))));
    V v_a_247 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_246));
    V v_t_248 = (g_heff_2ebuild_2edriver_2eclosureGo(v_z_240, NTAG(TAG_Nil), v_a_247));
    V v_t_249 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_a_245; V b_3 = NTAG(TAG_Nothing); V a_4 = v_t_248; V r_ = (g_heff_2ebuild_2edriver_2eelabNeeding(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); heff_drop(v_t_248); r_; });
    V v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2ebuild_2edriver_2eappendD(v_z_240, v_t_2410));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1777264376x185554286_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1777264376x185554286(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s214260857x938990544_str0, 0, "");
V g_list_2emap_24s214260857x938990544_lam0(V self, V *args); static Clo g_list_2emap_24s214260857x938990544_lam0_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_lam0, 1, 0};
Clo g_list_2emap_24s214260857x938990544_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_entry, 1, 0};

V g_list_2emap_24s214260857x938990544(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V rv_4 = ((V)&g_list_2emap_24s214260857x938990544_lam0_clo); V rr_ = heff_rec_reuse_n(v_x_241, 15ULL, 5, shape_span__name__key__member__ty); heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s214260857x938990544(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s214260857x938990544_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s214260857x938990544(a[0]);
}
V g_list_2emap_24s214260857x938990544_lam0(V self, V *args) {
  V v_u_243 = args[0];
  heff_drop(v_u_243);
  return ((V)&g_list_2emap_24s214260857x938990544_str0);
}
Clo g_list_2efoldl_24s1221316612x1915668835_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1221316612x1915668835_entry, 2, 0};

V g_list_2efoldl_24s1221316612x1915668835(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_x_242, 5)), heff_dup(heff_rfield(v_x_242, 3))));
    V v_a_245 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_x_242, 4), v_t_244));
    V v_t_246 = (g_list_2emap_24s424270175x1918189508(heff_dup(heff_rfield(v_a_245, 0))));
    V v_a_247 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_246));
    V v_t_248 = (g_heff_2ebuild_2edriver_2eclosureGo(v_z_240, NTAG(TAG_Nil), v_a_247));
    V v_t_249 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_a_245; V b_3 = NTAG(TAG_Nothing); V a_4 = v_t_248; V r_ = (g_heff_2ebuild_2edriver_2eelabNeeding(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); heff_drop(v_t_248); r_; });
    V v_t_2410 = (g_heff_2ebuild_2edriver_2elean(v_t_249));
    V v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    V v_t_2412 = (g_heff_2ebuild_2edriver_2eappendD(v_z_240, v_t_2411));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1221316612x1915668835_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1221316612x1915668835(a[0], a[1]);
}
Clo g_list_2emap_24s1431621018x139529971_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1431621018x139529971_entry, 2, 0};

V g_list_2emap_24s1431621018x139529971(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_x_242)));
    V v_t_245 = heff_strAppend(v_t_244, heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_242, 2, 5)));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1431621018x139529971(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1431621018x139529971_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1431621018x139529971(a[0], a[1]);
}
Clo g_list_2efoldl_24s407249128x802036125_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s407249128x802036125_entry, 2, 0};

V g_list_2efoldl_24s407249128x802036125(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_242, 0);
      v_t_249 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s407249128x802036125_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s407249128x802036125(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s944722006x358970142_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s944722006x358970142_entry, 1, 0};

V g_list_2emap_24s944722006x358970142(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_t_245, 0, 2), (g_list_2emap_24s944722006x358970142(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s944722006x358970142_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s944722006x358970142(a[0]);
}
V g_list_2efoldl_24s682444417x1397580212_lam0(V self, V *args);
Clo g_list_2efoldl_24s682444417x1397580212_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s682444417x1397580212_entry, 6, 0};

V g_list_2efoldl_24s682444417x1397580212(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_z_244, V v_x3_245) {
top: ;
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return v_z_244;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x3_245, 0);
    V v_xs_247 = heff_field(v_x3_245, 1);
    V v_t_248 = (g_prelude_2esplitFrom(heff_dup(v_lit_242), heff_dup(heff_rfield(v_x_246, 4)), heff_dup(v_lit_243), NTAG(TAG_Nil)));
    V v_t_2412 = (g_list_2emap(heff_clo_n(g_list_2efoldl_24s682444417x1397580212_lam0, 1, 3, (V[]){heff_dup(v_x_246), heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_t_248));
    V v_t_2413 = (g_heff_2ebuild_2edriver_2epromoteAt(v_z_244, heff_dup(heff_rfield(v_x_246, 7)), heff_dup(heff_rfield(v_x_246, 8)), v_t_2412));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_t_2413;
    V t_5 = v_xs_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_z_244 = t_4;
    v_x3_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x3_245);
  }
}
V g_list_2efoldl_24s682444417x1397580212_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_list_2efoldl_24s682444417x1397580212(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
V g_list_2efoldl_24s682444417x1397580212_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_get_n(v_x_246, 9, 10);
  V v_t_2411;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_lit_241);
    v_t_2411 = v_lit_240;
    break;
  }
  case TAG_False: {
    heff_drop(v_lit_240);
    v_t_2411 = v_lit_241;
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  return heff_strAppend(v_t_2411, v_a_249);
}
Clo g_list_2emerge_24s293607948x301101025_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s293607948x301101025_entry, 2, 0};

V g_list_2emerge_24s293607948x301101025(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 10);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_y_244, 0)), heff_dup(heff_rfield(v_x_242, 0)))) {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s293607948x301101025(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      } else {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s293607948x301101025(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s293607948x301101025_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s293607948x301101025(a[0], a[1]);
}
Clo g_list_2esortBy_24s851943868x104872707_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s851943868x104872707_entry, 1, 0};

V g_list_2esortBy_24s851943868x104872707(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s851943868x104872707(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s851943868x104872707(v_t_2411));
      return (g_list_2emerge_24s293607948x301101025(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s851943868x104872707_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s851943868x104872707(a[0]);
}
Clo g_list_2emap_24s570961906x1112476114_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s570961906x1112476114_entry, 1, 0};

V g_list_2emap_24s570961906x1112476114(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2edriver_2elabelOfV(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s570961906x1112476114(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s570961906x1112476114_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s570961906x1112476114(a[0]);
}
HEFF_LIT(g_list_2emap_24s218655275x981659442_str0, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str1, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str2, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str3, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str4, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str5, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str6, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str7, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_str8, 0, "");
Clo g_list_2emap_24s218655275x981659442_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s218655275x981659442_entry, 1, 0};

V g_list_2emap_24s218655275x981659442(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_241)) {
    case TAG_VFun: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2413 = ((V)&g_list_2emap_24s218655275x981659442_str0);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2413 = ((V)&g_list_2emap_24s218655275x981659442_str1);
      break;
    }
    case TAG_VTag: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2413 = ((V)&g_list_2emap_24s218655275x981659442_str2);
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2413 = ((V)&g_list_2emap_24s218655275x981659442_str3);
      break;
    }
    case TAG_VFloat: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2413 = ((V)&g_list_2emap_24s218655275x981659442_str4);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2413 = ((V)&g_list_2emap_24s218655275x981659442_str5);
      break;
    }
    case TAG_VStr: {
      V v_s_2410 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_2413 = v_s_2410;
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2413 = ((V)&g_list_2emap_24s218655275x981659442_str6);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2413 = ((V)&g_list_2emap_24s218655275x981659442_str7);
      break;
    }
    case TAG_VErased: {
      v_t_2413 = ((V)&g_list_2emap_24s218655275x981659442_str8);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, (g_list_2emap_24s218655275x981659442(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s218655275x981659442_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s218655275x981659442(a[0]);
}
Clo g_list_2emap_24s1895313378x47656836_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1895313378x47656836_entry, 1, 0};

V g_list_2emap_24s1895313378x47656836(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2edriver_2eoutcomeOfV(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1895313378x47656836(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1895313378x47656836_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1895313378x47656836(a[0]);
}
Clo g_list_2efilter_24s835571418x868029304_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s835571418x868029304_entry, 1, 0};

V g_list_2efilter_24s835571418x868029304(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    switch (heff_tag_of(v_t_243)) {
    case TAG_SError: {
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s835571418x868029304(v_xs_242))});
    }
    case TAG_SWarning: {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_SDebug: {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s835571418x868029304_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s835571418x868029304(a[0]);
}
Clo g_list_2emap_24s268264395x330149387_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s268264395x330149387_entry, 4, 0};

V g_list_2emap_24s268264395x330149387(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(heff_rfield(v_x_244, 0)), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_get_n(v_x_244, 1, 2), heff_dup(v_lit_242)))));
    return heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s268264395x330149387(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s268264395x330149387_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s268264395x330149387(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efilter_24s2048945121x1749617505_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2048945121x1749617505_entry, 2, 0};

V g_list_2efilter_24s2048945121x1749617505(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_x_242), heff_dup(v_lit_240))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2efilter_24s2048945121x1749617505(v_lit_240, v_xs_243))});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s2048945121x1749617505_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2048945121x1749617505(a[0], a[1]);
}
Clo g_list_2efoldl_24s1936649287x1723798793_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1936649287x1723798793_entry, 2, 0};

V g_list_2efoldl_24s1936649287x1723798793(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2edriver_2eglueOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1936649287x1723798793_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1936649287x1723798793(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1798985515x221942800_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1798985515x221942800_entry, 2, 0};

V g_list_2efoldl_24s1798985515x221942800(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_a_244), v_z_240));
      switch (heff_tag_of(v_a_246)) {
      case TAG_Nothing: {
        v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_a_244), heff_dup(v_a_245), v_z_240));
        break;
      }
      case TAG_Just: {
        heff_take_n(v_a_246, 0ULL, 1);
        v_t_248 = v_z_240;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1798985515x221942800_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1798985515x221942800(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1522665373x570032865_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1522665373x570032865_entry, 10, 0};

V g_list_2emap_24s1522665373x570032865(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_x2_249) {
top: ;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24Cons = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2412 = heff_take_field(v_x_2410, 1);
    V v_t_2413;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_AssocLeft: {
      v_t_2413 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2413 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2413 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2414 = heff_take_field(v_x_2410, 3);
    V v_t_2415;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      v_t_2415 = heff_dup(v_lit_244);
      break;
    }
    case TAG_False: {
      v_t_2415 = heff_dup(v_lit_245);
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2416 = heff_take_field(v_x_2410, 2);
    V v_t_2419;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nil: {
      v_t_2419 = heff_dup(v_lit_247);
      break;
    }
    case TAG_Cons: {
      V v_a_2417 = heff_field(v_t_2416, 0);
      V v_a_2418 = heff_field(v_t_2416, 1);
      heff_take_n(v_t_2416, 3ULL, 2);
      v_t_2419 = ({ V a_0 = heff_dup(v_lit_248); V a_1 = v_a_2417; V a_2 = v_a_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2418); r_; });
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_t_2420 = heff_strAppend(heff_get_n(v_x_2410, 0, 5), heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(v_t_2413), heff_strAppend(v_t_2415, heff_strAppend(heff_dup(v_lit_246), v_t_2419)))));
    return heff_tag_at_n(v_ru_24x2_249_24Cons, TAG_Cons, 2, (V[]){v_t_2420, (g_list_2emap_24s1522665373x570032865(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_xs_2411))});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_list_2emap_24s1522665373x570032865_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1522665373x570032865(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2emap_24s738510110x679538579_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s738510110x679538579_entry, 2, 0};

V g_list_2emap_24s738510110x679538579(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_take_field(v_x_242, 0), heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_242, 1, 2)));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s738510110x679538579(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s738510110x679538579_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s738510110x679538579(a[0], a[1]);
}
Clo g_list_2emap_24s2063150796x1704946690_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2063150796x1704946690_entry, 1, 0};

V g_list_2emap_24s2063150796x1704946690(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), (g_list_2emap_24s2063150796x1704946690(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2063150796x1704946690_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2063150796x1704946690(a[0]);
}
Clo g_list_2efoldl_24s775969440x1318400394_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s775969440x1318400394_entry, 3, 0};

V g_list_2efoldl_24s775969440x1318400394(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength(heff_dup(v_x_243)));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(heff_dup(v_lit_240), v_x_243));
    V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_248;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s775969440x1318400394_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s775969440x1318400394(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s196488697x1402130510_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s196488697x1402130510_entry, 12, 0};

V g_list_2efoldl_24s196488697x1402130510(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_z_2410, V v_x3_2411) {
top: ;
  switch (heff_tag_of(v_x3_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return v_z_2410;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x3_2411, 0);
    V v_xs_2413 = heff_field(v_x3_2411, 1);
    V v_ru_24x3_2411_24Cons = heff_take_reuse_n(v_x3_2411, 3ULL, 2);
    V v_a_2414 = heff_take_field(v_x_2412, 0);
    V v_t_2415 = heff_intShow(heff_strLength(heff_dup(v_a_2414)));
    V v_t_2416 = heff_strAppend(v_t_2415, heff_strAppend(heff_dup(v_lit_240), v_a_2414));
    V v_t_2417 = heff_take_field(v_x_2412, 1);
    V v_t_2418;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_AssocLeft: {
      v_t_2418 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2418 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2418 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2419 = heff_take_field(v_x_2412, 3);
    V v_t_2420;
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      v_t_2420 = heff_dup(v_lit_244);
      break;
    }
    case TAG_False: {
      v_t_2420 = heff_dup(v_lit_245);
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    V v_a_2421 = heff_take_field(v_x_2412, 4);
    V v_t_2422 = heff_intShow(heff_strLength(heff_dup(v_a_2421)));
    V v_t_2423 = heff_strAppend(v_t_2422, heff_strAppend(heff_dup(v_lit_246), v_a_2421));
    V v_a_2424 = heff_get_n(v_x_2412, 2, 5);
    V v_t_2425 = (g_list_2efoldl_24s1116451536x2100070357(heff_dup(v_lit_247), heff_dup(v_lit_248), v_a_2424));
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_2424));
    V v_t_2427 = heff_tag_at_n(v_ru_24x3_2411_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_t_2425), (g_list_2efoldl_24s775969440x1318400394(heff_dup(v_lit_249), NTAG(TAG_Nil), v_t_2426))});
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2418), v_t_2428});
    V v_t_2430 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2429}), v_z_2410));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_lit_249;
    V t_10 = v_t_2430;
    V t_11 = v_xs_2413;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_lit_249 = t_9;
    v_z_2410 = t_10;
    v_x3_2411 = t_11;
    goto top;
  }
  default: return heff_nomatch(v_x3_2411);
  }
}
V g_list_2efoldl_24s196488697x1402130510_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s196488697x1402130510(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
}
Clo g_list_2efoldl_24s1370710786x897780937_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1370710786x897780937_entry, 4, 0};

V g_list_2efoldl_24s1370710786x897780937(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_a_246 = heff_take_field(v_x_244, 0);
    V v_t_247 = heff_intShow(heff_strLength(heff_dup(v_a_246)));
    V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(heff_dup(v_lit_240), v_a_246));
    V v_a_249 = heff_get_n(v_x_244, 1, 2);
    V v_t_2410 = heff_intShow(heff_strLength(heff_dup(v_a_249)));
    V v_t_2411 = heff_strAppend(v_t_2410, heff_strAppend(heff_dup(v_lit_241), v_a_249));
    V v_t_2412 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    V v_t_2413 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2412}), v_z_242));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2413;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1370710786x897780937_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1370710786x897780937(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1176007509x671449441_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1176007509x671449441_entry, 5, 0};

V g_list_2emap_24s1176007509x671449441(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 2ULL, 2);
      v_a_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_a_2410 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_a_249), heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_t_2415;
    switch (heff_tag_of(v_a_2410)) {
    case TAG_Nil: {
      v_t_2415 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_MkPair, 2, (V[]){v_a_249, heff_dup(v_lit_242)});
      break;
    }
    case TAG_Cons: {
      V v_a_2411 = heff_field(v_a_2410, 0);
      V v_a_2412 = heff_field(v_a_2410, 1);
      heff_take_n(v_a_2410, 3ULL, 2);
      switch (heff_tag_of(v_a_2412)) {
      case TAG_Nil: {
        heff_drop(v_a_2411);
        v_t_2415 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_MkPair, 2, (V[]){v_a_249, heff_dup(v_lit_243)});
        break;
      }
      case TAG_Cons: {
        V v_a_2413 = heff_field(v_a_2412, 0);
        heff_take_n(v_a_2412, 1ULL, 2);
        heff_drop(v_a_249);
        v_t_2415 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_MkPair, 2, (V[]){v_a_2411, v_a_2413});
        break;
      }
      default: heff_nomatch(v_a_2412);
      }
      break;
    }
    default: heff_nomatch(v_a_2410);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, (g_list_2emap_24s1176007509x671449441(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246))});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s1176007509x671449441_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1176007509x671449441(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24s1854884545x892082821_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1854884545x892082821_entry, 2, 0};

V g_list_2efoldl_24s1854884545x892082821(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2edoc_2e_3c_3e(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1854884545x892082821_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1854884545x892082821(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1221903513x233153387_str0, 1, "\012");
HEFF_LIT(g_list_2emap_24s1221903513x233153387_str1, 0, "");
HEFF_LIT(g_list_2emap_24s1221903513x233153387_str2, 0, "");
Clo g_list_2emap_24s1221903513x233153387_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1221903513x233153387_entry, 1, 0};

V g_list_2emap_24s1221903513x233153387(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = (g_prelude_2esplitFrom(((V)&g_list_2emap_24s1221903513x233153387_str0), heff_get_n(v_x_241, 0, 2), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_s_246 = ((V)&g_list_2emap_24s1221903513x233153387_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_s_246 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_248;
    if (heff_strEq_c(heff_dup(v_s_246), ((V)&g_list_2emap_24s1221903513x233153387_str2))) {
      heff_drop(v_s_246);
      v_t_248 = NTAG(TAG_None);
    } else {
      v_t_248 = heff_tag_n(TAG_Text, 1, (V[]){v_s_246});
    }
    V v_t_249 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_248));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_list_2emap_24s1221903513x233153387(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1221903513x233153387_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1221903513x233153387(a[0]);
}
HEFF_LIT(g_list_2emap_24s422923909x1655406376_str0, 1, "\012");
HEFF_LIT(g_list_2emap_24s422923909x1655406376_str1, 0, "");
HEFF_LIT(g_list_2emap_24s422923909x1655406376_str2, 0, "");
HEFF_LIT(g_list_2emap_24s422923909x1655406376_str3, 1, " ");
Clo g_list_2emap_24s422923909x1655406376_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s422923909x1655406376_entry, 1, 0};

V g_list_2emap_24s422923909x1655406376(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = (g_prelude_2esplitFrom(((V)&g_list_2emap_24s422923909x1655406376_str0), v_x_241, MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_s_246 = ((V)&g_list_2emap_24s422923909x1655406376_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_s_246 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_248;
    if (heff_strEq_c(heff_dup(v_s_246), ((V)&g_list_2emap_24s422923909x1655406376_str2))) {
      heff_drop(v_s_246);
      v_t_248 = NTAG(TAG_None);
    } else {
      v_t_248 = heff_tag_n(TAG_Text, 1, (V[]){v_s_246});
    }
    V v_t_249 = (g_std_2edoc_2e_3c_3e(v_t_248, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_list_2emap_24s422923909x1655406376_str3)})));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_list_2emap_24s422923909x1655406376(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s422923909x1655406376_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s422923909x1655406376(a[0]);
}
HEFF_LIT(g_list_2eany_24s577543654x765608923_str0, 12, "-- fmt: skip");
Clo g_list_2eany_24s577543654x765608923_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s577543654x765608923_entry, 1, 0};

V g_list_2eany_24s577543654x765608923(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_s_243 = heff_dup(heff_rfield(v_x_241, 0));
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(heff_dup(v_s_243), heff_strLength(heff_dup(v_s_243))));
    if (heff_strEq_c(heff_strSlice(v_s_243, MK_INT(0LL), v_t_244), ((V)&g_list_2eany_24s577543654x765608923_str0))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s577543654x765608923_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s577543654x765608923(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s759871588x920431471_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s759871588x920431471_entry, 1, 0};

V g_list_2emap_24s759871588x920431471(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 9), (g_list_2emap_24s759871588x920431471(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s759871588x920431471_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s759871588x920431471(a[0]);
}
Clo g_list_2eany_24s2118781542x1794344985_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2118781542x1794344985_entry, 1, 0};

V g_list_2eany_24s2118781542x1794344985(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s2118781542x1794344985_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s2118781542x1794344985(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s725725455x1186198702_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s725725455x1186198702_entry, 1, 0};

V g_list_2emap_24s725725455x1186198702(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(heff_dup(v_x_241), heff_strLength(heff_dup(v_x_241))));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_x_241, MK_INT(0LL), v_t_243), (g_list_2emap_24s725725455x1186198702(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s725725455x1186198702(a[0]);
}
Clo g_list_2emap_24s1195846327x230486685_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1195846327x230486685_entry, 7, 0};

V g_list_2emap_24s1195846327x230486685(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkFieldPat: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      V v_ru_24x_247_24MkFieldPat = heff_take_reuse_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2esyntax_2eformat_2epatKey(v_a_2410));
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_a_2413 = heff_tag_at_n(v_ru_24x_247_24MkFieldPat, TAG_Cons, 2, (V[]){v_a_249, v_t_2412});
      V v_a_2414 = (g_list_2emap_24s1367796012x2117543847(heff_dup(v_lit_242), v_a_2413));
      V v_t_2417;
      switch (heff_tag_of(v_a_2414)) {
      case TAG_Nil: {
        v_t_2417 = heff_dup(v_lit_243);
        break;
      }
      case TAG_Cons: {
        V v_a_2415 = heff_field(v_a_2414, 0);
        V v_a_2416 = heff_field(v_a_2414, 1);
        heff_take_n(v_a_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = heff_dup(v_lit_244); V a_1 = v_a_2415; V a_2 = v_a_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2416); r_; });
        break;
      }
      default: heff_nomatch(v_a_2414);
      }
      v_t_2418 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2417, heff_dup(v_lit_245))));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, (g_list_2emap_24s1195846327x230486685(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s1195846327x230486685_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1195846327x230486685(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s1561756891x1126436879_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1561756891x1126436879_entry, 1, 0};

V g_list_2emap_24s1561756891x1126436879(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2eformat_2epatKey(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1561756891x1126436879(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1561756891x1126436879_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1561756891x1126436879(a[0]);
}
Clo g_list_2emap_24s1602529591x1809288035_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1602529591x1809288035_entry, 1, 0};

V g_list_2emap_24s1602529591x1809288035(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 5), (g_list_2emap_24s1602529591x1809288035(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1602529591x1809288035_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1602529591x1809288035(a[0]);
}
Clo g_list_2emap_24s953916415x1126219438_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s953916415x1126219438_entry, 2, 0};

V g_list_2emap_24s953916415x1126219438(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_244 = heff_get_n(v_x_242, 2, 3);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(heff_dup(v_a_244), heff_strLength(heff_dup(v_a_244))));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_a_244, heff_dup(v_lit_240), v_t_245), (g_list_2emap_24s953916415x1126219438(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s953916415x1126219438_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s953916415x1126219438(a[0], a[1]);
}
Clo g_list_2eall_24s107199714x217634386_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s107199714x217634386_entry, 3, 0};

V g_list_2eall_24s107199714x217634386(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if (heff_intLe_c(heff_dup(v_lit_240), heff_dup(v_x_243))) {
      if (heff_intLe_c(heff_dup(v_x_243), heff_dup(v_lit_241))) {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      } else {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eall_24s107199714x217634386_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eall_24s107199714x217634386(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s546447922x1671206170_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s546447922x1671206170_entry, 2, 0};

V g_list_2emap_24s546447922x1671206170(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_244 = (g_prelude_2eparseInt(v_x_242));
    V v_t_246;
    switch (heff_tag_of(v_a_244)) {
    case TAG_Nothing: {
      v_t_246 = heff_dup(v_lit_240);
      break;
    }
    case TAG_Just: {
      V v_a_245 = heff_field(v_a_244, 0);
      heff_take_n(v_a_244, 1ULL, 1);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s546447922x1671206170(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s546447922x1671206170_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s546447922x1671206170(a[0], a[1]);
}
Clo g_list_2eall_24s1821787051x863686734_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1821787051x863686734_entry, 13, 0};

V g_list_2eall_24s1821787051x863686734(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_x2_2412) {
top: ;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    heff_drop(v_lit_2410);
    heff_drop(v_lit_2411);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    V v_t_2416;
    if (heff_intLe_c(heff_dup(v_lit_240), heff_dup(v_x_2413))) {
      v_t_2416 = heff_intLe(heff_dup(v_x_2413), heff_dup(v_lit_241));
    } else {
      v_t_2416 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      V t_10 = v_lit_2410;
      V t_11 = v_lit_2411;
      V t_12 = v_xs_2414;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_lit_2411 = t_11;
      v_x2_2412 = t_12;
      goto top;
    }
    case TAG_False: {
      V v_t_2423;
      if (heff_intLe_c(heff_dup(v_lit_242), heff_dup(v_x_2413))) {
        if (heff_intLe_c(heff_dup(v_x_2413), heff_dup(v_lit_243))) {
          v_t_2423 = NTAG(TAG_True);
        } else {
          if (heff_intLe_c(heff_dup(v_lit_244), heff_dup(v_x_2413))) {
            if (heff_intLe_c(heff_dup(v_x_2413), heff_dup(v_lit_245))) {
              v_t_2423 = NTAG(TAG_True);
            } else {
              v_t_2423 = heff_intEq(heff_dup(v_x_2413), heff_dup(v_lit_246));
            }
          } else {
            v_t_2423 = heff_intEq(heff_dup(v_x_2413), heff_dup(v_lit_247));
          }
        }
      } else {
        if (heff_intLe_c(heff_dup(v_lit_248), heff_dup(v_x_2413))) {
          if (heff_intLe_c(heff_dup(v_x_2413), heff_dup(v_lit_249))) {
            v_t_2423 = NTAG(TAG_True);
          } else {
            v_t_2423 = heff_intEq(heff_dup(v_x_2413), heff_dup(v_lit_2410));
          }
        } else {
          v_t_2423 = heff_intEq(heff_dup(v_x_2413), heff_dup(v_lit_2411));
        }
      }
      switch (heff_tag_of(v_t_2423)) {
      case TAG_True: {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_lit_245;
        V t_6 = v_lit_246;
        V t_7 = v_lit_247;
        V t_8 = v_lit_248;
        V t_9 = v_lit_249;
        V t_10 = v_lit_2410;
        V t_11 = v_lit_2411;
        V t_12 = v_xs_2414;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_lit_245 = t_5;
        v_lit_246 = t_6;
        v_lit_247 = t_7;
        v_lit_248 = t_8;
        v_lit_249 = t_9;
        v_lit_2410 = t_10;
        v_lit_2411 = t_11;
        v_x2_2412 = t_12;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        heff_drop(v_lit_243);
        heff_drop(v_lit_244);
        heff_drop(v_lit_245);
        heff_drop(v_lit_246);
        heff_drop(v_lit_247);
        heff_drop(v_lit_248);
        heff_drop(v_lit_249);
        heff_drop(v_lit_2410);
        heff_drop(v_lit_2411);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2423);
      }
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_list_2eall_24s1821787051x863686734_entry(V self, V *a) {
  (void)self;
  V a12 = a[12]; V r = g_list_2eall_24s1821787051x863686734(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a12); heff_drop(a12); return r;
}
Clo g_list_2emap_24s1626183354x549349049_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1626183354x549349049_entry, 1, 0};

V g_list_2emap_24s1626183354x549349049(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), (g_list_2emap_24s1626183354x549349049(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1626183354x549349049_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1626183354x549349049(a[0]);
}
Clo g_list_2ezipWith_24s868949484x1127836054_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s868949484x1127836054_entry, 2, 0};

V g_list_2ezipWith_24s868949484x1127836054(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_244, 0, 3), v_x_242});
      return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2ezipWith_24s868949484x1127836054(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s868949484x1127836054_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s868949484x1127836054(a[0], a[1]);
}
Clo g_list_2ezipWith_24s568889179x755145155_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s568889179x755145155_entry, 2, 0};

V g_list_2ezipWith_24s568889179x755145155(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_244, 0, 2), v_x_242});
      return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2ezipWith_24s568889179x755145155(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s568889179x755145155_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s568889179x755145155(a[0], a[1]);
}
Clo g_list_2ezipWith_24s31176117x1618486040_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s31176117x1618486040_entry, 2, 0};

V g_list_2ezipWith_24s31176117x1618486040(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_244, 1, 3), v_x_242});
      return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2ezipWith_24s31176117x1618486040(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s31176117x1618486040_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s31176117x1618486040(a[0], a[1]);
}
Clo g_list_2emap_24s336317878x1053990440_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s336317878x1053990440_entry, 1, 0};

V g_list_2emap_24s336317878x1053990440(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 3), (g_list_2emap_24s336317878x1053990440(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s336317878x1053990440_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s336317878x1053990440(a[0]);
}
Clo g_list_2efilter_24s1214006305x787928862_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1214006305x787928862_entry, 1, 0};

V g_list_2efilter_24s1214006305x787928862(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_241, 1)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1214006305x787928862(v_xs_242))});
    } else {
      heff_drop_rec(v_x_241, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1214006305x787928862_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1214006305x787928862(a[0]);
}
Clo g_list_2emap_24s467999193x422550880_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s467999193x422550880_entry, 4, 0};

V g_list_2emap_24s467999193x422550880(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_take_field(v_x_244, 0), heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(heff_rfield(v_x_244, 1)), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_get_n(v_x_244, 2, 3), heff_dup(v_lit_242))))));
    return heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s467999193x422550880(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s467999193x422550880_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s467999193x422550880(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emerge_24s132798885x1165759438_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s132798885x1165759438_entry, 2, 0};

V g_list_2emerge_24s132798885x1165759438(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = (g_heff_2ebuild_2eproject_2esumBefore(heff_dup(v_x_242), heff_dup(v_y_244)));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s132798885x1165759438(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s132798885x1165759438(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s132798885x1165759438_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s132798885x1165759438(a[0], a[1]);
}
Clo g_list_2esortBy_24s492793466x2081132734_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s492793466x2081132734_entry, 1, 0};

V g_list_2esortBy_24s492793466x2081132734(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s492793466x2081132734(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s492793466x2081132734(v_t_2411));
      return (g_list_2emerge_24s132798885x1165759438(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s492793466x2081132734_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s492793466x2081132734(a[0]);
}
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str0, 9, "{ name = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str1, 9, ", path = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str2, 12, ", version = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_str3, 2, " }");
Clo g_list_2emap_24s1381986540x1952410492_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1381986540x1952410492_entry, 1, 0};

V g_list_2emap_24s1381986540x1952410492(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2eproject_2equoted(heff_take_field(v_x_241, 0)));
    V v_t_244 = (g_heff_2ebuild_2eproject_2equoted(heff_take_field(v_x_241, 1)));
    V v_t_245 = (g_heff_2ebuild_2eproject_2equoted(heff_get_n(v_x_241, 2, 3)));
    V v_t_246 = heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_str0), heff_strAppend(v_t_243, heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_str1), heff_strAppend(v_t_244, heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_str2), heff_strAppend(v_t_245, ((V)&g_list_2emap_24s1381986540x1952410492_str3)))))));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s1381986540x1952410492(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1381986540x1952410492_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1381986540x1952410492(a[0]);
}
HEFF_LIT(g_list_2emap_24s404123879x745642248_str0, 9, "{ name = ");
HEFF_LIT(g_list_2emap_24s404123879x745642248_str1, 8, ", dir = ");
HEFF_LIT(g_list_2emap_24s404123879x745642248_str2, 2, " }");
Clo g_list_2emap_24s404123879x745642248_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s404123879x745642248_entry, 1, 0};

V g_list_2emap_24s404123879x745642248(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2eproject_2equoted(heff_take_field(v_x_241, 0)));
    V v_t_244 = (g_heff_2ebuild_2eproject_2equoted(heff_get_n(v_x_241, 1, 2)));
    V v_t_245 = heff_strAppend(((V)&g_list_2emap_24s404123879x745642248_str0), heff_strAppend(v_t_243, heff_strAppend(((V)&g_list_2emap_24s404123879x745642248_str1), heff_strAppend(v_t_244, ((V)&g_list_2emap_24s404123879x745642248_str2)))));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s404123879x745642248(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s404123879x745642248_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s404123879x745642248(a[0]);
}
Clo g_list_2emap_24s871082722x1690249882_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s871082722x1690249882_entry, 1, 0};

V g_list_2emap_24s871082722x1690249882(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_x_241, 0)), heff_get_n(v_x_241, 1, 3)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s871082722x1690249882(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s871082722x1690249882_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s871082722x1690249882(a[0]);
}
Clo g_list_2efoldl_24s9956384x694087549_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s9956384x694087549_entry, 2, 0};

V g_list_2efoldl_24s9956384x694087549(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_z_240, 0)))) {
      V v_a_245 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(heff_rfield(v_x_242, 1))));
      V v_t_247;
      switch (heff_tag_of(v_a_245)) {
      case TAG_Nothing: {
        v_t_247 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_a_246 = heff_field(v_a_245, 0);
        heff_take_n(v_a_245, 1ULL, 1);
        v_t_247 = v_a_246;
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      V v_a_248 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(heff_rfield(v_z_240, 1))));
      V v_t_2410;
      switch (heff_tag_of(v_a_248)) {
      case TAG_Nothing: {
        v_t_2410 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_a_249 = heff_field(v_a_248, 0);
        heff_take_n(v_a_248, 1ULL, 1);
        v_t_2410 = v_a_249;
        break;
      }
      default: heff_nomatch(v_a_248);
      }
      V v_t_2411 = ({ V a_0 = v_t_247; V a_1 = v_t_2410; V r_ = (g_heff_2ebuild_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_247); heff_drop(v_t_2410); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop_rec(v_z_240, 3);
        v_t_2412 = heff_dup(v_x_242);
        break;
      }
      case TAG_False: {
        v_t_2412 = v_z_240;
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
    } else {
      v_t_2412 = v_z_240;
    }
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s9956384x694087549_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s9956384x694087549(a[0], a1); heff_drop(a1); return r;
}
V g_list_2efoldl_24s230517345x1163337657_lam0(V self, V *args);
Clo g_list_2efoldl_24s230517345x1163337657_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s230517345x1163337657_entry, 2, 0};

V g_list_2efoldl_24s230517345x1163337657(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = (g_list_2eany(heff_clo_n(g_list_2efoldl_24s230517345x1163337657_lam0, 1, 1, (V[]){heff_dup(v_x_242)}), v_z_240));
    V v_t_247;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_247 = v_z_240;
      break;
    }
    case TAG_False: {
      V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
      v_t_247 = (g_prelude_2e_2b_2b(v_z_240, v_t_246));
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s230517345x1163337657_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s230517345x1163337657(a[0], a[1]);
}
V g_list_2efoldl_24s230517345x1163337657_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_a_244, 0, 3), heff_get_n(v_x_242, 0, 3));
}
HEFF_LIT(g_list_2emap_24s1462590149x1582455373_str0, 3, ".hf");
Clo g_list_2emap_24s1462590149x1582455373_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1462590149x1582455373_entry, 1, 0};

V g_list_2emap_24s1462590149x1582455373(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_x_241)), MK_INT(3LL));
    V v_t_244 = heff_strSlice(heff_dup(v_x_241), v_t_243, heff_strLength(heff_dup(v_x_241)));
    V v_t_247;
    if (heff_strEq_c(v_t_244, ((V)&g_list_2emap_24s1462590149x1582455373_str0))) {
      V v_t_246 = heff_intSub(heff_strLength(heff_dup(v_x_241)), MK_INT(3LL));
      v_t_247 = heff_strSlice(v_x_241, MK_INT(0LL), v_t_246);
    } else {
      v_t_247 = v_x_241;
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_list_2emap_24s1462590149x1582455373(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1462590149x1582455373(a[0]);
}
Clo g_list_2emap_24s201309086x301344224_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s201309086x301344224_entry, 1, 0};

V g_list_2emap_24s201309086x301344224(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), (g_list_2emap_24s201309086x301344224(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s201309086x301344224_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s201309086x301344224(a[0]);
}
Clo g_list_2emap_24s1900047848x1273517071_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1900047848x1273517071_entry, 1, 0};

V g_list_2emap_24s1900047848x1273517071(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), (g_list_2emap_24s1900047848x1273517071(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1900047848x1273517071_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1900047848x1273517071(a[0]);
}
Clo g_list_2efoldl_24s2031248677x950202423_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2031248677x950202423_entry, 2, 0};

V g_list_2efoldl_24s2031248677x950202423(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2elocals_2epatternBinders(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2031248677x950202423(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s478414341x1543613922_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s478414341x1543613922_entry, 2, 0};

V g_list_2efoldl_24s478414341x1543613922(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkFieldPat: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eelab_2elocals_2epatternBinders(heff_dup(v_a_245)));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s478414341x1543613922(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1397104144x44544585_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1397104144x44544585_entry, 1, 0};

V g_list_2emap_24s1397104144x44544585(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 2), (g_list_2emap_24s1397104144x44544585(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1397104144x44544585_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1397104144x44544585(a[0]);
}
Clo g_list_2efilter_24s1765650963x934927761_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1765650963x934927761_entry, 1, 0};

V g_list_2efilter_24s1765650963x934927761(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 2));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop_rec(v_x_241, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1765650963x934927761(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1765650963x934927761_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1765650963x934927761(a[0]);
}
Clo g_list_2emap_24s405944583x1077136121_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s405944583x1077136121_entry, 1, 0};

V g_list_2emap_24s405944583x1077136121(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 0)), 0, 3);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_241, 0)), 1, 3);
    V v_t_245 = heff_rec_n(3, shape_name__field__use, (V[]){v_t_243, v_t_244, heff_get_n(v_x_241, 1, 2)});
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s405944583x1077136121(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s405944583x1077136121_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s405944583x1077136121(a[0]);
}
Clo g_list_2efilter_24s1923635572x1866981478_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1923635572x1866981478_entry, 1, 0};

V g_list_2efilter_24s1923635572x1866981478(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 0)), 2, 3);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1923635572x1866981478(v_xs_242))});
    }
    case TAG_False: {
      heff_drop_rec(v_x_241, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1923635572x1866981478_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1923635572x1866981478(a[0]);
}
Clo g_list_2efoldl_24s491023592x445693380_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s491023592x445693380_entry, 2, 0};

V g_list_2efoldl_24s491023592x445693380(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = (g_heff_2eelab_2elocals_2edeclaration(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(heff_take_field(v_z_240, 0), heff_take_field(v_a_244, 0)));
    V v_t_246 = (g_prelude_2e_2b_2b(heff_get_n(v_z_240, 1, 2), heff_get_n(v_a_244, 1, 2)));
    V t_0 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_245, v_t_246});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s491023592x445693380_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s491023592x445693380(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emerge_24s1795243648x793343406_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1795243648x793343406_entry, 2, 0};

V g_list_2emerge_24s1795243648x793343406(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 2);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_y_244, 0)))) {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s1795243648x793343406(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      } else {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s1795243648x793343406(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1795243648x793343406_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1795243648x793343406(a[0], a[1]);
}
Clo g_list_2esortBy_24s727161593x858225784_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s727161593x858225784_entry, 1, 0};

V g_list_2esortBy_24s727161593x858225784(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s727161593x858225784(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s727161593x858225784(v_t_2411));
      return (g_list_2emerge_24s1795243648x793343406(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s727161593x858225784_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s727161593x858225784(a[0]);
}
Clo g_list_2emerge_24s184369168x2028177428_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s184369168x2028177428_entry, 2, 0};

V g_list_2emerge_24s184369168x2028177428(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 5);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 1, 2);
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 0, 2);
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_y_244, 0)), 1, 2);
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_y_244, 0)), 0, 2);
      if (heff_intLe_c(heff_intSub(v_t_246, v_t_247), heff_intSub(v_t_248, v_t_249))) {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s184369168x2028177428(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      } else {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s184369168x2028177428(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s184369168x2028177428_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s184369168x2028177428(a[0], a[1]);
}
Clo g_list_2esortBy_24s45117555x207111745_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s45117555x207111745_entry, 1, 0};

V g_list_2esortBy_24s45117555x207111745(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s45117555x207111745(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s45117555x207111745(v_t_2411));
      return (g_list_2emerge_24s184369168x2028177428(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s45117555x207111745_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s45117555x207111745(a[0]);
}
Clo g_list_2emap_24s394088139x1521650250_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s394088139x1521650250_entry, 1, 0};

V g_list_2emap_24s394088139x1521650250(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_249 = (g_heff_2ebuild_2equery_2eprimitiveName(v_t_245, heff_get_n(v_t_248, 0, 4)));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_list_2emap_24s394088139x1521650250(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s394088139x1521650250_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s394088139x1521650250(a[0]);
}
Clo g_list_2emerge_24s1199840358x829708481_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1199840358x829708481_entry, 2, 0};

V g_list_2emerge_24s1199840358x829708481(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 2);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_strLt_c(heff_dup(heff_rfield(v_y_244, 0)), heff_dup(heff_rfield(v_x_242, 0)))) {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s1199840358x829708481(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      } else {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s1199840358x829708481(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1199840358x829708481_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1199840358x829708481(a[0], a[1]);
}
Clo g_list_2esortBy_24s231284928x1216253427_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s231284928x1216253427_entry, 1, 0};

V g_list_2esortBy_24s231284928x1216253427(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s231284928x1216253427(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s231284928x1216253427(v_t_2411));
      return (g_list_2emerge_24s1199840358x829708481(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s231284928x1216253427_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s231284928x1216253427(a[0]);
}
Clo g_list_2emap_24s173442543x1801751270_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s173442543x1801751270_entry, 1, 0};

V g_list_2emap_24s173442543x1801751270(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_TagVariant: {
        V v_t_245 = heff_field(v_x11_243, 0);
        V v_tsp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 3);
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_t_245, v_tsp_246})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_249 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_list_2emap_24s173442543x1801751270(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s173442543x1801751270_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s173442543x1801751270(a[0]);
}
Clo g_list_2emap_24s1675313341x192238134_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1675313341x192238134_entry, 1, 0};

V g_list_2emap_24s1675313341x192238134(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkEquation: {
        V v_fsp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 2ULL, 4);
        v_t_249 = v_fsp_246;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_list_2emap_24s1675313341x192238134(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1675313341x192238134_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1675313341x192238134(a[0]);
}
Clo g_list_2emap_24s2000102784x314586828_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2000102784x314586828_entry, 1, 0};

V g_list_2emap_24s2000102784x314586828(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclareField: {
        V v_x_245 = heff_field(v_x11_243, 0);
        V v_sp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 4);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_245, v_sp_246})});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_list_2emap_24s2000102784x314586828(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2000102784x314586828_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2000102784x314586828(a[0]);
}
Clo g_list_2emap_24s419146097x822538985_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s419146097x822538985_entry, 1, 0};

V g_list_2emap_24s419146097x822538985(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 2), (g_list_2emap_24s419146097x822538985(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s419146097x822538985_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s419146097x822538985(a[0]);
}
Clo g_list_2emap_24s53115558x1845817090_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s53115558x1845817090_entry, 1, 0};

V g_list_2emap_24s53115558x1845817090(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 3), (g_list_2emap_24s53115558x1845817090(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s53115558x1845817090_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s53115558x1845817090(a[0]);
}
Clo g_list_2emap_24s1784220752x1516752412_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1784220752x1516752412_entry, 1, 0};

V g_list_2emap_24s1784220752x1516752412(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 3), (g_list_2emap_24s1784220752x1516752412(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1784220752x1516752412_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1784220752x1516752412(a[0]);
}
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_str0, 5, "-- | ");
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_str1, 4, "-- |");
HEFF_LIT(g_list_2emap_24s1819241345x1511673126_str2, 0, "");
Clo g_list_2emap_24s1819241345x1511673126_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1819241345x1511673126_entry, 1, 0};

V g_list_2emap_24s1819241345x1511673126(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), MK_INT(5LL)), ((V)&g_list_2emap_24s1819241345x1511673126_str0))) {
      V v_t_244 = heff_strSlice(heff_dup(v_x_241), MK_INT(5LL), heff_strLength(v_x_241));
      v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    } else {
      if (heff_strEq_c(v_x_241, ((V)&g_list_2emap_24s1819241345x1511673126_str1))) {
        v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_list_2emap_24s1819241345x1511673126_str2)});
      } else {
        v_t_246 = NTAG(TAG_Nothing);
      }
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s1819241345x1511673126(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1819241345x1511673126(a[0]);
}
Clo g_list_2efoldl_24s1472875662x470242985_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1472875662x470242985_entry, 2, 0};

V g_list_2efoldl_24s1472875662x470242985(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2equery_2edocMdStep(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1472875662x470242985_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1472875662x470242985(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2024565375x57673182_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2024565375x57673182_entry, 3, 0};

V g_list_2efoldl_24s2024565375x57673182(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2426;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_DeclEquations: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_248 = heff_field(v_a_245, 1);
        heff_take_n(v_a_245, 3ULL, 4);
        v_t_2426 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__kind__span, (V[]){v_a_247, heff_dup(v_lit_240), v_a_248}), NTAG(TAG_Nil)});
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_a_245, 0ULL, 5);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2426 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_a_245, 0ULL, 4);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2426 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_a_245, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2426 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2426 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2426 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2427 = (g_prelude_2e_2b_2b(v_t_2426, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_2427;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s2024565375x57673182_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2024565375x57673182(a[0], a[1], a[2]);
}
Clo g_list_2efind_24s1364769258x905208224_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1364769258x905208224_entry, 1, 0};

V g_list_2efind_24s1364769258x905208224(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 0)), 1, 3);
    V v_a_245;
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      v_a_245 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_a_245 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    switch (heff_tag_of(v_a_245)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_241)});
    }
    default: return heff_nomatch(v_a_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efind_24s1364769258x905208224_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efind_24s1364769258x905208224(a0); heff_drop(a0); return r;
}
Clo g_list_2efilter_24s1951626341x2001490815_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1951626341x2001490815_entry, 1, 0};

V g_list_2efilter_24s1951626341x2001490815(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 0)), 1, 3);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x_241, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1951626341x2001490815(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1951626341x2001490815_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1951626341x2001490815(a[0]);
}
Clo g_list_2efoldl_24s2134067310x2049132013_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2134067310x2049132013_entry, 2, 0};

V g_list_2efoldl_24s2134067310x2049132013(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2134067310x2049132013(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1777318809x1106245647_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1777318809x1106245647_entry, 2, 0};

V g_list_2efoldl_24s1777318809x1106245647(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_DeclareField: {
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_248));
        V v_t_2412;
        switch (heff_tag_of(v_a_249)) {
        case TAG_Nothing: {
          v_t_2412 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_a_2411 = heff_field(v_a_249, 0);
          v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2411));
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        v_t_2414 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2412));
        break;
      }
      case TAG_BadFieldDecl: {
        V v_a_2413 = heff_field(v_a_244, 0);
        v_t_2414 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2413));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2414, v_z_240));
    V t_0 = v_t_2415;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1777318809x1106245647_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1777318809x1106245647(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s491084544x100802329_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s491084544x100802329_entry, 2, 0};

V g_list_2efoldl_24s491084544x100802329(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_248 = heff_field(v_a_244, 2);
        V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_a_248)));
        v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2134067310x2049132013(a_0, a_1)); heff_drop(v_t_249); r_; });
        break;
      }
      case TAG_BadVariant: {
        V v_a_2410 = heff_field(v_a_244, 0);
        v_t_2411 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2410));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2411, v_z_240));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s491084544x100802329(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s189033563x26633104_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s189033563x26633104_entry, 2, 0};

V g_list_2efoldl_24s189033563x26633104(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_248));
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_249 = heff_field(v_a_244, 0);
        v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_249));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s189033563x26633104_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s189033563x26633104(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s302194196x751324068_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s302194196x751324068_entry, 2, 0};

V g_list_2efoldl_24s302194196x751324068(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_247));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s302194196x751324068(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1620243413x998711352_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1620243413x998711352_entry, 2, 0};

V g_list_2efoldl_24s1620243413x998711352(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_StmtBind: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_248));
        break;
      }
      case TAG_StmtLet: {
        V v_a_2410 = heff_field(v_a_244, 1);
        v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2410));
        break;
      }
      case TAG_StmtExpr: {
        V v_a_2411 = heff_field(v_a_244, 0);
        v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2411));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1620243413x998711352_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1620243413x998711352(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s496727651x1448898893_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s496727651x1448898893_entry, 2, 0};

V g_list_2efoldl_24s496727651x1448898893(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkEquation: {
        V v_a_249 = heff_field(v_a_244, 3);
        v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_249));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s496727651x1448898893_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s496727651x1448898893(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1975553568x1034350329_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1975553568x1034350329_entry, 2, 0};

V g_list_2efoldl_24s1975553568x1034350329(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_ExplicitParam: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_248));
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2411 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2411));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1975553568x1034350329_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1975553568x1034350329(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s54159557x1528472185_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s54159557x1528472185_entry, 2, 0};

V g_list_2efoldl_24s54159557x1528472185(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s54159557x1528472185(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emerge_24s601132804x1969384800_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s601132804x1969384800_entry, 2, 0};

V g_list_2emerge_24s601132804x1969384800(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 5);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_y_244, 2)), 0, 2);
      if (heff_intLe_c(v_t_246, v_t_247)) {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s601132804x1969384800(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      } else {
        return heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s601132804x1969384800(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s601132804x1969384800_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s601132804x1969384800(a[0], a[1]);
}
Clo g_list_2esortBy_24s1802715880x492507304_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1802715880x492507304_entry, 1, 0};

V g_list_2esortBy_24s1802715880x492507304(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s1802715880x492507304(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s1802715880x492507304(v_t_2411));
      return (g_list_2emerge_24s601132804x1969384800(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1802715880x492507304_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1802715880x492507304(a[0]);
}
Clo g_list_2efilter_24s413142873x1263311264_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s413142873x1263311264_entry, 2, 0};

V g_list_2efilter_24s413142873x1263311264(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2efilter_24s413142873x1263311264(v_lit_240, v_xs_243))});
    } else {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s413142873x1263311264_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s413142873x1263311264(a[0], a[1]);
}
Clo g_list_2efoldl_24s571074576x1179600767_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s571074576x1179600767_entry, 2, 0};

V g_list_2efoldl_24s571074576x1179600767(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_dup(heff_rfield(v_z_240, 1))});
    V v_t_245 = ({ V rv_1 = v_t_244; V rr_ = heff_rec_reuse_n(v_z_240, 29ULL, 5, shape_sources__errors__paths__package__packages); heff_rfield(rr_, 1) = rv_1; rr_; });
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s571074576x1179600767(a[0], a[1]);
}
Clo g_list_2eany_24s976871491x582277361_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s976871491x582277361_entry, 1, 0};

V g_list_2eany_24s976871491x582277361(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_243 = (g_list_2efilter_24s835571418x868029304(heff_dup(heff_rfield(v_x_241, 6))));
    V v_a_246;
    switch (heff_tag_of(v_a_243)) {
    case TAG_Nil: {
      v_a_246 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_a_243, 0ULL, 2);
      v_a_246 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    switch (heff_tag_of(v_a_246)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_a_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s976871491x582277361_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s976871491x582277361(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1288527083x146849530_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1288527083x146849530_entry, 1, 0};

V g_list_2emap_24s1288527083x146849530(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V rr_ = heff_rec_reuse_n(v_x_241, 3ULL, 2, shape_name__key); rr_; });
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1288527083x146849530(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1288527083x146849530_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1288527083x146849530(a[0]);
}
Clo g_list_2emap_24s570241860x1995261629_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s570241860x1995261629_entry, 1, 0};

V g_list_2emap_24s570241860x1995261629(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_x_241, 0)), heff_get_n(v_x_241, 1, 2)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s570241860x1995261629(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s570241860x1995261629_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s570241860x1995261629(a[0]);
}
Clo g_list_2emap_24s1416288597x2006619516_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1416288597x2006619516_entry, 1, 0};

V g_list_2emap_24s1416288597x2006619516(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 13), (g_list_2emap_24s1416288597x2006619516(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1416288597x2006619516_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1416288597x2006619516(a[0]);
}
Clo g_list_2efilter_24s1966237873x2134891024_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1966237873x2134891024_entry, 3, 0};

V g_list_2efilter_24s1966237873x2134891024(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_intSub(heff_strLength(heff_dup(v_x_243)), heff_strLength(heff_dup(v_lit_240)));
    V v_t_246 = heff_strSlice(heff_dup(v_x_243), v_t_245, heff_strLength(heff_dup(v_x_243)));
    if (heff_strEq_c(v_t_246, heff_dup(v_lit_241))) {
      return heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_list_2efilter_24s1966237873x2134891024(v_lit_240, v_lit_241, v_xs_244))});
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24s1966237873x2134891024_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1966237873x2134891024(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s620173997x1959585086_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s620173997x1959585086_entry, 2, 0};

V g_list_2efoldl_24s620173997x1959585086(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 1)), 2, 3);
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s620173997x1959585086_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s620173997x1959585086(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s844754919x2100408598_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s844754919x2100408598_entry, 4, 0};

V g_list_2efoldl_24s844754919x2100408598(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_a_246 = (g_list_2efilter_24s835571418x868029304(heff_dup(heff_rfield(v_x_244, 6))));
    V v_t_247 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_a_246; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_a_246); r_; });
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_intAdd(v_z_242, v_t_247);
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s844754919x2100408598_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24s844754919x2100408598(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efilter_24s34002769x154977349_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s34002769x154977349_entry, 1, 0};

V g_list_2efilter_24s34002769x154977349(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 2)), 6, 10);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop_rec(v_x_241, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s34002769x154977349(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s34002769x154977349_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s34002769x154977349(a[0]);
}
Clo g_list_2efilter_24s1956506708x1796911658_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1956506708x1796911658_entry, 1, 0};

V g_list_2efilter_24s1956506708x1796911658(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop_rec(v_x_241, 10);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1956506708x1796911658(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1956506708x1796911658_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1956506708x1796911658(a[0]);
}
Clo g_list_2emap_24s1420651609x666245096_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1420651609x666245096_entry, 1, 0};

V g_list_2emap_24s1420651609x666245096(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_x_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1420651609x666245096(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1420651609x666245096(a[0]);
}
Clo g_list_2emap_24s914137198x2013970988_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s914137198x2013970988_entry, 6, 0};

V g_list_2emap_24s914137198x2013970988(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_a_2410;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_246, 0));
      v_a_2410 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_t_2411 = (g_heff_2eutil_2ejson_2eescapeGo(v_a_2410, heff_dup(v_lit_241), heff_dup(v_lit_242)));
    V v_t_2412 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
    V v_t_2415;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_246, 1);
      heff_take_n(v_x_246, 2ULL, 2);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_t_2416 = heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), ({ V a_0 = v_t_2415; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop(v_t_2415); r_; })));
    return heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2416, (g_list_2emap_24s914137198x2013970988(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247))});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s914137198x2013970988_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s914137198x2013970988(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s1533895818x411093629_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1533895818x411093629_entry, 1, 0};

V g_list_2emap_24s1533895818x411093629(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2edriver_2elean(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1533895818x411093629(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1533895818x411093629_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1533895818x411093629(a[0]);
}
Clo g_list_2emap_24s1120421688x983574011_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1120421688x983574011_entry, 1, 0};

V g_list_2emap_24s1120421688x983574011(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), (g_list_2emap_24s1120421688x983574011(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1120421688x983574011_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1120421688x983574011(a[0]);
}
Clo g_list_2emap_24s434052990x93204247_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s434052990x93204247_entry, 1, 0};

V g_list_2emap_24s434052990x93204247(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), (g_list_2emap_24s434052990x93204247(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s434052990x93204247_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s434052990x93204247(a[0]);
}
HEFF_LIT(g_list_2emap_24s4199228x1154005405_str0, 4, "kind");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_str1, 6, "detail");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_str2, 5, "label");
Clo g_list_2emap_24s4199228x1154005405_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s4199228x1154005405_entry, 1, 0};

V g_list_2emap_24s4199228x1154005405(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_x_241, 0)});
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_str0), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(3LL)})});
    V v_t_245 = heff_tag_n(TAG_JString, 1, (V[]){heff_get_n(v_x_241, 1, 2)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_str1), v_t_245}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_str2), v_t_243}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_247}), (g_list_2emap_24s4199228x1154005405(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s4199228x1154005405(a[0]);
}
Clo g_list_2efind_24s913819130x636901392_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s913819130x636901392_entry, 2, 0};

V g_list_2efind_24s913819130x636901392(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c(v_t_246, heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s913819130x636901392_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s913819130x636901392(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1733204117x1102777152_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1733204117x1102777152_entry, 1, 0};

V g_list_2emap_24s1733204117x1102777152(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 8), (g_list_2emap_24s1733204117x1102777152(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1733204117x1102777152_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1733204117x1102777152(a[0]);
}
Clo g_list_2emap_24s278643433x636689823_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s278643433x636689823_entry, 1, 0};

V g_list_2emap_24s278643433x636689823(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 8), (g_list_2emap_24s278643433x636689823(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s278643433x636689823_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s278643433x636689823(a[0]);
}
Clo g_list_2eany_24s1925868661x1054952755_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1925868661x1054952755_entry, 4, 0};

V g_list_2eany_24s1925868661x1054952755(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_strLength(heff_dup(heff_rfield(v_x_244, 1)));
    if (heff_intLt_c(heff_dup(v_lit_240), v_t_246)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      return NTAG(TAG_True);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_241))) {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        return NTAG(TAG_True);
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_242))) {
          heff_drop(v_lit_240);
          heff_drop(v_lit_241);
          heff_drop(v_lit_242);
          return NTAG(TAG_True);
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_lit_242;
          V t_3 = v_xs_245;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_lit_242 = t_2;
          v_x2_243 = t_3;
          goto top;
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s1925868661x1054952755_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2eany_24s1925868661x1054952755(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2eany_24s1225534391x2032069000_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1225534391x2032069000_entry, 6, 0};

V g_list_2eany_24s1225534391x2032069000(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      return NTAG(TAG_True);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 1)), heff_dup(v_lit_241))) {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        heff_drop(v_lit_243);
        heff_drop(v_lit_244);
        return NTAG(TAG_True);
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), heff_dup(v_lit_242))) {
          heff_drop(v_lit_240);
          heff_drop(v_lit_241);
          heff_drop(v_lit_242);
          heff_drop(v_lit_243);
          heff_drop(v_lit_244);
          return NTAG(TAG_True);
        } else {
          V v_t_2411 = (g_prelude_2eindexFrom(heff_dup(v_lit_243), heff_dup(heff_rfield(v_x_246, 0)), heff_dup(v_lit_244)));
          switch (heff_tag_of(v_t_2411)) {
          case TAG_Nothing: {
            V t_0 = v_lit_240;
            V t_1 = v_lit_241;
            V t_2 = v_lit_242;
            V t_3 = v_lit_243;
            V t_4 = v_lit_244;
            V t_5 = v_xs_247;
            v_lit_240 = t_0;
            v_lit_241 = t_1;
            v_lit_242 = t_2;
            v_lit_243 = t_3;
            v_lit_244 = t_4;
            v_x2_245 = t_5;
            goto top;
          }
          case TAG_Just: {
            heff_take_n(v_t_2411, 0ULL, 1);
            heff_drop(v_lit_240);
            heff_drop(v_lit_241);
            heff_drop(v_lit_242);
            heff_drop(v_lit_243);
            heff_drop(v_lit_244);
            return NTAG(TAG_True);
          }
          default: return heff_nomatch(v_t_2411);
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2eany_24s1225534391x2032069000_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_list_2eany_24s1225534391x2032069000(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
Clo g_list_2eany_24s851022240x390352190_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s851022240x390352190_entry, 2, 0};

V g_list_2eany_24s851022240x390352190(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 2)), heff_dup(v_lit_240))) {
      V v_t_245 = heff_dup(heff_rfield(v_x_242, 4));
      V v_a_248;
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nil: {
        v_a_248 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_245, 0ULL, 2);
        v_a_248 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      switch (heff_tag_of(v_a_248)) {
      case TAG_True: {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_lit_240);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_a_248);
      }
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s851022240x390352190_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s851022240x390352190(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s381963598x1143766061_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s381963598x1143766061_entry, 2, 0};

V g_list_2emap_24s381963598x1143766061(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_242, 0, 8));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s381963598x1143766061(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s381963598x1143766061_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s381963598x1143766061(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str0, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str1, 1, "]");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str2, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str3, 4, "...]");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str4, 3, "...");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str5, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_str6, 4, "...]");
Clo g_list_2emap_24s2029999044x514618413_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029999044x514618413_entry, 1, 0};

V g_list_2emap_24s2029999044x514618413(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_243 = heff_take_field(v_x_241, 0);
    V v_t_244 = heff_get_n(v_x_241, 1, 3);
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_One: {
      v_t_245 = v_m_243;
      break;
    }
    case TAG_Optional: {
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str0), heff_strAppend(v_m_243, ((V)&g_list_2emap_24s2029999044x514618413_str1)));
      break;
    }
    case TAG_Many: {
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str2), heff_strAppend(v_m_243, ((V)&g_list_2emap_24s2029999044x514618413_str3)));
      break;
    }
    case TAG_Some: {
      v_t_245 = heff_strAppend(v_m_243, ((V)&g_list_2emap_24s2029999044x514618413_str4));
      break;
    }
    case TAG_Rest: {
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str5), heff_strAppend(v_m_243, ((V)&g_list_2emap_24s2029999044x514618413_str6)));
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s2029999044x514618413(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029999044x514618413(a[0]);
}
Clo g_list_2emap_24s1281445768x1036802655_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1281445768x1036802655_entry, 1, 0};

V g_list_2emap_24s1281445768x1036802655(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eflagWord(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1281445768x1036802655(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1281445768x1036802655(a[0]);
}
Clo g_list_2emap_24s1548004359x911871967_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1548004359x911871967_entry, 1, 0};

V g_list_2emap_24s1548004359x911871967(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eheadOf(heff_dup(v_x_241)));
    V v_t_244 = (g_std_2ecli_2eline2(v_t_243, heff_get_n(v_x_241, 1, 4)));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s1548004359x911871967(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1548004359x911871967_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1548004359x911871967(a[0]);
}
Clo g_list_2efilter_24s645966254x607857854_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s645966254x607857854_entry, 1, 0};

V g_list_2efilter_24s645966254x607857854(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 2));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s645966254x607857854(v_xs_242))});
    }
    case TAG_False: {
      heff_drop_rec(v_x_241, 4);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s645966254x607857854_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s645966254x607857854(a[0]);
}
Clo g_list_2emap_24s1753874608x910016727_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1753874608x910016727_entry, 1, 0};

V g_list_2emap_24s1753874608x910016727(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eflagLine(v_x_241));
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1753874608x910016727(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1753874608x910016727(a[0]);
}
Clo g_list_2emap_24s1354894546x482665166_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1354894546x482665166_entry, 4, 0};

V g_list_2emap_24s1354894546x482665166(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_246 = heff_take_field(v_x_244, 0);
    V v_a_247 = heff_get_n(v_x_244, 1, 4);
    V v_t_249;
    if (heff_strEq_c(heff_dup(v_a_247), heff_dup(v_lit_240))) {
      heff_drop(v_a_247);
      v_t_249 = v_a_246;
    } else {
      v_t_249 = heff_strAppend(v_a_246, heff_strAppend(heff_dup(v_lit_241), v_a_247));
    }
    return heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_249, heff_dup(v_lit_242)), (g_list_2emap_24s1354894546x482665166(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1354894546x482665166_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1354894546x482665166(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s876522837x2005194065_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s876522837x2005194065_entry, 4, 0};

V g_list_2emap_24s876522837x2005194065(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_244, 0));
      v_a_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_a_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 2ULL, 2);
      v_a_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2413;
    if (heff_strEq_c(heff_dup(v_a_2411), heff_dup(v_lit_240))) {
      heff_drop(v_a_2411);
      v_t_2413 = v_a_248;
    } else {
      v_t_2413 = heff_strAppend(v_a_248, heff_strAppend(heff_dup(v_lit_241), v_a_2411));
    }
    return heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, heff_dup(v_lit_242)), (g_list_2emap_24s876522837x2005194065(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s876522837x2005194065_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s876522837x2005194065(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1230413390x1744519585_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230413390x1744519585_entry, 2, 0};

V g_list_2emap_24s1230413390x1744519585(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_242, heff_dup(v_lit_240)), (g_list_2emap_24s1230413390x1744519585(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1230413390x1744519585_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1230413390x1744519585(a[0], a[1]);
}
Clo g_list_2emap_24s117049731x163598814_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s117049731x163598814_entry, 1, 0};

V g_list_2emap_24s117049731x163598814(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), (g_list_2emap_24s117049731x163598814(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s117049731x163598814_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s117049731x163598814(a[0]);
}