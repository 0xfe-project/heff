// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_EProject 35489
#define TAG_ERecord 5518
#define TAG_ESpec 56652
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ImplicitParam 51130
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Large 60129
#define TAG_Many 40086
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_None 17785
#define TAG_Ok 9325
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_PAs 26446
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PSelf 48502
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_Rest 61983
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SGlobal 8650
#define TAG_SWarning 44190
#define TAG_SetField 47531
#define TAG_Small 51389
#define TAG_Some 35657
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define TAG_Text 56194
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VCons 11629
#define TAG_VErased 42634
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_above 293969847
#define LBL_alias 294261354
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_arg 306384
#define LBL_arity 294440695
#define LBL_assoc 294479919
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_build 295453320
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_detail 611917692
#define LBL_diags 296935042
#define LBL_dir 308999
#define LBL_doc 309170
#define LBL_el 9998
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectFrom 460383968
#define LBL_expectTo 956903013
#define LBL_field 298786068
#define LBL_first 298798794
#define LBL_fixed 298804110
#define LBL_fixities 357800079
#define LBL_global 704121550
#define LBL_groups 709681407
#define LBL_hash 9690581
#define LBL_holds 300818350
#define LBL_id 10114
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_js 10160
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_label 304085774
#define LBL_level 304224158
#define LBL_line 9817275
#define LBL_local 304503685
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_member 869372357
#define LBL_meta 9843404
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ok 10307
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_places 961367927
#define LBL_post 9942375
#define LBL_pre 320797
#define LBL_protos 967342774
#define LBL_renames 1324191545
#define LBL_severity 75955546
#define LBL_ships 310766033
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_sol 323594
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_tok 324554
#define LBL_ty 10476
#define LBL_use 325633
#define LBL_uses 10094739
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_version 583465758
#define LBL_watch 314261737
static uint32_t shape_arg__pre__post[] = {LBL_arg, LBL_pre, LBL_post};
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_id__assoc__ops[] = {LBL_id, LBL_assoc, LBL_ops};
static uint32_t shape_js__env[] = {LBL_js, LBL_env};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_local__global[] = {LBL_local, LBL_global};
static uint32_t shape_name__field__use[] = {LBL_name, LBL_field, LBL_use};
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_name__kind__span[] = {LBL_name, LBL_kind, LBL_span};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2earity_2earityOne(V, V);
V g_heff_2earity_2earityOne_entry(V self, V *a);
extern Clo g_heff_2earity_2earityOne_clo;
V g_heff_2eclauses_2erenamer(V, V);
V g_heff_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eclauses_2erenamer_clo;
V g_heff_2edriver_2eappendD(V, V);
V g_heff_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2edriver_2eappendD_clo;
V g_heff_2edriver_2eclosureGo(V, V, V);
V g_heff_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2edriver_2eclosureGo_clo;
V g_heff_2edriver_2eelabNeeding(V, V, V, V, V);
V g_heff_2edriver_2eelabNeeding_entry(V self, V *a);
extern Clo g_heff_2edriver_2eelabNeeding_clo;
V g_heff_2edriver_2eenvOne(V, V);
V g_heff_2edriver_2eenvOne_entry(V self, V *a);
extern Clo g_heff_2edriver_2eenvOne_clo;
V g_heff_2edriver_2eglueOne(V, V);
V g_heff_2edriver_2eglueOne_entry(V self, V *a);
extern Clo g_heff_2edriver_2eglueOne_clo;
V g_heff_2edriver_2ehint(V);
V g_heff_2edriver_2ehint_entry(V self, V *a);
extern Clo g_heff_2edriver_2ehint_clo;
V g_heff_2edriver_2elabelOfV(V);
V g_heff_2edriver_2elabelOfV_entry(V self, V *a);
extern Clo g_heff_2edriver_2elabelOfV_clo;
V g_heff_2edriver_2elean(V);
V g_heff_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2edriver_2elean_clo;
V g_heff_2edriver_2enubStrD(V);
V g_heff_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2edriver_2enubStrD_clo;
V g_heff_2edriver_2eoutcomeOfV(V);
V g_heff_2edriver_2eoutcomeOfV_entry(V self, V *a);
extern Clo g_heff_2edriver_2eoutcomeOfV_clo;
V g_heff_2edriver_2epromoteAt(V, V, V, V);
V g_heff_2edriver_2epromoteAt_entry(V self, V *a);
extern Clo g_heff_2edriver_2epromoteAt_clo;
V g_heff_2eeffect_2edropLastD(V);
V g_heff_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eeffect_2edropLastD_clo;
V g_heff_2eemit_2ebindName(V, V);
V g_heff_2eemit_2ebindName_entry(V self, V *a);
extern Clo g_heff_2eemit_2ebindName_clo;
V g_heff_2eemit_2eexportNameOf(V);
V g_heff_2eemit_2eexportNameOf_entry(V self, V *a);
extern Clo g_heff_2eemit_2eexportNameOf_clo;
V g_heff_2eemit_2ehostLineOf(V);
V g_heff_2eemit_2ehostLineOf_entry(V self, V *a);
extern Clo g_heff_2eemit_2ehostLineOf_clo;
V g_heff_2eemit_2elastDotFrom(V, V);
V g_heff_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2eemit_2elastDotFrom_clo;
V g_heff_2eemit_2eprimUses(V, V);
V g_heff_2eemit_2eprimUses_entry(V self, V *a);
extern Clo g_heff_2eemit_2eprimUses_clo;
V g_heff_2eemit_2esafeChars(V, V, V);
V g_heff_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2eemit_2esafeChars_clo;
V g_heff_2eemit_2esafeRes(V);
V g_heff_2eemit_2esafeRes_entry(V self, V *a);
extern Clo g_heff_2eemit_2esafeRes_clo;
V g_heff_2eemit_2espellAt(V, V);
V g_heff_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2eemit_2espellAt_clo;
V g_heff_2eemit_2etailApp(V);
V g_heff_2eemit_2etailApp_entry(V self, V *a);
extern Clo g_heff_2eemit_2etailApp_clo;
V g_heff_2eemit_2etailGlobals(V);
V g_heff_2eemit_2etailGlobals_entry(V self, V *a);
extern Clo g_heff_2eemit_2etailGlobals_clo;
V g_heff_2eemit_2etrampolineStr_get(void);
V g_heff_2eemit_2evalueRefs(V);
V g_heff_2eemit_2evalueRefs_entry(V self, V *a);
extern Clo g_heff_2eemit_2evalueRefs_clo;
V g_heff_2eemitc_2earityOne(V, V);
V g_heff_2eemitc_2earityOne_entry(V self, V *a);
extern Clo g_heff_2eemitc_2earityOne_clo;
V g_heff_2eemitc_2eborAll(V, V);
V g_heff_2eemitc_2eborAll_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eborAll_clo;
V g_heff_2eemitc_2eborDef(V, V);
V g_heff_2eemitc_2eborDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eborDef_clo;
V g_heff_2eemitc_2ebuildsSize(V, V);
V g_heff_2eemitc_2ebuildsSize_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ebuildsSize_clo;
V g_heff_2eemitc_2eelemS(V, V);
V g_heff_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eelemS_clo;
V g_heff_2eemitc_2efreeOf(V, V);
V g_heff_2eemitc_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2eemitc_2efreeOf_clo;
V g_heff_2eemitc_2eidentAt(V, V, V);
V g_heff_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eidentAt_clo;
V g_heff_2eemitc_2eknownTags_get(void);
V g_heff_2eemitc_2elastDotGo(V, V, V);
V g_heff_2eemitc_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2eemitc_2elastDotGo_clo;
V g_heff_2eemitc_2emangleW(V, V, V, V);
V g_heff_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2eemitc_2emangleW_clo;
V g_heff_2eemitc_2enamesInGo(V, V, V, V);
V g_heff_2eemitc_2enamesInGo_entry(V self, V *a);
extern Clo g_heff_2eemitc_2enamesInGo_clo;
V g_heff_2eemitc_2eprimCloDef(V);
V g_heff_2eemitc_2eprimCloDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eprimCloDef_clo;
V g_heff_2eemitc_2epubLine(V);
V g_heff_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2eemitc_2epubLine_clo;
V g_heff_2eemitc_2eshapeDef(V);
V g_heff_2eemitc_2eshapeDef_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eshapeDef_clo;
V g_heff_2eemitc_2etagsLbls(V);
V g_heff_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2eemitc_2etagsLbls_clo;
V g_heff_2efixed_2efloat32Ops_get(void);
V g_heff_2efixed_2eintOps_get(void);
V g_heff_2efixity_2eappendF(V, V);
V g_heff_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2efixity_2eappendF_clo;
V g_heff_2efixity_2enubByE(V);
V g_heff_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2efixity_2enubByE_clo;
V g_heff_2efixity_2enubByG(V);
V g_heff_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2efixity_2enubByG_clo;
V g_heff_2efixity_2ereserved_get(void);
V g_heff_2efmt_2eimports_2espacesOf(V);
V g_heff_2efmt_2eimports_2espacesOf_entry(V self, V *a);
extern Clo g_heff_2efmt_2eimports_2espacesOf_clo;
V g_heff_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2eformat_2epatKey(V);
V g_heff_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2eformat_2epatKey_clo;
V g_heff_2eimport_2eimplicitImports_get(void);
V g_heff_2eimport_2eimportsOf(V, V);
V g_heff_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2eimport_2eimportsOf_clo;
V g_heff_2eimport_2erenamed(V, V);
V g_heff_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2eimport_2erenamed_clo;
V g_heff_2eimport_2espaces(V);
V g_heff_2eimport_2espaces_entry(V self, V *a);
extern Clo g_heff_2eimport_2espaces_clo;
V g_heff_2einterp_2eshowValGo(V, V);
V g_heff_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2einterp_2eshowValGo_clo;
V g_heff_2eir_2efreshBindOne(V, V);
V g_heff_2eir_2efreshBindOne_entry(V self, V *a);
extern Clo g_heff_2eir_2efreshBindOne_clo;
V g_heff_2eir_2eglobalsGo(V);
V g_heff_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2eir_2eglobalsGo_clo;
V g_heff_2eir_2eisValue(V);
V g_heff_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2eir_2eisValue_clo;
V g_heff_2eir_2enubI(V);
V g_heff_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2eir_2enubI_clo;
V g_heff_2ejson_2eescapeGo(V, V, V);
V g_heff_2ejson_2eescapeGo_entry(V self, V *a);
extern Clo g_heff_2ejson_2eescapeGo_clo;
V g_heff_2ejson_2estringify(V);
V g_heff_2ejson_2estringify_entry(V self, V *a);
extern Clo g_heff_2ejson_2estringify_clo;
V g_heff_2elift_2eliftGo_24s104003089x2047780485(V, V, V);
V g_heff_2elift_2eliftGo_24s104003089x2047780485_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftGo_24s104003089x2047780485_clo;
V g_heff_2elocals_2edeclaration(V);
V g_heff_2elocals_2edeclaration_entry(V self, V *a);
extern Clo g_heff_2elocals_2edeclaration_clo;
V g_heff_2elocals_2epatternBinders(V);
V g_heff_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2elocals_2epatternBinders_clo;
V g_heff_2epresyntax_2ealtOf_24s1311504944x45681609(V);
V g_heff_2epresyntax_2ealtOf_24s1311504944x45681609_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2ealtOf_24s1311504944x45681609_clo;
V g_heff_2epresyntax_2eargOf_24s1825882790x1322352207(V);
V g_heff_2epresyntax_2eargOf_24s1825882790x1322352207_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eargOf_24s1825882790x1322352207_clo;
V g_heff_2epresyntax_2echkDe_24s1632343938x112901564(V, V);
V g_heff_2epresyntax_2echkDe_24s1632343938x112901564_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2echkDe_24s1632343938x112901564_clo;
V g_heff_2epresyntax_2echkNode_24s769858677x299167023(V);
V g_heff_2epresyntax_2echkNode_24s769858677x299167023_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2echkNode_24s769858677x299167023_clo;
V g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(V);
V g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823_clo;
V g_heff_2epresyntax_2edeclN_24s819476248x1348827013(V);
V g_heff_2epresyntax_2edeclN_24s819476248x1348827013_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2edeclN_24s819476248x1348827013_clo;
V g_heff_2epresyntax_2eequationOf_24s1475199660x271778313(V);
V g_heff_2epresyntax_2eequationOf_24s1475199660x271778313_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eequationOf_24s1475199660x271778313_clo;
V g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142(V);
V g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142_clo;
V g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488(V);
V g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488_clo;
V g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947(V);
V g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947_clo;
V g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648(V);
V g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648_clo;
V g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(V, V);
V g_heff_2epresyntax_2etypNom_24s2062588653x1022079868_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2etypNom_24s2062588653x1022079868_clo;
V g_heff_2epresyntax_2evariantOf_24s1987057975x582429604(V);
V g_heff_2epresyntax_2evariantOf_24s1987057975x582429604_entry(V self, V *a);
extern Clo g_heff_2epresyntax_2evariantOf_24s1987057975x582429604_clo;
V g_heff_2eprims_2efixedImpl(V);
V g_heff_2eprims_2efixedImpl_entry(V self, V *a);
extern Clo g_heff_2eprims_2efixedImpl_clo;
V g_heff_2eprint_2earmOf_24s139775371x1736504365(V);
V g_heff_2eprint_2earmOf_24s139775371x1736504365_entry(V self, V *a);
extern Clo g_heff_2eprint_2earmOf_24s139775371x1736504365_clo;
V g_heff_2eprint_2ecommaSep(V);
V g_heff_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eprint_2ecommaSep_clo;
V g_heff_2eprint_2eescFrom(V, V);
V g_heff_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eprint_2eescFrom_clo;
V g_heff_2eprint_2epr_get(void);
V g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(V);
V g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_entry(V self, V *a);
extern Clo g_heff_2eprint_2eshowTermF_24s1075694671x1846348221_clo;
V g_heff_2eprint_2eshowTypeF_24s1624445707x628038617(V);
V g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_entry(V self, V *a);
extern Clo g_heff_2eprint_2eshowTypeF_24s1624445707x628038617_clo;
V g_heff_2eproject_2enewerGo(V, V);
V g_heff_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2eproject_2enewerGo_clo;
V g_heff_2eproject_2equoted(V);
V g_heff_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2eproject_2equoted_clo;
V g_heff_2eproject_2esumBefore(V, V);
V g_heff_2eproject_2esumBefore_entry(V self, V *a);
extern Clo g_heff_2eproject_2esumBefore_clo;
V g_heff_2eproject_2eversion(V);
V g_heff_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2eproject_2eversion_clo;
V g_heff_2equery_2elocalDeclF_24s535437546x2025255677(V);
V g_heff_2equery_2elocalDeclF_24s535437546x2025255677_entry(V self, V *a);
extern Clo g_heff_2equery_2elocalDeclF_24s535437546x2025255677_clo;
V g_heff_2equery_2elocalTermF_24s1158823265x601317201(V);
V g_heff_2equery_2elocalTermF_24s1158823265x601317201_entry(V self, V *a);
extern Clo g_heff_2equery_2elocalTermF_24s1158823265x601317201_clo;
V g_heff_2erename_2eglobalsTermF_24s1917262683x63074516(V);
V g_heff_2erename_2eglobalsTermF_24s1917262683x63074516_entry(V self, V *a);
extern Clo g_heff_2erename_2eglobalsTermF_24s1917262683x63074516_clo;
V g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774(V);
V g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774_entry(V self, V *a);
extern Clo g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774_clo;
V g_heff_2esimplify_2eflat(V);
V g_heff_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eflat_clo;
V g_heff_2esimplify_2esgFlat(V, V, V);
V g_heff_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2esimplify_2esgFlat_clo;
V g_heff_2espec_2ebindOne(V, V);
V g_heff_2espec_2ebindOne_entry(V self, V *a);
extern Clo g_heff_2espec_2ebindOne_clo;
V g_heff_2espec_2ekeyGo(V, V);
V g_heff_2espec_2ekeyGo_entry(V self, V *a);
extern Clo g_heff_2espec_2ekeyGo_clo;
V g_heff_2esurface_2easNameE(V);
V g_heff_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esurface_2easNameE_clo;
V g_heff_2esurface_2eidentOf(V);
V g_heff_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esurface_2eidentOf_clo;
V g_heff_2etoplevel_2ethawOne(V, V);
V g_heff_2etoplevel_2ethawOne_entry(V self, V *a);
extern Clo g_heff_2etoplevel_2ethawOne_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s107199714x217634386(V, V, V);
V g_list_2eall_24s107199714x217634386_entry(V self, V *a);
extern Clo g_list_2eall_24s107199714x217634386_clo;
V g_list_2eall_24s1175244903x419753027(V);
V g_list_2eall_24s1175244903x419753027_entry(V self, V *a);
extern Clo g_list_2eall_24s1175244903x419753027_clo;
V g_list_2eall_24s1225041428x2030583288(V);
V g_list_2eall_24s1225041428x2030583288_entry(V self, V *a);
extern Clo g_list_2eall_24s1225041428x2030583288_clo;
V g_list_2eall_24s1821787051x863686734(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eall_24s1821787051x863686734_entry(V self, V *a);
extern Clo g_list_2eall_24s1821787051x863686734_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1231799341x1378938612(V, V);
V g_list_2eany_24s1231799341x1378938612_entry(V self, V *a);
extern Clo g_list_2eany_24s1231799341x1378938612_clo;
V g_list_2eany_24s141450647x925029990(V);
V g_list_2eany_24s141450647x925029990_entry(V self, V *a);
extern Clo g_list_2eany_24s141450647x925029990_clo;
V g_list_2eany_24s1438978125x414501573(V);
V g_list_2eany_24s1438978125x414501573_entry(V self, V *a);
extern Clo g_list_2eany_24s1438978125x414501573_clo;
V g_list_2eany_24s15435789x327987819(V);
V g_list_2eany_24s15435789x327987819_entry(V self, V *a);
extern Clo g_list_2eany_24s15435789x327987819_clo;
V g_list_2eany_24s1711990188x1947159119(V);
V g_list_2eany_24s1711990188x1947159119_entry(V self, V *a);
extern Clo g_list_2eany_24s1711990188x1947159119_clo;
V g_list_2eany_24s2049821274x1050838097(V);
V g_list_2eany_24s2049821274x1050838097_entry(V self, V *a);
extern Clo g_list_2eany_24s2049821274x1050838097_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2eany_24s303571641x1461404329(V);
V g_list_2eany_24s303571641x1461404329_entry(V self, V *a);
extern Clo g_list_2eany_24s303571641x1461404329_clo;
V g_list_2eany_24s664291608x697916754(V);
V g_list_2eany_24s664291608x697916754_entry(V self, V *a);
extern Clo g_list_2eany_24s664291608x697916754_clo;
V g_list_2eany_24s699824326x1365177236(V, V, V, V, V, V);
V g_list_2eany_24s699824326x1365177236_entry(V self, V *a);
extern Clo g_list_2eany_24s699824326x1365177236_clo;
V g_list_2eany_24s8708556x2121103388(V, V, V, V);
V g_list_2eany_24s8708556x2121103388_entry(V self, V *a);
extern Clo g_list_2eany_24s8708556x2121103388_clo;
V g_list_2eany_24s910662703x1730636603(V);
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a);
extern Clo g_list_2eany_24s910662703x1730636603_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1013516255x907593536(V);
V g_list_2efilter_24s1013516255x907593536_entry(V self, V *a);
extern Clo g_list_2efilter_24s1013516255x907593536_clo;
V g_list_2efilter_24s1032170133x1551961113(V);
V g_list_2efilter_24s1032170133x1551961113_entry(V self, V *a);
extern Clo g_list_2efilter_24s1032170133x1551961113_clo;
V g_list_2efilter_24s1412390516x2102311772(V);
V g_list_2efilter_24s1412390516x2102311772_entry(V self, V *a);
extern Clo g_list_2efilter_24s1412390516x2102311772_clo;
V g_list_2efilter_24s1477606187x944222946(V);
V g_list_2efilter_24s1477606187x944222946_entry(V self, V *a);
extern Clo g_list_2efilter_24s1477606187x944222946_clo;
V g_list_2efilter_24s1488835706x1708666848(V);
V g_list_2efilter_24s1488835706x1708666848_entry(V self, V *a);
extern Clo g_list_2efilter_24s1488835706x1708666848_clo;
V g_list_2efilter_24s1551648278x579137009(V);
V g_list_2efilter_24s1551648278x579137009_entry(V self, V *a);
extern Clo g_list_2efilter_24s1551648278x579137009_clo;
V g_list_2efilter_24s1966237873x2134891024(V, V, V);
V g_list_2efilter_24s1966237873x2134891024_entry(V self, V *a);
extern Clo g_list_2efilter_24s1966237873x2134891024_clo;
V g_list_2efilter_24s1985229710x1815452821(V);
V g_list_2efilter_24s1985229710x1815452821_entry(V self, V *a);
extern Clo g_list_2efilter_24s1985229710x1815452821_clo;
V g_list_2efilter_24s2048945121x1749617505(V, V);
V g_list_2efilter_24s2048945121x1749617505_entry(V self, V *a);
extern Clo g_list_2efilter_24s2048945121x1749617505_clo;
V g_list_2efilter_24s2056490818x625949248(V, V);
V g_list_2efilter_24s2056490818x625949248_entry(V self, V *a);
extern Clo g_list_2efilter_24s2056490818x625949248_clo;
V g_list_2efilter_24s314366508x59199896(V);
V g_list_2efilter_24s314366508x59199896_entry(V self, V *a);
extern Clo g_list_2efilter_24s314366508x59199896_clo;
V g_list_2efilter_24s328645370x374613117(V);
V g_list_2efilter_24s328645370x374613117_entry(V self, V *a);
extern Clo g_list_2efilter_24s328645370x374613117_clo;
V g_list_2efilter_24s352363709x250826586(V, V);
V g_list_2efilter_24s352363709x250826586_entry(V self, V *a);
extern Clo g_list_2efilter_24s352363709x250826586_clo;
V g_list_2efilter_24s413688307x112671032(V, V, V, V);
V g_list_2efilter_24s413688307x112671032_entry(V self, V *a);
extern Clo g_list_2efilter_24s413688307x112671032_clo;
V g_list_2efilter_24s446957238x1069456192(V, V, V, V);
V g_list_2efilter_24s446957238x1069456192_entry(V self, V *a);
extern Clo g_list_2efilter_24s446957238x1069456192_clo;
V g_list_2efilter_24s518854376x1845646382(V);
V g_list_2efilter_24s518854376x1845646382_entry(V self, V *a);
extern Clo g_list_2efilter_24s518854376x1845646382_clo;
V g_list_2efilter_24s581973887x894775069(V);
V g_list_2efilter_24s581973887x894775069_entry(V self, V *a);
extern Clo g_list_2efilter_24s581973887x894775069_clo;
V g_list_2efilter_24s787257770x404639529(V);
V g_list_2efilter_24s787257770x404639529_entry(V self, V *a);
extern Clo g_list_2efilter_24s787257770x404639529_clo;
V g_list_2efilter_24s792047172x367808768(V);
V g_list_2efilter_24s792047172x367808768_entry(V self, V *a);
extern Clo g_list_2efilter_24s792047172x367808768_clo;
V g_list_2efilter_24s926921591x156811372(V, V, V, V);
V g_list_2efilter_24s926921591x156811372_entry(V self, V *a);
extern Clo g_list_2efilter_24s926921591x156811372_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efind_24s2127599001x720452116(V);
V g_list_2efind_24s2127599001x720452116_entry(V self, V *a);
extern Clo g_list_2efind_24s2127599001x720452116_clo;
V g_list_2efind_24s913819130x636901392(V, V);
V g_list_2efind_24s913819130x636901392_entry(V self, V *a);
extern Clo g_list_2efind_24s913819130x636901392_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1009481344x1999114184(V, V);
V g_list_2efoldl_24s1009481344x1999114184_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1009481344x1999114184_clo;
V g_list_2efoldl_24s1092063785x854423403(V, V);
V g_list_2efoldl_24s1092063785x854423403_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1092063785x854423403_clo;
V g_list_2efoldl_24s1112037391x343083959(V, V, V, V);
V g_list_2efoldl_24s1112037391x343083959_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1112037391x343083959_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1127955551x950394381(V, V);
V g_list_2efoldl_24s1127955551x950394381_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1127955551x950394381_clo;
V g_list_2efoldl_24s114050048x1903860601(V, V);
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a);
extern Clo g_list_2efoldl_24s114050048x1903860601_clo;
V g_list_2efoldl_24s1182805385x625192302(V, V);
V g_list_2efoldl_24s1182805385x625192302_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1182805385x625192302_clo;
V g_list_2efoldl_24s1184002650x1359070118(V, V);
V g_list_2efoldl_24s1184002650x1359070118_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1184002650x1359070118_clo;
V g_list_2efoldl_24s1187012699x1099443358(V, V);
V g_list_2efoldl_24s1187012699x1099443358_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1187012699x1099443358_clo;
V g_list_2efoldl_24s1193656352x574625876(V, V);
V g_list_2efoldl_24s1193656352x574625876_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1193656352x574625876_clo;
V g_list_2efoldl_24s1202969196x1354597937(V, V);
V g_list_2efoldl_24s1202969196x1354597937_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1202969196x1354597937_clo;
V g_list_2efoldl_24s122245128x1667515165(V, V);
V g_list_2efoldl_24s122245128x1667515165_entry(V self, V *a);
extern Clo g_list_2efoldl_24s122245128x1667515165_clo;
V g_list_2efoldl_24s1259922006x559759121(V, V);
V g_list_2efoldl_24s1259922006x559759121_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1259922006x559759121_clo;
V g_list_2efoldl_24s1313979667x1986692492(V, V);
V g_list_2efoldl_24s1313979667x1986692492_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1313979667x1986692492_clo;
V g_list_2efoldl_24s132236332x1381264820(V, V);
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a);
extern Clo g_list_2efoldl_24s132236332x1381264820_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1376308465x96441915(V, V);
V g_list_2efoldl_24s1376308465x96441915_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1376308465x96441915_clo;
V g_list_2efoldl_24s1388689313x1238506813(V, V);
V g_list_2efoldl_24s1388689313x1238506813_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1388689313x1238506813_clo;
V g_list_2efoldl_24s1393779768x1672249294(V, V);
V g_list_2efoldl_24s1393779768x1672249294_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1393779768x1672249294_clo;
V g_list_2efoldl_24s1403790318x1472055750(V, V, V);
V g_list_2efoldl_24s1403790318x1472055750_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1403790318x1472055750_clo;
V g_list_2efoldl_24s1415479944x2009929531(V, V, V);
V g_list_2efoldl_24s1415479944x2009929531_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1415479944x2009929531_clo;
V g_list_2efoldl_24s1499776652x169167135(V, V);
V g_list_2efoldl_24s1499776652x169167135_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1499776652x169167135_clo;
V g_list_2efoldl_24s1507142368x592417200(V, V);
V g_list_2efoldl_24s1507142368x592417200_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1507142368x592417200_clo;
V g_list_2efoldl_24s1530401830x609500251(V, V);
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530401830x609500251_clo;
V g_list_2efoldl_24s1537290326x1300290376(V, V);
V g_list_2efoldl_24s1537290326x1300290376_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1537290326x1300290376_clo;
V g_list_2efoldl_24s153737048x1104410749(V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s153737048x1104410749_entry(V self, V *a);
extern Clo g_list_2efoldl_24s153737048x1104410749_clo;
V g_list_2efoldl_24s1550111079x1462185085(V, V);
V g_list_2efoldl_24s1550111079x1462185085_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1550111079x1462185085_clo;
V g_list_2efoldl_24s158718066x589068864(V, V);
V g_list_2efoldl_24s158718066x589068864_entry(V self, V *a);
extern Clo g_list_2efoldl_24s158718066x589068864_clo;
V g_list_2efoldl_24s1590278025x237389125(V, V);
V g_list_2efoldl_24s1590278025x237389125_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1590278025x237389125_clo;
V g_list_2efoldl_24s160534628x909100549(V, V);
V g_list_2efoldl_24s160534628x909100549_entry(V self, V *a);
extern Clo g_list_2efoldl_24s160534628x909100549_clo;
V g_list_2efoldl_24s1618987991x843428997(V, V, V);
V g_list_2efoldl_24s1618987991x843428997_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1618987991x843428997_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1670799345x2002421308(V, V);
V g_list_2efoldl_24s1670799345x2002421308_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1670799345x2002421308_clo;
V g_list_2efoldl_24s1672632733x1500872851(V, V);
V g_list_2efoldl_24s1672632733x1500872851_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1672632733x1500872851_clo;
V g_list_2efoldl_24s1686199548x1740309507(V, V);
V g_list_2efoldl_24s1686199548x1740309507_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1686199548x1740309507_clo;
V g_list_2efoldl_24s1696234796x1855206942(V, V);
V g_list_2efoldl_24s1696234796x1855206942_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1696234796x1855206942_clo;
V g_list_2efoldl_24s1701682704x1534841280(V, V);
V g_list_2efoldl_24s1701682704x1534841280_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1701682704x1534841280_clo;
V g_list_2efoldl_24s1768561025x1024615304(V, V);
V g_list_2efoldl_24s1768561025x1024615304_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1768561025x1024615304_clo;
V g_list_2efoldl_24s1798985515x221942800(V, V);
V g_list_2efoldl_24s1798985515x221942800_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1798985515x221942800_clo;
V g_list_2efoldl_24s1801866615x1952232028(V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1801866615x1952232028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1801866615x1952232028_clo;
V g_list_2efoldl_24s1803604645x588057571(V, V);
V g_list_2efoldl_24s1803604645x588057571_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1803604645x588057571_clo;
V g_list_2efoldl_24s1808984284x920551775(V, V);
V g_list_2efoldl_24s1808984284x920551775_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1808984284x920551775_clo;
V g_list_2efoldl_24s1845550822x1006046555(V, V);
V g_list_2efoldl_24s1845550822x1006046555_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1845550822x1006046555_clo;
V g_list_2efoldl_24s1854884545x892082821(V, V);
V g_list_2efoldl_24s1854884545x892082821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1854884545x892082821_clo;
V g_list_2efoldl_24s1871125585x175648018(V, V);
V g_list_2efoldl_24s1871125585x175648018_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1871125585x175648018_clo;
V g_list_2efoldl_24s1875482002x8607380(V, V, V, V);
V g_list_2efoldl_24s1875482002x8607380_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1875482002x8607380_clo;
V g_list_2efoldl_24s1885051946x1524849902(V, V);
V g_list_2efoldl_24s1885051946x1524849902_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1885051946x1524849902_clo;
V g_list_2efoldl_24s1889728774x506508078(V, V);
V g_list_2efoldl_24s1889728774x506508078_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1889728774x506508078_clo;
V g_list_2efoldl_24s1940164053x1118096699(V, V, V, V, V);
V g_list_2efoldl_24s1940164053x1118096699_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1940164053x1118096699_clo;
V g_list_2efoldl_24s1948718100x381870663(V, V);
V g_list_2efoldl_24s1948718100x381870663_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1948718100x381870663_clo;
V g_list_2efoldl_24s1958541883x442288263(V, V);
V g_list_2efoldl_24s1958541883x442288263_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1958541883x442288263_clo;
V g_list_2efoldl_24s1978402334x1625948189(V, V);
V g_list_2efoldl_24s1978402334x1625948189_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1978402334x1625948189_clo;
V g_list_2efoldl_24s1984245835x1989432102(V, V);
V g_list_2efoldl_24s1984245835x1989432102_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1984245835x1989432102_clo;
V g_list_2efoldl_24s2020645692x239769631(V, V);
V g_list_2efoldl_24s2020645692x239769631_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2020645692x239769631_clo;
V g_list_2efoldl_24s2040448920x1981923787(V, V);
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2040448920x1981923787_clo;
V g_list_2efoldl_24s2042221365x352889312(V, V);
V g_list_2efoldl_24s2042221365x352889312_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2042221365x352889312_clo;
V g_list_2efoldl_24s2049334416x2039919674(V, V);
V g_list_2efoldl_24s2049334416x2039919674_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2049334416x2039919674_clo;
V g_list_2efoldl_24s2140388286x271582403(V, V);
V g_list_2efoldl_24s2140388286x271582403_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2140388286x271582403_clo;
V g_list_2efoldl_24s216488628x1112278107(V, V);
V g_list_2efoldl_24s216488628x1112278107_entry(V self, V *a);
extern Clo g_list_2efoldl_24s216488628x1112278107_clo;
V g_list_2efoldl_24s221185798x216232137(V, V);
V g_list_2efoldl_24s221185798x216232137_entry(V self, V *a);
extern Clo g_list_2efoldl_24s221185798x216232137_clo;
V g_list_2efoldl_24s243791521x1469186053(V, V);
V g_list_2efoldl_24s243791521x1469186053_entry(V self, V *a);
extern Clo g_list_2efoldl_24s243791521x1469186053_clo;
V g_list_2efoldl_24s25418915x1870962456(V, V);
V g_list_2efoldl_24s25418915x1870962456_entry(V self, V *a);
extern Clo g_list_2efoldl_24s25418915x1870962456_clo;
V g_list_2efoldl_24s264628968x955404565(V, V);
V g_list_2efoldl_24s264628968x955404565_entry(V self, V *a);
extern Clo g_list_2efoldl_24s264628968x955404565_clo;
V g_list_2efoldl_24s291440091x511951757(V, V);
V g_list_2efoldl_24s291440091x511951757_entry(V self, V *a);
extern Clo g_list_2efoldl_24s291440091x511951757_clo;
V g_list_2efoldl_24s337191029x991313305(V, V);
V g_list_2efoldl_24s337191029x991313305_entry(V self, V *a);
extern Clo g_list_2efoldl_24s337191029x991313305_clo;
V g_list_2efoldl_24s339301719x719980567(V, V);
V g_list_2efoldl_24s339301719x719980567_entry(V self, V *a);
extern Clo g_list_2efoldl_24s339301719x719980567_clo;
V g_list_2efoldl_24s340728100x227093504(V, V);
V g_list_2efoldl_24s340728100x227093504_entry(V self, V *a);
extern Clo g_list_2efoldl_24s340728100x227093504_clo;
V g_list_2efoldl_24s352779828x1056053810(V, V);
V g_list_2efoldl_24s352779828x1056053810_entry(V self, V *a);
extern Clo g_list_2efoldl_24s352779828x1056053810_clo;
V g_list_2efoldl_24s356415811x1271115937(V, V);
V g_list_2efoldl_24s356415811x1271115937_entry(V self, V *a);
extern Clo g_list_2efoldl_24s356415811x1271115937_clo;
V g_list_2efoldl_24s361191175x1417189158(V, V);
V g_list_2efoldl_24s361191175x1417189158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s361191175x1417189158_clo;
V g_list_2efoldl_24s361359697x457944167(V, V);
V g_list_2efoldl_24s361359697x457944167_entry(V self, V *a);
extern Clo g_list_2efoldl_24s361359697x457944167_clo;
V g_list_2efoldl_24s407249128x802036125(V, V);
V g_list_2efoldl_24s407249128x802036125_entry(V self, V *a);
extern Clo g_list_2efoldl_24s407249128x802036125_clo;
V g_list_2efoldl_24s495329560x2124268843(V, V);
V g_list_2efoldl_24s495329560x2124268843_entry(V self, V *a);
extern Clo g_list_2efoldl_24s495329560x2124268843_clo;
V g_list_2efoldl_24s501235026x755516560(V, V);
V g_list_2efoldl_24s501235026x755516560_entry(V self, V *a);
extern Clo g_list_2efoldl_24s501235026x755516560_clo;
V g_list_2efoldl_24s628776168x954682162(V, V);
V g_list_2efoldl_24s628776168x954682162_entry(V self, V *a);
extern Clo g_list_2efoldl_24s628776168x954682162_clo;
V g_list_2efoldl_24s635091757x1027446614(V, V);
V g_list_2efoldl_24s635091757x1027446614_entry(V self, V *a);
extern Clo g_list_2efoldl_24s635091757x1027446614_clo;
V g_list_2efoldl_24s638445529x932797857(V, V);
V g_list_2efoldl_24s638445529x932797857_entry(V self, V *a);
extern Clo g_list_2efoldl_24s638445529x932797857_clo;
V g_list_2efoldl_24s647105187x1503385827(V, V, V, V);
V g_list_2efoldl_24s647105187x1503385827_entry(V self, V *a);
extern Clo g_list_2efoldl_24s647105187x1503385827_clo;
V g_list_2efoldl_24s656114908x500828470(V, V, V);
V g_list_2efoldl_24s656114908x500828470_entry(V self, V *a);
extern Clo g_list_2efoldl_24s656114908x500828470_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s693515418x622271110(V, V);
V g_list_2efoldl_24s693515418x622271110_entry(V self, V *a);
extern Clo g_list_2efoldl_24s693515418x622271110_clo;
V g_list_2efoldl_24s741293892x1082420503(V, V);
V g_list_2efoldl_24s741293892x1082420503_entry(V self, V *a);
extern Clo g_list_2efoldl_24s741293892x1082420503_clo;
V g_list_2efoldl_24s775969440x1318400394(V, V, V);
V g_list_2efoldl_24s775969440x1318400394_entry(V self, V *a);
extern Clo g_list_2efoldl_24s775969440x1318400394_clo;
V g_list_2efoldl_24s85178867x1278479365(V, V, V, V, V);
V g_list_2efoldl_24s85178867x1278479365_entry(V self, V *a);
extern Clo g_list_2efoldl_24s85178867x1278479365_clo;
V g_list_2efoldl_24s895450532x1092988905(V, V);
V g_list_2efoldl_24s895450532x1092988905_entry(V self, V *a);
extern Clo g_list_2efoldl_24s895450532x1092988905_clo;
V g_list_2efoldl_24s906555454x1998445727(V, V);
V g_list_2efoldl_24s906555454x1998445727_entry(V self, V *a);
extern Clo g_list_2efoldl_24s906555454x1998445727_clo;
V g_list_2efoldl_24s955934086x410334961(V, V);
V g_list_2efoldl_24s955934086x410334961_entry(V self, V *a);
extern Clo g_list_2efoldl_24s955934086x410334961_clo;
V g_list_2efoldl_24s966961137x2098673946(V, V);
V g_list_2efoldl_24s966961137x2098673946_entry(V self, V *a);
extern Clo g_list_2efoldl_24s966961137x2098673946_clo;
V g_list_2elookupBy(V, V, V);
V g_list_2elookupBy_entry(V self, V *a);
extern Clo g_list_2elookupBy_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s100060928x1092394615(V);
V g_list_2emap_24s100060928x1092394615_entry(V self, V *a);
extern Clo g_list_2emap_24s100060928x1092394615_clo;
V g_list_2emap_24s1006477676x1816442814(V, V, V);
V g_list_2emap_24s1006477676x1816442814_entry(V self, V *a);
extern Clo g_list_2emap_24s1006477676x1816442814_clo;
V g_list_2emap_24s103707540x1926696396(V);
V g_list_2emap_24s103707540x1926696396_entry(V self, V *a);
extern Clo g_list_2emap_24s103707540x1926696396_clo;
V g_list_2emap_24s1039286686x792451646(V, V, V, V, V, V, V);
V g_list_2emap_24s1039286686x792451646_entry(V self, V *a);
extern Clo g_list_2emap_24s1039286686x792451646_clo;
V g_list_2emap_24s1050849012x1625930324(V);
V g_list_2emap_24s1050849012x1625930324_entry(V self, V *a);
extern Clo g_list_2emap_24s1050849012x1625930324_clo;
V g_list_2emap_24s1063020973x859787996(V);
V g_list_2emap_24s1063020973x859787996_entry(V self, V *a);
extern Clo g_list_2emap_24s1063020973x859787996_clo;
V g_list_2emap_24s1070305723x611506852(V, V);
V g_list_2emap_24s1070305723x611506852_entry(V self, V *a);
extern Clo g_list_2emap_24s1070305723x611506852_clo;
V g_list_2emap_24s1107296543x493652800(V, V, V, V, V, V, V);
V g_list_2emap_24s1107296543x493652800_entry(V self, V *a);
extern Clo g_list_2emap_24s1107296543x493652800_clo;
V g_list_2emap_24s1128256044x1808758821(V);
V g_list_2emap_24s1128256044x1808758821_entry(V self, V *a);
extern Clo g_list_2emap_24s1128256044x1808758821_clo;
V g_list_2emap_24s115901570x2012684568(V);
V g_list_2emap_24s115901570x2012684568_entry(V self, V *a);
extern Clo g_list_2emap_24s115901570x2012684568_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1176007509x671449441(V, V, V, V, V);
V g_list_2emap_24s1176007509x671449441_entry(V self, V *a);
extern Clo g_list_2emap_24s1176007509x671449441_clo;
V g_list_2emap_24s1199561713x637397077(V);
V g_list_2emap_24s1199561713x637397077_entry(V self, V *a);
extern Clo g_list_2emap_24s1199561713x637397077_clo;
V g_list_2emap_24s1201440454x1180037198(V);
V g_list_2emap_24s1201440454x1180037198_entry(V self, V *a);
extern Clo g_list_2emap_24s1201440454x1180037198_clo;
V g_list_2emap_24s1230413390x1744519585(V, V);
V g_list_2emap_24s1230413390x1744519585_entry(V self, V *a);
extern Clo g_list_2emap_24s1230413390x1744519585_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s1282605757x1399508316(V);
V g_list_2emap_24s1282605757x1399508316_entry(V self, V *a);
extern Clo g_list_2emap_24s1282605757x1399508316_clo;
V g_list_2emap_24s1300207191x1224487257(V);
V g_list_2emap_24s1300207191x1224487257_entry(V self, V *a);
extern Clo g_list_2emap_24s1300207191x1224487257_clo;
V g_list_2emap_24s1318342530x1153530785(V);
V g_list_2emap_24s1318342530x1153530785_entry(V self, V *a);
extern Clo g_list_2emap_24s1318342530x1153530785_clo;
V g_list_2emap_24s1328195927x21044528(V, V);
V g_list_2emap_24s1328195927x21044528_entry(V self, V *a);
extern Clo g_list_2emap_24s1328195927x21044528_clo;
V g_list_2emap_24s1339179958x587003135(V);
V g_list_2emap_24s1339179958x587003135_entry(V self, V *a);
extern Clo g_list_2emap_24s1339179958x587003135_clo;
V g_list_2emap_24s1363203549x1204645634(V);
V g_list_2emap_24s1363203549x1204645634_entry(V self, V *a);
extern Clo g_list_2emap_24s1363203549x1204645634_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2emap_24s1377907145x510226651(V);
V g_list_2emap_24s1377907145x510226651_entry(V self, V *a);
extern Clo g_list_2emap_24s1377907145x510226651_clo;
V g_list_2emap_24s1378753456x1787722089(V, V, V, V);
V g_list_2emap_24s1378753456x1787722089_entry(V self, V *a);
extern Clo g_list_2emap_24s1378753456x1787722089_clo;
V g_list_2emap_24s1395929658x2029872776(V);
V g_list_2emap_24s1395929658x2029872776_entry(V self, V *a);
extern Clo g_list_2emap_24s1395929658x2029872776_clo;
V g_list_2emap_24s1400303153x1892969832(V, V, V, V);
V g_list_2emap_24s1400303153x1892969832_entry(V self, V *a);
extern Clo g_list_2emap_24s1400303153x1892969832_clo;
V g_list_2emap_24s1405724801x1371482992(V, V);
V g_list_2emap_24s1405724801x1371482992_entry(V self, V *a);
extern Clo g_list_2emap_24s1405724801x1371482992_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s1445534224x744280941(V, V);
V g_list_2emap_24s1445534224x744280941_entry(V self, V *a);
extern Clo g_list_2emap_24s1445534224x744280941_clo;
V g_list_2emap_24s1486836708x2052186263(V, V, V, V, V, V, V);
V g_list_2emap_24s1486836708x2052186263_entry(V self, V *a);
extern Clo g_list_2emap_24s1486836708x2052186263_clo;
V g_list_2emap_24s1494416374x1091091471(V);
V g_list_2emap_24s1494416374x1091091471_entry(V self, V *a);
extern Clo g_list_2emap_24s1494416374x1091091471_clo;
V g_list_2emap_24s1502118967x1628699884(V);
V g_list_2emap_24s1502118967x1628699884_entry(V self, V *a);
extern Clo g_list_2emap_24s1502118967x1628699884_clo;
V g_list_2emap_24s1516017384x1249556640(V);
V g_list_2emap_24s1516017384x1249556640_entry(V self, V *a);
extern Clo g_list_2emap_24s1516017384x1249556640_clo;
V g_list_2emap_24s151602879x50155996(V);
V g_list_2emap_24s151602879x50155996_entry(V self, V *a);
extern Clo g_list_2emap_24s151602879x50155996_clo;
V g_list_2emap_24s1522647702x498321911(V);
V g_list_2emap_24s1522647702x498321911_entry(V self, V *a);
extern Clo g_list_2emap_24s1522647702x498321911_clo;
V g_list_2emap_24s1557660835x11088490(V);
V g_list_2emap_24s1557660835x11088490_entry(V self, V *a);
extern Clo g_list_2emap_24s1557660835x11088490_clo;
V g_list_2emap_24s1568304002x1464883775(V);
V g_list_2emap_24s1568304002x1464883775_entry(V self, V *a);
extern Clo g_list_2emap_24s1568304002x1464883775_clo;
V g_list_2emap_24s1573559022x513331157(V, V, V);
V g_list_2emap_24s1573559022x513331157_entry(V self, V *a);
extern Clo g_list_2emap_24s1573559022x513331157_clo;
V g_list_2emap_24s1579450514x1236398533(V);
V g_list_2emap_24s1579450514x1236398533_entry(V self, V *a);
extern Clo g_list_2emap_24s1579450514x1236398533_clo;
V g_list_2emap_24s1615664184x1715591303(V);
V g_list_2emap_24s1615664184x1715591303_entry(V self, V *a);
extern Clo g_list_2emap_24s1615664184x1715591303_clo;
V g_list_2emap_24s1653859898x762241412(V);
V g_list_2emap_24s1653859898x762241412_entry(V self, V *a);
extern Clo g_list_2emap_24s1653859898x762241412_clo;
V g_list_2emap_24s1654555371x977048649(V, V, V, V, V, V);
V g_list_2emap_24s1654555371x977048649_entry(V self, V *a);
extern Clo g_list_2emap_24s1654555371x977048649_clo;
V g_list_2emap_24s1666645564x937815737(V);
V g_list_2emap_24s1666645564x937815737_entry(V self, V *a);
extern Clo g_list_2emap_24s1666645564x937815737_clo;
V g_list_2emap_24s1674044852x1346586108(V);
V g_list_2emap_24s1674044852x1346586108_entry(V self, V *a);
extern Clo g_list_2emap_24s1674044852x1346586108_clo;
V g_list_2emap_24s1678842425x1782957403(V);
V g_list_2emap_24s1678842425x1782957403_entry(V self, V *a);
extern Clo g_list_2emap_24s1678842425x1782957403_clo;
V g_list_2emap_24s1707404317x571860793(V);
V g_list_2emap_24s1707404317x571860793_entry(V self, V *a);
extern Clo g_list_2emap_24s1707404317x571860793_clo;
V g_list_2emap_24s1709449575x435379565(V);
V g_list_2emap_24s1709449575x435379565_entry(V self, V *a);
extern Clo g_list_2emap_24s1709449575x435379565_clo;
V g_list_2emap_24s1711626084x463433445(V);
V g_list_2emap_24s1711626084x463433445_entry(V self, V *a);
extern Clo g_list_2emap_24s1711626084x463433445_clo;
V g_list_2emap_24s1720519248x238652889(V);
V g_list_2emap_24s1720519248x238652889_entry(V self, V *a);
extern Clo g_list_2emap_24s1720519248x238652889_clo;
V g_list_2emap_24s1731489230x1144208469(V);
V g_list_2emap_24s1731489230x1144208469_entry(V self, V *a);
extern Clo g_list_2emap_24s1731489230x1144208469_clo;
V g_list_2emap_24s1750409203x420789256(V);
V g_list_2emap_24s1750409203x420789256_entry(V self, V *a);
extern Clo g_list_2emap_24s1750409203x420789256_clo;
V g_list_2emap_24s1751623379x2107197849(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1751623379x2107197849_entry(V self, V *a);
extern Clo g_list_2emap_24s1751623379x2107197849_clo;
V g_list_2emap_24s1753874608x910016727(V);
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1812644305x1204862673(V);
V g_list_2emap_24s1812644305x1204862673_entry(V self, V *a);
extern Clo g_list_2emap_24s1812644305x1204862673_clo;
V g_list_2emap_24s1821466936x1723477761(V);
V g_list_2emap_24s1821466936x1723477761_entry(V self, V *a);
extern Clo g_list_2emap_24s1821466936x1723477761_clo;
V g_list_2emap_24s1826078263x1390195856(V);
V g_list_2emap_24s1826078263x1390195856_entry(V self, V *a);
extern Clo g_list_2emap_24s1826078263x1390195856_clo;
V g_list_2emap_24s1890391385x30945199(V);
V g_list_2emap_24s1890391385x30945199_entry(V self, V *a);
extern Clo g_list_2emap_24s1890391385x30945199_clo;
V g_list_2emap_24s1895883353x1446382196(V, V);
V g_list_2emap_24s1895883353x1446382196_entry(V self, V *a);
extern Clo g_list_2emap_24s1895883353x1446382196_clo;
V g_list_2emap_24s1896835896x1330972393(V, V, V, V);
V g_list_2emap_24s1896835896x1330972393_entry(V self, V *a);
extern Clo g_list_2emap_24s1896835896x1330972393_clo;
V g_list_2emap_24s1936495134x1065491338(V);
V g_list_2emap_24s1936495134x1065491338_entry(V self, V *a);
extern Clo g_list_2emap_24s1936495134x1065491338_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1953731716x1367196380(V);
V g_list_2emap_24s1953731716x1367196380_entry(V self, V *a);
extern Clo g_list_2emap_24s1953731716x1367196380_clo;
V g_list_2emap_24s1956448299x403813387(V);
V g_list_2emap_24s1956448299x403813387_entry(V self, V *a);
extern Clo g_list_2emap_24s1956448299x403813387_clo;
V g_list_2emap_24s1986592085x2028054718(V);
V g_list_2emap_24s1986592085x2028054718_entry(V self, V *a);
extern Clo g_list_2emap_24s1986592085x2028054718_clo;
V g_list_2emap_24s1990289043x1851991154(V);
V g_list_2emap_24s1990289043x1851991154_entry(V self, V *a);
extern Clo g_list_2emap_24s1990289043x1851991154_clo;
V g_list_2emap_24s1990717753x185449813(V);
V g_list_2emap_24s1990717753x185449813_entry(V self, V *a);
extern Clo g_list_2emap_24s1990717753x185449813_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_list_2emap_24s1999471019x1288081638(V, V, V, V, V, V, V);
V g_list_2emap_24s1999471019x1288081638_entry(V self, V *a);
extern Clo g_list_2emap_24s1999471019x1288081638_clo;
V g_list_2emap_24s2006210321x387008715(V);
V g_list_2emap_24s2006210321x387008715_entry(V self, V *a);
extern Clo g_list_2emap_24s2006210321x387008715_clo;
V g_list_2emap_24s2010528650x1583508341(V);
V g_list_2emap_24s2010528650x1583508341_entry(V self, V *a);
extern Clo g_list_2emap_24s2010528650x1583508341_clo;
V g_list_2emap_24s2011789418x1542377058(V);
V g_list_2emap_24s2011789418x1542377058_entry(V self, V *a);
extern Clo g_list_2emap_24s2011789418x1542377058_clo;
V g_list_2emap_24s2013411847x1567363783(V);
V g_list_2emap_24s2013411847x1567363783_entry(V self, V *a);
extern Clo g_list_2emap_24s2013411847x1567363783_clo;
V g_list_2emap_24s2029999044x514618413(V);
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_clo;
V g_list_2emap_24s2039214748x107984299(V);
V g_list_2emap_24s2039214748x107984299_entry(V self, V *a);
extern Clo g_list_2emap_24s2039214748x107984299_clo;
V g_list_2emap_24s2051540388x950525029(V);
V g_list_2emap_24s2051540388x950525029_entry(V self, V *a);
extern Clo g_list_2emap_24s2051540388x950525029_clo;
V g_list_2emap_24s2070860064x992136139(V);
V g_list_2emap_24s2070860064x992136139_entry(V self, V *a);
extern Clo g_list_2emap_24s2070860064x992136139_clo;
V g_list_2emap_24s2100141652x1420713717(V);
V g_list_2emap_24s2100141652x1420713717_entry(V self, V *a);
extern Clo g_list_2emap_24s2100141652x1420713717_clo;
V g_list_2emap_24s2103553821x564582624(V, V);
V g_list_2emap_24s2103553821x564582624_entry(V self, V *a);
extern Clo g_list_2emap_24s2103553821x564582624_clo;
V g_list_2emap_24s2108633891x219265853(V);
V g_list_2emap_24s2108633891x219265853_entry(V self, V *a);
extern Clo g_list_2emap_24s2108633891x219265853_clo;
V g_list_2emap_24s211047076x203275960(V, V, V, V);
V g_list_2emap_24s211047076x203275960_entry(V self, V *a);
extern Clo g_list_2emap_24s211047076x203275960_clo;
V g_list_2emap_24s2130760772x63857074(V);
V g_list_2emap_24s2130760772x63857074_entry(V self, V *a);
extern Clo g_list_2emap_24s2130760772x63857074_clo;
V g_list_2emap_24s2137530563x1198821735(V, V, V, V);
V g_list_2emap_24s2137530563x1198821735_entry(V self, V *a);
extern Clo g_list_2emap_24s2137530563x1198821735_clo;
V g_list_2emap_24s231476130x1974273190(V, V, V, V, V, V);
V g_list_2emap_24s231476130x1974273190_entry(V self, V *a);
extern Clo g_list_2emap_24s231476130x1974273190_clo;
V g_list_2emap_24s237468257x275222167(V);
V g_list_2emap_24s237468257x275222167_entry(V self, V *a);
extern Clo g_list_2emap_24s237468257x275222167_clo;
V g_list_2emap_24s242536205x1745537053(V);
V g_list_2emap_24s242536205x1745537053_entry(V self, V *a);
extern Clo g_list_2emap_24s242536205x1745537053_clo;
V g_list_2emap_24s278797158x626714787(V, V, V, V, V, V, V);
V g_list_2emap_24s278797158x626714787_entry(V self, V *a);
extern Clo g_list_2emap_24s278797158x626714787_clo;
V g_list_2emap_24s292465422x1926397249(V, V, V, V, V, V);
V g_list_2emap_24s292465422x1926397249_entry(V self, V *a);
extern Clo g_list_2emap_24s292465422x1926397249_clo;
V g_list_2emap_24s329401138x269902185(V);
V g_list_2emap_24s329401138x269902185_entry(V self, V *a);
extern Clo g_list_2emap_24s329401138x269902185_clo;
V g_list_2emap_24s340479869x2094246170(V);
V g_list_2emap_24s340479869x2094246170_entry(V self, V *a);
extern Clo g_list_2emap_24s340479869x2094246170_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s374365348x2042978339(V, V);
V g_list_2emap_24s374365348x2042978339_entry(V self, V *a);
extern Clo g_list_2emap_24s374365348x2042978339_clo;
V g_list_2emap_24s37757954x1077935016(V);
V g_list_2emap_24s37757954x1077935016_entry(V self, V *a);
extern Clo g_list_2emap_24s37757954x1077935016_clo;
V g_list_2emap_24s420379013x173468973(V);
V g_list_2emap_24s420379013x173468973_entry(V self, V *a);
extern Clo g_list_2emap_24s420379013x173468973_clo;
V g_list_2emap_24s422245392x621266857(V);
V g_list_2emap_24s422245392x621266857_entry(V self, V *a);
extern Clo g_list_2emap_24s422245392x621266857_clo;
V g_list_2emap_24s445281531x1187441763(V);
V g_list_2emap_24s445281531x1187441763_entry(V self, V *a);
extern Clo g_list_2emap_24s445281531x1187441763_clo;
V g_list_2emap_24s455042168x142217368(V, V, V, V, V, V, V);
V g_list_2emap_24s455042168x142217368_entry(V self, V *a);
extern Clo g_list_2emap_24s455042168x142217368_clo;
V g_list_2emap_24s46845351x1913259050(V);
V g_list_2emap_24s46845351x1913259050_entry(V self, V *a);
extern Clo g_list_2emap_24s46845351x1913259050_clo;
V g_list_2emap_24s471051852x543057245(V);
V g_list_2emap_24s471051852x543057245_entry(V self, V *a);
extern Clo g_list_2emap_24s471051852x543057245_clo;
V g_list_2emap_24s47431100x1937383650(V, V, V, V, V);
V g_list_2emap_24s47431100x1937383650_entry(V self, V *a);
extern Clo g_list_2emap_24s47431100x1937383650_clo;
V g_list_2emap_24s483092743x614910894(V);
V g_list_2emap_24s483092743x614910894_entry(V self, V *a);
extern Clo g_list_2emap_24s483092743x614910894_clo;
V g_list_2emap_24s499977176x606563528(V, V, V);
V g_list_2emap_24s499977176x606563528_entry(V self, V *a);
extern Clo g_list_2emap_24s499977176x606563528_clo;
V g_list_2emap_24s517793000x1987655475(V, V);
V g_list_2emap_24s517793000x1987655475_entry(V self, V *a);
extern Clo g_list_2emap_24s517793000x1987655475_clo;
V g_list_2emap_24s529928550x768238834(V);
V g_list_2emap_24s529928550x768238834_entry(V self, V *a);
extern Clo g_list_2emap_24s529928550x768238834_clo;
V g_list_2emap_24s530187580x1837272535(V);
V g_list_2emap_24s530187580x1837272535_entry(V self, V *a);
extern Clo g_list_2emap_24s530187580x1837272535_clo;
V g_list_2emap_24s546447922x1671206170(V, V);
V g_list_2emap_24s546447922x1671206170_entry(V self, V *a);
extern Clo g_list_2emap_24s546447922x1671206170_clo;
V g_list_2emap_24s565104239x2094869705(V);
V g_list_2emap_24s565104239x2094869705_entry(V self, V *a);
extern Clo g_list_2emap_24s565104239x2094869705_clo;
V g_list_2emap_24s56748846x104951169(V);
V g_list_2emap_24s56748846x104951169_entry(V self, V *a);
extern Clo g_list_2emap_24s56748846x104951169_clo;
V g_list_2emap_24s629204667x1319563393(V);
V g_list_2emap_24s629204667x1319563393_entry(V self, V *a);
extern Clo g_list_2emap_24s629204667x1319563393_clo;
V g_list_2emap_24s629291802x1492808929(V);
V g_list_2emap_24s629291802x1492808929_entry(V self, V *a);
extern Clo g_list_2emap_24s629291802x1492808929_clo;
V g_list_2emap_24s638199897x1254231767(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s638199897x1254231767_entry(V self, V *a);
extern Clo g_list_2emap_24s638199897x1254231767_clo;
V g_list_2emap_24s639165353x1158789933(V);
V g_list_2emap_24s639165353x1158789933_entry(V self, V *a);
extern Clo g_list_2emap_24s639165353x1158789933_clo;
V g_list_2emap_24s673260838x1534389301(V, V, V, V, V, V);
V g_list_2emap_24s673260838x1534389301_entry(V self, V *a);
extern Clo g_list_2emap_24s673260838x1534389301_clo;
V g_list_2emap_24s695437276x936974799(V);
V g_list_2emap_24s695437276x936974799_entry(V self, V *a);
extern Clo g_list_2emap_24s695437276x936974799_clo;
V g_list_2emap_24s716972220x498274748(V);
V g_list_2emap_24s716972220x498274748_entry(V self, V *a);
extern Clo g_list_2emap_24s716972220x498274748_clo;
V g_list_2emap_24s729285507x950715386(V);
V g_list_2emap_24s729285507x950715386_entry(V self, V *a);
extern Clo g_list_2emap_24s729285507x950715386_clo;
V g_list_2emap_24s73473062x206541869(V);
V g_list_2emap_24s73473062x206541869_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_clo;
V g_list_2emap_24s752136398x849307084(V, V, V);
V g_list_2emap_24s752136398x849307084_entry(V self, V *a);
extern Clo g_list_2emap_24s752136398x849307084_clo;
V g_list_2emap_24s759389655x1953947393(V);
V g_list_2emap_24s759389655x1953947393_entry(V self, V *a);
extern Clo g_list_2emap_24s759389655x1953947393_clo;
V g_list_2emap_24s759991793x2063474551(V);
V g_list_2emap_24s759991793x2063474551_entry(V self, V *a);
extern Clo g_list_2emap_24s759991793x2063474551_clo;
V g_list_2emap_24s769615621x481570027(V);
V g_list_2emap_24s769615621x481570027_entry(V self, V *a);
extern Clo g_list_2emap_24s769615621x481570027_clo;
V g_list_2emap_24s791123004x231442264(V, V);
V g_list_2emap_24s791123004x231442264_entry(V self, V *a);
extern Clo g_list_2emap_24s791123004x231442264_clo;
V g_list_2emap_24s832649871x524798512(V);
V g_list_2emap_24s832649871x524798512_entry(V self, V *a);
extern Clo g_list_2emap_24s832649871x524798512_clo;
V g_list_2emap_24s855006972x1903601780(V);
V g_list_2emap_24s855006972x1903601780_entry(V self, V *a);
extern Clo g_list_2emap_24s855006972x1903601780_clo;
V g_list_2emap_24s876522837x2005194065(V, V, V, V);
V g_list_2emap_24s876522837x2005194065_entry(V self, V *a);
extern Clo g_list_2emap_24s876522837x2005194065_clo;
V g_list_2emap_24s877811985x526414493(V);
V g_list_2emap_24s877811985x526414493_entry(V self, V *a);
extern Clo g_list_2emap_24s877811985x526414493_clo;
V g_list_2emap_24s894988921x1774367189(V);
V g_list_2emap_24s894988921x1774367189_entry(V self, V *a);
extern Clo g_list_2emap_24s894988921x1774367189_clo;
V g_list_2emap_24s935072664x1288339118(V);
V g_list_2emap_24s935072664x1288339118_entry(V self, V *a);
extern Clo g_list_2emap_24s935072664x1288339118_clo;
V g_list_2emap_24s936489142x1270771276(V);
V g_list_2emap_24s936489142x1270771276_entry(V self, V *a);
extern Clo g_list_2emap_24s936489142x1270771276_clo;
V g_list_2emap_24s942708720x1221319722(V, V, V, V, V, V, V, V);
V g_list_2emap_24s942708720x1221319722_entry(V self, V *a);
extern Clo g_list_2emap_24s942708720x1221319722_clo;
V g_list_2emap_24s961430293x1662461983(V);
V g_list_2emap_24s961430293x1662461983_entry(V self, V *a);
extern Clo g_list_2emap_24s961430293x1662461983_clo;
V g_list_2emap_24s97238482x188466296(V);
V g_list_2emap_24s97238482x188466296_entry(V self, V *a);
extern Clo g_list_2emap_24s97238482x188466296_clo;
V g_list_2emap_24s989117243x1797506341(V);
V g_list_2emap_24s989117243x1797506341_entry(V self, V *a);
extern Clo g_list_2emap_24s989117243x1797506341_clo;
V g_list_2emap_24s998052584x332015457(V);
V g_list_2emap_24s998052584x332015457_entry(V self, V *a);
extern Clo g_list_2emap_24s998052584x332015457_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emerge_24s1166706590x737431029(V, V);
V g_list_2emerge_24s1166706590x737431029_entry(V self, V *a);
extern Clo g_list_2emerge_24s1166706590x737431029_clo;
V g_list_2emerge_24s1191944780x1350694468(V, V);
V g_list_2emerge_24s1191944780x1350694468_entry(V self, V *a);
extern Clo g_list_2emerge_24s1191944780x1350694468_clo;
V g_list_2emerge_24s1292713123x1836632175(V, V);
V g_list_2emerge_24s1292713123x1836632175_entry(V self, V *a);
extern Clo g_list_2emerge_24s1292713123x1836632175_clo;
V g_list_2emerge_24s1426753428x241553373(V, V);
V g_list_2emerge_24s1426753428x241553373_entry(V self, V *a);
extern Clo g_list_2emerge_24s1426753428x241553373_clo;
V g_list_2emerge_24s1992744726x1360756089(V, V);
V g_list_2emerge_24s1992744726x1360756089_entry(V self, V *a);
extern Clo g_list_2emerge_24s1992744726x1360756089_clo;
V g_list_2emerge_24s241948340x1176187119(V, V);
V g_list_2emerge_24s241948340x1176187119_entry(V self, V *a);
extern Clo g_list_2emerge_24s241948340x1176187119_clo;
V g_list_2emerge_24s421658182x1352532226(V, V);
V g_list_2emerge_24s421658182x1352532226_entry(V self, V *a);
extern Clo g_list_2emerge_24s421658182x1352532226_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2esortBy(V, V);
V g_list_2esortBy_entry(V self, V *a);
extern Clo g_list_2esortBy_clo;
V g_list_2esortBy_24s1384104572x138718272(V);
V g_list_2esortBy_24s1384104572x138718272_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1384104572x138718272_clo;
V g_list_2esortBy_24s1807141477x2081348872(V);
V g_list_2esortBy_24s1807141477x2081348872_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1807141477x2081348872_clo;
V g_list_2esortBy_24s1813115913x1547761659(V);
V g_list_2esortBy_24s1813115913x1547761659_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1813115913x1547761659_clo;
V g_list_2esortBy_24s1843786193x1453001387(V);
V g_list_2esortBy_24s1843786193x1453001387_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1843786193x1453001387_clo;
V g_list_2esortBy_24s1946011436x1651136814(V);
V g_list_2esortBy_24s1946011436x1651136814_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1946011436x1651136814_clo;
V g_list_2esortBy_24s209720638x21662806(V);
V g_list_2esortBy_24s209720638x21662806_entry(V self, V *a);
extern Clo g_list_2esortBy_24s209720638x21662806_clo;
V g_list_2esortBy_24s33211212x1318186357(V);
V g_list_2esortBy_24s33211212x1318186357_entry(V self, V *a);
extern Clo g_list_2esortBy_24s33211212x1318186357_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s1610853704x1401907306(V, V, V);
V g_list_2ezipWith_24s1610853704x1401907306_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1610853704x1401907306_clo;
V g_list_2ezipWith_24s1814128165x1680687847(V, V, V, V, V);
V g_list_2ezipWith_24s1814128165x1680687847_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1814128165x1680687847_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s1947952772x1156675739(V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s1947952772x1156675739_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1947952772x1156675739_clo;
V g_list_2ezipWith_24s2075573643x1334977728(V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s2075573643x1334977728_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s2075573643x1334977728_clo;
V g_list_2ezipWith_24s259431397x671561817(V, V);
V g_list_2ezipWith_24s259431397x671561817_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s259431397x671561817_clo;
V g_list_2ezipWith_24s504224228x1938399024(V, V);
V g_list_2ezipWith_24s504224228x1938399024_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s504224228x1938399024_clo;
V g_list_2ezipWith_24s738847920x410598254(V, V);
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_clo;
V g_list_2ezipWith_24s896882142x1217494120(V, V, V);
V g_list_2ezipWith_24s896882142x1217494120_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s896882142x1217494120_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2ecli_2eflagLine(V);
V g_std_2ecli_2eflagLine_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagLine_clo;
V g_std_2ecli_2eflagWord(V);
V g_std_2ecli_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagWord_clo;
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ehardline_get(void);
Clo g_list_2emap_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_entry, 2, 0};

V g_list_2emap(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap(v_f_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_entry(V self, V *a) {
  (void)self;
  return g_list_2emap(a[0], a[1]);
}
Clo g_list_2efoldl_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_entry, 3, 0};

V g_list_2efoldl(V v_f_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(heff_apply(heff_dup(v_f_240), 2, (V[]){v_z_241, heff_dup(v_x_243)}));
    V t_0 = v_f_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_f_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_list_2efoldl_24s1370882877x364361272_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1370882877x364361272_entry, 2, 0};

V g_list_2efoldl_24s1370882877x364361272(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V t_0 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1370882877x364361272(a[0], a[1]);
}
Clo g_list_2efilter_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_entry, 2, 0};

V g_list_2efilter(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2efilter(v_p_240, v_xs_243))});
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter(a[0], a[1]);
}
Clo g_list_2efoldl_24s1116451536x2100070357_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1116451536x2100070357_entry, 3, 0};

V g_list_2efoldl_24s1116451536x2100070357(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x3_242, 1);
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1116451536x2100070357(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_list_2etake_clo = {{0x80000000u, K_CLO, 0}, g_list_2etake_entry, 2, 0};

V g_list_2etake(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2etake(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243))});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2etake_entry(V self, V *a) {
  (void)self;
  return g_list_2etake(a[0], a[1]);
}
Clo g_list_2edrop_clo = {{0x80000000u, K_CLO, 0}, g_list_2edrop_entry, 2, 0};

V g_list_2edrop(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2edrop_entry(V self, V *a) {
  (void)self;
  return g_list_2edrop(a[0], a[1]);
}
Clo g_list_2ezipWith_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_entry, 3, 0};

V g_list_2ezipWith(V v_f_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_ys_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_f_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_247 = heff_tr(heff_apply(heff_dup(v_f_240), 2, (V[]){v_x_243, v_y_245}));
      return heff_tag_at(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_list_2ezipWith(v_f_240, v_xs2_244, v_ys2_246))});
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2ezipWith_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith(a[0], a[1], a[2]);
}
Clo g_list_2eany_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_entry, 2, 0};

V g_list_2eany(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eany(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2eall_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_entry, 2, 0};

V g_list_2eall(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_p_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eall(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efind_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_entry, 2, 0};

V g_list_2efind(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efind(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2elookupBy_clo = {{0x80000000u, K_CLO, 0}, g_list_2elookupBy_entry, 3, 0};

V g_list_2elookupBy(V v_eq_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_eq_240);
    heff_drop(v_k_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_k_27_245 = heff_field(v_x31_243, 0);
      V v_v_246 = heff_field(v_x31_243, 1);
      V v_t_247 = heff_tr(heff_apply(heff_dup(v_eq_240), 2, (V[]){heff_dup(v_k_241), heff_dup(v_k_27_245)}));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_eq_240);
        heff_drop(v_k_241);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_v_246)});
      }
      case TAG_False: {
        V t_0 = v_eq_240;
        V t_1 = v_k_241;
        V t_2 = v_rest_244;
        v_eq_240 = t_0;
        v_k_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2elookupBy_entry(V self, V *a) {
  (void)self;
  V r = g_list_2elookupBy(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_list_2efoldl_24s114050048x1903860601_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s114050048x1903860601_entry, 2, 0};

V g_list_2efoldl_24s114050048x1903860601(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V t_0 = heff_intAdd(v_z_240, heff_dup(v_x_242));
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s114050048x1903860601(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2erange_clo = {{0x80000000u, K_CLO, 0}, g_list_2erange_entry, 2, 0};

V g_list_2erange(V v_a_240, V v_b_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_241), heff_dup(v_a_240))) {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    return NTAG(TAG_Nil);
  } else {
    return heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_a_240), (g_list_2erange(heff_intAdd(v_a_240, MK_INT(1LL)), v_b_241))});
  }
}
V g_list_2erange_entry(V self, V *a) {
  (void)self;
  return g_list_2erange(a[0], a[1]);
}
Clo g_list_2ereplicate_clo = {{0x80000000u, K_CLO, 0}, g_list_2ereplicate_entry, 2, 0};

V g_list_2ereplicate(V v_n_240, V v_x_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_x_241);
    return NTAG(TAG_Nil);
  } else {
    return heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_241), (g_list_2ereplicate(heff_intSub(v_n_240, MK_INT(1LL)), v_x_241))});
  }
}
V g_list_2ereplicate_entry(V self, V *a) {
  (void)self;
  return g_list_2ereplicate(a[0], a[1]);
}
Clo g_list_2emerge_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_entry, 3, 0};

V g_list_2emerge(V v_le_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      return v_xs_241;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      V v_ru_24ys_242_24Cons = heff_take_reuse_n(v_ys_242, 3ULL, 2);
      heff_drop_tag(v_xs_241, 2);
      V v_t_247 = heff_tr(heff_apply(heff_dup(v_le_240), 2, (V[]){heff_dup(v_x_243), heff_dup(v_y_245)}));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_list_2emerge(v_le_240, v_xs2_244, heff_tag(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_y_245, (g_list_2emerge(v_le_240, heff_tag(TAG_Cons, 2, (V[]){v_x_243, v_xs2_244}), v_ys2_246))});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2emerge_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge(a[0], a[1], a[2]);
}
Clo g_list_2esortBy_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_entry, 2, 0};

V g_list_2esortBy(V v_le_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_xs2_243)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop_tag(v_xs_241, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_243, 0ULL, 2);
      heff_drop(v_x_242);
      V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_247 = heff_intDiv(v_t_246, MK_INT(2LL));
      V v_t_248 = (g_list_2etake(v_t_247, heff_dup(v_xs_241)));
      V v_t_249 = (g_list_2esortBy(heff_dup(v_le_240), v_t_248));
      V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_2411 = heff_intDiv(v_t_2410, MK_INT(2LL));
      V v_t_2412 = (g_list_2edrop(v_t_2411, v_xs_241));
      V v_t_2413 = (g_list_2esortBy(heff_dup(v_le_240), v_t_2412));
      return (g_list_2emerge(v_le_240, v_t_249, v_t_2413));
    }
    default: return heff_nomatch(v_xs2_243);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2esortBy_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy(a[0], a[1]);
}
Clo g_list_2emap_24s1415906091x1371825187_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1415906091x1371825187_entry, 1, 0};

V g_list_2emap_24s1415906091x1371825187(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1415906091x1371825187(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1415906091x1371825187(a[0]);
}
Clo g_list_2emap_24s366344330x1145113647_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366344330x1145113647_entry, 1, 0};

V g_list_2emap_24s366344330x1145113647(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s366344330x1145113647(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366344330x1145113647(a[0]);
}
V g_list_2efoldl_24s1259922006x559759121_lam0(V self, V *args);
Clo g_list_2efoldl_24s1259922006x559759121_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1259922006x559759121_entry, 2, 0};

V g_list_2efoldl_24s1259922006x559759121(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244;
    switch (heff_tag_of(v_x_242)) {
    case TAG_I8: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_I16: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_I32: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_I64: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_U8: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_U16: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_U32: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_U64: {
      v_t_244 = heff_dup(g_heff_2efixed_2eintOps_get());
      break;
    }
    case TAG_F32: {
      v_t_244 = heff_dup(g_heff_2efixed_2efloat32Ops_get());
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_246 = (g_list_2emap(heff_clo(g_list_2efoldl_24s1259922006x559759121_lam0, 1, 1, (V[]){heff_dup(v_x_242)}), v_t_244));
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1259922006x559759121_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1259922006x559759121(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_list_2efoldl_24s1259922006x559759121_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_rec(2, shape_fixed__op, (V[]){v_x_242, v_a_245});
}
Clo g_list_2emap_24s1707404317x571860793_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1707404317x571860793_entry, 1, 0};

V g_list_2emap_24s1707404317x571860793(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_looser), (g_list_2emap_24s1707404317x571860793(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1707404317x571860793_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1707404317x571860793(a[0]);
}
Clo g_list_2efoldl_24s1499776652x169167135_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1499776652x169167135_entry, 2, 0};

V g_list_2efoldl_24s1499776652x169167135(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
    V v_t_245 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
    V v_t_246 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
    V v_t_247 = (g_heff_2eimport_2espaces(heff_intSub(v_t_245, v_t_246)));
    V v_t_248 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
    V v_t_249 = heff_strSlice(heff_dup(v_z_240), v_t_248, heff_strLength(heff_dup(v_z_240)));
    V v_t_2410 = heff_strAppend(heff_strSlice(v_z_240, MK_INT(0LL), v_t_244), heff_strAppend(v_t_247, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1499776652x169167135_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1499776652x169167135(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s1821466936x1723477761_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1821466936x1723477761_entry, 1, 0};

V g_list_2emap_24s1821466936x1723477761(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_name), (g_list_2emap_24s1821466936x1723477761(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1821466936x1723477761_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1821466936x1723477761(a[0]);
}
V g_list_2efoldl_24s158718066x589068864_lam0(V self, V *args);
Clo g_list_2efoldl_24s158718066x589068864_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s158718066x589068864_entry, 2, 0};

V g_list_2efoldl_24s158718066x589068864(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_245 = (g_list_2efilter(heff_clo(g_list_2efoldl_24s158718066x589068864_lam0, 1, 1, (V[]){heff_dup(v_x_242)}), heff_dup(g_heff_2eimport_2eimplicitImports_get())));
    V v_t_246 = (g_prelude_2e_2b_2b(v_t_245, v_z_240));
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s158718066x589068864_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s158718066x589068864(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_list_2efoldl_24s158718066x589068864_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_a_244, LBL_name), v_x_242);
}
V g_list_2efoldl_24s2049334416x2039919674_lam0(V self, V *args);
Clo g_list_2efoldl_24s2049334416x2039919674_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2049334416x2039919674_entry, 2, 0};

V g_list_2efoldl_24s2049334416x2039919674(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_clo(g_list_2efoldl_24s2049334416x2039919674_lam0, 1, 1, (V[]){v_x_242}), heff_get(heff_dup(v_z_240), LBL_local)});
    V v_t_246 = heff_rec(2, shape_local__global, (V[]){v_t_245, heff_get(v_z_240, LBL_global)});
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2049334416x2039919674_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2049334416x2039919674(a[0], a[1]);
}
V g_list_2efoldl_24s2049334416x2039919674_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_244);
  return heff_tag(TAG_Ok, 1, (V[]){v_x_242});
}
Clo g_list_2emap_24s1070305723x611506852_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1070305723x611506852_entry, 2, 0};

V g_list_2emap_24s1070305723x611506852(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      v_t_246 = heff_strAppend(v_a_244, heff_strAppend(heff_dup(v_lit_240), ({ V b_0 = NTAG(TAG_False); V a_1 = v_a_245; V r_ = (g_heff_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); heff_drop(v_a_245); r_; })));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s1070305723x611506852(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1070305723x611506852_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1070305723x611506852(a[0], a[1]);
}
Clo g_list_2emap_24s517793000x1987655475_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s517793000x1987655475_entry, 2, 0};

V g_list_2emap_24s517793000x1987655475(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_dup(v_lit_240), ({ V b_0 = NTAG(TAG_True); V a_1 = v_x_242; V r_ = (g_heff_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_242); r_; }));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s517793000x1987655475(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s517793000x1987655475_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s517793000x1987655475(a[0], a[1]);
}
Clo g_list_2emap_24s115901570x2012684568_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s115901570x2012684568_entry, 1, 0};

V g_list_2emap_24s115901570x2012684568(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_x_241; V r_ = (g_heff_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s115901570x2012684568(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s115901570x2012684568_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s115901570x2012684568(a[0]);
}
Clo g_list_2emap_24s471051852x543057245_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s471051852x543057245_entry, 1, 0};

V g_list_2emap_24s471051852x543057245(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2eargOf_24s1825882790x1322352207(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s471051852x543057245(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s471051852x543057245_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s471051852x543057245(a[0]);
}
Clo g_list_2emap_24s151602879x50155996_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s151602879x50155996_entry, 1, 0};

V g_list_2emap_24s151602879x50155996(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_x_241));
    V v_t_2413;
    switch (heff_tag_of(v_a_243)) {
    case TAG_IsInferable: {
      V v_a_244 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_247;
      switch (heff_tag_of(v_a_244)) {
      case TAG_At: {
        V v_a_246 = heff_dup(heff_field(v_a_244, 1));
        v_t_247 = v_a_246;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_CInf, 1, (V[]){v_a_244}), v_t_247});
      break;
    }
    case TAG_IsCheckable: {
      V v_a_248 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2413 = v_a_248;
      break;
    }
    case TAG_IsType: {
      V v_a_249 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_a_249)) {
      case TAG_At: {
        V v_a_2411 = heff_dup(heff_field(v_a_249, 1));
        v_t_2412 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_a_249);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_CType, 1, (V[]){v_a_249}), v_t_2412});
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2413, (g_list_2emap_24s151602879x50155996(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s151602879x50155996_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s151602879x50155996(a[0]);
}
Clo g_list_2emap_24s1720519248x238652889_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1720519248x238652889_entry, 1, 0};

V g_list_2emap_24s1720519248x238652889(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2efieldDeclOf_24s2049272031x2094854488(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1720519248x238652889(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1720519248x238652889_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1720519248x238652889(a[0]);
}
Clo g_list_2emap_24s2013411847x1567363783_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2013411847x1567363783_entry, 1, 0};

V g_list_2emap_24s2013411847x1567363783(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = (g_heff_2epresyntax_2eclassifyTermF_24s424495455x1038711823(v_x_241));
    V v_t_2413;
    switch (heff_tag_of(v_a_243)) {
    case TAG_IsInferable: {
      V v_a_244 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_247;
      switch (heff_tag_of(v_a_244)) {
      case TAG_At: {
        V v_a_246 = heff_dup(heff_field(v_a_244, 1));
        v_t_247 = v_a_246;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_TInf, 1, (V[]){v_a_244}), v_t_247});
      break;
    }
    case TAG_IsCheckable: {
      V v_a_248 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_a_248)) {
      case TAG_At: {
        V v_a_2410 = heff_dup(heff_field(v_a_248, 1));
        v_t_2411 = v_a_2410;
        break;
      }
      default: heff_nomatch(v_a_248);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_TChk, 1, (V[]){v_a_248}), v_t_2411});
      break;
    }
    case TAG_IsType: {
      V v_a_2412 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2413 = v_a_2412;
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2413, (g_list_2emap_24s2013411847x1567363783(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2013411847x1567363783_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2013411847x1567363783(a[0]);
}
Clo g_list_2emap_24s1522647702x498321911_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1522647702x498321911_entry, 1, 0};

V g_list_2emap_24s1522647702x498321911(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2evariantOf_24s1987057975x582429604(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1522647702x498321911(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1522647702x498321911_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1522647702x498321911(a[0]);
}
Clo g_list_2emap_24s1201440454x1180037198_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1201440454x1180037198_entry, 1, 0};

V g_list_2emap_24s1201440454x1180037198(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2efieldSetOf_24s1980909823x69898947(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1201440454x1180037198(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1201440454x1180037198_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1201440454x1180037198(a[0]);
}
Clo g_list_2emap_24s729285507x950715386_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s729285507x950715386_entry, 1, 0};

V g_list_2emap_24s729285507x950715386(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2ealtOf_24s1311504944x45681609(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s729285507x950715386(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s729285507x950715386_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s729285507x950715386(a[0]);
}
Clo g_list_2emap_24s1812644305x1204862673_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1812644305x1204862673_entry, 1, 0};

V g_list_2emap_24s1812644305x1204862673(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2eequationOf_24s1475199660x271778313(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1812644305x1204862673(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1812644305x1204862673_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1812644305x1204862673(a[0]);
}
Clo g_list_2emap_24s1050849012x1625930324_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1050849012x1625930324_entry, 1, 0};

V g_list_2emap_24s1050849012x1625930324(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2epresyntax_2eparamOf_24s1115423126x2093765648(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1050849012x1625930324(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1050849012x1625930324_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1050849012x1625930324(a[0]);
}
Clo g_list_2emap_24s97238482x188466296_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s97238482x188466296_entry, 1, 0};

V g_list_2emap_24s97238482x188466296(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_ArgExplicit: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24ArgExplicit = heff_take_reuse_n(v_a_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        V v_t_249;
        switch (heff_tag_of(v_a_245)) {
        case TAG_At: {
          V v_a_246 = heff_field(v_a_245, 0);
          V v_a_247 = heff_field(v_a_245, 1);
          heff_take_n(v_a_245, 3ULL, 2);
          V v_t_248 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_a_246));
          v_t_249 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_248, v_a_247});
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        v_t_2417 = heff_tag_at(v_ru_24a_243_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_249});
        break;
      }
      case TAG_ArgProject: {
        V v_a_2410 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24ArgProject = heff_take_reuse_n(v_a_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop_cell(v_ru_24x_241_24At, 2);
        v_t_2417 = heff_tag_at(v_ru_24a_243_24ArgProject, TAG_ArgProject, 1, (V[]){v_a_2410});
        break;
      }
      case TAG_ArgNamed: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_a_2412 = heff_field(v_a_243, 1);
        heff_take_n(v_a_243, 3ULL, 2);
        V v_t_2416;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          V v_t_2415 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_a_2413));
          v_t_2416 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2415, v_a_2414});
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2417 = heff_tag_at(v_ru_24x_241_24At, TAG_ArgNamed, 2, (V[]){v_a_2411, v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag(TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2418, (g_list_2emap_24s97238482x188466296(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s97238482x188466296_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s97238482x188466296(a[0]);
}
Clo g_list_2emap_24s759991793x2063474551_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s759991793x2063474551_entry, 1, 0};

V g_list_2emap_24s759991793x2063474551(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2epresyntax_2efieldDeclN_24s28815368x1200642142(v_a_243));
      v_t_246 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s759991793x2063474551(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s759991793x2063474551_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s759991793x2063474551(a[0]);
}
Clo g_list_2emap_24s1678842425x1782957403_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1678842425x1782957403_entry, 1, 0};

V g_list_2emap_24s1678842425x1782957403(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      v_t_245 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_a_244, v_a_243));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1678842425x1782957403(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1678842425x1782957403_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1678842425x1782957403(a[0]);
}
Clo g_list_2emap_24s2010528650x1583508341_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2010528650x1583508341_entry, 1, 0};

V g_list_2emap_24s2010528650x1583508341(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_a_243)) {
      case TAG_TagVariant: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24TagVariant = heff_take_reuse_n(v_a_243, 7ULL, 3);
        v_t_2412 = heff_tag_at(v_ru_24a_243_24TagVariant, TAG_TagVariant, 3, (V[]){v_a_245, v_a_246, (g_list_2emap_24s1678842425x1782957403(v_a_247))});
        break;
      }
      case TAG_BadVariant: {
        V v_a_248 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadVariant = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          v_t_2411 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_a_2410, v_a_249));
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2412 = heff_tag_at(v_ru_24a_243_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2411});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2413 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2412, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2413, (g_list_2emap_24s2010528650x1583508341(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2010528650x1583508341_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2010528650x1583508341(a[0]);
}
Clo g_list_2emap_24s2070860064x992136139_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2070860064x992136139_entry, 1, 0};

V g_list_2emap_24s2070860064x992136139(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_a_243));
      v_t_246 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s2070860064x992136139(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2070860064x992136139_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2070860064x992136139(a[0]);
}
Clo g_list_2emap_24s629204667x1319563393_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s629204667x1319563393_entry, 1, 0};

V g_list_2emap_24s629204667x1319563393(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_SetField: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24SetField = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2411;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          V v_t_2410 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_a_248));
          v_t_2411 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2410, v_a_249});
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2417 = heff_tag_at(v_ru_24a_243_24SetField, TAG_SetField, 3, (V[]){v_a_245, v_a_246, v_t_2411});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2412 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadFieldSet = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          V v_t_2415 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_a_2413));
          v_t_2416 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2415, v_a_2414});
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2417 = heff_tag_at(v_ru_24a_243_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag_at(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2418, (g_list_2emap_24s629204667x1319563393(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s629204667x1319563393_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s629204667x1319563393(a[0]);
}
Clo g_list_2emap_24s769615621x481570027_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s769615621x481570027_entry, 1, 0};

V g_list_2emap_24s769615621x481570027(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        heff_take_n(v_a_243, 3ULL, 2);
        V v_t_2410;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_field(v_a_246, 0);
          V v_a_248 = heff_field(v_a_246, 1);
          heff_take_n(v_a_246, 3ULL, 2);
          V v_t_249 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_a_247));
          v_t_2410 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_249, v_a_248});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2411 = heff_tag_at(v_ru_24x_241_24At, TAG_MkAlt, 2, (V[]){v_a_245, v_t_2410});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2412 = heff_tag(TAG_At, 2, (V[]){v_t_2411, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2412, (g_list_2emap_24s769615621x481570027(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s769615621x481570027_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s769615621x481570027(a[0]);
}
Clo g_list_2emap_24s759389655x1953947393_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s759389655x1953947393_entry, 1, 0};

V g_list_2emap_24s759389655x1953947393(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_248 = heff_field(v_a_243, 3);
        V v_ru_24a_243_24MkEquation = heff_take_reuse_n(v_a_243, 15ULL, 4);
        V v_t_2412;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          V v_t_2411 = (g_heff_2epresyntax_2echkNode_24s769858677x299167023(v_a_249));
          v_t_2412 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2411, v_a_2410});
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2413 = heff_tag_at(v_ru_24a_243_24MkEquation, TAG_MkEquation, 4, (V[]){v_a_245, v_a_246, v_a_247, v_t_2412});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2414 = heff_tag_at(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2413, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2414, (g_list_2emap_24s759389655x1953947393(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s759389655x1953947393_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s759389655x1953947393(a[0]);
}
Clo g_list_2emap_24s2108633891x219265853_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2108633891x219265853_entry, 1, 0};

V g_list_2emap_24s2108633891x219265853(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_ExplicitParam: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24ExplicitParam = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          v_t_2410 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_a_249, v_a_248));
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2417 = heff_tag_at(v_ru_24a_243_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_a_245, v_a_246, v_t_2410});
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_a_2412 = heff_field(v_a_243, 1);
        V v_a_2413 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24ImplicitParam = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2416;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          v_t_2416 = (g_heff_2epresyntax_2etypNom_24s2062588653x1022079868(v_a_2415, v_a_2414));
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2417 = heff_tag_at(v_ru_24a_243_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_a_2411, v_a_2412, v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2418, (g_list_2emap_24s2108633891x219265853(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2108633891x219265853_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2108633891x219265853(a[0]);
}
Clo g_list_2emap_24s935072664x1288339118_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s935072664x1288339118_entry, 1, 0};

V g_list_2emap_24s935072664x1288339118(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_245 = (g_heff_2epresyntax_2edeclN_24s819476248x1348827013(v_a_243));
      v_t_246 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_245, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s935072664x1288339118(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s935072664x1288339118_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s935072664x1288339118(a[0]);
}
Clo g_list_2emap_24s1826078263x1390195856_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1826078263x1390195856_entry, 1, 0};

V g_list_2emap_24s1826078263x1390195856(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_2415;
      switch (heff_tag_of(v_a_243)) {
      case TAG_SetField: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24SetField = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          v_t_2410 = (g_heff_2epresyntax_2echkDe_24s1632343938x112901564(v_a_249, v_a_248));
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2415 = heff_tag_at(v_ru_24a_243_24SetField, TAG_SetField, 3, (V[]){v_a_245, v_a_246, v_t_2410});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadFieldSet = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_a_2411)) {
        case TAG_At: {
          V v_a_2412 = heff_field(v_a_2411, 0);
          V v_a_2413 = heff_field(v_a_2411, 1);
          heff_take_n(v_a_2411, 3ULL, 2);
          v_t_2414 = (g_heff_2epresyntax_2echkDe_24s1632343938x112901564(v_a_2413, v_a_2412));
          break;
        }
        default: heff_nomatch(v_a_2411);
        }
        v_t_2415 = heff_tag_at(v_ru_24a_243_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2414});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2416 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2415, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2416, (g_list_2emap_24s1826078263x1390195856(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1826078263x1390195856_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1826078263x1390195856(a[0]);
}
Clo g_list_2emap_24s1367796012x2117543847_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1367796012x2117543847_entry, 2, 0};

V g_list_2emap_24s1367796012x2117543847(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_242), (g_list_2emap_24s1367796012x2117543847(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1367796012x2117543847(a[0], a[1]);
}
Clo g_list_2efoldl_24s25418915x1870962456_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s25418915x1870962456_entry, 2, 0};

V g_list_2efoldl_24s25418915x1870962456(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s25418915x1870962456_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s25418915x1870962456(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1871125585x175648018_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1871125585x175648018_entry, 2, 0};

V g_list_2efoldl_24s1871125585x175648018(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2erename_2eglobalsTermF_24s1917262683x63074516(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1871125585x175648018_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1871125585x175648018(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s352779828x1056053810_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s352779828x1056053810_entry, 2, 0};

V g_list_2efoldl_24s352779828x1056053810(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2erename_2eglobalsTypeF_24s1660746940x107905774(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s352779828x1056053810_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s352779828x1056053810(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s501235026x755516560_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s501235026x755516560_entry, 2, 0};

V g_list_2efoldl_24s501235026x755516560(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_arrayToList(heff_dup(v_a_245))));
      v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s352779828x1056053810(a_0, a_1)); heff_drop(v_t_246); r_; });
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s501235026x755516560_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s501235026x755516560(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s495329560x2124268843_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s495329560x2124268843_entry, 2, 0};

V g_list_2efoldl_24s495329560x2124268843(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2erename_2eglobalsTermF_24s1917262683x63074516(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s495329560x2124268843_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s495329560x2124268843(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s337191029x991313305_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s337191029x991313305_entry, 2, 0};

V g_list_2efoldl_24s337191029x991313305(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_a_245)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_a_245, 1);
        v_t_248 = (g_heff_2erename_2eglobalsTermF_24s1917262683x63074516(v_a_247));
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s337191029x991313305_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s337191029x991313305(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efilter_24s2056490818x625949248_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2056490818x625949248_entry, 2, 0};

V g_list_2efilter_24s2056490818x625949248(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLt_c(heff_dup(v_lit_240), heff_strLength(heff_dup(v_x_242)))) {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2efilter_24s2056490818x625949248(v_lit_240, v_xs_243))});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s2056490818x625949248_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2056490818x625949248(a[0], a[1]);
}
Clo g_list_2efoldl_24s160534628x909100549_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s160534628x909100549_entry, 2, 0};

V g_list_2efoldl_24s160534628x909100549(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
    V v_t_245 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
    V v_t_246 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
    V v_t_247 = (g_heff_2efmt_2eimports_2espacesOf(heff_intSub(v_t_245, v_t_246)));
    V v_t_248 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
    V v_t_249 = heff_strSlice(heff_dup(v_z_240), v_t_248, heff_strLength(heff_dup(v_z_240)));
    V v_t_2410 = heff_strAppend(heff_strSlice(v_z_240, MK_INT(0LL), v_t_244), heff_strAppend(v_t_247, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s160534628x909100549_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s160534628x909100549(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emerge_24s421658182x1352532226_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s421658182x1352532226_entry, 2, 0};

V g_list_2emerge_24s421658182x1352532226(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_get(heff_dup(v_x_242), LBL_start), heff_get(heff_dup(v_y_244), LBL_start))) {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s421658182x1352532226(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      } else {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s421658182x1352532226(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s421658182x1352532226_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s421658182x1352532226(a[0], a[1]);
}
Clo g_list_2esortBy_24s209720638x21662806_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s209720638x21662806_entry, 1, 0};

V g_list_2esortBy_24s209720638x21662806(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s209720638x21662806(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s209720638x21662806(v_t_2411));
      return (g_list_2emerge_24s421658182x1352532226(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s209720638x21662806_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s209720638x21662806(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_list_2emap_24s2039214748x107984299_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 109, 112, 111, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s2039214748x107984299_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_list_2emap_24s2039214748x107984299_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2039214748x107984299_entry, 1, 0};

V g_list_2emap_24s2039214748x107984299(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_span), LBL_start);
    V v_t_244 = heff_get(heff_get(v_x_241, LBL_span), LBL_end);
    V v_t_245 = heff_rec(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_list_2emap_24s2039214748x107984299_str0), ((V)&g_list_2emap_24s2039214748x107984299_str1), v_t_243, v_t_244, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s2039214748x107984299(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2039214748x107984299_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2039214748x107984299(a[0]);
}
Clo g_list_2emerge_24s1166706590x737431029_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1166706590x737431029_entry, 2, 0};

V g_list_2emerge_24s1166706590x737431029(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_get(heff_dup(v_x_242), LBL_start), heff_get(heff_dup(v_y_244), LBL_start))) {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s1166706590x737431029(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      } else {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s1166706590x737431029(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1166706590x737431029_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1166706590x737431029(a[0], a[1]);
}
Clo g_list_2esortBy_24s1843786193x1453001387_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1843786193x1453001387_entry, 1, 0};

V g_list_2esortBy_24s1843786193x1453001387(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s1843786193x1453001387(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s1843786193x1453001387(v_t_2411));
      return (g_list_2emerge_24s1166706590x737431029(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1843786193x1453001387_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1843786193x1453001387(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s961430293x1662461983_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_list_2emap_24s961430293x1662461983_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s961430293x1662461983_entry, 1, 0};

V g_list_2emap_24s961430293x1662461983(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(heff_dup(v_x_241), LBL_end), heff_tag(TAG_Just, 1, (V[]){v_x_241}), ((V)&g_list_2emap_24s961430293x1662461983_str0), MK_INT(0LL), MK_INT(0LL)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s961430293x1662461983(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s961430293x1662461983_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s961430293x1662461983(a[0]);
}
Clo g_list_2emap_24s1731489230x1144208469_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1731489230x1144208469_entry, 1, 0};

V g_list_2emap_24s1731489230x1144208469(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(heff_dup(v_x_241), LBL_end), NTAG(TAG_Nothing), heff_get(v_x_241, LBL_text), MK_INT(0LL), MK_INT(0LL)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1731489230x1144208469(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1731489230x1144208469_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1731489230x1144208469(a[0]);
}
Clo g_list_2emap_24s1502118967x1628699884_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1502118967x1628699884_entry, 1, 0};

V g_list_2emap_24s1502118967x1628699884(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2esurface_2eidentOf(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1502118967x1628699884(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1502118967x1628699884_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1502118967x1628699884(a[0]);
}
Clo g_list_2emap_24s100060928x1092394615_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s100060928x1092394615_entry, 1, 0};

V g_list_2emap_24s100060928x1092394615(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esurface_2easNameE(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s100060928x1092394615(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s100060928x1092394615_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s100060928x1092394615(a[0]);
}
Clo g_list_2emap_24s1666645564x937815737_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1666645564x937815737_entry, 1, 0};

V g_list_2emap_24s1666645564x937815737(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag(TAG_EProject, 1, (V[]){heff_get(heff_dup(v_x_241), LBL_text)});
    V v_t_244 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(v_x_241, LBL_end)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_At, 2, (V[]){v_t_243, v_t_244}), (g_list_2emap_24s1666645564x937815737(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1666645564x937815737_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1666645564x937815737(a[0]);
}
Clo g_list_2efoldl_24s1618987991x843428997_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1618987991x843428997_entry, 3, 0};

V g_list_2efoldl_24s1618987991x843428997(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_SetField: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_249 = heff_field(v_a_245, 2);
        heff_take_n(v_a_245, 5ULL, 3);
        V v_a_2412;
        switch (heff_tag_of(v_z_241)) {
        case TAG_At: {
          V v_a_2411 = heff_dup(heff_field(v_z_241, 1));
          v_a_2412 = v_a_2411;
          break;
        }
        default: heff_nomatch(v_z_241);
        }
        V v_t_2413 = heff_rec(2, shape_start__end, (V[]){heff_get(v_a_2412, LBL_start), heff_get(heff_dup(v_a_246), LBL_end)});
        v_t_2415 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_ESpec, 4, (V[]){v_z_241, v_a_247, v_a_246, v_a_249}), v_t_2413});
        break;
      }
      case TAG_BadFieldSet: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop(v_z_241);
        v_t_2415 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag(TAG_EInvalid, 1, (V[]){heff_dup(v_lit_240)}), v_a_246});
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2415;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1618987991x843428997_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1618987991x843428997(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1615664184x1715591303_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1615664184x1715591303_entry, 1, 0};

V g_list_2emap_24s1615664184x1715591303(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_ExplicitParam: {
        V v_x_245 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_245;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_248 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, (g_list_2emap_24s1615664184x1715591303(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1615664184x1715591303_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1615664184x1715591303(a[0]);
}
Clo g_list_2emap_24s1711626084x463433445_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1711626084x463433445_entry, 1, 0};

V g_list_2emap_24s1711626084x463433445(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_text), (g_list_2emap_24s1711626084x463433445(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1711626084x463433445_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1711626084x463433445(a[0]);
}
Clo g_list_2emap_24s1400303153x1892969832_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1400303153x1892969832_entry, 4, 0};

V g_list_2emap_24s1400303153x1892969832(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_get(heff_dup(v_x_244), LBL_text), heff_dup(v_lit_242)));
    V v_t_247 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_244), LBL_start), heff_get(v_x_244, LBL_end)});
    V v_t_248 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), v_t_246, v_t_247, NTAG(TAG_Nothing)});
    return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_list_2emap_24s1400303153x1892969832(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1400303153x1892969832_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1400303153x1892969832(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efilter_24s1488835706x1708666848_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1488835706x1708666848_entry, 1, 0};

V g_list_2efilter_24s1488835706x1708666848(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(heff_dup(v_x_241), LBL_text)}));
    V v_t_244 = ({ V a_0 = v_t_243; V b_1 = heff_dup(g_heff_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1488835706x1708666848(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1488835706x1708666848_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1488835706x1708666848(a[0]);
}
Clo g_list_2emap_24s877811985x526414493_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s877811985x526414493_entry, 1, 0};

V g_list_2emap_24s877811985x526414493(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_ops);
    V v_t_248;
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      v_t_248 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_op_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 2);
      V v_t_246 = (g_list_2emap_24s1711626084x463433445(heff_get(heff_dup(v_x_241), LBL_ops)));
      V v_t_247 = heff_rec(3, shape_id__assoc__ops, (V[]){heff_get(v_op_244, LBL_text), heff_get(v_x_241, LBL_assoc), v_t_246});
      v_t_248 = heff_tag(TAG_Just, 1, (V[]){v_t_247});
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_list_2emap_24s877811985x526414493(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s877811985x526414493_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s877811985x526414493(a[0]);
}
Clo g_list_2efilter_24s446957238x1069456192_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s446957238x1069456192_entry, 4, 0};

V g_list_2efilter_24s446957238x1069456192(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V b_2 = heff_get(heff_dup(v_x_244), LBL_ops); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    if (heff_intEq_c(v_t_246, heff_dup(v_lit_242))) {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, (g_list_2efilter_24s446957238x1069456192(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s446957238x1069456192_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s446957238x1069456192(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s894988921x1774367189_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s894988921x1774367189_entry, 1, 0};

V g_list_2emap_24s894988921x1774367189(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec(2, shape_start__end, (V[]){heff_get(heff_dup(v_x_241), LBL_start), heff_get(heff_dup(v_x_241), LBL_end)});
    V v_t_244 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_get(v_x_241, LBL_msg), v_t_243, NTAG(TAG_Nothing)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s894988921x1774367189(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s894988921x1774367189_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s894988921x1774367189(a[0]);
}
Clo g_list_2emap_24s2103553821x564582624_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2103553821x564582624_entry, 2, 0};

V g_list_2emap_24s2103553821x564582624(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_PVar, 1, (V[]){heff_dup(v_lit_240)}), (g_list_2emap_24s2103553821x564582624(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2103553821x564582624_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2103553821x564582624(a[0], a[1]);
}
Clo g_list_2efoldl_24s1403790318x1472055750_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1403790318x1472055750_entry, 3, 0};

V g_list_2efoldl_24s1403790318x1472055750(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_2419;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      switch (heff_tag_of(v_a_246)) {
      case TAG_PVar: {
        V v_a_247 = heff_field(v_a_246, 0);
        if (heff_strEq_c(heff_dup(v_a_247), heff_dup(v_lit_240))) {
          v_t_2419 = v_z_241;
        } else {
          if (heff_strEq_c(heff_dup(v_a_247), heff_dup(v_a_245))) {
            v_t_2419 = v_z_241;
          } else {
            V v_t_2410 = (g_heff_2eclauses_2erenamer(heff_dup(v_a_247), heff_dup(v_a_245)));
            v_t_2419 = heff_tr(heff_apply(heff_get(v_t_2410, LBL_chk), 1, (V[]){v_z_241}));
          }
        }
        break;
      }
      case TAG_PTag: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PLit: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PRec: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PAs: {
        v_t_2419 = v_z_241;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2419;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1403790318x1472055750_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1403790318x1472055750(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_list_2efoldl_24s895450532x1092988905_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s895450532x1092988905_entry, 2, 0};

V g_list_2efoldl_24s895450532x1092988905(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s895450532x1092988905_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s895450532x1092988905(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s264628968x955404565_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s264628968x955404565_entry, 2, 0};

V g_list_2efoldl_24s264628968x955404565(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_i_244 = heff_field(v_x_242, 0);
      V v_x22_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_x22_245)) {
      case TAG_PVar: {
        V v_l_246 = heff_field(v_x22_245, 0);
        v_t_247 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(v_l_246), heff_dup(v_i_244), v_z_240));
        break;
      }
      case TAG_PSelf: {
        v_t_247 = v_z_240;
        break;
      }
      default: heff_nomatch(v_x22_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s264628968x955404565_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s264628968x955404565(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s291440091x511951757_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s291440091x511951757_entry, 2, 0};

V g_list_2efoldl_24s291440091x511951757(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_get(heff_dup(v_x_242), LBL_sol);
    V v_t_247;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_rec(2, shape_name__span, (V[]){heff_get(heff_dup(v_x_242), LBL_name), heff_get(v_x_242, LBL_span)});
      v_t_247 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_z_240});
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_247 = v_z_240;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s291440091x511951757_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s291440091x511951757(a[0], a[1]);
}
Clo g_list_2eany_24s141450647x925029990_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s141450647x925029990_entry, 1, 0};

V g_list_2eany_24s141450647x925029990(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_a_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s141450647x925029990_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eany_24s141450647x925029990(a[0]); heff_drop(a[0]); return r;
}
Clo g_list_2emap_24s420379013x173468973_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s420379013x173468973_entry, 1, 0};

V g_list_2emap_24s420379013x173468973(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eprims_2efixedImpl(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s420379013x173468973(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s420379013x173468973_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s420379013x173468973(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s1516017384x1249556640_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s1516017384x1249556640_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
Clo g_list_2emap_24s1516017384x1249556640_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1516017384x1249556640_entry, 1, 0};

V g_list_2emap_24s1516017384x1249556640(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eprint_2eescFrom(v_x_241, MK_INT(0LL)));
    V v_t_244 = heff_strAppend(((V)&g_list_2emap_24s1516017384x1249556640_str0), heff_strAppend(v_t_243, ((V)&g_list_2emap_24s1516017384x1249556640_str1)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s1516017384x1249556640(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1516017384x1249556640_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1516017384x1249556640(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_list_2emap_24s1300207191x1224487257_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {40, 48, 32, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s1300207191x1224487257_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_list_2emap_24s1300207191x1224487257_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1300207191x1224487257_entry, 1, 0};

V g_list_2emap_24s1300207191x1224487257(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    if (heff_intLt_c(heff_dup(v_x_241), MK_INT(0LL))) {
      V v_t_244 = heff_intShow(heff_intSub(MK_INT(0LL), v_x_241));
      v_t_245 = heff_strAppend(((V)&g_list_2emap_24s1300207191x1224487257_str0), heff_strAppend(v_t_244, ((V)&g_list_2emap_24s1300207191x1224487257_str1)));
    } else {
      v_t_245 = heff_intShow(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1300207191x1224487257(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1300207191x1224487257_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1300207191x1224487257(a[0]);
}
Clo g_list_2emap_24s1999471019x1288081638_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1999471019x1288081638_entry, 7, 0};

V g_list_2emap_24s1999471019x1288081638(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2eprint_2eescFrom(v_a_249, heff_dup(v_lit_242)));
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eprint_2eshowTypeF_24s1624445707x628038617(a_0)); heff_drop(v_a_2410); r_; });
      v_t_2414 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)))));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return heff_tag_at(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2414, (g_list_2emap_24s1999471019x1288081638(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s1999471019x1288081638_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1999471019x1288081638(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s1486836708x2052186263_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1486836708x2052186263_entry, 7, 0};

V g_list_2emap_24s1486836708x2052186263(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2eprint_2eescFrom(v_a_249, heff_dup(v_lit_242)));
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eprint_2eshowTermF_24s1075694671x1846348221(a_0)); heff_drop(v_a_2410); r_; });
      v_t_2414 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)))));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return heff_tag_at(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2414, (g_list_2emap_24s1486836708x2052186263(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s1486836708x2052186263_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1486836708x2052186263(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s638199897x1254231767_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s638199897x1254231767_entry, 11, 0};

V g_list_2emap_24s638199897x1254231767(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_x2_2410) {
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24Cons = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2421;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_MkPair: {
      V v_a_2413 = heff_field(v_x_2411, 0);
      V v_a_2414 = heff_field(v_x_2411, 1);
      heff_take_n(v_x_2411, 3ULL, 2);
      V v_t_2415 = (g_heff_2eprint_2eescFrom(v_a_2413, heff_dup(v_lit_242)));
      V v_t_2416 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2415, heff_dup(v_lit_243)));
      V v_a_2417 = (g_list_2emap(heff_get(heff_dup(g_heff_2eprint_2epr_get()), LBL_ty), heff_arrayToList(v_a_2414)));
      V v_t_2418 = ({ V a_0 = v_a_2417; V r_ = (g_heff_2eprint_2ecommaSep(a_0)); heff_drop(v_a_2417); r_; });
      V v_t_2419 = heff_strAppend(heff_dup(v_lit_246), heff_strAppend(v_t_2418, heff_dup(v_lit_247)));
      V v_t_2420 = heff_strAppend(heff_dup(v_lit_245), heff_strAppend(v_t_2419, heff_dup(v_lit_248)));
      v_t_2421 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2416, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2420, heff_dup(v_lit_249)))));
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    return heff_tag_at(v_ru_24x2_2410_24Cons, TAG_Cons, 2, (V[]){v_t_2421, (g_list_2emap_24s638199897x1254231767(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_249, v_xs_2412))});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_list_2emap_24s638199897x1254231767_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s638199897x1254231767(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
Clo g_list_2emap_24s1107296543x493652800_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1107296543x493652800_entry, 7, 0};

V g_list_2emap_24s1107296543x493652800(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2eprint_2eescFrom(v_a_249, heff_dup(v_lit_242)));
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eprint_2earmOf_24s139775371x1736504365(a_0)); heff_drop(v_a_2410); r_; });
      v_t_2414 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)))));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return heff_tag_at(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2414, (g_list_2emap_24s1107296543x493652800(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s1107296543x493652800_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1107296543x493652800(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2efilter_24s328645370x374613117_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s328645370x374613117_entry, 1, 0};

V g_list_2efilter_24s328645370x374613117(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s328645370x374613117(v_xs_242))});
    }
    case TAG_False: {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s328645370x374613117_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s328645370x374613117(a[0]);
}
Clo g_list_2eany_24s228396297x1310020012_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s228396297x1310020012_entry, 1, 0};

V g_list_2eany_24s228396297x1310020012(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eany_24s228396297x1310020012(a[0]); heff_drop(a[0]); return r;
}
Clo g_list_2emap_24s1579450514x1236398533_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1579450514x1236398533_entry, 1, 0};

V g_list_2emap_24s1579450514x1236398533(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_x_241), LBL_name), heff_get(v_x_241, LBL_el)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1579450514x1236398533(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1579450514x1236398533_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1579450514x1236398533(a[0]);
}
Clo g_list_2emap_24s1445534224x744280941_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1445534224x744280941_entry, 2, 0};

V g_list_2emap_24s1445534224x744280941(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_240), (g_list_2emap_24s1445534224x744280941(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1445534224x744280941_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1445534224x744280941(a[0], a[1]);
}
Clo g_list_2emap_24s1990719097x1419059608_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1990719097x1419059608_entry, 1, 0};

V g_list_2emap_24s1990719097x1419059608(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tr(heff_apply(v_x_241, 1, (V[]){NTAG(TAG_MkUnit)}));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1990719097x1419059608(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1990719097x1419059608(a[0]);
}
Clo g_list_2efoldl_24s1845550822x1006046555_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1845550822x1006046555_entry, 2, 0};

V g_list_2efoldl_24s1845550822x1006046555(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2etoplevel_2ethawOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1845550822x1006046555_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1845550822x1006046555(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s635091757x1027446614_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s635091757x1027446614_entry, 2, 0};

V g_list_2efoldl_24s635091757x1027446614(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_242), NTAG(TAG_MkUnit), heff_get(heff_dup(v_z_240), LBL_broken)));
    V v_t_245 = heff_rec(6, shape_order__entries__aliases__broken__ambiguous__places, (V[]){heff_get(heff_dup(v_z_240), LBL_order), heff_get(heff_dup(v_z_240), LBL_entries), heff_get(heff_dup(v_z_240), LBL_aliases), v_t_244, heff_get(heff_dup(v_z_240), LBL_ambiguous), heff_get(v_z_240, LBL_places)});
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s635091757x1027446614_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s635091757x1027446614(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s628776168x954682162_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s628776168x954682162_entry, 2, 0};

V g_list_2efoldl_24s628776168x954682162(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2edriver_2eenvOne(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s628776168x954682162_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s628776168x954682162(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s243791521x1469186053_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s243791521x1469186053_entry, 2, 0};

V g_list_2efoldl_24s243791521x1469186053(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = heff_get(heff_dup(v_x_242), LBL_level);
    V v_t_245;
    switch (heff_tag_of(v_z_240)) {
    case TAG_Small: {
      v_t_245 = v_a_244;
      break;
    }
    case TAG_Large: {
      switch (heff_tag_of(v_a_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_a_244;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_a_244;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_a_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_a_244;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s243791521x1469186053_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s243791521x1469186053(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s855006972x1903601780_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s855006972x1903601780_entry, 1, 0};

V g_list_2emap_24s855006972x1903601780(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag(TAG_SGlobal, 1, (V[]){heff_get(heff_dup(v_x_241), LBL_key)});
    V v_t_244 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_get(v_x_241, LBL_name), v_t_243});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s855006972x1903601780(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s855006972x1903601780_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s855006972x1903601780(a[0]);
}
Clo g_list_2efoldl_24s955934086x410334961_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s955934086x410334961_entry, 2, 0};

V g_list_2efoldl_24s955934086x410334961(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = heff_get(heff_dup(v_x_242), LBL_fixities);
    V v_t_245 = (g_heff_2efixity_2eappendF(heff_get(heff_dup(v_z_240), LBL_groups), heff_get(heff_dup(v_a_244), LBL_groups)));
    V v_t_246 = (g_heff_2efixity_2enubByG(v_t_245));
    V v_t_247 = (g_heff_2efixity_2eappendF(heff_get(v_z_240, LBL_above), heff_get(v_a_244, LBL_above)));
    V v_t_248 = (g_heff_2efixity_2enubByE(v_t_247));
    V t_0 = heff_rec(2, shape_groups__above, (V[]){v_t_246, v_t_248});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s955934086x410334961_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s955934086x410334961(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s530187580x1837272535_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s530187580x1837272535_entry, 1, 0};

V g_list_2emap_24s530187580x1837272535(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2edriver_2ehint(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s530187580x1837272535(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s530187580x1837272535_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s530187580x1837272535(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[56]; } g_list_2emap_24s1568304002x1464883775_str0 = {{0x80000000u, K_STR, 0}, 56, 56, {111, 110, 108, 121, 32, 116, 104, 101, 32, 108, 105, 98, 114, 97, 114, 121, 32, 116, 104, 97, 116, 32, 103, 111, 101, 115, 32, 119, 105, 116, 104, 32, 104, 101, 102, 102, 32, 100, 101, 99, 108, 97, 114, 101, 115, 32, 112, 114, 105, 109, 105, 116, 105, 118, 101, 115}};
Clo g_list_2emap_24s1568304002x1464883775_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1568304002x1464883775_entry, 1, 0};

V g_list_2emap_24s1568304002x1464883775(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = heff_rec(5, shape_code__severity__msg__span__note, (V[]){MK_INT(335LL), NTAG(TAG_SError), ((V)&g_list_2emap_24s1568304002x1464883775_str0), v_sp_244, NTAG(TAG_Nothing)});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1568304002x1464883775(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1568304002x1464883775_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1568304002x1464883775(a[0]);
}
Clo g_list_2emap_24s1937570095x2110149801_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1937570095x2110149801_entry, 1, 0};

V g_list_2emap_24s1937570095x2110149801(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1937570095x2110149801(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1937570095x2110149801(a[0]);
}
Clo g_list_2emap_24s2011789418x1542377058_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2011789418x1542377058_entry, 1, 0};

V g_list_2emap_24s2011789418x1542377058(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2424;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_243, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_243, 0ULL, 5);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_243, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2418 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2424 = heff_tag(TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){v_x_2418, v_sp_244})});
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2424, (g_list_2emap_24s2011789418x1542377058(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2011789418x1542377058_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2011789418x1542377058(a[0]);
}
Clo g_list_2efilter_24s787257770x404639529_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s787257770x404639529_entry, 1, 0};

V g_list_2efilter_24s787257770x404639529(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2424;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_dup(heff_field(v_x_241, 0));
      V v_sp_244 = heff_dup(heff_field(v_x_241, 1));
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_243, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_243, 0ULL, 5);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_243, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2418 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2424 = heff_tag(TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){v_x_2418, v_sp_244})});
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_sp_244);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nothing: {
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s787257770x404639529(v_xs_242))});
    }
    case TAG_Just: {
      heff_take_n(v_t_2424, 0ULL, 1);
      heff_drop(v_x_241);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s787257770x404639529_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s787257770x404639529(a[0]);
}
Clo g_list_2efoldl_24s1701682704x1534841280_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1701682704x1534841280_entry, 2, 0};

V g_list_2efoldl_24s1701682704x1534841280(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2eimport_2eimportsOf(heff_get(heff_dup(v_x_242), LBL_implicit), heff_get(heff_dup(v_x_242), LBL_source)));
    V v_a_245 = ({ V b_0 = heff_get(heff_dup(v_x_242), LBL_renames); V a_1 = v_t_244; V r_ = (g_heff_2eimport_2erenamed(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_246 = (g_list_2emap_24s1821466936x1723477761(heff_get(heff_dup(v_a_245), LBL_imports)));
    V v_a_247 = (g_heff_2edriver_2enubStrD(v_t_246));
    V v_t_248 = (g_heff_2edriver_2eclosureGo(v_z_240, NTAG(TAG_Nil), v_a_247));
    V v_t_249 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_a_245; V b_3 = NTAG(TAG_Nothing); V a_4 = v_t_248; V r_ = (g_heff_2edriver_2eelabNeeding(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); heff_drop(v_t_248); r_; });
    V v_t_2410 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2edriver_2eappendD(v_z_240, v_t_2410));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1701682704x1534841280_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1701682704x1534841280(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s237468257x275222167_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_list_2emap_24s237468257x275222167_lam0(V self, V *args); static Clo g_list_2emap_24s237468257x275222167_lam0_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s237468257x275222167_lam0, 1, 0};
Clo g_list_2emap_24s237468257x275222167_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s237468257x275222167_entry, 1, 0};

V g_list_2emap_24s237468257x275222167(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_rec(5, shape_span__name__key__member__ty, (V[]){heff_get(heff_dup(v_x_241), LBL_span), heff_get(heff_dup(v_x_241), LBL_name), heff_get(heff_dup(v_x_241), LBL_key), heff_get(v_x_241, LBL_member), ((V)&g_list_2emap_24s237468257x275222167_lam0_clo)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s237468257x275222167(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s237468257x275222167_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s237468257x275222167(a[0]);
}
V g_list_2emap_24s237468257x275222167_lam0(V self, V *args) {
  V v_u_243 = args[0];
  heff_drop(v_u_243);
  return ((V)&g_list_2emap_24s237468257x275222167_str0);
}
Clo g_list_2efoldl_24s1092063785x854423403_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1092063785x854423403_entry, 2, 0};

V g_list_2efoldl_24s1092063785x854423403(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2eimport_2eimportsOf(heff_get(heff_dup(v_x_242), LBL_implicit), heff_get(heff_dup(v_x_242), LBL_source)));
    V v_a_245 = ({ V b_0 = heff_get(heff_dup(v_x_242), LBL_renames); V a_1 = v_t_244; V r_ = (g_heff_2eimport_2erenamed(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_246 = (g_list_2emap_24s1821466936x1723477761(heff_get(heff_dup(v_a_245), LBL_imports)));
    V v_a_247 = (g_heff_2edriver_2enubStrD(v_t_246));
    V v_t_248 = (g_heff_2edriver_2eclosureGo(v_z_240, NTAG(TAG_Nil), v_a_247));
    V v_t_249 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_a_245; V b_3 = NTAG(TAG_Nothing); V a_4 = v_t_248; V r_ = (g_heff_2edriver_2eelabNeeding(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); heff_drop(v_t_248); r_; });
    V v_t_2410 = (g_heff_2edriver_2elean(v_t_249));
    V v_t_2411 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    V v_t_2412 = (g_heff_2edriver_2eappendD(v_z_240, v_t_2411));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1092063785x854423403_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1092063785x854423403(a[0], a[1]);
}
Clo g_list_2emap_24s1750409203x420789256_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1750409203x420789256_entry, 1, 0};

V g_list_2emap_24s1750409203x420789256(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_key), (g_list_2emap_24s1750409203x420789256(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1750409203x420789256_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1750409203x420789256(a[0]);
}
Clo g_list_2emap_24s752136398x849307084_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s752136398x849307084_entry, 3, 0};

V g_list_2emap_24s752136398x849307084(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_get(heff_dup(v_x_243), LBL_code));
    V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_245, heff_strAppend(heff_dup(v_lit_241), heff_get(v_x_243, LBL_msg))));
    return heff_tag_at(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s752136398x849307084(v_lit_240, v_lit_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s752136398x849307084_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s752136398x849307084(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s407249128x802036125_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s407249128x802036125_entry, 2, 0};

V g_list_2efoldl_24s407249128x802036125(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_242, 0);
      v_t_249 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s407249128x802036125_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s407249128x802036125(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s1063020973x859787996_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1063020973x859787996_entry, 1, 0};

V g_list_2emap_24s1063020973x859787996(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_t_245, LBL_start), (g_list_2emap_24s1063020973x859787996(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1063020973x859787996_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1063020973x859787996(a[0]);
}
Clo g_list_2emap_24s374365348x2042978339_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s374365348x2042978339_entry, 2, 0};

V g_list_2emap_24s374365348x2042978339(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_242, heff_dup(v_lit_240)), (g_list_2emap_24s374365348x2042978339(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s374365348x2042978339_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s374365348x2042978339(a[0], a[1]);
}
Clo g_list_2efoldl_24s1940164053x1118096699_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1940164053x1118096699_entry, 5, 0};

V g_list_2efoldl_24s1940164053x1118096699(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_244, 0);
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_t_247 = (g_prelude_2esplitFrom(heff_dup(v_lit_241), heff_get(heff_dup(v_x_245), LBL_value), heff_dup(v_lit_242), NTAG(TAG_Nil)));
    V v_t_248 = (g_list_2emap_24s1367796012x2117543847(heff_dup(v_lit_240), v_t_247));
    V v_t_249 = (g_heff_2edriver_2epromoteAt(v_z_243, heff_get(heff_dup(v_x_245), LBL_expectFrom), heff_get(heff_dup(v_x_245), LBL_expectTo), v_t_248));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_249;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24s1940164053x1118096699_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1940164053x1118096699(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[4]); return r;
}
Clo g_list_2emap_24s2130760772x63857074_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2130760772x63857074_entry, 1, 0};

V g_list_2emap_24s2130760772x63857074(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2edriver_2elabelOfV(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s2130760772x63857074(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2130760772x63857074_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2130760772x63857074(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s695437276x936974799_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s695437276x936974799_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s695437276x936974799_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s695437276x936974799_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s695437276x936974799_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s695437276x936974799_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s695437276x936974799_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s695437276x936974799_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_list_2emap_24s695437276x936974799_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s695437276x936974799_entry, 1, 0};

V g_list_2emap_24s695437276x936974799(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_VFun: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2412 = ((V)&g_list_2emap_24s695437276x936974799_str0);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2412 = ((V)&g_list_2emap_24s695437276x936974799_str1);
      break;
    }
    case TAG_VTag: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2412 = ((V)&g_list_2emap_24s695437276x936974799_str2);
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2412 = ((V)&g_list_2emap_24s695437276x936974799_str3);
      break;
    }
    case TAG_VFloat: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2412 = ((V)&g_list_2emap_24s695437276x936974799_str4);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2412 = ((V)&g_list_2emap_24s695437276x936974799_str5);
      break;
    }
    case TAG_VStr: {
      V v_s_2410 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_2412 = v_s_2410;
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2412 = ((V)&g_list_2emap_24s695437276x936974799_str6);
      break;
    }
    case TAG_VErased: {
      v_t_2412 = ((V)&g_list_2emap_24s695437276x936974799_str7);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_list_2emap_24s695437276x936974799(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s695437276x936974799_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s695437276x936974799(a[0]);
}
Clo g_list_2emap_24s103707540x1926696396_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s103707540x1926696396_entry, 1, 0};

V g_list_2emap_24s103707540x1926696396(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2edriver_2eoutcomeOfV(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s103707540x1926696396(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s103707540x1926696396_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s103707540x1926696396(a[0]);
}
Clo g_list_2efilter_24s1551648278x579137009_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1551648278x579137009_entry, 1, 0};

V g_list_2efilter_24s1551648278x579137009(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_severity);
    switch (heff_tag_of(v_t_243)) {
    case TAG_SError: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1551648278x579137009(v_xs_242))});
    }
    case TAG_SWarning: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_SDebug: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1551648278x579137009_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1551648278x579137009(a[0]);
}
Clo g_list_2emap_24s499977176x606563528_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s499977176x606563528_entry, 3, 0};

V g_list_2emap_24s499977176x606563528(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_x_243, heff_dup(v_lit_241)));
    return heff_tag_at(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s499977176x606563528(v_lit_240, v_lit_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s499977176x606563528_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s499977176x606563528(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s211047076x203275960_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s211047076x203275960_entry, 4, 0};

V g_list_2emap_24s211047076x203275960(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_get(heff_dup(v_x_244), LBL_module), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_get(v_x_244, LBL_alias), heff_dup(v_lit_242)))));
    return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s211047076x203275960(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s211047076x203275960_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s211047076x203275960(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efilter_24s2048945121x1749617505_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2048945121x1749617505_entry, 2, 0};

V g_list_2efilter_24s2048945121x1749617505(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_x_242), heff_dup(v_lit_240))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2efilter_24s2048945121x1749617505(v_lit_240, v_xs_243))});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s2048945121x1749617505_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2048945121x1749617505(a[0], a[1]);
}
Clo g_list_2efoldl_24s1672632733x1500872851_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1672632733x1500872851_entry, 2, 0};

V g_list_2efoldl_24s1672632733x1500872851(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2edriver_2eglueOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1672632733x1500872851_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1672632733x1500872851(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1182805385x625192302_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1182805385x625192302_entry, 2, 0};

V g_list_2efoldl_24s1182805385x625192302(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eir_2efreshBindOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1182805385x625192302_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1182805385x625192302(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s422245392x621266857_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s422245392x621266857_entry, 1, 0};

V g_list_2emap_24s422245392x621266857(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = ({ V a_0 = v_a_244; V r_ = (g_heff_2eir_2eisValue(a_0)); heff_drop(v_a_244); r_; });
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s422245392x621266857(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s422245392x621266857_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s422245392x621266857(a[0]);
}
Clo g_list_2emap_24s2051540388x950525029_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2051540388x950525029_entry, 1, 0};

V g_list_2emap_24s2051540388x950525029(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2eir_2eisValue(a_0)); heff_drop(v_x_241); r_; });
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s2051540388x950525029(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2051540388x950525029_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2051540388x950525029(a[0]);
}
Clo g_list_2emap_24s1173914895x100384474_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1173914895x100384474_entry, 1, 0};

V g_list_2emap_24s1173914895x100384474(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = v_y_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1173914895x100384474(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1173914895x100384474(a[0]);
}
Clo g_list_2efoldl_24s693515418x622271110_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s693515418x622271110_entry, 2, 0};

V g_list_2efoldl_24s693515418x622271110(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2espec_2ebindOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s693515418x622271110_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s693515418x622271110(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s2006210321x387008715_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2006210321x387008715_entry, 1, 0};

V g_list_2emap_24s2006210321x387008715(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_b_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 4ULL, 3);
      v_t_246 = v_b_245;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s2006210321x387008715(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2006210321x387008715_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2006210321x387008715(a[0]);
}
Clo g_list_2efoldl_24s741293892x1082420503_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s741293892x1082420503_entry, 2, 0};

V g_list_2efoldl_24s741293892x1082420503(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2esimplify_2eflat(heff_get(heff_dup(v_x_242), LBL_body)));
    V v_t_245 = ({ V a_0 = v_z_240; V a_1 = heff_get(heff_dup(v_x_242), LBL_key); V a_2 = v_t_244; V r_ = (g_heff_2esimplify_2esgFlat(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s741293892x1082420503_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s741293892x1082420503(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s2100141652x1420713717_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2100141652x1420713717_entry, 1, 0};

V g_list_2emap_24s2100141652x1420713717(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2432;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2432, (g_list_2emap_24s2100141652x1420713717(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2100141652x1420713717_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2100141652x1420713717(a[0]);
}
Clo g_list_2emap_24s1990289043x1851991154_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1990289043x1851991154_entry, 1, 0};

V g_list_2emap_24s1990289043x1851991154(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2432;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2432, (g_list_2emap_24s1990289043x1851991154(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1990289043x1851991154_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1990289043x1851991154(a[0]);
}
Clo g_list_2efoldl_24s2040448920x1981923787_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2040448920x1981923787_entry, 2, 0};

V g_list_2efoldl_24s2040448920x1981923787(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s2040448920x1981923787(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s85178867x1278479365_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s85178867x1278479365_entry, 5, 0};

V g_list_2efoldl_24s85178867x1278479365(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_ru_24x3_244_24Cons = heff_take_reuse_n(v_x3_244, 2ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_z_243)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_z_243, 0);
      V v_a_248 = heff_field(v_z_243, 1);
      heff_take_n(v_z_243, 3ULL, 2);
      V v_t_249 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), heff_intShow(heff_dup(v_a_248))));
      v_t_2410 = heff_tag_at(v_ru_24x3_244_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_249, v_a_247}), heff_intAdd(v_a_248, heff_dup(v_lit_242))});
      break;
    }
    default: heff_nomatch(v_z_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_2410;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24s85178867x1278479365_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s85178867x1278479365(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s1809017761x1063871171_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1809017761x1063871171_entry, 1, 0};

V g_list_2emap_24s1809017761x1063871171(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_EVar, 1, (V[]){v_x_241}), (g_list_2emap_24s1809017761x1063871171(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1809017761x1063871171(a[0]);
}
Clo g_list_2emap_24s73473062x206541869_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s73473062x206541869_entry, 1, 0};

V g_list_2emap_24s73473062x206541869(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_True), (g_list_2emap_24s73473062x206541869(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s73473062x206541869_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s73473062x206541869(a[0]);
}
Clo g_list_2ezipWith_24s896882142x1217494120_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s896882142x1217494120_entry, 3, 0};

V g_list_2ezipWith_24s896882142x1217494120(V v_lit_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ys_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_247;
      switch (heff_tag_of(v_x_243)) {
      case TAG_True: {
        v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_y_245; V r_ = (g_heff_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_y_245); r_; });
        break;
      }
      case TAG_False: {
        heff_drop(v_y_245);
        v_t_247 = heff_dup(v_lit_240);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      return heff_tag_at(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_list_2ezipWith_24s896882142x1217494120(v_lit_240, v_xs2_244, v_ys2_246))});
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2ezipWith_24s896882142x1217494120_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s896882142x1217494120(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s361191175x1417189158_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s361191175x1417189158_entry, 2, 0};

V g_list_2efoldl_24s361191175x1417189158(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_245;
    if (heff_intLe_c(heff_dup(v_z_240), heff_dup(v_x_242))) {
      v_t_245 = v_z_240;
    } else {
      heff_drop(v_z_240);
      v_t_245 = heff_dup(v_x_242);
    }
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s361191175x1417189158_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s361191175x1417189158(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1768561025x1024615304_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1768561025x1024615304_entry, 2, 0};

V g_list_2efoldl_24s1768561025x1024615304(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eir_2eglobalsGo(heff_dup(v_x_242)));
    V v_t_245 = (g_heff_2eir_2enubI(v_t_244));
    V v_t_246 = (g_prelude_2e_2b_2b(v_t_245, v_z_240));
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1768561025x1024615304_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1768561025x1024615304(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2eany_24s15435789x327987819_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s15435789x327987819_entry, 1, 0};

V g_list_2eany_24s15435789x327987819(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2435;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_x13_245 = heff_field(v_x_241, 2);
      switch (heff_tag_of(v_x13_245)) {
      case TAG_EVar: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_EMatch: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x13_245);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_2435);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s15435789x327987819_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eany_24s15435789x327987819(a[0]); heff_drop(a[0]); return r;
}
Clo g_list_2ezipWith_24s1029292936x211450510_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1029292936x211450510_entry, 2, 0};

V g_list_2ezipWith_24s1029292936x211450510(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_246 = heff_field(v_x_242, 0);
        heff_take_n(v_x_242, 1ULL, 2);
        v_t_248 = v_a_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_248, v_y_244}), (g_list_2ezipWith_24s1029292936x211450510(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1029292936x211450510(a[0], a[1]);
}
Clo g_list_2efoldl_24s1686199548x1740309507_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1686199548x1740309507_entry, 2, 0};

V g_list_2efoldl_24s1686199548x1740309507(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2earity_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1686199548x1740309507_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1686199548x1740309507(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2ezipWith_24s738847920x410598254_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s738847920x410598254_entry, 2, 0};

V g_list_2ezipWith_24s738847920x410598254(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkArm: {
        V v_a_246 = heff_dup(heff_field(v_x_242, 0));
        v_t_249 = v_a_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_t_2413;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkArm: {
        V v_a_2411 = heff_field(v_x_242, 1);
        heff_take_n(v_x_242, 2ULL, 3);
        v_t_2413 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkArm, 3, (V[]){v_t_249, v_t_2413, v_y_244}), (g_list_2ezipWith_24s738847920x410598254(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s738847920x410598254(a[0], a[1]);
}
Clo g_list_2efoldl_24s656114908x500828470_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s656114908x500828470_entry, 3, 0};

V g_list_2efoldl_24s656114908x500828470(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_heff_2elift_2eliftGo_24s104003089x2047780485(heff_dup(v_lit_240), heff_dup(v_x_243), heff_get(heff_dup(v_x_243), LBL_body)));
    V v_t_249;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_t_245, 0);
      V v_a_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      V v_t_248 = heff_rec(3, shape_key__name__body, (V[]){heff_get(heff_dup(v_x_243), LBL_key), heff_get(v_x_243, LBL_name), v_a_246});
      v_t_249 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get(v_a_247, LBL_out)))});
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2410 = (g_prelude_2e_2b_2b(v_t_249, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_2410;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s656114908x500828470_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s656114908x500828470(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s2042221365x352889312_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2042221365x352889312_entry, 2, 0};

V g_list_2efoldl_24s2042221365x352889312(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_get(heff_dup(v_x_242), LBL_key), heff_get(heff_dup(v_x_242), LBL_body), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2042221365x352889312_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s2042221365x352889312(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1696234796x1855206942_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1696234796x1855206942_entry, 2, 0};

V g_list_2efoldl_24s1696234796x1855206942(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemit_2evalueRefs(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1696234796x1855206942_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1696234796x1855206942(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1313979667x1986692492_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1313979667x1986692492_entry, 2, 0};

V g_list_2efoldl_24s1313979667x1986692492(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eemit_2evalueRefs(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1313979667x1986692492_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1313979667x1986692492(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1388689313x1238506813_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1388689313x1238506813_entry, 2, 0};

V g_list_2efoldl_24s1388689313x1238506813(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2eemit_2evalueRefs(a_0)); heff_drop(v_t_247); r_; });
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1388689313x1238506813_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1388689313x1238506813(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2eany_24s303571641x1461404329_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s303571641x1461404329_entry, 1, 0};

V g_list_2eany_24s303571641x1461404329(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2eemit_2etailApp(a_0)); heff_drop(v_t_246); r_; });
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s303571641x1461404329_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eany_24s303571641x1461404329(a[0]); heff_drop(a[0]); return r;
}
Clo g_list_2efoldl_24s1184002650x1359070118_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1184002650x1359070118_entry, 2, 0};

V g_list_2efoldl_24s1184002650x1359070118(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_heff_2eemit_2etailGlobals(v_t_247));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1184002650x1359070118_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1184002650x1359070118(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1202969196x1354597937_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1202969196x1354597937_entry, 2, 0};

V g_list_2efoldl_24s1202969196x1354597937(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2eemit_2ebindName(heff_get(heff_dup(v_z_240), LBL_env), v_x_242));
    V v_t_245 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get(heff_dup(v_a_244), LBL_js), NTAG(TAG_Nil)});
    V v_t_246 = (g_prelude_2e_2b_2b(heff_get(v_z_240, LBL_js), v_t_245));
    V v_t_247 = heff_rec(2, shape_js__env, (V[]){v_t_246, heff_get(v_a_244, LBL_env)});
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1202969196x1354597937_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1202969196x1354597937(a[0], a[1]);
}
Clo g_list_2emap_24s1890391385x30945199_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1890391385x30945199_entry, 1, 0};

V g_list_2emap_24s1890391385x30945199(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_code), (g_list_2emap_24s1890391385x30945199(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1890391385x30945199_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1890391385x30945199(a[0]);
}
Clo g_list_2ezipWith_24s1610853704x1401907306_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1610853704x1401907306_entry, 3, 0};

V g_list_2ezipWith_24s1610853704x1401907306(V v_lit_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ys_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_247 = heff_strAppend(v_x_243, heff_strAppend(heff_dup(v_lit_240), v_y_245));
      return heff_tag_at(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_list_2ezipWith_24s1610853704x1401907306(v_lit_240, v_xs2_244, v_ys2_246))});
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2ezipWith_24s1610853704x1401907306_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1610853704x1401907306(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1808984284x920551775_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1808984284x920551775_entry, 2, 0};

V g_list_2efoldl_24s1808984284x920551775(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = ({ V a_0 = v_z_240; V a_1 = v_t_246; V r_ = (g_heff_2eemit_2eprimUses(a_0, a_1)); heff_drop(v_t_246); r_; });
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1808984284x920551775_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1808984284x920551775(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s340728100x227093504_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s340728100x227093504_entry, 2, 0};

V g_list_2efoldl_24s340728100x227093504(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = ({ V a_0 = v_z_240; V a_1 = v_t_247; V r_ = (g_heff_2eemit_2eprimUses(a_0, a_1)); heff_drop(v_t_247); r_; });
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s340728100x227093504_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s340728100x227093504(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s216488628x1112278107_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s216488628x1112278107_entry, 2, 0};

V g_list_2efoldl_24s216488628x1112278107(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = ({ V a_0 = v_z_240; V b_1 = heff_get(heff_dup(v_x_242), LBL_body); V r_ = (g_heff_2eemit_2eprimUses(a_0, b_1)); heff_drop(b_1); r_; });
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s216488628x1112278107_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s216488628x1112278107(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s942708720x1221319722_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s942708720x1221319722_entry, 8, 0};

V g_list_2emap_24s942708720x1221319722(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_a_2410 = heff_get(v_x_248, LBL_key);
    V v_a_2411 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_a_2410), heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_a_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_2411));
    V v_a_2415;
    switch (heff_tag_of(v_a_2412)) {
    case TAG_Nil: {
      v_a_2415 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_a_2413 = heff_field(v_a_2412, 0);
      heff_take_n(v_a_2412, 1ULL, 2);
      v_a_2415 = heff_tag(TAG_Just, 1, (V[]){v_a_2413});
      break;
    }
    default: heff_nomatch(v_a_2412);
    }
    V v_a_2417;
    switch (heff_tag_of(v_a_2415)) {
    case TAG_Nothing: {
      v_a_2417 = v_a_2410;
      break;
    }
    case TAG_Just: {
      V v_a_2416 = heff_field(v_a_2415, 0);
      heff_take_n(v_a_2415, 1ULL, 1);
      heff_drop(v_a_2410);
      v_a_2417 = v_a_2416;
      break;
    }
    default: heff_nomatch(v_a_2415);
    }
    V v_t_2418 = heff_intSub(heff_strLength(heff_dup(v_a_2417)), heff_dup(v_lit_242));
    V v_t_2419 = (g_heff_2eemit_2elastDotFrom(heff_dup(v_a_2417), v_t_2418));
    V v_t_2420 = (g_heff_2eemit_2espellAt(v_a_2417, v_t_2419));
    V v_a_2421 = (g_heff_2eemit_2esafeChars(v_t_2420, heff_dup(v_lit_243), heff_dup(v_lit_244)));
    V v_t_2423;
    if (heff_strEq_c(heff_dup(v_a_2421), heff_dup(v_lit_245))) {
      heff_drop(v_a_2421);
      v_t_2423 = heff_dup(v_lit_246);
    } else {
      v_t_2423 = v_a_2421;
    }
    V v_t_2424 = (g_heff_2eemit_2esafeRes(v_t_2423));
    return heff_tag_at(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_t_2424, (g_list_2emap_24s942708720x1221319722(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_249))});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s942708720x1221319722_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s942708720x1221319722(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2efoldl_24s657006386x1833506039_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s657006386x1833506039_entry, 2, 0};

V g_list_2efoldl_24s657006386x1833506039(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s657006386x1833506039(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s906555454x1998445727_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s906555454x1998445727_entry, 2, 0};

V g_list_2efoldl_24s906555454x1998445727(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = ({ V b_0 = heff_get(heff_dup(v_x_242), LBL_body); V r_ = (g_heff_2eemit_2evalueRefs(b_0)); heff_drop(b_0); r_; });
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s906555454x1998445727_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s906555454x1998445727(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efilter_24s413688307x112671032_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s413688307x112671032_entry, 4, 0};

V g_list_2efilter_24s413688307x112671032(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242))) {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, (g_list_2efilter_24s413688307x112671032(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s413688307x112671032_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s413688307x112671032(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s629291802x1492808929_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s629291802x1492808929_entry, 1, 0};

V g_list_2emap_24s629291802x1492808929(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eemit_2eexportNameOf(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s629291802x1492808929(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s629291802x1492808929_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s629291802x1492808929(a[0]);
}
Clo g_list_2emap_24s1674044852x1346586108_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1674044852x1346586108_entry, 1, 0};

V g_list_2emap_24s1674044852x1346586108(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eemit_2ehostLineOf(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1674044852x1346586108(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1674044852x1346586108_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1674044852x1346586108(a[0]);
}
Clo g_list_2emap_24s1654555371x977048649_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1654555371x977048649_entry, 6, 0};

V g_list_2emap_24s1654555371x977048649(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_2410;
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_246), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242))) {
      V v_t_249 = heff_strSlice(heff_dup(v_x_246), heff_dup(v_lit_244), heff_strLength(v_x_246));
      v_t_2410 = heff_strAppend(heff_dup(v_lit_243), v_t_249);
    } else {
      v_t_2410 = v_x_246;
    }
    return heff_tag_at(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_list_2emap_24s1654555371x977048649(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247))});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s1654555371x977048649_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1654555371x977048649(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s47431100x1937383650_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s47431100x1937383650_entry, 5, 0};

V g_list_2emap_24s47431100x1937383650(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), v_x_245, heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_a_248 = (g_heff_2eeffect_2edropLastD(v_t_247));
    V v_t_2411;
    switch (heff_tag_of(v_a_248)) {
    case TAG_Nil: {
      v_t_2411 = heff_dup(v_lit_242);
      break;
    }
    case TAG_Cons: {
      V v_a_249 = heff_field(v_a_248, 0);
      V v_a_2410 = heff_field(v_a_248, 1);
      heff_take_n(v_a_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = heff_dup(v_lit_243); V a_1 = v_a_249; V a_2 = v_a_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2410); r_; });
      break;
    }
    default: heff_nomatch(v_a_248);
    }
    return heff_tag_at(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2411, (g_list_2emap_24s47431100x1937383650(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246))});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s47431100x1937383650_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s47431100x1937383650(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efilter_24s926921591x156811372_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s926921591x156811372_entry, 4, 0};

V g_list_2efilter_24s926921591x156811372(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242))) {
      return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, (g_list_2efilter_24s926921591x156811372(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s926921591x156811372_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s926921591x156811372(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eany_24s1711990188x1947159119_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1711990188x1947159119_entry, 1, 0};

V g_list_2eany_24s1711990188x1947159119(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if (heff_strEq_c(heff_dup(v_x_241), heff_dup(g_heff_2eemit_2etrampolineStr_get()))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1711990188x1947159119_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eany_24s1711990188x1947159119(a[0]); heff_drop(a[0]); return r;
}
Clo g_list_2emap_24s565104239x2094869705_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s565104239x2094869705_entry, 1, 0};

V g_list_2emap_24s565104239x2094869705(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = heff_rec(2, shape_name__key, (V[]){heff_dup(v_a_243), v_a_243});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s565104239x2094869705(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s565104239x2094869705_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s565104239x2094869705(a[0]);
}
Clo g_list_2emap_24s46845351x1913259050_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s46845351x1913259050_entry, 1, 0};

V g_list_2emap_24s46845351x1913259050(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_t_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 3);
      v_t_246 = v_t_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s46845351x1913259050(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s46845351x1913259050_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s46845351x1913259050(a[0]);
}
Clo g_list_2efoldl_24s1127955551x950394381_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1127955551x950394381_entry, 2, 0};

V g_list_2efoldl_24s1127955551x950394381(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2eemitc_2etagsLbls(v_x_242));
    V v_t_2410;
    switch (heff_tag_of(v_a_244)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_a_244, 0);
      V v_a_246 = heff_field(v_a_244, 1);
      heff_take_n(v_a_244, 3ULL, 2);
      switch (heff_tag_of(v_z_240)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_z_240, 0);
        V v_a_248 = heff_field(v_z_240, 1);
        heff_take_n(v_z_240, 3ULL, 2);
        V v_t_249 = (g_prelude_2e_2b_2b(v_a_245, v_a_247));
        v_t_2410 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_249, (g_prelude_2e_2b_2b(v_a_246, v_a_248))});
        break;
      }
      default: heff_nomatch(v_z_240);
      }
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1127955551x950394381_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1127955551x950394381(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s1953731716x1367196380_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_list_2emap_24s1953731716x1367196380_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1953731716x1367196380_entry, 1, 0};

V g_list_2emap_24s1953731716x1367196380(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eemitc_2emangleW(v_x_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_list_2emap_24s1953731716x1367196380_str0)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1953731716x1367196380(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1953731716x1367196380_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1953731716x1367196380(a[0]);
}
Clo g_list_2efoldl_24s1530401830x609500251_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1530401830x609500251_entry, 2, 0};

V g_list_2efoldl_24s1530401830x609500251(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1530401830x609500251(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1187012699x1099443358_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1187012699x1099443358_entry, 2, 0};

V g_list_2efoldl_24s1187012699x1099443358(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2efreeOf(NTAG(TAG_Nil), heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1187012699x1099443358_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1187012699x1099443358(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s455042168x142217368_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s455042168x142217368_entry, 7, 0};

V g_list_2emap_24s455042168x142217368(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strAppend(heff_dup(v_lit_241), (g_heff_2eemitc_2emangleW(v_x_247, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244))));
    V v_t_2410 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_249, heff_dup(v_lit_245)));
    return heff_tag_at(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_list_2emap_24s455042168x142217368(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s455042168x142217368_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s455042168x142217368(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2eall_24s1175244903x419753027_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1175244903x419753027_entry, 1, 0};

V g_list_2eall_24s1175244903x419753027(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_pre);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nil: {
      V v_t_244 = heff_get(heff_dup(v_x_241), LBL_post);
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nil: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_Cons: {
        heff_take_n(v_t_244, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_t_243, 0ULL, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1175244903x419753027_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eall_24s1175244903x419753027(a[0]); heff_drop(a[0]); return r;
}
Clo g_list_2emap_24s1363203549x1204645634_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1363203549x1204645634_entry, 1, 0};

V g_list_2emap_24s1363203549x1204645634(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_arg), (g_list_2emap_24s1363203549x1204645634(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1363203549x1204645634_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1363203549x1204645634(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_list_2ezipWith_24s259431397x671561817_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_list_2ezipWith_24s259431397x671561817_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {86, 32, 97, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_list_2ezipWith_24s259431397x671561817_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2ezipWith_24s259431397x671561817_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_list_2ezipWith_24s259431397x671561817_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s259431397x671561817_entry, 2, 0};

V g_list_2ezipWith_24s259431397x671561817(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_get(heff_dup(v_x_242), LBL_pre);
      V v_t_2412;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        V v_t_247 = heff_strAppend(((V)&g_list_2ezipWith_24s259431397x671561817_str0), heff_intShow(heff_dup(v_y_244)));
        V v_t_248 = heff_strAppend(((V)&g_list_2ezipWith_24s259431397x671561817_str1), heff_strAppend(heff_intShow(v_y_244), heff_strAppend(((V)&g_list_2ezipWith_24s259431397x671561817_str2), heff_strAppend(heff_get(heff_dup(v_x_242), LBL_arg), ((V)&g_list_2ezipWith_24s259431397x671561817_str3)))));
        V v_t_249 = heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
        v_t_2412 = heff_rec(3, shape_arg__pre__post, (V[]){v_t_247, v_t_249, heff_get(v_x_242, LBL_post)});
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_246, 0ULL, 2);
        heff_drop_cell(v_ru_24xs_240_24Cons, 2);
        heff_drop(v_y_244);
        v_t_2412 = v_x_242;
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_list_2ezipWith_24s259431397x671561817(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s259431397x671561817_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s259431397x671561817(a[0], a[1]);
}
Clo g_list_2efoldl_24s638445529x932797857_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s638445529x932797857_entry, 2, 0};

V g_list_2efoldl_24s638445529x932797857(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_x_242), LBL_pre), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s638445529x932797857_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s638445529x932797857(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1958541883x442288263_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1958541883x442288263_entry, 2, 0};

V g_list_2efoldl_24s1958541883x442288263(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_x_242), LBL_post), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1958541883x442288263_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1958541883x442288263(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2ezipWith_24s1947952772x1156675739_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1947952772x1156675739_entry, 9, 0};

V g_list_2ezipWith_24s1947952772x1156675739(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_xs_247, V v_ys_248) {
top: ;
  switch (heff_tag_of(v_xs_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_ys_248);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_xs_247, 0);
    V v_xs2_2410 = heff_field(v_xs_247, 1);
    V v_ru_24xs_247_24Cons = heff_take_reuse_n(v_xs_247, 3ULL, 2);
    switch (heff_tag_of(v_ys_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_249);
      heff_drop(v_xs2_2410);
      heff_drop_cell(v_ru_24xs_247_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_2411 = heff_field(v_ys_248, 0);
      V v_ys2_2412 = heff_field(v_ys_248, 1);
      heff_take_n(v_ys_248, 3ULL, 2);
      V v_t_2413 = heff_strAppend(heff_dup(v_lit_241), (g_heff_2eemitc_2emangleW(v_x_249, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244))));
      V v_t_2414 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2413, heff_strAppend(heff_dup(v_lit_245), heff_strAppend(heff_intShow(v_y_2411), heff_dup(v_lit_246)))));
      return heff_tag_at(v_ru_24xs_247_24Cons, TAG_Cons, 2, (V[]){v_t_2414, (g_list_2ezipWith_24s1947952772x1156675739(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs2_2410, v_ys2_2412))});
    }
    default: return heff_nomatch(v_ys_248);
    }
  }
  default: return heff_nomatch(v_xs_247);
  }
}
V g_list_2ezipWith_24s1947952772x1156675739_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1947952772x1156675739(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_list_2ezipWith_24s1814128165x1680687847_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1814128165x1680687847_entry, 5, 0};

V g_list_2ezipWith_24s1814128165x1680687847(V v_lit_240, V v_lit_241, V v_lit_242, V v_xs_243, V v_ys_244) {
top: ;
  switch (heff_tag_of(v_xs_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_ys_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_xs_243, 0);
    V v_xs2_246 = heff_field(v_xs_243, 1);
    V v_ru_24xs_243_24Cons = heff_take_reuse_n(v_xs_243, 3ULL, 2);
    switch (heff_tag_of(v_ys_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_245);
      heff_drop(v_xs2_246);
      heff_drop_cell(v_ru_24xs_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_ys_244, 0);
      V v_ys2_248 = heff_field(v_ys_244, 1);
      heff_take_n(v_ys_244, 3ULL, 2);
      V v_t_249 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(v_y_247), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_x_245, heff_dup(v_lit_242)))));
      return heff_tag_at(v_ru_24xs_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_list_2ezipWith_24s1814128165x1680687847(v_lit_240, v_lit_241, v_lit_242, v_xs2_246, v_ys2_248))});
    }
    default: return heff_nomatch(v_ys_244);
    }
  }
  default: return heff_nomatch(v_xs_243);
  }
}
V g_list_2ezipWith_24s1814128165x1680687847_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1814128165x1680687847(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2ezipWith_24s2075573643x1334977728_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s2075573643x1334977728_entry, 8, 0};

V g_list_2ezipWith_24s2075573643x1334977728(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_xs_246, V v_ys_247) {
top: ;
  switch (heff_tag_of(v_xs_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_ys_247);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_xs_246, 0);
    V v_xs2_249 = heff_field(v_xs_246, 1);
    V v_ru_24xs_246_24Cons = heff_take_reuse_n(v_xs_246, 3ULL, 2);
    switch (heff_tag_of(v_ys_247)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_x_248);
      heff_drop(v_xs2_249);
      heff_drop_cell(v_ru_24xs_246_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_2410 = heff_field(v_ys_247, 0);
      V v_ys2_2411 = heff_field(v_ys_247, 1);
      heff_take_n(v_ys_247, 3ULL, 2);
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_240), (g_heff_2eemitc_2emangleW(v_x_248, heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243))));
      V v_t_2413 = heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_244), heff_strAppend(heff_intShow(v_y_2410), heff_dup(v_lit_245))));
      return heff_tag_at(v_ru_24xs_246_24Cons, TAG_Cons, 2, (V[]){v_t_2413, (g_list_2ezipWith_24s2075573643x1334977728(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs2_249, v_ys2_2411))});
    }
    default: return heff_nomatch(v_ys_247);
    }
  }
  default: return heff_nomatch(v_xs_246);
  }
}
V g_list_2ezipWith_24s2075573643x1334977728_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s2075573643x1334977728(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2eany_24s910662703x1730636603_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s910662703x1730636603_entry, 1, 0};

V g_list_2eany_24s910662703x1730636603(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_x_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eany_24s910662703x1730636603(a[0]); heff_drop(a[0]); return r;
}
Clo g_list_2ezipWith_24s1876717925x1404326288_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1876717925x1404326288_entry, 2, 0};

V g_list_2ezipWith_24s1876717925x1404326288(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      return heff_tag_at(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_list_2ezipWith_24s1876717925x1404326288(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1876717925x1404326288(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_list_2eall_24s1225041428x2030583288_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_list_2eall_24s1225041428x2030583288_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
Clo g_list_2eall_24s1225041428x2030583288_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1225041428x2030583288_entry, 1, 0};

V g_list_2eall_24s1225041428x2030583288(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_t_243 = heff_field(v_x_241, 0);
      V v_vs_244 = heff_field(v_x_241, 1);
      switch (heff_tag_of(v_vs_244)) {
      case TAG_Nil: {
        if (heff_strEq_c(heff_dup(v_t_243), ((V)&g_list_2eall_24s1225041428x2030583288_str0))) {
          v_t_249 = NTAG(TAG_True);
        } else {
          v_t_249 = heff_strEq(heff_dup(v_t_243), ((V)&g_list_2eall_24s1225041428x2030583288_str1));
        }
        break;
      }
      case TAG_Cons: {
        v_t_249 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_vs_244);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1225041428x2030583288_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eall_24s1225041428x2030583288(a[0]); heff_drop(a[0]); return r;
}
Clo g_list_2efoldl_24s1651310864x859456474_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1651310864x859456474_entry, 2, 0};

V g_list_2efoldl_24s1651310864x859456474(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1651310864x859456474(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s231476130x1974273190_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s231476130x1974273190_entry, 6, 0};

V g_list_2emap_24s231476130x1974273190(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), (g_heff_2eemitc_2emangleW(v_x_246, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244)))));
    return heff_tag_at(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_list_2emap_24s231476130x1974273190(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247))});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s231476130x1974273190_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s231476130x1974273190(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s1006477676x1816442814_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1006477676x1816442814_entry, 3, 0};

V g_list_2emap_24s1006477676x1816442814(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(v_x_243), heff_dup(v_lit_241)));
    return heff_tag_at(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s1006477676x1816442814(v_lit_240, v_lit_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1006477676x1816442814_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1006477676x1816442814(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1378753456x1787722089_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1378753456x1787722089_entry, 4, 0};

V g_list_2emap_24s1378753456x1787722089(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_244, 1));
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_244, 0);
      heff_take_n(v_x_244, 1ULL, 2);
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2412 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(v_t_248), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_242)))));
    return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_list_2emap_24s1378753456x1787722089(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1378753456x1787722089_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1378753456x1787722089(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eany_24s1438978125x414501573_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1438978125x414501573_entry, 1, 0};

V g_list_2eany_24s1438978125x414501573(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_vs_244 = heff_field(v_x_241, 1);
      V v_b_245 = heff_field(v_x_241, 2);
      V v_x1_248;
      switch (heff_tag_of(v_vs_244)) {
      case TAG_Nil: {
        v_x1_248 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        v_x1_248 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_vs_244);
      }
      switch (heff_tag_of(v_x1_248)) {
      case TAG_True: {
        v_t_2410 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_244));
        v_t_2410 = (g_heff_2eemitc_2ebuildsSize(v_t_249, heff_dup(v_b_245)));
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1438978125x414501573_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eany_24s1438978125x414501573(a[0]); heff_drop(a[0]); return r;
}
Clo g_list_2emap_24s1573559022x513331157_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1573559022x513331157_entry, 3, 0};

V g_list_2emap_24s1573559022x513331157(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_a_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_a_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_248 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_a_247; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_a_247); r_; });
    return heff_tag_at(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_list_2emap_24s1573559022x513331157(v_lit_240, v_lit_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1573559022x513331157_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1573559022x513331157(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1537290326x1300290376_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1537290326x1300290376_entry, 2, 0};

V g_list_2efoldl_24s1537290326x1300290376(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2eborDef(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1537290326x1300290376_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1537290326x1300290376(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1889728774x506508078_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1889728774x506508078_entry, 2, 0};

V g_list_2efoldl_24s1889728774x506508078(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2eborAll(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1889728774x506508078_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1889728774x506508078(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s1039286686x792451646_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1039286686x792451646_entry, 7, 0};

V g_list_2emap_24s1039286686x792451646(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_a_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_dup(heff_field(v_x_247, 0));
      v_a_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), (g_heff_2eemitc_2emangleW(v_a_2411, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244))));
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2416 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_245), heff_intShow(v_t_2415))));
    return heff_tag_at(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2416, (g_list_2emap_24s1039286686x792451646(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s1039286686x792451646_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1039286686x792451646(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2efilter_24s314366508x59199896_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s314366508x59199896_entry, 1, 0};

V g_list_2efilter_24s314366508x59199896(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_a_246 = ({ V a_0 = v_t_245; V b_1 = heff_dup(g_heff_2eemitc_2eknownTags_get()); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_a_246)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s314366508x59199896(v_xs_242))});
    }
    default: return heff_nomatch(v_a_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s314366508x59199896_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s314366508x59199896(a[0]);
}
Clo g_list_2emap_24s1377907145x510226651_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1377907145x510226651_entry, 1, 0};

V g_list_2emap_24s1377907145x510226651(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eemitc_2eshapeDef(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1377907145x510226651(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1377907145x510226651_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1377907145x510226651(a[0]);
}
Clo g_list_2efoldl_24s1670799345x2002421308_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1670799345x2002421308_entry, 2, 0};

V g_list_2efoldl_24s1670799345x2002421308(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_x_242), LBL_protos), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1670799345x2002421308_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1670799345x2002421308(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s122245128x1667515165_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s122245128x1667515165_entry, 2, 0};

V g_list_2efoldl_24s122245128x1667515165(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2eprimCloDef(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s122245128x1667515165_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s122245128x1667515165(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1885051946x1524849902_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1885051946x1524849902_entry, 2, 0};

V g_list_2efoldl_24s1885051946x1524849902(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_x_242), LBL_code), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1885051946x1524849902_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1885051946x1524849902(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efilter_24s1412390516x2102311772_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1412390516x2102311772_entry, 1, 0};

V g_list_2efilter_24s1412390516x2102311772(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = ({ V a_0 = heff_dup(v_x_241); V b_1 = heff_dup(g_heff_2eemitc_2eknownTags_get()); V r_ = (g_heff_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_a_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1412390516x2102311772(v_xs_242))});
    }
    default: return heff_nomatch(v_a_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1412390516x2102311772_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1412390516x2102311772(a[0]);
}
Clo g_list_2efoldl_24s1112037391x343083959_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1112037391x343083959_entry, 4, 0};

V g_list_2efoldl_24s1112037391x343083959(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_heff_2eemitc_2enamesInGo(heff_dup(v_lit_240), heff_get(heff_dup(v_x_244), LBL_text), heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_242));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_247;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1112037391x343083959_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1112037391x343083959(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
Clo g_list_2efoldl_24s966961137x2098673946_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s966961137x2098673946_entry, 2, 0};

V g_list_2efoldl_24s966961137x2098673946(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eemitc_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s966961137x2098673946_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s966961137x2098673946(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s132236332x1381264820_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s132236332x1381264820_entry, 2, 0};

V g_list_2efoldl_24s132236332x1381264820(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 1));
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_2413 = (g_map_2elookup_24s1546226666x2146984184(v_t_2412, v_z_240));
    V v_t_2415;
    switch (heff_tag_of(v_a_2413)) {
    case TAG_Nothing: {
      v_t_2415 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_a_2414 = heff_field(v_a_2413, 0);
      heff_take_n(v_a_2413, 1ULL, 1);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_a_2413);
    }
    V v_t_2416 = (g_map_2einsert_24s1341440536x470972936(v_t_246, heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2415}), v_z_240));
    V t_0 = v_t_2416;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s132236332x1381264820_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s132236332x1381264820(a[0], a[1]);
}
Clo g_list_2emap_24s1339179958x587003135_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1339179958x587003135_entry, 1, 0};

V g_list_2emap_24s1339179958x587003135(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eemitc_2epubLine(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1339179958x587003135(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1339179958x587003135_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1339179958x587003135(a[0]);
}
Clo g_list_2emap_24s1328195927x21044528_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1328195927x21044528_entry, 2, 0};

V g_list_2emap_24s1328195927x21044528(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strSlice(heff_dup(v_x_242), heff_dup(v_lit_240), heff_strLength(v_x_242));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s1328195927x21044528(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1328195927x21044528_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1328195927x21044528(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_list_2efilter_24s1477606187x944222946_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {115, 116, 97, 116, 105, 99, 32, 67, 108, 111, 32, 103, 95}};
Clo g_list_2efilter_24s1477606187x944222946_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1477606187x944222946_entry, 1, 0};

V g_list_2efilter_24s1477606187x944222946(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), MK_INT(13LL)), ((V)&g_list_2efilter_24s1477606187x944222946_str0))) {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1477606187x944222946(v_xs_242))});
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1477606187x944222946_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1477606187x944222946(a[0]);
}
Clo g_list_2efoldl_24s153737048x1104410749_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s153737048x1104410749_entry, 10, 0};

V g_list_2efoldl_24s153737048x1104410749(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_z_248, V v_x3_249) {
top: ;
  switch (heff_tag_of(v_x3_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    return v_z_248;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x3_249, 0);
    V v_xs_2411 = heff_field(v_x3_249, 1);
    V v_ru_24x3_249_24Cons = heff_take_reuse_n(v_x3_249, 3ULL, 2);
    V v_a_2414;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_a_2412 = heff_dup(heff_field(v_x_2410, 0));
      v_a_2414 = heff_get(v_a_2412, LBL_key);
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_a_2415 = (g_heff_2eemitc_2elastDotGo(heff_dup(v_a_2414), heff_dup(v_lit_240), heff_dup(v_lit_241)));
    V v_t_2417;
    if (heff_intLt_c(heff_dup(v_a_2415), heff_dup(v_lit_242))) {
      heff_drop(v_a_2415);
      v_t_2417 = v_a_2414;
    } else {
      v_t_2417 = heff_strSlice(v_a_2414, heff_dup(v_lit_243), v_a_2415);
    }
    V v_a_2420;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_a_2418 = heff_dup(heff_field(v_x_2410, 0));
      v_a_2420 = heff_get(v_a_2418, LBL_key);
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    V v_a_2421 = (g_heff_2eemitc_2elastDotGo(heff_dup(v_a_2420), heff_dup(v_lit_244), heff_dup(v_lit_245)));
    V v_t_2423;
    if (heff_intLt_c(heff_dup(v_a_2421), heff_dup(v_lit_246))) {
      heff_drop(v_a_2421);
      v_t_2423 = v_a_2420;
    } else {
      v_t_2423 = heff_strSlice(v_a_2420, heff_dup(v_lit_247), v_a_2421);
    }
    V v_a_2424 = (g_map_2elookup_24s1546226666x2146984184(v_t_2423, v_z_248));
    V v_t_2426;
    switch (heff_tag_of(v_a_2424)) {
    case TAG_Nothing: {
      v_t_2426 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_a_2425 = heff_field(v_a_2424, 0);
      heff_take_n(v_a_2424, 1ULL, 1);
      v_t_2426 = v_a_2425;
      break;
    }
    default: heff_nomatch(v_a_2424);
    }
    V v_t_2427 = (g_map_2einsert_24s1341440536x470972936(v_t_2417, heff_tag_at(v_ru_24x3_249_24Cons, TAG_Cons, 2, (V[]){v_x_2410, v_t_2426}), v_z_248));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_t_2427;
    V t_9 = v_xs_2411;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_z_248 = t_8;
    v_x3_249 = t_9;
    goto top;
  }
  default: return heff_nomatch(v_x3_249);
  }
}
V g_list_2efoldl_24s153737048x1104410749_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s153737048x1104410749(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2emap_24s1653859898x762241412_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1653859898x762241412_entry, 1, 0};

V g_list_2emap_24s1653859898x762241412(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_t_245, LBL_body), (g_list_2emap_24s1653859898x762241412(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1653859898x762241412_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1653859898x762241412(a[0]);
}
Clo g_list_2efoldl_24s1984245835x1989432102_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1984245835x1989432102_entry, 2, 0};

V g_list_2efoldl_24s1984245835x1989432102(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      V v_t_246 = (g_heff_2eir_2eglobalsGo(heff_get(heff_dup(v_a_244), LBL_body)));
      v_t_247 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_get(v_a_244, LBL_key), (g_heff_2eir_2enubI(v_t_246))});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1984245835x1989432102_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1984245835x1989432102(a[0], a[1]);
}
Clo g_list_2emap_24s242536205x1745537053_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s242536205x1745537053_entry, 1, 0};

V g_list_2emap_24s242536205x1745537053(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_body), (g_list_2emap_24s242536205x1745537053(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s242536205x1745537053_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s242536205x1745537053(a[0]);
}
Clo g_list_2emap_24s673260838x1534389301_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s673260838x1534389301_entry, 6, 0};

V g_list_2emap_24s673260838x1534389301(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_strSlice(heff_dup(v_x_246), heff_dup(v_lit_240), heff_strLength(heff_dup(v_lit_241)));
    V v_t_2410;
    if (heff_strEq_c(v_t_248, heff_dup(v_lit_242))) {
      v_t_2410 = heff_tag(TAG_Just, 1, (V[]){(g_heff_2eemitc_2eidentAt(v_x_246, heff_dup(v_lit_243), heff_dup(v_lit_244)))});
    } else {
      heff_drop(v_x_246);
      v_t_2410 = NTAG(TAG_Nothing);
    }
    return heff_tag_at(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_list_2emap_24s673260838x1534389301(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247))});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s673260838x1534389301_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s673260838x1534389301(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2efoldl_24s1854884545x892082821_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1854884545x892082821_entry, 2, 0};

V g_list_2efoldl_24s1854884545x892082821(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2edoc_2e_3c_3e(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1854884545x892082821_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1854884545x892082821(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s1956448299x403813387_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s1956448299x403813387_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s1956448299x403813387_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_list_2emap_24s1956448299x403813387_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1956448299x403813387_entry, 1, 0};

V g_list_2emap_24s1956448299x403813387(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = (g_prelude_2esplitFrom(((V)&g_list_2emap_24s1956448299x403813387_str0), heff_get(v_x_241, LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_s_246 = ((V)&g_list_2emap_24s1956448299x403813387_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_s_246 = ({ V a_0 = heff_dup(g_heff_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_248;
    if (heff_strEq_c(heff_dup(v_s_246), ((V)&g_list_2emap_24s1956448299x403813387_str2))) {
      heff_drop(v_s_246);
      v_t_248 = NTAG(TAG_None);
    } else {
      v_t_248 = heff_tag(TAG_Text, 1, (V[]){v_s_246});
    }
    V v_t_249 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_248));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_list_2emap_24s1956448299x403813387(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1956448299x403813387_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1956448299x403813387(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s1990717753x185449813_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s1990717753x185449813_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s1990717753x185449813_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s1990717753x185449813_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_list_2emap_24s1990717753x185449813_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1990717753x185449813_entry, 1, 0};

V g_list_2emap_24s1990717753x185449813(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = (g_prelude_2esplitFrom(((V)&g_list_2emap_24s1990717753x185449813_str0), v_x_241, MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_s_246 = ((V)&g_list_2emap_24s1990717753x185449813_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_s_246 = ({ V a_0 = heff_dup(g_heff_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_248;
    if (heff_strEq_c(heff_dup(v_s_246), ((V)&g_list_2emap_24s1990717753x185449813_str2))) {
      heff_drop(v_s_246);
      v_t_248 = NTAG(TAG_None);
    } else {
      v_t_248 = heff_tag(TAG_Text, 1, (V[]){v_s_246});
    }
    V v_t_249 = (g_std_2edoc_2e_3c_3e(v_t_248, heff_tag(TAG_Text, 1, (V[]){((V)&g_list_2emap_24s1990717753x185449813_str3)})));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_list_2emap_24s1990717753x185449813(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1990717753x185449813_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1990717753x185449813(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_list_2eany_24s2049821274x1050838097_str0 = {{0x80000000u, K_STR, 0}, 12, 12, {45, 45, 32, 102, 109, 116, 58, 32, 115, 107, 105, 112}};
Clo g_list_2eany_24s2049821274x1050838097_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2049821274x1050838097_entry, 1, 0};

V g_list_2eany_24s2049821274x1050838097(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_s_243 = heff_get(heff_dup(v_x_241), LBL_text);
    V v_t_244 = (g_heff_2efmt_2elayout_2ertrimEnd(heff_dup(v_s_243), heff_strLength(heff_dup(v_s_243))));
    if (heff_strEq_c(heff_strSlice(v_s_243, MK_INT(0LL), v_t_244), ((V)&g_list_2eany_24s2049821274x1050838097_str0))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s2049821274x1050838097_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eany_24s2049821274x1050838097(a[0]); heff_drop(a[0]); return r;
}
Clo g_list_2emap_24s1494416374x1091091471_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1494416374x1091091471_entry, 1, 0};

V g_list_2emap_24s1494416374x1091091471(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_text), (g_list_2emap_24s1494416374x1091091471(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1494416374x1091091471_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1494416374x1091091471(a[0]);
}
Clo g_list_2emap_24s1936495134x1065491338_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1936495134x1065491338_entry, 1, 0};

V g_list_2emap_24s1936495134x1065491338(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2efmt_2elayout_2ertrimEnd(heff_dup(v_x_241), heff_strLength(heff_dup(v_x_241))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_x_241, MK_INT(0LL), v_t_243), (g_list_2emap_24s1936495134x1065491338(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1936495134x1065491338_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1936495134x1065491338(a[0]);
}
Clo g_list_2emap_24s278797158x626714787_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s278797158x626714787_entry, 7, 0};

V g_list_2emap_24s278797158x626714787(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkFieldPat: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      V v_ru_24x_247_24MkFieldPat = heff_take_reuse_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2eformat_2epatKey(v_a_2410));
      V v_t_2412 = heff_tag_at(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_a_2413 = heff_tag_at(v_ru_24x_247_24MkFieldPat, TAG_Cons, 2, (V[]){v_a_249, v_t_2412});
      V v_a_2414 = (g_list_2emap_24s1367796012x2117543847(heff_dup(v_lit_242), v_a_2413));
      V v_t_2417;
      switch (heff_tag_of(v_a_2414)) {
      case TAG_Nil: {
        v_t_2417 = heff_dup(v_lit_243);
        break;
      }
      case TAG_Cons: {
        V v_a_2415 = heff_field(v_a_2414, 0);
        V v_a_2416 = heff_field(v_a_2414, 1);
        heff_take_n(v_a_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = heff_dup(v_lit_244); V a_1 = v_a_2415; V a_2 = v_a_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2416); r_; });
        break;
      }
      default: heff_nomatch(v_a_2414);
      }
      v_t_2418 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2417, heff_dup(v_lit_245))));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2418, (g_list_2emap_24s278797158x626714787(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248))});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s278797158x626714787_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s278797158x626714787(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s37757954x1077935016_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s37757954x1077935016_entry, 1, 0};

V g_list_2emap_24s37757954x1077935016(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eformat_2epatKey(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s37757954x1077935016(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s37757954x1077935016_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s37757954x1077935016(a[0]);
}
Clo g_list_2emap_24s639165353x1158789933_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s639165353x1158789933_entry, 1, 0};

V g_list_2emap_24s639165353x1158789933(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_msg), (g_list_2emap_24s639165353x1158789933(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s639165353x1158789933_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s639165353x1158789933(a[0]);
}
Clo g_list_2emap_24s1895883353x1446382196_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1895883353x1446382196_entry, 2, 0};

V g_list_2emap_24s1895883353x1446382196(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_244 = heff_get(v_x_242, LBL_text);
    V v_t_245 = (g_heff_2efmt_2elayout_2ertrimEnd(heff_dup(v_a_244), heff_strLength(heff_dup(v_a_244))));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_a_244, heff_dup(v_lit_240), v_t_245), (g_list_2emap_24s1895883353x1446382196(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1895883353x1446382196_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1895883353x1446382196(a[0], a[1]);
}
Clo g_list_2eall_24s107199714x217634386_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s107199714x217634386_entry, 3, 0};

V g_list_2eall_24s107199714x217634386(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if (heff_intLe_c(heff_dup(v_lit_240), heff_dup(v_x_243))) {
      if (heff_intLe_c(heff_dup(v_x_243), heff_dup(v_lit_241))) {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      } else {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eall_24s107199714x217634386_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eall_24s107199714x217634386(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_list_2emap_24s546447922x1671206170_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s546447922x1671206170_entry, 2, 0};

V g_list_2emap_24s546447922x1671206170(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_244 = (g_prelude_2eparseInt(v_x_242));
    V v_t_246;
    switch (heff_tag_of(v_a_244)) {
    case TAG_Nothing: {
      v_t_246 = heff_dup(v_lit_240);
      break;
    }
    case TAG_Just: {
      V v_a_245 = heff_field(v_a_244, 0);
      heff_take_n(v_a_244, 1ULL, 1);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s546447922x1671206170(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s546447922x1671206170_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s546447922x1671206170(a[0], a[1]);
}
Clo g_list_2eall_24s1821787051x863686734_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1821787051x863686734_entry, 13, 0};

V g_list_2eall_24s1821787051x863686734(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_x2_2412) {
top: ;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    heff_drop(v_lit_2410);
    heff_drop(v_lit_2411);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    V v_t_2416;
    if (heff_intLe_c(heff_dup(v_lit_240), heff_dup(v_x_2413))) {
      v_t_2416 = heff_intLe(heff_dup(v_x_2413), heff_dup(v_lit_241));
    } else {
      v_t_2416 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      V t_10 = v_lit_2410;
      V t_11 = v_lit_2411;
      V t_12 = v_xs_2414;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_lit_2411 = t_11;
      v_x2_2412 = t_12;
      goto top;
    }
    case TAG_False: {
      V v_t_2423;
      if (heff_intLe_c(heff_dup(v_lit_242), heff_dup(v_x_2413))) {
        if (heff_intLe_c(heff_dup(v_x_2413), heff_dup(v_lit_243))) {
          v_t_2423 = NTAG(TAG_True);
        } else {
          if (heff_intLe_c(heff_dup(v_lit_244), heff_dup(v_x_2413))) {
            if (heff_intLe_c(heff_dup(v_x_2413), heff_dup(v_lit_245))) {
              v_t_2423 = NTAG(TAG_True);
            } else {
              v_t_2423 = heff_intEq(heff_dup(v_x_2413), heff_dup(v_lit_246));
            }
          } else {
            v_t_2423 = heff_intEq(heff_dup(v_x_2413), heff_dup(v_lit_247));
          }
        }
      } else {
        if (heff_intLe_c(heff_dup(v_lit_248), heff_dup(v_x_2413))) {
          if (heff_intLe_c(heff_dup(v_x_2413), heff_dup(v_lit_249))) {
            v_t_2423 = NTAG(TAG_True);
          } else {
            v_t_2423 = heff_intEq(heff_dup(v_x_2413), heff_dup(v_lit_2410));
          }
        } else {
          v_t_2423 = heff_intEq(heff_dup(v_x_2413), heff_dup(v_lit_2411));
        }
      }
      switch (heff_tag_of(v_t_2423)) {
      case TAG_True: {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_lit_245;
        V t_6 = v_lit_246;
        V t_7 = v_lit_247;
        V t_8 = v_lit_248;
        V t_9 = v_lit_249;
        V t_10 = v_lit_2410;
        V t_11 = v_lit_2411;
        V t_12 = v_xs_2414;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_lit_245 = t_5;
        v_lit_246 = t_6;
        v_lit_247 = t_7;
        v_lit_248 = t_8;
        v_lit_249 = t_9;
        v_lit_2410 = t_10;
        v_lit_2411 = t_11;
        v_x2_2412 = t_12;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        heff_drop(v_lit_243);
        heff_drop(v_lit_244);
        heff_drop(v_lit_245);
        heff_drop(v_lit_246);
        heff_drop(v_lit_247);
        heff_drop(v_lit_248);
        heff_drop(v_lit_249);
        heff_drop(v_lit_2410);
        heff_drop(v_lit_2411);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2423);
      }
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_list_2eall_24s1821787051x863686734_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eall_24s1821787051x863686734(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12]); heff_drop(a[12]); return r;
}
Clo g_list_2ezipWith_24s504224228x1938399024_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s504224228x1938399024_entry, 2, 0};

V g_list_2ezipWith_24s504224228x1938399024(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_tag_at(v_ru_24xs_240_24Cons, TAG_MkPair, 2, (V[]){heff_get(v_y_244, LBL_name), v_x_242});
      return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2ezipWith_24s504224228x1938399024(v_xs2_243, v_ys2_245))});
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s504224228x1938399024_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s504224228x1938399024(a[0], a[1]);
}
Clo g_list_2emap_24s2137530563x1198821735_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2137530563x1198821735_entry, 4, 0};

V g_list_2emap_24s2137530563x1198821735(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_get(heff_dup(v_x_244), LBL_path), heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_get(heff_dup(v_x_244), LBL_version), heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_get(v_x_244, LBL_hash), heff_dup(v_lit_242))))));
    return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s2137530563x1198821735(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s2137530563x1198821735_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2137530563x1198821735(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emerge_24s1191944780x1350694468_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1191944780x1350694468_entry, 2, 0};

V g_list_2emerge_24s1191944780x1350694468(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = (g_heff_2eproject_2esumBefore(heff_dup(v_x_242), heff_dup(v_y_244)));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s1191944780x1350694468(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s1191944780x1350694468(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1191944780x1350694468_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1191944780x1350694468(a[0], a[1]);
}
Clo g_list_2esortBy_24s1813115913x1547761659_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1813115913x1547761659_entry, 1, 0};

V g_list_2esortBy_24s1813115913x1547761659(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s1813115913x1547761659(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s1813115913x1547761659(v_t_2411));
      return (g_list_2emerge_24s1191944780x1350694468(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1813115913x1547761659_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1813115913x1547761659(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_list_2emap_24s1318342530x1153530785_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {123, 32, 110, 97, 109, 101, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_list_2emap_24s1318342530x1153530785_str1 = {{0x80000000u, K_STR, 0}, 9, 9, {44, 32, 112, 97, 116, 104, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_list_2emap_24s1318342530x1153530785_str2 = {{0x80000000u, K_STR, 0}, 12, 12, {44, 32, 118, 101, 114, 115, 105, 111, 110, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_list_2emap_24s1318342530x1153530785_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
Clo g_list_2emap_24s1318342530x1153530785_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1318342530x1153530785_entry, 1, 0};

V g_list_2emap_24s1318342530x1153530785(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eproject_2equoted(heff_get(heff_dup(v_x_241), LBL_name)));
    V v_t_244 = (g_heff_2eproject_2equoted(heff_get(heff_dup(v_x_241), LBL_path)));
    V v_t_245 = (g_heff_2eproject_2equoted(heff_get(v_x_241, LBL_version)));
    V v_t_246 = heff_strAppend(((V)&g_list_2emap_24s1318342530x1153530785_str0), heff_strAppend(v_t_243, heff_strAppend(((V)&g_list_2emap_24s1318342530x1153530785_str1), heff_strAppend(v_t_244, heff_strAppend(((V)&g_list_2emap_24s1318342530x1153530785_str2), heff_strAppend(v_t_245, ((V)&g_list_2emap_24s1318342530x1153530785_str3)))))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_list_2emap_24s1318342530x1153530785(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1318342530x1153530785_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1318342530x1153530785(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_list_2emap_24s340479869x2094246170_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {123, 32, 110, 97, 109, 101, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_list_2emap_24s340479869x2094246170_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {44, 32, 100, 105, 114, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_list_2emap_24s340479869x2094246170_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
Clo g_list_2emap_24s340479869x2094246170_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s340479869x2094246170_entry, 1, 0};

V g_list_2emap_24s340479869x2094246170(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eproject_2equoted(heff_get(heff_dup(v_x_241), LBL_name)));
    V v_t_244 = (g_heff_2eproject_2equoted(heff_get(v_x_241, LBL_dir)));
    V v_t_245 = heff_strAppend(((V)&g_list_2emap_24s340479869x2094246170_str0), heff_strAppend(v_t_243, heff_strAppend(((V)&g_list_2emap_24s340479869x2094246170_str1), heff_strAppend(v_t_244, ((V)&g_list_2emap_24s340479869x2094246170_str2)))));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s340479869x2094246170(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s340479869x2094246170_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s340479869x2094246170(a[0]);
}
Clo g_list_2emap_24s56748846x104951169_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s56748846x104951169_entry, 1, 0};

V g_list_2emap_24s56748846x104951169(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_x_241), LBL_name), heff_get(v_x_241, LBL_path)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s56748846x104951169(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s56748846x104951169_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s56748846x104951169(a[0]);
}
Clo g_list_2efoldl_24s1507142368x592417200_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1507142368x592417200_entry, 2, 0};

V g_list_2efoldl_24s1507142368x592417200(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    if (heff_strEq_c(heff_get(heff_dup(v_x_242), LBL_path), heff_get(heff_dup(v_z_240), LBL_path))) {
      V v_a_245 = (g_heff_2eproject_2eversion(heff_get(heff_dup(v_x_242), LBL_version)));
      V v_t_247;
      switch (heff_tag_of(v_a_245)) {
      case TAG_Nothing: {
        v_t_247 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_a_246 = heff_field(v_a_245, 0);
        heff_take_n(v_a_245, 1ULL, 1);
        v_t_247 = v_a_246;
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      V v_a_248 = (g_heff_2eproject_2eversion(heff_get(heff_dup(v_z_240), LBL_version)));
      V v_t_2410;
      switch (heff_tag_of(v_a_248)) {
      case TAG_Nothing: {
        v_t_2410 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_a_249 = heff_field(v_a_248, 0);
        heff_take_n(v_a_248, 1ULL, 1);
        v_t_2410 = v_a_249;
        break;
      }
      default: heff_nomatch(v_a_248);
      }
      V v_t_2411 = ({ V a_0 = v_t_247; V a_1 = v_t_2410; V r_ = (g_heff_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_247); heff_drop(v_t_2410); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop(v_z_240);
        v_t_2412 = heff_dup(v_x_242);
        break;
      }
      case TAG_False: {
        v_t_2412 = v_z_240;
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
    } else {
      v_t_2412 = v_z_240;
    }
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1507142368x592417200_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1507142368x592417200(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_list_2efoldl_24s1590278025x237389125_lam0(V self, V *args);
Clo g_list_2efoldl_24s1590278025x237389125_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1590278025x237389125_entry, 2, 0};

V g_list_2efoldl_24s1590278025x237389125(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = (g_list_2eany(heff_clo(g_list_2efoldl_24s1590278025x237389125_lam0, 1, 1, (V[]){heff_dup(v_x_242)}), v_z_240));
    V v_t_247;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_247 = v_z_240;
      break;
    }
    case TAG_False: {
      V v_t_246 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
      v_t_247 = (g_prelude_2e_2b_2b(v_z_240, v_t_246));
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1590278025x237389125_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1590278025x237389125(a[0], a[1]);
}
V g_list_2efoldl_24s1590278025x237389125_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_a_244, LBL_path), heff_get(v_x_242, LBL_path));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_list_2emap_24s1128256044x1808758821_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
Clo g_list_2emap_24s1128256044x1808758821_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1128256044x1808758821_entry, 1, 0};

V g_list_2emap_24s1128256044x1808758821(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_x_241)), MK_INT(3LL));
    V v_t_244 = heff_strSlice(heff_dup(v_x_241), v_t_243, heff_strLength(heff_dup(v_x_241)));
    V v_t_247;
    if (heff_strEq_c(v_t_244, ((V)&g_list_2emap_24s1128256044x1808758821_str0))) {
      V v_t_246 = heff_intSub(heff_strLength(heff_dup(v_x_241)), MK_INT(3LL));
      v_t_247 = heff_strSlice(v_x_241, MK_INT(0LL), v_t_246);
    } else {
      v_t_247 = v_x_241;
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_list_2emap_24s1128256044x1808758821(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1128256044x1808758821_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1128256044x1808758821(a[0]);
}
Clo g_list_2emap_24s998052584x332015457_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s998052584x332015457_entry, 1, 0};

V g_list_2emap_24s998052584x332015457(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_path), (g_list_2emap_24s998052584x332015457(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s998052584x332015457_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s998052584x332015457(a[0]);
}
Clo g_list_2efoldl_24s1009481344x1999114184_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1009481344x1999114184_entry, 2, 0};

V g_list_2efoldl_24s1009481344x1999114184(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2elocals_2epatternBinders(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1009481344x1999114184_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1009481344x1999114184(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s2020645692x239769631_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2020645692x239769631_entry, 2, 0};

V g_list_2efoldl_24s2020645692x239769631(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkFieldPat: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2elocals_2epatternBinders(heff_dup(v_a_245)));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2020645692x239769631_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s2020645692x239769631(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s1282605757x1399508316_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1282605757x1399508316_entry, 1, 0};

V g_list_2emap_24s1282605757x1399508316(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_use), (g_list_2emap_24s1282605757x1399508316(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1282605757x1399508316_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1282605757x1399508316(a[0]);
}
Clo g_list_2efilter_24s518854376x1845646382_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s518854376x1845646382_entry, 1, 0};

V g_list_2efilter_24s518854376x1845646382(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_field);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s518854376x1845646382(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s518854376x1845646382_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s518854376x1845646382(a[0]);
}
Clo g_list_2emap_24s936489142x1270771276_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s936489142x1270771276_entry, 1, 0};

V g_list_2emap_24s936489142x1270771276(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_binder), LBL_name);
    V v_t_244 = heff_get(heff_get(heff_dup(v_x_241), LBL_binder), LBL_span);
    V v_t_245 = heff_rec(3, shape_name__field__use, (V[]){v_t_243, v_t_244, heff_get(v_x_241, LBL_use)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_list_2emap_24s936489142x1270771276(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s936489142x1270771276_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s936489142x1270771276(a[0]);
}
Clo g_list_2efilter_24s1985229710x1815452821_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1985229710x1815452821_entry, 1, 0};

V g_list_2efilter_24s1985229710x1815452821(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_binder), LBL_field);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1985229710x1815452821(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1985229710x1815452821_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1985229710x1815452821(a[0]);
}
Clo g_list_2efoldl_24s1803604645x588057571_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1803604645x588057571_entry, 2, 0};

V g_list_2efoldl_24s1803604645x588057571(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = (g_heff_2elocals_2edeclaration(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_z_240), LBL_binders), heff_get(heff_dup(v_a_244), LBL_binders)));
    V v_t_246 = (g_prelude_2e_2b_2b(heff_get(v_z_240, LBL_uses), heff_get(v_a_244, LBL_uses)));
    V t_0 = heff_rec(2, shape_binders__uses, (V[]){v_t_245, v_t_246});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1803604645x588057571_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1803604645x588057571(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emerge_24s1992744726x1360756089_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1992744726x1360756089_entry, 2, 0};

V g_list_2emerge_24s1992744726x1360756089(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_get(heff_dup(v_x_242), LBL_start), heff_get(heff_dup(v_y_244), LBL_start))) {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s1992744726x1360756089(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      } else {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s1992744726x1360756089(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1992744726x1360756089_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1992744726x1360756089(a[0], a[1]);
}
Clo g_list_2esortBy_24s1946011436x1651136814_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1946011436x1651136814_entry, 1, 0};

V g_list_2esortBy_24s1946011436x1651136814(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s1946011436x1651136814(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s1946011436x1651136814(v_t_2411));
      return (g_list_2emerge_24s1992744726x1360756089(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1946011436x1651136814_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1946011436x1651136814(a[0]);
}
Clo g_list_2emerge_24s241948340x1176187119_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s241948340x1176187119_entry, 2, 0};

V g_list_2emerge_24s241948340x1176187119(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_end);
      V v_t_247 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
      V v_t_248 = heff_get(heff_get(heff_dup(v_y_244), LBL_span), LBL_end);
      V v_t_249 = heff_get(heff_get(heff_dup(v_y_244), LBL_span), LBL_start);
      if (heff_intLe_c(heff_intSub(v_t_246, v_t_247), heff_intSub(v_t_248, v_t_249))) {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s241948340x1176187119(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      } else {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s241948340x1176187119(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s241948340x1176187119_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s241948340x1176187119(a[0], a[1]);
}
Clo g_list_2esortBy_24s1807141477x2081348872_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1807141477x2081348872_entry, 1, 0};

V g_list_2esortBy_24s1807141477x2081348872(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s1807141477x2081348872(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s1807141477x2081348872(v_t_2411));
      return (g_list_2emerge_24s241948340x1176187119(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1807141477x2081348872_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1807141477x2081348872(a[0]);
}
Clo g_list_2emerge_24s1292713123x1836632175_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1292713123x1836632175_entry, 2, 0};

V g_list_2emerge_24s1292713123x1836632175(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_strLt_c(heff_get(heff_dup(v_y_244), LBL_label), heff_get(heff_dup(v_x_242), LBL_label))) {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s1292713123x1836632175(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      } else {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s1292713123x1836632175(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1292713123x1836632175_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1292713123x1836632175(a[0], a[1]);
}
Clo g_list_2esortBy_24s33211212x1318186357_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s33211212x1318186357_entry, 1, 0};

V g_list_2esortBy_24s33211212x1318186357(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s33211212x1318186357(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s33211212x1318186357(v_t_2411));
      return (g_list_2emerge_24s1292713123x1836632175(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s33211212x1318186357_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s33211212x1318186357(a[0]);
}
Clo g_list_2emap_24s1986592085x2028054718_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1986592085x2028054718_entry, 1, 0};

V g_list_2emap_24s1986592085x2028054718(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_TagVariant: {
        V v_t_245 = heff_field(v_x11_243, 0);
        V v_tsp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 3);
        v_t_249 = heff_tag(TAG_Just, 1, (V[]){heff_rec(2, shape_name__span, (V[]){v_t_245, v_tsp_246})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_249 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_list_2emap_24s1986592085x2028054718(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1986592085x2028054718_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1986592085x2028054718(a[0]);
}
Clo g_list_2emap_24s1709449575x435379565_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1709449575x435379565_entry, 1, 0};

V g_list_2emap_24s1709449575x435379565(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkEquation: {
        V v_fsp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 2ULL, 4);
        v_t_249 = v_fsp_246;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, (g_list_2emap_24s1709449575x435379565(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1709449575x435379565_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1709449575x435379565(a[0]);
}
Clo g_list_2emap_24s329401138x269902185_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s329401138x269902185_entry, 1, 0};

V g_list_2emap_24s329401138x269902185(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclareField: {
        V v_x_245 = heff_field(v_x11_243, 0);
        V v_sp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 4);
        v_t_2410 = heff_tag(TAG_Just, 1, (V[]){heff_rec(2, shape_name__span, (V[]){v_x_245, v_sp_246})});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_list_2emap_24s329401138x269902185(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s329401138x269902185_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s329401138x269902185(a[0]);
}
Clo g_list_2emap_24s1557660835x11088490_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1557660835x11088490_entry, 1, 0};

V g_list_2emap_24s1557660835x11088490(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_span), (g_list_2emap_24s1557660835x11088490(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1557660835x11088490_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1557660835x11088490(a[0]);
}
Clo g_list_2efoldl_24s1415479944x2009929531_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1415479944x2009929531_entry, 3, 0};

V g_list_2efoldl_24s1415479944x2009929531(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2427;
    switch (heff_tag_of(v_t_247)) {
    case TAG_DeclEquations: {
      V v_a_248 = heff_field(v_t_247, 0);
      V v_a_249 = heff_field(v_t_247, 1);
      heff_take_n(v_t_247, 3ULL, 4);
      v_t_2427 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec(3, shape_name__kind__span, (V[]){v_a_248, heff_dup(v_lit_240), v_a_249}), NTAG(TAG_Nil)});
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_t_247, 0ULL, 5);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      v_t_2427 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_t_247, 0ULL, 4);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      v_t_2427 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      v_t_2427 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      v_t_2427 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      v_t_2427 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2427, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_2428;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1415479944x2009929531_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1415479944x2009929531(a[0], a[1], a[2]);
}
Clo g_list_2efind_24s2127599001x720452116_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s2127599001x720452116_entry, 1, 0};

V g_list_2efind_24s2127599001x720452116(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_target), LBL_member);
    V v_a_245;
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      v_a_245 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_a_245 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    switch (heff_tag_of(v_a_245)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_241)});
    }
    default: return heff_nomatch(v_a_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efind_24s2127599001x720452116_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efind_24s2127599001x720452116(a[0]); heff_drop(a[0]); return r;
}
Clo g_list_2efilter_24s1013516255x907593536_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1013516255x907593536_entry, 1, 0};

V g_list_2efilter_24s1013516255x907593536(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_target), LBL_member);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1013516255x907593536(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1013516255x907593536_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1013516255x907593536(a[0]);
}
Clo g_list_2efoldl_24s1978402334x1625948189_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1978402334x1625948189_entry, 2, 0};

V g_list_2efoldl_24s1978402334x1625948189(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1978402334x1625948189_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1978402334x1625948189(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1550111079x1462185085_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1550111079x1462185085_entry, 2, 0};

V g_list_2efoldl_24s1550111079x1462185085(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_DeclareField: {
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_t_2410 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_248)));
        V v_t_2412;
        switch (heff_tag_of(v_a_249)) {
        case TAG_Nothing: {
          v_t_2412 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_a_2411 = heff_field(v_a_249, 0);
          v_t_2412 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_2411)));
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        v_t_2414 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2412));
        break;
      }
      case TAG_BadFieldDecl: {
        V v_a_2413 = heff_field(v_a_244, 0);
        v_t_2414 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_2413)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2414, v_z_240));
    V t_0 = v_t_2415;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1550111079x1462185085_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1550111079x1462185085(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1376308465x96441915_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1376308465x96441915_entry, 2, 0};

V g_list_2efoldl_24s1376308465x96441915(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_248 = heff_field(v_a_244, 2);
        V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_a_248)));
        v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s1978402334x1625948189(a_0, a_1)); heff_drop(v_t_249); r_; });
        break;
      }
      case TAG_BadVariant: {
        V v_a_2410 = heff_field(v_a_244, 0);
        v_t_2411 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_2410)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2411, v_z_240));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1376308465x96441915_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1376308465x96441915(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s361359697x457944167_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s361359697x457944167_entry, 2, 0};

V g_list_2efoldl_24s361359697x457944167(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2410 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_248)));
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_249 = heff_field(v_a_244, 0);
        v_t_2410 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_249)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s361359697x457944167_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s361359697x457944167(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s356415811x1271115937_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s356415811x1271115937_entry, 2, 0};

V g_list_2efoldl_24s356415811x1271115937(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_247)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s356415811x1271115937_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s356415811x1271115937(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1193656352x574625876_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1193656352x574625876_entry, 2, 0};

V g_list_2efoldl_24s1193656352x574625876(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_StmtBind: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_248)));
        break;
      }
      case TAG_StmtLet: {
        V v_a_2410 = heff_field(v_a_244, 1);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_2410)));
        break;
      }
      case TAG_StmtExpr: {
        V v_a_2411 = heff_field(v_a_244, 0);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_2411)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1193656352x574625876_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1193656352x574625876(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s339301719x719980567_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s339301719x719980567_entry, 2, 0};

V g_list_2efoldl_24s339301719x719980567(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkEquation: {
        V v_a_249 = heff_field(v_a_244, 3);
        v_t_2410 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_249)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s339301719x719980567_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s339301719x719980567(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1948718100x381870663_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1948718100x381870663_entry, 2, 0};

V g_list_2efoldl_24s1948718100x381870663(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_ExplicitParam: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_248)));
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2411 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2equery_2elocalTermF_24s1158823265x601317201(heff_dup(v_a_2411)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1948718100x381870663_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1948718100x381870663(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1393779768x1672249294_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1393779768x1672249294_entry, 2, 0};

V g_list_2efoldl_24s1393779768x1672249294(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2equery_2elocalDeclF_24s535437546x2025255677(v_x_242));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1393779768x1672249294_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1393779768x1672249294(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emerge_24s1426753428x241553373_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1426753428x241553373_entry, 2, 0};

V g_list_2emerge_24s1426753428x241553373(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_246 = heff_get(heff_get(heff_dup(v_x_242), LBL_span), LBL_start);
      V v_t_247 = heff_get(heff_get(heff_dup(v_y_244), LBL_span), LBL_start);
      if (heff_intLe_c(v_t_246, v_t_247)) {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2emerge_24s1426753428x241553373(v_xs2_243, heff_tag(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245})))});
      } else {
        return heff_tag_at(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, (g_list_2emerge_24s1426753428x241553373(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245))});
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1426753428x241553373_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1426753428x241553373(a[0], a[1]);
}
Clo g_list_2esortBy_24s1384104572x138718272_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s1384104572x138718272_entry, 1, 0};

V g_list_2esortBy_24s1384104572x138718272(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = heff_intDiv(v_t_245, MK_INT(2LL));
      V v_t_247 = (g_list_2etake(v_t_246, heff_dup(v_xs_240)));
      V v_t_248 = (g_list_2esortBy_24s1384104572x138718272(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = heff_intDiv(v_t_249, MK_INT(2LL));
      V v_t_2411 = (g_list_2edrop(v_t_2410, v_xs_240));
      V v_t_2412 = (g_list_2esortBy_24s1384104572x138718272(v_t_2411));
      return (g_list_2emerge_24s1426753428x241553373(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s1384104572x138718272_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s1384104572x138718272(a[0]);
}
Clo g_list_2efoldl_24s1798985515x221942800_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1798985515x221942800_entry, 2, 0};

V g_list_2efoldl_24s1798985515x221942800(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_a_244), v_z_240));
      switch (heff_tag_of(v_a_246)) {
      case TAG_Nothing: {
        v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_a_244), heff_dup(v_a_245), v_z_240));
        break;
      }
      case TAG_Just: {
        heff_take_n(v_a_246, 0ULL, 1);
        v_t_248 = v_z_240;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1798985515x221942800_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1798985515x221942800(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s1751623379x2107197849_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1751623379x2107197849_entry, 8, 0};

V g_list_2emap_24s1751623379x2107197849(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = heff_get(heff_dup(v_x_248), LBL_assoc);
    V v_t_2411;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_AssocLeft: {
      v_t_2411 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2411 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2411 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2412 = heff_get(heff_dup(v_x_248), LBL_ops);
    V v_t_2415;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nil: {
      v_t_2415 = heff_dup(v_lit_245);
      break;
    }
    case TAG_Cons: {
      V v_a_2413 = heff_field(v_t_2412, 0);
      V v_a_2414 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = heff_dup(v_lit_246); V a_1 = v_a_2413; V a_2 = v_a_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2414); r_; });
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2416 = heff_strAppend(heff_get(v_x_248, LBL_id), heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_intShow(v_t_2411), heff_strAppend(heff_dup(v_lit_244), v_t_2415))));
    return heff_tag_at(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_t_2416, (g_list_2emap_24s1751623379x2107197849(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_xs_249))});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s1751623379x2107197849_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1751623379x2107197849(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2emap_24s1405724801x1371482992_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1405724801x1371482992_entry, 2, 0};

V g_list_2emap_24s1405724801x1371482992(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_get(heff_dup(v_x_242), LBL_tighter), heff_strAppend(heff_dup(v_lit_240), heff_get(v_x_242, LBL_looser)));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s1405724801x1371482992(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1405724801x1371482992_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1405724801x1371482992(a[0], a[1]);
}
Clo g_list_2efoldl_24s775969440x1318400394_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s775969440x1318400394_entry, 3, 0};

V g_list_2efoldl_24s775969440x1318400394(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength(heff_dup(v_x_243)));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(heff_dup(v_lit_240), v_x_243));
    V v_t_247 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_248;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s775969440x1318400394_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s775969440x1318400394(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1801866615x1952232028_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1801866615x1952232028_entry, 9, 0};

V g_list_2efoldl_24s1801866615x1952232028(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_z_247, V v_x3_248) {
top: ;
  switch (heff_tag_of(v_x3_248)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return v_z_247;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x3_248, 0);
    V v_xs_2410 = heff_field(v_x3_248, 1);
    V v_ru_24x3_248_24Cons = heff_take_reuse_n(v_x3_248, 3ULL, 2);
    V v_a_2411 = heff_get(heff_dup(v_x_249), LBL_id);
    V v_t_2412 = heff_intShow(heff_strLength(heff_dup(v_a_2411)));
    V v_t_2413 = heff_strAppend(v_t_2412, heff_strAppend(heff_dup(v_lit_240), v_a_2411));
    V v_t_2414 = heff_get(heff_dup(v_x_249), LBL_assoc);
    V v_t_2415;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_AssocLeft: {
      v_t_2415 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2415 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2415 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_a_2416 = heff_get(v_x_249, LBL_ops);
    V v_t_2417 = (g_list_2efoldl_24s1116451536x2100070357(heff_dup(v_lit_244), heff_dup(v_lit_245), v_a_2416));
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_2416));
    V v_t_2419 = heff_tag_at(v_ru_24x3_248_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_t_2417), (g_list_2efoldl_24s775969440x1318400394(heff_dup(v_lit_246), NTAG(TAG_Nil), v_t_2418))});
    V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){heff_intShow(v_t_2415), v_t_2419});
    V v_t_2421 = (g_prelude_2e_2b_2b(heff_tag(TAG_Cons, 2, (V[]){v_t_2413, v_t_2420}), v_z_247));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_t_2421;
    V t_8 = v_xs_2410;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_z_247 = t_7;
    v_x3_248 = t_8;
    goto top;
  }
  default: return heff_nomatch(v_x3_248);
  }
}
V g_list_2efoldl_24s1801866615x1952232028_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1801866615x1952232028(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_list_2efoldl_24s647105187x1503385827_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s647105187x1503385827_entry, 4, 0};

V g_list_2efoldl_24s647105187x1503385827(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_a_246 = heff_get(heff_dup(v_x_244), LBL_tighter);
    V v_t_247 = heff_intShow(heff_strLength(heff_dup(v_a_246)));
    V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(heff_dup(v_lit_240), v_a_246));
    V v_a_249 = heff_get(v_x_244, LBL_looser);
    V v_t_2410 = heff_intShow(heff_strLength(heff_dup(v_a_249)));
    V v_t_2411 = heff_strAppend(v_t_2410, heff_strAppend(heff_dup(v_lit_241), v_a_249));
    V v_t_2412 = heff_tag_at(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    V v_t_2413 = (g_prelude_2e_2b_2b(heff_tag(TAG_Cons, 2, (V[]){v_t_248, v_t_2412}), v_z_242));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2413;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s647105187x1503385827_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s647105187x1503385827(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1176007509x671449441_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1176007509x671449441_entry, 5, 0};

V g_list_2emap_24s1176007509x671449441(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 2ULL, 2);
      v_a_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_a_2410 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(v_a_249), heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_t_2415;
    switch (heff_tag_of(v_a_2410)) {
    case TAG_Nil: {
      v_t_2415 = heff_tag_at(v_ru_24x2_244_24Cons, TAG_MkPair, 2, (V[]){v_a_249, heff_dup(v_lit_242)});
      break;
    }
    case TAG_Cons: {
      V v_a_2411 = heff_field(v_a_2410, 0);
      V v_a_2412 = heff_field(v_a_2410, 1);
      heff_take_n(v_a_2410, 3ULL, 2);
      switch (heff_tag_of(v_a_2412)) {
      case TAG_Nil: {
        heff_drop(v_a_2411);
        v_t_2415 = heff_tag_at(v_ru_24x2_244_24Cons, TAG_MkPair, 2, (V[]){v_a_249, heff_dup(v_lit_243)});
        break;
      }
      case TAG_Cons: {
        V v_a_2413 = heff_field(v_a_2412, 0);
        heff_take_n(v_a_2412, 1ULL, 2);
        heff_drop(v_a_249);
        v_t_2415 = heff_tag_at(v_ru_24x2_244_24Cons, TAG_MkPair, 2, (V[]){v_a_2411, v_a_2413});
        break;
      }
      default: heff_nomatch(v_a_2412);
      }
      break;
    }
    default: heff_nomatch(v_a_2410);
    }
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2415, (g_list_2emap_24s1176007509x671449441(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246))});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s1176007509x671449441_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1176007509x671449441(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efilter_24s352363709x250826586_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s352363709x250826586_entry, 2, 0};

V g_list_2efilter_24s352363709x250826586(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_get(heff_dup(v_x_242), LBL_parent), heff_dup(v_lit_240))) {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_list_2efilter_24s352363709x250826586(v_lit_240, v_xs_243))});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s352363709x250826586_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s352363709x250826586(a[0], a[1]);
}
Clo g_list_2efoldl_24s2140388286x271582403_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2140388286x271582403_entry, 2, 0};

V g_list_2efoldl_24s2140388286x271582403(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_get(heff_dup(v_z_240), LBL_errors)});
    V v_t_245 = heff_rec(5, shape_sources__errors__paths__package__packages, (V[]){heff_get(heff_dup(v_z_240), LBL_sources), v_t_244, heff_get(heff_dup(v_z_240), LBL_paths), heff_get(heff_dup(v_z_240), LBL_package), heff_get(v_z_240, LBL_packages)});
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2140388286x271582403_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2140388286x271582403(a[0], a[1]);
}
Clo g_list_2eany_24s664291608x697916754_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s664291608x697916754_entry, 1, 0};

V g_list_2eany_24s664291608x697916754(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_243 = (g_list_2efilter_24s1551648278x579137009(heff_get(heff_dup(v_x_241), LBL_diags)));
    V v_a_246;
    switch (heff_tag_of(v_a_243)) {
    case TAG_Nil: {
      v_a_246 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_a_243, 0ULL, 2);
      v_a_246 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    switch (heff_tag_of(v_a_246)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_a_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s664291608x697916754_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eany_24s664291608x697916754(a[0]); heff_drop(a[0]); return r;
}
Clo g_list_2emap_24s445281531x1187441763_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s445281531x1187441763_entry, 1, 0};

V g_list_2emap_24s445281531x1187441763(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec(2, shape_name__key, (V[]){heff_get(heff_dup(v_x_241), LBL_name), heff_get(v_x_241, LBL_key)});
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s445281531x1187441763(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s445281531x1187441763_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s445281531x1187441763(a[0]);
}
Clo g_list_2emap_24s716972220x498274748_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s716972220x498274748_entry, 1, 0};

V g_list_2emap_24s716972220x498274748(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_get(heff_dup(v_x_241), LBL_name), heff_get(v_x_241, LBL_key)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s716972220x498274748(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s716972220x498274748_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s716972220x498274748(a[0]);
}
Clo g_list_2efilter_24s1966237873x2134891024_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1966237873x2134891024_entry, 3, 0};

V g_list_2efilter_24s1966237873x2134891024(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_intSub(heff_strLength(heff_dup(v_x_243)), heff_strLength(heff_dup(v_lit_240)));
    V v_t_246 = heff_strSlice(heff_dup(v_x_243), v_t_245, heff_strLength(heff_dup(v_x_243)));
    if (heff_strEq_c(v_t_246, heff_dup(v_lit_241))) {
      return heff_tag_at(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_list_2efilter_24s1966237873x2134891024(v_lit_240, v_lit_241, v_xs_244))});
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24s1966237873x2134891024_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1966237873x2134891024(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s221185798x216232137_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s221185798x216232137_entry, 2, 0};

V g_list_2efoldl_24s221185798x216232137(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get(heff_get(heff_dup(v_x_242), LBL_build), LBL_ships);
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s221185798x216232137_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s221185798x216232137(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2efoldl_24s1875482002x8607380_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1875482002x8607380_entry, 4, 0};

V g_list_2efoldl_24s1875482002x8607380(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_a_246 = (g_list_2efilter_24s1551648278x579137009(heff_get(heff_dup(v_x_244), LBL_diags)));
    V v_t_247 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_a_246; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_a_246); r_; });
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_intAdd(v_z_242, v_t_247);
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1875482002x8607380_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efoldl_24s1875482002x8607380(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
Clo g_list_2emap_24s1395929658x2029872776_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1395929658x2029872776_entry, 1, 0};

V g_list_2emap_24s1395929658x2029872776(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_module), (g_list_2emap_24s1395929658x2029872776(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1395929658x2029872776_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1395929658x2029872776(a[0]);
}
Clo g_list_2efilter_24s1032170133x1551961113_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1032170133x1551961113_entry, 1, 0};

V g_list_2efilter_24s1032170133x1551961113(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_get(heff_dup(v_x_241), LBL_watch), LBL_holds);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s1032170133x1551961113(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1032170133x1551961113_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1032170133x1551961113(a[0]);
}
Clo g_list_2efilter_24s792047172x367808768_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s792047172x367808768_entry, 1, 0};

V g_list_2efilter_24s792047172x367808768(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_ok);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s792047172x367808768(v_xs_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s792047172x367808768_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s792047172x367808768(a[0]);
}
Clo g_list_2emap_24s1420651609x666245096_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1420651609x666245096_entry, 1, 0};

V g_list_2emap_24s1420651609x666245096(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_x_241});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1420651609x666245096(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1420651609x666245096(a[0]);
}
Clo g_list_2emap_24s292465422x1926397249_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s292465422x1926397249_entry, 6, 0};

V g_list_2emap_24s292465422x1926397249(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_246, 0);
      V v_a_249 = heff_field(v_x_246, 1);
      heff_take_n(v_x_246, 3ULL, 2);
      V v_t_2410 = (g_heff_2ejson_2eescapeGo(v_a_248, heff_dup(v_lit_241), heff_dup(v_lit_242)));
      V v_t_2411 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2410, heff_dup(v_lit_243)));
      v_t_2412 = heff_strAppend(v_t_2411, heff_strAppend(heff_dup(v_lit_244), ({ V a_0 = v_a_249; V r_ = (g_heff_2ejson_2estringify(a_0)); heff_drop(v_a_249); r_; })));
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    return heff_tag_at(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_list_2emap_24s292465422x1926397249(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247))});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s292465422x1926397249_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s292465422x1926397249(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24s1199561713x637397077_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1199561713x637397077_entry, 1, 0};

V g_list_2emap_24s1199561713x637397077(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2edriver_2elean(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1199561713x637397077(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1199561713x637397077_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1199561713x637397077(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_list_2emap_24s529928550x768238834_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {107, 105, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_list_2emap_24s529928550x768238834_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {100, 101, 116, 97, 105, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_list_2emap_24s529928550x768238834_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {108, 97, 98, 101, 108}};
Clo g_list_2emap_24s529928550x768238834_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s529928550x768238834_entry, 1, 0};

V g_list_2emap_24s529928550x768238834(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag(TAG_JString, 1, (V[]){heff_get(heff_dup(v_x_241), LBL_label)});
    V v_t_244 = heff_tag_at(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s529928550x768238834_str0), heff_tag(TAG_JInt, 1, (V[]){MK_INT(3LL)})});
    V v_t_245 = heff_tag(TAG_JString, 1, (V[]){heff_get(v_x_241, LBL_detail)});
    V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s529928550x768238834_str1), v_t_245}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s529928550x768238834_str2), v_t_243}), heff_tag(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
    return heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_JObject, 1, (V[]){v_t_247}), (g_list_2emap_24s529928550x768238834(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s529928550x768238834_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s529928550x768238834(a[0]);
}
Clo g_list_2efind_24s913819130x636901392_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s913819130x636901392_entry, 2, 0};

V g_list_2efind_24s913819130x636901392(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c(v_t_246, heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s913819130x636901392_entry(V self, V *a) {
  (void)self;
  V r = g_list_2efind_24s913819130x636901392(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s832649871x524798512_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s832649871x524798512_entry, 1, 0};

V g_list_2emap_24s832649871x524798512(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_long), (g_list_2emap_24s832649871x524798512(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s832649871x524798512_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s832649871x524798512(a[0]);
}
Clo g_list_2emap_24s483092743x614910894_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s483092743x614910894_entry, 1, 0};

V g_list_2emap_24s483092743x614910894(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get(v_x_241, LBL_short), (g_list_2emap_24s483092743x614910894(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s483092743x614910894_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s483092743x614910894(a[0]);
}
Clo g_list_2eany_24s8708556x2121103388_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s8708556x2121103388_entry, 4, 0};

V g_list_2eany_24s8708556x2121103388(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_strLength(heff_get(heff_dup(v_x_244), LBL_short));
    if (heff_intLt_c(heff_dup(v_lit_240), v_t_246)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      return NTAG(TAG_True);
    } else {
      if (heff_strEq_c(heff_get(heff_dup(v_x_244), LBL_short), heff_dup(v_lit_241))) {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        return NTAG(TAG_True);
      } else {
        if (heff_strEq_c(heff_get(heff_dup(v_x_244), LBL_short), heff_dup(v_lit_242))) {
          heff_drop(v_lit_240);
          heff_drop(v_lit_241);
          heff_drop(v_lit_242);
          return NTAG(TAG_True);
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_lit_242;
          V t_3 = v_xs_245;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_lit_242 = t_2;
          v_x2_243 = t_3;
          goto top;
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s8708556x2121103388_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eany_24s8708556x2121103388(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
Clo g_list_2eany_24s699824326x1365177236_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s699824326x1365177236_entry, 6, 0};

V g_list_2eany_24s699824326x1365177236(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_long), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      return NTAG(TAG_True);
    } else {
      if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_short), heff_dup(v_lit_241))) {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        heff_drop(v_lit_243);
        heff_drop(v_lit_244);
        return NTAG(TAG_True);
      } else {
        if (heff_strEq_c(heff_get(heff_dup(v_x_246), LBL_long), heff_dup(v_lit_242))) {
          heff_drop(v_lit_240);
          heff_drop(v_lit_241);
          heff_drop(v_lit_242);
          heff_drop(v_lit_243);
          heff_drop(v_lit_244);
          return NTAG(TAG_True);
        } else {
          V v_t_2411 = (g_prelude_2eindexFrom(heff_dup(v_lit_243), heff_get(heff_dup(v_x_246), LBL_long), heff_dup(v_lit_244)));
          switch (heff_tag_of(v_t_2411)) {
          case TAG_Nothing: {
            V t_0 = v_lit_240;
            V t_1 = v_lit_241;
            V t_2 = v_lit_242;
            V t_3 = v_lit_243;
            V t_4 = v_lit_244;
            V t_5 = v_xs_247;
            v_lit_240 = t_0;
            v_lit_241 = t_1;
            v_lit_242 = t_2;
            v_lit_243 = t_3;
            v_lit_244 = t_4;
            v_x2_245 = t_5;
            goto top;
          }
          case TAG_Just: {
            heff_take_n(v_t_2411, 0ULL, 1);
            heff_drop(v_lit_240);
            heff_drop(v_lit_241);
            heff_drop(v_lit_242);
            heff_drop(v_lit_243);
            heff_drop(v_lit_244);
            return NTAG(TAG_True);
          }
          default: return heff_nomatch(v_t_2411);
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2eany_24s699824326x1365177236_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eany_24s699824326x1365177236(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[5]); return r;
}
Clo g_list_2eany_24s1231799341x1378938612_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1231799341x1378938612_entry, 2, 0};

V g_list_2eany_24s1231799341x1378938612(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_get(heff_dup(v_x_242), LBL_meta), heff_dup(v_lit_240))) {
      V v_t_245 = heff_get(heff_dup(v_x_242), LBL_values);
      V v_a_248;
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nil: {
        v_a_248 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_245, 0ULL, 2);
        v_a_248 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      switch (heff_tag_of(v_a_248)) {
      case TAG_True: {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_lit_240);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_a_248);
      }
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1231799341x1378938612_entry(V self, V *a) {
  (void)self;
  V r = g_list_2eany_24s1231799341x1378938612(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_list_2emap_24s791123004x231442264_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s791123004x231442264_entry, 2, 0};

V g_list_2emap_24s791123004x231442264(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_dup(v_lit_240), heff_get(v_x_242, LBL_long));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s791123004x231442264(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s791123004x231442264_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s791123004x231442264(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s2029999044x514618413_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s2029999044x514618413_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s2029999044x514618413_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_list_2emap_24s2029999044x514618413_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 46, 46, 93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_list_2emap_24s2029999044x514618413_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 46, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_list_2emap_24s2029999044x514618413_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_list_2emap_24s2029999044x514618413_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 46, 46, 93}};
Clo g_list_2emap_24s2029999044x514618413_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029999044x514618413_entry, 1, 0};

V g_list_2emap_24s2029999044x514618413(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_arity);
    V v_t_244;
    switch (heff_tag_of(v_t_243)) {
    case TAG_One: {
      v_t_244 = heff_get(v_x_241, LBL_meta);
      break;
    }
    case TAG_Optional: {
      v_t_244 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str0), heff_strAppend(heff_get(v_x_241, LBL_meta), ((V)&g_list_2emap_24s2029999044x514618413_str1)));
      break;
    }
    case TAG_Many: {
      v_t_244 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str2), heff_strAppend(heff_get(v_x_241, LBL_meta), ((V)&g_list_2emap_24s2029999044x514618413_str3)));
      break;
    }
    case TAG_Some: {
      v_t_244 = heff_strAppend(heff_get(v_x_241, LBL_meta), ((V)&g_list_2emap_24s2029999044x514618413_str4));
      break;
    }
    case TAG_Rest: {
      v_t_244 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_str5), heff_strAppend(heff_get(v_x_241, LBL_meta), ((V)&g_list_2emap_24s2029999044x514618413_str6)));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s2029999044x514618413(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029999044x514618413(a[0]);
}
Clo g_list_2emap_24s1281445768x1036802655_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1281445768x1036802655_entry, 1, 0};

V g_list_2emap_24s1281445768x1036802655(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eflagWord(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1281445768x1036802655(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1281445768x1036802655(a[0]);
}
Clo g_list_2emap_24s989117243x1797506341_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s989117243x1797506341_entry, 1, 0};

V g_list_2emap_24s989117243x1797506341(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eheadOf(heff_dup(v_x_241)));
    V v_t_244 = (g_std_2ecli_2eline2(v_t_243, heff_get(v_x_241, LBL_doc)));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_list_2emap_24s989117243x1797506341(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s989117243x1797506341_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s989117243x1797506341(a[0]);
}
Clo g_list_2efilter_24s581973887x894775069_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s581973887x894775069_entry, 1, 0};

V g_list_2efilter_24s581973887x894775069(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get(heff_dup(v_x_241), LBL_shown);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_list_2efilter_24s581973887x894775069(v_xs_242))});
    }
    case TAG_False: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s581973887x894775069_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s581973887x894775069(a[0]);
}
Clo g_list_2emap_24s1753874608x910016727_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1753874608x910016727_entry, 1, 0};

V g_list_2emap_24s1753874608x910016727(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2eflagLine(v_x_241));
    return heff_tag_at(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, (g_list_2emap_24s1753874608x910016727(v_xs_242))});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1753874608x910016727(a[0]);
}
Clo g_list_2emap_24s1896835896x1330972393_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1896835896x1330972393_entry, 4, 0};

V g_list_2emap_24s1896835896x1330972393(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_246 = heff_get(heff_dup(v_x_244), LBL_name);
    V v_a_247 = heff_get(v_x_244, LBL_doc);
    V v_t_249;
    if (heff_strEq_c(heff_dup(v_a_247), heff_dup(v_lit_240))) {
      heff_drop(v_a_247);
      v_t_249 = v_a_246;
    } else {
      v_t_249 = heff_strAppend(v_a_246, heff_strAppend(heff_dup(v_lit_241), v_a_247));
    }
    return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_249, heff_dup(v_lit_242)), (g_list_2emap_24s1896835896x1330972393(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1896835896x1330972393_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1896835896x1330972393(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s876522837x2005194065_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s876522837x2005194065_entry, 4, 0};

V g_list_2emap_24s876522837x2005194065(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_244, 0));
      v_a_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_a_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 2ULL, 2);
      v_a_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2413;
    if (heff_strEq_c(heff_dup(v_a_2411), heff_dup(v_lit_240))) {
      heff_drop(v_a_2411);
      v_t_2413 = v_a_248;
    } else {
      v_t_2413 = heff_strAppend(v_a_248, heff_strAppend(heff_dup(v_lit_241), v_a_2411));
    }
    return heff_tag_at(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, heff_dup(v_lit_242)), (g_list_2emap_24s876522837x2005194065(v_lit_240, v_lit_241, v_lit_242, v_xs_245))});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s876522837x2005194065_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s876522837x2005194065(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1230413390x1744519585_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230413390x1744519585_entry, 2, 0};

V g_list_2emap_24s1230413390x1744519585(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_242, heff_dup(v_lit_240)), (g_list_2emap_24s1230413390x1744519585(v_lit_240, v_xs_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1230413390x1744519585_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1230413390x1744519585(a[0], a[1]);
}