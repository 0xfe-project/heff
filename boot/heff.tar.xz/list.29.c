// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Flagged 28540
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_Kept 49931
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_NoneGiven 36085
#define TAG_PatVar 49363
#define TAG_Picked 5619
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SError 24172
#define TAG_SetPath 11095
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_Typed 36072
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_again 294104954
#define LBL_alias 294261354
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_by 9918
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_dir 308999
#define LBL_e 319
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_flags 298871457
#define LBL_holds 300818350
#define LBL_imports 10411951
#define LBL_input 301716452
#define LBL_item 9738202
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_meta 9843404
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ok 10307
#define LBL_options 1129866465
#define LBL_params 951713969
#define LBL_part 9928890
#define LBL_required 351999471
#define LBL_result 1012715336
#define LBL_severity 75955546
#define LBL_size 10026184
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watch 314261737
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_name__kind__span[] = {LBL_name, LBL_kind, LBL_span};
static uint32_t shape_options__at[] = {LBL_options, LBL_at};
static uint32_t shape_params__result[] = {LBL_params, LBL_result};
static uint32_t shape_part__input[] = {LBL_part, LBL_input};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
static uint32_t shape_value__ty__size__flags__span[] = {LBL_value, LBL_ty, LBL_size, LBL_flags, LBL_span};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2edocpages_2epage(V);
V g_heff_2ebuild_2edocpages_2epage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2epage_clo;
V g_heff_2ebuild_2edriver_2eimportOfGo(V, V, V);
V g_heff_2ebuild_2edriver_2eimportOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportOfGo_clo;
V g_heff_2ebuild_2edriver_2eplaceAt(V, V);
V g_heff_2ebuild_2edriver_2eplaceAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eplaceAt_clo;
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070(V, V);
V g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eowned_2econdKids(V);
V g_heff_2ecompile_2eowned_2econdKids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2econdKids_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2escalars_2egivenOf(V, V);
V g_heff_2ecompile_2escalars_2egivenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2egivenOf_clo;
V g_heff_2ecompile_2escalars_2eslotWith(V, V, V, V, V, V);
V g_heff_2ecompile_2escalars_2eslotWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotWith_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(V);
V g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925_clo;
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955(V, V, V);
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_list_2eall_24s743242824x1965727204(V);
V g_list_2eall_24s743242824x1965727204_entry(V self, V *a);
extern Clo g_list_2eall_24s743242824x1965727204_clo;
V g_list_2eany_24s1027174601x1571638094(V, V, V, V);
V g_list_2eany_24s1027174601x1571638094_entry(V self, V *a);
extern Clo g_list_2eany_24s1027174601x1571638094_clo;
V g_list_2eany_24s2037198014x392734282(V, V);
V g_list_2eany_24s2037198014x392734282_entry(V self, V *a);
extern Clo g_list_2eany_24s2037198014x392734282_clo;
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
V g_list_2eany_24s331724893x1262243254(V);
V g_list_2eany_24s331724893x1262243254_entry(V self, V *a);
extern Clo g_list_2eany_24s331724893x1262243254_clo;
V g_list_2eany_24s860380051x1466609135(V);
V g_list_2eany_24s860380051x1466609135_entry(V self, V *a);
extern Clo g_list_2eany_24s860380051x1466609135_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl_24f2071981990x435576741(V, V, V);
V g_list_2efoldl_24f2071981990x435576741_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2071981990x435576741_clo;
V g_list_2efoldl_24f319030394x1380151895(V, V, V);
V g_list_2efoldl_24f319030394x1380151895_entry(V self, V *a);
extern Clo g_list_2efoldl_24f319030394x1380151895_clo;
V g_list_2efoldl_24s1372957693x1709266208(V, V);
V g_list_2efoldl_24s1372957693x1709266208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1372957693x1709266208_clo;
V g_list_2efoldl_24s1516272141x1201056882(V, V, V);
V g_list_2efoldl_24s1516272141x1201056882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1516272141x1201056882_clo;
V g_list_2efoldl_24s1551647072x1644392086(V, V);
V g_list_2efoldl_24s1551647072x1644392086_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1551647072x1644392086_clo;
V g_list_2efoldl_24s1810610888x1691479932(V, V);
V g_list_2efoldl_24s1810610888x1691479932_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1810610888x1691479932_clo;
V g_list_2efoldl_24s1854174827x1081689521(V, V);
V g_list_2efoldl_24s1854174827x1081689521_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1854174827x1081689521_clo;
V g_list_2efoldl_24s537755658x300885499(V, V);
V g_list_2efoldl_24s537755658x300885499_entry(V self, V *a);
extern Clo g_list_2efoldl_24s537755658x300885499_clo;
V g_list_2efoldl_24s552376067x1255995125(V, V);
V g_list_2efoldl_24s552376067x1255995125_entry(V self, V *a);
extern Clo g_list_2efoldl_24s552376067x1255995125_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s932544939x1448830416_24scalars(V, V, V);
V g_list_2efoldl_24s932544939x1448830416_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s932544939x1448830416_24scalars_clo;
V g_list_2ekeepIf_24f428638463x2144521938(V, V, V, V);
V g_list_2ekeepIf_24f428638463x2144521938_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f428638463x2144521938_clo;
V g_list_2ekeepIf_24f428638463x2144521938_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24f428638463x2144521938_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f428638463x2144521938_24dps_clo;
V g_list_2ekeepIf_24s458067099x815639923_24dps(V, V);
V g_list_2ekeepIf_24s458067099x815639923_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s458067099x815639923_24dps_clo;
V g_list_2ekeepIf_24s479112018x1726839132_24dps(V, V);
V g_list_2ekeepIf_24s479112018x1726839132_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s479112018x1726839132_24dps_clo;
V g_list_2ekeepIf_24s483972445x1090422631_24dps(V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s483972445x1090422631_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s483972445x1090422631_24dps_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2ekeepIf_24s930188071x496633547_24dps(V, V, V);
V g_list_2ekeepIf_24s930188071x496633547_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_24dps_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1176765648x1638512070(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1176765648x1638512070_entry(V self, V *a);
extern Clo g_list_2emap_24f1176765648x1638512070_clo;
V g_list_2emap_24f1176765648x1638512070_24dps(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1176765648x1638512070_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1176765648x1638512070_24dps_clo;
V g_list_2emap_24f1221888634x716224461_24dps(V, V, V);
V g_list_2emap_24f1221888634x716224461_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1221888634x716224461_24dps_clo;
V g_list_2emap_24f869471183x993026796(V, V, V);
V g_list_2emap_24f869471183x993026796_entry(V self, V *a);
extern Clo g_list_2emap_24f869471183x993026796_clo;
V g_list_2emap_24f869471183x993026796_24dps(V, V, V, V);
V g_list_2emap_24f869471183x993026796_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f869471183x993026796_24dps_clo;
V g_list_2emap_24s1218298322x1569510752(V, V);
V g_list_2emap_24s1218298322x1569510752_entry(V self, V *a);
extern Clo g_list_2emap_24s1218298322x1569510752_clo;
V g_list_2emap_24s1218298322x1569510752_24dps(V, V, V);
V g_list_2emap_24s1218298322x1569510752_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1218298322x1569510752_24dps_clo;
V g_list_2emap_24s1628253759x601849359_24dps(V, V, V, V);
V g_list_2emap_24s1628253759x601849359_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1628253759x601849359_24dps_clo;
V g_list_2emap_24s1732792088x1893487364(V, V, V);
V g_list_2emap_24s1732792088x1893487364_entry(V self, V *a);
extern Clo g_list_2emap_24s1732792088x1893487364_clo;
V g_list_2emap_24s1732792088x1893487364_24dps(V, V, V, V);
V g_list_2emap_24s1732792088x1893487364_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1732792088x1893487364_24dps_clo;
V g_list_2emap_24s1737386070x1499208753_24dps(V, V);
V g_list_2emap_24s1737386070x1499208753_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1737386070x1499208753_24dps_clo;
V g_list_2emap_24s1782778565x402128078(V);
V g_list_2emap_24s1782778565x402128078_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_clo;
V g_list_2emap_24s1816200867x1876638332(V);
V g_list_2emap_24s1816200867x1876638332_entry(V self, V *a);
extern Clo g_list_2emap_24s1816200867x1876638332_clo;
V g_list_2emap_24s1887874170x1747433177(V);
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_clo;
V g_list_2emap_24s1887874170x1747433177_24dps(V, V);
V g_list_2emap_24s1887874170x1747433177_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_24dps_clo;
V g_list_2emap_24s204237290x1967740547_24dps(V, V, V, V, V);
V g_list_2emap_24s204237290x1967740547_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s204237290x1967740547_24dps_clo;
V g_list_2emap_24s2133060086x110881273(V, V, V, V, V, V, V);
V g_list_2emap_24s2133060086x110881273_entry(V self, V *a);
extern Clo g_list_2emap_24s2133060086x110881273_clo;
V g_list_2emap_24s2133060086x110881273_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s2133060086x110881273_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2133060086x110881273_24dps_clo;
V g_list_2emap_24s215892288x1392224072(V, V);
V g_list_2emap_24s215892288x1392224072_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_clo;
V g_list_2emap_24s215892288x1392224072_24tok2(V, V, V);
V g_list_2emap_24s215892288x1392224072_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_24tok2_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s328130413x305756849(V, V, V, V);
V g_list_2emap_24s328130413x305756849_entry(V self, V *a);
extern Clo g_list_2emap_24s328130413x305756849_clo;
V g_list_2emap_24s328130413x305756849_24dps(V, V, V, V, V);
V g_list_2emap_24s328130413x305756849_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s328130413x305756849_24dps_clo;
V g_list_2emap_24s386875578x1005587669_24dps(V, V);
V g_list_2emap_24s386875578x1005587669_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_24dps_clo;
V g_list_2emap_24s404123879x745642248(V);
V g_list_2emap_24s404123879x745642248_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_clo;
V g_list_2emap_24s404123879x745642248_24dps(V, V);
V g_list_2emap_24s404123879x745642248_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_24dps_clo;
V g_list_2emap_24s456747242x756515627_24dps(V, V);
V g_list_2emap_24s456747242x756515627_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s456747242x756515627_24dps_clo;
V g_list_2emap_24s474585387x1072098790(V);
V g_list_2emap_24s474585387x1072098790_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_clo;
V g_list_2emap_24s510639937x1058700299_24dps(V, V);
V g_list_2emap_24s510639937x1058700299_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s510639937x1058700299_24dps_clo;
V g_list_2emap_24s510830240x893896831(V, V);
V g_list_2emap_24s510830240x893896831_entry(V self, V *a);
extern Clo g_list_2emap_24s510830240x893896831_clo;
V g_list_2emap_24s510830240x893896831_24dps(V, V, V);
V g_list_2emap_24s510830240x893896831_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s510830240x893896831_24dps_clo;
V g_list_2emap_24s529174x2075875906(V);
V g_list_2emap_24s529174x2075875906_entry(V self, V *a);
extern Clo g_list_2emap_24s529174x2075875906_clo;
V g_list_2emap_24s529174x2075875906_24dps(V, V);
V g_list_2emap_24s529174x2075875906_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s529174x2075875906_24dps_clo;
V g_list_2emap_24s588468714x1874323009_24dps(V, V);
V g_list_2emap_24s588468714x1874323009_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s588468714x1874323009_24dps_clo;
V g_list_2emap_24s674081137x339217813(V);
V g_list_2emap_24s674081137x339217813_entry(V self, V *a);
extern Clo g_list_2emap_24s674081137x339217813_clo;
V g_list_2emap_24s763976875x1978337183_24dps(V, V);
V g_list_2emap_24s763976875x1978337183_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s763976875x1978337183_24dps_clo;
V g_list_2emap_24s886389550x1086668531_24dps(V, V);
V g_list_2emap_24s886389550x1086668531_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s886389550x1086668531_24dps_clo;
V g_list_2emap_24s892909862x1245535974_24dps(V, V, V, V, V);
V g_list_2emap_24s892909862x1245535974_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s892909862x1245535974_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s151204990x680105425(V, V);
V g_list_2ezipWith_24s151204990x680105425_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s151204990x680105425_clo;
V g_list_2ezipWith_24s1958630276x749154843_24dps(V, V, V);
V g_list_2ezipWith_24s1958630276x749154843_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_24dps_clo;
V g_list_2ezipWith_24s919837080x1979082626(V, V, V, V);
V g_list_2ezipWith_24s919837080x1979082626_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s919837080x1979082626_clo;
V g_list_2ezipWith_24s919837080x1979082626_24dps(V, V, V, V, V);
V g_list_2ezipWith_24s919837080x1979082626_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s919837080x1979082626_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2ecli_2einteractive_2eswitchOptions_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
Clo g_list_2ekeepIf_24s930188071x496633547_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s930188071x496633547_entry, 2, 0};

V g_list_2ekeepIf_24s930188071x496633547(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c_lent(v_x_242, v_lit_240, 0)) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s930188071x496633547_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s930188071x496633547(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1810610888x1691479932_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1810610888x1691479932_entry, 2, 0};

V g_list_2efoldl_24s1810610888x1691479932(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_m_244 = v_z_240;
    V v_d_245 = heff_dup(v_x_242);
    V v_body_246 = heff_take_field(v_d_245, 2);
    V v_key_247 = heff_get_n(v_d_245, 0, 3);
    V v_t_2448;
    switch (heff_tag_of(v_body_246)) {
    case TAG_EVar: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_ELam: {
      V v_xs_2410 = heff_field(v_body_246, 0);
      heff_take_n(v_body_246, 1ULL, 2);
      V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2410; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      v_t_2448 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_244, v_key_247, v_t_2412));
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_body_246, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_body_246, 0ULL, 4);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_body_246, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_body_246, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2448 = v_m_244;
      break;
    }
    default: heff_nomatch(v_body_246);
    }
    V t_0 = v_t_2448;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1810610888x1691479932_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1810610888x1691479932(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s2077819594x1842428557_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2077819594x1842428557_entry, 2, 0};

V g_list_2eany_24s2077819594x1842428557(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_lit_240, v_x_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s2077819594x1842428557(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1732792088x1893487364_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1732792088x1893487364_entry, 3, 0};

V g_list_2emap_24s1732792088x1893487364(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1732792088x1893487364_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1732792088x1893487364_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1732792088x1893487364(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s529174x2075875906_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s529174x2075875906_entry, 1, 0};

V g_list_2emap_24s529174x2075875906(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s529174x2075875906_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s529174x2075875906_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s529174x2075875906(a[0]);
}
Clo g_list_2emap_24s529174x2075875906_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s529174x2075875906_24dps_entry, 2, 0};

V g_list_2emap_24s529174x2075875906_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eargOf_24s1218795925x999132925(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s529174x2075875906_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s529174x2075875906_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1887874170x1747433177_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1887874170x1747433177_entry, 1, 0};

V g_list_2emap_24s1887874170x1747433177(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_241));
    V v_t_2415;
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_a_246 = v_field_245;
        V v_t_249;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_248 = heff_dup(heff_field(v_a_246, 1));
          v_t_249 = v_a_248;
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_a_246}), v_t_249});
      } else {
        if ((v_tag_244 == ((int64_t)1ULL))) {
          V v_a_2410 = v_field_245;
          V v_t_2413;
          switch (heff_tag_of(v_a_2410)) {
          case TAG_At: {
            V v_a_2412 = heff_dup(heff_field(v_a_2410, 1));
            v_t_2413 = v_a_2412;
            break;
          }
          default: heff_nomatch(v_a_2410);
          }
          v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_a_2410}), v_t_2413});
        } else {
          V v_a_2414 = v_field_245;
          v_t_2415 = v_a_2414;
        }
      }
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s1887874170x1747433177_24dps(v_xs_242, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1887874170x1747433177(a[0]);
}
Clo g_list_2emap_24s386875578x1005587669_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s386875578x1005587669_24dps_entry, 2, 0};

V g_list_2emap_24s386875578x1005587669_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2452;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_x2_246 = v_a_244;
      V v_t_2451;
      switch (heff_tag_of(v_x2_246)) {
      case TAG_DeclEquations: {
        V v_f_247 = heff_field(v_x2_246, 0);
        V v_sp_248 = heff_field(v_x2_246, 1);
        V v_declared_249 = heff_field(v_x2_246, 2);
        V v_ty_2410 = heff_field(v_x2_246, 3);
        V v_eqs_2411 = heff_field(v_x2_246, 4);
        V v_ru_24x2_246_24DeclEquations = heff_take_reuse_n(v_x2_246, 31ULL, 5);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        V v_t_2414;
        switch (heff_tag_of(v_ty_2410)) {
        case TAG_At: {
          V v_n_2412 = heff_field(v_ty_2410, 0);
          V v_sp_2413 = heff_field(v_ty_2410, 1);
          V v_ru_24ty_2410_24At = heff_take_reuse_n(v_ty_2410, 3ULL, 2);
          v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24ty_2410_24At, v_sp_2413, v_n_2412));
          break;
        }
        default: heff_nomatch(v_ty_2410);
        }
        V v_t_2415 = (g_list_2emap_24s1782778565x402128078(v_eqs_2411));
        v_t_2451 = heff_tag_at_n(v_ru_24x2_246_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_247, v_sp_248, v_declared_249, v_t_2414, v_t_2415});
        break;
      }
      case TAG_DeclDefine: {
        V v_x_2416 = heff_field(v_x2_246, 0);
        V v_sp_2417 = heff_field(v_x2_246, 1);
        V v_ps_2418 = heff_field(v_x2_246, 2);
        V v_u_2419 = heff_field(v_x2_246, 3);
        V v_body_2420 = heff_field(v_x2_246, 4);
        V v_ru_24x2_246_24DeclDefine = heff_take_reuse_n(v_x2_246, 31ULL, 5);
        V v_t_2421 = (g_list_2emap_24s474585387x1072098790(v_ps_2418));
        V v_t_2424;
        switch (heff_tag_of(v_u_2419)) {
        case TAG_At: {
          V v_n_2422 = heff_field(v_u_2419, 0);
          V v_sp_2423 = heff_field(v_u_2419, 1);
          V v_ru_24u_2419_24At = heff_take_reuse_n(v_u_2419, 3ULL, 2);
          v_t_2424 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24u_2419_24At, v_sp_2423, v_n_2422));
          break;
        }
        default: heff_nomatch(v_u_2419);
        }
        V v_t_2428;
        switch (heff_tag_of(v_body_2420)) {
        case TAG_At: {
          V v_n_2425 = heff_field(v_body_2420, 0);
          V v_sp_2426 = heff_field(v_body_2420, 1);
          heff_take_n(v_body_2420, 3ULL, 2);
          V v_t_2427 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2425));
          v_t_2428 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2427, v_sp_2426});
          break;
        }
        default: heff_nomatch(v_body_2420);
        }
        v_t_2451 = heff_tag_at_n(v_ru_24x2_246_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2416, v_sp_2417, v_t_2421, v_t_2424, v_t_2428});
        break;
      }
      case TAG_DeclTheory: {
        V v_x_2429 = heff_field(v_x2_246, 0);
        V v_sp_2430 = heff_field(v_x2_246, 1);
        V v_ps_2431 = heff_field(v_x2_246, 2);
        V v_body_2432 = heff_field(v_x2_246, 3);
        V v_ru_24x2_246_24DeclTheory = heff_take_reuse_n(v_x2_246, 15ULL, 4);
        V v_t_2433 = (g_list_2emap_24s474585387x1072098790(v_ps_2431));
        V v_t_2437;
        switch (heff_tag_of(v_body_2432)) {
        case TAG_At: {
          V v_n_2434 = heff_field(v_body_2432, 0);
          V v_sp_2435 = heff_field(v_body_2432, 1);
          heff_take_n(v_body_2432, 3ULL, 2);
          V v_t_2436 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2434));
          v_t_2437 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2436, v_sp_2435});
          break;
        }
        default: heff_nomatch(v_body_2432);
        }
        v_t_2451 = heff_tag_at_n(v_ru_24x2_246_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2429, v_sp_2430, v_t_2433, v_t_2437});
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2438 = heff_field(v_x2_246, 0);
        V v_sp_2439 = heff_field(v_x2_246, 1);
        V v_t_2440 = heff_field(v_x2_246, 2);
        V v_ru_24x2_246_24DeclPrimitive = heff_take_reuse_n(v_x2_246, 7ULL, 3);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        V v_t_2443;
        switch (heff_tag_of(v_t_2440)) {
        case TAG_At: {
          V v_n_2441 = heff_field(v_t_2440, 0);
          V v_sp_2442 = heff_field(v_t_2440, 1);
          V v_ru_24t_2440_24At = heff_take_reuse_n(v_t_2440, 3ULL, 2);
          v_t_2443 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2440_24At, v_sp_2442, v_n_2441));
          break;
        }
        default: heff_nomatch(v_t_2440);
        }
        v_t_2451 = heff_tag_at_n(v_ru_24x2_246_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2438, v_sp_2439, v_t_2443});
        break;
      }
      case TAG_DeclTest: {
        V v_x_2444 = heff_field(v_x2_246, 0);
        V v_sp_2445 = heff_field(v_x2_246, 1);
        V v_ru_24x2_246_24DeclTest = heff_take_reuse_n(v_x2_246, 3ULL, 2);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2451 = heff_tag_at_n(v_ru_24x2_246_24DeclTest, TAG_DeclTest, 2, (V[]){v_x_2444, v_sp_2445});
        break;
      }
      case TAG_DeclWatch: {
        V v_c_2446 = heff_field(v_x2_246, 0);
        V v_ru_24x2_246_24DeclWatch = heff_take_reuse_n(v_x2_246, 1ULL, 1);
        V v_t_2450;
        switch (heff_tag_of(v_c_2446)) {
        case TAG_At: {
          V v_n_2447 = heff_field(v_c_2446, 0);
          V v_sp_2448 = heff_field(v_c_2446, 1);
          heff_take_n(v_c_2446, 3ULL, 2);
          V v_t_2449 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2447));
          v_t_2450 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2449, v_sp_2448});
          break;
        }
        default: heff_nomatch(v_c_2446);
        }
        v_t_2451 = heff_tag_at_n(v_ru_24x2_246_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_2450});
        break;
      }
      default: heff_nomatch(v_x2_246);
      }
      v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2453 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2452, heff_hole()});
    V v_u_2454 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2453));
    heff_drop(v_u_2454);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2453;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s386875578x1005587669_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s386875578x1005587669_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s892909862x1245535974_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s892909862x1245535974_24dps_entry, 5, 0};

V g_list_2emap_24s892909862x1245535974_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 5);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_MkEquation: {
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_a_2411 = heff_field(v_a_247, 2);
        V v_a_2412 = heff_field(v_a_247, 3);
        V v_ru_24a_247_24MkEquation = heff_take_reuse_n(v_a_247, 14ULL, 4);
        V v_t_2413 = heff_strAppend(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_lit_241));
        V v_t_2414 = heff_tag_at_n(v_ru_24x_245_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_lit_242)}), heff_dup(v_a_2410)});
        V v_t_2415 = heff_tag_at_n(v_ru_24a_247_24MkEquation, TAG_MkEquation, 4, (V[]){v_t_2413, v_a_2410, heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2414, v_a_2411}), v_a_2412});
        v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_a_248});
        break;
      }
      default: heff_nomatch(v_a_247);
      }
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s892909862x1245535974_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s892909862x1245535974_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2eany_24s860380051x1466609135_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s860380051x1466609135_entry, 1, 0};

V g_list_2eany_24s860380051x1466609135(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2ehandlerLike(heff_dup(v_x_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s860380051x1466609135_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s860380051x1466609135(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1737386070x1499208753_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1737386070x1499208753_24dps_entry, 2, 0};

V g_list_2emap_24s1737386070x1499208753_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      V v_ru_24x_242_24MkArm = heff_take_reuse_n(v_x_242, 7ULL, 3);
      V v_t_247 = (g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070(v_a_246, NTAG(TAG_Nothing)));
      v_t_248 = heff_tag_at_n(v_ru_24x_242_24MkArm, TAG_MkArm, 3, (V[]){v_a_244, v_a_245, v_t_247});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_xs_243;
    V t_1 = v_cell_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1737386070x1499208753_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1737386070x1499208753_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1854174827x1081689521_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1854174827x1081689521_entry, 2, 0};

V g_list_2efoldl_24s1854174827x1081689521(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_acc_244 = v_z_240;
    V v_x2_245 = v_x_242;
    V v_t_2413;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_x22_247 = heff_field(v_x2_245, 1);
      V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
      switch (heff_tag_of(v_x22_247)) {
      case TAG_RepV: {
        V v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_246)}), v_acc_244});
        v_t_2413 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_246}), v_t_248});
        break;
      }
      case TAG_RepFix: {
        V v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_246)}), v_acc_244});
        v_t_2413 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Kept, 2, (V[]){v_x_246, v_x22_247}), v_t_2410});
        break;
      }
      case TAG_RepF64: {
        V v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_246)}), v_acc_244});
        v_t_2413 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Kept, 2, (V[]){v_x_246, v_x22_247}), v_t_2411});
        break;
      }
      case TAG_RepInt: {
        V v_t_2412 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_246)}), v_acc_244});
        v_t_2413 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Kept, 2, (V[]){v_x_246, v_x22_247}), v_t_2412});
        break;
      }
      default: heff_nomatch(v_x22_247);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1854174827x1081689521_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1854174827x1081689521(a[0], a[1]);
}
Clo g_list_2efoldl_24s1372957693x1709266208_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1372957693x1709266208_entry, 2, 0};

V g_list_2efoldl_24s1372957693x1709266208(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_249;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_x_242, 0);
        v_t_249 = heff_dup(v_a_247);
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      v_t_2410 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, v_t_249, NTAG(TAG_MkUnit)));
    } else {
      heff_drop(v_t_246);
      v_t_2410 = v_z_240;
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1372957693x1709266208_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1372957693x1709266208(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s479112018x1726839132_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s479112018x1726839132_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s479112018x1726839132_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    switch (heff_tag_of(v_t_249)) {
    case TAG_RepV: {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2410;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepFix: {
      heff_take_n(v_t_249, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepF64: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepInt: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s479112018x1726839132_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s479112018x1726839132_24dps(a[0], a[1]);
}
V g_list_2ezipWith_24s919837080x1979082626_lam0(V self, V *args);
Clo g_list_2ezipWith_24s919837080x1979082626_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s919837080x1979082626_entry, 4, 0};

V g_list_2ezipWith_24s919837080x1979082626(V v_lit_240, V v_lit_241, V v_x2_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_x3_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_243, 0);
      V v_ys_247 = heff_field(v_x3_243, 1);
      V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
      V v_kind_248 = heff_dup(v_lit_240);
      V v_c_249 = heff_dup(v_lit_241);
      V v_p_2410 = v_x_244;
      V v_i_2411 = v_y_246;
      V v_gs_2420 = (g_list_2emap_24tok2(v_ru_24x3_243_24Cons, heff_clo_n(g_list_2ezipWith_24s919837080x1979082626_lam0, 1, 2, (V[]){heff_dup(v_i_2411), heff_dup(v_p_2410)}), heff_dup(heff_rfield(v_c_249, 3))));
      V v_t_2421 = (g_list_2efoldl_24f2071981990x435576741(MK_INT(1LL), MK_INT(0LL), v_gs_2420));
      V v_t_2422 = (g_list_2efoldl_24s1551647072x1644392086(NTAG(TAG_NoneGiven), v_gs_2420));
      V v_t_2423 = ({ V a_0 = v_kind_248; V a_1 = v_c_249; V a_2 = v_i_2411; V a_3 = v_p_2410; V a_4 = v_t_2421; V a_5 = v_t_2422; V r_ = (g_heff_2ecompile_2escalars_2eslotWith(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_kind_248); r_; });
      V v_cell_2424 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
      V v_u_2425 = (g_list_2ezipWith_24s919837080x1979082626_24dps(v_lit_240, v_lit_241, v_xs_245, v_ys_247, heff_dup(v_cell_2424)));
      heff_drop(v_u_2425);
      return v_cell_2424;
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ezipWith_24s919837080x1979082626_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s919837080x1979082626(a[0], a[1], a[2], a[3]);
}
V g_list_2ezipWith_24s919837080x1979082626_lam0(V self, V *args) {
  V v_args_2412 = args[0];
  V v_i_2411 = heff_env(self)[0];
  V v_p_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT3 v_t_2413 = ({ V a_0 = v_i_2411; V a_1 = v_args_2412; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_args_2412); r_; });
  V v_t_2419;
  {
    V v_field_2415 = v_t_2413.f[1];
    V v_field_2416 = v_t_2413.f[2];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_x_2417 = v_field_2415;
      V v_x12_2418 = v_field_2416;
      heff_drop(v_x12_2418);
      v_t_2419 = v_x_2417;
    } else {
      heff_drop(v_field_2415);
      heff_drop(v_field_2416);
      v_t_2419 = NTAG(TAG_EAbandon);
    }
  }
  return ({ V a_0 = v_p_2410; V a_1 = v_t_2419; V r_ = (g_heff_2ecompile_2escalars_2egivenOf(a_0, a_1)); heff_drop(v_p_2410); r_; });
}
Clo g_list_2eall_24s743242824x1965727204_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s743242824x1965727204_entry, 1, 0};

V g_list_2eall_24s743242824x1965727204(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2eir_2eisValue(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s743242824x1965727204_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s743242824x1965727204(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s932544939x1448830416_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s932544939x1448830416_24scalars_entry, 3, 0};

V g_list_2efoldl_24s932544939x1448830416_24scalars(V v_params_240, V v_result_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_params__result, (V[]){v_params_240, v_result_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_params_245 = heff_dup(heff_rfield(v_x_243, 0));
    V v_result_246 = heff_dup(heff_rfield(v_x_243, 1));
    V v_t_247 = (g_list_2ezipWith_24s151204990x680105425(v_params_240, v_params_245));
    V v_a_248 = v_result_241;
    V v_t_249 = ({ V a_0 = v_a_248; V a_1 = v_result_246; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_result_246); r_; });
    V v_t_2410;
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      v_t_2410 = v_a_248;
    } else {
      heff_drop(v_a_248);
      heff_drop(v_t_249);
      v_t_2410 = NTAG(TAG_RepV);
    }
    V t_0 = v_t_247;
    V t_1 = v_t_2410;
    V t_2 = v_xs_244;
    v_params_240 = t_0;
    v_result_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s932544939x1448830416_24scalars_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s932544939x1448830416_24scalars(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s510639937x1058700299_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s510639937x1058700299_24dps_entry, 2, 0};

V g_list_2emap_24s510639937x1058700299_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 3, 5), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s510639937x1058700299_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s510639937x1058700299_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s331724893x1262243254_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s331724893x1262243254_entry, 1, 0};

V g_list_2eany_24s331724893x1262243254(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if (heff_strEq_c(heff_dup(v_x_241), heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s331724893x1262243254_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s331724893x1262243254(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1218298322x1569510752_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1218298322x1569510752_entry, 2, 0};

V g_list_2emap_24s1218298322x1569510752(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1218298322x1569510752_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1218298322x1569510752_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1218298322x1569510752(a[0], a[1]);
}
Clo g_list_2emap_24s2133060086x110881273_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2133060086x110881273_entry, 7, 0};

V g_list_2emap_24s2133060086x110881273(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_dup(heff_field(v_x_247, 0));
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2411); r_; });
    V v_t_2413 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), v_t_2412));
    V v_t_2416;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_2415 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_t_2416 = v_a_2415;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2413, heff_dup(v_lit_245)), heff_intShow(v_t_2416));
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = (g_list_2emap_24s2133060086x110881273_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s2133060086x110881273_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2133060086x110881273(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2efoldl_24s552376067x1255995125_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s552376067x1255995125_entry, 2, 0};

V g_list_2efoldl_24s552376067x1255995125(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s537755658x300885499(v_z_240, heff_rfield(v_x_242, 1)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s552376067x1255995125_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s552376067x1255995125(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s886389550x1086668531_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s886389550x1086668531_24dps_entry, 2, 0};

V g_list_2emap_24s886389550x1086668531_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      V v_sp_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_MkSegment: {
        V v_v_246 = heff_field(v_x11_244, 0);
        V v_ty_247 = heff_field(v_x11_244, 1);
        V v_size_248 = heff_field(v_x11_244, 2);
        V v_little_249 = heff_field(v_x11_244, 3);
        V v_signed_2410 = heff_field(v_x11_244, 4);
        heff_take_n(v_x11_244, 31ULL, 5);
        int64_t v_t_2411;
        if ((heff_dup(v_little_249) == NTAG(TAG_True))) {
          heff_drop(v_little_249);
          v_t_2411 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_249);
          v_t_2411 = ((int64_t)0ULL);
        }
        int64_t v_t_2412;
        if ((heff_dup(v_signed_2410) == NTAG(TAG_True))) {
          heff_drop(v_signed_2410);
          v_t_2412 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_2410);
          v_t_2412 = ((int64_t)0ULL);
        }
        v_t_2413 = heff_rec_n(5, shape_value__ty__size__flags__span, (V[]){v_v_246, v_ty_247, v_size_248, heff_box_word((v_t_2411 + v_t_2412)), v_sp_245});
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s886389550x1086668531_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s886389550x1086668531_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s2037198014x392734282_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2037198014x392734282_entry, 2, 0};

V g_list_2eany_24s2037198014x392734282(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_name_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_alias_245 = heff_dup(heff_rfield(v_x_242, 1));
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), v_name_244)) {
      V v_a_246 = v_alias_245;
      V v_t_247 = heff_dup(heff_rfield(v_lit_240, 1));
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_a_246)) {
        case TAG_Nothing: {
          heff_drop_rec(v_lit_240, 3);
          return NTAG(TAG_True);
        }
        case TAG_Just: {
          heff_take_n(v_a_246, 0ULL, 1);
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_a_246);
        }
      }
      case TAG_Just: {
        V v_a_249 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 1);
        switch (heff_tag_of(v_a_246)) {
        case TAG_Nothing: {
          heff_drop(v_a_249);
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_Just: {
          V v_a_2410 = heff_field(v_a_246, 0);
          heff_take_n(v_a_246, 1ULL, 1);
          if (heff_strEq_c(v_a_249, v_a_2410)) {
            heff_drop_rec(v_lit_240, 3);
            return NTAG(TAG_True);
          } else {
            V t_0 = v_lit_240;
            V t_1 = v_xs_243;
            v_lit_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        }
        default: return heff_nomatch(v_a_246);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    } else {
      heff_drop(v_alias_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s2037198014x392734282_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s2037198014x392734282(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s204237290x1967740547_24dps_str0, 15, "the primitive `");
HEFF_LIT(g_list_2emap_24s204237290x1967740547_24dps_str1, 14, "` is declared ");
HEFF_LIT(g_list_2emap_24s204237290x1967740547_24dps_str2, 6, ", and ");
Clo g_list_2emap_24s204237290x1967740547_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s204237290x1967740547_24dps_entry, 5, 0};

V g_list_2emap_24s204237290x1967740547_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_done_247 = heff_dup(v_lit_240);
    V v_imps_248 = heff_dup(v_lit_241);
    V v_c_249 = heff_dup(v_lit_242);
    V v_t_2410 = v_x_245;
    V v_again_2411 = heff_take_field(v_t_2410, 1);
    V v_first_2412 = heff_get_n(v_t_2410, 0, 2);
    V v_t_2413 = heff_strAppend(((V)&g_list_2emap_24s204237290x1967740547_24dps_str0), heff_take_field(v_again_2411, 0));
    V v_t_2414 = (g_heff_2ebuild_2edriver_2eplaceAt(heff_take_field(v_first_2412, 1), heff_get_n(v_first_2412, 2, 3)));
    V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_list_2emap_24s204237290x1967740547_24dps_str1)), v_t_2414);
    V v_t_2416 = (g_heff_2ebuild_2edriver_2eplaceAt(heff_dup(heff_rfield(v_again_2411, 1)), heff_dup(heff_rfield(v_again_2411, 2))));
    V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_list_2emap_24s204237290x1967740547_24dps_str2)), v_t_2416);
    V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_again_2411, 1)), 0, 14);
    V v_t_2420;
    if (heff_strEq_c(v_t_2418, heff_get_n(v_c_249, 0, 14))) {
      heff_drop(v_done_247);
      heff_drop_rec(v_imps_248, 4);
      v_t_2420 = heff_get_n(v_again_2411, 2, 3);
    } else {
      V v_t_2419 = heff_get_n(heff_get_n(v_again_2411, 1, 3), 0, 14);
      v_t_2420 = ({ V a_0 = v_done_247; V a_1 = v_t_2419; V b_2 = heff_get_n(v_imps_248, 0, 4); V r_ = (g_heff_2ebuild_2edriver_2eimportOfGo(a_0, a_1, b_2)); heff_drop(v_done_247); heff_drop(b_2); r_; });
    }
    V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(336LL), NTAG(TAG_SError), v_t_2417, v_t_2420, NTAG(TAG_Nothing)});
    V v_cell_2422 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2421, heff_hole()});
    V v_u_2423 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2422));
    heff_drop(v_u_2423);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2422;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s204237290x1967740547_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s204237290x1967740547_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_list_2emap_24s588468714x1874323009_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_24dps_str3, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_24dps_str4, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_24dps_str5, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_24dps_str6, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_24dps_str7, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_24dps_str8, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_24dps_str9, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_24dps_str10, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_24dps_str11, 0, "");
Clo g_list_2emap_24s588468714x1874323009_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s588468714x1874323009_24dps_entry, 2, 0};

V g_list_2emap_24s588468714x1874323009_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_v_244 = v_x_242;
    V v_t_2418;
    switch (heff_tag_of(v_v_244)) {
    case TAG_VFun: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_248 = heff_dup(heff_field(v_v_244, 1));
      v_t_2418 = v_vs_248;
      break;
    }
    case TAG_VInt: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_244);
    }
    HeffT3 v_t_2419 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2418; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_t_2438;
    {
      V v_field_2421 = v_t_2419.f[1];
      V v_field_2422 = v_t_2419.f[2];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        V v_x_2423 = v_field_2421;
        V v_x12_2424 = v_field_2422;
        heff_drop(v_x12_2424);
        switch (heff_tag_of(v_x_2423)) {
        case TAG_VFun: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s588468714x1874323009_24dps_str0);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s588468714x1874323009_24dps_str1);
          break;
        }
        case TAG_VTag: {
          heff_take_n(v_x_2423, 0ULL, 2);
          v_t_2438 = ((V)&g_list_2emap_24s588468714x1874323009_24dps_str2);
          break;
        }
        case TAG_VInt: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s588468714x1874323009_24dps_str3);
          break;
        }
        case TAG_VFloat: {
          heff_take_na(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s588468714x1874323009_24dps_str4);
          break;
        }
        case TAG_VFloat32: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s588468714x1874323009_24dps_str5);
          break;
        }
        case TAG_VStr: {
          V v_s_2432 = heff_field(v_x_2423, 0);
          heff_take_n(v_x_2423, 1ULL, 1);
          v_t_2438 = v_s_2432;
          break;
        }
        case TAG_VRune: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s588468714x1874323009_24dps_str6);
          break;
        }
        case TAG_VArr: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s588468714x1874323009_24dps_str7);
          break;
        }
        case TAG_VBytes: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s588468714x1874323009_24dps_str8);
          break;
        }
        case TAG_VBits: {
          heff_take_n(v_x_2423, 0ULL, 2);
          v_t_2438 = ((V)&g_list_2emap_24s588468714x1874323009_24dps_str9);
          break;
        }
        case TAG_VErased: {
          v_t_2438 = ((V)&g_list_2emap_24s588468714x1874323009_24dps_str10);
          break;
        }
        default: heff_nomatch(v_x_2423);
        }
      } else {
        heff_drop(v_field_2421);
        heff_drop(v_field_2422);
        v_t_2438 = ((V)&g_list_2emap_24s588468714x1874323009_24dps_str11);
      }
    }
    V v_t_2452;
    switch (heff_tag_of(v_v_244)) {
    case TAG_VFun: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2442 = heff_field(v_v_244, 1);
      heff_take_n(v_v_244, 2ULL, 2);
      v_t_2452 = v_vs_2442;
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      heff_take_na(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      heff_take_n(v_v_244, 0ULL, 2);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_244);
    }
    HeffT3 v_t_2453 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2452; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2452); r_; });
    V v_t_2472;
    {
      V v_field_2455 = v_t_2453.f[1];
      V v_field_2456 = v_t_2453.f[2];
      int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
      if ((v_tag_2454 == ((int64_t)0ULL))) {
        V v_x_2457 = v_field_2455;
        V v_x12_2458 = v_field_2456;
        heff_drop(v_x12_2458);
        switch (heff_tag_of(v_x_2457)) {
        case TAG_VFun: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VTag: {
          heff_take_n(v_x_2457, 0ULL, 2);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VInt: {
          V v_i_2463 = heff_field(v_x_2457, 0);
          heff_take_n(v_x_2457, 1ULL, 1);
          v_t_2472 = v_i_2463;
          break;
        }
        case TAG_VFloat: {
          heff_take_na(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VFloat32: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VStr: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VRune: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VArr: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VBytes: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VBits: {
          heff_take_n(v_x_2457, 0ULL, 2);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VErased: {
          v_t_2472 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_x_2457);
        }
      } else {
        heff_drop(v_field_2455);
        heff_drop(v_field_2456);
        v_t_2472 = MK_INT(0LL);
      }
    }
    V v_cell_2473 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, v_t_2472}), heff_hole()});
    V v_u_2474 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2473));
    heff_drop(v_u_2474);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2473;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s588468714x1874323009_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s588468714x1874323009_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1958630276x749154843_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1958630276x749154843_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1958630276x749154843_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_245, 0, 2), v_x_243});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1958630276x749154843_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1958630276x749154843_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s404123879x745642248_str0, 9, "{ name = ");
HEFF_LIT(g_list_2emap_24s404123879x745642248_str1, 8, ", dir = ");
HEFF_LIT(g_list_2emap_24s404123879x745642248_str2, 2, " }");
Clo g_list_2emap_24s404123879x745642248_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s404123879x745642248_entry, 1, 0};

V g_list_2emap_24s404123879x745642248(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_243 = heff_take_field(v_x_241, 0);
    V v_dir_244 = heff_get_n(v_x_241, 1, 2);
    V v_t_245 = ({ V a_0 = v_name_243; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_name_243); r_; });
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s404123879x745642248_str0), v_t_245), ((V)&g_list_2emap_24s404123879x745642248_str1));
    V v_t_247 = ({ V a_0 = v_dir_244; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_dir_244); r_; });
    V v_t_248 = heff_strAppend(heff_strAppend(v_t_246, v_t_247), ((V)&g_list_2emap_24s404123879x745642248_str2));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s404123879x745642248_24dps(v_xs_242, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s404123879x745642248_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s404123879x745642248(a[0]);
}
Clo g_list_2efoldl_24s1516272141x1201056882_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1516272141x1201056882_entry, 3, 0};

V g_list_2efoldl_24s1516272141x1201056882(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2427;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_DeclEquations: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_248 = heff_field(v_a_245, 1);
        heff_take_n(v_a_245, 3ULL, 5);
        v_t_2427 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__kind__span, (V[]){v_a_247, heff_dup(v_lit_240), v_a_248}), NTAG(TAG_Nil)});
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_a_245, 0ULL, 5);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_a_245, 0ULL, 4);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_a_245, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_a_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_a_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2427 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2427, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_2428;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1516272141x1201056882_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1516272141x1201056882(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s510830240x893896831_str0, 0, "");
HEFF_LIT(g_list_2emap_24s510830240x893896831_str1, 2, ", ");
HEFF_LIT(g_list_2emap_24s510830240x893896831_str2, 1, "[");
HEFF_LIT(g_list_2emap_24s510830240x893896831_str3, 1, "]");
HEFF_LIT(g_list_2emap_24s510830240x893896831_str4, 1, " ");
HEFF_LIT(g_list_2emap_24s510830240x893896831_str5, 0, "");
HEFF_LIT(g_list_2emap_24s510830240x893896831_str6, 0, "");
HEFF_LIT(g_list_2emap_24s510830240x893896831_str7, 5, "(path");
HEFF_LIT(g_list_2emap_24s510830240x893896831_str8, 1, ")");
Clo g_list_2emap_24s510830240x893896831_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s510830240x893896831_entry, 2, 0};

V g_list_2emap_24s510830240x893896831(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_244 = heff_dup(v_lit_240);
    V v_x2_245 = v_x_242;
    V v_t_2422;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_ru_24x2_245_24At = heff_take_reuse_n(v_x2_245, 1ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_SetPath: {
        V v_path_248 = heff_field(v_x21_246, 0);
        V v_e_249 = heff_field(v_x21_246, 1);
        heff_take_n(v_x21_246, 3ULL, 2);
        V v_x2_2410 = (g_list_2emap_24s1816200867x1876638332(v_path_248));
        V v_t_2413;
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_Nil: {
          v_t_2413 = ((V)&g_list_2emap_24s510830240x893896831_str0);
          break;
        }
        case TAG_Cons: {
          V v_x_2411 = heff_field(v_x2_2410, 0);
          V v_xs_2412 = heff_field(v_x2_2410, 1);
          heff_take_n(v_x2_2410, 3ULL, 2);
          v_t_2413 = ({ V a_0 = ((V)&g_list_2emap_24s510830240x893896831_str1); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2410);
        }
        V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s510830240x893896831_str2), v_t_2413), ((V)&g_list_2emap_24s510830240x893896831_str3));
        V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_e_249}));
        V v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
        V v_parts_2417 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_Cons, 2, (V[]){v_t_2414, v_t_2416});
        V v_x2_2418 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s510830240x893896831_str4), v_parts_2417));
        V v_t_2421;
        switch (heff_tag_of(v_x2_2418)) {
        case TAG_Nil: {
          v_t_2421 = ((V)&g_list_2emap_24s510830240x893896831_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2419 = heff_field(v_x2_2418, 0);
          V v_xs_2420 = heff_field(v_x2_2418, 1);
          heff_take_n(v_x2_2418, 3ULL, 2);
          v_t_2421 = ({ V a_0 = ((V)&g_list_2emap_24s510830240x893896831_str6); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2418);
        }
        v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s510830240x893896831_str7), v_t_2421), ((V)&g_list_2emap_24s510830240x893896831_str8));
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_cell_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
    V v_u_2424 = (g_list_2emap_24s510830240x893896831_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2423)));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s510830240x893896831_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s510830240x893896831(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s458067099x815639923_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s458067099x815639923_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s458067099x815639923_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (!(heff_dup(heff_rfield(v_x_242, 1)) == NTAG(TAG_True))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
      heff_drop(v_u_245);
      V t_0 = v_xs_243;
      V t_1 = v_cell_244;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 12);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s458067099x815639923_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s458067099x815639923_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s483972445x1090422631_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s483972445x1090422631_24dps_entry, 7, 0};

V g_list_2ekeepIf_24s483972445x1090422631_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_dup(heff_field(v_x_247, 0));
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2412 = (g_list_2emap_24s674081137x339217813(heff_strRunes(v_t_2411)));
    V v_a_2413 = heff_strOfRunes(v_t_2412);
    V v_a_2414 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_a_2413}));
    V v_t_2415 = heff_tr(heff_call(heff_dup(v_a_2414), 1, (V[]){heff_dup(v_lit_240)}));
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_x_247);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_a_2414);
      heff_drop(v_t_2415);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_248;
      V t_6 = v_d_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      v_d_246 = t_6;
      goto top;
    } else {
      heff_drop(v_t_2415);
      V v_t_2416 = heff_tr(heff_call(heff_dup(v_a_2414), 1, (V[]){heff_dup(v_lit_241)}));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_x_247);
        heff_drop_cell(v_ru_24x2_245_24Cons, 2);
        heff_drop(v_a_2414);
        heff_drop(v_t_2416);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_248;
        V t_6 = v_d_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        v_d_246 = t_6;
        goto top;
      } else {
        heff_drop(v_t_2416);
        V v_t_2417 = heff_tr(heff_call(heff_dup(v_a_2414), 1, (V[]){heff_dup(v_lit_242)}));
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x2_245_24Cons, 2);
          heff_drop(v_a_2414);
          heff_drop(v_t_2417);
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_lit_242;
          V t_3 = v_lit_243;
          V t_4 = v_lit_244;
          V t_5 = v_xs_248;
          V t_6 = v_d_246;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_lit_242 = t_2;
          v_lit_243 = t_3;
          v_lit_244 = t_4;
          v_x2_245 = t_5;
          v_d_246 = t_6;
          goto top;
        } else {
          heff_drop(v_t_2417);
          V v_t_2418 = heff_tr(heff_call(heff_dup(v_a_2414), 1, (V[]){heff_dup(v_lit_243)}));
          if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
            heff_drop(v_x_247);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop(v_a_2414);
            heff_drop(v_t_2418);
            V t_0 = v_lit_240;
            V t_1 = v_lit_241;
            V t_2 = v_lit_242;
            V t_3 = v_lit_243;
            V t_4 = v_lit_244;
            V t_5 = v_xs_248;
            V t_6 = v_d_246;
            v_lit_240 = t_0;
            v_lit_241 = t_1;
            v_lit_242 = t_2;
            v_lit_243 = t_3;
            v_lit_244 = t_4;
            v_x2_245 = t_5;
            v_d_246 = t_6;
            goto top;
          } else {
            heff_drop(v_t_2418);
            V v_a_2419 = heff_tr(heff_call(v_a_2414, 1, (V[]){heff_dup(v_lit_244)}));
            if (!(heff_dup(v_a_2419) == NTAG(TAG_True))) {
              heff_drop(v_a_2419);
              V v_cell_2420 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
              V v_u_2421 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2420));
              heff_drop(v_u_2421);
              V t_0 = v_lit_240;
              V t_1 = v_lit_241;
              V t_2 = v_lit_242;
              V t_3 = v_lit_243;
              V t_4 = v_lit_244;
              V t_5 = v_xs_248;
              V t_6 = v_cell_2420;
              v_lit_240 = t_0;
              v_lit_241 = t_1;
              v_lit_242 = t_2;
              v_lit_243 = t_3;
              v_lit_244 = t_4;
              v_x2_245 = t_5;
              v_d_246 = t_6;
              goto top;
            } else {
              heff_drop(v_x_247);
              heff_drop_cell(v_ru_24x2_245_24Cons, 2);
              heff_drop(v_a_2419);
              V t_0 = v_lit_240;
              V t_1 = v_lit_241;
              V t_2 = v_lit_242;
              V t_3 = v_lit_243;
              V t_4 = v_lit_244;
              V t_5 = v_xs_248;
              V t_6 = v_d_246;
              v_lit_240 = t_0;
              v_lit_241 = t_1;
              v_lit_242 = t_2;
              v_lit_243 = t_3;
              v_lit_244 = t_4;
              v_x2_245 = t_5;
              v_d_246 = t_6;
              goto top;
            }
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2ekeepIf_24s483972445x1090422631_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s483972445x1090422631_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s763976875x1978337183_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s763976875x1978337183_24dps_entry, 2, 0};

V g_list_2emap_24s763976875x1978337183_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2edocpages_2epage(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s763976875x1978337183_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s763976875x1978337183_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1628253759x601849359_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1628253759x601849359_24dps_entry, 4, 0};

V g_list_2emap_24s1628253759x601849359_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop_rec(v_lit_241, 5);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_a_246 = heff_dup(heff_rfield(v_lit_240, 3));
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 1)), 0, 2);
    V v_t_248 = heff_strSlice(heff_dup(v_a_246), heff_dup(heff_rfield(v_lit_241, 2)), v_t_247);
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 1)), 1, 2);
    V v_t_2410 = heff_strSlice(v_a_246, v_t_249, heff_dup(heff_rfield(v_lit_241, 4)));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_248, v_x_244), v_t_2410);
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_2412;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1628253759x601849359_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1628253759x601849359_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eany_24s1027174601x1571638094_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1027174601x1571638094_entry, 4, 0};

V g_list_2eany_24s1027174601x1571638094(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_x_244, v_lit_241, v_lit_242, 0))) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s1027174601x1571638094_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2eany_24s1027174601x1571638094(a[0], a1, a2, a3); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2emap_24s328130413x305756849_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s328130413x305756849_entry, 4, 0};

V g_list_2emap_24s328130413x305756849(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_source_246 = heff_take_field(v_x_244, 1);
    V v_span_247 = heff_get_n(v_x_244, 2, 4);
    V v_t_248 = ({ V a_0 = v_source_246; V a_1 = v_span_247; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_246); r_; });
    V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_lit_241), heff_tag_n(TAG_JInt, 1, (V[]){heff_dup(v_lit_242)})});
    V v_t_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_lit_240), v_t_248}), v_t_2410});
    V v_cell_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2411}), heff_hole()});
    V v_u_2413 = (g_list_2emap_24s328130413x305756849_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s328130413x305756849_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s328130413x305756849(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_list_2emap_24s456747242x756515627_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s456747242x756515627_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s456747242x756515627_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s456747242x756515627_24dps_str3, 0, "");
Clo g_list_2emap_24s456747242x756515627_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s456747242x756515627_24dps_entry, 2, 0};

V g_list_2emap_24s456747242x756515627_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_f_244 = v_x_242;
    V v_t_2413;
    if (heff_strEq_c(heff_dup(heff_rfield(v_f_244, 2)), ((V)&g_list_2emap_24s456747242x756515627_24dps_str0))) {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2413 = heff_tag_n(TAG_Picked, 1, (V[]){heff_rec_n(2, shape_options__at, (V[]){heff_dup(g_std_2ecli_2einteractive_2eswitchOptions_get()), MK_INT(0LL)})});
    } else {
      V v_t_245 = heff_dup(heff_rfield(v_f_244, 4));
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        V v_t_246 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_list_2emap_24s456747242x756515627_24dps_str1)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        V v_t_247 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_list_2emap_24s456747242x756515627_24dps_str2)), v_t_246});
        v_t_2413 = heff_tag_n(TAG_Typed, 1, (V[]){v_t_247});
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_245, 0ULL, 2);
        V v_t_2410 = heff_dup(heff_rfield(v_f_244, 6));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_t_2410);
          V v_t_2411 = heff_rec_n(2, shape_options__at, (V[]){heff_dup(heff_rfield(v_f_244, 4)), MK_INT(0LL)});
          v_t_2413 = heff_tag_n(TAG_Picked, 1, (V[]){v_t_2411});
        } else {
          heff_drop(v_t_2410);
          V v_t_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_list_2emap_24s456747242x756515627_24dps_str3), heff_dup(heff_rfield(v_f_244, 4))});
          v_t_2413 = heff_tag_n(TAG_Picked, 1, (V[]){heff_rec_n(2, shape_options__at, (V[]){v_t_2412, MK_INT(0LL)})});
        }
        break;
      }
      default: heff_nomatch(v_t_245);
      }
    }
    V v_t_2414 = heff_rec_n(2, shape_part__input, (V[]){heff_tag_n(TAG_Flagged, 1, (V[]){v_f_244}), v_t_2413});
    V v_cell_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2415;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s456747242x756515627_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s456747242x756515627_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f1221888634x716224461_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1221888634x716224461_24dps_entry, 3, 0};

V g_list_2emap_24f1221888634x716224461_24dps(V v_lit_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_CondTrue: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_CondFalse: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_CondRel: {
    V v_es_244 = heff_field(v_x1_241, 1);
    V v_t_245 = (g_list_2emap_24s215892288x1392224072(v_lit_240, heff_dup(v_es_244)));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_245);
  }
  case TAG_CondRelU: {
    V v_es_247 = heff_field(v_x1_241, 1);
    V v_t_248 = (g_list_2emap_24s215892288x1392224072(v_lit_240, heff_dup(v_es_247)));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_248);
  }
  case TAG_CondBool: {
    V v_e_249 = heff_field(v_x1_241, 0);
    V v_t_2410 = (g_list_2emap_24s215892288x1392224072(heff_dup(v_lit_240), NTAG(TAG_Nil)));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_lit_240, heff_dup(v_e_249)}), v_t_2410});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2411);
  }
  case TAG_CondNot: {
    V v_c_2412 = heff_field(v_x1_241, 0);
    V t_0 = v_lit_240;
    V t_1 = v_c_2412;
    V t_2 = v_d_242;
    v_lit_240 = t_0;
    v_x1_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_CondIf: {
    V v_a_2413 = heff_field(v_x1_241, 0);
    V v_b_2414 = heff_field(v_x1_241, 1);
    V v_c_2415 = heff_field(v_x1_241, 2);
    V v_t_2416 = (g_heff_2ecompile_2eowned_2econdKids(v_a_2413));
    V v_t_2417 = (g_heff_2ecompile_2eowned_2econdKids(v_b_2414));
    V v_t_2418 = (g_heff_2ecompile_2eowned_2econdKids(v_c_2415));
    V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2418));
    V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2419));
    V v_t_2421 = (g_list_2emap_24s215892288x1392224072(v_lit_240, v_t_2420));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2421);
  }
  case TAG_CondLet: {
    V v_e_2423 = heff_field(v_x1_241, 1);
    V v_c_2424 = heff_field(v_x1_241, 2);
    V v_cell_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_e_2423)}), heff_hole()});
    V v_u_2427 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2426));
    heff_drop(v_u_2427);
    V t_0 = v_lit_240;
    V t_1 = v_c_2424;
    V t_2 = v_cell_2426;
    v_lit_240 = t_0;
    v_x1_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2emap_24f1221888634x716224461_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24f1221888634x716224461_24dps(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24f428638463x2144521938_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f428638463x2144521938_entry, 4, 0};

V g_list_2ekeepIf_24f428638463x2144521938(V v_lit_240, V v_lit_241, V v_lit_242, V v_x1_243) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_xs_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24Cons = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x1_243 = t_3;
      goto top;
    }
    case TAG_Just: {
      V v_x_246 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      if (!heff_strEq_c(heff_strSlice_lent(v_x_246, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24x1_243_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
        V v_u_248 = (g_list_2ekeepIf_24f428638463x2144521938_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        heff_drop_cell(v_ru_24x1_243_24Cons, 2);
        heff_drop(v_x_246);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_245;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x1_243 = t_3;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_244);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_list_2ekeepIf_24f428638463x2144521938_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24f428638463x2144521938(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24f869471183x993026796_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f869471183x993026796_entry, 3, 0};

V g_list_2emap_24f869471183x993026796(V v_lit_240, V v_box_24lit_241, V v_x2_242) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if ((v_lit_241 < heff_unbox_word(heff_strLength_lent(v_x_243, 0)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_243), heff_hole()});
      V v_u_246 = (g_list_2emap_24f869471183x993026796_24dps(v_lit_240, heff_box_word(v_lit_241), v_xs_244, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f869471183x993026796_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f869471183x993026796(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f319030394x1380151895_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f319030394x1380151895_entry, 3, 0};

V g_list_2efoldl_24f319030394x1380151895(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 6, 10);
    if (!(heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f319030394x1380151895_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f319030394x1380151895(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1176765648x1638512070_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1176765648x1638512070_entry, 12, 0};

V g_list_2emap_24f1176765648x1638512070(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_lit_244, V v_lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_lit_248, V v_lit_249, V v_box_24lit_2410, V v_x2_2411) {
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_246 = heff_unbox_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_unbox_word(v_box_24lit_247);
  int64_t v_lit_2410 = heff_unbox_word(v_box_24lit_2410);
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24Cons = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_name_2414 = heff_take_field(v_x_2412, 0);
    V v_key_2415 = heff_get_n(v_x_2412, 1, 2);
    V v_a_2416 = heff_dup(v_name_2414);
    if ((heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_lit_241, v_a_2416, v_lit_242, 0)) ? (((v_lit_243 <= heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_245, 0)) <= v_lit_246)) ? 0 : ((v_lit_247 <= heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_248, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_a_2416, v_lit_249, 0)) <= v_lit_2410) : 1)) : 1)) {
      heff_drop(v_a_2416);
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_2411_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_2414, v_key_2415}), heff_hole()});
      V v_u_2418 = (g_list_2emap_24f1176765648x1638512070_24dps(v_lit_240, v_lit_241, v_lit_242, heff_box_word(v_lit_243), v_lit_244, v_lit_245, heff_box_word(v_lit_246), heff_box_word(v_lit_247), v_lit_248, v_lit_249, heff_box_word(v_lit_2410), v_xs_2413, heff_dup(v_cell_2417)));
      heff_drop(v_u_2418);
      return v_cell_2417;
    } else {
      heff_drop_cell(v_ru_24x2_2411_24Cons, 2);
      heff_drop(v_name_2414);
      heff_drop(v_key_2415);
      heff_drop(v_a_2416);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2emap_24f1176765648x1638512070_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a8 = a[8]; V a9 = a[9]; V r = g_list_2emap_24f1176765648x1638512070(a[0], a1, a2, a[3], a4, a5, a[6], a[7], a8, a9, a[10], a[11]); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a8); heff_drop(a9); return r;
}
Clo g_list_2emap_24f1176765648x1638512070_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1176765648x1638512070_24dps_entry, 13, 0};

V g_list_2emap_24f1176765648x1638512070_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_lit_244, V v_lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_lit_248, V v_lit_249, V v_box_24lit_2410, V v_x2_2411, V v_d_2412) {
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
  int64_t v_lit_246 = heff_unbox_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_unbox_word(v_box_24lit_247);
  int64_t v_lit_2410 = heff_unbox_word(v_box_24lit_2410);
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_2412, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2411, 0);
    V v_xs_2414 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24Cons = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_name_2415 = heff_take_field(v_x_2413, 0);
    V v_key_2416 = heff_get_n(v_x_2413, 1, 2);
    V v_a_2417 = heff_dup(v_name_2415);
    if ((heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_lit_241, v_a_2417, v_lit_242, 0)) ? (((v_lit_243 <= heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_245, 0)) <= v_lit_246)) ? 0 : ((v_lit_247 <= heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_248, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_a_2417, v_lit_249, 0)) <= v_lit_2410) : 1)) : 1)) {
      heff_drop(v_a_2417);
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_2411_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_2415, v_key_2416}), heff_hole()});
      V v_u_2419 = heff_setField(v_d_2412, MK_INT(1LL), heff_dup(v_cell_2418));
      heff_drop(v_u_2419);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2414;
      V t_12 = v_cell_2418;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      v_d_2412 = t_12;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_2411_24Cons, 2);
      heff_drop(v_name_2415);
      heff_drop(v_key_2416);
      heff_drop(v_a_2417);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2414;
      V t_12 = v_d_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      v_d_2412 = t_12;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2emap_24f1176765648x1638512070_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a8 = a[8]; V a9 = a[9]; V r = g_list_2emap_24f1176765648x1638512070_24dps(a[0], a1, a2, a[3], a4, a5, a[6], a[7], a8, a9, a[10], a[11], a[12]); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a8); heff_drop(a9); return r;
}