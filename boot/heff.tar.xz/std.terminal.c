// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Begin 41697
#define TAG_Continue 52606
#define TAG_Done 47505
#define TAG_Draw 50003
#define TAG_Finish 61316
#define TAG_Interactive 42932
#define TAG_Measure 52418
#define TAG_ReadInput 54226
#define LBL_columns 1181578779
#define LBL_cursor 598022785
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_rows 10002080
#define LBL_start 311115900
#define LBL_step 10036115
#define LBL_view 10114924
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287(V);
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_clo;
V g_std_2eterminal_2econsole_get(void);
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400(V, V, V);
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400_entry(V self, V *a);
extern Clo g_std_2eterminal_2einteractWith_24s1999309355x1375671400_clo;
V g_std_2eterminal_2eloop_24s462750511x1514375825(V, V, V, V);
V g_std_2eterminal_2eloop_24s462750511x1514375825_entry(V self, V *a);
extern Clo g_std_2eterminal_2eloop_24s462750511x1514375825_clo;
V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244(V, V);
V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_clo;
V g_std_2eterminal_2ewidget_2epaintSpans(V, V);
V g_std_2eterminal_2ewidget_2epaintSpans_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2epaintSpans_clo;
HeffT2 g_std_2eterminal_2ewidget_2estepAll_24cpr(V, V, V);
V g_std_2eterminal_2econsole_lam1(V self, V *args);
V g_std_2eterminal_2econsole_lam2(V self, V *args);
V g_std_2eterminal_2econsole_lam3(V self, V *args);
V g_std_2eterminal_2econsole_lam4(V self, V *args);
V g_std_2eterminal_2econsole_lam0(V self, V *args); static Clo g_std_2eterminal_2econsole_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2econsole_lam0, 3, 0};
V g_std_2eterminal_2econsole_lam5(V self, V *args); static Clo g_std_2eterminal_2econsole_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2econsole_lam5, 4, 0};

static V g_std_2eterminal_2econsole_val;
static HEFF_ONCE g_std_2eterminal_2econsole_st;
static V g_std_2eterminal_2econsole_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2eterminal_2econsole_lam0_clo), ((V)&g_std_2eterminal_2econsole_lam5_clo)});
}
V g_std_2eterminal_2econsole_get(void) {
  if (HEFF_DONE(g_std_2eterminal_2econsole_st)) return g_std_2eterminal_2econsole_val;
  return heff_global(&g_std_2eterminal_2econsole_val, &g_std_2eterminal_2econsole_st, g_std_2eterminal_2econsole_init);
}
V g_std_2eterminal_2econsole_lam1(V self, V *args) {
  V v_b_244 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_tr(heff_call(v_k_243, 1, (V[]){v_b_244}));
  V f_ = v_g_241;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eterminal_2econsole_lam2(V self, V *args) {
  V v_b_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_k_246, 1, (V[]){v_b_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eterminal_2econsole_lam3(V self, V *args) {
  V v_s_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_k_2411, 1, (V[]){v_s_2412}));
  V f_ = v_g_241;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eterminal_2econsole_lam4(V self, V *args) {
  V v_s_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tr(heff_call(v_k_2414, 1, (V[]){v_s_2415}));
  V f_ = v_g_241;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eterminal_2econsole_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Interactive: {
    V v_k_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Interactive = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Interactive, TAG_Interactive, 1, (V[]){heff_clo_n(g_std_2eterminal_2econsole_lam1, 1, 2, (V[]){v_k_243, v_g_241})});
  }
  case TAG_Begin: {
    V v_k_246 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Begin = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Begin, TAG_Begin, 1, (V[]){heff_clo_n(g_std_2eterminal_2econsole_lam2, 1, 2, (V[]){v_k_246, v_g_241})});
  }
  case TAG_Finish: {
    V v_x_249 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Finish = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2410 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_249}));
    return heff_tag_at_n(v_ru_24p_242_24Finish, TAG_Finish, 1, (V[]){v_t_2410});
  }
  case TAG_Measure: {
    V v_k_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Measure = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Measure, TAG_Measure, 1, (V[]){heff_clo_n(g_std_2eterminal_2econsole_lam3, 1, 2, (V[]){v_k_2411, v_g_241})});
  }
  case TAG_ReadInput: {
    V v_k_2414 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24ReadInput = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24ReadInput, TAG_ReadInput, 1, (V[]){heff_clo_n(g_std_2eterminal_2econsole_lam4, 1, 2, (V[]){v_k_2414, v_g_241})});
  }
  case TAG_Draw: {
    V v_s_2417 = heff_field(v_p_242, 0);
    V v_x_2418 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Draw = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2419 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2418}));
    return heff_tag_re_n(v_ru_24p_242_24Draw, TAG_Draw, 2, 1ULL, (V[]){v_s_2417, v_t_2419});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2eterminal_2econsole_lam5(V self, V *args) {
  V v_m_2420 = args[0];
  V v_n_2421 = args[1];
  V v_nt_2422 = args[2];
  V v_p_2423 = args[3];
  heff_drop(v_m_2420);
  heff_drop(v_n_2421);
  heff_drop(v_nt_2422);
  return v_p_2423;
}
HEFF_LIT(g_std_2eterminal_2eloop_24s462750511x1514375825_str0, 7, "\033[0m\033[K");
HEFF_LIT(g_std_2eterminal_2eloop_24s462750511x1514375825_str1, 0, "");
HEFF_LIT(g_std_2eterminal_2eloop_24s462750511x1514375825_str2, 2, "\015\012");
HEFF_LIT(g_std_2eterminal_2eloop_24s462750511x1514375825_str3, 0, "");
HEFF_LIT(g_std_2eterminal_2eloop_24s462750511x1514375825_str4, 2, "\033[");
HEFF_LIT(g_std_2eterminal_2eloop_24s462750511x1514375825_str5, 1, ";");
HEFF_LIT(g_std_2eterminal_2eloop_24s462750511x1514375825_str6, 7, "H\033[\?25h");
HEFF_LIT(g_std_2eterminal_2eloop_24s462750511x1514375825_str7, 17, "\033[\?2026h\033[\?25l\033[H");
HEFF_LIT(g_std_2eterminal_2eloop_24s462750511x1514375825_str8, 7, "\033[0m\033[J");
HEFF_LIT(g_std_2eterminal_2eloop_24s462750511x1514375825_str9, 8, "\033[\?2026l");
V g_std_2eterminal_2eloop_24s462750511x1514375825_lam1(V self, V *args); static Clo g_std_2eterminal_2eloop_24s462750511x1514375825_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2eloop_24s462750511x1514375825_lam1, 1, 0};
V g_std_2eterminal_2eloop_24s462750511x1514375825_lam3(V self, V *args);
V g_std_2eterminal_2eloop_24s462750511x1514375825_lam5(V self, V *args); static Clo g_std_2eterminal_2eloop_24s462750511x1514375825_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2eloop_24s462750511x1514375825_lam5, 1, 0};
V g_std_2eterminal_2eloop_24s462750511x1514375825_lam6(V self, V *args);
V g_std_2eterminal_2eloop_24s462750511x1514375825_lam4(V self, V *args);
V g_std_2eterminal_2eloop_24s462750511x1514375825_lam2(V self, V *args);
V g_std_2eterminal_2eloop_24s462750511x1514375825_lam0(V self, V *args);
Clo g_std_2eterminal_2eloop_24s462750511x1514375825_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2eloop_24s462750511x1514375825_entry, 4, 0};

V g_std_2eterminal_2eloop_24s462750511x1514375825(V v_app_240, V v_at_241, V v_z_242, V v_z_243) {
top: ;
  V v_c_244 = (g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287(v_at_241));
  return heff_tail(v_c_244, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_std_2eterminal_2eloop_24s462750511x1514375825_lam0, 1, 3, (V[]){v_z_242, v_app_240, v_z_243})});
}
V g_std_2eterminal_2eloop_24s462750511x1514375825_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2eloop_24s462750511x1514375825(a[0], a[1], a[2], a[3]);
}
V g_std_2eterminal_2eloop_24s462750511x1514375825_lam1(V self, V *args) {
  V v_s_246 = args[0];
  return v_s_246;
}
V g_std_2eterminal_2eloop_24s462750511x1514375825_lam3(V self, V *args) {
  V v_r_2418 = args[0];
  V v_columns_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = ({ V a_0 = v_columns_2413; V a_1 = v_r_2418; V r_ = (g_std_2eterminal_2ewidget_2epaintSpans(a_0, a_1)); heff_drop(v_r_2418); r_; });
  return heff_strAppend(v_t_2419, ((V)&g_std_2eterminal_2eloop_24s462750511x1514375825_str0));
}
V g_std_2eterminal_2eloop_24s462750511x1514375825_lam5(V self, V *args) {
  V v_s_2439 = args[0];
  return v_s_2439;
}
V g_std_2eterminal_2eloop_24s462750511x1514375825_lam6(V self, V *args) {
  V v_x_2443 = args[0];
  V v_app_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_f_2444 = heff_dup(heff_rfield(v_app_240, 1));
  heff_clo_take(self, 4);
  V v_st_2445 = v_x_245;
  V v_x3_2446 = v_x_2443;
  V v_t_2457;
  switch (heff_tag_of(v_x3_2446)) {
  case TAG_Nothing: {
    heff_drop(v_f_2444);
    heff_drop(v_st_2445);
    v_t_2457 = heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_Nothing)});
    break;
  }
  case TAG_Just: {
    V v_input_2447 = heff_field(v_x3_2446, 0);
    V v_ru_24x3_2446_24Just = heff_take_reuse_n(v_x3_2446, 1ULL, 1);
    V v_x3_2448 = (g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244(v_input_2447, MK_INT(0LL)));
    switch (heff_tag_of(v_x3_2448)) {
    case TAG_Nil: {
      heff_drop(v_f_2444);
      heff_drop_cell(v_ru_24x3_2446_24Just, 1);
      v_t_2457 = heff_tag_n(TAG_Continue, 1, (V[]){v_st_2445});
      break;
    }
    case TAG_Cons: {
      V v_k_2449 = heff_field(v_x3_2448, 0);
      V v_ks_2450 = heff_field(v_x3_2448, 1);
      heff_take_n(v_x3_2448, 3ULL, 2);
      V v_t_2451 = heff_tr(heff_call(heff_dup(v_f_2444), 2, (V[]){v_k_2449, v_st_2445}));
      HeffT2 v_t_2452 = ({ V a_0 = v_f_2444; V a_1 = v_t_2451; V a_2 = v_ks_2450; HeffT2 r_ = (g_std_2eterminal_2ewidget_2estepAll_24cpr(a_0, a_1, a_2)); heff_drop(v_ks_2450); r_; });
      {
        V v_field_2454 = v_t_2452.f[1];
        int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
        if ((v_tag_2453 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x3_2446_24Just, 1);
          V v_st_2455 = v_field_2454;
          v_t_2457 = heff_tag_n(TAG_Continue, 1, (V[]){v_st_2455});
        } else {
          V v_r_2456 = v_field_2454;
          v_t_2457 = heff_tag_n(TAG_Done, 1, (V[]){heff_tag_at_n(v_ru_24x3_2446_24Just, TAG_Just, 1, (V[]){v_r_2456})});
        }
      }
      break;
    }
    default: heff_nomatch(v_x3_2448);
    }
    break;
  }
  default: heff_nomatch(v_x3_2446);
  }
  switch (heff_tag_of(v_t_2457)) {
  case TAG_Continue: {
    V v_next_2458 = heff_field(v_t_2457, 0);
    heff_take_n(v_t_2457, 1ULL, 1);
    return (g_std_2eterminal_2eloop_24s462750511x1514375825(v_app_240, v_next_2458, v_z_242, v_z_243));
  }
  case TAG_Done: {
    V v_r_2459 = heff_field(v_t_2457, 0);
    heff_take_n(v_t_2457, 1ULL, 1);
    heff_drop_rec(v_app_240, 3);
    heff_drop(v_z_242);
    V f_ = v_z_243;
    args[0] = v_r_2459;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2457);
  }
}
V g_std_2eterminal_2eloop_24s462750511x1514375825_lam4(V self, V *args) {
  V v_x_2438 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_app_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_drop(v_x_2438);
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadInput, 1, (V[]){((V)&g_std_2eterminal_2eloop_24s462750511x1514375825_lam5_clo)})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), heff_dup(v_z_242), heff_clo_n(g_std_2eterminal_2eloop_24s462750511x1514375825_lam6, 1, 4, (V[]){v_app_240, v_x_245, v_z_242, v_z_243})));
}
V g_std_2eterminal_2eloop_24s462750511x1514375825_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_app_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_size_2411 = heff_dup(v_x_2410);
  V v_rows_2412 = heff_take_field(v_size_2411, 1);
  V v_columns_2413 = heff_get_n(v_size_2411, 0, 2);
  V v_f_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_app_240, 2)), 2, (V[]){v_x_2410, heff_dup(v_x_245)}));
  V v_rows_2415 = heff_take_field(v_f_2414, 0);
  V v_cursor_2416 = heff_get_n(v_f_2414, 1, 2);
  V v_t_2417 = (g_list_2etake(v_rows_2412, v_rows_2415));
  V v_x2_2420 = (g_list_2emap(heff_clo_n(g_std_2eterminal_2eloop_24s462750511x1514375825_lam3, 1, 1, (V[]){v_columns_2413}), v_t_2417));
  V v_t_2423;
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_Nil: {
    v_t_2423 = ((V)&g_std_2eterminal_2eloop_24s462750511x1514375825_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_xs_2422 = heff_field(v_x2_2420, 1);
    heff_take_n(v_x2_2420, 3ULL, 2);
    v_t_2423 = ({ V a_0 = ((V)&g_std_2eterminal_2eloop_24s462750511x1514375825_str2); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2420);
  }
  V v_t_2424 = v_cursor_2416;
  V v_t_2431;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_Nothing: {
    v_t_2431 = ((V)&g_std_2eterminal_2eloop_24s462750511x1514375825_str3);
    break;
  }
  case TAG_Just: {
    V v_x11_2425 = heff_field(v_t_2424, 0);
    heff_take_n(v_t_2424, 1ULL, 1);
    switch (heff_tag_of(v_x11_2425)) {
    case TAG_MkPair: {
      V v_c_2426 = heff_field(v_x11_2425, 0);
      V v_r_2427 = heff_field(v_x11_2425, 1);
      heff_take_n(v_x11_2425, 3ULL, 2);
      V v_t_2428 = heff_intShow(heff_intAdd(v_r_2427, MK_INT(1LL)));
      V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_std_2eterminal_2eloop_24s462750511x1514375825_str4), v_t_2428), ((V)&g_std_2eterminal_2eloop_24s462750511x1514375825_str5));
      V v_t_2430 = heff_intShow(heff_intAdd(v_c_2426, MK_INT(1LL)));
      v_t_2431 = heff_strAppend(heff_strAppend(v_t_2429, v_t_2430), ((V)&g_std_2eterminal_2eloop_24s462750511x1514375825_str6));
      break;
    }
    default: heff_nomatch(v_x11_2425);
    }
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_std_2eterminal_2eloop_24s462750511x1514375825_str7), v_t_2423), ((V)&g_std_2eterminal_2eloop_24s462750511x1514375825_str8));
  V v_s_2433 = heff_strAppend(heff_strAppend(v_t_2432, v_t_2431), ((V)&g_std_2eterminal_2eloop_24s462750511x1514375825_str9));
  V v_t_2434 = heff_tag_n(TAG_Draw, 2, (V[]){v_s_2433, NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s535099379x685970669(v_t_2437, heff_dup(v_z_242), heff_clo_n(g_std_2eterminal_2eloop_24s462750511x1514375825_lam4, 1, 4, (V[]){v_z_242, v_app_240, v_x_245, v_z_243})));
}
V g_std_2eterminal_2eloop_24s462750511x1514375825_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_app_240 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Measure, 1, (V[]){((V)&g_std_2eterminal_2eloop_24s462750511x1514375825_lam1_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  heff_clo_take(self, 3);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_z_242), heff_clo_n(g_std_2eterminal_2eloop_24s462750511x1514375825_lam2, 1, 4, (V[]){v_app_240, v_x_245, v_z_242, v_z_243})));
}
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400_lam0(V self, V *args); static Clo g_std_2eterminal_2einteractWith_24s1999309355x1375671400_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2einteractWith_24s1999309355x1375671400_lam0, 1, 0};
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400_lam3(V self, V *args);
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400_lam2(V self, V *args);
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400_lam1(V self, V *args);
Clo g_std_2eterminal_2einteractWith_24s1999309355x1375671400_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2einteractWith_24s1999309355x1375671400_entry, 3, 0};

V g_std_2eterminal_2einteractWith_24s1999309355x1375671400(V v_app_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Begin, 1, (V[]){((V)&g_std_2eterminal_2einteractWith_24s1999309355x1375671400_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_245})});
  HEFF_LAST return g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_246}), heff_dup(v_hd_241), heff_clo_n(g_std_2eterminal_2einteractWith_24s1999309355x1375671400_lam1, 1, 3, (V[]){v_app_240, v_hd_241, v_k_242}));
}
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2einteractWith_24s1999309355x1375671400(a[0], a[1], a[2]);
}
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400_lam0(V self, V *args) {
  V v_b_243 = args[0];
  return v_b_243;
}
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_drop(v_x_2413);
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_t_249 = heff_tag_n(TAG_Finish, 1, (V[]){NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(v_t_2412, v_hd_241, heff_clo_n(g_std_2eterminal_2einteractWith_24s1999309355x1375671400_lam3, 1, 2, (V[]){v_k_242, v_x_248})));
}
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_app_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
    heff_drop(v_x_247);
    heff_clo_take(self, 3);
    return (g_std_2eterminal_2eloop_24s462750511x1514375825(heff_dup(v_app_240), heff_get_n(v_app_240, 0, 3), heff_dup(v_hd_241), heff_clo_n(g_std_2eterminal_2einteractWith_24s1999309355x1375671400_lam2, 1, 2, (V[]){v_hd_241, v_k_242})));
  } else {
    heff_drop(v_x_247);
    heff_clo_take(self, 3);
    heff_drop_rec(v_app_240, 3);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}