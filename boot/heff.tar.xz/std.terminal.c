// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Begin 41697
#define TAG_Continue 52606
#define TAG_Draw 50003
#define TAG_Finish 61316
#define TAG_Interactive 42932
#define TAG_Measure 52418
#define TAG_ReadInput 54226
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_start 311115900
#define LBL_step 10036115
#define LBL_view 10114924
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_std_2eterminal_2econsole_get(void);
V g_std_2eterminal_2einteract_24s565449676x1025154109(V, V);
V g_std_2eterminal_2einteract_24s565449676x1025154109_entry(V self, V *a);
extern Clo g_std_2eterminal_2einteract_24s565449676x1025154109_clo;
V g_std_2eterminal_2eloop_24s128358813x21722470(V, V, V);
V g_std_2eterminal_2eloop_24s128358813x21722470_entry(V self, V *a);
extern Clo g_std_2eterminal_2eloop_24s128358813x21722470_clo;
V g_std_2eterminal_2ewidget_2edecodeFrom(V, V);
V g_std_2eterminal_2ewidget_2edecodeFrom_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2edecodeFrom_clo;
V g_std_2eterminal_2ewidget_2epaint(V, V);
V g_std_2eterminal_2ewidget_2epaint_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2epaint_clo;
HeffT2 g_std_2eterminal_2ewidget_2estepAll_24cpr(V, V, V);
V g_std_2eterminal_2econsole_lam1(V self, V *args);
V g_std_2eterminal_2econsole_lam2(V self, V *args);
V g_std_2eterminal_2econsole_lam3(V self, V *args);
V g_std_2eterminal_2econsole_lam4(V self, V *args);
V g_std_2eterminal_2econsole_lam0(V self, V *args); static Clo g_std_2eterminal_2econsole_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2econsole_lam0, 3, 0};
V g_std_2eterminal_2econsole_lam5(V self, V *args); static Clo g_std_2eterminal_2econsole_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2econsole_lam5, 4, 0};

static V g_std_2eterminal_2econsole_val;
static HEFF_ONCE g_std_2eterminal_2econsole_st;
static V g_std_2eterminal_2econsole_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2eterminal_2econsole_lam0_clo), ((V)&g_std_2eterminal_2econsole_lam5_clo)});
}
V g_std_2eterminal_2econsole_get(void) {
  if (HEFF_DONE(g_std_2eterminal_2econsole_st)) return g_std_2eterminal_2econsole_val;
  return heff_global(&g_std_2eterminal_2econsole_val, &g_std_2eterminal_2econsole_st, g_std_2eterminal_2econsole_init);
}
V g_std_2eterminal_2econsole_lam1(V self, V *args) {
  V v_b_244 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_tr(heff_call(v_k_243, 1, (V[]){v_b_244}));
  V f_ = v_g_241;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eterminal_2econsole_lam2(V self, V *args) {
  V v_b_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_k_246, 1, (V[]){v_b_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eterminal_2econsole_lam3(V self, V *args) {
  V v_s_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_k_2411, 1, (V[]){v_s_2412}));
  V f_ = v_g_241;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eterminal_2econsole_lam4(V self, V *args) {
  V v_s_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tr(heff_call(v_k_2414, 1, (V[]){v_s_2415}));
  V f_ = v_g_241;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eterminal_2econsole_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Interactive: {
    V v_k_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Interactive = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Interactive, TAG_Interactive, 1, (V[]){heff_clo_n(g_std_2eterminal_2econsole_lam1, 1, 2, (V[]){v_k_243, v_g_241})});
  }
  case TAG_Begin: {
    V v_k_246 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Begin = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Begin, TAG_Begin, 1, (V[]){heff_clo_n(g_std_2eterminal_2econsole_lam2, 1, 2, (V[]){v_k_246, v_g_241})});
  }
  case TAG_Finish: {
    V v_x_249 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Finish = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2410 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_249}));
    return heff_tag_at_n(v_ru_24p_242_24Finish, TAG_Finish, 1, (V[]){v_t_2410});
  }
  case TAG_Measure: {
    V v_k_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Measure = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Measure, TAG_Measure, 1, (V[]){heff_clo_n(g_std_2eterminal_2econsole_lam3, 1, 2, (V[]){v_k_2411, v_g_241})});
  }
  case TAG_ReadInput: {
    V v_k_2414 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24ReadInput = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24ReadInput, TAG_ReadInput, 1, (V[]){heff_clo_n(g_std_2eterminal_2econsole_lam4, 1, 2, (V[]){v_k_2414, v_g_241})});
  }
  case TAG_Draw: {
    V v_s_2417 = heff_field(v_p_242, 0);
    V v_x_2418 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Draw = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2419 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2418}));
    return heff_tag_at_n(v_ru_24p_242_24Draw, TAG_Draw, 2, (V[]){v_s_2417, v_t_2419});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2eterminal_2econsole_lam5(V self, V *args) {
  V v_m_2420 = args[0];
  V v_n_2421 = args[1];
  V v_nt_2422 = args[2];
  V v_p_2423 = args[3];
  heff_drop(v_m_2420);
  heff_drop(v_n_2421);
  heff_drop(v_nt_2422);
  return v_p_2423;
}
V g_std_2eterminal_2eloop_24s128358813x21722470_lam0(V self, V *args); static Clo g_std_2eterminal_2eloop_24s128358813x21722470_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2eloop_24s128358813x21722470_lam0, 1, 0};
V g_std_2eterminal_2eloop_24s128358813x21722470_lam4(V self, V *args); static Clo g_std_2eterminal_2eloop_24s128358813x21722470_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2eloop_24s128358813x21722470_lam4, 1, 0};
V g_std_2eterminal_2eloop_24s128358813x21722470_lam5(V self, V *args);
V g_std_2eterminal_2eloop_24s128358813x21722470_lam3(V self, V *args);
V g_std_2eterminal_2eloop_24s128358813x21722470_lam2(V self, V *args);
V g_std_2eterminal_2eloop_24s128358813x21722470_lam1(V self, V *args);
Clo g_std_2eterminal_2eloop_24s128358813x21722470_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2eloop_24s128358813x21722470_entry, 3, 0};

V g_std_2eterminal_2eloop_24s128358813x21722470(V v_ev_240, V v_app_241, V v_st_242) {
top: ;
  V v_t_244 = heff_tr(heff_call(heff_dup(v_ev_240), 1, (V[]){heff_tag_n(TAG_Measure, 1, (V[]){((V)&g_std_2eterminal_2eloop_24s128358813x21722470_lam0_clo)})}));
  return heff_clo_n(g_std_2eterminal_2eloop_24s128358813x21722470_lam1, 2, 4, (V[]){v_t_244, v_app_241, v_st_242, v_ev_240});
}
V g_std_2eterminal_2eloop_24s128358813x21722470_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2eloop_24s128358813x21722470(a[0], a[1], a[2]);
}
V g_std_2eterminal_2eloop_24s128358813x21722470_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_std_2eterminal_2eloop_24s128358813x21722470_lam4(V self, V *args) {
  V v_s_2413 = args[0];
  return v_s_2413;
}
V g_std_2eterminal_2eloop_24s128358813x21722470_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_app_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_ev_240 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    heff_drop_rec(v_app_241, 3);
    heff_drop(v_st_242);
    heff_drop(v_ev_240);
    heff_drop(v_hd_245);
    V f_ = v_k_246;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_input_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Just = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    V v_t_2417 = ({ V a_0 = v_input_2416; V a_1 = MK_INT(0LL); V r_ = (g_std_2eterminal_2ewidget_2edecodeFrom(a_0, a_1)); heff_drop(v_input_2416); r_; });
    HeffT2 v_t_2418 = ({ V a_0 = heff_dup(heff_rfield(v_app_241, 1)); V a_1 = heff_tag_at_n(v_ru_24x_2415_24Just, TAG_Continue, 1, (V[]){v_st_242}); V a_2 = v_t_2417; HeffT2 r_ = (g_std_2eterminal_2ewidget_2estepAll_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_st_2421 = v_field_2420;
        V v_t_2422 = (g_std_2eterminal_2eloop_24s128358813x21722470(v_ev_240, v_app_241, v_st_2421));
        V f_ = v_t_2422;
        heff_room[0] = v_hd_245;
        heff_room[1] = v_k_246;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_rec(v_app_241, 3);
        heff_drop(v_ev_240);
        heff_drop(v_hd_245);
        V v_r_2423 = v_field_2420;
        V f_ = v_k_246;
        args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_r_2423});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_std_2eterminal_2eloop_24s128358813x21722470_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ev_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_app_241 = heff_env(self)[3];
  V v_st_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2412);
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_ev_240), 1, (V[]){heff_tag_n(TAG_ReadInput, 1, (V[]){((V)&g_std_2eterminal_2eloop_24s128358813x21722470_lam4_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2414, heff_dup(v_hd_245), heff_clo_n(g_std_2eterminal_2eloop_24s128358813x21722470_lam5, 1, 5, (V[]){v_k_246, v_app_241, v_st_242, v_ev_240, v_hd_245})));
}
V g_std_2eterminal_2eloop_24s128358813x21722470_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_app_241 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_ev_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_app_241, 2)), 2, (V[]){heff_dup(v_x_247), heff_dup(v_st_242)}));
  V v_s_249 = (g_std_2eterminal_2ewidget_2epaint(v_x_247, v_t_248));
  V v_t_2410 = heff_tag_n(TAG_Draw, 2, (V[]){v_s_249, NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tr(heff_call(heff_dup(v_ev_240), 1, (V[]){v_t_2410}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2411, heff_dup(v_hd_245), heff_clo_n(g_std_2eterminal_2eloop_24s128358813x21722470_lam3, 1, 5, (V[]){v_ev_240, v_hd_245, v_k_246, v_app_241, v_st_242})));
}
V g_std_2eterminal_2eloop_24s128358813x21722470_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_t_244 = heff_env(self)[0];
  V v_app_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_ev_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_co_2eop_24s615738393x1686646143(v_t_244, heff_dup(v_hd_245), heff_clo_n(g_std_2eterminal_2eloop_24s128358813x21722470_lam2, 1, 5, (V[]){v_app_241, v_st_242, v_ev_240, v_hd_245, v_k_246})));
}
V g_std_2eterminal_2einteract_24s565449676x1025154109_lam0(V self, V *args); static Clo g_std_2eterminal_2einteract_24s565449676x1025154109_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2einteract_24s565449676x1025154109_lam0, 1, 0};
V g_std_2eterminal_2einteract_24s565449676x1025154109_lam4(V self, V *args);
V g_std_2eterminal_2einteract_24s565449676x1025154109_lam3(V self, V *args);
V g_std_2eterminal_2einteract_24s565449676x1025154109_lam2(V self, V *args);
V g_std_2eterminal_2einteract_24s565449676x1025154109_lam1(V self, V *args);
Clo g_std_2eterminal_2einteract_24s565449676x1025154109_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2einteract_24s565449676x1025154109_entry, 2, 0};

V g_std_2eterminal_2einteract_24s565449676x1025154109(V v_ev_240, V v_app_241) {
top: ;
  V v_t_243 = heff_tr(heff_call(heff_dup(v_ev_240), 1, (V[]){heff_tag_n(TAG_Begin, 1, (V[]){((V)&g_std_2eterminal_2einteract_24s565449676x1025154109_lam0_clo)})}));
  return heff_clo_n(g_std_2eterminal_2einteract_24s565449676x1025154109_lam1, 2, 3, (V[]){v_t_243, v_ev_240, v_app_241});
}
V g_std_2eterminal_2einteract_24s565449676x1025154109_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2einteract_24s565449676x1025154109(a[0], a[1]);
}
V g_std_2eterminal_2einteract_24s565449676x1025154109_lam0(V self, V *args) {
  V v_b_242 = args[0];
  return v_b_242;
}
V g_std_2eterminal_2einteract_24s565449676x1025154109_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2411);
  V f_ = v_k_245;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eterminal_2einteract_24s565449676x1025154109_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_ev_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_Finish, 1, (V[]){NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tr(heff_call(v_ev_240, 1, (V[]){v_t_249}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2410, v_hd_244, heff_clo_n(g_std_2eterminal_2einteract_24s565449676x1025154109_lam4, 1, 2, (V[]){v_k_245, v_x_248})));
}
V g_std_2eterminal_2einteract_24s565449676x1025154109_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_ev_240 = heff_env(self)[0];
  V v_app_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_246) == NTAG(TAG_True))) {
    heff_drop(v_x_246);
    V v_c_247 = (g_std_2eterminal_2eloop_24s128358813x21722470(heff_dup(v_ev_240), heff_dup(v_app_241), heff_get_n(v_app_241, 0, 3)));
    V f_ = v_c_247;
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_std_2eterminal_2einteract_24s565449676x1025154109_lam3, 1, 3, (V[]){v_ev_240, v_hd_244, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_246);
    heff_drop(v_ev_240);
    heff_drop_rec(v_app_241, 3);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_std_2eterminal_2einteract_24s565449676x1025154109_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_t_243 = heff_env(self)[0];
  V v_ev_240 = heff_env(self)[1];
  V v_app_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s615738393x1686646143(v_t_243, heff_dup(v_hd_244), heff_clo_n(g_std_2eterminal_2einteract_24s565449676x1025154109_lam2, 1, 4, (V[]){v_ev_240, v_app_241, v_hd_244, v_k_245})));
}