// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_heff_2ebuild_2epackaging_2ebuildText_get(void);
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231(V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_clo;
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_clo;
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823(V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s1552018029x993523539(V, V);
V g_list_2ekeepIf_24s1552018029x993523539_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1552018029x993523539_clo;
V g_list_2emap_24f1285463828x1893111862(V, V, V);
V g_list_2emap_24f1285463828x1893111862_entry(V self, V *a);
extern Clo g_list_2emap_24f1285463828x1893111862_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str4, 5, "0.1.0");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str5, 22, "package = { module = \"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str6, 11, "\", heff = \"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str7, 3, "\" }");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str8, 35, "import manifest\012\012package : Package\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str10, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str12, 4, "src/");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str13, 12, "/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str14, 7, "module ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str15, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str17, 27, "greeting : String -> String");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str18, 38, "greeting name = \"Hello, \" ^ name ^ \"!\"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str19, 24, "-- | >>> greeting \"heff\"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str20, 19, "-- | \"Hello, heff!\"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str22, 26, "-- | a greeting, of `name`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str24, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str25, 66, "-- A module of the package, as every file of src/ is: `heff build`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str26, 52, "-- checks them all, and `heff test` their doc tests.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str27, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str28, 8, "/main.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str29, 15, "-- The program ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str30, 42, ": `heff build` builds it to .heff/bin/, as");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str31, 29, "-- a build, by `heff run app/");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str32, 10, "/main.hf`.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str33, 11, "module app.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str34, 5, ".main");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str35, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str36, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str37, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str38, 20, "main : Co stdio Unit");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str39, 24, "main = program (io := _)");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str40, 34, "program = print (greeting \"world\")");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str41, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str42, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str43, 60, "program : {e : HFunctor} -> {{io : stdio <: e}} -> Co e Unit");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str44, 13, "import std.io");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str45, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str46, 9, "import co");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str47, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str48, 68, "-- build.hf says, and `heff install` into ~/.heff/bin/; run, without");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str49, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str50, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str51, 9, "/build.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str52, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str53, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str54, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str55, 8, "greets =");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str56, 64, "  unit \"greeting\" (assertEqual (greeting \"test\") \"Hello, test!\")");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str57, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str58, 13, "greets : Test");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str59, 12, "import check");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str60, 20, "module test.greeting");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str61, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str62, 9, "-- tests.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str63, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str64, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str65, 68, "-- `heff test` runs the tests of every file of test/ (and src/): the");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str66, 71, "-- definitions of type `Test` (lib/check.hf), after the watches and doc");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str67, 16, "test/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str68, 10, ".gitignore");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str69, 7, ".heff/\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str70, 1, ".");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str71, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str72, 20, "heff: the directory ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str73, 82, " has no name to name a package by: say the project's directory, as `heff init DIR`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str74, 21, "heff: the directory `");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str75, 25, "` cannot name a package (");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str76, 36, "): name it otherwise, as `heff init ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str77, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str78, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str79, 1, "_");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str80, 1, "_");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str81, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str82, 1, "_");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str83, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str84, 3, "app");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str85, 4, "pkg_");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str86, 4, "_app");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str87, 1, "`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str88, 62, "heff: `heff` is heff's own package: name the project otherwise");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str89, 23, "heff: a new project in ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str90, 56, "; there, `heff build` builds it and `heff test` tests it");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str91, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str92, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str93, 5, " has ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str94, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str95, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str96, 25, " already; nothing written");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str97, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str98, 1, "\012");
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_entry, 6, 0};

V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0(V v_e_240, V v_hd_241, V v_dir_242, V v_x_243, V v_k_244, V v_x_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2413, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam1, 1, 6, (V[]){v_dir_242, v_x_243, heff_dup(v_x_245), v_e_240, v_hd_241, v_k_244})));
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam0(V self, V *args) {
  V v_s_246 = args[0];
  return v_s_246;
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam3(V self, V *args) {
  V v_x_24115 = args[0];
  V v_dir_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_24115) == NTAG(TAG_True))) {
    heff_drop(v_x_24115);
    V v_t_24116 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str89), v_dir_242), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str90));
    V v_t_24117 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_24116, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str91)), NTAG(TAG_MkUnit)});
    V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
    V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
    V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
    V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
    V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24122})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24123}), v_hd_241, v_k_244));
  } else {
    heff_drop(v_x_24115);
    heff_drop(v_dir_242);
    V v_t_24124 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24124})});
    V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
    V v_t_24127 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24126})});
    V v_t_24128 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24127})});
    V v_t_24129 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24128})});
    V v_t_24130 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24129})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24130}), v_hd_241, v_k_244));
  }
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam4(V self, V *args) {
  V v_x_24145 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24145);
  V v_t_24146 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24147 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24146})});
  V v_t_24148 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24147})});
  V v_t_24149 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24148})});
  V v_t_24150 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24149})});
  V v_t_24151 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24150})});
  V v_t_24152 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24151})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24152}), v_hd_241, v_k_244));
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam5(V self, V *args) {
  V v_x_24161 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24161);
  V v_t_24162 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24163 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24162})});
  V v_t_24164 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24163})});
  V v_t_24165 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24164})});
  V v_t_24166 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24165})});
  V v_t_24167 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24166})});
  V v_t_24168 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24167})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24168}), v_hd_241, v_k_244));
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam2(V self, V *args) {
  V v_x_2486 = args[0];
  V v_dir_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2438 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_x_2485 = heff_env(self)[4];
  V v_hd_241 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_shown_2487;
  if (heff_strEq_c_lent(v_dir_242, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str70), 2)) {
    v_shown_2487 = v_x_243;
  } else {
    heff_drop(v_x_243);
    v_shown_2487 = heff_dup(v_dir_242);
  }
  V v_name_2488 = v_x_2438;
  V v_t_24114;
  if (heff_strEq_c_lent(v_name_2488, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str71), 2)) {
    heff_drop(v_name_2488);
    V v_t_2489 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str72), v_shown_2487), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str73));
    v_t_24114 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2489});
  } else {
    heff_drop(v_shown_2487);
    HeffT2 v_t_2490 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_name_2488));
    {
      V v_field_2492 = v_t_2490.f[1];
      int64_t v_tag_2491 = ((int64_t)v_t_2490.f[0]);
      if ((v_tag_2491 == ((int64_t)0ULL))) {
        V v_why_2493 = v_field_2492;
        V v_t_2494 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str74), heff_dup(v_name_2488)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str75));
        V v_t_2495 = heff_strAppend(heff_strAppend(v_t_2494, v_why_2493), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str76));
        V v_x_2496 = v_name_2488;
        V v_x2_2497 = (g_list_2emap_24f1285463828x1893111862(heff_dup(v_x_2496), MK_INT(0LL), heff_strLength(v_x_2496)));
        V v_s_24100;
        switch (heff_tag_of(v_x2_2497)) {
        case TAG_Nil: {
          v_s_24100 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str77);
          break;
        }
        case TAG_Cons: {
          V v_x_2498 = heff_field(v_x2_2497, 0);
          V v_xs_2499 = heff_field(v_x2_2497, 1);
          heff_take_n(v_x2_2497, 3ULL, 2);
          v_s_24100 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str78); V a_1 = v_x_2498; V a_2 = v_xs_2499; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2499); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2497);
        }
        V v_t_24101 = ({ V a_0 = v_s_24100; V b_1 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str79); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str80), v_s_24100, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_24100); heff_drop(b_1); r_; });
        V v_x2_24102 = (g_list_2ekeepIf_24s1552018029x993523539(MK_INT(0LL), v_t_24101));
        V v_x_24105;
        switch (heff_tag_of(v_x2_24102)) {
        case TAG_Nil: {
          v_x_24105 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str81);
          break;
        }
        case TAG_Cons: {
          V v_x_24103 = heff_field(v_x2_24102, 0);
          V v_xs_24104 = heff_field(v_x2_24102, 1);
          heff_take_n(v_x2_24102, 3ULL, 2);
          v_x_24105 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str82); V a_1 = v_x_24103; V a_2 = v_xs_24104; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24104); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24102);
        }
        V v_x_24106;
        if (heff_strEq_c_lent(v_x_24105, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str83), 2)) {
          heff_drop(v_x_24105);
          v_x_24106 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str84);
        } else {
          if (((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_24105, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_24105, MK_INT(0LL), 2)) <= ((int64_t)57ULL)))) {
            v_x_24106 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str85), v_x_24105);
          } else {
            v_x_24106 = v_x_24105;
          }
        }
        HeffT2 v_t_24107 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_x_24106));
        V v_t_24111;
        {
          V v_field_24109 = v_t_24107.f[1];
          int64_t v_tag_24108 = ((int64_t)v_t_24107.f[0]);
          v_t_24111 = heff_bool(((v_tag_24108 == ((int64_t)0ULL)) ? ({ V v_x_24110 = heff_dup(v_field_24109); int c_ = 0; heff_drop(v_x_24110); c_; }) : 1));
          heff_drop(v_field_24109);
        }
        V v_t_24112;
        if (((heff_dup(v_t_24111) == NTAG(TAG_True)) && !heff_strEq_c(heff_dup(v_x_24106), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get())))) {
          heff_drop(v_t_24111);
          v_t_24112 = v_x_24106;
        } else {
          heff_drop(v_t_24111);
          v_t_24112 = heff_strAppend(v_x_24106, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str86));
        }
        V v_t_24113 = heff_strAppend(heff_strAppend(v_t_2495, v_t_24112), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str87));
        v_t_24114 = heff_tag_n(TAG_Just, 1, (V[]){v_t_24113});
      } else {
        heff_drop(v_field_2492);
        if (heff_strEq_c(v_name_2488, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
          v_t_24114 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str88)});
        } else {
          v_t_24114 = NTAG(TAG_Nothing);
        }
      }
    }
  }
  switch (heff_tag_of(v_t_24114)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_x_2486)) {
    case TAG_Nil: {
      return (g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823(heff_dup(v_e_240), heff_dup(v_dir_242), v_x_2485, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam3, 1, 4, (V[]){v_dir_242, v_e_240, v_hd_241, v_k_244})));
    }
    case TAG_Cons: {
      heff_drop_tag(v_x_2485, 2);
      V v_t_24133 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str92), v_dir_242), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str93));
      V v_t_24136;
      switch (heff_tag_of(v_x_2486)) {
      case TAG_Nil: {
        v_t_24136 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str94);
        break;
      }
      case TAG_Cons: {
        V v_x_24134 = heff_field(v_x_2486, 0);
        V v_xs_24135 = heff_field(v_x_2486, 1);
        heff_take_n(v_x_2486, 3ULL, 2);
        v_t_24136 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str95); V a_1 = v_x_24134; V a_2 = v_xs_24135; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24135); r_; });
        break;
      }
      default: heff_nomatch(v_x_2486);
      }
      V v_str_24137 = heff_strAppend(heff_strAppend(v_t_24133, v_t_24136), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str96));
      V v_t_24138 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_24137, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str97)), NTAG(TAG_MkUnit)});
      V v_t_24139 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24138})});
      V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
      V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
      V v_t_24142 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24141})});
      V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
      V v_t_24144 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24143})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24144}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam4, 1, 3, (V[]){v_e_240, v_hd_241, v_k_244})));
    }
    default: return heff_nomatch(v_x_2486);
    }
  }
  case TAG_Just: {
    V v_why_24153 = heff_field(v_t_24114, 0);
    V v_ru_24t_24114_24Just = heff_take_reuse_n(v_t_24114, 1ULL, 1);
    heff_drop(v_x_2486);
    heff_drop(v_dir_242);
    heff_drop_tag(v_x_2485, 2);
    V v_t_24154 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_why_24153, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str98)), NTAG(TAG_MkUnit)});
    V v_t_24155 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24154})});
    V v_t_24156 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24155})});
    V v_t_24157 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24156})});
    V v_t_24158 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24157})});
    V v_t_24159 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24158})});
    V v_t_24160 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24159})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24160}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam5, 1, 3, (V[]){v_e_240, v_hd_241, v_k_244})));
  }
  default: return heff_nomatch(v_t_24114);
  }
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_dir_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_241 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2415;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str0))) {
    v_st_2415 = NTAG(TAG_Windows);
  } else {
    v_st_2415 = NTAG(TAG_Posix);
  }
  V v_dir_2416 = heff_dup(v_dir_242);
  V v_x3_2417 = heff_dup(v_x_243);
  V v_x_2438;
  if (heff_strEq_c_lent(v_dir_2416, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str1), 2)) {
    heff_drop(v_dir_2416);
    HeffT3 v_t_2418 = (g_std_2epath_2eparse_24cpr(v_st_2415, v_x3_2417));
    {
      V v_field_2419 = v_t_2418.f[0];
      V v_field_2420 = v_t_2418.f[1];
      V v_field_2421 = v_t_2418.f[2];
      V v_x11_2422 = v_field_2419;
      heff_drop(v_x11_2422);
      V v_x12_2423 = v_field_2420;
      heff_drop(v_x12_2423);
      V v_xs_2424 = v_field_2421;
      V v_x1_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
      switch (heff_tag_of(v_x1_2425)) {
      case TAG_Nil: {
        v_x_2438 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2426 = heff_field(v_x1_2425, 0);
        heff_take_n(v_x1_2425, 1ULL, 2);
        v_x_2438 = v_x_2426;
        break;
      }
      default: heff_nomatch(v_x1_2425);
      }
    }
  } else {
    heff_drop(v_x3_2417);
    HeffT3 v_t_2428 = (g_std_2epath_2eparse_24cpr(v_st_2415, v_dir_2416));
    {
      V v_field_2429 = v_t_2428.f[0];
      V v_field_2430 = v_t_2428.f[1];
      V v_field_2431 = v_t_2428.f[2];
      V v_x11_2432 = v_field_2429;
      heff_drop(v_x11_2432);
      V v_x12_2433 = v_field_2430;
      heff_drop(v_x12_2433);
      V v_xs_2434 = v_field_2431;
      V v_x1_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2434));
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_Nil: {
        v_x_2438 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_2436 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 2);
        v_x_2438 = v_x_2436;
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
    }
  }
  V v_name_2439 = heff_dup(v_x_2438);
  V v_v_2441;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    v_v_2441 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str4);
    break;
  }
  case TAG_Just: {
    V v_x_2440 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    v_v_2441 = v_x_2440;
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_2442 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str5), heff_dup(v_name_2439)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str6));
  V v_t_2443 = heff_strAppend(heff_strAppend(v_t_2442, v_v_2441), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str7));
  V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str8), v_t_2443), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str9));
  V v_t_2445 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str10), heff_strAppend(v_t_2444, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str11))});
  V v_t_2446 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str12), heff_dup(v_name_2439)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str13));
  V v_name_2447 = heff_dup(v_name_2439);
  V v_t_2448 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str14), v_name_2447), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str15));
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str16), NTAG(TAG_Nil)});
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str17), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str18), v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str19), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str20), v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str22), v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str23), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, v_t_2452})});
  V v_t_2454 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str24); V a_1 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str25); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str26), v_t_2453}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2455 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str27), heff_dup(v_name_2439)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str28));
  V v_name_2456 = heff_dup(v_name_2439);
  V v_t_2457 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str29), heff_dup(v_name_2456)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str30));
  V v_t_2458 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str31), heff_dup(v_name_2456)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str32));
  V v_t_2459 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str33), heff_dup(v_name_2456)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str34));
  V v_t_2460 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str35), v_name_2456), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str36));
  V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str37), NTAG(TAG_Nil)});
  V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str38), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str39), v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str40), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str41), v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str42), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str43), v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str44), v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str45), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str46), v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str47), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str48), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_t_2467})});
  V v_t_2469 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str49); V a_1 = v_t_2457; V a_2 = v_t_2468; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2468, 2); r_; });
  V v_t_2470 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str50), heff_dup(v_name_2439)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str51));
  V v_name_2471 = v_name_2439;
  V v_t_2472 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str52), v_name_2471), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str53));
  V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str54), NTAG(TAG_Nil)});
  V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str55), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str56), v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str57), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str58), v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str59), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2472, v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str60), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str61), v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str62), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str63), v_t_2477})});
  V v_t_2479 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str64); V a_1 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str65); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str66), v_t_2478}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str67), v_t_2479}), NTAG(TAG_Nil)});
  V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2470, heff_dup(g_heff_2ebuild_2epackaging_2ebuildText_get())}), v_t_2480});
  V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2455, v_t_2469}), v_t_2481});
  V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2446, v_t_2454}), v_t_2482});
  V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str68), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_str69)}), v_t_2483});
  V v_x_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_t_2484});
  return (g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231(heff_dup(v_e_240), heff_dup(v_dir_242), heff_dup(v_x_2485), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_lam2, 1, 7, (V[]){v_dir_242, v_x_243, v_x_2438, v_e_240, v_x_2485, v_hd_241, v_k_244})));
}