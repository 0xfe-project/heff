// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CInf 46723
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CType 17595
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EDo 15964
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_I64 19315
#define TAG_ImplicitParam 51130
#define TAG_Many 40086
#define TAG_MkAlt 55173
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Rest 61983
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_Some 35658
#define TAG_StmtExpr 2862
#define LBL_all 306203
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_back 9511342
#define LBL_backend 2032133329
#define LBL_build 295453320
#define LBL_checked 974171621
#define LBL_deeper 611485124
#define LBL_end 310101
#define LBL_env 310119
#define LBL_front 299063875
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_meta 9843404
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_numbered 1006183371
#define LBL_ops 319788
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_self 10021907
#define LBL_source 1050636102
#define LBL_sp 10436
#define LBL_span 10032145
#define LBL_start 311115900
static uint32_t shape_deeper__env__self__at[] = {LBL_deeper, LBL_env, LBL_self, LBL_at};
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603(V);
V g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603_clo;
V g_heff_2ecompile_2eglue_2eglueOf(V, V, V);
V g_heff_2ecompile_2eglue_2eglueOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eglueOf_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2elower_2egroupOut(V, V, V, V);
V g_heff_2ecompile_2elower_2egroupOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2egroupOut_clo;
V g_heff_2ecompile_2eowned_2eownSt(V, V, V);
V g_heff_2ecompile_2eowned_2eownSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownSt_clo;
V g_heff_2ecompile_2esimplify_2ebodyTakes(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ebodyTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebodyTakes_clo;
V g_heff_2ecompile_2esimplify_2eenvOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eenvOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eenvOf_clo;
HeffT2 g_heff_2ecompile_2espec_2enthS_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
HeffT2 g_heff_2esyntax_2epresyntax_2estmtAcc_24s169345181x1621877738_24cpr(V, V);
V g_list_2eall_24s1155681438x1635771547(V, V, V, V, V, V);
V g_list_2eall_24s1155681438x1635771547_entry(V self, V *a);
extern Clo g_list_2eall_24s1155681438x1635771547_clo;
V g_list_2eall_24s262401054x194288545(V, V);
V g_list_2eall_24s262401054x194288545_entry(V self, V *a);
extern Clo g_list_2eall_24s262401054x194288545_clo;
V g_list_2eany_24s105899861x584770213(V);
V g_list_2eany_24s105899861x584770213_entry(V self, V *a);
extern Clo g_list_2eany_24s105899861x584770213_clo;
V g_list_2eany_24s1672254115x651817494(V, V);
V g_list_2eany_24s1672254115x651817494_entry(V self, V *a);
extern Clo g_list_2eany_24s1672254115x651817494_clo;
V g_list_2eany_24s2003678755x1820404042(V);
V g_list_2eany_24s2003678755x1820404042_entry(V self, V *a);
extern Clo g_list_2eany_24s2003678755x1820404042_clo;
V g_list_2eany_24s285809686x1684902122(V, V);
V g_list_2eany_24s285809686x1684902122_entry(V self, V *a);
extern Clo g_list_2eany_24s285809686x1684902122_clo;
V g_list_2eany_24s624430845x1248965393(V);
V g_list_2eany_24s624430845x1248965393_entry(V self, V *a);
extern Clo g_list_2eany_24s624430845x1248965393_clo;
V g_list_2ecollapse_24s1391945213x481576570(V, V);
V g_list_2ecollapse_24s1391945213x481576570_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s1391945213x481576570_clo;
HeffT2 g_list_2efind_24s595925281x993936542_24cpr(V, V);
V g_list_2efoldl_24f1582053009x1594640150(V, V, V, V, V);
V g_list_2efoldl_24f1582053009x1594640150_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1582053009x1594640150_clo;
V g_list_2efoldl_24f1663632568x709545076(V, V, V, V);
V g_list_2efoldl_24f1663632568x709545076_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1663632568x709545076_clo;
V g_list_2efoldl_24f932140008x904662204(V, V, V);
V g_list_2efoldl_24f932140008x904662204_entry(V self, V *a);
extern Clo g_list_2efoldl_24f932140008x904662204_clo;
V g_list_2efoldl_24s1278499411x1393297768(V, V);
V g_list_2efoldl_24s1278499411x1393297768_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1278499411x1393297768_clo;
V g_list_2efoldl_24s1854884545x892082821(V, V);
V g_list_2efoldl_24s1854884545x892082821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1854884545x892082821_clo;
V g_list_2efoldl_24s193704652x357697644(V, V);
V g_list_2efoldl_24s193704652x357697644_entry(V self, V *a);
extern Clo g_list_2efoldl_24s193704652x357697644_clo;
V g_list_2efoldl_24s2062876492x2082655823(V, V);
V g_list_2efoldl_24s2062876492x2082655823_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2062876492x2082655823_clo;
V g_list_2efoldl_24s2062876492x2082655823_24scalars(V, V, V);
V g_list_2efoldl_24s2062876492x2082655823_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2062876492x2082655823_24scalars_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s330602584x1277356584(V, V, V);
V g_list_2efoldl_24s330602584x1277356584_entry(V self, V *a);
extern Clo g_list_2efoldl_24s330602584x1277356584_clo;
V g_list_2efoldl_24s490001784x345683100(V, V);
V g_list_2efoldl_24s490001784x345683100_entry(V self, V *a);
extern Clo g_list_2efoldl_24s490001784x345683100_clo;
V g_list_2efoldl_24s630841978x1026694071(V, V);
V g_list_2efoldl_24s630841978x1026694071_entry(V self, V *a);
extern Clo g_list_2efoldl_24s630841978x1026694071_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s122741325x871243494_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_24dps_clo;
V g_list_2ekeepIf_24s1441124185x871809048_24dps(V, V, V);
V g_list_2ekeepIf_24s1441124185x871809048_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1441124185x871809048_24dps_clo;
V g_list_2ekeepIf_24s1457049037x722637222(V);
V g_list_2ekeepIf_24s1457049037x722637222_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1457049037x722637222_clo;
V g_list_2ekeepIf_24s1457049037x722637222_24dps(V, V);
V g_list_2ekeepIf_24s1457049037x722637222_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1457049037x722637222_24dps_clo;
V g_list_2ekeepIf_24s1823913665x1128491553(V, V);
V g_list_2ekeepIf_24s1823913665x1128491553_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1823913665x1128491553_clo;
V g_list_2ekeepIf_24s1823913665x1128491553_24dps(V, V, V);
V g_list_2ekeepIf_24s1823913665x1128491553_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1823913665x1128491553_24dps_clo;
V g_list_2ekeepIf_24s185327080x101197346(V, V, V, V);
V g_list_2ekeepIf_24s185327080x101197346_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s185327080x101197346_clo;
V g_list_2ekeepIf_24s185327080x101197346_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s185327080x101197346_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s185327080x101197346_24dps_clo;
V g_list_2ekeepIf_24s2053104128x1598844325(V, V, V, V);
V g_list_2ekeepIf_24s2053104128x1598844325_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2053104128x1598844325_clo;
V g_list_2ekeepIf_24s2053104128x1598844325_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s2053104128x1598844325_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2053104128x1598844325_24dps_clo;
V g_list_2ekeepIf_24s257286374x378693326_24dps(V, V, V);
V g_list_2ekeepIf_24s257286374x378693326_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s257286374x378693326_24dps_clo;
V g_list_2ekeepIf_24s423901581x541836270(V, V);
V g_list_2ekeepIf_24s423901581x541836270_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s423901581x541836270_clo;
V g_list_2ekeepIf_24s423901581x541836270_24dps(V, V, V);
V g_list_2ekeepIf_24s423901581x541836270_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s423901581x541836270_24dps_clo;
V g_list_2ekeepIf_24s512765522x2052101617_24dps(V, V, V);
V g_list_2ekeepIf_24s512765522x2052101617_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s512765522x2052101617_24dps_clo;
V g_list_2ekeepIf_24s708019417x1279437633_24dps(V, V, V);
V g_list_2ekeepIf_24s708019417x1279437633_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s708019417x1279437633_24dps_clo;
V g_list_2ekeepIf_24s742867582x682687968_24dps(V, V, V);
V g_list_2ekeepIf_24s742867582x682687968_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s742867582x682687968_24dps_clo;
V g_list_2emap_24f505181408x1813697659(V, V);
V g_list_2emap_24f505181408x1813697659_entry(V self, V *a);
extern Clo g_list_2emap_24f505181408x1813697659_clo;
V g_list_2emap_24f505181408x1813697659_24dps(V, V, V);
V g_list_2emap_24f505181408x1813697659_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f505181408x1813697659_24dps_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s1059370217x1267747283_24dps(V, V);
V g_list_2emap_24s1059370217x1267747283_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_24dps_clo;
V g_list_2emap_24s1367173129x1257089258_24dps(V, V);
V g_list_2emap_24s1367173129x1257089258_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1367173129x1257089258_24dps_clo;
V g_list_2emap_24s1460603830x671758883(V, V);
V g_list_2emap_24s1460603830x671758883_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_clo;
V g_list_2emap_24s1460603830x671758883_24dps(V, V, V);
V g_list_2emap_24s1460603830x671758883_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_24dps_clo;
V g_list_2emap_24s1478286876x830244177_24dps(V, V);
V g_list_2emap_24s1478286876x830244177_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1478286876x830244177_24dps_clo;
V g_list_2emap_24s1518131677x2038133191(V, V, V);
V g_list_2emap_24s1518131677x2038133191_entry(V self, V *a);
extern Clo g_list_2emap_24s1518131677x2038133191_clo;
V g_list_2emap_24s1518131677x2038133191_24dps(V, V, V, V);
V g_list_2emap_24s1518131677x2038133191_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1518131677x2038133191_24dps_clo;
V g_list_2emap_24s1628253759x601849359(V, V, V);
V g_list_2emap_24s1628253759x601849359_entry(V self, V *a);
extern Clo g_list_2emap_24s1628253759x601849359_clo;
V g_list_2emap_24s1628253759x601849359_24dps(V, V, V, V);
V g_list_2emap_24s1628253759x601849359_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1628253759x601849359_24dps_clo;
V g_list_2emap_24s164225955x66209884_24dps(V, V, V, V);
V g_list_2emap_24s164225955x66209884_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_24dps_clo;
V g_list_2emap_24s1688354384x1781591142(V, V, V);
V g_list_2emap_24s1688354384x1781591142_entry(V self, V *a);
extern Clo g_list_2emap_24s1688354384x1781591142_clo;
V g_list_2emap_24s1688354384x1781591142_24dps(V, V, V, V);
V g_list_2emap_24s1688354384x1781591142_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1688354384x1781591142_24dps_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s1844509821x2028168277_24dps(V, V);
V g_list_2emap_24s1844509821x2028168277_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_24dps_clo;
V g_list_2emap_24s1937570095x2110149801_24dps(V, V);
V g_list_2emap_24s1937570095x2110149801_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24dps_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s1960706388x853997965(V);
V g_list_2emap_24s1960706388x853997965_entry(V self, V *a);
extern Clo g_list_2emap_24s1960706388x853997965_clo;
V g_list_2emap_24s1960706388x853997965_24dps(V, V);
V g_list_2emap_24s1960706388x853997965_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1960706388x853997965_24dps_clo;
V g_list_2emap_24s1985010810x1780722131_24dps(V, V, V, V, V);
V g_list_2emap_24s1985010810x1780722131_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1985010810x1780722131_24dps_clo;
V g_list_2emap_24s2029999044x514618413_24dps(V, V);
V g_list_2emap_24s2029999044x514618413_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_24dps_clo;
V g_list_2emap_24s265594371x763318798(V);
V g_list_2emap_24s265594371x763318798_entry(V self, V *a);
extern Clo g_list_2emap_24s265594371x763318798_clo;
V g_list_2emap_24s265594371x763318798_24dps(V, V);
V g_list_2emap_24s265594371x763318798_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s265594371x763318798_24dps_clo;
V g_list_2emap_24s272223926x273382154(V);
V g_list_2emap_24s272223926x273382154_entry(V self, V *a);
extern Clo g_list_2emap_24s272223926x273382154_clo;
V g_list_2emap_24s272223926x273382154_24dps(V, V);
V g_list_2emap_24s272223926x273382154_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s272223926x273382154_24dps_clo;
V g_list_2emap_24s273193875x235978955_24dps(V, V, V, V, V);
V g_list_2emap_24s273193875x235978955_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s273193875x235978955_24dps_clo;
V g_list_2emerge_24s1347843181x1368204458(V, V);
V g_list_2emerge_24s1347843181x1368204458_entry(V self, V *a);
extern Clo g_list_2emerge_24s1347843181x1368204458_clo;
V g_list_2emergeRuns_24s594401848x1575493307(V, V);
V g_list_2emergeRuns_24s594401848x1575493307_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s594401848x1575493307_clo;
V g_list_2epushRun_24s1577108484x1259861853(V, V, V);
V g_list_2epushRun_24s1577108484x1259861853_entry(V self, V *a);
extern Clo g_list_2epushRun_24s1577108484x1259861853_clo;
V g_list_2erunFrom_24s1871674023x1487040306(V, V);
V g_list_2erunFrom_24s1871674023x1487040306_entry(V self, V *a);
extern Clo g_list_2erunFrom_24s1871674023x1487040306_clo;
V g_list_2ezipWith_24s29557946x653938035_24dps(V, V, V);
V g_list_2ezipWith_24s29557946x653938035_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s29557946x653938035_24dps_clo;
V g_list_2ezipWith_24s704759456x417074234(V, V, V, V, V);
V g_list_2ezipWith_24s704759456x417074234_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s704759456x417074234_clo;
V g_list_2ezipWith_24s704759456x417074234_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s704759456x417074234_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s704759456x417074234_24dps_clo;
V g_list_2ezipWith_24s870182194x1066240094_24dps(V, V, V);
V g_list_2ezipWith_24s870182194x1066240094_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2e_3c_3e_24tok2(V, V, V);
V g_std_2edoc_2e_3c_3e_24tok2_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_24tok2_clo;
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
V g_std_2eordmap_2einsert_24s1937835736x1362370727(V, V, V);
V g_std_2eordmap_2einsert_24s1937835736x1362370727_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1937835736x1362370727_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
Clo g_list_2efoldl_24s2127176832x914341824_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2127176832x914341824_entry, 2, 0};

V g_list_2efoldl_24s2127176832x914341824(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_std_2eordmap_2einsert_24s1937835736x1362370727(v_z_240, v_t_246, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2127176832x914341824(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s2003678755x1820404042_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2003678755x1820404042_entry, 1, 0};

V g_list_2eany_24s2003678755x1820404042(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    HeffT2 v_t_243 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_x_241); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2estmtAcc_24s169345181x1621877738_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_244 = v_t_243.f[0];
      V v_field_245 = v_t_243.f[1];
      V v_a_246 = v_field_244;
      V v_a_247 = v_field_245;
      heff_drop(v_a_247);
      if ((heff_dup(v_a_246) == NTAG(TAG_True))) {
        heff_drop(v_a_246);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_a_246);
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s2003678755x1820404042_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s2003678755x1820404042(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s272223926x273382154_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s272223926x273382154_entry, 1, 0};

V g_list_2emap_24s272223926x273382154(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x11_243, 0);
        V v_b_246 = heff_field(v_x11_243, 1);
        V v_ru_24x11_243_24MkAlt = heff_take_reuse_n(v_x11_243, 3ULL, 2);
        V v_t_2416;
        switch (heff_tag_of(v_b_246)) {
        case TAG_At: {
          V v_e1_247 = heff_dup(heff_field(v_b_246, 0));
          switch (heff_tag_of(v_e1_247)) {
          case TAG_EDo: {
            V v_ss_249 = heff_field(v_e1_247, 0);
            heff_take_n(v_e1_247, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop_cell(v_ru_24x_241_24At, 2);
            switch (heff_tag_of(v_b_246)) {
            case TAG_At: {
              heff_take_n(v_b_246, 0ULL, 2);
              v_t_2416 = v_ss_249;
              break;
            }
            default: heff_nomatch(v_b_246);
            }
            break;
          }
          default: {
            heff_drop(v_e1_247);
            V v_t_2414;
            switch (heff_tag_of(v_b_246)) {
            case TAG_At: {
              V v_s_2413 = heff_dup(heff_field(v_b_246, 1));
              v_t_2414 = v_s_2413;
              break;
            }
            default: heff_nomatch(v_b_246);
            }
            V v_t_2415 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_b_246}), v_t_2414});
            v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_b_246);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x11_243_24MkAlt, TAG_MkPair, 2, (V[]){v_p_245, v_t_2416});
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = (g_list_2emap_24s272223926x273382154_24dps(v_xs_242, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s272223926x273382154_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s272223926x273382154(a[0]);
}
Clo g_list_2emap_24s1844509821x2028168277_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1844509821x2028168277_24dps_entry, 2, 0};

V g_list_2emap_24s1844509821x2028168277_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_242));
    V v_t_2416;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_a_247 = v_field_246;
        v_t_2416 = v_a_247;
      } else {
        if ((v_tag_245 == ((int64_t)1ULL))) {
          V v_a_248 = v_field_246;
          V v_t_2411;
          switch (heff_tag_of(v_a_248)) {
          case TAG_At: {
            V v_a_2410 = heff_dup(heff_field(v_a_248, 1));
            v_t_2411 = v_a_2410;
            break;
          }
          default: heff_nomatch(v_a_248);
          }
          v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_248}), v_t_2411});
        } else {
          V v_a_2412 = v_field_246;
          V v_t_2415;
          switch (heff_tag_of(v_a_2412)) {
          case TAG_At: {
            V v_a_2414 = heff_dup(heff_field(v_a_2412, 1));
            v_t_2415 = v_a_2414;
            break;
          }
          default: heff_nomatch(v_a_2412);
          }
          v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2412}), v_t_2415});
        }
      }
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2417;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1844509821x2028168277_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1844509821x2028168277_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1059370217x1267747283_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1059370217x1267747283_entry, 1, 0};

V g_list_2emap_24s1059370217x1267747283(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_ExplicitParam: {
        V v_x_245 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_245;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_248 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1059370217x1267747283_24dps(v_xs_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1059370217x1267747283(a[0]);
}
Clo g_list_2ekeepIf_24s2053104128x1598844325_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2053104128x1598844325_entry, 4, 0};

V g_list_2ekeepIf_24s2053104128x1598844325(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s65689923x209800052(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_rfield(v_x_244, 1)));
    V v_a_247 = heff_bool(heff_intEq_c_lent(v_t_246, v_lit_242, 0));
    heff_drop(v_t_246);
    if (!(heff_dup(v_a_247) == NTAG(TAG_True))) {
      heff_drop(v_a_247);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_249 = (g_list_2ekeepIf_24s2053104128x1598844325_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop_rec(v_x_244, 8);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_a_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s2053104128x1598844325_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s2053104128x1598844325(a[0], a[1], a[2], a[3]);
}
Clo g_list_2ezipWith_24s704759456x417074234_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s704759456x417074234_entry, 5, 0};

V g_list_2ezipWith_24s704759456x417074234(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_x3_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_245);
      heff_drop(v_xs_246);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_x3_244, 0);
      V v_ys_248 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_249;
      if (heff_strEq_c_lent(v_x_245, v_lit_240, 0)) {
        heff_drop(v_x_245);
        v_t_249 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), heff_dup(v_lit_242)), heff_intShow(v_y_247));
      } else {
        heff_drop(v_y_247);
        v_t_249 = v_x_245;
      }
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2411 = (g_list_2ezipWith_24s704759456x417074234_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_246, v_ys_248, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s704759456x417074234_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ezipWith_24s704759456x417074234(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2eall_24s1155681438x1635771547_str0, 0, "");
HEFF_LIT(g_list_2eall_24s1155681438x1635771547_str1, 0, "");
Clo g_list_2eall_24s1155681438x1635771547_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1155681438x1635771547_entry, 6, 0};

V g_list_2eall_24s1155681438x1635771547(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_go_248 = heff_dup(v_lit_240);
    V v_s_249 = heff_dup(v_lit_241);
    V v_fo_2410 = heff_dup(v_lit_242);
    V v_f_2411 = heff_dup(v_lit_243);
    V v_argv_2412 = heff_dup(v_lit_244);
    V v_k_2413 = v_x_246;
    V v_t_24126;
    switch (heff_tag_of(v_f_2411)) {
    case TAG_EVar: {
      V v_p_2414 = heff_field(v_f_2411, 0);
      V v_ru_24f_2411_24EVar = heff_take_reuse_n(v_f_2411, 1ULL, 1);
      V v_go_2415 = v_go_248;
      V v_s_2416 = v_s_249;
      V v_fo_2417 = heff_dup(v_fo_2410);
      V v_argv_2418 = v_argv_2412;
      V v_k_2419 = v_k_2413;
      HeffT2 v_t_2420 = ({ V b_0 = heff_get_n(v_fo_2410, 1, 4); V a_1 = v_p_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_2414); r_; });
      {
        V v_field_2422 = v_t_2420.f[1];
        int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
        if ((v_tag_2421 == ((int64_t)0ULL))) {
          V v_x61_2423 = v_field_2422;
          switch (heff_tag_of(v_x61_2423)) {
          case TAG_EVar: {
            heff_take_n(v_x61_2423, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EGlobal: {
            V v_h_2425 = heff_field(v_x61_2423, 0);
            heff_take_n(v_x61_2423, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            V v_t_2426 = heff_get_n(heff_get_n(v_s_2416, 7, 10), 0, 7);
            V v_t_2427 = ({ V a_0 = v_ru_24f_2411_24EVar; V a_1 = v_t_2426; V a_2 = v_h_2425; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; });
            v_t_24126 = ({ V a_0 = v_go_2415; V a_1 = v_fo_2417; V a_2 = v_h_2425; V a_3 = v_argv_2418; V a_4 = v_k_2419; V a_5 = v_t_2427; V r_ = (g_heff_2ecompile_2esimplify_2ebodyTakes(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2427); r_; });
            break;
          }
          case TAG_ELam: {
            V v_ys_2428 = heff_field(v_x61_2423, 0);
            V v_b_2429 = heff_field(v_x61_2423, 1);
            V v_ru_24x61_2423_24ELam = heff_take_reuse_n(v_x61_2423, 3ULL, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop_rec(v_s_2416, 10);
            V v_lit_2430 = v_ys_2428;
            V v_lit_2431 = v_b_2429;
            V v_go_2432 = v_go_2415;
            V v_fo_2433 = v_fo_2417;
            V v_deeper_2434 = heff_take_field(v_fo_2433, 0);
            V v_env_2435 = heff_get_n(v_fo_2433, 1, 4);
            V v_h_2436 = ((V)&g_list_2eall_24s1155681438x1635771547_str0);
            V v_argv_2437 = v_argv_2418;
            V v_k_2438 = v_k_2419;
            if (heff_intLt_c_lent(MK_INT(0LL), v_deeper_2434, 1)) {
              V v_x_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_lit_2430));
              if (heff_intLt_c_lent(v_k_2438, v_x_2439, 2)) {
                V v_t_2440 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_2431), NTAG(TAG_Nil)});
                V v_x_2441 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(400LL), MK_INT(0LL), v_t_2440));
                if (!heff_intLt_c_lent(MK_INT(400LL), v_x_2441, 1)) {
                  heff_drop(v_x_2441);
                  V v_t_2442 = (g_heff_2ecompile_2esimplify_2eenvOf(v_env_2435, heff_dup(v_lit_2430), v_argv_2437));
                  V v_t_2443 = heff_rec_n(4, shape_deeper__env__self__at, (V[]){heff_intSub(v_deeper_2434, MK_INT(1LL)), v_t_2442, v_h_2436, heff_dup(v_k_2438)});
                  HeffT2 v_t_2444 = ({ V a_0 = v_k_2438; V a_1 = v_lit_2430; HeffT2 r_ = (g_heff_2ecompile_2espec_2enthS_24cpr(a_0, a_1)); heff_drop(v_lit_2430); r_; });
                  V v_t_2448;
                  {
                    V v_field_2446 = v_t_2444.f[1];
                    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                    if ((v_tag_2445 == ((int64_t)0ULL))) {
                      V v_x_2447 = v_field_2446;
                      v_t_2448 = v_x_2447;
                    } else {
                      heff_drop(v_field_2446);
                      v_t_2448 = ((V)&g_list_2eall_24s1155681438x1635771547_str1);
                    }
                  }
                  V v_t_2449 = heff_tag_at_n(v_ru_24x61_2423_24ELam, TAG_Cons, 2, (V[]){v_lit_2431, NTAG(TAG_Nil)});
                  V v_x_2450 = heff_tr(heff_call(v_go_2432, 3, (V[]){v_t_2443, v_t_2448, v_t_2449}));
                  v_t_24126 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2450, 1));
                  heff_drop(v_x_2450);
                } else {
                  heff_drop_cell(v_ru_24x61_2423_24ELam, 2);
                  heff_drop(v_lit_2430);
                  heff_drop(v_lit_2431);
                  heff_drop(v_go_2432);
                  heff_drop(v_deeper_2434);
                  heff_drop(v_env_2435);
                  heff_drop(v_h_2436);
                  heff_drop(v_argv_2437);
                  heff_drop(v_k_2438);
                  heff_drop(v_x_2441);
                  v_t_24126 = NTAG(TAG_False);
                }
              } else {
                heff_drop_cell(v_ru_24x2_245_24Cons, 2);
                heff_drop_cell(v_ru_24x61_2423_24ELam, 2);
                heff_drop(v_lit_2430);
                heff_drop(v_lit_2431);
                heff_drop(v_go_2432);
                heff_drop(v_deeper_2434);
                heff_drop(v_env_2435);
                heff_drop(v_h_2436);
                heff_drop(v_argv_2437);
                heff_drop(v_k_2438);
                v_t_24126 = NTAG(TAG_False);
              }
            } else {
              heff_drop_cell(v_ru_24x2_245_24Cons, 2);
              heff_drop_cell(v_ru_24x61_2423_24ELam, 2);
              heff_drop(v_lit_2430);
              heff_drop(v_lit_2431);
              heff_drop(v_go_2432);
              heff_drop(v_deeper_2434);
              heff_drop(v_env_2435);
              heff_drop(v_h_2436);
              heff_drop(v_argv_2437);
              heff_drop(v_k_2438);
              v_t_24126 = NTAG(TAG_False);
            }
            break;
          }
          case TAG_EApp: {
            heff_take_n(v_x61_2423, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_ELet: {
            heff_take_n(v_x61_2423, 0ULL, 3);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_ERecord: {
            heff_take_n(v_x61_2423, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EProj: {
            heff_take_n(v_x61_2423, 0ULL, 4);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_ETag: {
            heff_take_n(v_x61_2423, 0ULL, 3);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EMatch: {
            heff_take_n(v_x61_2423, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EPrim: {
            heff_take_n(v_x61_2423, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EPrimCall: {
            heff_take_n(v_x61_2423, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_ECall: {
            heff_take_n(v_x61_2423, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EInt: {
            heff_take_n(v_x61_2423, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EFloat: {
            heff_take_nf(v_x61_2423, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EStr: {
            heff_take_n(v_x61_2423, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EBytes: {
            heff_take_n(v_x61_2423, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EFixed: {
            heff_take_n(v_x61_2423, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EFloat32: {
            heff_take_na(v_x61_2423, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EAbandon: {
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EBool: {
            heff_take_n(v_x61_2423, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_ESet: {
            heff_take_n(v_x61_2423, 0ULL, 3);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EValues: {
            heff_take_n(v_x61_2423, 0ULL, 1);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          case TAG_EFix: {
            heff_take_n(v_x61_2423, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_245_24Cons, 2);
            heff_drop_cell(v_ru_24f_2411_24EVar, 1);
            heff_drop(v_go_2415);
            heff_drop_rec(v_s_2416, 10);
            heff_drop(v_fo_2417);
            heff_drop(v_argv_2418);
            heff_drop(v_k_2419);
            v_t_24126 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x61_2423);
          }
        } else {
          heff_drop_cell(v_ru_24x2_245_24Cons, 2);
          heff_drop_cell(v_ru_24f_2411_24EVar, 1);
          heff_drop(v_go_2415);
          heff_drop_rec(v_s_2416, 10);
          heff_drop(v_fo_2417);
          heff_drop(v_argv_2418);
          heff_drop(v_k_2419);
          heff_drop(v_field_2422);
          v_t_24126 = NTAG(TAG_False);
        }
      }
      break;
    }
    case TAG_EGlobal: {
      V v_h_2486 = heff_field(v_f_2411, 0);
      V v_ru_24f_2411_24EGlobal = heff_take_reuse_n(v_f_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      if (heff_strEq_c(heff_dup(v_h_2486), heff_dup(heff_rfield(v_fo_2410, 2)))) {
        heff_drop(v_go_248);
        heff_drop_rec(v_s_249, 10);
        heff_drop(v_argv_2412);
        heff_drop(v_h_2486);
        heff_drop_cell(v_ru_24f_2411_24EGlobal, 1);
        v_t_24126 = heff_bool(heff_intEq_c(heff_dup(v_k_2413), heff_dup(heff_rfield(v_fo_2410, 3))));
        heff_drop_rec(v_fo_2410, 4);
        heff_drop(v_k_2413);
      } else {
        V v_t_2487 = heff_get_n(heff_get_n(v_s_249, 7, 10), 0, 7);
        V v_t_2488 = ({ V a_0 = v_ru_24f_2411_24EGlobal; V a_1 = v_t_2487; V a_2 = v_h_2486; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(a_0, a_1, a_2)); heff_drop(v_t_2487); r_; });
        v_t_24126 = ({ V a_0 = v_go_248; V a_1 = v_fo_2410; V a_2 = v_h_2486; V a_3 = v_argv_2412; V a_4 = v_k_2413; V a_5 = v_t_2488; V r_ = (g_heff_2ecompile_2esimplify_2ebodyTakes(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2488); r_; });
      }
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_f_2411, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_f_2411, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_f_2411, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_f_2411, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_f_2411, 0ULL, 4);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_f_2411, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_f_2411, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_f_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_f_2411, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_f_2411, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_f_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_f_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_f_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_f_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_f_2411, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_f_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_f_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_f_2411, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_f_2411, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_f_2411, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_go_248);
      heff_drop_rec(v_s_249, 10);
      heff_drop_rec(v_fo_2410, 4);
      heff_drop(v_argv_2412);
      heff_drop(v_k_2413);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_f_2411);
    }
    if ((heff_dup(v_t_24126) == NTAG(TAG_True))) {
      heff_drop(v_t_24126);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_xs_247);
      heff_drop(v_t_24126);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2eall_24s1155681438x1635771547_entry(V self, V *a) {
  (void)self;
  return g_list_2eall_24s1155681438x1635771547(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2ekeepIf_24s423901581x541836270_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s423901581x541836270_entry, 2, 0};

V g_list_2ekeepIf_24s423901581x541836270(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2443;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_2443 = heff_bool(!heff_strEq_c_lent(v_lit_240, v_a_244, 0));
      heff_drop(v_a_244);
      break;
    }
    case TAG_EGlobal: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EApp: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ELet: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ERecord: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EProj: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ETag: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EMatch: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrim: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ECall: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EInt: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EBool: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ESet: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EValues: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFix: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
      heff_drop(v_t_2443);
      V v_cell_2444 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2445 = (g_list_2ekeepIf_24s423901581x541836270_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2444)));
      heff_drop(v_u_2445);
      return v_cell_2444;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_2443);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s423901581x541836270_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s423901581x541836270(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s630841978x1026694071_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s630841978x1026694071_entry, 2, 0};

V g_list_2efoldl_24s630841978x1026694071(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2443;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ECall: {
      V v_a_2427 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2443 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_a_2427, NTAG(TAG_Nil)});
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2443, v_z_240));
    V t_0 = v_t_2444;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s630841978x1026694071_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s630841978x1026694071(a[0], a[1]);
}
Clo g_list_2eany_24s1672254115x651817494_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1672254115x651817494_entry, 2, 0};

V g_list_2eany_24s1672254115x651817494(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_lit_240, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    V v_t_2446;
    switch (heff_tag_of(v_t_246)) {
    case TAG_EVar: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      v_t_2446 = heff_bool(heff_strEq_c_lent(v_x_242, v_a_247, 0));
      heff_drop(v_a_247);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_t_246, 0ULL, 3);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_t_246, 0ULL, 4);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_t_246, 0ULL, 3);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_t_246, 0ULL, 3);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
      heff_drop(v_t_2446);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2446);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1672254115x651817494_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1672254115x651817494(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s870182194x1066240094_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s870182194x1066240094_24dps_entry, 3, 0};

V g_list_2ezipWith_24s870182194x1066240094_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_243)) {
      case TAG_RepV: {
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_248 = v_y_245;
        break;
      }
      case TAG_RepFix: {
        v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_RWord, 2, (V[]){v_x_243, v_y_245});
        break;
      }
      case TAG_RepF64: {
        v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_RWord, 2, (V[]){v_x_243, v_y_245});
        break;
      }
      case TAG_RepInt: {
        v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_RWord, 2, (V[]){v_x_243, v_y_245});
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_249;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s870182194x1066240094_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s870182194x1066240094_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s490001784x345683100_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s490001784x345683100_entry, 2, 0};

V g_list_2efoldl_24s490001784x345683100(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_acc_244 = v_z_240;
    V v_s_245 = v_x_242;
    V v_t_2435;
    switch (heff_tag_of(v_s_245)) {
    case TAG_CDrop: {
      heff_take_n(v_s_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CLet: {
      V v_x_247 = heff_field(v_s_245, 0);
      V v_e_248 = heff_field(v_s_245, 1);
      V v_ru_24s_245_24CLet = heff_take_reuse_n(v_s_245, 3ULL, 2);
      v_t_2435 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24s_245_24CLet, TAG_MkPair, 2, (V[]){v_x_247, v_e_248}), v_acc_244});
      break;
    }
    case TAG_CDecl: {
      heff_take_n(v_s_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CSet: {
      V v_x_2410 = heff_field(v_s_245, 0);
      V v_e_2411 = heff_field(v_s_245, 1);
      V v_ru_24s_245_24CSet = heff_take_reuse_n(v_s_245, 3ULL, 2);
      v_t_2435 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24s_245_24CSet, TAG_MkPair, 2, (V[]){v_x_2410, v_e_2411}), v_acc_244});
      break;
    }
    case TAG_CAbandon: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CIf: {
      V v_a_2413 = heff_field(v_s_245, 1);
      V v_b_2414 = heff_field(v_s_245, 2);
      heff_take_n(v_s_245, 6ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      V v_t_2415 = (g_list_2efoldl_24s490001784x345683100(v_acc_244, v_a_2413));
      v_t_2435 = (g_list_2efoldl_24s490001784x345683100(v_t_2415, v_b_2414));
      break;
    }
    case TAG_CSwitch: {
      V v_arms_2417 = heff_field(v_s_245, 1);
      heff_take_n(v_s_245, 2ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = ({ V a_0 = v_acc_244; V a_1 = v_arms_2417; V r_ = (g_list_2efoldl_24s193704652x357697644(a_0, a_1)); heff_drop(v_arms_2417); r_; });
      break;
    }
    case TAG_CReturn: {
      heff_take_n(v_s_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CInPlace: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CRoomed: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CTail: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CLoop: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CLoopTo: {
      heff_take_n(v_s_245, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CLabel: {
      heff_take_n(v_s_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    case TAG_CJump: {
      heff_take_n(v_s_245, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2435 = v_acc_244;
      break;
    }
    default: heff_nomatch(v_s_245);
    }
    V t_0 = v_t_2435;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s490001784x345683100_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s490001784x345683100(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s708019417x1279437633_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s708019417x1279437633_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s708019417x1279437633_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_strEq_c_lent(v_lit_240, v_t_247, 2)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_248;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s708019417x1279437633_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s708019417x1279437633_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1688354384x1781591142_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1688354384x1781591142_entry, 3, 0};

V g_list_2emap_24s1688354384x1781591142(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2eowned_2eownSt(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1688354384x1781591142_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1688354384x1781591142_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1688354384x1781591142(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1688354384x1781591142_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1688354384x1781591142_24dps_entry, 4, 0};

V g_list_2emap_24s1688354384x1781591142_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2eowned_2eownSt(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1688354384x1781591142_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1688354384x1781591142_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s273193875x235978955_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s273193875x235978955_24dps_entry, 5, 0};

V g_list_2emap_24s273193875x235978955_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_245, 0));
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_a_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 2ULL, 2);
      v_a_2412 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_numbered_2413 = heff_take_field(v_a_2412, 1);
    V v_kinds_2414 = heff_get_n(v_a_2412, 2, 7);
    V v_t_2416;
    if ((heff_dup(v_numbered_2413) == NTAG(TAG_True))) {
      heff_drop(v_numbered_2413);
      V v_t_2415 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
      v_t_2416 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2415, v_kinds_2414});
    } else {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_numbered_2413);
      v_t_2416 = v_kinds_2414;
    }
    V v_t_2417 = ({ V a_0 = heff_dup(v_lit_241); V a_1 = heff_dup(v_lit_242); V a_2 = v_t_2416; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_t_249, heff_dup(v_lit_240)), v_t_2417});
    V v_cell_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2419;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s273193875x235978955_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s273193875x235978955_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s1460603830x671758883_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1460603830x671758883_entry, 2, 0};

V g_list_2emap_24s1460603830x671758883(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EStr, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1460603830x671758883_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1460603830x671758883_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1460603830x671758883(a[0], a[1]);
}
Clo g_list_2efoldl_24s1278499411x1393297768_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1278499411x1393297768_entry, 2, 0};

V g_list_2efoldl_24s1278499411x1393297768(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2eordmap_2einsert_24s1703101629x493626677(v_z_240, heff_dup(v_x_242), NTAG(TAG_MkUnit)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1278499411x1393297768_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1278499411x1393297768(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1367173129x1257089258_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1367173129x1257089258_24dps_entry, 2, 0};

V g_list_2emap_24s1367173129x1257089258_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1367173129x1257089258_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1367173129x1257089258_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1457049037x722637222_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1457049037x722637222_entry, 1, 0};

V g_list_2ekeepIf_24s1457049037x722637222(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2410 = (g_list_2ekeepIf_24s1457049037x722637222_24dps(v_xs_242, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1457049037x722637222_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1457049037x722637222(a[0]);
}
Clo g_list_2emap_24s1478286876x830244177_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1478286876x830244177_24dps_entry, 2, 0};

V g_list_2emap_24s1478286876x830244177_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1478286876x830244177_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1478286876x830244177_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s330602584x1277356584_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s330602584x1277356584_entry, 3, 0};

V g_list_2efoldl_24s330602584x1277356584(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_248 = heff_strAppend(heff_get_n(v_t_247, 0, 3), heff_dup(v_lit_240));
    V v_t_2411;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_243, 1);
      v_t_2411 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2412 = heff_strAppend(v_t_248, heff_intShow(v_t_2411));
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_243, 1);
      v_t_2415 = heff_dup(v_a_2414);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2416 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_241, v_t_2412, v_t_2415));
    V t_0 = v_lit_240;
    V t_1 = v_t_2416;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s330602584x1277356584_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s330602584x1277356584(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2eall_24s262401054x194288545_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s262401054x194288545_entry, 2, 0};

V g_list_2eall_24s262401054x194288545(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_x_242, v_lit_240, 0)) {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_lit_240);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s262401054x194288545_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall_24s262401054x194288545(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s512765522x2052101617_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s512765522x2052101617_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s512765522x2052101617_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_intEq_c_lent(v_x_243, v_lit_240, 0)) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s512765522x2052101617_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s512765522x2052101617_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1985010810x1780722131_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1985010810x1780722131_24dps_entry, 5, 0};

V g_list_2emap_24s1985010810x1780722131_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2elower_2egroupOut(v_lit_240, heff_dup(v_lit_241), v_lit_242, v_x_245));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1985010810x1780722131_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s1985010810x1780722131_24dps(a0, a[1], a2, a[3], a[4]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s122741325x871243494_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s122741325x871243494_24dps_entry, 5, 0};

V g_list_2ekeepIf_24s122741325x871243494_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (!heff_strEq_c(heff_strSlice_lent(v_x_245, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_248 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s122741325x871243494_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24s122741325x871243494_24dps(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s185327080x101197346_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s185327080x101197346_entry, 4, 0};

V g_list_2ekeepIf_24s185327080x101197346(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_244, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_247 = (g_list_2ekeepIf_24s185327080x101197346_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s185327080x101197346_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24s185327080x101197346(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24s164225955x66209884_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s164225955x66209884_24dps_entry, 4, 0};

V g_list_2emap_24s164225955x66209884_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2eglue_2eglueOf(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s164225955x66209884_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s164225955x66209884_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_str1, 4, "  V ");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_str2, 2, "v_");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_str3, 11, "heff_field(");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_str4, 2, ", ");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_str5, 1, ")");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_str6, 20, "heff_dup(heff_field(");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_str7, 2, ", ");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_str8, 2, "))");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_str9, 3, " = ");
HEFF_LIT(g_list_2emap_24s1518131677x2038133191_str10, 1, ";");
Clo g_list_2emap_24s1518131677x2038133191_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1518131677x2038133191_entry, 3, 0};

V g_list_2emap_24s1518131677x2038133191(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_sv_245 = heff_dup(v_lit_240);
    V v_plain_246 = heff_dup(v_lit_241);
    V v_x3_247 = v_x_243;
    V v_t_2418;
    switch (heff_tag_of(v_x3_247)) {
    case TAG_MkPair: {
      V v_v_248 = heff_field(v_x3_247, 0);
      V v_i_249 = heff_field(v_x3_247, 1);
      heff_take_n(v_x3_247, 3ULL, 2);
      V v_t_2410 = ({ V a_0 = v_v_248; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_list_2emap_24s1518131677x2038133191_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_v_248); r_; });
      V v_t_2411 = heff_strAppend(((V)&g_list_2emap_24s1518131677x2038133191_str1), heff_strAppend(((V)&g_list_2emap_24s1518131677x2038133191_str2), v_t_2410));
      V v_t_2416;
      if ((heff_dup(v_plain_246) == NTAG(TAG_True))) {
        heff_drop(v_plain_246);
        V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1518131677x2038133191_str3), v_sv_245), ((V)&g_list_2emap_24s1518131677x2038133191_str4));
        V v_t_2413 = heff_strAppend(v_t_2412, heff_intShow(v_i_249));
        v_t_2416 = heff_strAppend(v_t_2413, ((V)&g_list_2emap_24s1518131677x2038133191_str5));
      } else {
        heff_drop(v_plain_246);
        V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1518131677x2038133191_str6), v_sv_245), ((V)&g_list_2emap_24s1518131677x2038133191_str7));
        V v_t_2415 = heff_strAppend(v_t_2414, heff_intShow(v_i_249));
        v_t_2416 = heff_strAppend(v_t_2415, ((V)&g_list_2emap_24s1518131677x2038133191_str8));
      }
      V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_list_2emap_24s1518131677x2038133191_str9)), v_t_2416);
      v_t_2418 = heff_strAppend(v_t_2417, ((V)&g_list_2emap_24s1518131677x2038133191_str10));
      break;
    }
    default: heff_nomatch(v_x3_247);
    }
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = (g_list_2emap_24s1518131677x2038133191_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_2419)));
    heff_drop(v_u_2420);
    return v_cell_2419;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1518131677x2038133191_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1518131677x2038133191(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1960706388x853997965_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1960706388x853997965_entry, 1, 0};

V g_list_2emap_24s1960706388x853997965(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1960706388x853997965_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1960706388x853997965_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1960706388x853997965(a[0]);
}
Clo g_list_2emap_24s265594371x763318798_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s265594371x763318798_entry, 1, 0};

V g_list_2emap_24s265594371x763318798(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_243 = heff_take_field(v_x_241, 0);
    V v_key_244 = heff_get_n(v_x_241, 1, 4);
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){v_name_243, heff_tag_n(TAG_SGlobal, 1, (V[]){v_key_244})});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s265594371x763318798_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s265594371x763318798_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s265594371x763318798(a[0]);
}
Clo g_list_2eany_24s285809686x1684902122_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s285809686x1684902122_entry, 2, 0};

V g_list_2eany_24s285809686x1684902122(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s285809686x1684902122_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s285809686x1684902122(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1823913665x1128491553_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1823913665x1128491553_entry, 2, 0};

V g_list_2ekeepIf_24s1823913665x1128491553(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(v_x_242), heff_dup(heff_rfield(v_lit_240, 1)))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s1823913665x1128491553_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1823913665x1128491553_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1823913665x1128491553(a[0], a[1]);
}
Clo g_list_2ezipWith_24s29557946x653938035_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s29557946x653938035_24dps_entry, 3, 0};

V g_list_2ezipWith_24s29557946x653938035_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_245, 1, 3), v_x_243});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s29557946x653938035_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s29557946x653938035_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s257286374x378693326_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s257286374x378693326_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s257286374x378693326_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 0, 2);
    if ((heff_intLe_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_t_245)) && heff_intLe_c(heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 1, 2), heff_dup(heff_rfield(v_lit_240, 1))))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s257286374x378693326_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s257286374x378693326_24dps(a[0], a[1], a[2]);
}
Clo g_list_2epushRun_24s1577108484x1259861853_clo = {{0x80000000u, K_CLO, 0}, g_list_2epushRun_24s1577108484x1259861853_entry, 3, 0};

V g_list_2epushRun_24s1577108484x1259861853(V v_k_240, V v_run_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_j_245 = heff_field(v_x41_243, 0);
      V v_below_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24MkPair = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      if (heff_intEq_c_lent(v_j_245, v_k_240, 0)) {
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_j_245);
        heff_drop_cell(v_ru_24x41_243_24MkPair, 2);
        V v_t_247 = (g_list_2emerge_24s1347843181x1368204458(v_below_246, v_run_241));
        V t_0 = heff_intAdd(v_k_240, MK_INT(1LL));
        V t_1 = v_t_247;
        V t_2 = v_rest_244;
        v_k_240 = t_0;
        v_run_241 = t_1;
        v_x4_242 = t_2;
        goto top;
      } else {
        V v_t_248 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_243_24MkPair, TAG_MkPair, 2, (V[]){v_j_245, v_below_246}), v_rest_244});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), v_t_248});
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2epushRun_24s1577108484x1259861853_entry(V self, V *a) {
  (void)self;
  return g_list_2epushRun_24s1577108484x1259861853(a[0], a[1], a[2]);
}
Clo g_list_2emergeRuns_24s594401848x1575493307_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeRuns_24s594401848x1575493307_entry, 2, 0};

V g_list_2emergeRuns_24s594401848x1575493307(V v_stack_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkPair: {
    V v_run_242 = heff_field(v_x3_241, 0);
    V v_x32_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x32_243)) {
    case TAG_Nil: {
      return ({ V a_0 = v_run_242; V a_1 = v_stack_240; V r_ = (g_list_2ecollapse_24s1391945213x481576570(a_0, a_1)); heff_drop(v_stack_240); r_; });
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x32_243, 0);
      V v_xs_245 = heff_field(v_x32_243, 1);
      heff_take_n(v_x32_243, 3ULL, 2);
      V v_t_246 = (g_list_2epushRun_24s1577108484x1259861853(MK_INT(0LL), v_run_242, v_stack_240));
      V v_t_247 = (g_list_2erunFrom_24s1871674023x1487040306(v_x_244, v_xs_245));
      V t_0 = v_t_246;
      V t_1 = v_t_247;
      v_stack_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x32_243);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2emergeRuns_24s594401848x1575493307_entry(V self, V *a) {
  (void)self;
  return g_list_2emergeRuns_24s594401848x1575493307(a[0], a[1]);
}
Clo g_list_2efoldl_24s1854884545x892082821_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1854884545x892082821_entry, 2, 0};

V g_list_2efoldl_24s1854884545x892082821(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2edoc_2e_3c_3e(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1854884545x892082821_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1854884545x892082821(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2062876492x2082655823_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2062876492x2082655823_entry, 2, 0};

V g_list_2efoldl_24s2062876492x2082655823(V v_z_240, V v_x3_241) {
top: ;
  V v_front_242 = heff_take_field(v_z_240, 0);
  V v_back_243 = heff_get_n(v_z_240, 1, 2);
  return (g_list_2efoldl_24s2062876492x2082655823_24scalars(v_front_242, v_back_243, v_x3_241));
}
V g_list_2efoldl_24s2062876492x2082655823_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2062876492x2082655823(a[0], a[1]);
}

HeffT2 g_list_2efind_24s595925281x993936542_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 7);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_lit_240, 6)), 0, 14);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), v_t_244)) {
      heff_drop_rec(v_lit_240, 7);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2ekeepIf_24s742867582x682687968_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s742867582x682687968_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s742867582x682687968_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 4);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s742867582x682687968_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s742867582x682687968_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2eany_24s105899861x584770213_str0, 4, "page");
Clo g_list_2eany_24s105899861x584770213_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s105899861x584770213_entry, 1, 0};

V g_list_2eany_24s105899861x584770213(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 1)), 0, 3);
    if (heff_strEq_c(v_t_243, ((V)&g_list_2eany_24s105899861x584770213_str0))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s105899861x584770213_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s105899861x584770213(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1628253759x601849359_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1628253759x601849359_entry, 3, 0};

V g_list_2emap_24s1628253759x601849359(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop_rec(v_lit_241, 5);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_a_245 = heff_dup(heff_rfield(v_lit_240, 3));
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 1)), 0, 2);
    V v_t_247 = heff_strSlice(heff_dup(v_a_245), heff_dup(heff_rfield(v_lit_241, 2)), v_t_246);
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 1)), 1, 2);
    V v_t_249 = heff_strSlice(v_a_245, v_t_248, heff_dup(heff_rfield(v_lit_241, 4)));
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_247, v_x_243), v_t_249);
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s1628253759x601849359_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1628253759x601849359_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1628253759x601849359(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s1441124185x871809048_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1441124185x871809048_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1441124185x871809048_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 8);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_x_243, 2)), heff_dup(heff_rfield(v_lit_240, 2)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 8);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1441124185x871809048_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1441124185x871809048_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str0, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str1, 1, "]");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str2, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str3, 4, "...]");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str4, 3, "...");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str5, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str6, 4, "...]");
Clo g_list_2emap_24s2029999044x514618413_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029999044x514618413_24dps_entry, 2, 0};

V g_list_2emap_24s2029999044x514618413_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_meta_244 = heff_take_field(v_x_242, 0);
    V v_arity_245 = heff_get_n(v_x_242, 1, 3);
    V v_m_246 = v_meta_244;
    V v_t_247;
    switch (heff_tag_of(v_arity_245)) {
    case TAG_One: {
      v_t_247 = v_m_246;
      break;
    }
    case TAG_Optional: {
      v_t_247 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_24dps_str0), v_m_246), ((V)&g_list_2emap_24s2029999044x514618413_24dps_str1));
      break;
    }
    case TAG_Many: {
      v_t_247 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_24dps_str2), v_m_246), ((V)&g_list_2emap_24s2029999044x514618413_24dps_str3));
      break;
    }
    case TAG_Some: {
      v_t_247 = heff_strAppend(v_m_246, ((V)&g_list_2emap_24s2029999044x514618413_24dps_str4));
      break;
    }
    case TAG_Rest: {
      v_t_247 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_24dps_str5), v_m_246), ((V)&g_list_2emap_24s2029999044x514618413_24dps_str6));
      break;
    }
    default: heff_nomatch(v_arity_245);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029999044x514618413_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029999044x514618413_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s624430845x1248965393_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s624430845x1248965393_entry, 1, 0};

V g_list_2eany_24s624430845x1248965393(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    switch (heff_tag_of(v_t_243)) {
    case TAG_One: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Optional: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Many: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Some: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Rest: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s624430845x1248965393_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s624430845x1248965393(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24f1663632568x709545076_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1663632568x709545076_entry, 4, 0};

V g_list_2efoldl_24f1663632568x709545076(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_2431;
    switch (heff_tag_of(v_x_244)) {
    case TAG_PartVal: {
      V v_a_246 = heff_field(v_x_244, 0);
      switch (heff_tag_of(v_a_246)) {
      case TAG_SVar: {
        V v_a_247 = heff_field(v_a_246, 0);
        v_t_2431 = heff_bool(heff_strEq_c_lent(v_lit_242, v_a_247, 0));
        break;
      }
      case TAG_SGlobal: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SRec: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    case TAG_PartOp: {
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop(v_t_2431);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2431);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f1663632568x709545076_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_list_2efoldl_24f1663632568x709545076(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f1582053009x1594640150_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1582053009x1594640150_entry, 5, 0};

V g_list_2efoldl_24f1582053009x1594640150(V v_lit_240, V v_z_241, V v_lit_242, V v_n_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_n_243);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    if (heff_intLe_c_lent(v_n_243, MK_INT(0LL), 2)) {
      heff_drop(v_lit_240);
      heff_drop(v_n_243);
      return v_z_241;
    } else {
      if (heff_strEq_c_lent(v_x_245, v_lit_242, 0)) {
        V t_0 = heff_dup(v_lit_240);
        V t_1 = heff_intAdd(v_z_241, v_lit_240);
        V t_2 = v_lit_242;
        V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
        V t_4 = v_xs_246;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_lit_242 = t_2;
        v_n_243 = t_3;
        v_x2_244 = t_4;
        goto top;
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_z_241;
        V t_2 = v_lit_242;
        V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
        V t_4 = v_xs_246;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_lit_242 = t_2;
        v_n_243 = t_3;
        v_x2_244 = t_4;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2efoldl_24f1582053009x1594640150_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_list_2efoldl_24f1582053009x1594640150(a[0], a[1], a2, a[3], a4); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_list_2emap_24f505181408x1813697659_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f505181408x1813697659_entry, 2, 0};

V g_list_2emap_24f505181408x1813697659(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_x_242);
      HEFF_LAST return g_list_2emap_24s1809017761x1063871171_24tok2(v_ru_24x2_241_24Cons, v_xs_243);
    } else {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_hole()});
      V v_u_245 = (g_list_2emap_24f505181408x1813697659_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f505181408x1813697659_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f505181408x1813697659(a[0], a[1]);
}
Clo g_list_2efoldl_24f932140008x904662204_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f932140008x904662204_entry, 3, 0};

V g_list_2efoldl_24f932140008x904662204(V v_z_240, V v_box_24n_241, V v_x2_242) {
  int64_t v_n_241 = heff_unbox_word(v_box_24n_241);
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if ((v_n_241 <= ((int64_t)0ULL))) {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return v_z_240;
    } else {
      V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_z_240});
      int64_t t_1 = (v_n_241 - ((int64_t)1ULL));
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_n_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f932140008x904662204_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f932140008x904662204(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1937570095x2110149801_24tok2_entry, 2, 0};

V g_list_2emap_24s1937570095x2110149801_24tok2(V v_tok_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1937570095x2110149801_24dps(v_xs_243, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1937570095x2110149801_24tok2(a[0], a[1]);
}