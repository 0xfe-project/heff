// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
HeffT2 g_std_2ehttp_2eheaderIn_24cpr(V, V);
V g_std_2ehttp_2esameFrom(V, V, V);
V g_std_2ehttp_2esameFrom_entry(V self, V *a);
extern Clo g_std_2ehttp_2esameFrom_clo;
Clo g_std_2ehttp_2esameFrom_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2esameFrom_entry, 3, 0};

V g_std_2ehttp_2esameFrom(V v_a_240, V v_b_241, V v_box_24i_242) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_a_240, 0)) <= v_i_242)) {
    return NTAG(TAG_True);
  } else {
    V v_c_243 = heff_strByteAt_lent(v_a_240, heff_box_word(v_i_242), 2);
    V v_t_244;
    if (((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)90ULL)))) {
      v_t_244 = heff_box_word((heff_unbox_word(v_c_243) + ((int64_t)32ULL)));
    } else {
      v_t_244 = v_c_243;
    }
    V v_c_245 = heff_strByteAt_lent(v_b_241, heff_box_word(v_i_242), 2);
    V v_t_246;
    if (((((int64_t)65ULL) <= heff_peek_word(v_c_245)) && (heff_peek_word(v_c_245) <= ((int64_t)90ULL)))) {
      v_t_246 = heff_box_word((heff_unbox_word(v_c_245) + ((int64_t)32ULL)));
    } else {
      v_t_246 = v_c_245;
    }
    if ((heff_unbox_word(v_t_244) == heff_unbox_word(v_t_246))) {
      V t_0 = v_a_240;
      V t_1 = v_b_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      v_a_240 = t_0;
      v_b_241 = t_1;
      v_i_242 = t_2;
      goto top;
    } else {
      return NTAG(TAG_False);
    }
  }
}
V g_std_2ehttp_2esameFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ehttp_2esameFrom(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_std_2ehttp_2eheaderIn_24cpr(V v_name_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if ((heff_unbox_word(heff_strLength_lent(v_name_240, 0)) == heff_unbox_word(heff_strLength_lent(v_n_244, 0)))) {
        V v_t_246 = (g_std_2ehttp_2esameFrom(v_name_240, v_n_244, MK_INT(0LL)));
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_245)}});
        } else {
          heff_drop(v_t_246);
          V t_0 = v_name_240;
          V t_1 = v_rest_243;
          v_name_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      } else {
        V t_0 = v_name_240;
        V t_1 = v_rest_243;
        v_name_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}