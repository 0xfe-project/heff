// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
HeffT2 g_std_2ehttp_2eheaderIn_24cpr(V, V);
V g_std_2ehttp_2esameName_2esameFrom_240(V, V, V);
V g_std_2ehttp_2esameName_2esameFrom_240_entry(V self, V *a);
extern Clo g_std_2ehttp_2esameName_2esameFrom_240_clo;

HeffT2 g_std_2ehttp_2eheaderIn_24cpr(V v_name_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if ((heff_unbox_word(heff_strLength_lent(v_name_240, 0)) == heff_unbox_word(heff_strLength_lent(v_n_244, 0)))) {
        V v_t_246 = (g_std_2ehttp_2esameName_2esameFrom_240(v_name_240, v_n_244, MK_INT(0LL)));
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_245)}});
        } else {
          heff_drop(v_t_246);
          V t_0 = v_name_240;
          V t_1 = v_rest_243;
          v_name_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      } else {
        V t_0 = v_name_240;
        V t_1 = v_rest_243;
        v_name_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}