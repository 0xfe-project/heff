// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_JArray 50516
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_PathUri 23459
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Send 26077
#define LBL_checked 974171621
#define LBL_claim 296100950
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_error 298143266
#define LBL_imports 10411951
#define LBL_key 315609
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_severity 75955546
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_path__target__name__occurrences[] = {LBL_path, LBL_target, LBL_name, LBL_occurrences};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_text__program[] = {LBL_text, LBL_program};
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2edriver_2etraceless(V);
V g_heff_2ebuild_2edriver_2etraceless_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etraceless_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
V g_heff_2ebuild_2equery_2edefinitionAt(V, V);
V g_heff_2ebuild_2equery_2edefinitionAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionAt_clo;
V g_heff_2ebuild_2equery_2edocMarkdownIn(V, V);
V g_heff_2ebuild_2equery_2edocMarkdownIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMarkdownIn_clo;
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V, V, V);
V g_heff_2ebuild_2equery_2etargetIn(V, V, V, V);
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etargetIn_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL(V);
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo;
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741(V, V, V, V, V);
V g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741_clo;
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713(V, V);
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_clo;
V g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739(V, V, V, V);
V g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(V);
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_clo;
V g_heff_2elsp_2elsp_2ehoverOf(V, V);
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679(V, V);
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_clo;
V g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594(V, V);
V g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_clo;
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok1(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok1_clo;
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok2(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok2_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok2_clo;
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673(V, V, V);
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993(V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993_clo;
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438(V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406(V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_clo;
V g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_clo;
V g_heff_2elsp_2elsp_2eundue(V, V);
V g_heff_2elsp_2elsp_2eundue_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eundue_clo;
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923(V, V);
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_clo;
V g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212(V, V);
V g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
V g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(V, V, V);
V g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_entry(V self, V *a);
extern Clo g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_clo;
V g_json_2equotedInto_2eescapeInto_241(V, V, V);
V g_json_2equotedInto_2eescapeInto_241_entry(V self, V *a);
extern Clo g_json_2equotedInto_2eescapeInto_241_clo;
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
V g_list_2eany_24s1399422749x931279364(V, V);
V g_list_2eany_24s1399422749x931279364_entry(V self, V *a);
extern Clo g_list_2eany_24s1399422749x931279364_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1424316379x433407702_24cpr(V, V, V, V, V, V);
HeffT2 g_list_2efind_24s792771115x178990339_24cpr(V, V);
V g_list_2efoldl_24f2094160282x1876485468(V, V, V);
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2094160282x1876485468_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2ekeepIf_24s1161549307x1906011635(V);
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_clo;
V g_list_2ekeepIf_24s304198972x561714839(V, V);
V g_list_2ekeepIf_24s304198972x561714839_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s304198972x561714839_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1533895818x411093629(V);
V g_list_2emap_24s1533895818x411093629_entry(V self, V *a);
extern Clo g_list_2emap_24s1533895818x411093629_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str1, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str2, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str3, 1, "s");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str4, 7, "module ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str5, 2, " (");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str6, 22, ") does not elaborate: ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str7, 6, " error");
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ediagsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagsOf_entry, 3, 0};

V g_heff_2elsp_2elsp_2ediagsOf(V v_src_240, V v_program_241, V v_errors_242) {
top: ;
  V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_241)));
  V v_t_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    v_t_246 = heff_get_n(v_x_244, 6, 14);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam0, 1, 1, (V[]){heff_dup(v_src_240)}), v_errors_242));
  V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_241));
  V v_xs_2417 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2416; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2416); r_; });
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2417));
  V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam1, 1, 1, (V[]){v_src_240}), v_t_2418));
  V v_t_2441 = (g_heff_2elsp_2elsp_2ecatMaybesL(v_t_2440));
  V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2441));
  return (g_prelude_2e_2b_2b(v_t_246, v_t_2442));
}
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ediagsOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_imports_249 = heff_get_n(v_t_248, 0, 4);
  HeffT2 v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str0); V a_2 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str1); V a_3 = v_e_247; V b_4 = MK_INT(0LL); V a_5 = v_imports_249; HeffT2 r_ = (g_list_2efind_24s1424316379x433407702_24cpr(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(b_4); heff_drop(v_imports_249); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_sp_2414;
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_i_2413 = v_field_2412;
      v_sp_2414 = heff_get_n(v_i_2413, 2, 3);
    } else {
      heff_drop(v_field_2412);
      v_sp_2414 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
    }
    return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_e_247, v_sp_2414, NTAG(TAG_Nothing)});
  }
}
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args) {
  V v_c_2419 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_imports_2421 = heff_get_n(v_t_2420, 0, 4);
  V v_c_2422 = v_c_2419;
  V v_x1_2423 = (g_list_2ekeepIf_24s1161549307x1906011635(heff_dup(heff_rfield(v_c_2422, 6))));
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_Nil: {
    heff_drop(v_imports_2421);
    heff_drop_rec(v_c_2422, 14);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2423, 0ULL, 2);
    V v_t_2426 = (g_list_2eany_24s1399422749x931279364(heff_dup(v_c_2422), v_imports_2421));
    if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
      heff_drop(v_t_2426);
      HeffT2 v_t_2427 = ({ V a_0 = heff_rfield(v_c_2422, 0); V a_1 = v_imports_2421; HeffT2 r_ = (g_list_2efind_24s792771115x178990339_24cpr(a_0, a_1)); heff_drop(v_imports_2421); r_; });
      {
        V v_field_2429 = v_t_2427.f[1];
        int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
        V v_sp_2431;
        if ((v_tag_2428 == ((int64_t)0ULL))) {
          V v_i_2430 = v_field_2429;
          v_sp_2431 = heff_get_n(v_i_2430, 2, 3);
        } else {
          heff_drop(v_field_2429);
          v_sp_2431 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
        }
        V v_t_2432 = (g_list_2efoldl_24f2094160282x1876485468(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_2422, 6)));
        V v_t_2433 = (g_list_2efoldl_24f2094160282x1876485468(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_2422, 6)));
        V v_t_2434;
        if (heff_intEq_c(v_t_2433, MK_INT(1LL))) {
          v_t_2434 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str2);
        } else {
          v_t_2434 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str3);
        }
        V v_t_2435 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ediagsOf_str4), heff_take_field(v_c_2422, 0));
        V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2elsp_2elsp_2ediagsOf_str5)), heff_get_n(v_c_2422, 1, 14));
        V v_t_2437 = heff_strAppend(heff_strAppend(v_t_2436, ((V)&g_heff_2elsp_2elsp_2ediagsOf_str6)), heff_intShow(v_t_2432));
        V v_msg_2438 = heff_strAppend(heff_strAppend(v_t_2437, ((V)&g_heff_2elsp_2elsp_2ediagsOf_str7)), v_t_2434);
        V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SWarning), v_msg_2438, v_sp_2431, NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2439});
      }
    } else {
      heff_drop(v_imports_2421);
      heff_drop_rec(v_c_2422, 14);
      heff_drop(v_t_2426);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_x1_2423);
  }
}
Clo g_heff_2elsp_2elsp_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeptOf_entry, 1, 0};

V g_heff_2elsp_2elsp_2ekeptOf(V v_program_240) {
top: ;
  V v_x1_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_240)));
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_program_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
    V v_xs_245 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_244; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_244); r_; });
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
    V v_t_247 = (g_list_2emap_24s1533895818x411093629(v_t_246));
    V v_t_248 = (g_heff_2ebuild_2edriver_2etraceless(v_x_242));
    V v_t_249 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return (g_prelude_2e_2b_2b(v_t_247, v_t_249));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ekeptOf(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str0, 10, "   (local)");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str1, 11, "   (global)");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str2, 3, " : ");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str3, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str4, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str6, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str7, 4, "\012```");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str8, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str9, 11, "\012```\012\012---\012\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str10, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str11, 8, "markdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str12, 5, "value");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str13, 8, "contents");
Clo g_heff_2elsp_2elsp_2ehoverOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehoverOf_entry, 2, 0};

V g_heff_2elsp_2elsp_2ehoverOf(V v_a_240, V v_p_241) {
top: ;
  V v_program_242 = heff_take_field(v_a_240, 2);
  V v_text_243 = heff_get_n(v_a_240, 1, 3);
  V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_242)));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    heff_drop(v_program_242);
    heff_drop(v_text_243);
    return NTAG(TAG_JNull);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Cons = heff_take_reuse_n(v_x1_244, 1ULL, 2);
    V v_off_247 = (g_heff_2elsp_2elsp_2eoffsetIn(v_text_243, heff_dup(v_p_241)));
    HeffT2 v_t_248 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_x_245, v_off_247));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_i_2411 = v_field_2410;
        V v_name_2412 = heff_take_field(v_i_2411, 1);
        V v_ty_2413 = heff_take_field(v_i_2411, 4);
        V v_key_2414 = heff_get_n(v_i_2411, 2, 5);
        V v_t_2415 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_name_2412));
        V v_t_2416 = heff_tr(heff_call(v_ty_2413, 1, (V[]){NTAG(TAG_MkUnit)}));
        V v_t_2417 = v_key_2414;
        V v_t_2419;
        switch (heff_tag_of(v_t_2417)) {
        case TAG_Nothing: {
          v_t_2419 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str0);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2417, 0ULL, 1);
          v_t_2419 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str1);
          break;
        }
        default: heff_nomatch(v_t_2417);
        }
        V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2elsp_2elsp_2ehoverOf_str2)), v_t_2416);
        V v_t_2421 = heff_strAppend(v_t_2420, v_t_2419);
        V v_program_2422 = v_program_242;
        V v_off_2423 = ({ V a_0 = v_text_243; V a_1 = v_p_241; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(a_0, a_1)); heff_drop(v_text_243); r_; });
        V v_t_2424 = (g_heff_2ebuild_2equery_2edefinitionAt(v_program_2422, v_off_2423));
        V v_doc_2433;
        switch (heff_tag_of(v_t_2424)) {
        case TAG_Nothing: {
          v_doc_2433 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str3);
          break;
        }
        case TAG_Just: {
          V v_d_2425 = heff_field(v_t_2424, 0);
          heff_take_n(v_t_2424, 1ULL, 1);
          V v_source_2426 = heff_take_field(v_d_2425, 1);
          V v_span_2427 = heff_get_n(v_d_2425, 2, 3);
          V v_src_2428 = heff_dup(v_source_2426);
          V v_start_2429 = ({ V a_0 = v_source_2426; V a_1 = heff_get_n(v_span_2427, 0, 2); V r_ = (g_heff_2ebuild_2equery_2elineStartOf(a_0, a_1)); heff_drop(v_source_2426); r_; });
          V v_t_2430 = ({ V a_0 = v_src_2428; V a_1 = v_start_2429; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ecommentAbove(a_0, a_1, a_2)); heff_drop(v_src_2428); r_; });
          V v_t_2431 = (g_list_2emap_24s1819241345x1511673126(v_t_2430));
          V v_ls_2432 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2431));
          v_doc_2433 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str4); V a_1 = v_ls_2432; V r_ = (g_heff_2ebuild_2equery_2edocMarkdownIn(a_0, a_1)); heff_drop(v_ls_2432); r_; });
          break;
        }
        default: heff_nomatch(v_t_2424);
        }
        V v_t_2435;
        if (heff_strEq_c_lent(v_doc_2433, ((V)&g_heff_2elsp_2elsp_2ehoverOf_str5), 2)) {
          heff_drop(v_doc_2433);
          v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str6), v_t_2421), ((V)&g_heff_2elsp_2elsp_2ehoverOf_str7));
        } else {
          V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str8), v_t_2421), ((V)&g_heff_2elsp_2elsp_2ehoverOf_str9));
          v_t_2435 = heff_strAppend(v_t_2434, v_doc_2433);
        }
        V v_t_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str10), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str11)})});
        V v_t_2437 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str12), heff_tag_n(TAG_JString, 1, (V[]){v_t_2435})});
        V v_t_2438 = heff_tag_at_n(v_ru_24x1_244_24Cons, TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
        V v_t_2439 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_t_2438})});
        V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str13), v_t_2439}), NTAG(TAG_Nil)});
        return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2440});
      } else {
        heff_drop(v_p_241);
        heff_drop(v_program_242);
        heff_drop(v_text_243);
        heff_drop_cell(v_ru_24x1_244_24Cons, 2);
        heff_drop(v_field_2410);
        return NTAG(TAG_JNull);
      }
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehoverOf(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2eundue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eundue_entry, 2, 0};

V g_heff_2elsp_2elsp_2eundue(V v_due_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_due_240;
  }
  case TAG_Cons: {
    V v_f_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(v_due_240, v_f_242));
    V t_0 = v_t_244;
    V t_1 = v_rest_243;
    v_due_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2eundue_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eundue(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str1, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str4, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str5, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str6, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str7, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str8, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str9, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str10, 1, "}");
Clo g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_entry, 2, 0};

V g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594(V v_method_240, V v_params_241) {
top: ;
  V v_t_242 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str0), ((V)&g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str1), MK_INT(0LL)));
  V v_acc_243 = heff_strAppend(heff_strAppend(v_t_242, ((V)&g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str2)), ((V)&g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str3));
  V v_t_244 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str4), heff_strAppend(v_acc_243, ((V)&g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str5)), MK_INT(0LL)));
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str6), heff_tag_n(TAG_JString, 1, (V[]){v_method_240})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str7), v_params_241}), NTAG(TAG_Nil)});
  V v_t_247 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str8); V a_1 = heff_strAppend(v_t_244, ((V)&g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str9)); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_246}); V r_ = (g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_a_248 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_str10)), NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return heff_tail(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){v_t_2412});
}
V g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_str0, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_str1, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_str2, 31, "textDocument/publishDiagnostics");
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam3, 1, 0};
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam8(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_entry, 2, 0};

V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713(V v_st_240, V v_f_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 0), v_f_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_d_245 = v_field_244;
      return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam0, 2, 3, (V[]){v_st_240, v_f_241, v_d_245});
    } else {
      heff_drop(v_f_241);
      heff_drop(v_field_244);
      return heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam8, 2, 1, (V[]){v_st_240});
    }
  }
}
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam2(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_d_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2elsp_2elsp_2eanalysed_24s1421130319x689647871(v_st_240, v_f_241, v_d_245, v_hd_249, v_k_2410));
}
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam3(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam1(V self, V *args) {
  V v_use_248 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_d_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_248;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam2, 2, 3, (V[]){v_st_240, v_f_241, v_d_245});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam3_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam5(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_a_2418 = heff_env(self)[0];
  heff_drop(v_hd_2419);
  heff_clo_take(self, 1);
  V f_ = v_k_2420;
  args[0] = v_a_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_d_245 = heff_env(self)[0];
  V v_program_2424 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_drop(v_x_2430);
  heff_clo_take(self, 5);
  V v_t_2431 = heff_rec_n(2, shape_text__program, (V[]){heff_get_n(v_d_245, 1, 2), v_program_2424});
  V v_c_2432 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_st_240, 1), v_f_241, v_t_2431));
  V v_due_2433 = heff_take_field(v_st_240, 2);
  V v_project_2434 = heff_take_field(v_st_240, 3);
  V v_watch_2435 = heff_take_field(v_st_240, 4);
  V v_shutdown_2436 = heff_take_field(v_st_240, 5);
  V v_lib_2437 = heff_take_field(v_st_240, 6);
  V v_t_2438 = ({ V rv_1 = v_c_2432; V rv_2 = v_due_2433; V rv_3 = v_project_2434; V rv_4 = v_watch_2435; V rv_5 = v_shutdown_2436; V rv_6 = v_lib_2437; V rr_ = heff_rec_reuse_nf(v_st_240, 1ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V f_ = v_k_247;
  args[0] = v_t_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_d_245 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_diags_2423 = heff_take_field(v_x_2422, 1);
  V v_program_2424 = heff_get_n(v_x_2422, 0, 2);
  V v_t_2425 = heff_tag_n(TAG_JString, 1, (V[]){heff_dup(heff_rfield(v_d_245, 0))});
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_str0), heff_tag_n(TAG_JArray, 1, (V[]){v_diags_2423})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_str1), v_t_2425}), v_t_2427});
  V v_t_2429 = heff_tr(g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594(((V)&g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_str2), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2428})));
  heff_clo_take(self, 5);
  V f_ = v_t_2429;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam7, 1, 5, (V[]){v_d_245, v_program_2424, v_st_240, v_f_241, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_d_245 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_t_2421;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_why_2417 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    v_t_2421 = heff_tr(heff_call(((V)&g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_clo), 4, (V[]){heff_dup(v_st_240), heff_dup(v_f_241), heff_dup(v_d_245), v_why_2417}));
    break;
  }
  case TAG_Right: {
    V v_a_2418 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    v_t_2421 = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam5, 2, 1, (V[]){v_a_2418});
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  heff_clo_take(self, 5);
  V f_ = v_t_2421;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam6, 1, 5, (V[]){v_d_245, v_hd_246, v_st_240, v_f_241, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_st_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_d_245 = heff_env(self)[2];
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam1, 1, 3, (V[]){heff_dup(v_st_240), heff_dup(v_f_241), heff_dup(v_d_245)})})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  heff_clo_take(self, 3);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_246), heff_clo_n(g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam4, 1, 5, (V[]){v_st_240, v_f_241, v_d_245, v_hd_246, v_k_247})));
}
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_lam8(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_drop(v_hd_2439);
  heff_clo_take(self, 1);
  V f_ = v_k_2440;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_entry, 6, 0};

V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152(V v_a_240, V v_f_241, V v_off_242, V v_t_243, V v_z_244, V v_z_245) {
top: ;
  V v_target_246 = heff_take_field(v_t_243, 0);
  V v_name_247 = heff_get_n(v_t_243, 1, 2);
  V v_st_248 = heff_take_field(v_a_240, 0);
  V v_program_249 = heff_get_n(v_a_240, 2, 3);
  V v_t_2410 = heff_dup(heff_rfield(v_target_246, 2));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_247), NTAG(TAG_Nil)});
    V v_c_2412 = (g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673(v_st_248, heff_dup(v_f_241), heff_tag_n(TAG_Just, 1, (V[]){v_t_2411})));
    return heff_tail(v_c_2412, 2, (V[]){v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_lam0, 1, 6, (V[]){v_name_247, v_program_249, v_target_246, v_f_241, v_z_245, v_off_242})});
  }
  case TAG_Just: {
    V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 0ULL, 1);
    heff_drop(v_z_244);
    V v_name_2424 = heff_dup(v_name_247);
    V v_occurrences_2425 = (g_heff_2ebuild_2equery_2eoccurrences(v_program_249, heff_dup(v_target_246), v_name_247));
    V v_target_2426 = heff_tag_at_n(v_ru_24t_2410_24Just, TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_241, v_target_246, v_name_2424, v_occurrences_2425})});
    return heff_tail(v_z_245, 1, (V[]){heff_rec_n(3, shape_st__off__target, (V[]){v_st_248, v_off_242, v_target_2426})});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_name_247 = heff_env(self)[0];
  V v_program_249 = heff_env(self)[1];
  V v_target_246 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_off_242 = heff_env(self)[5];
  V v_program_2414 = heff_take_field(v_x_2413, 1);
  V v_st_2415 = heff_get_n(v_x_2413, 0, 2);
  V v_name_2416 = heff_dup(v_name_247);
  V v_t_2417 = heff_dup(v_program_2414);
  V v_t_2420;
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nil: {
    heff_drop(v_program_2414);
    v_t_2420 = v_program_249;
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2417, 0ULL, 2);
    heff_drop(v_program_249);
    v_t_2420 = v_program_2414;
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  V v_occurrences_2421 = (g_heff_2ebuild_2equery_2eoccurrences(v_t_2420, heff_dup(v_target_246), v_name_247));
  V v_target_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_241, v_target_246, v_name_2416, v_occurrences_2421})});
  V f_ = v_z_245;
  args[0] = heff_rec_n(3, shape_st__off__target, (V[]){v_st_2415, v_off_242, v_target_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = (g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923(v_st_240, heff_dup(v_p_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_lam0, 2, 2, (V[]){v_c_242, v_p_241});
}
V g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    heff_clo_take(self, 4);
    heff_drop(v_p_241);
    heff_drop(v_hd_243);
    V v_t_248 = heff_rec_n(3, shape_st__off__target, (V[]){heff_get_n(v_x_245, 0, 3), MK_INT(0LL), NTAG(TAG_Nothing)});
    V f_ = v_k_244;
    args[0] = v_t_248;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_249 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    V v_program_2410 = heff_dup(heff_rfield(v_x_245, 2));
    V v_off_2411 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_x_245, 1), heff_dup(v_p_241)));
    V v_x1_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_2410)));
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nil: {
      heff_clo_take(self, 4);
      heff_drop(v_p_241);
      heff_drop(v_hd_243);
      heff_drop(v_f_249);
      heff_drop_cell(v_ru_24x_247_24Just, 1);
      heff_drop(v_program_2410);
      heff_drop(v_off_2411);
      V v_t_2413 = heff_rec_n(3, shape_st__off__target, (V[]){heff_get_n(v_x_245, 0, 3), MK_INT(0LL), NTAG(TAG_Nothing)});
      V f_ = v_k_244;
      args[0] = v_t_2413;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 2);
      V v_t_2416 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_x_2414, 4)));
      V v_t_2417 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_2416));
      V v_t_2418 = ({ V a_0 = v_program_2410; V a_1 = v_x_2414; V a_2 = v_t_2417; V a_3 = v_off_2411; V r_ = (g_heff_2ebuild_2equery_2etargetIn(a_0, a_1, a_2, a_3)); heff_drop(v_program_2410); r_; });
      switch (heff_tag_of(v_t_2418)) {
      case TAG_Nothing: {
        heff_clo_take(self, 4);
        heff_drop(v_p_241);
        heff_drop(v_hd_243);
        heff_drop(v_f_249);
        heff_drop_cell(v_ru_24x_247_24Just, 1);
        V v_t_2419 = heff_rec_n(3, shape_st__off__target, (V[]){heff_get_n(v_x_245, 0, 3), MK_INT(0LL), NTAG(TAG_Nothing)});
        V f_ = v_k_244;
        args[0] = v_t_2419;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Just: {
        V v_t_2420 = heff_field(v_t_2418, 0);
        heff_take_n(v_t_2418, 1ULL, 1);
        heff_clo_take(self, 4);
        V v_t_2421 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_x_245, 1), v_p_241));
        return (g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok1(v_ru_24x_247_24Just, v_x_245, v_f_249, v_t_2421, v_t_2420, v_hd_243, v_k_244));
      }
      default: return heff_nomatch(v_t_2418);
      }
    }
    default: return heff_nomatch(v_x1_2412);
    }
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_t_246 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(heff_dup(v_p_241)));
  heff_clo_take(self, 3);
  V f_ = v_t_246;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_lam2, 1, 4, (V[]){v_x_245, v_k_244, v_p_241, v_hd_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_lam1, 1, 3, (V[]){v_p_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_str1, 5, "range");
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam0, 2, 0};
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam2, 1, 0};
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam5(V self, V *args);
Clo g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_entry, 2, 0};

V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    return ((V)&g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_st_246 = heff_dup(v_st_240);
    V v_o_247 = v_o_244;
    V v_path_248 = heff_take_field(v_o_247, 0);
    V v_source_249 = heff_take_field(v_o_247, 1);
    V v_span_2410 = heff_get_n(v_o_247, 2, 4);
    V v_p_2411 = v_path_248;
    HeffT2 v_t_2412 = ({ V b_0 = heff_get_n(v_st_246, 0, 7); V a_1 = v_p_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      V v_c_2423;
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_p_2411);
        V v_d_2415 = v_field_2414;
        v_c_2423 = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam1, 2, 1, (V[]){v_d_2415});
      } else {
        heff_drop(v_field_2414);
        V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_PathUri, 2, (V[]){v_p_2411, ((V)&g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam2_clo)})});
        V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
        V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
        v_c_2423 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})}));
      }
      V v_c_2431 = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam3, 2, 3, (V[]){v_c_2423, v_source_249, v_span_2410});
      return heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam5, 2, 3, (V[]){v_c_2431, v_st_240, v_rest_245});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_d_2415 = heff_env(self)[0];
  heff_drop(v_hd_2416);
  heff_clo_take(self, 1);
  V f_ = v_k_2417;
  args[0] = heff_get_n(v_d_2415, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam2(V self, V *args) {
  V v_u_2418 = args[0];
  return v_u_2418;
}
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_source_249 = heff_env(self)[0];
  V v_span_2410 = heff_env(self)[1];
  V v_k_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2427 = ({ V a_0 = v_source_249; V a_1 = v_span_2410; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_249); r_; });
  V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_str0), heff_tag_n(TAG_JString, 1, (V[]){v_x_2426})});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_str1), v_t_2427}), NTAG(TAG_Nil)});
  V v_x_2430 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2429})});
  V f_ = v_k_2425;
  args[0] = v_x_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam3(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_source_249 = heff_env(self)[1];
  V v_span_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam4, 1, 3, (V[]){v_source_249, v_span_2410, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam7(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_2433 = heff_env(self)[0];
  V v_x_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2433;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2434, v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2432 = heff_env(self)[2];
  V v_k_2433 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2435 = (g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679(v_st_240, v_rest_245));
  V f_ = v_t_2435;
  heff_room[0] = v_hd_2432;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam7, 1, 2, (V[]){v_k_2433, v_x_2434});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam5(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_c_2431 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2431;
  args[0] = heff_dup(v_hd_2432);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_lam6, 1, 4, (V[]){v_st_240, v_rest_245, v_hd_2432, v_k_2433});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str1, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str4, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str5, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str6, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str7, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str8, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str10, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str11, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str12, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str13, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str15, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str16, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str17, 4, "null");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str18, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str19, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str20, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str21, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str22, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str23, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str24, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str25, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str26, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str27, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str28, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str29, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str30, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str31, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str32, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str33, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str34, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str35, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str36, 1, "{");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str37, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str38, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str39, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str40, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str41, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str42, 1, "}");
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_entry, 5, 0};

V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438(V v_id_240, V v_new_241, V v_tg_242, V v_z_243, V v_z_244) {
top: ;
  V v_target_245 = heff_take_field(v_tg_242, 2);
  V v_st_246 = heff_get_n(v_tg_242, 0, 3);
  V v_t_247 = v_target_245;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_new_241);
    V v_t_248 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str0), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str1), MK_INT(0LL)));
    V v_acc_249 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str2)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str3));
    V v_t_2410 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str4), heff_strAppend(v_acc_249, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str5)), MK_INT(0LL)));
    V v_acc_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str6));
    V v_t_2412 = heff_strAppend(heff_strAppend(v_acc_2411, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str7)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str8));
    V v_t_2413 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str9), v_t_2412, MK_INT(0LL)));
    V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str10)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str11));
    V v_acc_2415 = ({ V a_0 = v_t_2414; V a_1 = v_id_240; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_240); r_; });
    V v_t_2416 = heff_strAppend(heff_strAppend(v_acc_2415, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str12)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str13));
    V v_t_2417 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str14), v_t_2416, MK_INT(0LL)));
    V v_acc_2418 = heff_strAppend(heff_strAppend(v_t_2417, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str15)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str16));
    V v_t_2419 = heff_strAppend(heff_strAppend(v_acc_2418, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str17)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str18));
    V v_a_2420 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s535099379x685970669(v_t_2424, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam0, 1, 2, (V[]){v_z_244, v_st_246})));
  }
  case TAG_Just: {
    V v_t_2426 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
    HeffT2 v_t_2427 = (g_heff_2ebuild_2equery_2erenameRefused_24cpr(heff_dup(heff_rfield(v_t_2426, 1)), heff_dup(heff_rfield(v_t_2426, 2)), heff_dup(v_new_241)));
    {
      V v_field_2429 = v_t_2427.f[1];
      int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
      if ((v_tag_2428 == ((int64_t)0ULL))) {
        heff_drop(v_new_241);
        heff_drop_rec(v_t_2426, 4);
        V v_why_2430 = v_field_2429;
        V v_c_2431 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1(v_ru_24t_247_24Just, v_id_240, MK_INT(-32803LL), v_why_2430));
        return heff_tail(v_c_2431, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam1, 1, 2, (V[]){v_z_244, v_st_246})});
      } else {
        heff_drop_cell(v_ru_24t_247_24Just, 1);
        heff_drop(v_field_2429);
        V v_c_2433 = (g_heff_2elsp_2elsp_2erenameChecked_24s2017338171x2088114993(v_st_246, heff_dup(v_t_2426), heff_dup(v_new_241)));
        return heff_tail(v_c_2433, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam2, 1, 5, (V[]){v_t_2426, v_new_241, v_z_243, v_id_240, v_z_244})});
      }
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam0(V self, V *args) {
  V v_x_2425 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  heff_drop(v_x_2425);
  heff_clo_take(self, 2);
  V f_ = v_z_244;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam1(V self, V *args) {
  V v_x_2432 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  heff_drop(v_x_2432);
  heff_clo_take(self, 2);
  V f_ = v_z_244;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam3(V self, V *args) {
  V v_p_2444 = args[0];
  V v_os_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2445 = (g_list_2ekeepIf_24s304198972x561714839(v_p_2444, v_os_2441));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2444, v_os_2445});
}
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam5(V self, V *args) {
  V v_x_2469 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_drop(v_x_2469);
  V v_t_2472;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2434)) {
  case TAG_MkPair: {
    V v_x_2470 = heff_field(v_x_2434, 0);
    heff_take_n(v_x_2434, 1ULL, 2);
    v_t_2472 = v_x_2470;
    break;
  }
  default: heff_nomatch(v_x_2434);
  }
  V f_ = v_z_244;
  args[0] = v_t_2472;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam4(V self, V *args) {
  V v_x_2447 = args[0];
  V v_id_240 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_t_2448 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str19), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str20), MK_INT(0LL)));
  V v_acc_2449 = heff_strAppend(heff_strAppend(v_t_2448, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str21)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str22));
  V v_t_2450 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str23), heff_strAppend(v_acc_2449, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str24)), MK_INT(0LL)));
  V v_acc_2451 = heff_strAppend(v_t_2450, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str25));
  V v_t_2452 = heff_strAppend(heff_strAppend(v_acc_2451, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str26)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str27));
  V v_t_2453 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str28), v_t_2452, MK_INT(0LL)));
  V v_t_2454 = heff_strAppend(heff_strAppend(v_t_2453, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str29)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str30));
  heff_clo_take(self, 4);
  V v_acc_2455 = ({ V a_0 = v_t_2454; V a_1 = v_id_240; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_240); r_; });
  V v_t_2456 = heff_strAppend(heff_strAppend(v_acc_2455, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str31)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str32));
  V v_t_2457 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str33), v_t_2456, MK_INT(0LL)));
  V v_acc_2458 = heff_strAppend(heff_strAppend(v_t_2457, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str34)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str35));
  V v_t_2459 = heff_strAppend(heff_strAppend(v_acc_2458, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str36)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str37));
  V v_t_2460 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str38), v_t_2459, MK_INT(0LL)));
  V v_t_2461 = heff_strAppend(heff_strAppend(v_t_2460, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str39)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str40));
  V v_acc_2462 = ({ V a_0 = v_t_2461; V b_1 = heff_tag_n(TAG_JObject, 1, (V[]){v_x_2447}); V r_ = (g_json_2estringify_2ewriteInto_240(a_0, b_1)); heff_drop(b_1); r_; });
  V v_acc_2463 = heff_strAppend(v_acc_2462, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str41));
  V v_a_2464 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_acc_2463, ((V)&g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_str42)), NTAG(TAG_MkUnit)});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})});
  return (g_co_2eop_24s535099379x685970669(v_t_2468, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam5, 1, 2, (V[]){v_x_2434, v_z_244})));
}
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam6(V self, V *args) {
  V v_x_2475 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_drop(v_x_2475);
  V v_t_2478;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2434)) {
  case TAG_MkPair: {
    V v_x_2476 = heff_field(v_x_2434, 0);
    heff_take_n(v_x_2434, 1ULL, 2);
    v_t_2478 = v_x_2476;
    break;
  }
  default: heff_nomatch(v_x_2434);
  }
  V f_ = v_z_244;
  args[0] = v_t_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam2(V self, V *args) {
  V v_x_2434 = args[0];
  V v_t_2426 = heff_env(self)[0];
  V v_new_241 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_id_240 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_t_2437;
  switch (heff_tag_of(v_x_2434)) {
  case TAG_MkPair: {
    V v_y_2436 = heff_dup(heff_field(v_x_2434, 1));
    v_t_2437 = v_y_2436;
    break;
  }
  default: heff_nomatch(v_x_2434);
  }
  switch (heff_tag_of(v_t_2437)) {
  case TAG_Nothing: {
    V v_t_2440;
    switch (heff_tag_of(v_x_2434)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_dup(heff_field(v_x_2434, 0));
      v_t_2440 = v_x_2438;
      break;
    }
    default: heff_nomatch(v_x_2434);
    }
    heff_clo_take(self, 5);
    V v_os_2441 = heff_get_n(v_t_2426, 3, 4);
    V v_t_2442 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2441)));
    V v_t_2443 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2442));
    V v_t_2446 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam3, 1, 1, (V[]){v_os_2441}), v_t_2443));
    return (g_heff_2elsp_2elsp_2echangesOf_24s644374086x1264715741(v_t_2440, v_new_241, v_t_2446, heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam4, 1, 4, (V[]){v_id_240, v_z_243, v_x_2434, v_z_244})));
  }
  case TAG_Just: {
    V v_why_2473 = heff_field(v_t_2437, 0);
    V v_ru_24t_2437_24Just = heff_take_reuse_n(v_t_2437, 1ULL, 1);
    heff_clo_take(self, 5);
    heff_drop_rec(v_t_2426, 4);
    heff_drop(v_new_241);
    V v_t_2474 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1(v_ru_24t_2437_24Just, v_id_240, MK_INT(-32803LL), v_why_2473));
    V f_ = v_t_2474;
    heff_room[0] = v_z_243;
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_lam6, 1, 2, (V[]){v_x_2434, v_z_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2437);
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_str0, 10, "package.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_str1, 11, "/package.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_str2, 8, "build.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_str3, 9, "/build.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_str4, 7, "module ");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_str5, 1, "\012");
V g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_entry, 4, 0};

V g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739(V v_st_240, V v_f_241, V v_z_242, V v_z_243) {
top: ;
  if ((heff_strEq_c_lent(v_f_241, ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_str0), 2) || ({ int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)11ULL)); int c_ = ({ V v_t_2420 = heff_strSlice_lent(v_f_241, heff_box_word(v_t_244), heff_strLength_lent(v_f_241, 0), 6); int c_ = (heff_strEq_c_lent(v_t_2420, ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_str1), 2) || (heff_strEq_c_lent(v_f_241, ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_str2), 2) || ({ int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)9ULL)); int c_ = ({ V v_t_2421 = heff_strSlice_lent(v_f_241, heff_box_word(v_t_245), heff_strLength_lent(v_f_241, 0), 6); int c_ = heff_strEq_c_lent(v_t_2421, ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_str3), 2); heff_drop(v_t_2421); c_; }); c_; }))); heff_drop(v_t_2420); c_; }); c_; }))) {
    heff_drop_rec(v_st_240, 7);
    heff_drop(v_f_241);
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_Nothing)});
  } else {
    V v_c_246 = (g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(heff_get_n(v_st_240, 6, 7), heff_dup(v_f_241)));
    return heff_tail(v_c_246, 2, (V[]){v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_lam0, 1, 2, (V[]){v_f_241, v_z_243})});
  }
}
V g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_n_248 = (g_heff_2ebuild_2eload_2emoduleOf(v_x_247, v_f_241));
  V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_str4), heff_dup(v_n_248)), ((V)&g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_str5));
  V v_t_2410 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_t_249, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_x2_2411 = heff_get_n(v_t_2410, 2, 4);
  V v_x_2419;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nothing: {
    heff_drop(v_n_248);
    v_x_2419 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_h_2412 = heff_field(v_x2_2411, 0);
    V v_ru_24x2_2411_24Just = heff_take_reuse_n(v_x2_2411, 1ULL, 1);
    V v_name_2413 = heff_take_field(v_h_2412, 0);
    V v_error_2414 = heff_get_n(v_h_2412, 4, 5);
    V v_t_2415 = v_name_2413;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      heff_drop(v_n_248);
      heff_drop_cell(v_ru_24x2_2411_24Just, 1);
      heff_drop(v_error_2414);
      v_x_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_m_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      V v_t_2417 = v_error_2414;
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Nothing: {
        if (heff_strEq_c_lent(v_m_2416, v_n_248, 1)) {
          v_x_2419 = heff_tag_at_n(v_ru_24x2_2411_24Just, TAG_Just, 1, (V[]){v_n_248});
        } else {
          heff_drop(v_n_248);
          heff_drop_cell(v_ru_24x2_2411_24Just, 1);
          v_x_2419 = NTAG(TAG_Nothing);
        }
        break;
      }
      case TAG_Just: {
        heff_take_n(v_t_2417, 0ULL, 1);
        heff_drop(v_n_248);
        heff_drop_cell(v_ru_24x2_2411_24Just, 1);
        heff_drop(v_m_2416);
        v_x_2419 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V f_ = v_z_243;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok1_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok1_entry, 7, 0};

V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok1(V v_tok_240, V v_a_241, V v_f_242, V v_off_243, V v_t_244, V v_z_245, V v_z_246) {
top: ;
  V v_target_247 = heff_take_field(v_t_244, 0);
  V v_name_248 = heff_get_n(v_t_244, 1, 2);
  V v_st_249 = heff_take_field(v_a_241, 0);
  V v_program_2410 = heff_get_n(v_a_241, 2, 3);
  V v_t_2411 = heff_dup(heff_rfield(v_target_247, 2));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_248), NTAG(TAG_Nil)});
    V v_c_2413 = (g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673(v_st_249, heff_dup(v_f_242), heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_t_2412})));
    return heff_tail(v_c_2413, 2, (V[]){v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok1_lam0, 1, 6, (V[]){v_name_248, v_program_2410, v_target_247, v_f_242, v_z_246, v_off_243})});
  }
  case TAG_Just: {
    heff_take_n(v_t_2411, 0ULL, 1);
    heff_drop(v_z_245);
    V v_name_2425 = heff_dup(v_name_248);
    V v_occurrences_2426 = (g_heff_2ebuild_2equery_2eoccurrences(v_program_2410, heff_dup(v_target_247), v_name_248));
    V v_target_2427 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_242, v_target_247, v_name_2425, v_occurrences_2426})});
    return heff_tail(v_z_246, 1, (V[]){heff_rec_n(3, shape_st__off__target, (V[]){v_st_249, v_off_243, v_target_2427})});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok1(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok1_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_name_248 = heff_env(self)[0];
  V v_program_2410 = heff_env(self)[1];
  V v_target_247 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_off_243 = heff_env(self)[5];
  V v_program_2415 = heff_take_field(v_x_2414, 1);
  V v_st_2416 = heff_get_n(v_x_2414, 0, 2);
  V v_name_2417 = heff_dup(v_name_248);
  V v_t_2418 = heff_dup(v_program_2415);
  V v_t_2421;
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_t_2418)) {
  case TAG_Nil: {
    heff_drop(v_program_2415);
    v_t_2421 = v_program_2410;
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2418, 0ULL, 2);
    heff_drop(v_program_2410);
    v_t_2421 = v_program_2415;
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V v_occurrences_2422 = (g_heff_2ebuild_2equery_2eoccurrences(v_t_2421, heff_dup(v_target_247), v_name_248));
  V v_target_2423 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_242, v_target_247, v_name_2417, v_occurrences_2422})});
  V f_ = v_z_246;
  args[0] = heff_rec_n(3, shape_st__off__target, (V[]){v_st_2416, v_off_243, v_target_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}