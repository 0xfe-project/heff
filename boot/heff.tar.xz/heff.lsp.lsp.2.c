// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_ProjectFiles 9175
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Send 26077
#define LBL_analysis 1868176469
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_code 9554612
#define LBL_current 1358797751
#define LBL_cut 308412
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_equals 651658986
#define LBL_imports 10411951
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_severity 75955546
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_watch 314261737
static uint32_t shape_analysis__at[] = {LBL_analysis, LBL_at};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_program__kept[] = {LBL_program, LBL_kept};
static uint32_t shape_root__names__program__current__kept[] = {LBL_root, LBL_names, LBL_program, LBL_current, LBL_kept};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2edriver_2eelabNext(V, V, V);
V g_heff_2ebuild_2edriver_2eelabNext_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNext_clo;
V g_heff_2ebuild_2edriver_2etraceless(V);
V g_heff_2ebuild_2edriver_2etraceless_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etraceless_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(V, V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
V g_heff_2ebuild_2equery_2edefinitionAt(V, V);
V g_heff_2ebuild_2equery_2edefinitionAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionAt_clo;
V g_heff_2ebuild_2equery_2edocMarkdownIn(V, V);
V g_heff_2ebuild_2equery_2edocMarkdownIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMarkdownIn_clo;
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2equery_2etargetIn(V, V, V, V);
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etargetIn_clo;
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524(V, V, V, V, V, V, V);
V g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_clo;
V g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747(V, V, V, V, V);
V g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL(V);
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(V, V);
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_clo;
V g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051(V, V, V, V);
V g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_clo;
V g_heff_2elsp_2elsp_2ehoverOf(V, V);
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981(V, V, V, V);
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_clo;
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445(V, V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574(V, V, V, V);
V g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574_clo;
V g_heff_2elsp_2elsp_2enamedIn(V);
V g_heff_2elsp_2elsp_2enamedIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enamedIn_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085(V, V, V);
V g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_clo;
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1_clo;
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok2(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok2_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok2_clo;
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_clo;
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_clo;
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900(V, V, V, V);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_clo;
V g_heff_2elsp_2elsp_2eundue(V, V);
V g_heff_2elsp_2elsp_2eundue_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eundue_clo;
V g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680(V, V, V);
V g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_clo;
V g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953(V, V, V);
V g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(V, V, V);
V g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_entry(V self, V *a);
extern Clo g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_clo;
V g_json_2equotedInto_2eescapeInto_241(V, V, V);
V g_json_2equotedInto_2eescapeInto_241_entry(V self, V *a);
extern Clo g_json_2equotedInto_2eescapeInto_241_clo;
V g_list_2eany_24s1027174601x1571638094(V, V, V, V);
V g_list_2eany_24s1027174601x1571638094_entry(V self, V *a);
extern Clo g_list_2eany_24s1027174601x1571638094_clo;
V g_list_2eany_24s1399422749x931279364(V, V);
V g_list_2eany_24s1399422749x931279364_entry(V self, V *a);
extern Clo g_list_2eany_24s1399422749x931279364_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s1424316379x433407702_24cpr(V, V, V, V, V, V);
HeffT2 g_list_2efind_24s792771115x178990339_24cpr(V, V);
V g_list_2efoldl_24f2094160282x1876485468(V, V, V);
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2094160282x1876485468_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1161549307x1906011635(V);
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1533895818x411093629(V);
V g_list_2emap_24s1533895818x411093629_entry(V self, V *a);
extern Clo g_list_2emap_24s1533895818x411093629_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str1, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str2, 7, "module ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str3, 2, " (");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str4, 22, ") does not elaborate: ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str6, 1, "s");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str7, 6, " error");
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ediagsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagsOf_entry, 3, 0};

V g_heff_2elsp_2elsp_2ediagsOf(V v_src_240, V v_program_241, V v_errors_242) {
top: ;
  V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_241)));
  V v_t_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    v_t_246 = heff_get_n(v_x_244, 6, 14);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam0, 1, 1, (V[]){heff_dup(v_src_240)}), v_errors_242));
  V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_241));
  V v_xs_2417 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2416; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2416); r_; });
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2417));
  V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam1, 1, 1, (V[]){v_src_240}), v_t_2418));
  V v_t_2441 = (g_heff_2elsp_2elsp_2ecatMaybesL(v_t_2440));
  V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2441));
  return (g_prelude_2e_2b_2b(v_t_246, v_t_2442));
}
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ediagsOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_imports_249 = heff_get_n(v_t_248, 0, 4);
  HeffT2 v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str0); V a_2 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str1); V a_3 = v_e_247; V b_4 = MK_INT(0LL); V a_5 = v_imports_249; HeffT2 r_ = (g_list_2efind_24s1424316379x433407702_24cpr(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(b_4); heff_drop(v_imports_249); r_; });
  V v_sp_2414;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_i_2413 = v_field_2412;
      v_sp_2414 = heff_get_n(v_i_2413, 2, 3);
    } else {
      heff_drop(v_field_2412);
      v_sp_2414 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
    }
  }
  return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_e_247, v_sp_2414, NTAG(TAG_Nothing)});
}
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args) {
  V v_c_2419 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_imports_2421 = heff_get_n(v_t_2420, 0, 4);
  V v_c_2422 = v_c_2419;
  V v_x1_2423 = (g_list_2ekeepIf_24s1161549307x1906011635(heff_dup(heff_rfield(v_c_2422, 6))));
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_Nil: {
    heff_drop(v_imports_2421);
    heff_drop_rec(v_c_2422, 14);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2423, 0ULL, 2);
    V v_t_2426 = (g_list_2eany_24s1399422749x931279364(heff_dup(v_c_2422), v_imports_2421));
    if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
      heff_drop(v_t_2426);
      HeffT2 v_t_2427 = ({ V a_0 = heff_rfield(v_c_2422, 0); V a_1 = v_imports_2421; HeffT2 r_ = (g_list_2efind_24s792771115x178990339_24cpr(a_0, a_1)); heff_drop(v_imports_2421); r_; });
      V v_sp_2431;
      {
        V v_field_2429 = v_t_2427.f[1];
        int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
        if ((v_tag_2428 == ((int64_t)0ULL))) {
          V v_i_2430 = v_field_2429;
          v_sp_2431 = heff_get_n(v_i_2430, 2, 3);
        } else {
          heff_drop(v_field_2429);
          v_sp_2431 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
        }
      }
      V v_t_2432 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ediagsOf_str2), heff_take_field(v_c_2422, 0));
      V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2elsp_2elsp_2ediagsOf_str3)), heff_take_field(v_c_2422, 1));
      V v_t_2434 = (g_list_2efoldl_24f2094160282x1876485468(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_2422, 6)));
      V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2433, ((V)&g_heff_2elsp_2elsp_2ediagsOf_str4)), heff_intShow(v_t_2434));
      V v_t_2436 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_c_2422, 6, 14); V r_ = (g_list_2efoldl_24f2094160282x1876485468(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2437;
      if (heff_intEq_c(v_t_2436, MK_INT(1LL))) {
        v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str5);
      } else {
        v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str6);
      }
      V v_msg_2438 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2elsp_2elsp_2ediagsOf_str7)), v_t_2437);
      V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SWarning), v_msg_2438, v_sp_2431, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2439});
    } else {
      heff_drop(v_imports_2421);
      heff_drop_rec(v_c_2422, 14);
      heff_drop(v_t_2426);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_x1_2423);
  }
}
Clo g_heff_2elsp_2elsp_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeptOf_entry, 1, 0};

V g_heff_2elsp_2elsp_2ekeptOf(V v_program_240) {
top: ;
  V v_x1_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_240)));
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_program_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
    V v_xs_245 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_244; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_244); r_; });
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
    V v_t_247 = (g_list_2emap_24s1533895818x411093629(v_t_246));
    V v_t_248 = (g_heff_2ebuild_2edriver_2etraceless(v_x_242));
    V v_t_249 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return (g_prelude_2e_2b_2b(v_t_247, v_t_249));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ekeptOf(a[0]);
}
Clo g_heff_2elsp_2elsp_2enamedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enamedIn_entry, 1, 0};

V g_heff_2elsp_2elsp_2enamedIn(V v_l_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2elsp_2elsp_2enamedIn_24cpr(v_l_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_start__end, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2elsp_2elsp_2enamedIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2enamedIn(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str0, 3, " : ");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str1, 10, "   (local)");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str2, 11, "   (global)");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str3, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str4, 8, "markdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str6, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str7, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str8, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str9, 4, "\012```");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str10, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str11, 11, "\012```\012\012---\012\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str12, 5, "value");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str13, 8, "contents");
Clo g_heff_2elsp_2elsp_2ehoverOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehoverOf_entry, 2, 0};

V g_heff_2elsp_2elsp_2ehoverOf(V v_a_240, V v_p_241) {
top: ;
  V v_program_242 = heff_take_field(v_a_240, 2);
  V v_text_243 = heff_get_n(v_a_240, 1, 3);
  V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_242)));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    heff_drop(v_program_242);
    heff_drop(v_text_243);
    return NTAG(TAG_JNull);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Cons = heff_take_reuse_n(v_x1_244, 1ULL, 2);
    V v_off_247 = (g_heff_2elsp_2elsp_2eoffsetIn(v_text_243, heff_dup(v_p_241)));
    HeffT2 v_t_248 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_x_245, v_off_247));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_i_2411 = v_field_2410;
        V v_name_2412 = heff_take_field(v_i_2411, 1);
        V v_ty_2413 = heff_take_field(v_i_2411, 4);
        V v_key_2414 = heff_get_n(v_i_2411, 2, 5);
        V v_t_2415 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_name_2412));
        V v_t_2416 = heff_tr(heff_call(v_ty_2413, 1, (V[]){NTAG(TAG_MkUnit)}));
        V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2elsp_2elsp_2ehoverOf_str0)), v_t_2416);
        V v_t_2419;
        switch (heff_tag_of(v_key_2414)) {
        case TAG_Nothing: {
          v_t_2419 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str1);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_key_2414, 0ULL, 1);
          v_t_2419 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str2);
          break;
        }
        default: heff_nomatch(v_key_2414);
        }
        V v_t_2420 = heff_strAppend(v_t_2417, v_t_2419);
        V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str3), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str4)})});
        V v_program_2422 = v_program_242;
        V v_off_2423 = ({ V a_0 = v_text_243; V a_1 = v_p_241; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(a_0, a_1)); heff_drop(v_text_243); r_; });
        V v_t_2424 = (g_heff_2ebuild_2equery_2edefinitionAt(v_program_2422, v_off_2423));
        V v_doc_2433;
        switch (heff_tag_of(v_t_2424)) {
        case TAG_Nothing: {
          v_doc_2433 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str5);
          break;
        }
        case TAG_Just: {
          V v_d_2425 = heff_field(v_t_2424, 0);
          heff_take_n(v_t_2424, 1ULL, 1);
          V v_source_2426 = heff_take_field(v_d_2425, 1);
          V v_span_2427 = heff_get_n(v_d_2425, 2, 3);
          V v_src_2428 = heff_dup(v_source_2426);
          V v_start_2429 = ({ V a_0 = v_source_2426; V a_1 = heff_get_n(v_span_2427, 0, 2); V r_ = (g_heff_2ebuild_2equery_2elineStartOf(a_0, a_1)); heff_drop(v_source_2426); r_; });
          V v_t_2430 = ({ V a_0 = v_src_2428; V a_1 = v_start_2429; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ecommentAbove(a_0, a_1, a_2)); heff_drop(v_src_2428); r_; });
          V v_t_2431 = (g_list_2emap_24s1819241345x1511673126(v_t_2430));
          V v_ls_2432 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2431));
          v_doc_2433 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str6); V a_1 = v_ls_2432; V r_ = (g_heff_2ebuild_2equery_2edocMarkdownIn(a_0, a_1)); heff_drop(v_ls_2432); r_; });
          break;
        }
        default: heff_nomatch(v_t_2424);
        }
        V v_t_2435;
        if (heff_strEq_c_lent(v_doc_2433, ((V)&g_heff_2elsp_2elsp_2ehoverOf_str7), 2)) {
          heff_drop(v_doc_2433);
          v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str8), v_t_2420), ((V)&g_heff_2elsp_2elsp_2ehoverOf_str9));
        } else {
          V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str10), v_t_2420), ((V)&g_heff_2elsp_2elsp_2ehoverOf_str11));
          v_t_2435 = heff_strAppend(v_t_2434, v_doc_2433);
        }
        V v_t_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str12), heff_tag_n(TAG_JString, 1, (V[]){v_t_2435})});
        V v_t_2437 = heff_tag_at_n(v_ru_24x1_244_24Cons, TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
        V v_t_2438 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2437})});
        V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str13), v_t_2438}), NTAG(TAG_Nil)});
        return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2439});
      } else {
        heff_drop(v_p_241);
        heff_drop(v_program_242);
        heff_drop(v_text_243);
        heff_drop_cell(v_ru_24x1_244_24Cons, 2);
        heff_drop(v_field_2410);
        return NTAG(TAG_JNull);
      }
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehoverOf(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2eundue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eundue_entry, 2, 0};

V g_heff_2elsp_2elsp_2eundue(V v_due_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_due_240;
  }
  case TAG_Cons: {
    V v_f_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(v_due_240, v_f_242));
    V t_0 = v_t_244;
    V t_1 = v_rest_243;
    v_due_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2eundue_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eundue(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_str0, 20, "textDocument/didSave");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_str1, 20, "textDocument/didOpen");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_str2, 4, "text");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_str3, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_str4, 21, "textDocument/didClose");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_str5, 13, "textDocument/");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_str6, 31, "workspace/didChangeWatchedFiles");
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam0, 2, 0};
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam5(V self, V *args);
Clo g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_entry, 4, 0};

V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981(V v_e_240, V v_st_241, V v_m_242, V v_p_243) {
top: ;
  if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_str0), 2)) {
    heff_drop(v_e_240);
    heff_drop_rec(v_st_241, 7);
    heff_drop(v_p_243);
    return ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam0_clo);
  } else {
    if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_str1), 2)) {
      heff_drop_rec(v_st_241, 7);
      V v_c_246 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(heff_dup(v_e_240), heff_dup(v_p_243)));
      return heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam1, 2, 3, (V[]){v_c_246, v_p_243, v_e_240});
    } else {
      if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_str4), 2)) {
        V v_c_2422 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(heff_dup(v_e_240), v_p_243));
        return heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam3, 2, 3, (V[]){v_c_2422, v_st_241, v_e_240});
      } else {
        heff_drop(v_e_240);
        heff_drop_rec(v_st_241, 7);
        heff_drop(v_p_243);
        return heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam5, 2, 1, (V[]){heff_dup(v_m_242)});
      }
    }
  }
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_str2), NTAG(TAG_Nil)});
  HeffT2 v_t_2411 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_str3), v_t_2410}); V a_1 = v_p_243; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2421;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_it1_2414 = v_field_2413;
      switch (heff_tag_of(v_it1_2414)) {
      case TAG_JNull: {
        v_t_2421 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2414, 0ULL, 1);
        v_t_2421 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2414, 0ULL, 1);
        v_t_2421 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2414, 0ULL, 1);
        v_t_2421 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        V v_s_2418 = heff_field(v_it1_2414, 0);
        V v_ru_24it1_2414_24JString = heff_take_reuse_n(v_it1_2414, 1ULL, 1);
        v_t_2421 = heff_tag_at_n(v_ru_24it1_2414_24JString, TAG_Just, 1, (V[]){v_s_2418});
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_2414, 0ULL, 1);
        v_t_2421 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2414, 0ULL, 1);
        v_t_2421 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_2414);
      }
    } else {
      heff_drop(v_field_2413);
      v_t_2421 = NTAG(TAG_Nothing);
    }
  }
  return (g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747(v_e_240, v_x_249, v_t_2421, v_hd_247, v_k_248));
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam2, 1, 4, (V[]){v_p_243, v_e_240, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2423 = heff_env(self)[2];
  V v_k_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2431;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Nothing: {
    heff_drop_rec(v_st_241, 7);
    v_t_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_f_2426 = heff_dup(heff_field(v_x_2425, 0));
    HeffT2 v_t_2427 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_f_2426; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_f_2426); r_; });
    {
      V v_field_2429 = v_t_2427.f[1];
      int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
      if ((v_tag_2428 == ((int64_t)0ULL))) {
        V v_d_2430 = v_field_2429;
        v_t_2431 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2430, 1, 2)});
      } else {
        heff_drop(v_field_2429);
        v_t_2431 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  return (g_heff_2elsp_2elsp_2easOnDisk_24s1215192981x1556249747(v_e_240, v_x_2425, v_t_2431, v_hd_2423, v_k_2424));
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam3(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam4, 1, 4, (V[]){v_st_241, v_e_240, v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_lam5(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2432);
  V v_t_2434 = heff_bool((heff_strEq_c(heff_strSlice_lent(v_m_242, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_str5)) ? 0 : !heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s528342271x1120757981_str6), 2)));
  heff_drop(v_m_242);
  V f_ = v_k_2433;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam4, 1, 0};
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_entry, 8, 0};

V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845(V v_e_240, V v_st_241, V v_f_242, V v_d_243, V v_ds_244, V v_lo_245, V v_hi_246, V v_a_247) {
top: ;
  if (heff_intLe_c(heff_intSub(heff_dup(v_hi_246), heff_dup(v_lo_245)), MK_INT(1LL))) {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    heff_drop(v_f_242);
    heff_drop_rec(v_d_243, 2);
    heff_drop(v_hi_246);
    HeffT3 v_t_248 = (g_list_2edrop_24cpr(v_lo_245, v_ds_244));
    {
      V v_field_2410 = v_t_248.f[1];
      V v_field_2411 = v_t_248.f[2];
      V v_tag_249 = heff_box_i64(((int64_t)v_t_248.f[0]));
      return heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam0, 2, 4, (V[]){v_tag_249, v_field_2410, v_field_2411, v_a_247});
    }
  } else {
    return heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam1, 2, 8, (V[]){v_lo_245, v_hi_246, heff_dup(v_ds_244), v_d_243, v_e_240, v_st_241, v_f_242, v_a_247});
  }
}
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7]); heff_drop(a4); return r;
}
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_tag_249 = heff_env(self)[0];
  V v_field_2410 = heff_env(self)[1];
  V v_field_2411 = heff_env(self)[2];
  V v_a_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_hd_2412);
  V v_t_2416;
  if ((heff_unbox_i64(v_tag_249) == ((int64_t)0ULL))) {
    V v_x_2414 = v_field_2410;
    V v_x12_2415 = v_field_2411;
    heff_drop(v_x12_2415);
    v_t_2416 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2414});
  } else {
    heff_drop(v_field_2410);
    heff_drop(v_field_2411);
    v_t_2416 = NTAG(TAG_Nothing);
  }
  V f_ = v_k_2413;
  args[0] = heff_rec_n(2, shape_analysis__at, (V[]){v_a_247, v_t_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_lo_245 = heff_env(self)[0];
  V v_hi_246 = heff_env(self)[1];
  V v_ds_244 = heff_env(self)[2];
  V v_d_243 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_f_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2422 = heff_intDiv(heff_intAdd(v_lo_245, v_hi_246), MK_INT(2LL));
  HeffT3 v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = v_ds_244; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_ds_244); r_; });
  V v_t_2429;
  {
    V v_field_2425 = v_t_2423.f[1];
    V v_field_2426 = v_t_2423.f[2];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    if ((v_tag_2424 == ((int64_t)0ULL))) {
      V v_x_2427 = v_field_2425;
      V v_x12_2428 = v_field_2426;
      heff_drop(v_x12_2428);
      v_t_2429 = heff_get_n(v_x_2427, 0, 2);
    } else {
      heff_drop(v_field_2425);
      heff_drop(v_field_2426);
      v_t_2429 = heff_strLength(heff_dup(heff_rfield(v_d_243, 1)));
    }
  }
  return ({ V a_0 = v_e_240; V a_1 = v_st_241; V a_2 = v_f_242; V a_3 = v_d_243; V a_4 = v_t_2429; V a_5 = v_hd_2420; V a_6 = v_k_2421; V r_ = (g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2429); r_; });
}
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam4(V self, V *args) {
  V v_r_2430 = args[0];
  return v_r_2430;
}
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam2(V self, V *args) {
  V v_use_2419 = args[0];
  V v_lo_245 = heff_env(self)[0];
  V v_hi_246 = heff_env(self)[1];
  V v_ds_244 = heff_env(self)[2];
  V v_d_243 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_f_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_use_2419;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam3, 2, 7, (V[]){v_lo_245, v_hi_246, v_ds_244, v_d_243, v_e_240, v_st_241, v_f_242});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam4_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_lo_245 = heff_env(self)[0];
  V v_hi_246 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_d_243 = heff_env(self)[5];
  V v_ds_244 = heff_env(self)[6];
  V v_a_247 = heff_env(self)[7];
  V v_hd_2417 = heff_env(self)[8];
  V v_k_2418 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Left: {
    heff_take_n(v_x_2436, 0ULL, 1);
    V v_t_2438 = heff_intDiv(heff_intAdd(heff_dup(v_lo_245), v_hi_246), MK_INT(2LL));
    V v_t_2439 = ({ V a_0 = v_e_240; V a_1 = v_st_241; V a_2 = v_f_242; V a_3 = v_d_243; V a_4 = v_ds_244; V a_5 = v_lo_245; V a_6 = v_t_2438; V a_7 = v_a_247; V r_ = (g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_ds_244); r_; });
    V f_ = v_t_2439;
    heff_room[0] = v_hd_2417;
    heff_room[1] = v_k_2418;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2440 = heff_field(v_x_2436, 0);
    heff_take_n(v_x_2436, 1ULL, 1);
    heff_drop(v_a_247);
    V v_t_2441 = heff_intDiv(heff_intAdd(v_lo_245, heff_dup(v_hi_246)), MK_INT(2LL));
    V v_t_2442 = ({ V a_0 = v_e_240; V a_1 = v_st_241; V a_2 = v_f_242; V a_3 = v_d_243; V a_4 = v_ds_244; V a_5 = v_t_2441; V a_6 = v_hi_246; V a_7 = v_y_2440; V r_ = (g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_ds_244); r_; });
    V f_ = v_t_2442;
    heff_room[0] = v_hd_2417;
    heff_room[1] = v_k_2418;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2436);
  }
}
V g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_lo_245 = heff_env(self)[0];
  V v_hi_246 = heff_env(self)[1];
  V v_ds_244 = heff_env(self)[2];
  V v_d_243 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_f_242 = heff_env(self)[6];
  V v_a_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam2, 1, 7, (V[]){heff_dup(v_lo_245), heff_dup(v_hi_246), heff_dup(v_ds_244), heff_dup(v_d_243), heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_f_242)})})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_hd_2417), heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s396356375x666629845_lam5, 1, 10, (V[]){v_lo_245, v_hi_246, v_e_240, v_st_241, v_f_242, v_d_243, v_ds_244, v_a_247, v_hd_2417, v_k_2418})));
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str1, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str4, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str5, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str6, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str7, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str8, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str9, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str10, 1, "}");
Clo g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_entry, 3, 0};

V g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085(V v_e_240, V v_method_241, V v_params_242) {
top: ;
  V v_t_243 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str0), ((V)&g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str1), MK_INT(0LL)));
  V v_acc_244 = heff_strAppend(heff_strAppend(v_t_243, ((V)&g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str2)), ((V)&g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str3));
  V v_t_245 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str4), heff_strAppend(v_acc_244, ((V)&g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str5)), MK_INT(0LL)));
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str6), heff_tag_n(TAG_JString, 1, (V[]){v_method_241})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str7), v_params_242}), NTAG(TAG_Nil)});
  V v_t_248 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str8); V a_1 = heff_strAppend(v_t_245, ((V)&g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str9)); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_247}); V r_ = (g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_a_249 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_248, ((V)&g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_str10)), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_e_240, v_t_2414});
}
V g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enotify_24s1831673837x147651085(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam2, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam8(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam8, 3, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam14(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam14, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam15(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_entry, 7, 0};

V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827(V v_e_240, V v_st_241, V v_root_242, V v_f_243, V v_names_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam0, 1, 5, (V[]){heff_dup(v_root_242), heff_dup(v_e_240), heff_dup(v_names_244), heff_dup(v_st_241), v_f_243})})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), v_hd_245, heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam15, 1, 4, (V[]){v_st_241, v_root_242, v_names_244, v_k_246})));
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam2(V self, V *args) {
  V v_fs_2410 = args[0];
  return v_fs_2410;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam7(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_d_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2436);
  V v_t_2438 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2435, 1, 2)});
  V f_ = v_k_2437;
  args[0] = v_t_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam8(V self, V *args) {
  V v_x_2442 = args[0];
  V v_hd_2443 = args[1];
  V v_k_2444 = args[2];
  heff_drop(v_hd_2443);
  V f_ = v_k_2444;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2442});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam10(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451;
  switch (heff_tag_of(v_x_2448)) {
  case TAG_Left: {
    heff_take_n(v_x_2448, 0ULL, 1);
    v_t_2451 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2450 = heff_field(v_x_2448, 0);
    V v_ru_24x_2448_24Right = heff_take_reuse_n(v_x_2448, 1ULL, 1);
    v_t_2451 = heff_tag_at_n(v_ru_24x_2448_24Right, TAG_Just, 1, (V[]){v_y_2450});
    break;
  }
  default: heff_nomatch(v_x_2448);
  }
  V f_ = v_k_2447;
  args[0] = v_t_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam9(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2445;
  args[0] = v_hd_2446;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam10, 1, 1, (V[]){v_k_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam6(V self, V *args) {
  V v_p_2431 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2432 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_p_2431; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2434 = v_t_2432.f[1];
    int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
    if ((v_tag_2433 == ((int64_t)0ULL))) {
      heff_drop(v_p_2431);
      heff_drop(v_e_240);
      V v_d_2435 = v_field_2434;
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam7, 2, 1, (V[]){v_d_2435});
    } else {
      heff_drop(v_field_2434);
      V v_path_2439 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_p_2431));
      V v_c_2440 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2439; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2439); r_; });
      V v_t_2441 = (g_exception_2eattempted(v_e_240));
      V v_c_2445 = heff_tr(heff_call(v_c_2440, 2, (V[]){v_t_2441, ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam8_clo)}));
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam9, 2, 1, (V[]){v_c_2445});
    }
  }
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam13(V self, V *args) {
  V v_s_2457 = args[0];
  V v_names_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_names_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_2457, 8);
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    V v_names_2458 = heff_field(v_names_244, 0);
    heff_take_n(v_names_244, 1ULL, 1);
    return ({ V a_0 = MK_INT(0LL); V b_1 = heff_get_n(v_s_2457, 4, 8); V b_2 = MK_INT(0LL); V a_3 = v_names_2458; V r_ = (g_list_2eany_24s1027174601x1571638094(a_0, b_1, b_2, a_3)); heff_drop(b_1); heff_drop(b_2); heff_drop(v_names_2458); r_; });
  }
  default: return heff_nomatch(v_names_244);
  }
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam12(V self, V *args) {
  V v_x_2455 = args[0];
  V v_x_2453 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_names_244 = heff_env(self)[2];
  V v_kept_2427 = heff_env(self)[3];
  V v_hd_248 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2456 = (g_heff_2elsp_2elsp_2enubSources(v_x_2453));
  return (g_heff_2ebuild_2esession_2ecachedWhere_24s1430135857x1314208524(v_e_240, heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam13, 1, 1, (V[]){v_names_244}), v_kept_2427, v_x_2455, v_t_2456, v_hd_248, v_k_249));
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam11(V self, V *args) {
  V v_x_2453 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_lib_2422 = heff_env(self)[1];
  V v_f_243 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_names_244 = heff_env(self)[4];
  V v_kept_2427 = heff_env(self)[5];
  V v_k_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2454 = (g_heff_2ebuild_2eload_2epathsFor_24s2011359778x1681041460(heff_dup(v_e_240), v_lib_2422, v_f_243));
  V f_ = v_c_2454;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam12, 1, 6, (V[]){v_x_2453, v_e_240, v_names_244, v_kept_2427, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_root_242 = heff_env(self)[1];
  V v_f_243 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_248 = heff_env(self)[4];
  V v_names_244 = heff_env(self)[5];
  V v_k_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_lib_2422 = heff_dup(heff_rfield(v_st_241, 6));
  V v_t_2423 = heff_dup(heff_rfield(v_st_241, 3));
  V v_kept_2427;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Nothing: {
    heff_drop(v_root_242);
    v_kept_2427 = heff_dup(g_std_2eordmap_2eempty_get());
    break;
  }
  case TAG_Just: {
    V v_pr_2424 = heff_field(v_t_2423, 0);
    heff_take_n(v_t_2423, 1ULL, 1);
    V v_root_2425 = heff_take_field(v_pr_2424, 0);
    V v_kept_2426 = heff_get_n(v_pr_2424, 4, 5);
    if (heff_strEq_c(v_root_2425, v_root_242)) {
      v_kept_2427 = v_kept_2426;
    } else {
      heff_drop(v_kept_2426);
      v_kept_2427 = heff_dup(g_std_2eordmap_2eempty_get());
    }
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_243), NTAG(TAG_Nil)});
  V v_files_2429 = (g_prelude_2e_2b_2b(v_x_2421, v_t_2428));
  V v_t_2430 = (g_heff_2elsp_2elsp_2enubPaths(v_files_2429));
  V v_c_2452 = ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam6, 1, 2, (V[]){v_st_241, heff_dup(v_e_240)}); V a_2 = heff_dup(v_lib_2422); V a_3 = v_t_2430; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s1832439424x1747718445(a_0, a_1, a_2, a_3)); heff_drop(v_t_2430); r_; });
  V f_ = v_c_2452;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam11, 1, 7, (V[]){v_e_240, v_lib_2422, v_f_243, v_hd_248, v_names_244, v_kept_2427, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_names_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_root_242 = heff_env(self)[4];
  V v_f_243 = heff_env(self)[5];
  V v_k_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2420;
  switch (heff_tag_of(v_names_244)) {
  case TAG_Nothing: {
    v_c_2420 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam4, 2, 1, (V[]){v_x_2416});
    break;
  }
  case TAG_Just: {
    V v_names_2419 = heff_dup(heff_field(v_names_244, 0));
    v_c_2420 = ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_st_241); V a_2 = v_names_2419; V a_3 = v_x_2416; V r_ = (g_heff_2elsp_2elsp_2ementionedIn_24s1376351875x472828574(a_0, a_1, a_2, a_3)); heff_drop(v_names_2419); r_; });
    break;
  }
  default: heff_nomatch(v_names_244);
  }
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam5, 1, 7, (V[]){v_st_241, v_root_242, v_f_243, v_e_240, v_hd_248, v_names_244, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_root_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_names_244 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_f_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProjectFiles, 2, (V[]){heff_dup(v_root_242), ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam2_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_248), heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam3, 1, 7, (V[]){v_names_244, v_e_240, v_st_241, v_hd_248, v_root_242, v_f_243, v_k_249})));
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam14(V self, V *args) {
  V v_r_2459 = args[0];
  return v_r_2459;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam0(V self, V *args) {
  V v_use_247 = args[0];
  V v_root_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_names_244 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_f_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_use_247;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam1, 2, 5, (V[]){v_root_242, v_e_240, v_names_244, v_st_241, v_f_243});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam14_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s762398827x656268827_lam15(V self, V *args) {
  V v_x_2465 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_root_242 = heff_env(self)[1];
  V v_names_244 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_e_2468;
  switch (heff_tag_of(v_x_2465)) {
  case TAG_Left: {
    heff_take_n(v_x_2465, 0ULL, 1);
    v_e_2468 = heff_rec_n(2, shape_program__kept, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get())});
    break;
  }
  case TAG_Right: {
    V v_e_2467 = heff_field(v_x_2465, 0);
    heff_take_n(v_x_2465, 1ULL, 1);
    v_e_2468 = v_e_2467;
    break;
  }
  default: heff_nomatch(v_x_2465);
  }
  V v_program_2469 = heff_take_field(v_e_2468, 0);
  V v_kept_2470 = heff_get_n(v_e_2468, 1, 2);
  V v_kept_2477;
  switch (heff_tag_of(v_program_2469)) {
  case TAG_Nil: {
    heff_drop(v_kept_2470);
    V v_t_2471 = heff_dup(heff_rfield(v_st_241, 3));
    switch (heff_tag_of(v_t_2471)) {
    case TAG_Nothing: {
      v_kept_2477 = heff_dup(g_std_2eordmap_2eempty_get());
      break;
    }
    case TAG_Just: {
      V v_pr_2472 = heff_field(v_t_2471, 0);
      heff_take_n(v_t_2471, 1ULL, 1);
      V v_root_2473 = heff_take_field(v_pr_2472, 0);
      V v_kept_2474 = heff_get_n(v_pr_2472, 4, 5);
      if (heff_strEq_c_lent(v_root_2473, v_root_242, 1)) {
        v_kept_2477 = v_kept_2474;
      } else {
        heff_drop(v_kept_2474);
        v_kept_2477 = heff_dup(g_std_2eordmap_2eempty_get());
      }
      break;
    }
    default: heff_nomatch(v_t_2471);
    }
    break;
  }
  case TAG_Cons: {
    v_kept_2477 = v_kept_2470;
    break;
  }
  default: heff_nomatch(v_program_2469);
  }
  V v_due_2478 = heff_take_field(v_st_241, 2);
  V v_watch_2479 = heff_take_field(v_st_241, 4);
  V v_shutdown_2480 = heff_take_field(v_st_241, 5);
  V v_lib_2481 = heff_take_field(v_st_241, 6);
  V v_t_2482 = heff_rec_n(5, shape_root__names__program__current__kept, (V[]){v_root_242, v_names_244, heff_dup(v_program_2469), NTAG(TAG_True), v_kept_2477});
  V v_t_2483 = ({ V rv_2 = v_due_2478; V rv_3 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2482}); V rv_4 = v_watch_2479; V rv_5 = v_shutdown_2480; V rv_6 = v_lib_2481; V rr_ = heff_rec_reuse_nf(v_st_241, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V f_ = v_k_246;
  args[0] = heff_rec_n(2, shape_st__program, (V[]){v_t_2483, v_program_2469});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_str0, 0, "");
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam0, 2, 0};
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_entry, 4, 0};

V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900(V v_e_240, V v_st_241, V v_query_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    return ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    V v_t_248 = (g_heff_2ebuild_2equery_2esymbols(heff_dup(v_c_246)));
    V v_t_2411 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam1, 1, 1, (V[]){heff_dup(v_query_242)}), v_t_248));
    V v_c_2412 = (g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_c_246), v_t_2411));
    return heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam2, 2, 5, (V[]){v_c_2412, v_e_240, v_st_241, heff_dup(v_query_242), heff_dup(v_rest_247)});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam1(V self, V *args) {
  V v_y_249 = args[0];
  V v_query_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_s_2410 = ({ V b_0 = heff_get_n(v_y_249, 0, 5); V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_str0); V r_ = (g_heff_2elsp_2elsp_2elowerGo(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_ret_24bool = heff_bool(heff_intLe_c(MK_INT(0LL), heff_strFind_lent(v_query_242, v_s_2410, MK_INT(0LL), 4)));
  heff_drop(v_query_242);
  heff_drop(v_s_2410);
  return v_ret_24bool;
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2418 = (g_prelude_2e_2b_2b(v_x_2415, v_x_2417));
  V f_ = v_k_2414;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_query_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2413 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2416 = ({ V a_0 = v_e_240; V a_1 = v_st_241; V a_2 = v_query_242; V a_3 = v_rest_247; V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900(a_0, a_1, a_2, a_3)); heff_drop(v_query_242); heff_drop(v_rest_247); r_; });
  V f_ = v_c_2416;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam4, 1, 2, (V[]){v_x_2415, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_query_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_lam3, 1, 6, (V[]){v_e_240, v_st_241, v_query_242, v_rest_247, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_entry, 3, 0};

V g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953(V v_e_240, V v_st_241, V v_p_242) {
top: ;
  V v_c_243 = (g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680(heff_dup(v_e_240), v_st_241, heff_dup(v_p_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_lam0, 2, 3, (V[]){v_c_243, v_e_240, v_p_242});
}
V g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    heff_drop(v_p_242);
    heff_drop(v_e_240);
    heff_drop(v_hd_244);
    V v_t_249 = heff_rec_n(3, shape_st__off__target, (V[]){heff_get_n(v_x_246, 0, 3), MK_INT(0LL), NTAG(TAG_Nothing)});
    V f_ = v_k_245;
    args[0] = v_t_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_2410 = heff_field(v_x_248, 0);
    V v_ru_24x_248_24Just = heff_take_reuse_n(v_x_248, 1ULL, 1);
    V v_program_2411 = heff_dup(heff_rfield(v_x_246, 2));
    V v_off_2412 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_x_246, 1), heff_dup(v_p_242)));
    V v_x1_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_2411)));
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_Nil: {
      heff_drop(v_p_242);
      heff_drop(v_e_240);
      heff_drop(v_hd_244);
      heff_drop(v_f_2410);
      heff_drop_cell(v_ru_24x_248_24Just, 1);
      heff_drop(v_program_2411);
      heff_drop(v_off_2412);
      V v_t_2414 = heff_rec_n(3, shape_st__off__target, (V[]){heff_get_n(v_x_246, 0, 3), MK_INT(0LL), NTAG(TAG_Nothing)});
      V f_ = v_k_245;
      args[0] = v_t_2414;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x1_2413, 0);
      heff_take_n(v_x1_2413, 1ULL, 2);
      V v_t_2417 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_x_2415, 4)));
      V v_t_2418 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_2417));
      V v_t_2419 = ({ V a_0 = v_program_2411; V a_1 = v_x_2415; V a_2 = v_t_2418; V a_3 = v_off_2412; V r_ = (g_heff_2ebuild_2equery_2etargetIn(a_0, a_1, a_2, a_3)); heff_drop(v_program_2411); r_; });
      switch (heff_tag_of(v_t_2419)) {
      case TAG_Nothing: {
        heff_drop(v_p_242);
        heff_drop(v_e_240);
        heff_drop(v_hd_244);
        heff_drop(v_f_2410);
        heff_drop_cell(v_ru_24x_248_24Just, 1);
        V v_t_2420 = heff_rec_n(3, shape_st__off__target, (V[]){heff_get_n(v_x_246, 0, 3), MK_INT(0LL), NTAG(TAG_Nothing)});
        V f_ = v_k_245;
        args[0] = v_t_2420;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Just: {
        V v_t_2421 = heff_field(v_t_2419, 0);
        heff_take_n(v_t_2419, 1ULL, 1);
        V v_t_2422 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_x_246, 1), v_p_242));
        return (g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok1(v_ru_24x_248_24Just, v_e_240, v_x_246, v_f_2410, v_t_2422, v_t_2421, v_hd_244, v_k_245));
      }
      default: return heff_nomatch(v_t_2419);
      }
    }
    default: return heff_nomatch(v_x1_2413);
    }
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_247 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(heff_dup(v_e_240), heff_dup(v_p_242)));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_lam2, 1, 5, (V[]){v_x_246, v_k_245, v_p_242, v_e_240, v_hd_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_lam1, 1, 4, (V[]){v_e_240, v_p_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_str0, 1, " ");
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam3, 3, 0};
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam10(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam10, 1, 0};
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam6(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_entry, 6, 0};

V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223(V v_e_240, V v_st_241, V v_f_242, V v_program_243, V v_c_244, V v_s_245) {
top: ;
  V v_docs_246 = heff_take_field(v_st_241, 0);
  V v_lib_247 = heff_get_n(v_st_241, 6, 7);
  V v_c_2436 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265(heff_dup(v_e_240), heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam0, 1, 5, (V[]){heff_dup(v_f_242), v_c_244, heff_dup(v_s_245), v_docs_246, heff_dup(v_e_240)}), v_lib_247, v_f_242));
  return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam6, 2, 4, (V[]){v_c_2436, v_program_243, v_s_245, v_e_240});
}
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_s_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V v_src_2411 = heff_get_n(v_c_244, 3, 14);
  V v_t_2412 = heff_strSlice(heff_dup(v_src_2411), MK_INT(0LL), heff_take_field(v_s_245, 3));
  V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_str0)), heff_take_field(v_s_245, 0));
  V v_t_2414 = heff_strSlice(heff_dup(v_src_2411), heff_get_n(v_s_245, 4, 5), heff_strLength(v_src_2411));
  V v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_t_2413, v_t_2414)});
  V f_ = v_k_2410;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_d_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2419, 1, 2)});
  V f_ = v_k_2421;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2427 = args[1];
  V v_k_2428 = args[2];
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435;
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Left: {
    heff_take_n(v_x_2432, 0ULL, 1);
    v_t_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2434 = heff_field(v_x_2432, 0);
    V v_ru_24x_2432_24Right = heff_take_reuse_n(v_x_2432, 1ULL, 1);
    v_t_2435 = heff_tag_at_n(v_ru_24x_2432_24Right, TAG_Just, 1, (V[]){v_y_2434});
    break;
  }
  default: heff_nomatch(v_x_2432);
  }
  V f_ = v_k_2431;
  args[0] = v_t_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam4(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_c_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2429;
  args[0] = v_hd_2430;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam5, 1, 1, (V[]){v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam0(V self, V *args) {
  V v_q_248 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_s_245 = heff_env(self)[2];
  V v_docs_246 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c_lent(v_q_248, v_f_242, 2)) {
    heff_drop(v_q_248);
    heff_drop(v_docs_246);
    heff_drop(v_e_240);
    return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam1, 2, 2, (V[]){v_c_244, v_s_245});
  } else {
    heff_drop_rec(v_c_244, 14);
    heff_drop_rec(v_s_245, 5);
    HeffT2 v_t_2416 = ({ V a_0 = v_docs_246; V a_1 = v_q_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_docs_246); r_; });
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        heff_drop(v_q_248);
        heff_drop(v_e_240);
        V v_d_2419 = v_field_2418;
        return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam2, 2, 1, (V[]){v_d_2419});
      } else {
        heff_drop(v_field_2418);
        V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_q_248));
        V v_c_2424 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2423; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2423); r_; });
        V v_t_2425 = (g_exception_2eattempted(v_e_240));
        V v_c_2429 = heff_tr(heff_call(v_c_2424, 2, (V[]){v_t_2425, ((V)&g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam3_clo)}));
        return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam4, 2, 1, (V[]){v_c_2429});
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam9(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_program_243 = heff_env(self)[0];
  V v_s_245 = heff_env(self)[1];
  V v_x_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2441);
  V v_program_2443 = v_program_243;
  V v_s_2444 = v_s_245;
  V v_equals_2445 = heff_take_field(v_s_2444, 3);
  V v_name_2446 = heff_get_n(v_s_2444, 0, 5);
  V v_x1_2447 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_x_2439, 0, 5)));
  V v_x3_2450;
  switch (heff_tag_of(v_x1_2447)) {
  case TAG_Nil: {
    v_x3_2450 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2448 = heff_field(v_x1_2447, 0);
    heff_take_n(v_x1_2447, 1ULL, 2);
    v_x3_2450 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2448});
    break;
  }
  default: heff_nomatch(v_x1_2447);
  }
  V v_x_2465;
  switch (heff_tag_of(v_x3_2450)) {
  case TAG_Nothing: {
    heff_drop(v_program_2443);
    heff_drop(v_equals_2445);
    heff_drop(v_name_2446);
    v_x_2465 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_source_2451 = heff_field(v_x3_2450, 0);
    V v_ru_24x3_2450_24Just = heff_take_reuse_n(v_x3_2450, 1ULL, 1);
    V v_t_2452 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_2443));
    V v_xs_2453 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2452; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2452); r_; });
    V v_t_2454 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2453));
    V v_c_2455 = (g_heff_2ebuild_2edriver_2eelabNext(v_t_2454, v_source_2451, NTAG(TAG_Nothing)));
    HeffT2 v_t_2456 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_c_2455, heff_intAdd(v_equals_2445, MK_INT(1LL))));
    {
      V v_field_2458 = v_t_2456.f[1];
      int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
      if ((v_tag_2457 == ((int64_t)0ULL))) {
        V v_i_2459 = v_field_2458;
        V v_name_2460 = heff_take_field(v_i_2459, 1);
        V v_key_2461 = heff_take_field(v_i_2459, 2);
        V v_ty_2462 = heff_get_n(v_i_2459, 4, 5);
        if (heff_strEq_c(v_name_2460, v_name_2446)) {
          switch (heff_tag_of(v_key_2461)) {
          case TAG_Nothing: {
            V v_t_2463 = heff_tr(heff_call(v_ty_2462, 1, (V[]){NTAG(TAG_MkUnit)}));
            v_x_2465 = heff_tag_at_n(v_ru_24x3_2450_24Just, TAG_Just, 1, (V[]){v_t_2463});
            break;
          }
          case TAG_Just: {
            heff_take_n(v_key_2461, 0ULL, 1);
            heff_drop_cell(v_ru_24x3_2450_24Just, 1);
            heff_drop(v_ty_2462);
            v_x_2465 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_key_2461);
          }
        } else {
          heff_drop_cell(v_ru_24x3_2450_24Just, 1);
          heff_drop(v_key_2461);
          heff_drop(v_ty_2462);
          v_x_2465 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_name_2446);
        heff_drop_cell(v_ru_24x3_2450_24Just, 1);
        heff_drop(v_field_2458);
        v_x_2465 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_x3_2450);
  }
  V f_ = v_k_2442;
  args[0] = v_x_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam10(V self, V *args) {
  V v_r_2466 = args[0];
  return v_r_2466;
}
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam8(V self, V *args) {
  V v_use_2440 = args[0];
  V v_program_243 = heff_env(self)[0];
  V v_s_245 = heff_env(self)[1];
  V v_x_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_2440;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam9, 2, 3, (V[]){v_program_243, v_s_245, v_x_2439});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam10_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam11(V self, V *args) {
  V v_x_2472 = args[0];
  V v_k_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2475;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_Left: {
    heff_take_n(v_x_2472, 0ULL, 1);
    v_t_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_t_2474 = heff_field(v_x_2472, 0);
    heff_take_n(v_x_2472, 1ULL, 1);
    v_t_2475 = v_t_2474;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V f_ = v_k_2438;
  args[0] = v_t_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_program_243 = heff_env(self)[0];
  V v_s_245 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_2437 = heff_env(self)[3];
  V v_k_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam8, 1, 3, (V[]){v_program_243, v_s_245, v_x_2439})})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2471}), v_hd_2437, heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam11, 1, 1, (V[]){v_k_2438})));
}
V g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam6(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_c_2436 = heff_env(self)[0];
  V v_program_243 = heff_env(self)[1];
  V v_s_245 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2436;
  args[0] = heff_dup(v_hd_2437);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s91190449x1153474223_lam7, 1, 5, (V[]){v_program_243, v_s_245, v_e_240, v_hd_2437, v_k_2438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}