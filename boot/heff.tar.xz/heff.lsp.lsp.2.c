// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Send 26077
#define LBL_analysis 1868176469
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_code 9554612
#define LBL_cut 308412
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_equals 651658986
#define LBL_imports 10411951
#define LBL_key 315609
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_severity 75955546
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_analysis__at[] = {LBL_analysis, LBL_at};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_cut__name[] = {LBL_cut, LBL_name};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_program__diags[] = {LBL_program, LBL_diags};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_uri__text[] = {LBL_uri, LBL_text};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_heff_2ebuild_2edriver_2eelabNext(V, V, V);
V g_heff_2ebuild_2edriver_2eelabNext_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNext_clo;
V g_heff_2ebuild_2edriver_2etraceless(V);
V g_heff_2ebuild_2edriver_2etraceless_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etraceless_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
V g_heff_2ebuild_2equery_2edocAt(V, V);
V g_heff_2ebuild_2equery_2edocAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocAt_clo;
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V, V, V);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_clo;
V g_heff_2elsp_2elsp_2ebrokenImport(V, V);
V g_heff_2elsp_2elsp_2ebrokenImport_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ebrokenImport_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL(V);
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V, V);
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo;
V g_heff_2elsp_2elsp_2echanged(V, V, V);
V g_heff_2elsp_2elsp_2echanged_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echanged_clo;
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476(V, V, V);
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723(V, V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723_clo;
HeffT2 g_heff_2elsp_2elsp_2eclaimEdit_24cpr(V, V, V);
V g_heff_2elsp_2elsp_2edeclLine(V);
V g_heff_2elsp_2elsp_2edeclLine_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclLine_clo;
V g_heff_2elsp_2elsp_2edeclsGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_24dps_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482(V, V);
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_clo;
V g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018(V, V, V, V, V);
V g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_clo;
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543(V, V, V, V);
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_clo;
V g_heff_2elsp_2elsp_2ehoverOf(V, V);
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2ekeyOf(V);
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeyOf_clo;
V g_heff_2elsp_2elsp_2enameSpanIn(V, V, V);
V g_heff_2elsp_2elsp_2enameSpanIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enameSpanIn_clo;
V g_heff_2elsp_2elsp_2enamedIn(V);
V g_heff_2elsp_2elsp_2enamedIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enamedIn_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enotification_24s510245607x492030398(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2enotification_24s510245607x492030398_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotification_24s510245607x492030398_clo;
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966(V, V, V, V);
V g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotified_24s374980071x891489966_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubRoots_24dps(V, V);
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources_24dps(V, V);
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_clo;
V g_heff_2elsp_2elsp_2eprobedIn(V, V, V);
V g_heff_2elsp_2elsp_2eprobedIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedIn_clo;
V g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353(V, V, V);
V g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2eregistration_get(void);
V g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231_clo;
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031_clo;
V g_heff_2elsp_2elsp_2estoppedAnalysis(V, V, V);
V g_heff_2elsp_2elsp_2estoppedAnalysis_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedAnalysis_clo;
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_clo;
V g_heff_2elsp_2elsp_2etargetIn(V, V, V, V, V);
V g_heff_2elsp_2elsp_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2etargetIn_clo;
V g_heff_2elsp_2elsp_2eundue(V, V);
V g_heff_2elsp_2elsp_2eundue_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eundue_clo;
V g_heff_2elsp_2elsp_2eunits16Go(V, V, V, V);
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eunits16Go_clo;
V g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543(V, V, V);
V g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2erepeated(V, V);
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eany_24s2002848564x1372628513(V, V);
V g_list_2eany_24s2002848564x1372628513_entry(V self, V *a);
extern Clo g_list_2eany_24s2002848564x1372628513_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s1637307977x1351693783_24cpr(V, V, V, V, V, V);
HeffT2 g_list_2efind_24s250366202x1057933814_24cpr(V, V, V);
HeffT2 g_list_2efind_24s465947678x1101118081_24cpr(V, V);
HeffT2 g_list_2efind_24s727666736x1458251130_24cpr(V, V);
V g_list_2efoldl_24f2094160282x1876485468(V, V, V);
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2094160282x1876485468_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s1161549307x1906011635(V);
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_clo;
V g_list_2ekeepIf_24s1504784414x46513720(V, V);
V g_list_2ekeepIf_24s1504784414x46513720_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1504784414x46513720_clo;
V g_list_2ekeepIf_24s1592706127x1457322737(V, V);
V g_list_2ekeepIf_24s1592706127x1457322737_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1592706127x1457322737_clo;
V g_list_2ekeepIf_24s338188875x1751169912(V, V);
V g_list_2ekeepIf_24s338188875x1751169912_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s338188875x1751169912_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f738852651x284559611(V, V);
V g_prelude_2e_2b_2b_24f738852651x284559611_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f738852651x284559611_clo;
V g_std_2emap_2edelete_24s1614046289x1611773644(V, V);
V g_std_2emap_2edelete_24s1614046289x1611773644_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s1614046289x1611773644_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);

static V g_heff_2elsp_2elsp_2ejfalse_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejfalse_st;
static V g_heff_2elsp_2elsp_2ejfalse_init(void) {
  return heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2elsp_2elsp_2ejfalse_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejfalse_st)) return g_heff_2elsp_2elsp_2ejfalse_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejfalse_val, &g_heff_2elsp_2elsp_2ejfalse_st, g_heff_2elsp_2elsp_2ejfalse_init);
}
Clo g_heff_2elsp_2elsp_2eunits16Go_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eunits16Go_entry, 4, 0};

V g_heff_2elsp_2elsp_2eunits16Go(V v_src_240, V v_i_241, V v_j_242, V v_n_243) {
top: ;
  if (heff_intLe_c_lent(v_j_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return v_n_243;
  } else {
    if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241))) {
      heff_drop(v_i_241);
      heff_drop(v_j_242);
      return v_n_243;
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) < ((int64_t)128ULL))) {
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_j_242;
        V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_n_243 = t_3;
        goto top;
      } else {
        V v_t_247 = heff_intAdd(heff_dup(v_i_241), heff_strRuneWidth_lent(v_src_240, v_i_241, 0));
        V v_t_248 = heff_runeToInt(heff_strRuneAt_lent(v_src_240, v_i_241, 2));
        V v_t_2410;
        if (heff_intLe_c(MK_INT(65536LL), v_t_248)) {
          v_t_2410 = MK_INT(2LL);
        } else {
          v_t_2410 = MK_INT(1LL);
        }
        V t_0 = v_src_240;
        V t_1 = v_t_247;
        V t_2 = v_j_242;
        V t_3 = heff_intAdd(v_n_243, v_t_2410);
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_n_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eunits16Go(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2eoffsetGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetGo_entry, 5, 0};

V g_heff_2elsp_2elsp_2eoffsetGo(V v_src_240, V v_line_241, V v_ch_242, V v_i_243, V v_l_244) {
top: ;
  if (heff_intLe_c_lent(v_line_241, v_l_244, 0)) {
    heff_drop(v_line_241);
    heff_drop(v_l_244);
    V v_j_246 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str0), v_src_240, v_i_243, 1);
    V v_t_248;
    if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
      heff_drop(v_j_246);
      v_t_248 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_248 = v_j_246;
    }
    return (g_heff_2elsp_2elsp_2eoffset16(v_src_240, v_i_243, v_t_248, v_ch_242));
  } else {
    V v_j_249 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str1), v_src_240, v_i_243, 5);
    if (heff_intLt_c_lent(v_j_249, MK_INT(0LL), 2)) {
      heff_drop(v_line_241);
      heff_drop(v_ch_242);
      heff_drop(v_l_244);
      heff_drop(v_j_249);
      return heff_strLength_lent(v_src_240, 0);
    } else {
      V t_0 = v_src_240;
      V t_1 = v_line_241;
      V t_2 = v_ch_242;
      V t_3 = heff_intAdd(v_j_249, MK_INT(1LL));
      V t_4 = heff_intAdd(v_l_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_line_241 = t_1;
      v_ch_242 = t_2;
      v_i_243 = t_3;
      v_l_244 = t_4;
      goto top;
    }
  }
}
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffsetGo(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str0, 8, "severity");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str1, 6, "source");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str2, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str3, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str4, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str5, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str6, 1, "E");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str7, 1, "W");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str8, 1, "D");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str9, 1, "0");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str10, 4, "code");
Clo g_heff_2elsp_2elsp_2ediagnostic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagnostic_entry, 2, 0};

V g_heff_2elsp_2elsp_2ediagnostic(V v_src_240, V v_d_241) {
top: ;
  V v_t_242 = (g_heff_2elsp_2elsp_2erange(v_src_240, heff_take_field(v_d_241, 3)));
  V v_t_243 = heff_dup(heff_rfield(v_d_241, 1));
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SError: {
    v_t_244 = MK_INT(1LL);
    break;
  }
  case TAG_SWarning: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_SDebug: {
    v_t_244 = MK_INT(4LL);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str0), heff_tag_n(TAG_JInt, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str1), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str2)})});
  V v_t_247 = heff_take_field(v_d_241, 4);
  V v_t_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    v_t_249 = heff_dup(heff_rfield(v_d_241, 2));
    break;
  }
  case TAG_Just: {
    V v_n_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 2)), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ediagnostic_str3), v_n_248));
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str4), heff_tag_n(TAG_JString, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str5), v_t_242}), v_t_2412});
  V v_t_2422;
  if (heff_intEq_c(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL))) {
    heff_drop_rec(v_d_241, 5);
    v_t_2422 = NTAG(TAG_Nil);
  } else {
    V v_t_2415 = heff_take_field(v_d_241, 1);
    V v_t_2416;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_SError: {
      v_t_2416 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str6);
      break;
    }
    case TAG_SWarning: {
      v_t_2416 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str7);
      break;
    }
    case TAG_SDebug: {
      v_t_2416 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str8);
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    V v_t_2417 = (g_heff_2elsp_2erender_2enumDigits(heff_dup(heff_rfield(v_d_241, 0))));
    V v_t_2418 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_2417), ((V)&g_heff_2elsp_2elsp_2ediagnostic_str9)));
    V v_t_2419 = heff_intShow(heff_get_n(v_d_241, 0, 5));
    V v_t_2420 = heff_strAppend(v_t_2416, heff_strAppend(v_t_2418, v_t_2419));
    V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str10), heff_tag_n(TAG_JString, 1, (V[]){v_t_2420})});
    v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  }
  V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2422));
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2423});
}
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ediagnostic(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str1, 1, "s");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str2, 6, " error");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str3, 22, ") does not elaborate: ");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str4, 2, " (");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str5, 7, "module ");
Clo g_heff_2elsp_2elsp_2ebrokenImport_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ebrokenImport_entry, 2, 0};

V g_heff_2elsp_2elsp_2ebrokenImport(V v_imports_240, V v_c_241) {
top: ;
  V v_x1_242 = (g_list_2ekeepIf_24s1161549307x1906011635(heff_dup(heff_rfield(v_c_241, 6))));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_imports_240);
    heff_drop_rec(v_c_241, 14);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    heff_take_n(v_x1_242, 0ULL, 2);
    V v_t_245 = (g_list_2eany_24s2002848564x1372628513(heff_dup(v_c_241), v_imports_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      HeffT2 v_t_246 = (g_list_2efind_24s727666736x1458251130_24cpr(heff_rfield(v_c_241, 0), v_imports_240));
      V v_sp_2411;
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_i_2410 = v_field_248;
          v_sp_2411 = heff_get_n(v_i_2410, 2, 3);
        } else {
          heff_drop(v_field_248);
          v_sp_2411 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
        }
      }
      V v_t_2412 = (g_list_2efoldl_24f2094160282x1876485468(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 6)));
      V v_t_2413 = (g_list_2efoldl_24f2094160282x1876485468(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 6)));
      V v_t_2415;
      if (heff_intEq_c(v_t_2413, MK_INT(1LL))) {
        v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ebrokenImport_str0);
      } else {
        v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ebrokenImport_str1);
      }
      V v_t_2416 = heff_strAppend(heff_intShow(v_t_2412), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str2), v_t_2415));
      V v_t_2417 = heff_strAppend(heff_take_field(v_c_241, 1), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str3), v_t_2416));
      V v_t_2418 = heff_strAppend(heff_get_n(v_c_241, 0, 14), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str4), v_t_2417));
      V v_msg_2419 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str5), v_t_2418);
      V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SWarning), v_msg_2419, v_sp_2411, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
    } else {
      heff_drop(v_imports_240);
      heff_drop_rec(v_c_241, 14);
      heff_drop(v_t_245);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2elsp_2elsp_2ebrokenImport_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ebrokenImport(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecatMaybesL_entry, 1, 0};

V g_heff_2elsp_2elsp_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2elsp_2elsp_2ecatMaybesL_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecatMaybesL(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str1, 1, " ");
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ediagsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagsOf_entry, 3, 0};

V g_heff_2elsp_2elsp_2ediagsOf(V v_src_240, V v_program_241, V v_errors_242) {
top: ;
  V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_241)));
  V v_t_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    v_t_246 = heff_get_n(v_x_244, 6, 14);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam0, 1, 1, (V[]){heff_dup(v_src_240)}), v_errors_242));
  V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_241));
  V v_xs_2418 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2417; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2418));
  V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam1, 1, 1, (V[]){v_src_240}), v_t_2419));
  V v_t_2423 = (g_heff_2elsp_2elsp_2ecatMaybesL(v_t_2422));
  V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2423));
  return (g_prelude_2e_2b_2b(v_t_246, v_t_2424));
}
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ediagsOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_imports_249 = heff_get_n(v_t_248, 0, 4);
  HeffT2 v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str0); V a_2 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str1); V a_3 = v_e_247; V b_4 = MK_INT(0LL); V a_5 = v_imports_249; HeffT2 r_ = (g_list_2efind_24s1637307977x1351693783_24cpr(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(b_4); r_; });
  V v_sp_2415;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_i_2414 = v_field_2412;
      v_sp_2415 = heff_get_n(v_i_2414, 2, 3);
    } else {
      heff_drop(v_field_2412);
      v_sp_2415 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
    }
  }
  return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_e_247, v_sp_2415, NTAG(TAG_Nothing)});
}
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args) {
  V v_c_2420 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  return (g_heff_2elsp_2elsp_2ebrokenImport(heff_get_n(v_t_2421, 0, 4), v_c_2420));
}
Clo g_heff_2elsp_2elsp_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeptOf_entry, 1, 0};

V g_heff_2elsp_2elsp_2ekeptOf(V v_program_240) {
top: ;
  V v_x1_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_240)));
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_program_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2edriver_2etraceless(v_x_242));
    V v_t_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
    V v_xs_247 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_246; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_247));
    return (g_prelude_2e_2b_2b_24f738852651x284559611(v_t_245, v_t_248));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ekeptOf(a[0]);
}
Clo g_heff_2elsp_2elsp_2enamedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enamedIn_entry, 1, 0};

V g_heff_2elsp_2elsp_2enamedIn(V v_l_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2elsp_2elsp_2enamedIn_24cpr(v_l_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_start__end, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2elsp_2elsp_2enamedIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2enamedIn(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str0, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str1, 2, "{-");
Clo g_heff_2elsp_2elsp_2edeclsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edeclsGo_24dps_entry, 4, 0};

V g_heff_2elsp_2elsp_2edeclsGo_24dps(V v_x1_240, V v_key_241, V v_above_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_key_241);
    heff_drop(v_above_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_l_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_l_246 = heff_dup(heff_rfield(v_l_244, 1));
    if (heff_strEq_c(heff_strSlice_lent(v_l_246, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str0))) {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_l_246);
      V v_t_249;
      switch (heff_tag_of(v_above_242)) {
      case TAG_Nothing: {
        v_t_249 = heff_get_n(v_l_244, 0, 2);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_above_242, 0);
        heff_take_n(v_above_242, 1ULL, 1);
        heff_drop_rec(v_l_244, 2);
        v_t_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_above_242);
      }
      V t_0 = v_rest_245;
      V t_1 = v_key_241;
      V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
      V t_3 = v_d_243;
      v_x1_240 = t_0;
      v_key_241 = t_1;
      v_above_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      if (heff_strEq_c(heff_strSlice(v_l_246, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str1))) {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V v_t_2412;
        switch (heff_tag_of(v_above_242)) {
        case TAG_Nothing: {
          v_t_2412 = heff_get_n(v_l_244, 0, 2);
          break;
        }
        case TAG_Just: {
          V v_x_2411 = heff_field(v_above_242, 0);
          heff_take_n(v_above_242, 1ULL, 1);
          heff_drop_rec(v_l_244, 2);
          v_t_2412 = v_x_2411;
          break;
        }
        default: heff_nomatch(v_above_242);
        }
        V t_0 = v_rest_245;
        V t_1 = v_key_241;
        V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
        V t_3 = v_d_243;
        v_x1_240 = t_0;
        v_key_241 = t_1;
        v_above_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        V v_t_2413 = (g_heff_2elsp_2elsp_2edeclLine(heff_rfield(v_l_244, 1)));
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_t_2413);
          V v_t_2414 = (g_heff_2elsp_2elsp_2ekeyOf(heff_rfield(v_l_244, 1)));
          if (heff_strEq_c_lent(v_t_2414, v_key_241, 1)) {
            heff_drop(v_above_242);
            heff_drop_rec(v_l_244, 2);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            V t_0 = v_rest_245;
            V t_1 = v_key_241;
            V t_2 = NTAG(TAG_Nothing);
            V t_3 = v_d_243;
            v_x1_240 = t_0;
            v_key_241 = t_1;
            v_above_242 = t_2;
            v_d_243 = t_3;
            goto top;
          } else {
            heff_drop(v_key_241);
            V v_n_2416 = heff_dup(heff_rfield(v_l_244, 0));
            HeffT2 v_t_2417 = (g_heff_2elsp_2elsp_2enamedIn_24cpr(heff_rfield(v_l_244, 1)));
            V v_t_2423;
            {
              V v_field_2418 = v_t_2417.f[0];
              V v_field_2419 = v_t_2417.f[1];
              V v_t_2421;
              switch (heff_tag_of(v_above_242)) {
              case TAG_Nothing: {
                v_t_2421 = heff_dup(heff_rfield(v_l_244, 0));
                break;
              }
              case TAG_Just: {
                V v_x_2420 = heff_field(v_above_242, 0);
                heff_take_n(v_above_242, 1ULL, 1);
                v_t_2421 = v_x_2420;
                break;
              }
              default: heff_nomatch(v_above_242);
              }
              V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(v_field_2418, heff_dup(v_n_2416)), heff_intAdd(v_field_2419, v_n_2416)});
              v_t_2423 = heff_rec_n(2, shape_cut__name, (V[]){v_t_2421, v_t_2422});
            }
            V v_cell_2424 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
            V v_u_2425 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2424));
            heff_drop(v_u_2425);
            V v_t_2426 = ({ V b_0 = heff_get_n(v_l_244, 1, 2); V r_ = (g_heff_2elsp_2elsp_2ekeyOf(b_0)); heff_drop(b_0); r_; });
            V t_0 = v_rest_245;
            V t_1 = v_t_2426;
            V t_2 = NTAG(TAG_Nothing);
            V t_3 = v_cell_2424;
            v_x1_240 = t_0;
            v_key_241 = t_1;
            v_above_242 = t_2;
            v_d_243 = t_3;
            goto top;
          }
        } else {
          heff_drop(v_above_242);
          heff_drop_rec(v_l_244, 2);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_t_2413);
          V t_0 = v_rest_245;
          V t_1 = v_key_241;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = v_d_243;
          v_x1_240 = t_0;
          v_key_241 = t_1;
          v_above_242 = t_2;
          v_d_243 = t_3;
          goto top;
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2edeclsGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edeclsGo_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedAnalysis_str0, 42, "heff could not finish checking this file (");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedAnalysis_str1, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedAnalysis_str2, 59, "heff could not finish checking this file: it stopped here (");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedAnalysis_str3, 30, "); what follows is not checked");
Clo g_heff_2elsp_2elsp_2estoppedAnalysis_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedAnalysis_entry, 3, 0};

V g_heff_2elsp_2elsp_2estoppedAnalysis(V v_src_240, V v_why_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 0)), 1, 2);
  V v_t_244 = heff_take_field(v_s_242, 1);
  V v_t_2410;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2estoppedAnalysis_str0), heff_strAppend(v_why_241, ((V)&g_heff_2elsp_2elsp_2estoppedAnalysis_str1)));
    V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_t_245, heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get()), NTAG(TAG_Nothing)});
    v_t_2410 = (g_heff_2elsp_2elsp_2ediagnostic(v_src_240, v_t_246));
    break;
  }
  case TAG_Just: {
    V v_t_247 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_t_248 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2estoppedAnalysis_str2), heff_strAppend(v_why_241, ((V)&g_heff_2elsp_2elsp_2estoppedAnalysis_str3)));
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_t_248, heff_get_n(v_t_247, 1, 2), NTAG(TAG_Nothing)});
    v_t_2410 = (g_heff_2elsp_2elsp_2ediagnostic(v_src_240, v_t_249));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_diags_2412 = (g_prelude_2e_2b_2b(v_t_243, v_t_2411));
  V v_t_2413 = heff_get_n(heff_get_n(v_s_242, 0, 2), 0, 2);
  return heff_rec_n(2, shape_program__diags, (V[]){v_t_2413, v_diags_2412});
}
V g_heff_2elsp_2elsp_2estoppedAnalysis_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2estoppedAnalysis(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubSources_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_ss_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_s_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2ekeepIf_24s1592706127x1457322737(v_s_242, v_ss_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubSources_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str0, 10, "   (local)");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str1, 11, "   (global)");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str2, 3, " : ");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str3, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str4, 8, "markdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str6, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str7, 4, "\012```");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str8, 11, "\012```\012\012---\012\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str9, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str10, 5, "value");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str11, 8, "contents");
Clo g_heff_2elsp_2elsp_2ehoverOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehoverOf_entry, 2, 0};

V g_heff_2elsp_2elsp_2ehoverOf(V v_a_240, V v_p_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_a_240, 2))));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_a_240, 3);
    heff_drop(v_p_241);
    return NTAG(TAG_JNull);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Cons = heff_take_reuse_n(v_x1_242, 1ULL, 2);
    V v_off_245 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_a_240, 1), heff_dup(v_p_241)));
    HeffT2 v_t_246 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_x_243, v_off_245));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_i_2410 = v_field_248;
        V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2enamed(heff_take_field(v_i_2410, 1)));
        V v_t_2412 = heff_tr(heff_call(heff_take_field(v_i_2410, 4), 1, (V[]){NTAG(TAG_MkUnit)}));
        V v_t_2413 = heff_get_n(v_i_2410, 2, 5);
        V v_t_2415;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_Nothing: {
          v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str0);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str1);
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        V v_t_2416 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str2), heff_strAppend(v_t_2412, v_t_2415));
        V v_t_2417 = heff_strAppend(v_t_2411, v_t_2416);
        V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str3), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str4)})});
        V v_t_2419 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_a_240, 1), v_p_241));
        V v_doc_2420 = (g_heff_2ebuild_2equery_2edocAt(heff_get_n(v_a_240, 2, 3), v_t_2419));
        V v_t_2423;
        if (heff_strEq_c_lent(v_doc_2420, ((V)&g_heff_2elsp_2elsp_2ehoverOf_str5), 2)) {
          heff_drop(v_doc_2420);
          v_t_2423 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str6), heff_strAppend(v_t_2417, ((V)&g_heff_2elsp_2elsp_2ehoverOf_str7)));
        } else {
          V v_t_2422 = heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str8), v_doc_2420));
          v_t_2423 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str9), v_t_2422);
        }
        V v_t_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str10), heff_tag_n(TAG_JString, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_at_n(v_ru_24x1_242_24Cons, TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
        V v_t_2426 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2425})});
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str11), v_t_2426}), NTAG(TAG_Nil)});
        return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2427});
      } else {
        heff_drop_rec(v_a_240, 3);
        heff_drop(v_p_241);
        heff_drop_cell(v_ru_24x1_242_24Cons, 2);
        heff_drop(v_field_248);
        return NTAG(TAG_JNull);
      }
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehoverOf(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_cs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_241), heff_hole()});
    V v_t_244 = (g_list_2ekeepIf_24s1504784414x46513720(v_c_241, v_cs_242));
    V v_u_245 = (g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubCheckedPaths(a[0]);
}
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2ekeepIf_24s1504784414x46513720(v_c_242, v_cs_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubRoots_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_r_242; V a_1 = v_rs_243; V r_ = (g_list_2ekeepIf_24s338188875x1751169912(a_0, a_1)); heff_drop(v_r_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubRoots_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2eprobedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedIn_entry, 3, 0};

V g_heff_2elsp_2elsp_2eprobedIn(V v_program_240, V v_s_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_program_240);
    heff_drop_rec(v_s_241, 5);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_source_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
    V v_xs_245 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_244; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_244); r_; });
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
    V v_c_247 = ({ V a_0 = v_t_246; V a_1 = v_source_243; V b_2 = NTAG(TAG_Nothing); V r_ = (g_heff_2ebuild_2edriver_2eelabNext(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_248 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(1LL));
    HeffT2 v_t_249 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_c_247, v_t_248));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_i_2413 = v_field_2411;
        if (heff_strEq_c(heff_dup(heff_rfield(v_i_2413, 1)), heff_get_n(v_s_241, 0, 5))) {
          V v_t_2415 = heff_take_field(v_i_2413, 2);
          switch (heff_tag_of(v_t_2415)) {
          case TAG_Nothing: {
            V v_t_2416 = heff_tr(heff_call(heff_get_n(v_i_2413, 4, 5), 1, (V[]){NTAG(TAG_MkUnit)}));
            return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2416});
          }
          case TAG_Just: {
            heff_take_n(v_t_2415, 0ULL, 1);
            heff_drop_cell(v_ru_24x3_242_24Just, 1);
            heff_drop_rec(v_i_2413, 5);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2415);
          }
        } else {
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          heff_drop_rec(v_i_2413, 5);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_rec(v_s_241, 5);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_field_2411);
        return NTAG(TAG_Nothing);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eprobedIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprobedIn(a[0], a[1], a[2]);
}
Clo g_heff_2elsp_2elsp_2enameSpanIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enameSpanIn_entry, 3, 0};

V g_heff_2elsp_2elsp_2enameSpanIn(V v_src_240, V v_h_241, V v_m_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_h_241, 3)), 0, 2);
  V v_from_244 = heff_intAdd(v_t_243, MK_INT(6LL));
  V v_t_245 = heff_get_n(heff_get_n(v_h_241, 3, 5), 1, 2);
  V v_j_246 = heff_strFind(heff_dup(v_m_242), heff_strSlice_lent(v_src_240, v_from_244, v_t_245, 4), MK_INT(0LL));
  V v_t_248;
  if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
    heff_drop(v_j_246);
    v_t_248 = MK_INT(1LL);
  } else {
    v_t_248 = v_j_246;
  }
  V v_at_249 = heff_intAdd(v_from_244, v_t_248);
  V v_t_2410 = heff_intAdd(heff_dup(v_at_249), heff_strLength_lent(v_m_242, 0));
  return heff_rec_n(2, shape_start__end, (V[]){v_at_249, v_t_2410});
}
V g_heff_2elsp_2elsp_2enameSpanIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2elsp_2elsp_2enameSpanIn(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimEdit_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimEdit_24cpr_str1, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimEdit_24cpr_str2, 2, "\012\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimEdit_24cpr_str3, 7, "module ");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimEdit_24cpr_str4, 1, " ");

HeffT2 g_heff_2elsp_2elsp_2eclaimEdit_24cpr(V v_src_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_244;
    if (heff_strEq_c_lent(v_src_240, ((V)&g_heff_2elsp_2elsp_2eclaimEdit_24cpr_str0), 2)) {
      v_t_244 = ((V)&g_heff_2elsp_2elsp_2eclaimEdit_24cpr_str1);
    } else {
      v_t_244 = ((V)&g_heff_2elsp_2elsp_2eclaimEdit_24cpr_str2);
    }
    V v_t_245 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimEdit_24cpr_str3), heff_strAppend(v_n_241, v_t_244));
    V v_f_246 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get()), v_t_245});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
  }
  case TAG_Just: {
    V v_h_247 = heff_field(v_x3_242, 0);
    V v_t_248 = heff_dup(heff_rfield(v_h_247, 0));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_h_247, 3)), 0, 2);
      V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_h_247, 3)), 0, 2);
      V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(v_t_249, MK_INT(6LL)), heff_intAdd(v_t_2410, MK_INT(6LL))});
      V v_f_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimEdit_24cpr_str4), v_n_241)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
    }
    case TAG_Just: {
      V v_m_2413 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      if (heff_strEq_c_lent(v_m_2413, v_n_241, 0)) {
        heff_drop(v_n_241);
        heff_drop(v_m_2413);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V v_t_2415 = ({ V a_0 = v_src_240; V a_1 = heff_dup(v_h_247); V a_2 = v_m_2413; V r_ = (g_heff_2elsp_2elsp_2enameSpanIn(a_0, a_1, a_2)); heff_drop(v_m_2413); r_; });
        V v_f_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_n_241});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str2, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str3, 10, "heff-watch");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str4, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str5, 25, "client/registerCapability");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str6, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str7, 10, "heff-watch");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str8, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str9, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str10, 11, "globPattern");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str11, 7, "**/*.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str12, 8, "watchers");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str13, 15, "registerOptions");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str14, 13, "registrations");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str15, 6, "params");

static V g_heff_2elsp_2elsp_2eregistration_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2eregistration_st;
static V g_heff_2elsp_2elsp_2eregistration_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str1)})});
  V v_t_241 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str2), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str3)})});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str4), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str5)})});
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str6), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str7)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str8), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str9)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str10), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str11)})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_246}), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str12), heff_tag_n(TAG_JArray, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str13), heff_tag_n(TAG_JObject, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str14), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str15), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_2417})});
  return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_2418})});
}
V g_heff_2elsp_2elsp_2eregistration_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2eregistration_st)) return g_heff_2elsp_2elsp_2eregistration_val;
  return heff_global(&g_heff_2elsp_2elsp_2eregistration_val, &g_heff_2elsp_2elsp_2eregistration_st, g_heff_2elsp_2elsp_2eregistration_init);
}
Clo g_heff_2elsp_2elsp_2echanged_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echanged_entry, 3, 0};

V g_heff_2elsp_2elsp_2echanged(V v_st_240, V v_f_241, V v_text_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_st_240, 0), v_f_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_d_247 = v_field_245;
      V v_t_248 = ({ V rv_1 = v_text_242; V rr_ = heff_rec_reuse_nf(v_d_247, 1ULL, 2, shape_uri__text, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_d_249 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_st_240, 0), v_f_241, v_t_248));
      return ({ V rv_0 = v_d_249; V rr_ = heff_rec_reuse_nf(v_st_240, 126ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16380u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    } else {
      heff_drop(v_f_241);
      heff_drop(v_text_242);
      heff_drop(v_field_245);
      return v_st_240;
    }
  }
}
V g_heff_2elsp_2elsp_2echanged_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echanged(a[0], a[1], a[2]);
}
Clo g_heff_2elsp_2elsp_2eundue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eundue_entry, 2, 0};

V g_heff_2elsp_2elsp_2eundue(V v_due_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_due_240;
  }
  case TAG_Cons: {
    V v_f_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_std_2emap_2edelete_24s1614046289x1611773644(v_due_240, v_f_242));
    V t_0 = v_t_244;
    V t_1 = v_rest_243;
    v_due_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2eundue_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eundue(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam3, 1, 0};
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam4(V self, V *args);
Clo g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_entry, 8, 0};

V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104(V v_wire_240, V v_st_241, V v_f_242, V v_d_243, V v_ds_244, V v_lo_245, V v_hi_246, V v_a_247) {
top: ;
  if (heff_intLe_c(heff_intSub(heff_dup(v_hi_246), heff_dup(v_lo_245)), MK_INT(1LL))) {
    heff_drop(v_wire_240);
    heff_drop(v_st_241);
    heff_drop(v_f_242);
    heff_drop_rec(v_d_243, 2);
    heff_drop(v_hi_246);
    HeffT3 v_t_249 = (g_list_2edrop_24cpr(v_lo_245, v_ds_244));
    {
      V v_field_2411 = v_t_249.f[1];
      V v_field_2412 = v_t_249.f[2];
      V v_tag_2410 = heff_box_i64(((int64_t)v_t_249.f[0]));
      return heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam0, 2, 4, (V[]){v_tag_2410, v_field_2411, v_field_2412, v_a_247});
    }
  } else {
    V v_t_2432 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam1, 1, 6, (V[]){heff_dup(v_lo_245), heff_dup(v_hi_246), heff_dup(v_ds_244), heff_dup(v_d_243), heff_dup(v_st_241), heff_dup(v_f_242)})})}));
    return heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam4, 2, 9, (V[]){v_t_2432, v_lo_245, v_hi_246, v_wire_240, v_st_241, v_f_242, v_d_243, heff_dup(v_ds_244), v_a_247});
  }
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7]); heff_drop(a4); return r;
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_tag_2410 = heff_env(self)[0];
  V v_field_2411 = heff_env(self)[1];
  V v_field_2412 = heff_env(self)[2];
  V v_a_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_hd_2413);
  V v_t_2418;
  if ((heff_unbox_i64(v_tag_2410) == ((int64_t)0ULL))) {
    V v_x_2416 = v_field_2411;
    V v_x12_2417 = v_field_2412;
    heff_drop(v_x12_2417);
    v_t_2418 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2416});
  } else {
    heff_drop(v_field_2411);
    heff_drop(v_field_2412);
    v_t_2418 = NTAG(TAG_Nothing);
  }
  V f_ = v_k_2414;
  args[0] = heff_rec_n(2, shape_analysis__at, (V[]){v_a_247, v_t_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_lo_245 = heff_env(self)[0];
  V v_hi_246 = heff_env(self)[1];
  V v_ds_244 = heff_env(self)[2];
  V v_d_243 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_f_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = heff_intDiv(heff_intAdd(v_lo_245, v_hi_246), MK_INT(2LL));
  HeffT3 v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = v_ds_244; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_ds_244); r_; });
  V v_t_2430;
  {
    V v_field_2425 = v_t_2423.f[1];
    V v_field_2426 = v_t_2423.f[2];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    if ((v_tag_2424 == ((int64_t)0ULL))) {
      V v_x_2428 = v_field_2425;
      V v_x12_2429 = v_field_2426;
      heff_drop(v_x12_2429);
      v_t_2430 = heff_get_n(v_x_2428, 0, 2);
    } else {
      heff_drop(v_field_2425);
      heff_drop(v_field_2426);
      v_t_2430 = heff_strLength(heff_dup(heff_rfield(v_d_243, 1)));
    }
  }
  return ({ V a_0 = v_st_241; V a_1 = v_f_242; V a_2 = v_d_243; V a_3 = v_t_2430; V a_4 = v_hd_2420; V a_5 = v_k_2421; V r_ = (g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2430); r_; });
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam3(V self, V *args) {
  V v_r_2431 = args[0];
  return v_r_2431;
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam1(V self, V *args) {
  V v_use_2419 = args[0];
  V v_lo_245 = heff_env(self)[0];
  V v_hi_246 = heff_env(self)[1];
  V v_ds_244 = heff_env(self)[2];
  V v_d_243 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_f_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_use_2419;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam2, 2, 6, (V[]){v_lo_245, v_hi_246, v_ds_244, v_d_243, v_st_241, v_f_242});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam3_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_lo_245 = heff_env(self)[0];
  V v_hi_246 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_d_243 = heff_env(self)[5];
  V v_ds_244 = heff_env(self)[6];
  V v_a_247 = heff_env(self)[7];
  V v_hd_2433 = heff_env(self)[8];
  V v_k_2434 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2435)) {
  case TAG_Left: {
    heff_take_n(v_x_2435, 0ULL, 1);
    V v_t_2437 = heff_intDiv(heff_intAdd(heff_dup(v_lo_245), v_hi_246), MK_INT(2LL));
    V v_t_2438 = ({ V a_0 = v_wire_240; V a_1 = v_st_241; V a_2 = v_f_242; V a_3 = v_d_243; V a_4 = v_ds_244; V a_5 = v_lo_245; V a_6 = v_t_2437; V a_7 = v_a_247; V r_ = (g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_ds_244); r_; });
    V f_ = v_t_2438;
    heff_room[0] = v_hd_2433;
    heff_room[1] = v_k_2434;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2439 = heff_field(v_x_2435, 0);
    heff_take_n(v_x_2435, 1ULL, 1);
    heff_drop(v_a_247);
    V v_t_2440 = heff_intDiv(heff_intAdd(v_lo_245, heff_dup(v_hi_246)), MK_INT(2LL));
    V v_t_2441 = ({ V a_0 = v_wire_240; V a_1 = v_st_241; V a_2 = v_f_242; V a_3 = v_d_243; V a_4 = v_ds_244; V a_5 = v_t_2440; V a_6 = v_hi_246; V a_7 = v_y_2439; V r_ = (g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_ds_244); r_; });
    V f_ = v_t_2441;
    heff_room[0] = v_hd_2433;
    heff_room[1] = v_k_2434;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2435);
  }
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_t_2432 = heff_env(self)[0];
  V v_lo_245 = heff_env(self)[1];
  V v_hi_246 = heff_env(self)[2];
  V v_wire_240 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_f_242 = heff_env(self)[5];
  V v_d_243 = heff_env(self)[6];
  V v_ds_244 = heff_env(self)[7];
  V v_a_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return (g_co_2eop_24s615738393x1686646143(v_t_2432, heff_dup(v_hd_2433), heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s1116279717x1391657104_lam5, 1, 10, (V[]){v_lo_245, v_hi_246, v_wire_240, v_st_241, v_f_242, v_d_243, v_ds_244, v_a_247, v_hd_2433, v_k_2434})));
}
V g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723_entry, 5, 0};

V g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723(V v_wire_240, V v_st_241, V v_x2_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_wire_240);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){v_st_241});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    V v_c_247 = (g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476(heff_dup(v_wire_240), v_st_241, heff_dup(v_f_245)));
    return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723_lam0, 1, 4, (V[]){v_wire_240, heff_dup(v_rest_246), v_z_243, v_z_244})});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_wire_240; V a_1 = v_x_248; V a_2 = v_rest_246; V a_3 = v_z_243; V a_4 = v_z_244; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_246); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotification_24s510245607x492030398_str0, 13, "textDocument/");
HEFF_LIT(g_heff_2elsp_2elsp_2enotification_24s510245607x492030398_str1, 31, "workspace/didChangeWatchedFiles");
Clo g_heff_2elsp_2elsp_2enotification_24s510245607x492030398_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotification_24s510245607x492030398_entry, 6, 0};

V g_heff_2elsp_2elsp_2enotification_24s510245607x492030398(V v_wire_240, V v_st_241, V v_m_242, V v_p_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_248;
  if (heff_strEq_c(heff_strSlice_lent(v_m_242, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_heff_2elsp_2elsp_2enotification_24s510245607x492030398_str0))) {
    v_t_248 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_st_241, 119ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  } else {
    if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotification_24s510245607x492030398_str1), 2)) {
      v_t_248 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_st_241, 119ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      v_t_248 = v_st_241;
    }
  }
  V v_t_249 = (g_heff_2elsp_2elsp_2enotified_24s374980071x891489966(v_wire_240, v_t_248, v_m_242, v_p_243));
  return heff_tail(v_t_249, 2, (V[]){v_z_244, v_z_245});
}
V g_heff_2elsp_2elsp_2enotification_24s510245607x492030398_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2enotification_24s510245607x492030398(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353_entry, 3, 0};

V g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353(V v_wire_240, V v_st_241, V v_f_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(heff_dup(heff_rfield(v_st_241, 6)), heff_dup(v_f_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353_lam0, 2, 4, (V[]){v_c_243, v_st_241, v_wire_240, v_f_242});
}
V g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_247 = heff_dup(heff_rfield(v_st_241, 3));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    return (g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950(v_wire_240, v_st_241, heff_get_n(v_x_246, 0, 6), v_f_242, v_hd_244, v_k_245));
  }
  case TAG_Just: {
    V v_pr_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_pr_248, 0)), heff_dup(heff_rfield(v_x_246, 0)))) {
      heff_drop_rec(v_x_246, 6);
      heff_drop(v_wire_240);
      heff_drop(v_f_242);
      heff_drop(v_hd_244);
      V v_t_2410 = heff_rec_n(2, shape_st__program, (V[]){v_st_241, heff_get_n(v_pr_248, 1, 2)});
      V f_ = v_k_245;
      args[0] = v_t_2410;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop_rec(v_pr_248, 2);
      return (g_heff_2elsp_2elsp_2eprojectAnew_24s986238854x2008174950(v_wire_240, v_st_241, heff_get_n(v_x_246, 0, 6), v_f_242, v_hd_244, v_k_245));
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353_lam1, 1, 5, (V[]){v_st_241, v_wire_240, v_f_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_entry, 3, 0};

V g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543(V v_wire_240, V v_st_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482(heff_dup(v_wire_240), heff_dup(v_p_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_lam0, 2, 4, (V[]){v_c_243, v_st_241, v_wire_240, v_p_242});
}
V g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_f_248 = heff_env(self)[0];
  V v_d_2413 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2416 = (g_heff_2elsp_2elsp_2etargetIn(heff_take_field(v_x_2415, 0), v_f_248, v_d_2413, v_p_242, heff_get_n(v_x_2415, 1, 2)));
  V f_ = v_k_245;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop(v_wire_240);
    heff_drop(v_hd_244);
    heff_drop(v_p_242);
    V v_t_247 = heff_rec_n(3, shape_st__off__target, (V[]){v_st_241, MK_INT(0LL), NTAG(TAG_Nothing)});
    V f_ = v_k_245;
    args[0] = v_t_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_248 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_st_241, 0), v_f_248));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_d_2413 = v_field_2411;
        V v_c_2414 = (g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353(v_wire_240, v_st_241, heff_dup(v_f_248)));
        V f_ = v_c_2414;
        heff_room[0] = v_hd_244;
        heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_lam2, 1, 4, (V[]){v_f_248, v_d_2413, v_p_242, v_k_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_wire_240);
        heff_drop(v_hd_244);
        heff_drop(v_p_242);
        heff_drop(v_f_248);
        heff_drop(v_field_2411);
        V v_t_2417 = heff_rec_n(3, shape_st__off__target, (V[]){v_st_241, MK_INT(0LL), NTAG(TAG_Nothing)});
        V f_ = v_k_245;
        args[0] = v_t_2417;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s1096701300x173464543_lam1, 1, 5, (V[]){v_st_241, v_k_245, v_wire_240, v_hd_244, v_p_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str4, 11, "placeholder");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str5, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str6, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str7, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str8, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str10, 21, "` is not written here");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str11, 1, "`");
V g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_entry, 5, 0};

V g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550(V v_wire_240, V v_id_241, V v_tg_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_tg_242, 2));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str1)})});
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str2), NTAG(TAG_JNull)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str3), v_id_241}), v_t_248});
    V v_t_2410 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_249})});
    V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2410, 1); r_; });
    V v_t_2412 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2412}));
    return (g_co_2eop_24s615738393x1686646143(v_t_2413, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_lam0, 1, 2, (V[]){v_z_244, v_tg_242})));
  }
  case TAG_Just: {
    V v_t_2415 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    HeffT2 v_t_2416 = (g_heff_2ebuild_2equery_2erenameRefused_24cpr(heff_dup(heff_rfield(v_t_2415, 1)), heff_dup(heff_rfield(v_t_2415, 2)), heff_dup(heff_rfield(v_t_2415, 2))));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        heff_drop_rec(v_t_2415, 4);
        heff_drop_cell(v_ru_24t_245_24Just, 1);
        V v_why_2420 = v_field_2418;
        V v_c_2421 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231(v_wire_240, v_id_241, MK_INT(-32803LL), v_why_2420));
        return heff_tail(v_c_2421, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_lam1, 1, 2, (V[]){v_z_244, v_tg_242})});
      } else {
        heff_drop(v_field_2418);
        HeffT2 v_t_2423 = (g_list_2efind_24s250366202x1057933814_24cpr(heff_dup(v_t_2415), heff_dup(heff_rfield(v_tg_242, 1)), heff_dup(heff_rfield(v_t_2415, 3))));
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            V v_o_2427 = v_field_2425;
            V v_t_2428 = ({ V b_0 = heff_take_field(v_o_2427, 1); V a_1 = heff_get_n(v_o_2427, 2, 4); V r_ = (g_heff_2elsp_2elsp_2erange(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2429 = heff_tag_at_n(v_ru_24t_245_24Just, TAG_JString, 1, (V[]){heff_get_n(v_t_2415, 2, 4)});
            V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str4), v_t_2429}), NTAG(TAG_Nil)});
            V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str5), v_t_2428}), v_t_2430});
            V v_result_2432 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_2431});
            V v_t_2433 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str6), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str7)})});
            V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str8), v_result_2432}), NTAG(TAG_Nil)});
            V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str9), v_id_241}), v_t_2434});
            V v_t_2436 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_t_2435})});
            V v_t_2437 = ({ V a_0 = v_t_2436; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2436, 1); r_; });
            V v_t_2438 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2437, NTAG(TAG_MkUnit)});
            V v_t_2439 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2438}));
            return (g_co_2eop_24s615738393x1686646143(v_t_2439, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_lam2, 1, 2, (V[]){v_z_244, v_tg_242})));
          } else {
            heff_drop_cell(v_ru_24t_245_24Just, 1);
            heff_drop(v_field_2425);
            V v_t_2441 = heff_strAppend(heff_get_n(v_t_2415, 2, 4), ((V)&g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str10));
            V v_c_2442 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231(v_wire_240, v_id_241, MK_INT(-32803LL), heff_strAppend(((V)&g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_str11), v_t_2441)));
            return heff_tail(v_c_2442, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_lam3, 1, 2, (V[]){v_z_244, v_tg_242})});
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V f_ = v_z_244;
  args[0] = heff_get_n(v_tg_242, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V f_ = v_z_244;
  args[0] = heff_get_n(v_tg_242, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_lam2(V self, V *args) {
  V v_x_2440 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2440);
  V f_ = v_z_244;
  args[0] = heff_get_n(v_tg_242, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s2065087742x2016306550_lam3(V self, V *args) {
  V v_x_2443 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_tg_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2443);
  V f_ = v_z_244;
  args[0] = heff_get_n(v_tg_242, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_str0, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_str1, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_str2, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_str3, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_str4, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_str5, 9, "shut down");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_str6, 6, "params");
V g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_entry, 5, 0};

V g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018(V v_wire_240, V v_st_241, V v_msg_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_246 = (g_json_2eat_24cpr(v_t_245, heff_dup(v_msg_242)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_it1_2410 = v_field_248;
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_JNull: {
        heff_drop(v_wire_240);
        heff_drop(v_msg_242);
        heff_drop(v_z_243);
        return heff_tail(v_z_244, 1, (V[]){v_st_241});
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_wire_240);
        heff_drop(v_msg_242);
        heff_drop(v_z_243);
        return heff_tail(v_z_244, 1, (V[]){v_st_241});
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_wire_240);
        heff_drop(v_msg_242);
        heff_drop(v_z_243);
        return heff_tail(v_z_244, 1, (V[]){v_st_241});
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2410, 0ULL, 1);
        heff_drop(v_wire_240);
        heff_drop(v_msg_242);
        heff_drop(v_z_243);
        return heff_tail(v_z_244, 1, (V[]){v_st_241});
      }
      case TAG_JString: {
        V v_s_2414 = heff_field(v_it1_2410, 0);
        V v_ru_24it1_2410_24JString = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_msg_242)) {
        case TAG_JNull: {
          heff_drop_cell(v_ru_24it1_2410_24JString, 1);
          v_t_2429 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_drop_cell(v_ru_24it1_2410_24JString, 1);
          v_t_2429 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_drop_cell(v_ru_24it1_2410_24JString, 1);
          v_t_2429 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_drop_cell(v_ru_24it1_2410_24JString, 1);
          v_t_2429 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          heff_drop_cell(v_ru_24it1_2410_24JString, 1);
          v_t_2429 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JArray: {
          heff_drop_cell(v_ru_24it1_2410_24JString, 1);
          v_t_2429 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          V v_fs_2420 = heff_dup(heff_field(v_msg_242, 0));
          HeffT2 v_t_2421 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_str1); V a_1 = v_fs_2420; HeffT2 r_ = (g_list_2efind_24s465947678x1101118081_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          {
            V v_field_2423 = v_t_2421.f[1];
            int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
            if ((v_tag_2422 == ((int64_t)0ULL))) {
              V v_p_2425 = v_field_2423;
              V v_t_2428;
              switch (heff_tag_of(v_p_2425)) {
              case TAG_MkPair: {
                V v_y_2427 = heff_field(v_p_2425, 1);
                heff_take_n(v_p_2425, 2ULL, 2);
                v_t_2428 = v_y_2427;
                break;
              }
              default: heff_nomatch(v_p_2425);
              }
              v_t_2429 = heff_tag_at_n(v_ru_24it1_2410_24JString, TAG_Just, 1, (V[]){v_t_2428});
            } else {
              heff_drop_cell(v_ru_24it1_2410_24JString, 1);
              heff_drop(v_field_2423);
              v_t_2429 = NTAG(TAG_Nothing);
            }
          }
          break;
        }
        default: heff_nomatch(v_msg_242);
        }
        switch (heff_tag_of(v_t_2429)) {
        case TAG_Nothing: {
          V v_t_2443;
          switch (heff_tag_of(v_msg_242)) {
          case TAG_JNull: {
            v_t_2443 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_msg_242, 0ULL, 1);
            v_t_2443 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_msg_242, 0ULL, 1);
            v_t_2443 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_msg_242, 0ULL, 1);
            v_t_2443 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_msg_242, 0ULL, 1);
            v_t_2443 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_msg_242, 0ULL, 1);
            v_t_2443 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JObject: {
            V v_fs_2435 = heff_field(v_msg_242, 0);
            heff_take_n(v_msg_242, 1ULL, 1);
            HeffT2 v_t_2436 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_str2); V a_1 = v_fs_2435; HeffT2 r_ = (g_list_2efind_24s465947678x1101118081_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
            {
              V v_field_2438 = v_t_2436.f[1];
              int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
              if ((v_tag_2437 == ((int64_t)0ULL))) {
                V v_p_2440 = v_field_2438;
                switch (heff_tag_of(v_p_2440)) {
                case TAG_MkPair: {
                  V v_y_2442 = heff_field(v_p_2440, 1);
                  heff_take_n(v_p_2440, 2ULL, 2);
                  v_t_2443 = v_y_2442;
                  break;
                }
                default: heff_nomatch(v_p_2440);
                }
              } else {
                heff_drop(v_field_2438);
                v_t_2443 = NTAG(TAG_JNull);
              }
            }
            break;
          }
          default: heff_nomatch(v_msg_242);
          }
          return ({ V a_0 = v_wire_240; V a_1 = v_st_241; V a_2 = v_s_2414; V a_3 = v_t_2443; V a_4 = v_z_243; V a_5 = v_z_244; V r_ = (g_heff_2elsp_2elsp_2enotification_24s510245607x492030398(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_s_2414); r_; });
        }
        case TAG_Just: {
          V v_id_2444 = heff_field(v_t_2429, 0);
          heff_take_n(v_t_2429, 1ULL, 1);
          V v_t_2445 = heff_dup(heff_rfield(v_st_241, 5));
          if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
            heff_drop(v_t_2445);
            if (heff_strEq_c_lent(v_s_2414, ((V)&g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_str3), 2)) {
              V v_t_2460;
              switch (heff_tag_of(v_msg_242)) {
              case TAG_JNull: {
                v_t_2460 = NTAG(TAG_JNull);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_msg_242, 0ULL, 1);
                v_t_2460 = NTAG(TAG_JNull);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_msg_242, 0ULL, 1);
                v_t_2460 = NTAG(TAG_JNull);
                break;
              }
              case TAG_JFloat: {
                heff_take_na(v_msg_242, 0ULL, 1);
                v_t_2460 = NTAG(TAG_JNull);
                break;
              }
              case TAG_JString: {
                heff_take_n(v_msg_242, 0ULL, 1);
                v_t_2460 = NTAG(TAG_JNull);
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_msg_242, 0ULL, 1);
                v_t_2460 = NTAG(TAG_JNull);
                break;
              }
              case TAG_JObject: {
                V v_fs_2452 = heff_field(v_msg_242, 0);
                heff_take_n(v_msg_242, 1ULL, 1);
                HeffT2 v_t_2453 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_str4); V a_1 = v_fs_2452; HeffT2 r_ = (g_list_2efind_24s465947678x1101118081_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
                {
                  V v_field_2455 = v_t_2453.f[1];
                  int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
                  if ((v_tag_2454 == ((int64_t)0ULL))) {
                    V v_p_2457 = v_field_2455;
                    switch (heff_tag_of(v_p_2457)) {
                    case TAG_MkPair: {
                      V v_y_2459 = heff_field(v_p_2457, 1);
                      heff_take_n(v_p_2457, 2ULL, 2);
                      v_t_2460 = v_y_2459;
                      break;
                    }
                    default: heff_nomatch(v_p_2457);
                    }
                  } else {
                    heff_drop(v_field_2455);
                    v_t_2460 = NTAG(TAG_JNull);
                  }
                }
                break;
              }
              default: heff_nomatch(v_msg_242);
              }
              return (g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031(v_wire_240, v_st_241, v_s_2414, v_id_2444, v_t_2460, v_z_243, v_z_244));
            } else {
              heff_drop(v_msg_242);
              heff_drop(v_s_2414);
              V v_c_2461 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231(v_wire_240, v_id_2444, MK_INT(-32600LL), ((V)&g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_str5)));
              return heff_tail(v_c_2461, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_lam0, 1, 2, (V[]){v_z_244, v_st_241})});
            }
          } else {
            heff_drop(v_t_2445);
            V v_t_2476;
            switch (heff_tag_of(v_msg_242)) {
            case TAG_JNull: {
              v_t_2476 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JBool: {
              heff_take_n(v_msg_242, 0ULL, 1);
              v_t_2476 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JInt: {
              heff_take_n(v_msg_242, 0ULL, 1);
              v_t_2476 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JFloat: {
              heff_take_na(v_msg_242, 0ULL, 1);
              v_t_2476 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JString: {
              heff_take_n(v_msg_242, 0ULL, 1);
              v_t_2476 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JArray: {
              heff_take_n(v_msg_242, 0ULL, 1);
              v_t_2476 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JObject: {
              V v_fs_2468 = heff_field(v_msg_242, 0);
              heff_take_n(v_msg_242, 1ULL, 1);
              HeffT2 v_t_2469 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_str6); V a_1 = v_fs_2468; HeffT2 r_ = (g_list_2efind_24s465947678x1101118081_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
              {
                V v_field_2471 = v_t_2469.f[1];
                int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
                if ((v_tag_2470 == ((int64_t)0ULL))) {
                  V v_p_2473 = v_field_2471;
                  switch (heff_tag_of(v_p_2473)) {
                  case TAG_MkPair: {
                    V v_y_2475 = heff_field(v_p_2473, 1);
                    heff_take_n(v_p_2473, 2ULL, 2);
                    v_t_2476 = v_y_2475;
                    break;
                  }
                  default: heff_nomatch(v_p_2473);
                  }
                } else {
                  heff_drop(v_field_2471);
                  v_t_2476 = NTAG(TAG_JNull);
                }
              }
              break;
            }
            default: heff_nomatch(v_msg_242);
            }
            return (g_heff_2elsp_2elsp_2erequest_24s1848332288x1048526031(v_wire_240, v_st_241, v_s_2414, v_id_2444, v_t_2476, v_z_243, v_z_244));
          }
        }
        default: return heff_nomatch(v_t_2429);
        }
      }
      case TAG_JArray: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_wire_240);
        heff_drop(v_msg_242);
        heff_drop(v_z_243);
        return heff_tail(v_z_244, 1, (V[]){v_st_241});
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop(v_wire_240);
        heff_drop(v_msg_242);
        heff_drop(v_z_243);
        return heff_tail(v_z_244, 1, (V[]){v_st_241});
      }
      default: return heff_nomatch(v_it1_2410);
      }
    } else {
      heff_drop(v_wire_240);
      heff_drop(v_msg_242);
      heff_drop(v_z_243);
      heff_drop(v_field_248);
      return heff_tail(v_z_244, 1, (V[]){v_st_241});
    }
  }
}
V g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2ehandle_24s1332368419x1627367018_lam0(V self, V *args) {
  V v_x_2462 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2462);
  V f_ = v_z_244;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_str0, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_str1, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_str2, 2, " (");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_str3, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_str4, 22, "heff failed answering ");
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam0, 2, 0};
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam1, 2, 0};
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam2, 2, 0};
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam3, 2, 0};
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam4, 2, 0};
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam5, 2, 0};
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam6, 2, 0};
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam7(V self, V *args); static Clo g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam7, 2, 0};
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam10(V self, V *args);
Clo g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_entry, 4, 0};

V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543(V v_wire_240, V v_st_241, V v_msg_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Left: {
    V v_why_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Left = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    V v_x1_2419;
    switch (heff_tag_of(v_msg_242)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24x3_243_24Left, 1);
      v_x1_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_drop_cell(v_ru_24x3_243_24Left, 1);
      v_x1_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_drop_cell(v_ru_24x3_243_24Left, 1);
      v_x1_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_drop_cell(v_ru_24x3_243_24Left, 1);
      v_x1_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_drop_cell(v_ru_24x3_243_24Left, 1);
      v_x1_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_drop_cell(v_ru_24x3_243_24Left, 1);
      v_x1_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_2410 = heff_dup(heff_field(v_msg_242, 0));
      HeffT2 v_t_2411 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_str0); V a_1 = v_fs_2410; HeffT2 r_ = (g_list_2efind_24s465947678x1101118081_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_p_2415 = v_field_2413;
          V v_t_2418;
          switch (heff_tag_of(v_p_2415)) {
          case TAG_MkPair: {
            V v_y_2417 = heff_field(v_p_2415, 1);
            heff_take_n(v_p_2415, 2ULL, 2);
            v_t_2418 = v_y_2417;
            break;
          }
          default: heff_nomatch(v_p_2415);
          }
          v_x1_2419 = heff_tag_at_n(v_ru_24x3_243_24Left, TAG_Just, 1, (V[]){v_t_2418});
        } else {
          heff_drop_cell(v_ru_24x3_243_24Left, 1);
          heff_drop(v_field_2413);
          v_x1_2419 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_msg_242);
    }
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_str1), NTAG(TAG_Nil)});
    HeffT2 v_t_2421 = (g_json_2eat_24cpr(v_t_2420, v_msg_242));
    {
      V v_field_2423 = v_t_2421.f[1];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      V v_c_2451;
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_Nothing: {
        heff_drop(v_wire_240);
        heff_drop(v_why_244);
        heff_drop(v_field_2423);
        v_c_2451 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam0_clo);
        break;
      }
      case TAG_Just: {
        V v_id_2426 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        if ((v_tag_2422 == ((int64_t)0ULL))) {
          V v_it1_2428 = v_field_2423;
          switch (heff_tag_of(v_it1_2428)) {
          case TAG_JNull: {
            heff_drop(v_wire_240);
            heff_drop(v_why_244);
            heff_drop(v_id_2426);
            v_c_2451 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam1_clo);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2428, 0ULL, 1);
            heff_drop(v_wire_240);
            heff_drop(v_why_244);
            heff_drop(v_id_2426);
            v_c_2451 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam2_clo);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2428, 0ULL, 1);
            heff_drop(v_wire_240);
            heff_drop(v_why_244);
            heff_drop(v_id_2426);
            v_c_2451 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam3_clo);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2428, 0ULL, 1);
            heff_drop(v_wire_240);
            heff_drop(v_why_244);
            heff_drop(v_id_2426);
            v_c_2451 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam4_clo);
            break;
          }
          case TAG_JString: {
            V v_s_2440 = heff_field(v_it1_2428, 0);
            heff_take_n(v_it1_2428, 1ULL, 1);
            V v_t_2441 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_str2), heff_strAppend(v_why_244, ((V)&g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_str3)));
            V v_t_2442 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_str4), heff_strAppend(v_s_2440, v_t_2441));
            v_c_2451 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1134237454x2127531231(v_wire_240, v_id_2426, MK_INT(-32603LL), v_t_2442));
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2428, 0ULL, 1);
            heff_drop(v_wire_240);
            heff_drop(v_why_244);
            heff_drop(v_id_2426);
            v_c_2451 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam5_clo);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2428, 0ULL, 1);
            heff_drop(v_wire_240);
            heff_drop(v_why_244);
            heff_drop(v_id_2426);
            v_c_2451 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam6_clo);
            break;
          }
          default: heff_nomatch(v_it1_2428);
          }
        } else {
          heff_drop(v_wire_240);
          heff_drop(v_why_244);
          heff_drop(v_field_2423);
          heff_drop(v_id_2426);
          v_c_2451 = ((V)&g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam7_clo);
        }
        break;
      }
      default: heff_nomatch(v_x1_2419);
      }
      return heff_clo_n(g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam8, 2, 2, (V[]){v_c_2451, v_st_241});
    }
  }
  case TAG_Right: {
    V v_st2_2455 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    heff_drop(v_wire_240);
    heff_drop(v_st_241);
    heff_drop(v_msg_242);
    return heff_clo_n(g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam10, 2, 1, (V[]){v_st2_2455});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam0(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam1(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam2(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  heff_drop(v_hd_2432);
  V f_ = v_k_2433;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam3(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam4(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam5(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam6(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  heff_drop(v_hd_2447);
  V f_ = v_k_2448;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam7(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  heff_drop(v_hd_2449);
  V f_ = v_k_2450;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_k_2453 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2454);
  V f_ = v_k_2453;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam8(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k_2453 = args[1];
  V v_c_2451 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2451;
  args[0] = v_hd_2452;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam9, 1, 2, (V[]){v_k_2453, v_st_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ehandled_24s507326626x464862543_lam10(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_st2_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2456);
  V f_ = v_k_2457;
  args[0] = v_st2_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}