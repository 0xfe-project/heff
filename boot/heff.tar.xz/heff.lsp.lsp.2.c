// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Closed 4831
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Message 12631
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_Quit 47258
#define TAG_Right 62770
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Send 26077
#define TAG_Timeout 14063
#define LBL_checked 974171621
#define LBL_code 9554612
#define LBL_defines 1776893014
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_occurrences 673885394
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_severity 75955546
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_st__text__program[] = {LBL_st, LBL_text, LBL_program};
static uint32_t shape_uri__text[] = {LBL_uri, LBL_text};
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2edriver_2etraceless(V);
V g_heff_2ebuild_2edriver_2etraceless_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etraceless_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
V g_heff_2ebuild_2equery_2ecompletionsAt(V, V);
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo;
HeffT2 g_heff_2ebuild_2equery_2edefinitionAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2edocMarkdown(V);
V g_heff_2ebuild_2equery_2edocMarkdown_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMarkdown_clo;
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
HeffT2 g_heff_2ebuild_2equery_2etypeAt_24cpr(V, V);
V g_heff_2elsp_2elsp_2ebrokenImport(V, V);
V g_heff_2elsp_2elsp_2ebrokenImport_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ebrokenImport_clo;
V g_heff_2elsp_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2elsp_2ecatMaybesL(V);
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V, V);
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo;
V g_heff_2elsp_2elsp_2echanged(V, V, V);
V g_heff_2elsp_2elsp_2echanged_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echanged_clo;
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895(V, V, V);
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_clo;
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306(V, V);
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192(V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192_clo;
V g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039(V, V);
V g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806(V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_clo;
V g_heff_2elsp_2elsp_2eclosed(V, V);
V g_heff_2elsp_2elsp_2eclosed_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclosed_clo;
V g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314(V, V);
V g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070(V);
V g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070_clo;
V g_heff_2elsp_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119(V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119_clo;
V g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_clo;
V g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578(V, V);
V g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_clo;
V g_heff_2elsp_2elsp_2ehoverOf(V, V);
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
HeffT2 g_heff_2elsp_2elsp_2elastChange_24cpr(V);
V g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958(V, V);
V g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689(V, V, V);
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubRoots(V);
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_clo;
V g_heff_2elsp_2elsp_2enubRoots_24dps(V, V);
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources_24dps(V, V);
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140(V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140_clo;
V g_heff_2elsp_2elsp_2eproject_24s531222994x597819115(V, V);
V g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eproject_24s531222994x597819115_clo;
V g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452(V, V);
V g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_clo;
V g_heff_2elsp_2elsp_2epublish_24s450272378x127963581(V, V);
V g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2eregistration_get(void);
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390(V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057(V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057_clo;
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086(V, V, V, V);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_clo;
V g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819(V, V);
V g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_clo;
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510(V, V, V);
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_clo;
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371(V, V, V);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371_clo;
V g_heff_2elsp_2elsp_2eunits16Go(V, V, V, V);
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eunits16Go_clo;
V g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576(V, V);
V g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_clo;
V g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230(V, V);
V g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2erepeated(V, V);
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_clo;
V g_heff_2elsp_2erpc_2eawait_24s1780555806x701913170(V, V, V);
V g_heff_2elsp_2erpc_2eawait_24s1780555806x701913170_entry(V self, V *a);
extern Clo g_heff_2elsp_2erpc_2eawait_24s1780555806x701913170_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_24cpr(V, V);
V g_heff_2esyntax_2eformat_2emeaningFrom(V);
V g_heff_2esyntax_2eformat_2emeaningFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2emeaningFrom_clo;
V g_heff_2esyntax_2eformat_2esameMeaning(V, V, V, V);
V g_heff_2esyntax_2eformat_2esameMeaning_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2esameMeaning_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eany_24s384244645x1082490665(V, V);
V g_list_2eany_24s384244645x1082490665_entry(V self, V *a);
extern Clo g_list_2eany_24s384244645x1082490665_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1064353769x1815078842(V);
V g_list_2efilter_24s1064353769x1815078842_entry(V self, V *a);
extern Clo g_list_2efilter_24s1064353769x1815078842_clo;
V g_list_2efilter_24s1351460748x1231260144(V, V);
V g_list_2efilter_24s1351460748x1231260144_entry(V self, V *a);
extern Clo g_list_2efilter_24s1351460748x1231260144_clo;
V g_list_2efilter_24s1392550889x861369760(V, V);
V g_list_2efilter_24s1392550889x861369760_entry(V self, V *a);
extern Clo g_list_2efilter_24s1392550889x861369760_clo;
V g_list_2efilter_24s316268077x2111002396(V, V);
V g_list_2efilter_24s316268077x2111002396_entry(V self, V *a);
extern Clo g_list_2efilter_24s316268077x2111002396_clo;
V g_list_2efilter_24s951260806x709953240(V, V);
V g_list_2efilter_24s951260806x709953240_entry(V self, V *a);
extern Clo g_list_2efilter_24s951260806x709953240_clo;
HeffT2 g_list_2efind_24s1637307977x1351693783_24cpr(V, V, V, V, V, V);
HeffT2 g_list_2efind_24s465947678x1101118081_24cpr(V, V);
HeffT2 g_list_2efind_24s727666736x1458251130_24cpr(V, V);
V g_list_2efoldl_24f1046331721x1909432377(V, V, V);
V g_list_2efoldl_24f1046331721x1909432377_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1046331721x1909432377_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s361191175x1417189158(V, V);
V g_list_2efoldl_24s361191175x1417189158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s361191175x1417189158_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s4199228x1154005405(V);
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f738852651x284559611(V, V);
V g_prelude_2e_2b_2b_24f738852651x284559611_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f738852651x284559611_clo;
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;

static V g_heff_2elsp_2elsp_2ejfalse_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejfalse_st;
static V g_heff_2elsp_2elsp_2ejfalse_init(void) {
  return heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2elsp_2elsp_2ejfalse_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejfalse_st)) return g_heff_2elsp_2elsp_2ejfalse_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejfalse_val, &g_heff_2elsp_2elsp_2ejfalse_st, g_heff_2elsp_2elsp_2ejfalse_init);
}
Clo g_heff_2elsp_2elsp_2eunits16Go_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eunits16Go_entry, 4, 0};

V g_heff_2elsp_2elsp_2eunits16Go(V v_src_240, V v_i_241, V v_j_242, V v_n_243) {
top: ;
  if (heff_intLe_c_lent(v_j_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return v_n_243;
  } else {
    if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241))) {
      heff_drop(v_i_241);
      heff_drop(v_j_242);
      return v_n_243;
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) < ((int64_t)128ULL))) {
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_j_242;
        V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_n_243 = t_3;
        goto top;
      } else {
        V v_t_247 = heff_intAdd(heff_dup(v_i_241), heff_strRuneWidth_lent(v_src_240, v_i_241, 0));
        V v_t_248 = heff_runeToInt(heff_strRuneAt_lent(v_src_240, v_i_241, 2));
        V v_t_2410;
        if (heff_intLe_c(MK_INT(65536LL), v_t_248)) {
          v_t_2410 = MK_INT(2LL);
        } else {
          v_t_2410 = MK_INT(1LL);
        }
        V t_0 = v_src_240;
        V t_1 = v_t_247;
        V t_2 = v_j_242;
        V t_3 = heff_intAdd(v_n_243, v_t_2410);
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_n_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eunits16Go(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2eoffsetGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetGo_entry, 5, 0};

V g_heff_2elsp_2elsp_2eoffsetGo(V v_src_240, V v_line_241, V v_ch_242, V v_i_243, V v_l_244) {
top: ;
  if (heff_intLe_c_lent(v_line_241, v_l_244, 0)) {
    heff_drop(v_line_241);
    heff_drop(v_l_244);
    V v_j_246 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str0), v_src_240, v_i_243, 1);
    V v_t_248;
    if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
      heff_drop(v_j_246);
      v_t_248 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_248 = v_j_246;
    }
    return (g_heff_2elsp_2elsp_2eoffset16(v_src_240, v_i_243, v_t_248, v_ch_242));
  } else {
    V v_j_249 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str1), v_src_240, v_i_243, 5);
    if (heff_intLt_c_lent(v_j_249, MK_INT(0LL), 2)) {
      heff_drop(v_line_241);
      heff_drop(v_ch_242);
      heff_drop(v_l_244);
      heff_drop(v_j_249);
      return heff_strLength_lent(v_src_240, 0);
    } else {
      V t_0 = v_src_240;
      V t_1 = v_line_241;
      V t_2 = v_ch_242;
      V t_3 = heff_intAdd(v_j_249, MK_INT(1LL));
      V t_4 = heff_intAdd(v_l_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_line_241 = t_1;
      v_ch_242 = t_2;
      v_i_243 = t_3;
      v_l_244 = t_4;
      goto top;
    }
  }
}
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffsetGo(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str0, 8, "severity");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str1, 6, "source");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str2, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str3, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str4, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str5, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str6, 1, "E");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str7, 1, "W");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str8, 1, "D");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str9, 1, "0");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str10, 4, "code");
Clo g_heff_2elsp_2elsp_2ediagnostic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagnostic_entry, 2, 0};

V g_heff_2elsp_2elsp_2ediagnostic(V v_src_240, V v_d_241) {
top: ;
  V v_t_242 = (g_heff_2elsp_2elsp_2erange(v_src_240, heff_take_field(v_d_241, 3)));
  V v_t_243 = heff_dup(heff_rfield(v_d_241, 1));
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SError: {
    v_t_244 = MK_INT(1LL);
    break;
  }
  case TAG_SWarning: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_SDebug: {
    v_t_244 = MK_INT(4LL);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str0), heff_tag_n(TAG_JInt, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str1), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str2)})});
  V v_t_247 = heff_take_field(v_d_241, 4);
  V v_t_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    v_t_249 = heff_dup(heff_rfield(v_d_241, 2));
    break;
  }
  case TAG_Just: {
    V v_n_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 2)), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ediagnostic_str3), v_n_248));
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str4), heff_tag_n(TAG_JString, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str5), v_t_242}), v_t_2412});
  V v_t_2422;
  if (heff_intEq_c(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL))) {
    heff_drop_rec(v_d_241, 5);
    v_t_2422 = NTAG(TAG_Nil);
  } else {
    V v_t_2415 = heff_take_field(v_d_241, 1);
    V v_t_2416;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_SError: {
      v_t_2416 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str6);
      break;
    }
    case TAG_SWarning: {
      v_t_2416 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str7);
      break;
    }
    case TAG_SDebug: {
      v_t_2416 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str8);
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    V v_t_2417 = (g_heff_2elsp_2erender_2enumDigits(heff_dup(heff_rfield(v_d_241, 0))));
    V v_t_2418 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_2417), ((V)&g_heff_2elsp_2elsp_2ediagnostic_str9)));
    V v_t_2419 = heff_intShow(heff_get_n(v_d_241, 0, 5));
    V v_t_2420 = heff_strAppend(v_t_2416, heff_strAppend(v_t_2418, v_t_2419));
    V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str10), heff_tag_n(TAG_JString, 1, (V[]){v_t_2420})});
    v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  }
  V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2422));
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2423});
}
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ediagnostic(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str1, 1, "s");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str2, 6, " error");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str3, 22, ") does not elaborate: ");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str4, 2, " (");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str5, 7, "module ");
Clo g_heff_2elsp_2elsp_2ebrokenImport_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ebrokenImport_entry, 2, 0};

V g_heff_2elsp_2elsp_2ebrokenImport(V v_imports_240, V v_c_241) {
top: ;
  V v_x1_242 = (g_list_2efilter_24s1064353769x1815078842(heff_dup(heff_rfield(v_c_241, 6))));
  V v_t_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_242, 0ULL, 2);
    v_t_245 = (g_list_2eany_24s384244645x1082490665(heff_dup(v_c_241), v_imports_240));
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    HeffT2 v_t_246 = (g_list_2efind_24s727666736x1458251130_24cpr(heff_rfield(v_c_241, 0), v_imports_240));
    V v_sp_2411;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_i_2410 = v_field_248;
        v_sp_2411 = heff_get_n(v_i_2410, 2, 3);
      } else {
        heff_drop(v_field_248);
        v_sp_2411 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
      }
    }
    V v_t_2412 = (g_list_2efoldl_24f1046331721x1909432377(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 6)));
    V v_t_2413 = (g_list_2efoldl_24f1046331721x1909432377(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 6)));
    V v_t_2415;
    if (heff_intEq_c(v_t_2413, MK_INT(1LL))) {
      v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ebrokenImport_str0);
    } else {
      v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ebrokenImport_str1);
    }
    V v_t_2416 = heff_strAppend(heff_intShow(v_t_2412), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str2), v_t_2415));
    V v_t_2417 = heff_strAppend(heff_take_field(v_c_241, 1), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str3), v_t_2416));
    V v_t_2418 = heff_strAppend(heff_get_n(v_c_241, 0, 13), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str4), v_t_2417));
    V v_msg_2419 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str5), v_t_2418);
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SWarning), v_msg_2419, v_sp_2411, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
  } else {
    heff_drop(v_imports_240);
    heff_drop_rec(v_c_241, 13);
    heff_drop(v_t_245);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2elsp_2elsp_2ebrokenImport_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ebrokenImport(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecatMaybesL_entry, 1, 0};

V g_heff_2elsp_2elsp_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2elsp_2elsp_2ecatMaybesL_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecatMaybesL(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str1, 1, " ");
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ediagsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagsOf_entry, 3, 0};

V g_heff_2elsp_2elsp_2ediagsOf(V v_src_240, V v_program_241, V v_errors_242) {
top: ;
  V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_241)));
  V v_t_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    v_t_246 = heff_get_n(v_x_244, 6, 13);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam0, 1, 1, (V[]){heff_dup(v_src_240)}), v_errors_242));
  V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_241));
  V v_xs_2418 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2417; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2418));
  V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam1, 1, 1, (V[]){v_src_240}), v_t_2419));
  V v_t_2423 = (g_heff_2elsp_2elsp_2ecatMaybesL(v_t_2422));
  V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2423));
  return (g_prelude_2e_2b_2b(v_t_246, v_t_2424));
}
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ediagsOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_imports_249 = heff_get_n(v_t_248, 0, 3);
  HeffT2 v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str0); V a_2 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str1); V a_3 = v_e_247; V b_4 = MK_INT(0LL); V a_5 = v_imports_249; HeffT2 r_ = (g_list_2efind_24s1637307977x1351693783_24cpr(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(b_4); r_; });
  V v_sp_2415;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_i_2414 = v_field_2412;
      v_sp_2415 = heff_get_n(v_i_2414, 2, 3);
    } else {
      heff_drop(v_field_2412);
      v_sp_2415 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
    }
  }
  return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_e_247, v_sp_2415, NTAG(TAG_Nothing)});
}
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args) {
  V v_c_2420 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = (g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
  return (g_heff_2elsp_2elsp_2ebrokenImport(heff_get_n(v_t_2421, 0, 3), v_c_2420));
}
Clo g_heff_2elsp_2elsp_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeptOf_entry, 1, 0};

V g_heff_2elsp_2elsp_2ekeptOf(V v_program_240) {
top: ;
  V v_x1_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_240)));
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_program_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2edriver_2etraceless(v_x_242));
    V v_t_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
    V v_xs_247 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_246; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_247));
    return (g_prelude_2e_2b_2b_24f738852651x284559611(v_t_245, v_t_248));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ekeptOf(a[0]);
}
Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubSources_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_ss_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_s_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2efilter_24s1392550889x861369760(v_s_242, v_ss_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubSources_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str0, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str1, 8, "markdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str2, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str3, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str4, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str5, 4, "\012```");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str6, 11, "\012```\012\012---\012\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str7, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str8, 5, "value");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str9, 8, "contents");
Clo g_heff_2elsp_2elsp_2ehoverOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehoverOf_entry, 2, 0};

V g_heff_2elsp_2elsp_2ehoverOf(V v_a_240, V v_p_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_a_240, 2))));
  V v_t_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){v_x_243});
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop_rec(v_a_240, 3);
    heff_drop(v_p_241);
    return NTAG(TAG_JNull);
  }
  case TAG_Just: {
    V v_c_246 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    V v_t_247 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_a_240, 1), heff_dup(v_p_241)));
    HeffT2 v_t_248 = (g_heff_2ebuild_2equery_2etypeAt_24cpr(v_c_246, v_t_247));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_t_2412 = v_field_2410;
        V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str0), heff_tag_at_n(v_ru_24t_245_24Just, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str1)})});
        V v_off_2414 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_a_240, 1), v_p_241));
        HeffT2 v_t_2415 = (g_heff_2ebuild_2equery_2edefinitionAt_24cpr(heff_get_n(v_a_240, 2, 3), v_off_2414));
        V v_doc_2425;
        {
          V v_field_2417 = v_t_2415.f[1];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_d_2419 = v_field_2417;
            V v_t_2420 = heff_get_n(heff_dup(heff_rfield(v_d_2419, 2)), 0, 2);
            V v_start_2421 = (g_heff_2ebuild_2equery_2elineStartOf(heff_rfield(v_d_2419, 1), v_t_2420));
            V v_t_2422 = ({ V b_0 = heff_get_n(v_d_2419, 1, 3); V a_1 = v_start_2421; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ecommentAbove(b_0, a_1, a_2)); heff_drop(b_0); r_; });
            V v_t_2423 = (g_list_2emap_24s1819241345x1511673126(v_t_2422));
            V v_t_2424 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2423));
            v_doc_2425 = ({ V a_0 = v_t_2424; V r_ = (g_heff_2ebuild_2equery_2edocMarkdown(a_0)); heff_drop(v_t_2424); r_; });
          } else {
            heff_drop(v_field_2417);
            v_doc_2425 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str2);
          }
        }
        V v_t_2428;
        if (heff_strEq_c_lent(v_doc_2425, ((V)&g_heff_2elsp_2elsp_2ehoverOf_str3), 2)) {
          heff_drop(v_doc_2425);
          v_t_2428 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str4), heff_strAppend(v_t_2412, ((V)&g_heff_2elsp_2elsp_2ehoverOf_str5)));
        } else {
          V v_t_2427 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str6), v_doc_2425));
          v_t_2428 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str7), v_t_2427);
        }
        V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str8), heff_tag_n(TAG_JString, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
        V v_t_2431 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2430})});
        V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str9), v_t_2431}), NTAG(TAG_Nil)});
        return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2432});
      } else {
        heff_drop_rec(v_a_240, 3);
        heff_drop(v_p_241);
        heff_drop_cell(v_ru_24t_245_24Just, 1);
        heff_drop(v_field_2410);
        return NTAG(TAG_JNull);
      }
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehoverOf(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_cs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_241), heff_hole()});
    V v_t_244 = (g_list_2efilter_24s316268077x2111002396(v_c_241, v_cs_242));
    V v_u_245 = (g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubCheckedPaths(a[0]);
}
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2efilter_24s316268077x2111002396(v_c_242, v_cs_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubRoots_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_r_242; V a_1 = v_rs_243; V r_ = (g_list_2efilter_24s951260806x709953240(a_0, a_1)); heff_drop(v_r_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubRoots_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str2, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str3, 10, "heff-watch");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str4, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str5, 25, "client/registerCapability");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str6, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str7, 10, "heff-watch");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str8, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str9, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str10, 11, "globPattern");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str11, 7, "**/*.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str12, 8, "watchers");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str13, 15, "registerOptions");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str14, 13, "registrations");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str15, 6, "params");

static V g_heff_2elsp_2elsp_2eregistration_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2eregistration_st;
static V g_heff_2elsp_2elsp_2eregistration_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str1)})});
  V v_t_241 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str2), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str3)})});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str4), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str5)})});
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str6), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str7)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str8), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str9)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str10), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str11)})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_246}), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str12), heff_tag_n(TAG_JArray, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str13), heff_tag_n(TAG_JObject, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str14), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str15), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_2417})});
  return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_2418})});
}
V g_heff_2elsp_2elsp_2eregistration_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2eregistration_st)) return g_heff_2elsp_2elsp_2eregistration_val;
  return heff_global(&g_heff_2elsp_2elsp_2eregistration_val, &g_heff_2elsp_2elsp_2eregistration_st, g_heff_2elsp_2elsp_2eregistration_init);
}
Clo g_heff_2elsp_2elsp_2echanged_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echanged_entry, 3, 0};

V g_heff_2elsp_2elsp_2echanged(V v_st_240, V v_f_241, V v_text_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_240, 0), v_f_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_d_247 = v_field_245;
      V v_t_248 = ({ V rv_1 = v_text_242; V rr_ = heff_rec_reuse_nf(v_d_247, 1ULL, 2, shape_uri__text, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_d_249 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_st_240, 0), v_f_241, v_t_248));
      return ({ V rv_0 = v_d_249; V rr_ = heff_rec_reuse_nf(v_st_240, 126ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16380u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    } else {
      heff_drop(v_f_241);
      heff_drop(v_text_242);
      heff_drop(v_field_245);
      return v_st_240;
    }
  }
}
V g_heff_2elsp_2elsp_2echanged_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echanged(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_str2, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_str3, 31, "textDocument/publishDiagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_str4, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_str5, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_str6, 6, "params");
Clo g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_entry, 2, 0};

V g_heff_2elsp_2elsp_2epublish_24s450272378x127963581(V v_uri_240, V v_ds_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_str1)})});
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_str2), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_str3)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_str4), heff_tag_n(TAG_JString, 1, (V[]){v_uri_240})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_str5), heff_tag_n(TAG_JArray, 1, (V[]){v_ds_241})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_str6), v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_248})});
  V v_t_2410 = ({ V b_0 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_249}); V r_ = (g_json_2estringify(b_0)); heff_drop(b_0); r_; });
  V v_a_2411 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return heff_tail(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){v_t_2415});
}
V g_heff_2elsp_2elsp_2epublish_24s450272378x127963581_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2epublish_24s450272378x127963581(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str0, 4, "exit");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str1, 11, "initialized");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str2, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str3, 20, "textDocument/didOpen");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str4, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str5, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str6, 4, "text");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str7, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str11, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str12, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str13, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str14, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str15, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str16, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str17, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str18, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str19, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str20, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str21, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str22, 22, "textDocument/didChange");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str23, 20, "textDocument/didSave");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str24, 21, "textDocument/didClose");
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam3, 1, 0};
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam5, 2, 0};
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_entry, 3, 0};

V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689(V v_st_240, V v_m_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070(heff_dup(v_p_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam0, 2, 4, (V[]){v_c_243, heff_dup(v_m_241), v_st_240, v_p_242});
}
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam3(V self, V *args) {
  V v_n_2464 = args[0];
  return v_n_2464;
}
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam4(V self, V *args) {
  V v_x_2469 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_2426 = heff_env(self)[1];
  V v_text_2463 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2470 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_dup(heff_rfield(v_st_240, 2)), heff_dup(v_f_2426), heff_intAdd(v_x_2469, MK_INT(200LL))));
  V v_s_2471 = (g_heff_2elsp_2elsp_2echanged(v_st_240, v_f_2426, v_text_2463));
  V v_t_2472 = ({ V rv_2 = v_t_2470; V rr_ = heff_rec_reuse_nf(v_s_2471, 123ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16335u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_k_245;
  args[0] = v_t_2472;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam5(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k_2482 = args[1];
  heff_drop(v_hd_2481);
  V f_ = v_k_2482;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam6(V self, V *args) {
  V v_x_2484 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_2426 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2484);
  V v_x_2485 = ({ V a_0 = v_st_240; V a_1 = v_f_2426; V r_ = (g_heff_2elsp_2elsp_2eclosed(a_0, a_1)); heff_drop(v_f_2426); r_; });
  V f_ = v_k_245;
  args[0] = v_x_2485;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str0), 2)) {
    heff_drop(v_x_246);
    heff_drop(v_m_241);
    heff_drop(v_p_242);
    V v_t_248 = heff_get_n(v_st_240, 5, 7);
    V v_t_249;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      v_t_249 = MK_INT(0LL);
    } else {
      heff_drop(v_t_248);
      v_t_249 = MK_INT(1LL);
    }
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), v_hd_244, v_k_245));
  } else {
    if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str1), 2)) {
      heff_drop(v_x_246);
      heff_drop(v_m_241);
      heff_drop(v_p_242);
      V v_t_2415 = heff_dup(heff_rfield(v_st_240, 4));
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        V v_t_2416 = ({ V b_0 = heff_dup(g_heff_2elsp_2elsp_2eregistration_get()); V r_ = (g_json_2estringify(b_0)); heff_drop(b_0); r_; });
        V v_a_2417 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
        V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2417})});
        V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
        V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
        V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
        return (g_co_2eop_24s94900133x232571340(v_t_2421, v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam2, 1, 2, (V[]){v_k_245, v_st_240})));
      } else {
        heff_drop(v_hd_244);
        heff_drop(v_t_2415);
        V f_ = v_k_245;
        args[0] = v_st_240;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    } else {
      if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str2), 2)) {
        heff_drop(v_x_246);
        heff_drop(v_m_241);
        heff_drop(v_p_242);
        V v_t_2424 = (g_std_2emap_2etoListOnto(heff_rfield(v_st_240, 0), NTAG(TAG_Nil)));
        V v_t_2425 = (g_list_2emap_24s1415906091x1371825187(v_t_2424));
        return ({ V a_0 = v_st_240; V a_1 = v_t_2425; V a_2 = v_hd_244; V a_3 = v_k_245; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192(a_0, a_1, a_2, a_3)); heff_drop(v_t_2425); r_; });
      } else {
        switch (heff_tag_of(v_x_246)) {
        case TAG_Nothing: {
          heff_drop(v_m_241);
          heff_drop(v_hd_244);
          heff_drop(v_p_242);
          V f_ = v_k_245;
          args[0] = v_st_240;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_Just: {
          V v_f_2426 = heff_field(v_x_246, 0);
          V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
          if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str3), 2)) {
            heff_drop(v_m_241);
            heff_drop_cell(v_ru_24x_246_24Just, 1);
            V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str4), NTAG(TAG_Nil)});
            HeffT2 v_t_2429 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str5), v_t_2428}), heff_dup(v_p_242)));
            V v_t_2454;
            {
              V v_field_2431 = v_t_2429.f[1];
              int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
              V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str6), NTAG(TAG_Nil)});
              HeffT2 v_t_2433 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str7), v_t_2432}), v_p_242));
              {
                V v_field_2435 = v_t_2433.f[1];
                int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
                V v_t_2444;
                if ((v_tag_2430 == ((int64_t)0ULL))) {
                  V v_it1_2437 = v_field_2431;
                  switch (heff_tag_of(v_it1_2437)) {
                  case TAG_JNull: {
                    v_t_2444 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str8);
                    break;
                  }
                  case TAG_JBool: {
                    heff_take_n(v_it1_2437, 0ULL, 1);
                    v_t_2444 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str9);
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2437, 0ULL, 1);
                    v_t_2444 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str10);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2437, 0ULL, 1);
                    v_t_2444 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str11);
                    break;
                  }
                  case TAG_JString: {
                    V v_s_2441 = heff_field(v_it1_2437, 0);
                    heff_take_n(v_it1_2437, 1ULL, 1);
                    v_t_2444 = v_s_2441;
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2437, 0ULL, 1);
                    v_t_2444 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str12);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2437, 0ULL, 1);
                    v_t_2444 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str13);
                    break;
                  }
                  default: heff_nomatch(v_it1_2437);
                  }
                } else {
                  heff_drop(v_field_2431);
                  v_t_2444 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str14);
                }
                V v_t_2453;
                if ((v_tag_2434 == ((int64_t)0ULL))) {
                  V v_it1_2446 = v_field_2435;
                  switch (heff_tag_of(v_it1_2446)) {
                  case TAG_JNull: {
                    v_t_2453 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str15);
                    break;
                  }
                  case TAG_JBool: {
                    heff_take_n(v_it1_2446, 0ULL, 1);
                    v_t_2453 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str16);
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2446, 0ULL, 1);
                    v_t_2453 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str17);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2446, 0ULL, 1);
                    v_t_2453 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str18);
                    break;
                  }
                  case TAG_JString: {
                    V v_s_2450 = heff_field(v_it1_2446, 0);
                    heff_take_n(v_it1_2446, 1ULL, 1);
                    v_t_2453 = v_s_2450;
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2446, 0ULL, 1);
                    v_t_2453 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str19);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2446, 0ULL, 1);
                    v_t_2453 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str20);
                    break;
                  }
                  default: heff_nomatch(v_it1_2446);
                  }
                } else {
                  heff_drop(v_field_2435);
                  v_t_2453 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str21);
                }
                v_t_2454 = heff_rec_n(2, shape_uri__text, (V[]){v_t_2444, v_t_2453});
              }
            }
            V v_d_2455 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_st_240, 0), heff_dup(v_f_2426), v_t_2454));
            V v_t_2456 = ({ V rv_0 = v_d_2455; V rr_ = heff_rec_reuse_nf(v_st_240, 126ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16380u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            V v_t_2457 = (g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806(v_t_2456, v_f_2426));
            V f_ = v_t_2457;
            heff_room[0] = v_hd_244;
            heff_room[1] = v_k_245;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          } else {
            if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str22), 2)) {
              heff_drop(v_m_241);
              HeffT2 v_t_2459 = (g_heff_2elsp_2elsp_2elastChange_24cpr(v_p_242));
              {
                V v_field_2461 = v_t_2459.f[1];
                int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
                if ((v_tag_2460 == ((int64_t)0ULL))) {
                  V v_text_2463 = v_field_2461;
                  V v_t_2465 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam3_clo)})});
                  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
                  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
                  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
                  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2468}), v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam4, 1, 4, (V[]){v_st_240, v_f_2426, v_text_2463, v_k_245})));
                } else {
                  heff_drop(v_hd_244);
                  heff_drop(v_f_2426);
                  heff_drop_cell(v_ru_24x_246_24Just, 1);
                  heff_drop(v_field_2461);
                  V f_ = v_k_245;
                  args[0] = v_st_240;
                  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                  return heff_tail(f_, 1, args);
                }
              }
            } else {
              heff_drop(v_p_242);
              heff_drop_cell(v_ru_24x_246_24Just, 1);
              if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str23), 2)) {
                heff_drop(v_m_241);
                V v_t_2474 = (g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806(v_st_240, v_f_2426));
                V f_ = v_t_2474;
                heff_room[0] = v_hd_244;
                heff_room[1] = v_k_245;
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              } else {
                if (heff_strEq_c(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_str24))) {
                  HeffT2 v_t_2476 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_240, 0), v_f_2426));
                  V v_c_2483;
                  {
                    V v_field_2478 = v_t_2476.f[1];
                    int64_t v_tag_2477 = ((int64_t)v_t_2476.f[0]);
                    if ((v_tag_2477 == ((int64_t)0ULL))) {
                      V v_d_2480 = v_field_2478;
                      v_c_2483 = heff_tr(g_heff_2elsp_2elsp_2epublish_24s450272378x127963581(heff_get_n(v_d_2480, 0, 2), NTAG(TAG_Nil)));
                    } else {
                      heff_drop(v_field_2478);
                      v_c_2483 = ((V)&g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam5_clo);
                    }
                  }
                  V f_ = v_c_2483;
                  heff_room[0] = v_hd_244;
                  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam6, 1, 3, (V[]){v_st_240, v_f_2426, v_k_245});
                  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                } else {
                  heff_drop(v_hd_244);
                  heff_drop(v_f_2426);
                  V f_ = v_k_245;
                  args[0] = v_st_240;
                  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                  return heff_tail(f_, 1, args);
                }
              }
            }
          }
        }
        default: return heff_nomatch(v_x_246);
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689_lam1, 1, 5, (V[]){v_m_241, v_st_240, v_hd_244, v_k_245, v_p_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_str1, 0, "");
V g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s534802052x381893070(v_p_241));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_lam0, 2, 2, (V[]){v_c_242, v_st_240});
}
V g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_d_2412 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2429 = heff_get_n(v_d_2412, 1, 2);
  HeffT2 v_t_2430 = ({ V a_0 = heff_rfield(v_x_2428, 1); V a_1 = v_f_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_f_247); r_; });
  V v_x_2436;
  {
    V v_field_2432 = v_t_2430.f[1];
    int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
    if ((v_tag_2431 == ((int64_t)0ULL))) {
      V v_c_2434 = v_field_2432;
      if (heff_strEq_c(heff_dup(heff_rfield(v_c_2434, 0)), heff_dup(v_text_2429))) {
        v_x_2436 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2428, v_text_2429, heff_get_n(v_c_2434, 1, 2)});
      } else {
        heff_drop_rec(v_c_2434, 2);
        v_x_2436 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2428, v_text_2429, NTAG(TAG_Nil)});
      }
    } else {
      heff_drop(v_field_2432);
      v_x_2436 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2428, v_text_2429, NTAG(TAG_Nil)});
    }
  }
  V f_ = v_k_244;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_lam3(V self, V *args) {
  V v_x_2438 = args[0];
  V v_d_2412 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2439 = heff_get_n(v_d_2412, 1, 2);
  HeffT2 v_t_2440 = ({ V a_0 = heff_rfield(v_x_2438, 1); V a_1 = v_f_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_f_247); r_; });
  V v_x_2446;
  {
    V v_field_2442 = v_t_2440.f[1];
    int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
    if ((v_tag_2441 == ((int64_t)0ULL))) {
      V v_c_2444 = v_field_2442;
      if (heff_strEq_c(heff_dup(heff_rfield(v_c_2444, 0)), heff_dup(v_text_2439))) {
        v_x_2446 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2438, v_text_2439, heff_get_n(v_c_2444, 1, 2)});
      } else {
        heff_drop_rec(v_c_2444, 2);
        v_x_2446 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2438, v_text_2439, NTAG(TAG_Nil)});
      }
    } else {
      heff_drop(v_field_2442);
      v_x_2446 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2438, v_text_2439, NTAG(TAG_Nil)});
    }
  }
  V f_ = v_k_244;
  args[0] = v_x_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    V v_t_246 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_str0), NTAG(TAG_Nil)});
    V f_ = v_k_244;
    args[0] = v_t_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_240, 0), v_f_247));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_d_2412 = v_field_2410;
        HeffT2 v_t_2413 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_240, 1), v_f_247));
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2417 = v_field_2415;
            if (heff_strEq_c(heff_get_n(v_c_2417, 0, 2), heff_dup(heff_rfield(v_d_2412, 1)))) {
              heff_drop(v_hd_243);
              V v_text_2419 = heff_get_n(v_d_2412, 1, 2);
              HeffT2 v_t_2420 = ({ V a_0 = heff_rfield(v_st_240, 1); V a_1 = v_f_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_f_247); r_; });
              V v_x_2426;
              {
                V v_field_2422 = v_t_2420.f[1];
                int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                if ((v_tag_2421 == ((int64_t)0ULL))) {
                  V v_c_2424 = v_field_2422;
                  if (heff_strEq_c(heff_dup(heff_rfield(v_c_2424, 0)), heff_dup(v_text_2419))) {
                    v_x_2426 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2419, heff_get_n(v_c_2424, 1, 2)});
                  } else {
                    heff_drop_rec(v_c_2424, 2);
                    v_x_2426 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2419, NTAG(TAG_Nil)});
                  }
                } else {
                  heff_drop(v_field_2422);
                  v_x_2426 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2419, NTAG(TAG_Nil)});
                }
              }
              V f_ = v_k_244;
              args[0] = v_x_2426;
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            } else {
              V v_c_2427 = (g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306(v_st_240, heff_dup(v_f_247)));
              V f_ = v_c_2427;
              heff_room[0] = v_hd_243;
              heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_lam2, 1, 3, (V[]){v_d_2412, v_f_247, v_k_244});
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
          } else {
            heff_drop(v_field_2415);
            V v_c_2437 = (g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306(v_st_240, heff_dup(v_f_247)));
            V f_ = v_c_2437;
            heff_room[0] = v_hd_243;
            heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_lam3, 1, 3, (V[]){v_d_2412, v_f_247, v_k_244});
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
        }
      } else {
        heff_drop(v_hd_243);
        heff_drop(v_f_247);
        heff_drop(v_field_2410);
        V v_t_2447 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_str1), NTAG(TAG_Nil)});
        V f_ = v_k_244;
        args[0] = v_t_2447;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576_lam1, 1, 3, (V[]){v_st_240, v_k_244, v_hd_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_entry, 2, 0};

V g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_f_248 = heff_field(v_x21_245, 1);
      V v_c_249 = (g_heff_2elsp_2elsp_2eproject_24s531222994x597819115(v_st_240, heff_dup(v_f_248)));
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_lam1, 2, 2, (V[]){v_c_249, heff_dup(v_rest_246)});
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V v_t_244 = heff_rec_n(2, shape_st__program, (V[]){v_st_240, NTAG(TAG_Nil)});
  V f_ = v_k_243;
  args[0] = v_t_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_program_2415 = (g_prelude_2e_2b_2b(heff_get_n(v_x_2412, 1, 2), heff_take_field(v_x_2414, 1)));
  V v_t_2416 = ({ V rv_1 = v_program_2415; V rr_ = heff_rec_reuse_nf(v_x_2414, 1ULL, 2, shape_st__program, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2411;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2413 = ({ V a_0 = heff_dup(heff_rfield(v_x_2412, 0)); V a_1 = v_rest_246; V r_ = (g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452(a_0, a_1)); heff_drop(v_rest_246); r_; });
  V f_ = v_c_2413;
  heff_room[0] = v_hd_2410;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_lam3, 1, 2, (V[]){v_x_2412, v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452_lam2, 1, 3, (V[]){v_rest_246, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_str0, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_str1, 5, "range");
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam0, 2, 0};
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam2, 1, 0};
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_entry, 3, 0};

V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895(V v_st_240, V v_new_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_st_240, 7);
    heff_drop(v_new_241);
    return ((V)&g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam0_clo);
  }
  case TAG_Cons: {
    V v_b_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_p_247 = heff_dup(heff_rfield(v_b_245, 0));
    HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_240, 0), v_p_247));
    V v_c_2420;
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_p_247);
        V v_d_2412 = v_field_2410;
        v_c_2420 = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam1, 2, 1, (V[]){v_d_2412});
      } else {
        heff_drop(v_field_2410);
        V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_PathUri, 2, (V[]){v_p_247, ((V)&g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam2_clo)})});
        V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
        V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
        V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
        v_c_2420 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})}));
      }
    }
    return heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam3, 2, 5, (V[]){v_c_2420, v_st_240, v_new_241, v_rest_246, v_b_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_d_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_get_n(v_d_2412, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam2(V self, V *args) {
  V v_u_2415 = args[0];
  return v_u_2415;
}
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam6(V self, V *args) {
  V v_o_2426 = args[0];
  V v_new_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = ({ V b_0 = heff_take_field(v_o_2426, 1); V a_1 = heff_get_n(v_o_2426, 2, 4); V r_ = (g_heff_2elsp_2elsp_2erange(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_str0), heff_tag_n(TAG_JString, 1, (V[]){v_new_241})});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_str1), v_t_2427}), v_t_2429});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2430});
}
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_new_241 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  V v_k_2422 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2431 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam6, 1, 1, (V[]){v_new_241}), heff_get_n(v_b_245, 1, 2)));
  V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2423, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2431})});
  V v_x_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_x_2425});
  V f_ = v_k_2422;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_new_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2421 = heff_env(self)[3];
  V v_b_245 = heff_env(self)[4];
  V v_k_2422 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2424 = (g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895(v_st_240, heff_dup(v_new_241), v_rest_246));
  V f_ = v_c_2424;
  heff_room[0] = v_hd_2421;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam5, 1, 4, (V[]){v_new_241, v_b_245, v_x_2423, v_k_2422});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_new_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_b_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2420;
  args[0] = heff_dup(v_hd_2421);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echangesOf_24s924600953x1031632895_lam4, 1, 6, (V[]){v_st_240, v_new_241, v_rest_246, v_hd_2421, v_b_245, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str6, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str7, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str8, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str9, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str10, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str11, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str12, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str13, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str15, 2, "id");
V g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_entry, 6, 0};

V g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629(V v_st_240, V v_id_241, V v_d_242, V v_fix_243, V v_z_244, V v_z_245) {
top: ;
  V v_src_246 = heff_dup(heff_rfield(v_d_242, 1));
  HeffT2 v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_24cpr(v_fix_243, heff_dup(v_src_246)));
  V v_t_2417;
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_src_246);
      V v_why_2411 = v_field_249;
      v_t_2417 = heff_tag_n(TAG_Left, 1, (V[]){v_why_2411});
    } else {
      V v_out_2412 = v_field_249;
      V v_t_2413 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_246), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2414 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2413));
      V v_t_2415 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_out_2412), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2416 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2415));
      v_t_2417 = (g_heff_2esyntax_2eformat_2esameMeaning(v_src_246, v_out_2412, v_t_2414, v_t_2416));
    }
  }
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Left: {
    V v_ru_24t_2417_24Left = heff_take_reuse_n(v_t_2417, 0ULL, 1);
    heff_drop_rec(v_d_242, 2);
    V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str0), heff_tag_at_n(v_ru_24t_2417_24Left, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str1)})});
    V v_t_2420 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str2), v_t_2420}), NTAG(TAG_Nil)});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str3), v_id_241}), v_t_2421});
    V v_t_2423 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2422})});
    V v_t_2424 = ({ V a_0 = v_t_2423; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2423, 1); r_; });
    V v_a_2425 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2424, NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s94900133x232571340(v_t_2429, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_lam0, 1, 2, (V[]){v_z_245, v_st_240})));
  }
  case TAG_Right: {
    V v_t_2431 = heff_field(v_t_2417, 0);
    V v_ru_24t_2417_24Right = heff_take_reuse_n(v_t_2417, 1ULL, 1);
    if (heff_strEq_c(heff_dup(v_t_2431), heff_dup(heff_rfield(v_d_242, 1)))) {
      heff_drop_rec(v_d_242, 2);
      heff_drop(v_t_2431);
      V v_t_2433 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str4), heff_tag_at_n(v_ru_24t_2417_24Right, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str5)})});
      V v_t_2434 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
      V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str6), v_t_2434}), NTAG(TAG_Nil)});
      V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str7), v_id_241}), v_t_2435});
      V v_t_2437 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_t_2436})});
      V v_t_2438 = ({ V a_0 = v_t_2437; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2437, 1); r_; });
      V v_a_2439 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2438, NTAG(TAG_MkUnit)});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
      V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
      return (g_co_2eop_24s94900133x232571340(v_t_2443, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_lam1, 1, 2, (V[]){v_z_245, v_st_240})));
    } else {
      V v_src_2445 = heff_dup(heff_rfield(v_d_242, 1));
      V v_t_2446 = heff_strLength(heff_get_n(v_d_242, 1, 2));
      V v_t_2447 = (g_heff_2elsp_2elsp_2eposition(v_src_2445, MK_INT(0LL)));
      V v_t_2449;
      if ((((int64_t)0ULL) <= heff_peek_word(v_t_2446))) {
        v_t_2449 = v_t_2446;
      } else {
        heff_drop(v_t_2446);
        v_t_2449 = MK_INT(0LL);
      }
      V v_t_2450 = ({ V a_0 = v_src_2445; V a_1 = v_t_2449; V r_ = (g_heff_2elsp_2elsp_2eposition(a_0, a_1)); heff_drop(v_src_2445); r_; });
      V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str8), v_t_2450}), NTAG(TAG_Nil)});
      V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str9), v_t_2447}), v_t_2451});
      V v_t_2453 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str10), heff_tag_at_n(v_ru_24t_2417_24Right, TAG_JObject, 1, (V[]){v_t_2452})});
      V v_t_2454 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str11), heff_tag_n(TAG_JString, 1, (V[]){v_t_2431})});
      V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
      V v_t_2456 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, v_t_2455})});
      V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2456, NTAG(TAG_Nil)});
      V v_result_2458 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_2457});
      V v_t_2459 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str12), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str13)})});
      V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str14), v_result_2458}), NTAG(TAG_Nil)});
      V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_str15), v_id_241}), v_t_2460});
      V v_t_2462 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, v_t_2461})});
      V v_t_2463 = ({ V a_0 = v_t_2462; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2462, 1); r_; });
      V v_a_2464 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2463, NTAG(TAG_MkUnit)});
      V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2464})});
      V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
      V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
      V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
      return (g_co_2eop_24s94900133x232571340(v_t_2468, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_lam2, 1, 2, (V[]){v_z_245, v_st_240})));
    }
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_lam0(V self, V *args) {
  V v_x_2430 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2430);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_lam1(V self, V *args) {
  V v_x_2444 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s611459051x1120449629_lam2(V self, V *args) {
  V v_x_2469 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2469);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str0, 10, "initialize");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str1, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str2, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str3, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str4, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str5, 19, "dynamicRegistration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str6, 9, "workspace");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str7, 21, "didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str8, 12, "capabilities");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str9, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str10, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str11, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str12, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str13, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str14, 18, "textDocument/hover");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str15, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str16, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str17, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str18, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str19, 23, "textDocument/definition");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str20, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str21, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str22, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str23, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str24, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str25, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str26, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str27, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str28, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str29, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str30, 23, "textDocument/completion");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str31, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str32, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str33, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str34, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str35, 27, "textDocument/documentSymbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str36, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str37, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str38, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str39, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str40, 16, "workspace/symbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str41, 5, "query");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str42, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str43, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str44, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str45, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str46, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str47, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str48, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str49, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str50, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str51, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str52, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str53, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str54, 23, "textDocument/references");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str55, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str56, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str57, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str58, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str59, 18, "includeDeclaration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str60, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str61, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str62, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str63, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str64, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str65, 26, "textDocument/prepareRename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str66, 19, "textDocument/rename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str67, 7, "newName");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str68, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str69, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str70, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str71, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str72, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str73, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str74, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str75, 23, "textDocument/formatting");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str76, 23, "textDocument/codeAction");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str77, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str78, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str79, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str80, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str81, 10, "no method ");
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam10(V self, V *args); static Clo g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam10, 1, 0};
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam16(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam15(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam14(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam19(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam20(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam18(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam17(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam25(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam24(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam23(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam22(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam21(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam28(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam30(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam29(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam31(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam27(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam26(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam33(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam32(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam35(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam34(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam39(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam38(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam37(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam36(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam41(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam40(V self, V *args);
Clo g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_entry, 4, 0};

V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086(V v_st_240, V v_m_241, V v_id_242, V v_p_243) {
top: ;
  if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str0), 2)) {
    heff_drop(v_m_241);
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str1), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str2)})});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str3), heff_dup(g_heff_2elsp_2elsp_2ecapabilities_get())}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str4), v_id_242}), v_t_246});
    V v_t_248 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
    V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_248, 1); r_; });
    V v_a_2410 = heff_tag_n(TAG_Send, 2, (V[]){v_t_249, NTAG(TAG_MkUnit)});
    return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam0, 2, 3, (V[]){v_a_2410, v_p_243, v_st_240});
  } else {
    if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str9), 2)) {
      heff_drop(v_m_241);
      heff_drop(v_p_243);
      V v_t_2434 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str10), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str11)})});
      V v_t_2435 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str12), NTAG(TAG_JNull)});
      V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
      V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str13), v_id_242}), v_t_2436});
      V v_t_2438 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_t_2437})});
      V v_t_2439 = ({ V a_0 = v_t_2438; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2438, 1); r_; });
      V v_a_2440 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2439, NTAG(TAG_MkUnit)});
      return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam2, 2, 2, (V[]){v_a_2440, v_st_240});
    } else {
      if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str14), 2)) {
        heff_drop(v_m_241);
        V v_c_2450 = (g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576(v_st_240, heff_dup(v_p_243)));
        return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam4, 2, 3, (V[]){v_c_2450, v_p_243, v_id_242});
      } else {
        if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str19), 2)) {
          heff_drop(v_m_241);
          V v_c_2467 = (g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576(v_st_240, heff_dup(v_p_243)));
          return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam7, 2, 3, (V[]){v_c_2467, v_p_243, v_id_242});
        } else {
          if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str30), 2)) {
            heff_drop(v_m_241);
            V v_c_24123 = (g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576(v_st_240, heff_dup(v_p_243)));
            return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam14, 2, 3, (V[]){v_c_24123, v_p_243, v_id_242});
          } else {
            if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str35), 2)) {
              heff_drop(v_m_241);
              V v_c_24146 = (g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576(v_st_240, v_p_243));
              return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam17, 2, 2, (V[]){v_c_24146, v_id_242});
            } else {
              if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str40), 2)) {
                heff_drop(v_m_241);
                V v_t_24169 = (g_std_2emap_2etoListOnto(heff_rfield(v_st_240, 0), NTAG(TAG_Nil)));
                V v_t_24170 = (g_list_2emap_24s1415906091x1371825187(v_t_24169));
                V v_c_24171 = (g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819(heff_dup(v_st_240), v_t_24170));
                return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam21, 2, 4, (V[]){v_c_24171, v_st_240, v_p_243, v_id_242});
              } else {
                if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str54), 2)) {
                  heff_drop(v_m_241);
                  V v_c_24208 = (g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230(v_st_240, heff_dup(v_p_243)));
                  return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam26, 2, 3, (V[]){v_c_24208, v_id_242, v_p_243});
                } else {
                  if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str65), 2)) {
                    heff_drop(v_m_241);
                    V v_c_24259 = (g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230(v_st_240, v_p_243));
                    return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam32, 2, 2, (V[]){v_c_24259, v_id_242});
                  } else {
                    if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str66), 2)) {
                      heff_drop(v_m_241);
                      V v_c_24264 = (g_heff_2elsp_2elsp_2ewithTarget_24s6370911x444975230(v_st_240, heff_dup(v_p_243)));
                      return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam34, 2, 3, (V[]){v_c_24264, v_p_243, v_id_242});
                    } else {
                      if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str75), 2)) {
                        heff_drop(v_m_241);
                        return (g_heff_2elsp_2elsp_2eformatted_24s1223202703x2078867119(v_st_240, v_id_242, v_p_243));
                      } else {
                        if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str76), 2)) {
                          heff_drop(v_m_241);
                          V v_c_24283 = (g_heff_2elsp_2elsp_2ewithProgram_24s2097903225x1893011576(v_st_240, heff_dup(v_p_243)));
                          return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam36, 2, 3, (V[]){v_c_24283, v_p_243, v_id_242});
                        } else {
                          heff_drop(v_p_243);
                          V v_c_24301 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057(v_id_242, MK_INT(-32601LL), heff_strAppend(((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str81), v_m_241)));
                          return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam40, 2, 2, (V[]){v_c_24301, v_st_240});
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2417);
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str5), NTAG(TAG_Nil)});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str7), v_t_2418})});
  HeffT2 v_t_2420 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str8), v_t_2419}), v_p_243));
  {
    V v_field_2422 = v_t_2420.f[1];
    int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
    V v_t_2431;
    if ((v_tag_2421 == ((int64_t)0ULL))) {
      V v_it1_2424 = v_field_2422;
      switch (heff_tag_of(v_it1_2424)) {
      case TAG_JNull: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_JBool: {
        V v_b_2425 = heff_field(v_it1_2424, 0);
        heff_take_n(v_it1_2424, 1ULL, 1);
        v_t_2431 = v_b_2425;
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2424, 0ULL, 1);
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2424, 0ULL, 1);
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2424, 0ULL, 1);
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_2424, 0ULL, 1);
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2424, 0ULL, 1);
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_2424);
      }
    } else {
      heff_drop(v_field_2422);
      v_t_2431 = NTAG(TAG_False);
    }
    V v_t_2432 = ({ V rv_4 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_st_240, 111ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15615u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V f_ = v_k_2412;
    args[0] = v_t_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_a_2410 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s94900133x232571340(v_t_2416, v_hd_2411, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam1, 1, 3, (V[]){v_p_243, v_st_240, v_k_2412})));
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam3(V self, V *args) {
  V v_x_2447 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2447);
  V v_t_2448 = ({ V rv_5 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_st_240, 95ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 13311u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
  V f_ = v_k_2442;
  args[0] = v_t_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam2(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_a_2440 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2440})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  return (g_co_2eop_24s94900133x232571340(v_t_2446, v_hd_2441, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam3, 1, 2, (V[]){v_st_240, v_k_2442})));
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam6(V self, V *args) {
  V v_x_2465 = args[0];
  V v_k_2452 = heff_env(self)[0];
  V v_x_2453 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2465);
  V f_ = v_k_2452;
  args[0] = heff_get_n(v_x_2453, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam5(V self, V *args) {
  V v_x_2453 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_2451 = heff_env(self)[2];
  V v_k_2452 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_result_2454 = (g_heff_2elsp_2elsp_2ehoverOf(heff_dup(v_x_2453), v_p_243));
  V v_t_2455 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str15), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str16)})});
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str17), v_result_2454}), NTAG(TAG_Nil)});
  V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str18), v_id_242}), v_t_2456});
  V v_t_2458 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_t_2457})});
  V v_t_2459 = ({ V a_0 = v_t_2458; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2458, 1); r_; });
  V v_a_2460 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2459, NTAG(TAG_MkUnit)});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  return (g_co_2eop_24s94900133x232571340(v_t_2464, v_hd_2451, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam6, 1, 2, (V[]){v_k_2452, v_x_2453})));
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam4(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_c_2450 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2450;
  args[0] = heff_dup(v_hd_2451);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam5, 1, 4, (V[]){v_p_243, v_id_242, v_hd_2451, v_k_2452});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam9(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  V v_d_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2484);
  V f_ = v_k_2485;
  args[0] = heff_get_n(v_d_2483, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam10(V self, V *args) {
  V v_u_2486 = args[0];
  return v_u_2486;
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam12(V self, V *args) {
  V v_x_2494 = args[0];
  V v_d_2476 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_2492 = heff_env(self)[2];
  V v_k_2493 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2495 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str20), heff_tag_n(TAG_JString, 1, (V[]){v_x_2494})});
  V v_t_2496 = ({ V b_0 = heff_take_field(v_d_2476, 1); V a_1 = heff_get_n(v_d_2476, 2, 3); V r_ = (g_heff_2elsp_2elsp_2erange(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2497 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str21), v_t_2496}), NTAG(TAG_Nil)});
  V v_result_2498 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2495, v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str22), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str23)})});
  V v_t_24100 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str24), v_result_2498}), NTAG(TAG_Nil)});
  V v_t_24101 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str25), v_id_242}), v_t_24100});
  V v_t_24102 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2499, v_t_24101})});
  V v_t_24103 = ({ V a_0 = v_t_24102; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24102, 1); r_; });
  V v_a_24104 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24103, NTAG(TAG_MkUnit)});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  return (g_co_2eop_24s94900133x232571340(v_t_24108, v_hd_2492, v_k_2493));
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam11(V self, V *args) {
  V v_hd_2492 = args[0];
  V v_k_2493 = args[1];
  V v_c_2491 = heff_env(self)[0];
  V v_d_2476 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2491;
  args[0] = heff_dup(v_hd_2492);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam12, 1, 4, (V[]){v_d_2476, v_id_242, v_hd_2492, v_k_2493});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam13(V self, V *args) {
  V v_x_24121 = args[0];
  V v_k_2469 = heff_env(self)[0];
  V v_x_2470 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24121);
  V f_ = v_k_2469;
  args[0] = heff_get_n(v_x_2470, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam8(V self, V *args) {
  V v_x_2470 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_2468 = heff_env(self)[2];
  V v_k_2469 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2471 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_x_2470, 1), v_p_243));
  HeffT2 v_t_2472 = (g_heff_2ebuild_2equery_2edefinitionAt_24cpr(heff_dup(heff_rfield(v_x_2470, 2)), v_t_2471));
  V v_c_24120;
  {
    V v_field_2474 = v_t_2472.f[1];
    int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
    if ((v_tag_2473 == ((int64_t)0ULL))) {
      V v_d_2476 = v_field_2474;
      V v_p_2477 = heff_dup(heff_rfield(v_d_2476, 0));
      V v_t_2478 = heff_get_n(heff_dup(heff_rfield(v_x_2470, 0)), 0, 7);
      HeffT2 v_t_2479 = ({ V a_0 = v_t_2478; V a_1 = v_p_2477; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_2478); r_; });
      V v_c_2491;
      {
        V v_field_2481 = v_t_2479.f[1];
        int64_t v_tag_2480 = ((int64_t)v_t_2479.f[0]);
        if ((v_tag_2480 == ((int64_t)0ULL))) {
          heff_drop(v_p_2477);
          V v_d_2483 = v_field_2481;
          v_c_2491 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam9, 2, 1, (V[]){v_d_2483});
        } else {
          heff_drop(v_field_2481);
          V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_2477, ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam10_clo)})});
          V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
          V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
          V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
          v_c_2491 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})}));
        }
      }
      v_c_24120 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam11, 2, 3, (V[]){v_c_2491, v_d_2476, v_id_242});
    } else {
      heff_drop(v_field_2474);
      V v_t_24109 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str26), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str27)})});
      V v_t_24110 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str28), NTAG(TAG_JNull)});
      V v_t_24111 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24110, NTAG(TAG_Nil)});
      V v_t_24112 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str29), v_id_242}), v_t_24111});
      V v_t_24113 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24109, v_t_24112})});
      V v_t_24114 = ({ V a_0 = v_t_24113; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24113, 1); r_; });
      V v_a_24115 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24114, NTAG(TAG_MkUnit)});
      V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24115})});
      V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
      V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
      V v_t_24119 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
      v_c_24120 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){v_t_24119}));
    }
  }
  V f_ = v_c_24120;
  heff_room[0] = v_hd_2468;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam13, 1, 2, (V[]){v_k_2469, v_x_2470});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam7(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  V v_c_2467 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2467;
  args[0] = heff_dup(v_hd_2468);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam8, 1, 4, (V[]){v_p_243, v_id_242, v_hd_2468, v_k_2469});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam16(V self, V *args) {
  V v_x_24144 = args[0];
  V v_k_24125 = heff_env(self)[0];
  V v_x_24126 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24144);
  V f_ = v_k_24125;
  args[0] = heff_get_n(v_x_24126, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam15(V self, V *args) {
  V v_x_24126 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_24124 = heff_env(self)[2];
  V v_k_24125 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24127 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_x_24126, 2))));
  V v_t_24132;
  switch (heff_tag_of(v_x1_24127)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    v_t_24132 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24128 = heff_field(v_x1_24127, 0);
    heff_take_n(v_x1_24127, 1ULL, 2);
    V v_t_24130 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_x_24126, 1), v_p_243));
    V v_t_24131 = (g_heff_2ebuild_2equery_2ecompletionsAt(v_x_24128, v_t_24130));
    v_t_24132 = (g_list_2emap_24s4199228x1154005405(v_t_24131));
    break;
  }
  default: heff_nomatch(v_x1_24127);
  }
  V v_result_24133 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24132});
  V v_t_24134 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str31), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str32)})});
  V v_t_24135 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str33), v_result_24133}), NTAG(TAG_Nil)});
  V v_t_24136 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str34), v_id_242}), v_t_24135});
  V v_t_24137 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24134, v_t_24136})});
  V v_t_24138 = ({ V a_0 = v_t_24137; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24137, 1); r_; });
  V v_a_24139 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24138, NTAG(TAG_MkUnit)});
  V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24139})});
  V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
  V v_t_24142 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24141})});
  V v_t_24143 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
  return (g_co_2eop_24s94900133x232571340(v_t_24143, v_hd_24124, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam16, 1, 2, (V[]){v_k_24125, v_x_24126})));
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam14(V self, V *args) {
  V v_hd_24124 = args[0];
  V v_k_24125 = args[1];
  V v_c_24123 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24123;
  args[0] = heff_dup(v_hd_24124);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam15, 1, 4, (V[]){v_p_243, v_id_242, v_hd_24124, v_k_24125});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam19(V self, V *args) {
  V v_y_24154 = args[0];
  V v_x_24149 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_x_24149, 1, 3); V a_1 = v_y_24154; V r_ = (g_heff_2elsp_2elsp_2edocSymbol(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam20(V self, V *args) {
  V v_x_24167 = args[0];
  V v_k_24148 = heff_env(self)[0];
  V v_x_24149 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24167);
  V f_ = v_k_24148;
  args[0] = heff_get_n(v_x_24149, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam18(V self, V *args) {
  V v_x_24149 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24147 = heff_env(self)[1];
  V v_k_24148 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24150 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_x_24149, 2))));
  V v_t_24155;
  switch (heff_tag_of(v_x1_24150)) {
  case TAG_Nil: {
    v_t_24155 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24151 = heff_field(v_x1_24150, 0);
    heff_take_n(v_x1_24150, 1ULL, 2);
    V v_t_24153 = (g_heff_2ebuild_2equery_2esymbols(v_x_24151));
    v_t_24155 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam19, 1, 1, (V[]){heff_dup(v_x_24149)}), v_t_24153));
    break;
  }
  default: heff_nomatch(v_x1_24150);
  }
  V v_result_24156 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24155});
  V v_t_24157 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str36), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str37)})});
  V v_t_24158 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str38), v_result_24156}), NTAG(TAG_Nil)});
  V v_t_24159 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str39), v_id_242}), v_t_24158});
  V v_t_24160 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24157, v_t_24159})});
  V v_t_24161 = ({ V a_0 = v_t_24160; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24160, 1); r_; });
  V v_a_24162 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24161, NTAG(TAG_MkUnit)});
  V v_t_24163 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24162})});
  V v_t_24164 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24163})});
  V v_t_24165 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24164})});
  V v_t_24166 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24165})});
  return (g_co_2eop_24s94900133x232571340(v_t_24166, v_hd_24147, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam20, 1, 2, (V[]){v_k_24148, v_x_24149})));
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam17(V self, V *args) {
  V v_hd_24147 = args[0];
  V v_k_24148 = args[1];
  V v_c_24146 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24146;
  args[0] = heff_dup(v_hd_24147);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam18, 1, 3, (V[]){v_id_242, v_hd_24147, v_k_24148});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam25(V self, V *args) {
  V v_x_24206 = args[0];
  V v_k_24173 = heff_env(self)[0];
  V v_x_24177 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24206);
  V f_ = v_k_24173;
  args[0] = heff_get_n(v_x_24177, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam24(V self, V *args) {
  V v_x_24194 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24172 = heff_env(self)[1];
  V v_k_24173 = heff_env(self)[2];
  V v_x_24177 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24195 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str50), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str51)})});
  V v_t_24196 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str52), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24194})});
  V v_t_24197 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24196, NTAG(TAG_Nil)});
  V v_t_24198 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str53), v_id_242}), v_t_24197});
  V v_t_24199 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24195, v_t_24198})});
  V v_t_24200 = ({ V a_0 = v_t_24199; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24199, 1); r_; });
  V v_a_24201 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24200, NTAG(TAG_MkUnit)});
  V v_t_24202 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24201})});
  V v_t_24203 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24202})});
  V v_t_24204 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24203})});
  V v_t_24205 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24204})});
  return (g_co_2eop_24s94900133x232571340(v_t_24205, v_hd_24172, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam25, 1, 2, (V[]){v_k_24173, v_x_24177})));
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam23(V self, V *args) {
  V v_x_24177 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_hd_24172 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_k_24173 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24178 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str41), NTAG(TAG_Nil)});
  HeffT2 v_t_24179 = (g_json_2eat_24cpr(v_t_24178, v_p_243));
  V v_t_24191;
  {
    V v_field_24181 = v_t_24179.f[1];
    int64_t v_tag_24180 = ((int64_t)v_t_24179.f[0]);
    V v_t_24190;
    if ((v_tag_24180 == ((int64_t)0ULL))) {
      V v_it1_24183 = v_field_24181;
      switch (heff_tag_of(v_it1_24183)) {
      case TAG_JNull: {
        v_t_24190 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str42);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_24183, 0ULL, 1);
        v_t_24190 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str43);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24183, 0ULL, 1);
        v_t_24190 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str44);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24183, 0ULL, 1);
        v_t_24190 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str45);
        break;
      }
      case TAG_JString: {
        V v_s_24187 = heff_field(v_it1_24183, 0);
        heff_take_n(v_it1_24183, 1ULL, 1);
        v_t_24190 = v_s_24187;
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24183, 0ULL, 1);
        v_t_24190 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str46);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24183, 0ULL, 1);
        v_t_24190 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str47);
        break;
      }
      default: heff_nomatch(v_it1_24183);
      }
    } else {
      heff_drop(v_field_24181);
      v_t_24190 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str48);
    }
    v_t_24191 = ({ V a_0 = v_t_24190; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str49); V r_ = (g_heff_2elsp_2elsp_2elowerGo(a_0, a_1, a_2)); heff_drop(v_t_24190); r_; });
  }
  V v_t_24192 = (g_heff_2elsp_2elsp_2enubCheckedPaths(heff_dup(heff_rfield(v_x_24177, 1))));
  V v_c_24193 = ({ V a_0 = heff_dup(heff_rfield(v_x_24177, 0)); V a_1 = v_t_24191; V a_2 = v_t_24192; V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s1716897359x1938049371(a_0, a_1, a_2)); heff_drop(v_t_24191); heff_drop(v_t_24192); r_; });
  V f_ = v_c_24193;
  heff_room[0] = heff_dup(v_hd_24172);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam24, 1, 4, (V[]){v_id_242, v_hd_24172, v_k_24173, v_x_24177});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam22(V self, V *args) {
  V v_x_24174 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_24172 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  V v_k_24173 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24175 = (g_heff_2elsp_2elsp_2enubRoots(v_x_24174));
  V v_c_24176 = ({ V a_0 = v_st_240; V a_1 = v_t_24175; V r_ = (g_heff_2elsp_2elsp_2eprojects_24s817239513x1594688452(a_0, a_1)); heff_drop(v_t_24175); r_; });
  V f_ = v_c_24176;
  heff_room[0] = heff_dup(v_hd_24172);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam23, 1, 4, (V[]){v_p_243, v_hd_24172, v_id_242, v_k_24173});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam21(V self, V *args) {
  V v_hd_24172 = args[0];
  V v_k_24173 = args[1];
  V v_c_24171 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24171;
  args[0] = heff_dup(v_hd_24172);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam22, 1, 5, (V[]){v_st_240, v_hd_24172, v_p_243, v_id_242, v_k_24173});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam28(V self, V *args) {
  V v_o_24225 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24226 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str59), NTAG(TAG_Nil)});
  HeffT2 v_t_24227 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str60), v_t_24226}), v_p_243));
  {
    V v_field_24229 = v_t_24227.f[1];
    int64_t v_tag_24228 = ((int64_t)v_t_24227.f[0]);
    if ((v_tag_24228 == ((int64_t)0ULL))) {
      V v_it1_24231 = v_field_24229;
      V v_t_24238;
      switch (heff_tag_of(v_it1_24231)) {
      case TAG_JNull: {
        v_t_24238 = NTAG(TAG_True);
        break;
      }
      case TAG_JBool: {
        V v_b_24232 = heff_field(v_it1_24231, 0);
        heff_take_n(v_it1_24231, 1ULL, 1);
        v_t_24238 = v_b_24232;
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24231, 0ULL, 1);
        v_t_24238 = NTAG(TAG_True);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24231, 0ULL, 1);
        v_t_24238 = NTAG(TAG_True);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_24231, 0ULL, 1);
        v_t_24238 = NTAG(TAG_True);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24231, 0ULL, 1);
        v_t_24238 = NTAG(TAG_True);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24231, 0ULL, 1);
        v_t_24238 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_it1_24231);
      }
      V v_ret_24bool = heff_bool(((heff_dup(v_t_24238) == NTAG(TAG_True)) || ({ V v_t_24239 = heff_dup(heff_rfield(v_o_24225, 3)); int c_ = !(heff_dup(v_t_24239) == NTAG(TAG_True)); heff_drop(v_t_24239); c_; })));
      heff_drop_rec(v_o_24225, 4);
      heff_drop(v_t_24238);
      return v_ret_24bool;
    } else {
      heff_drop_rec(v_o_24225, 4);
      heff_drop(v_field_24229);
      return NTAG(TAG_True);
    }
  }
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam30(V self, V *args) {
  V v_x_24244 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24242 = heff_env(self)[1];
  V v_k_24243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str61), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str62)})});
  V v_t_24246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str63), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24244})});
  V v_t_24247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24246, NTAG(TAG_Nil)});
  V v_t_24248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str64), v_id_242}), v_t_24247});
  V v_t_24249 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24245, v_t_24248})});
  V v_t_24250 = ({ V a_0 = v_t_24249; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24249, 1); r_; });
  V v_a_24251 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24250, NTAG(TAG_MkUnit)});
  V v_t_24252 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24251})});
  V v_t_24253 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24252})});
  V v_t_24254 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24253})});
  V v_t_24255 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24254})});
  return (g_co_2eop_24s94900133x232571340(v_t_24255, v_hd_24242, v_k_24243));
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam29(V self, V *args) {
  V v_hd_24242 = args[0];
  V v_k_24243 = args[1];
  V v_c_24241 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24241;
  args[0] = heff_dup(v_hd_24242);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam30, 1, 3, (V[]){v_id_242, v_hd_24242, v_k_24243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam31(V self, V *args) {
  V v_x_24257 = args[0];
  V v_k_24210 = heff_env(self)[0];
  V v_x_24211 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24257);
  V f_ = v_k_24210;
  args[0] = heff_get_n(v_x_24211, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam27(V self, V *args) {
  V v_x_24211 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_hd_24209 = heff_env(self)[2];
  V v_k_24210 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24212 = heff_dup(heff_rfield(v_x_24211, 2));
  V v_c_24256;
  switch (heff_tag_of(v_t_24212)) {
  case TAG_Nothing: {
    heff_drop(v_p_243);
    V v_t_24213 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str55), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str56)})});
    V v_t_24214 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str57), NTAG(TAG_JNull)});
    V v_t_24215 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24214, NTAG(TAG_Nil)});
    V v_t_24216 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str58), v_id_242}), v_t_24215});
    V v_t_24217 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24213, v_t_24216})});
    V v_t_24218 = ({ V a_0 = v_t_24217; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24217, 1); r_; });
    V v_a_24219 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24218, NTAG(TAG_MkUnit)});
    V v_t_24220 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24219})});
    V v_t_24221 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24220})});
    V v_t_24222 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24221})});
    V v_t_24223 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24222})});
    v_c_24256 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){v_t_24223}));
    break;
  }
  case TAG_Just: {
    V v_t_24224 = heff_field(v_t_24212, 0);
    heff_take_n(v_t_24212, 1ULL, 1);
    V v_t_24240 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam28, 1, 1, (V[]){v_p_243}), heff_get_n(v_t_24224, 3, 4)));
    V v_c_24241 = (g_heff_2elsp_2elsp_2elocations_24s485602184x2108381958(heff_dup(heff_rfield(v_x_24211, 0)), v_t_24240));
    v_c_24256 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam29, 2, 2, (V[]){v_c_24241, v_id_242});
    break;
  }
  default: heff_nomatch(v_t_24212);
  }
  V f_ = v_c_24256;
  heff_room[0] = v_hd_24209;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam31, 1, 2, (V[]){v_k_24210, v_x_24211});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam26(V self, V *args) {
  V v_hd_24209 = args[0];
  V v_k_24210 = args[1];
  V v_c_24208 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24208;
  args[0] = heff_dup(v_hd_24209);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam27, 1, 4, (V[]){v_id_242, v_p_243, v_hd_24209, v_k_24210});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam33(V self, V *args) {
  V v_x_24262 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24260 = heff_env(self)[1];
  V v_k_24261 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2elsp_2elsp_2eprepared_24s1821860323x982224140(v_id_242, v_x_24262, v_hd_24260, v_k_24261));
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam32(V self, V *args) {
  V v_hd_24260 = args[0];
  V v_k_24261 = args[1];
  V v_c_24259 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24259;
  args[0] = heff_dup(v_hd_24260);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam33, 1, 3, (V[]){v_id_242, v_hd_24260, v_k_24261});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam35(V self, V *args) {
  V v_x_24267 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_24265 = heff_env(self)[2];
  V v_k_24266 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24268 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str67), NTAG(TAG_Nil)});
  HeffT2 v_t_24269 = (g_json_2eat_24cpr(v_t_24268, v_p_243));
  V v_t_24280;
  {
    V v_field_24271 = v_t_24269.f[1];
    int64_t v_tag_24270 = ((int64_t)v_t_24269.f[0]);
    if ((v_tag_24270 == ((int64_t)0ULL))) {
      V v_it1_24273 = v_field_24271;
      switch (heff_tag_of(v_it1_24273)) {
      case TAG_JNull: {
        v_t_24280 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str68);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_24273, 0ULL, 1);
        v_t_24280 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str69);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24273, 0ULL, 1);
        v_t_24280 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str70);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24273, 0ULL, 1);
        v_t_24280 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str71);
        break;
      }
      case TAG_JString: {
        V v_s_24277 = heff_field(v_it1_24273, 0);
        heff_take_n(v_it1_24273, 1ULL, 1);
        v_t_24280 = v_s_24277;
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24273, 0ULL, 1);
        v_t_24280 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str72);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24273, 0ULL, 1);
        v_t_24280 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str73);
        break;
      }
      default: heff_nomatch(v_it1_24273);
      }
    } else {
      heff_drop(v_field_24271);
      v_t_24280 = ((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str74);
    }
  }
  return (g_heff_2elsp_2elsp_2erenamed_24s951747469x565258390(v_id_242, v_t_24280, v_x_24267, v_hd_24265, v_k_24266));
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam34(V self, V *args) {
  V v_hd_24265 = args[0];
  V v_k_24266 = args[1];
  V v_c_24264 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24264;
  args[0] = heff_dup(v_hd_24265);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam35, 1, 4, (V[]){v_p_243, v_id_242, v_hd_24265, v_k_24266});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam39(V self, V *args) {
  V v_x_24300 = args[0];
  V v_k_24285 = heff_env(self)[0];
  V v_x_24286 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24300);
  V f_ = v_k_24285;
  args[0] = heff_get_n(v_x_24286, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam38(V self, V *args) {
  V v_x_24288 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24284 = heff_env(self)[1];
  V v_k_24285 = heff_env(self)[2];
  V v_x_24286 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24289 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str77), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str78)})});
  V v_t_24290 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str79), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24288})});
  V v_t_24291 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24290, NTAG(TAG_Nil)});
  V v_t_24292 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_str80), v_id_242}), v_t_24291});
  V v_t_24293 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24289, v_t_24292})});
  V v_t_24294 = ({ V a_0 = v_t_24293; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_24293, 1); r_; });
  V v_a_24295 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24294, NTAG(TAG_MkUnit)});
  V v_t_24296 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24295})});
  V v_t_24297 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24296})});
  V v_t_24298 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24297})});
  V v_t_24299 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24298})});
  return (g_co_2eop_24s94900133x232571340(v_t_24299, v_hd_24284, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam39, 1, 2, (V[]){v_k_24285, v_x_24286})));
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam37(V self, V *args) {
  V v_x_24286 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_hd_24284 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_k_24285 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_24287 = (g_heff_2elsp_2elsp_2ecodeActions_24s75863562x326130314(heff_dup(v_x_24286), v_p_243));
  V f_ = v_c_24287;
  heff_room[0] = heff_dup(v_hd_24284);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam38, 1, 4, (V[]){v_id_242, v_hd_24284, v_k_24285, v_x_24286});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam36(V self, V *args) {
  V v_hd_24284 = args[0];
  V v_k_24285 = args[1];
  V v_c_24283 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24283;
  args[0] = heff_dup(v_hd_24284);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam37, 1, 4, (V[]){v_p_243, v_hd_24284, v_id_242, v_k_24285});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam41(V self, V *args) {
  V v_x_24304 = args[0];
  V v_k_24303 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24304);
  V f_ = v_k_24303;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam40(V self, V *args) {
  V v_hd_24302 = args[0];
  V v_k_24303 = args[1];
  V v_c_24301 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24301;
  args[0] = v_hd_24302;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086_lam41, 1, 2, (V[]){v_k_24303, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str0, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str1, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str2, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str3, 13, "textDocument/");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str4, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str5, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str6, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str7, 9, "shut down");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str8, 6, "params");
V g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_entry, 2, 0};

V g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578(V v_st_240, V v_msg_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_json_2eat_24cpr(v_t_242, heff_dup(v_msg_241)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_t_2414;
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_it1_247 = v_field_245;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_JNull: {
        v_t_2414 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        V v_s_2411 = heff_field(v_it1_247, 0);
        V v_ru_24it1_247_24JString = heff_take_reuse_n(v_it1_247, 1ULL, 1);
        v_t_2414 = heff_tag_at_n(v_ru_24it1_247_24JString, TAG_Just, 1, (V[]){v_s_2411});
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_247, 0ULL, 1);
        v_t_2414 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_247);
      }
    } else {
      heff_drop(v_field_245);
      v_t_2414 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nothing: {
      heff_drop(v_msg_241);
      return heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_lam0, 2, 1, (V[]){v_st_240});
    }
    case TAG_Just: {
      V v_m_2417 = heff_field(v_t_2414, 0);
      V v_ru_24t_2414_24Just = heff_take_reuse_n(v_t_2414, 1ULL, 1);
      V v_t_2432;
      switch (heff_tag_of(v_msg_241)) {
      case TAG_JNull: {
        heff_drop_cell(v_ru_24t_2414_24Just, 1);
        v_t_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_drop_cell(v_ru_24t_2414_24Just, 1);
        v_t_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_drop_cell(v_ru_24t_2414_24Just, 1);
        v_t_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_drop_cell(v_ru_24t_2414_24Just, 1);
        v_t_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        heff_drop_cell(v_ru_24t_2414_24Just, 1);
        v_t_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JArray: {
        heff_drop_cell(v_ru_24t_2414_24Just, 1);
        v_t_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        V v_fs_2423 = heff_dup(heff_field(v_msg_241, 0));
        HeffT2 v_t_2424 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str1); V a_1 = v_fs_2423; HeffT2 r_ = (g_list_2efind_24s465947678x1101118081_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2426 = v_t_2424.f[1];
          int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
          if ((v_tag_2425 == ((int64_t)0ULL))) {
            V v_p_2428 = v_field_2426;
            V v_t_2431;
            switch (heff_tag_of(v_p_2428)) {
            case TAG_MkPair: {
              V v_y_2430 = heff_field(v_p_2428, 1);
              heff_take_n(v_p_2428, 2ULL, 2);
              v_t_2431 = v_y_2430;
              break;
            }
            default: heff_nomatch(v_p_2428);
            }
            v_t_2432 = heff_tag_at_n(v_ru_24t_2414_24Just, TAG_Just, 1, (V[]){v_t_2431});
          } else {
            heff_drop_cell(v_ru_24t_2414_24Just, 1);
            heff_drop(v_field_2426);
            v_t_2432 = NTAG(TAG_Nothing);
          }
        }
        break;
      }
      default: heff_nomatch(v_msg_241);
      }
      switch (heff_tag_of(v_t_2432)) {
      case TAG_Nothing: {
        V v_p_2446;
        switch (heff_tag_of(v_msg_241)) {
        case TAG_JNull: {
          v_p_2446 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_msg_241, 0ULL, 1);
          v_p_2446 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_msg_241, 0ULL, 1);
          v_p_2446 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_msg_241, 0ULL, 1);
          v_p_2446 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_msg_241, 0ULL, 1);
          v_p_2446 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_msg_241, 0ULL, 1);
          v_p_2446 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JObject: {
          V v_fs_2438 = heff_field(v_msg_241, 0);
          heff_take_n(v_msg_241, 1ULL, 1);
          HeffT2 v_t_2439 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str2); V a_1 = v_fs_2438; HeffT2 r_ = (g_list_2efind_24s465947678x1101118081_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          {
            V v_field_2441 = v_t_2439.f[1];
            int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
            if ((v_tag_2440 == ((int64_t)0ULL))) {
              V v_p_2443 = v_field_2441;
              switch (heff_tag_of(v_p_2443)) {
              case TAG_MkPair: {
                V v_y_2445 = heff_field(v_p_2443, 1);
                heff_take_n(v_p_2443, 2ULL, 2);
                v_p_2446 = v_y_2445;
                break;
              }
              default: heff_nomatch(v_p_2443);
              }
            } else {
              heff_drop(v_field_2441);
              v_p_2446 = NTAG(TAG_JNull);
            }
          }
          break;
        }
        default: heff_nomatch(v_msg_241);
        }
        V v_t_2449;
        if (heff_strEq_c(heff_strSlice_lent(v_m_2417, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str3))) {
          v_t_2449 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_st_240, 119ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
        } else {
          if (heff_strEq_c_lent(v_m_2417, ((V)&g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str4), 2)) {
            v_t_2449 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_st_240, 119ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
          } else {
            v_t_2449 = v_st_240;
          }
        }
        return ({ V a_0 = v_t_2449; V a_1 = v_m_2417; V a_2 = v_p_2446; V r_ = (g_heff_2elsp_2elsp_2enotified_24s711859171x1893296689(a_0, a_1, a_2)); heff_drop(v_m_2417); r_; });
      }
      case TAG_Just: {
        V v_id_2450 = heff_field(v_t_2432, 0);
        heff_take_n(v_t_2432, 1ULL, 1);
        V v_t_2451 = heff_dup(heff_rfield(v_st_240, 5));
        if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
          heff_drop(v_t_2451);
          if (heff_strEq_c_lent(v_m_2417, ((V)&g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str5), 2)) {
            V v_t_2466;
            switch (heff_tag_of(v_msg_241)) {
            case TAG_JNull: {
              v_t_2466 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JBool: {
              heff_take_n(v_msg_241, 0ULL, 1);
              v_t_2466 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JInt: {
              heff_take_n(v_msg_241, 0ULL, 1);
              v_t_2466 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JFloat: {
              heff_take_na(v_msg_241, 0ULL, 1);
              v_t_2466 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JString: {
              heff_take_n(v_msg_241, 0ULL, 1);
              v_t_2466 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JArray: {
              heff_take_n(v_msg_241, 0ULL, 1);
              v_t_2466 = NTAG(TAG_JNull);
              break;
            }
            case TAG_JObject: {
              V v_fs_2458 = heff_field(v_msg_241, 0);
              heff_take_n(v_msg_241, 1ULL, 1);
              HeffT2 v_t_2459 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str6); V a_1 = v_fs_2458; HeffT2 r_ = (g_list_2efind_24s465947678x1101118081_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
              {
                V v_field_2461 = v_t_2459.f[1];
                int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
                if ((v_tag_2460 == ((int64_t)0ULL))) {
                  V v_p_2463 = v_field_2461;
                  switch (heff_tag_of(v_p_2463)) {
                  case TAG_MkPair: {
                    V v_y_2465 = heff_field(v_p_2463, 1);
                    heff_take_n(v_p_2463, 2ULL, 2);
                    v_t_2466 = v_y_2465;
                    break;
                  }
                  default: heff_nomatch(v_p_2463);
                  }
                } else {
                  heff_drop(v_field_2461);
                  v_t_2466 = NTAG(TAG_JNull);
                }
              }
              break;
            }
            default: heff_nomatch(v_msg_241);
            }
            return (g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086(v_st_240, v_m_2417, v_id_2450, v_t_2466));
          } else {
            heff_drop(v_msg_241);
            heff_drop(v_m_2417);
            V v_c_2467 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s499979881x1483620057(v_id_2450, MK_INT(-32600LL), ((V)&g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str7)));
            return heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_lam1, 2, 2, (V[]){v_c_2467, v_st_240});
          }
        } else {
          heff_drop(v_t_2451);
          V v_t_2484;
          switch (heff_tag_of(v_msg_241)) {
          case TAG_JNull: {
            v_t_2484 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_msg_241, 0ULL, 1);
            v_t_2484 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_msg_241, 0ULL, 1);
            v_t_2484 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_msg_241, 0ULL, 1);
            v_t_2484 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_msg_241, 0ULL, 1);
            v_t_2484 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_msg_241, 0ULL, 1);
            v_t_2484 = NTAG(TAG_JNull);
            break;
          }
          case TAG_JObject: {
            V v_fs_2476 = heff_field(v_msg_241, 0);
            heff_take_n(v_msg_241, 1ULL, 1);
            HeffT2 v_t_2477 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_str8); V a_1 = v_fs_2476; HeffT2 r_ = (g_list_2efind_24s465947678x1101118081_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
            {
              V v_field_2479 = v_t_2477.f[1];
              int64_t v_tag_2478 = ((int64_t)v_t_2477.f[0]);
              if ((v_tag_2478 == ((int64_t)0ULL))) {
                V v_p_2481 = v_field_2479;
                switch (heff_tag_of(v_p_2481)) {
                case TAG_MkPair: {
                  V v_y_2483 = heff_field(v_p_2481, 1);
                  heff_take_n(v_p_2481, 2ULL, 2);
                  v_t_2484 = v_y_2483;
                  break;
                }
                default: heff_nomatch(v_p_2481);
                }
              } else {
                heff_drop(v_field_2479);
                v_t_2484 = NTAG(TAG_JNull);
              }
            }
            break;
          }
          default: heff_nomatch(v_msg_241);
          }
          return (g_heff_2elsp_2elsp_2erequest_24s678537686x1689231086(v_st_240, v_m_2417, v_id_2450, v_t_2484));
        }
      }
      default: return heff_nomatch(v_t_2432);
      }
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
}
V g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_lam2(V self, V *args) {
  V v_x_2470 = args[0];
  V v_k_2469 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2470);
  V f_ = v_k_2469;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_lam1(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  V v_c_2467 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2467;
  args[0] = v_hd_2468;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578_lam2, 1, 2, (V[]){v_k_2469, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam0, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam4, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_entry, 3, 0};

V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510(V v_st_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  HEFF_LAST return g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_247}), heff_dup(v_hd_241), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam1, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242}));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam0(V self, V *args) {
  V v_n_243 = args[0];
  return v_n_243;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510(v_x_2421, v_hd_241, v_k_242));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam4(V self, V *args) {
  V v_n_2422 = args[0];
  return v_n_2422;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510(v_x_2432, v_hd_241, v_k_242));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2428 = (g_std_2emap_2etoListOnto(heff_rfield(v_st_240, 2), NTAG(TAG_Nil)));
  V v_t_2429 = (g_list_2efilter_24s1351460748x1231260144(v_x_2427, v_t_2428));
  V v_t_2430 = (g_list_2emap_24s1415906091x1371825187(v_t_2429));
  V v_c_2431 = ({ V a_0 = v_st_240; V a_1 = v_t_2430; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039(a_0, a_1)); heff_drop(v_t_2430); r_; });
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam6, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Message: {
    V v_msg_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    V v_c_2420 = (g_heff_2elsp_2elsp_2ehandle_24s1793471436x1635934578(v_st_240, v_msg_2419));
    V f_ = v_c_2420;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam3, 1, 2, (V[]){v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Timeout: {
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam4_clo)})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), heff_dup(v_hd_241), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam5, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242})));
  }
  case TAG_Closed: {
    heff_drop_rec(v_st_240, 7);
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){MK_INT(1LL)})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_hd_241, v_k_242));
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = (g_std_2emap_2etoListOnto(heff_rfield(v_st_240, 2), NTAG(TAG_Nil)));
  V v_t_2410 = (g_list_2emap_24s366344330x1145113647(v_t_249));
  V v_t_2417;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nil: {
    heff_drop(v_x_248);
    v_t_2417 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_d_2411 = heff_field(v_t_2410, 0);
    V v_ds_2412 = heff_field(v_t_2410, 1);
    heff_take_n(v_t_2410, 3ULL, 2);
    V v_t_2413 = ({ V a_0 = v_d_2411; V a_1 = v_ds_2412; V r_ = (g_list_2efoldl_24s361191175x1417189158(a_0, a_1)); heff_drop(v_ds_2412); r_; });
    V v_y_2414 = heff_intSub(v_t_2413, v_x_248);
    V v_t_2416;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_2414, 1)) {
      v_t_2416 = v_y_2414;
    } else {
      heff_drop(v_y_2414);
      v_t_2416 = MK_INT(0LL);
    }
    v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  return (g_heff_2elsp_2erpc_2eawait_24s1780555806x701913170(v_t_2417, heff_dup(v_hd_241), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_lam2, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242})));
}