// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_UriPath 39251
#define LBL_checked 974171621
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_severity 75955546
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_st__text__program[] = {LBL_st, LBL_text, LBL_program};
static uint32_t shape_uri__text[] = {LBL_uri, LBL_text};
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_heff_2ebuild_2edriver_2etraceless(V);
V g_heff_2ebuild_2edriver_2etraceless_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etraceless_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
HeffT2 g_heff_2ebuild_2equery_2edefinitionAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2edocMarkdown(V);
V g_heff_2ebuild_2equery_2edocMarkdown_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMarkdown_clo;
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
HeffT2 g_heff_2ebuild_2equery_2etypeAt_24cpr(V, V);
V g_heff_2elsp_2elsp_2ebrokenImport(V, V);
V g_heff_2elsp_2elsp_2ebrokenImport_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ebrokenImport_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL(V);
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V, V);
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo;
V g_heff_2elsp_2elsp_2echanged(V, V, V);
V g_heff_2elsp_2elsp_2echanged_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echanged_clo;
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224(V, V, V);
V g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842(V, V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842_clo;
V g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571(V, V, V);
V g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986(V, V);
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_clo;
V g_heff_2elsp_2elsp_2ehoverOf(V, V);
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472(V, V, V);
V g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472_clo;
V g_heff_2elsp_2elsp_2elocations_24s380836666x674785152(V, V, V);
V g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubRoots_24dps(V, V);
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources_24dps(V, V);
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101(V, V, V);
V g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2eregistration_get(void);
V g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246_clo;
V g_heff_2elsp_2elsp_2etargetIn(V, V, V, V, V);
V g_heff_2elsp_2elsp_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2etargetIn_clo;
V g_heff_2elsp_2elsp_2eunits16Go(V, V, V, V);
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eunits16Go_clo;
V g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642(V, V, V);
V g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_clo;
V g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291(V, V, V);
V g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2erepeated(V, V);
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eany_24s1497517957x114012878(V);
V g_list_2eany_24s1497517957x114012878_entry(V self, V *a);
extern Clo g_list_2eany_24s1497517957x114012878_clo;
V g_list_2eany_24s2002848564x1372628513(V, V);
V g_list_2eany_24s2002848564x1372628513_entry(V self, V *a);
extern Clo g_list_2eany_24s2002848564x1372628513_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1064353769x1815078842(V);
V g_list_2efilter_24s1064353769x1815078842_entry(V self, V *a);
extern Clo g_list_2efilter_24s1064353769x1815078842_clo;
V g_list_2efilter_24s225982729x766830498(V, V);
V g_list_2efilter_24s225982729x766830498_entry(V self, V *a);
extern Clo g_list_2efilter_24s225982729x766830498_clo;
V g_list_2efilter_24s230260935x702529747(V, V);
V g_list_2efilter_24s230260935x702529747_entry(V self, V *a);
extern Clo g_list_2efilter_24s230260935x702529747_clo;
V g_list_2efilter_24s951260806x709953240(V, V);
V g_list_2efilter_24s951260806x709953240_entry(V self, V *a);
extern Clo g_list_2efilter_24s951260806x709953240_clo;
HeffT2 g_list_2efind_24s1637307977x1351693783_24cpr(V, V, V, V, V, V);
HeffT2 g_list_2efind_24s727666736x1458251130_24cpr(V, V);
V g_list_2efoldl_24f1046331721x1909432377(V, V, V);
V g_list_2efoldl_24f1046331721x1909432377_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1046331721x1909432377_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f738852651x284559611(V, V);
V g_prelude_2e_2b_2b_24f738852651x284559611_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f738852651x284559611_clo;
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);

static V g_heff_2elsp_2elsp_2ejfalse_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejfalse_st;
static V g_heff_2elsp_2elsp_2ejfalse_init(void) {
  return heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2elsp_2elsp_2ejfalse_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejfalse_st)) return g_heff_2elsp_2elsp_2ejfalse_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejfalse_val, &g_heff_2elsp_2elsp_2ejfalse_st, g_heff_2elsp_2elsp_2ejfalse_init);
}
Clo g_heff_2elsp_2elsp_2eunits16Go_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eunits16Go_entry, 4, 0};

V g_heff_2elsp_2elsp_2eunits16Go(V v_src_240, V v_i_241, V v_j_242, V v_n_243) {
top: ;
  if (heff_intLe_c_lent(v_j_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return v_n_243;
  } else {
    if (heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241))) {
      heff_drop(v_i_241);
      heff_drop(v_j_242);
      return v_n_243;
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) < ((int64_t)128ULL))) {
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_j_242;
        V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_n_243 = t_3;
        goto top;
      } else {
        V v_t_247 = heff_intAdd(heff_dup(v_i_241), heff_strRuneWidth_lent(v_src_240, v_i_241, 0));
        V v_t_248 = heff_runeToInt(heff_strRuneAt_lent(v_src_240, v_i_241, 2));
        V v_t_2410;
        if (heff_intLe_c(MK_INT(65536LL), v_t_248)) {
          v_t_2410 = MK_INT(2LL);
        } else {
          v_t_2410 = MK_INT(1LL);
        }
        V t_0 = v_src_240;
        V t_1 = v_t_247;
        V t_2 = v_j_242;
        V t_3 = heff_intAdd(v_n_243, v_t_2410);
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_n_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eunits16Go(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2eoffsetGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetGo_entry, 5, 0};

V g_heff_2elsp_2elsp_2eoffsetGo(V v_src_240, V v_line_241, V v_ch_242, V v_i_243, V v_l_244) {
top: ;
  if (heff_intLe_c_lent(v_line_241, v_l_244, 0)) {
    heff_drop(v_line_241);
    heff_drop(v_l_244);
    V v_j_246 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str0), v_src_240, v_i_243, 1);
    V v_t_248;
    if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
      heff_drop(v_j_246);
      v_t_248 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_248 = v_j_246;
    }
    return (g_heff_2elsp_2elsp_2eoffset16(v_src_240, v_i_243, v_t_248, v_ch_242));
  } else {
    V v_j_249 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str1), v_src_240, v_i_243, 5);
    if (heff_intLt_c_lent(v_j_249, MK_INT(0LL), 2)) {
      heff_drop(v_line_241);
      heff_drop(v_ch_242);
      heff_drop(v_l_244);
      heff_drop(v_j_249);
      return heff_strLength_lent(v_src_240, 0);
    } else {
      V t_0 = v_src_240;
      V t_1 = v_line_241;
      V t_2 = v_ch_242;
      V t_3 = heff_intAdd(v_j_249, MK_INT(1LL));
      V t_4 = heff_intAdd(v_l_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_line_241 = t_1;
      v_ch_242 = t_2;
      v_i_243 = t_3;
      v_l_244 = t_4;
      goto top;
    }
  }
}
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffsetGo(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str0, 8, "severity");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str1, 6, "source");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str2, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str3, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str4, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str5, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str6, 1, "E");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str7, 1, "W");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str8, 1, "D");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str9, 1, "0");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str10, 4, "code");
Clo g_heff_2elsp_2elsp_2ediagnostic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagnostic_entry, 2, 0};

V g_heff_2elsp_2elsp_2ediagnostic(V v_src_240, V v_d_241) {
top: ;
  V v_t_242 = (g_heff_2elsp_2elsp_2erange(v_src_240, heff_take_field(v_d_241, 3)));
  V v_t_243 = heff_dup(heff_rfield(v_d_241, 1));
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SError: {
    v_t_244 = MK_INT(1LL);
    break;
  }
  case TAG_SWarning: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_SDebug: {
    v_t_244 = MK_INT(4LL);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str0), heff_tag_n(TAG_JInt, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str1), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str2)})});
  V v_t_247 = heff_take_field(v_d_241, 4);
  V v_t_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    v_t_249 = heff_dup(heff_rfield(v_d_241, 2));
    break;
  }
  case TAG_Just: {
    V v_n_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 2)), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ediagnostic_str3), v_n_248));
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str4), heff_tag_n(TAG_JString, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str5), v_t_242}), v_t_2412});
  V v_t_2422;
  if (heff_intEq_c(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL))) {
    heff_drop_rec(v_d_241, 5);
    v_t_2422 = NTAG(TAG_Nil);
  } else {
    V v_t_2415 = heff_take_field(v_d_241, 1);
    V v_t_2416;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_SError: {
      v_t_2416 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str6);
      break;
    }
    case TAG_SWarning: {
      v_t_2416 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str7);
      break;
    }
    case TAG_SDebug: {
      v_t_2416 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str8);
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    V v_t_2417 = (g_heff_2elsp_2erender_2enumDigits(heff_dup(heff_rfield(v_d_241, 0))));
    V v_t_2418 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_2417), ((V)&g_heff_2elsp_2elsp_2ediagnostic_str9)));
    V v_t_2419 = heff_intShow(heff_get_n(v_d_241, 0, 5));
    V v_t_2420 = heff_strAppend(v_t_2416, heff_strAppend(v_t_2418, v_t_2419));
    V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str10), heff_tag_n(TAG_JString, 1, (V[]){v_t_2420})});
    v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  }
  V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2422));
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2423});
}
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ediagnostic(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str1, 1, "s");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str2, 6, " error");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str3, 22, ") does not elaborate: ");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str4, 2, " (");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str5, 7, "module ");
Clo g_heff_2elsp_2elsp_2ebrokenImport_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ebrokenImport_entry, 2, 0};

V g_heff_2elsp_2elsp_2ebrokenImport(V v_imports_240, V v_c_241) {
top: ;
  V v_x1_242 = (g_list_2efilter_24s1064353769x1815078842(heff_dup(heff_rfield(v_c_241, 6))));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_imports_240);
    heff_drop_rec(v_c_241, 14);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    heff_take_n(v_x1_242, 0ULL, 2);
    V v_t_245 = (g_list_2eany_24s2002848564x1372628513(heff_dup(v_c_241), v_imports_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      HeffT2 v_t_246 = (g_list_2efind_24s727666736x1458251130_24cpr(heff_rfield(v_c_241, 0), v_imports_240));
      V v_sp_2411;
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_i_2410 = v_field_248;
          v_sp_2411 = heff_get_n(v_i_2410, 2, 3);
        } else {
          heff_drop(v_field_248);
          v_sp_2411 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
        }
      }
      V v_t_2412 = (g_list_2efoldl_24f1046331721x1909432377(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 6)));
      V v_t_2413 = (g_list_2efoldl_24f1046331721x1909432377(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 6)));
      V v_t_2415;
      if (heff_intEq_c(v_t_2413, MK_INT(1LL))) {
        v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ebrokenImport_str0);
      } else {
        v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ebrokenImport_str1);
      }
      V v_t_2416 = heff_strAppend(heff_intShow(v_t_2412), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str2), v_t_2415));
      V v_t_2417 = heff_strAppend(heff_take_field(v_c_241, 1), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str3), v_t_2416));
      V v_t_2418 = heff_strAppend(heff_get_n(v_c_241, 0, 14), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str4), v_t_2417));
      V v_msg_2419 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str5), v_t_2418);
      V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SWarning), v_msg_2419, v_sp_2411, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
    } else {
      heff_drop(v_imports_240);
      heff_drop_rec(v_c_241, 14);
      heff_drop(v_t_245);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2elsp_2elsp_2ebrokenImport_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ebrokenImport(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecatMaybesL_entry, 1, 0};

V g_heff_2elsp_2elsp_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2elsp_2elsp_2ecatMaybesL_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecatMaybesL(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str1, 1, " ");
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ediagsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagsOf_entry, 3, 0};

V g_heff_2elsp_2elsp_2ediagsOf(V v_src_240, V v_program_241, V v_errors_242) {
top: ;
  V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_241)));
  V v_t_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    v_t_246 = heff_get_n(v_x_244, 6, 14);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam0, 1, 1, (V[]){heff_dup(v_src_240)}), v_errors_242));
  V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_241));
  V v_xs_2418 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2417; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2418));
  V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam1, 1, 1, (V[]){v_src_240}), v_t_2419));
  V v_t_2423 = (g_heff_2elsp_2elsp_2ecatMaybesL(v_t_2422));
  V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2423));
  return (g_prelude_2e_2b_2b(v_t_246, v_t_2424));
}
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ediagsOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_imports_249 = heff_get_n(v_t_248, 0, 4);
  HeffT2 v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str0); V a_2 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str1); V a_3 = v_e_247; V b_4 = MK_INT(0LL); V a_5 = v_imports_249; HeffT2 r_ = (g_list_2efind_24s1637307977x1351693783_24cpr(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(b_4); r_; });
  V v_sp_2415;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_i_2414 = v_field_2412;
      v_sp_2415 = heff_get_n(v_i_2414, 2, 3);
    } else {
      heff_drop(v_field_2412);
      v_sp_2415 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
    }
  }
  return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_e_247, v_sp_2415, NTAG(TAG_Nothing)});
}
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args) {
  V v_c_2420 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  return (g_heff_2elsp_2elsp_2ebrokenImport(heff_get_n(v_t_2421, 0, 4), v_c_2420));
}
Clo g_heff_2elsp_2elsp_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeptOf_entry, 1, 0};

V g_heff_2elsp_2elsp_2ekeptOf(V v_program_240) {
top: ;
  V v_x1_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_240)));
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_program_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2edriver_2etraceless(v_x_242));
    V v_t_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
    V v_xs_247 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_246; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_247));
    return (g_prelude_2e_2b_2b_24f738852651x284559611(v_t_245, v_t_248));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ekeptOf(a[0]);
}
Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubSources_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_ss_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_s_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2efilter_24s225982729x766830498(v_s_242, v_ss_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubSources_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str0, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str1, 8, "markdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str2, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str3, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str4, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str5, 4, "\012```");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str6, 11, "\012```\012\012---\012\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str7, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str8, 5, "value");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str9, 8, "contents");
Clo g_heff_2elsp_2elsp_2ehoverOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehoverOf_entry, 2, 0};

V g_heff_2elsp_2elsp_2ehoverOf(V v_a_240, V v_p_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_a_240, 2))));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_a_240, 3);
    heff_drop(v_p_241);
    return NTAG(TAG_JNull);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Cons = heff_take_reuse_n(v_x1_242, 1ULL, 2);
    V v_t_245 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_a_240, 1), heff_dup(v_p_241)));
    HeffT2 v_t_246 = (g_heff_2ebuild_2equery_2etypeAt_24cpr(v_x_243, v_t_245));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_t_2410 = v_field_248;
        V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str1)})});
        V v_off_2412 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_a_240, 1), v_p_241));
        HeffT2 v_t_2413 = (g_heff_2ebuild_2equery_2edefinitionAt_24cpr(heff_get_n(v_a_240, 2, 3), v_off_2412));
        V v_doc_2423;
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_d_2417 = v_field_2415;
            V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_d_2417, 2)), 0, 2);
            V v_start_2419 = (g_heff_2ebuild_2equery_2elineStartOf(heff_rfield(v_d_2417, 1), v_t_2418));
            V v_t_2420 = ({ V b_0 = heff_get_n(v_d_2417, 1, 3); V a_1 = v_start_2419; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ecommentAbove(b_0, a_1, a_2)); heff_drop(b_0); r_; });
            V v_t_2421 = (g_list_2emap_24s1819241345x1511673126(v_t_2420));
            V v_t_2422 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2421));
            v_doc_2423 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2ebuild_2equery_2edocMarkdown(a_0)); heff_drop(v_t_2422); r_; });
          } else {
            heff_drop(v_field_2415);
            v_doc_2423 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str2);
          }
        }
        V v_t_2426;
        if (heff_strEq_c_lent(v_doc_2423, ((V)&g_heff_2elsp_2elsp_2ehoverOf_str3), 2)) {
          heff_drop(v_doc_2423);
          v_t_2426 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2elsp_2elsp_2ehoverOf_str5)));
        } else {
          V v_t_2425 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str6), v_doc_2423));
          v_t_2426 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str7), v_t_2425);
        }
        V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str8), heff_tag_n(TAG_JString, 1, (V[]){v_t_2426})});
        V v_t_2428 = heff_tag_at_n(v_ru_24x1_242_24Cons, TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
        V v_t_2429 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2428})});
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str9), v_t_2429}), NTAG(TAG_Nil)});
        return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2430});
      } else {
        heff_drop_rec(v_a_240, 3);
        heff_drop(v_p_241);
        heff_drop_cell(v_ru_24x1_242_24Cons, 2);
        heff_drop(v_field_248);
        return NTAG(TAG_JNull);
      }
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehoverOf(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_cs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_241), heff_hole()});
    V v_t_244 = (g_list_2efilter_24s230260935x702529747(v_c_241, v_cs_242));
    V v_u_245 = (g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubCheckedPaths(a[0]);
}
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2efilter_24s230260935x702529747(v_c_242, v_cs_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubRoots_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_r_242; V a_1 = v_rs_243; V r_ = (g_list_2efilter_24s951260806x709953240(a_0, a_1)); heff_drop(v_r_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubRoots_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str2, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str3, 10, "heff-watch");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str4, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str5, 25, "client/registerCapability");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str6, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str7, 10, "heff-watch");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str8, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str9, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str10, 11, "globPattern");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str11, 7, "**/*.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str12, 8, "watchers");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str13, 15, "registerOptions");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str14, 13, "registrations");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str15, 6, "params");

static V g_heff_2elsp_2elsp_2eregistration_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2eregistration_st;
static V g_heff_2elsp_2elsp_2eregistration_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str1)})});
  V v_t_241 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str2), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str3)})});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str4), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str5)})});
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str6), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str7)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str8), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str9)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str10), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str11)})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_246}), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str12), heff_tag_n(TAG_JArray, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str13), heff_tag_n(TAG_JObject, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str14), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str15), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_2417})});
  return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_2418})});
}
V g_heff_2elsp_2elsp_2eregistration_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2eregistration_st)) return g_heff_2elsp_2elsp_2eregistration_val;
  return heff_global(&g_heff_2elsp_2elsp_2eregistration_val, &g_heff_2elsp_2elsp_2eregistration_st, g_heff_2elsp_2elsp_2eregistration_init);
}
Clo g_heff_2elsp_2elsp_2echanged_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echanged_entry, 3, 0};

V g_heff_2elsp_2elsp_2echanged(V v_st_240, V v_f_241, V v_text_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_240, 0), v_f_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_d_247 = v_field_245;
      V v_t_248 = ({ V rv_1 = v_text_242; V rr_ = heff_rec_reuse_nf(v_d_247, 1ULL, 2, shape_uri__text, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_d_249 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_st_240, 0), v_f_241, v_t_248));
      return ({ V rv_0 = v_d_249; V rr_ = heff_rec_reuse_nf(v_st_240, 126ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16380u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    } else {
      heff_drop(v_f_241);
      heff_drop(v_text_242);
      heff_drop(v_field_245);
      return v_st_240;
    }
  }
}
V g_heff_2elsp_2elsp_2echanged_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echanged(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_str1, 12, "textDocument");
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam0, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam1, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam2, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam3, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam4, 1, 0};
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam5, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam6, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam7(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam7, 2, 0};
Clo g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_entry, 2, 0};

V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986(V v_wire_240, V v_p_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_str1), v_t_242}), v_p_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_it1_247 = v_field_245;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_JNull: {
        heff_drop(v_wire_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam0_clo);
      }
      case TAG_JBool: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop(v_wire_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam1_clo);
      }
      case TAG_JInt: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop(v_wire_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam2_clo);
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_247, 0ULL, 1);
        heff_drop(v_wire_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam3_clo);
      }
      case TAG_JString: {
        V v_s_2419 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 1);
        V v_t_2421 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_UriPath, 2, (V[]){v_s_2419, ((V)&g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam4_clo)})}));
        return heff_tail(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2421});
      }
      case TAG_JArray: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop(v_wire_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam5_clo);
      }
      case TAG_JObject: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop(v_wire_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam6_clo);
      }
      default: return heff_nomatch(v_it1_247);
      }
    } else {
      heff_drop(v_wire_240);
      heff_drop(v_field_245);
      return ((V)&g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam7_clo);
    }
  }
}
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam3(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam4(V self, V *args) {
  V v_p_2420 = args[0];
  return v_p_2420;
}
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam5(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_lam7(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842_entry, 5, 0};

V g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842(V v_wire_240, V v_st_241, V v_x2_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_wire_240);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){v_st_241});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    V v_c_247 = (g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224(heff_dup(v_wire_240), v_st_241, heff_dup(v_f_245)));
    return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842_lam0, 1, 4, (V[]){v_wire_240, heff_dup(v_rest_246), v_z_243, v_z_244})});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_wire_240; V a_1 = v_x_248; V a_2 = v_rest_246; V a_3 = v_z_243; V a_4 = v_z_244; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s975024555x818489842(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_246); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_str1, 0, "");
V g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_entry, 3, 0};

V g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642(V v_wire_240, V v_st_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986(heff_dup(v_wire_240), v_p_242));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_lam0, 2, 3, (V[]){v_c_243, v_st_241, v_wire_240});
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_d_2413 = heff_env(self)[0];
  V v_f_248 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2430 = heff_get_n(v_d_2413, 1, 2);
  HeffT2 v_t_2431 = ({ V a_0 = heff_rfield(v_x_2429, 1); V a_1 = v_f_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_f_248); r_; });
  V v_x_2437;
  {
    V v_field_2433 = v_t_2431.f[1];
    int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
    if ((v_tag_2432 == ((int64_t)0ULL))) {
      V v_c_2435 = v_field_2433;
      if (heff_strEq_c(heff_dup(heff_rfield(v_c_2435, 0)), heff_dup(v_text_2430))) {
        v_x_2437 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2429, v_text_2430, heff_get_n(v_c_2435, 1, 2)});
      } else {
        heff_drop_rec(v_c_2435, 2);
        v_x_2437 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2429, v_text_2430, NTAG(TAG_Nil)});
      }
    } else {
      heff_drop(v_field_2433);
      v_x_2437 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2429, v_text_2430, NTAG(TAG_Nil)});
    }
  }
  V f_ = v_k_245;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_lam3(V self, V *args) {
  V v_x_2439 = args[0];
  V v_d_2413 = heff_env(self)[0];
  V v_f_248 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2440 = heff_get_n(v_d_2413, 1, 2);
  HeffT2 v_t_2441 = ({ V a_0 = heff_rfield(v_x_2439, 1); V a_1 = v_f_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_f_248); r_; });
  V v_x_2447;
  {
    V v_field_2443 = v_t_2441.f[1];
    int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
    if ((v_tag_2442 == ((int64_t)0ULL))) {
      V v_c_2445 = v_field_2443;
      if (heff_strEq_c(heff_dup(heff_rfield(v_c_2445, 0)), heff_dup(v_text_2440))) {
        v_x_2447 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2439, v_text_2440, heff_get_n(v_c_2445, 1, 2)});
      } else {
        heff_drop_rec(v_c_2445, 2);
        v_x_2447 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2439, v_text_2440, NTAG(TAG_Nil)});
      }
    } else {
      heff_drop(v_field_2443);
      v_x_2447 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2439, v_text_2440, NTAG(TAG_Nil)});
    }
  }
  V f_ = v_k_245;
  args[0] = v_x_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop(v_wire_240);
    heff_drop(v_hd_244);
    V v_t_247 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_str0), NTAG(TAG_Nil)});
    V f_ = v_k_245;
    args[0] = v_t_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_248 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_241, 0), v_f_248));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_d_2413 = v_field_2411;
        HeffT2 v_t_2414 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_241, 1), v_f_248));
        {
          V v_field_2416 = v_t_2414.f[1];
          int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
          if ((v_tag_2415 == ((int64_t)0ULL))) {
            V v_c_2418 = v_field_2416;
            if (heff_strEq_c(heff_get_n(v_c_2418, 0, 2), heff_dup(heff_rfield(v_d_2413, 1)))) {
              heff_drop(v_wire_240);
              heff_drop(v_hd_244);
              V v_text_2420 = heff_get_n(v_d_2413, 1, 2);
              HeffT2 v_t_2421 = ({ V a_0 = heff_rfield(v_st_241, 1); V a_1 = v_f_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_f_248); r_; });
              V v_x_2427;
              {
                V v_field_2423 = v_t_2421.f[1];
                int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
                if ((v_tag_2422 == ((int64_t)0ULL))) {
                  V v_c_2425 = v_field_2423;
                  if (heff_strEq_c(heff_dup(heff_rfield(v_c_2425, 0)), heff_dup(v_text_2420))) {
                    v_x_2427 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, v_text_2420, heff_get_n(v_c_2425, 1, 2)});
                  } else {
                    heff_drop_rec(v_c_2425, 2);
                    v_x_2427 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, v_text_2420, NTAG(TAG_Nil)});
                  }
                } else {
                  heff_drop(v_field_2423);
                  v_x_2427 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, v_text_2420, NTAG(TAG_Nil)});
                }
              }
              V f_ = v_k_245;
              args[0] = v_x_2427;
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            } else {
              V v_c_2428 = (g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224(v_wire_240, v_st_241, heff_dup(v_f_248)));
              V f_ = v_c_2428;
              heff_room[0] = v_hd_244;
              heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_lam2, 1, 3, (V[]){v_d_2413, v_f_248, v_k_245});
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
          } else {
            heff_drop(v_field_2416);
            V v_c_2438 = (g_heff_2elsp_2elsp_2echeck_24s321153717x1946296224(v_wire_240, v_st_241, heff_dup(v_f_248)));
            V f_ = v_c_2438;
            heff_room[0] = v_hd_244;
            heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_lam3, 1, 3, (V[]){v_d_2413, v_f_248, v_k_245});
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
        }
      } else {
        heff_drop(v_wire_240);
        heff_drop(v_hd_244);
        heff_drop(v_f_248);
        heff_drop(v_field_2411);
        V v_t_2448 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_str1), NTAG(TAG_Nil)});
        V f_ = v_k_245;
        args[0] = v_t_2448;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s1999279900x340594642_lam1, 1, 4, (V[]){v_st_241, v_k_245, v_wire_240, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_entry, 3, 0};

V g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291(V v_wire_240, V v_st_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986(heff_dup(v_wire_240), heff_dup(v_p_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_lam0, 2, 4, (V[]){v_c_243, v_st_241, v_wire_240, v_p_242});
}
V g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_f_248 = heff_env(self)[0];
  V v_d_2413 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2416 = (g_heff_2elsp_2elsp_2etargetIn(heff_take_field(v_x_2415, 0), v_f_248, v_d_2413, v_p_242, heff_get_n(v_x_2415, 1, 2)));
  V f_ = v_k_245;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop(v_wire_240);
    heff_drop(v_hd_244);
    heff_drop(v_p_242);
    V v_t_247 = heff_rec_n(3, shape_st__off__target, (V[]){v_st_241, MK_INT(0LL), NTAG(TAG_Nothing)});
    V f_ = v_k_245;
    args[0] = v_t_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_248 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_st_241, 0), v_f_248));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_d_2413 = v_field_2411;
        V v_c_2414 = (g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101(v_wire_240, v_st_241, heff_dup(v_f_248)));
        V f_ = v_c_2414;
        heff_room[0] = v_hd_244;
        heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_lam2, 1, 4, (V[]){v_f_248, v_d_2413, v_p_242, v_k_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_wire_240);
        heff_drop(v_hd_244);
        heff_drop(v_p_242);
        heff_drop(v_f_248);
        heff_drop(v_field_2411);
        V v_t_2417 = heff_rec_n(3, shape_st__off__target, (V[]){v_st_241, MK_INT(0LL), NTAG(TAG_Nothing)});
        V f_ = v_k_245;
        args[0] = v_t_2417;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s184296485x1203435291_lam1, 1, 5, (V[]){v_st_241, v_k_245, v_wire_240, v_hd_244, v_p_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_lam0, 2, 0};
V g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_entry, 3, 0};

V g_heff_2elsp_2elsp_2elocations_24s380836666x674785152(V v_wire_240, V v_st_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_wire_240);
    heff_drop(v_st_241);
    return ((V)&g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_c_247 = (g_heff_2elsp_2elsp_2elocationOf_24s1940725404x275865472(heff_dup(v_wire_240), heff_dup(v_st_241), v_o_245));
    return heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_lam1, 2, 4, (V[]){v_c_247, v_wire_240, v_st_241, v_rest_246});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elocations_24s380836666x674785152(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = (g_heff_2elsp_2elsp_2elocations_24s380836666x674785152(v_wire_240, v_st_241, v_rest_246));
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_lam3, 1, 2, (V[]){v_k_249, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s380836666x674785152_lam2, 1, 5, (V[]){v_wire_240, v_st_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str0, 4, "only");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str1, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str2, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str3, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str4, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str6, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str7, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str11, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str12, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str13, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str14, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str15, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str16, 5, "start");
V g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_entry, 3, 0};

V g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571(V v_wire_240, V v_a_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986(v_wire_240, heff_dup(v_p_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_lam0, 2, 3, (V[]){v_c_243, v_a_241, v_p_242});
}
V g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop_rec(v_a_241, 3);
    heff_drop(v_p_242);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_Nil);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    V v_x1_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_a_241, 2))));
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_241, 3);
      heff_drop(v_p_242);
      heff_drop(v_hd_244);
      heff_drop(v_f_247);
      V f_ = v_k_245;
      args[0] = NTAG(TAG_Nil);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x1_248, 0);
      V v_ru_24x1_248_24Cons = heff_take_reuse_n(v_x1_248, 1ULL, 2);
      V v_t_2411 = heff_tag_at_n(v_ru_24x1_248_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str0), NTAG(TAG_Nil)});
      HeffT2 v_t_2412 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str1), v_t_2411}), heff_dup(v_p_242)));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        V v_t_2424;
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_it1_2416 = v_field_2414;
          switch (heff_tag_of(v_it1_2416)) {
          case TAG_JNull: {
            v_t_2424 = heff_strEq(heff_dup(heff_rfield(v_x_249, 3)), heff_dup(heff_rfield(v_a_241, 1)));
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2416, 0ULL, 1);
            v_t_2424 = heff_strEq(heff_dup(heff_rfield(v_x_249, 3)), heff_dup(heff_rfield(v_a_241, 1)));
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2416, 0ULL, 1);
            v_t_2424 = heff_strEq(heff_dup(heff_rfield(v_x_249, 3)), heff_dup(heff_rfield(v_a_241, 1)));
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2416, 0ULL, 1);
            v_t_2424 = heff_strEq(heff_dup(heff_rfield(v_x_249, 3)), heff_dup(heff_rfield(v_a_241, 1)));
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2416, 0ULL, 1);
            v_t_2424 = heff_strEq(heff_dup(heff_rfield(v_x_249, 3)), heff_dup(heff_rfield(v_a_241, 1)));
            break;
          }
          case TAG_JArray: {
            V v_xs_2421 = heff_field(v_it1_2416, 0);
            heff_take_n(v_it1_2416, 1ULL, 1);
            V v_t_2422 = ({ V a_0 = v_xs_2421; V r_ = (g_list_2eany_24s1497517957x114012878(a_0)); heff_drop(v_xs_2421); r_; });
            v_t_2424 = heff_bool(((heff_dup(v_t_2422) == NTAG(TAG_True)) && heff_strEq_c(heff_dup(heff_rfield(v_x_249, 3)), heff_dup(heff_rfield(v_a_241, 1)))));
            heff_drop(v_t_2422);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2416, 0ULL, 1);
            v_t_2424 = heff_strEq(heff_dup(heff_rfield(v_x_249, 3)), heff_dup(heff_rfield(v_a_241, 1)));
            break;
          }
          default: heff_nomatch(v_it1_2416);
          }
        } else {
          heff_drop(v_field_2414);
          v_t_2424 = heff_strEq(heff_dup(heff_rfield(v_x_249, 3)), heff_dup(heff_rfield(v_a_241, 1)));
        }
        if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
          heff_drop(v_t_2424);
          V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str2), NTAG(TAG_Nil)});
          HeffT2 v_t_2426 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str3), v_t_2425}), heff_dup(v_p_242)));
          V v_t_2437;
          {
            V v_field_2428 = v_t_2426.f[1];
            int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
            if ((v_tag_2427 == ((int64_t)0ULL))) {
              V v_it1_2430 = v_field_2428;
              switch (heff_tag_of(v_it1_2430)) {
              case TAG_JNull: {
                v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str4);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2430, 0ULL, 1);
                v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str5);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_it1_2430, 0ULL, 1);
                v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str6);
                break;
              }
              case TAG_JFloat: {
                heff_take_na(v_it1_2430, 0ULL, 1);
                v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str7);
                break;
              }
              case TAG_JString: {
                V v_s_2434 = heff_field(v_it1_2430, 0);
                heff_take_n(v_it1_2430, 1ULL, 1);
                v_t_2437 = v_s_2434;
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2430, 0ULL, 1);
                v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str8);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2430, 0ULL, 1);
                v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str9);
                break;
              }
              default: heff_nomatch(v_it1_2430);
              }
            } else {
              heff_drop(v_field_2428);
              v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str10);
            }
          }
          V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str11), NTAG(TAG_Nil)});
          V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str13), v_t_2438})});
          HeffT2 v_t_2440 = (g_json_2eat_24cpr(v_t_2439, heff_dup(v_p_242)));
          V v_t_2466;
          {
            V v_field_2442 = v_t_2440.f[1];
            int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
            V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str14), NTAG(TAG_Nil)});
            V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_str16), v_t_2443})});
            HeffT2 v_t_2445 = (g_json_2eat_24cpr(v_t_2444, v_p_242));
            {
              V v_field_2447 = v_t_2445.f[1];
              int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
              V v_t_2456;
              if ((v_tag_2441 == ((int64_t)0ULL))) {
                V v_it1_2449 = v_field_2442;
                switch (heff_tag_of(v_it1_2449)) {
                case TAG_JNull: {
                  v_t_2456 = MK_INT(0LL);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_it1_2449, 0ULL, 1);
                  v_t_2456 = MK_INT(0LL);
                  break;
                }
                case TAG_JInt: {
                  V v_i_2451 = heff_field(v_it1_2449, 0);
                  heff_take_n(v_it1_2449, 1ULL, 1);
                  v_t_2456 = v_i_2451;
                  break;
                }
                case TAG_JFloat: {
                  double v_x_2452 = heff_tflat_f64(v_it1_2449, 0);
                  heff_take_na(v_it1_2449, 0ULL, 1);
                  v_t_2456 = heff_floor_f64(v_x_2452);
                  break;
                }
                case TAG_JString: {
                  heff_take_n(v_it1_2449, 0ULL, 1);
                  v_t_2456 = MK_INT(0LL);
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_it1_2449, 0ULL, 1);
                  v_t_2456 = MK_INT(0LL);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_it1_2449, 0ULL, 1);
                  v_t_2456 = MK_INT(0LL);
                  break;
                }
                default: heff_nomatch(v_it1_2449);
                }
              } else {
                heff_drop(v_field_2442);
                v_t_2456 = MK_INT(0LL);
              }
              V v_t_2465;
              if ((v_tag_2446 == ((int64_t)0ULL))) {
                V v_it1_2458 = v_field_2447;
                switch (heff_tag_of(v_it1_2458)) {
                case TAG_JNull: {
                  v_t_2465 = MK_INT(0LL);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_it1_2458, 0ULL, 1);
                  v_t_2465 = MK_INT(0LL);
                  break;
                }
                case TAG_JInt: {
                  V v_i_2460 = heff_field(v_it1_2458, 0);
                  heff_take_n(v_it1_2458, 1ULL, 1);
                  v_t_2465 = v_i_2460;
                  break;
                }
                case TAG_JFloat: {
                  double v_x_2461 = heff_tflat_f64(v_it1_2458, 0);
                  heff_take_na(v_it1_2458, 0ULL, 1);
                  v_t_2465 = heff_floor_f64(v_x_2461);
                  break;
                }
                case TAG_JString: {
                  heff_take_n(v_it1_2458, 0ULL, 1);
                  v_t_2465 = MK_INT(0LL);
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_it1_2458, 0ULL, 1);
                  v_t_2465 = MK_INT(0LL);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_it1_2458, 0ULL, 1);
                  v_t_2465 = MK_INT(0LL);
                  break;
                }
                default: heff_nomatch(v_it1_2458);
                }
              } else {
                heff_drop(v_field_2447);
                v_t_2465 = MK_INT(0LL);
              }
              v_t_2466 = (g_heff_2elsp_2elsp_2eoffsetGo(heff_rfield(v_a_241, 1), v_t_2456, v_t_2465, MK_INT(0LL), MK_INT(0LL)));
            }
          }
          return (g_heff_2elsp_2elsp_2esplitIn_24s103140875x1916449246(heff_dup(heff_rfield(v_a_241, 0)), v_f_247, v_t_2437, heff_get_n(v_a_241, 2, 3), v_x_249, v_t_2466, v_hd_244, v_k_245));
        } else {
          heff_drop_rec(v_a_241, 3);
          heff_drop(v_p_242);
          heff_drop(v_hd_244);
          heff_drop(v_f_247);
          heff_drop_rec(v_x_249, 14);
          heff_drop(v_t_2424);
          V f_ = v_k_245;
          args[0] = NTAG(TAG_Nil);
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
      }
    }
    default: return heff_nomatch(v_x1_248);
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ecodeActions_24s515337036x1045558571_lam1, 1, 4, (V[]){v_k_245, v_a_241, v_p_242, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}