// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_PathUri 23459
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Send 26077
#define TAG_UriPath 39251
#define LBL_checked 974171621
#define LBL_code 9554612
#define LBL_defines 1776893014
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_rune 10007553
#define LBL_severity 75955546
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
#define LBL_width 314485216
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_rune__width[] = {LBL_rune, LBL_width};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_uri__text[] = {LBL_uri, LBL_text};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2edriver_2etraceless(V);
V g_heff_2ebuild_2edriver_2etraceless_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etraceless_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
V g_heff_2ebuild_2equery_2ecompletionsAt(V, V);
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo;
V g_heff_2ebuild_2equery_2edefinitionAt(V, V);
V g_heff_2ebuild_2equery_2edefinitionAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionAt_clo;
V g_heff_2ebuild_2equery_2edocMarkdown(V);
V g_heff_2ebuild_2equery_2edocMarkdown_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMarkdown_clo;
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2equery_2etypeAt(V, V);
V g_heff_2ebuild_2equery_2etypeAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etypeAt_clo;
V g_heff_2elsp_2elsp_2ebrokenImport(V, V);
V g_heff_2elsp_2elsp_2ebrokenImport_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ebrokenImport_clo;
V g_heff_2elsp_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2elsp_2ecatMaybesL(V);
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V, V);
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo;
V g_heff_2elsp_2elsp_2echanged(V, V, V);
V g_heff_2elsp_2elsp_2echanged_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echanged_clo;
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(V, V);
V g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878_clo;
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421(V, V);
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_clo;
V g_heff_2elsp_2elsp_2edependentsOf(V, V);
V g_heff_2elsp_2elsp_2edependentsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edependentsOf_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(V);
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_clo;
V g_heff_2elsp_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028(V, V, V);
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_clo;
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493(V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493_clo;
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459(V, V);
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_clo;
V g_heff_2elsp_2elsp_2ehoverOf(V, V);
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2eloadError(V, V);
V g_heff_2elsp_2elsp_2eloadError_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadError_clo;
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873(V, V);
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_clo;
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104(V, V);
V g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
V g_heff_2elsp_2elsp_2enotification_24s270589690x602944811(V, V, V);
V g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotification_24s270589690x602944811_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubRoots(V);
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_clo;
V g_heff_2elsp_2elsp_2enubRoots_24dps(V, V);
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources_24dps(V, V);
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574(V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574_clo;
V g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215(V, V);
V g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215_clo;
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576(V, V);
V g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2eregistration_get(void);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918(V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223_clo;
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277(V, V, V, V);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_clo;
V g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005(V, V);
V g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005_clo;
V g_heff_2elsp_2elsp_2eshiftOf(V, V, V);
V g_heff_2elsp_2elsp_2eshiftOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eshiftOf_clo;
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041(V, V, V);
V g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041_clo;
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573(V, V, V);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573_clo;
V g_heff_2elsp_2elsp_2etargetIn(V, V, V, V, V);
V g_heff_2elsp_2elsp_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2etargetIn_clo;
V g_heff_2elsp_2elsp_2eunits16Go(V, V, V, V);
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eunits16Go_clo;
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(V, V);
V g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544_clo;
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799(V, V);
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2erepeated(V, V);
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2eutil_2ejson_2eat(V, V);
V g_heff_2eutil_2ejson_2eat_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2eat_clo;
V g_heff_2eutil_2ejson_2estringify(V);
V g_heff_2eutil_2ejson_2estringify_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2estringify_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1064353769x1815078842(V);
V g_list_2efilter_24s1064353769x1815078842_entry(V self, V *a);
extern Clo g_list_2efilter_24s1064353769x1815078842_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efind_24s913819130x636901392(V, V);
V g_list_2efind_24s913819130x636901392_entry(V self, V *a);
extern Clo g_list_2efind_24s913819130x636901392_clo;
V g_list_2efoldl_24f1385598430x897993480(V, V, V);
V g_list_2efoldl_24f1385598430x897993480_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1385598430x897993480_clo;
V g_list_2efoldl_24f1992548173x1980409276(V, V, V, V);
V g_list_2efoldl_24f1992548173x1980409276_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1992548173x1980409276_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_list_2emap_24s4199228x1154005405(V);
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_clo;
V g_map_2edelete_24s805420727x38051515(V, V);
V g_map_2edelete_24s805420727x38051515_entry(V self, V *a);
extern Clo g_map_2edelete_24s805420727x38051515_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f738852651x284559611(V, V);
V g_prelude_2e_2b_2b_24f738852651x284559611_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f738852651x284559611_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;

static V g_heff_2elsp_2elsp_2ejfalse_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejfalse_st;
static V g_heff_2elsp_2elsp_2ejfalse_init(void) {
  return heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2elsp_2elsp_2ejfalse_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejfalse_st)) return g_heff_2elsp_2elsp_2ejfalse_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejfalse_val, &g_heff_2elsp_2elsp_2ejfalse_st, g_heff_2elsp_2elsp_2ejfalse_init);
}
Clo g_heff_2elsp_2elsp_2eunits16Go_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eunits16Go_entry, 4, 0};

V g_heff_2elsp_2elsp_2eunits16Go(V v_src_240, V v_i_241, V v_j_242, V v_n_243) {
top: ;
  V v_t_245 = heff_bool((heff_intLe_c(heff_dup(v_j_242), heff_dup(v_i_241)) || heff_intLe_c(heff_strLength(heff_dup(v_src_240)), heff_dup(v_i_241))));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_src_240);
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    heff_drop(v_t_245);
    return v_n_243;
  } else {
    heff_drop(v_t_245);
    if (heff_intLt_c(heff_strByteAt(heff_dup(v_src_240), heff_dup(v_i_241)), MK_INT(128LL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_j_242;
      V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_n_243 = t_3;
      goto top;
    } else {
      V v_r_247 = heff_rec_n(2, shape_rune__width, (V[]){heff_strRuneAt(heff_dup(v_src_240), heff_dup(v_i_241)), heff_strRuneWidth(heff_dup(v_src_240), heff_dup(v_i_241))});
      V v_t_248 = heff_intAdd(v_i_241, heff_take_field(v_r_247, 1));
      V v_t_249 = heff_runeToInt(heff_get_n(v_r_247, 0, 2));
      V v_t_2411;
      if (heff_intLe_c(MK_INT(65536LL), v_t_249)) {
        v_t_2411 = MK_INT(2LL);
      } else {
        v_t_2411 = MK_INT(1LL);
      }
      V t_0 = v_src_240;
      V t_1 = v_t_248;
      V t_2 = v_j_242;
      V t_3 = heff_intAdd(v_n_243, v_t_2411);
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eunits16Go(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2eoffsetGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetGo_entry, 5, 0};

V g_heff_2elsp_2elsp_2eoffsetGo(V v_src_240, V v_line_241, V v_ch_242, V v_i_243, V v_l_244) {
top: ;
  if (heff_intLe_c(heff_dup(v_line_241), heff_dup(v_l_244))) {
    heff_drop(v_line_241);
    heff_drop(v_l_244);
    V v_x2_246 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str0), heff_dup(v_src_240), heff_dup(v_i_243)));
    V v_t_248;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nothing: {
      v_t_248 = heff_strLength(heff_dup(v_src_240));
      break;
    }
    case TAG_Just: {
      V v_x_247 = heff_field(v_x2_246, 0);
      heff_take_n(v_x2_246, 1ULL, 1);
      v_t_248 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return (g_heff_2elsp_2elsp_2eoffset16(v_src_240, v_i_243, v_t_248, v_ch_242));
  } else {
    V v_t_249 = (g_prelude_2eindexFrom(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str1), heff_dup(v_src_240), v_i_243));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop(v_line_241);
      heff_drop(v_ch_242);
      heff_drop(v_l_244);
      return heff_strLength(v_src_240);
    }
    case TAG_Just: {
      V v_e_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V t_0 = v_src_240;
      V t_1 = v_line_241;
      V t_2 = v_ch_242;
      V t_3 = heff_intAdd(v_e_2410, MK_INT(1LL));
      V t_4 = heff_intAdd(v_l_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_line_241 = t_1;
      v_ch_242 = t_2;
      v_i_243 = t_3;
      v_l_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
}
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eoffsetGo(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str0, 8, "severity");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str1, 6, "source");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str2, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str3, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str4, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str5, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str6, 1, "E");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str7, 1, "W");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str8, 1, "D");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str9, 1, "0");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str10, 4, "code");
Clo g_heff_2elsp_2elsp_2ediagnostic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagnostic_entry, 2, 0};

V g_heff_2elsp_2elsp_2ediagnostic(V v_src_240, V v_d_241) {
top: ;
  V v_t_242 = (g_heff_2elsp_2elsp_2erange(v_src_240, heff_take_field(v_d_241, 3)));
  V v_t_243 = heff_dup(heff_rfield(v_d_241, 1));
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SError: {
    v_t_244 = MK_INT(1LL);
    break;
  }
  case TAG_SWarning: {
    v_t_244 = MK_INT(2LL);
    break;
  }
  case TAG_SDebug: {
    v_t_244 = MK_INT(4LL);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str0), heff_tag_n(TAG_JInt, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str1), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str2)})});
  V v_t_247 = heff_take_field(v_d_241, 4);
  V v_t_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    v_t_249 = heff_dup(heff_rfield(v_d_241, 2));
    break;
  }
  case TAG_Just: {
    V v_n_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 2)), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ediagnostic_str3), v_n_248));
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str4), heff_tag_n(TAG_JString, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str5), v_t_242}), v_t_2412});
  V v_t_2422;
  if (heff_intEq_c(heff_dup(heff_rfield(v_d_241, 0)), MK_INT(0LL))) {
    heff_drop_rec(v_d_241, 5);
    v_t_2422 = NTAG(TAG_Nil);
  } else {
    V v_t_2415 = heff_take_field(v_d_241, 1);
    V v_t_2416;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_SError: {
      v_t_2416 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str6);
      break;
    }
    case TAG_SWarning: {
      v_t_2416 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str7);
      break;
    }
    case TAG_SDebug: {
      v_t_2416 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str8);
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    V v_t_2417 = (g_heff_2elsp_2erender_2enumDigits(heff_dup(heff_rfield(v_d_241, 0))));
    V v_t_2418 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_2417), ((V)&g_heff_2elsp_2elsp_2ediagnostic_str9)));
    V v_t_2419 = heff_intShow(heff_get_n(v_d_241, 0, 5));
    V v_t_2420 = heff_strAppend(v_t_2416, heff_strAppend(v_t_2418, v_t_2419));
    V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str10), heff_tag_n(TAG_JString, 1, (V[]){v_t_2420})});
    v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  }
  V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2422));
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2423});
}
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ediagnostic(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str1, 1, "s");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str2, 6, " error");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str3, 22, ") does not elaborate: ");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str4, 2, " (");
HEFF_LIT(g_heff_2elsp_2elsp_2ebrokenImport_str5, 7, "module ");
V g_heff_2elsp_2elsp_2ebrokenImport_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ebrokenImport_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ebrokenImport_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ebrokenImport_entry, 2, 0};

V g_heff_2elsp_2elsp_2ebrokenImport(V v_imports_240, V v_c_241) {
top: ;
  V v_x1_242 = (g_list_2efilter_24s1064353769x1815078842(heff_dup(heff_rfield(v_c_241, 6))));
  V v_x1_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    v_x1_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_242, 0ULL, 2);
    v_x1_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  V v_t_247;
  if ((heff_dup(v_x1_245) == NTAG(TAG_True))) {
    heff_drop(v_x1_245);
    v_t_247 = NTAG(TAG_False);
  } else {
    heff_drop(v_x1_245);
    v_t_247 = (g_list_2eany(heff_clo_n(g_heff_2elsp_2elsp_2ebrokenImport_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_imports_240));
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_t_249 = (g_list_2efind(heff_clo_n(g_heff_2elsp_2elsp_2ebrokenImport_lam1, 1, 1, (V[]){heff_dup(v_c_241)}), v_imports_240));
    V v_sp_2411;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      v_sp_2411 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
      break;
    }
    case TAG_Just: {
      V v_i_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      v_sp_2411 = heff_get_n(v_i_2410, 2, 3);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_t_2412 = (g_list_2efoldl_24f1385598430x897993480(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 6)));
    V v_t_2413 = (g_list_2efoldl_24f1385598430x897993480(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 6)));
    V v_t_2415;
    if (heff_intEq_c(v_t_2413, MK_INT(1LL))) {
      v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ebrokenImport_str0);
    } else {
      v_t_2415 = ((V)&g_heff_2elsp_2elsp_2ebrokenImport_str1);
    }
    V v_t_2416 = heff_strAppend(heff_intShow(v_t_2412), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str2), v_t_2415));
    V v_t_2417 = heff_strAppend(heff_take_field(v_c_241, 1), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str3), v_t_2416));
    V v_t_2418 = heff_strAppend(heff_get_n(v_c_241, 0, 13), heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str4), v_t_2417));
    V v_msg_2419 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ebrokenImport_str5), v_t_2418);
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SWarning), v_msg_2419, v_sp_2411, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
  } else {
    heff_drop_rec(v_c_241, 13);
    heff_drop(v_t_247);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2elsp_2elsp_2ebrokenImport_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ebrokenImport(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2ebrokenImport_lam0(V self, V *args) {
  V v_i_246 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_i_246, 0, 3), heff_get_n(v_c_241, 0, 13));
}
V g_heff_2elsp_2elsp_2ebrokenImport_lam1(V self, V *args) {
  V v_i_248 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_i_248, 0, 3), heff_get_n(v_c_241, 0, 13));
}
Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecatMaybesL_entry, 1, 0};

V g_heff_2elsp_2elsp_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2elsp_2elsp_2ecatMaybesL_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecatMaybesL(a[0]);
}
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ediagsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagsOf_entry, 3, 0};

V g_heff_2elsp_2elsp_2ediagsOf(V v_src_240, V v_program_241, V v_errors_242) {
top: ;
  V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_241)));
  V v_t_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    v_t_246 = heff_get_n(v_x_244, 6, 13);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_249 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam0, 1, 1, (V[]){heff_dup(v_src_240)}), v_errors_242));
  V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_241));
  V v_xs_2411 = (g_list_2edrop(MK_INT(1LL), v_t_2410));
  V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2411));
  V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam1, 1, 1, (V[]){v_src_240}), v_t_2412));
  V v_t_2416 = (g_heff_2elsp_2elsp_2ecatMaybesL(v_t_2415));
  V v_t_2417 = (g_prelude_2e_2b_2b(v_t_249, v_t_2416));
  return (g_prelude_2e_2b_2b(v_t_246, v_t_2417));
}
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ediagsOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
  return ({ V b_0 = heff_get_n(v_t_248, 0, 3); V a_1 = v_e_247; V r_ = (g_heff_2elsp_2elsp_2eloadError(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args) {
  V v_c_2413 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = (g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
  return ({ V b_0 = heff_get_n(v_t_2414, 0, 3); V a_1 = v_c_2413; V r_ = (g_heff_2elsp_2elsp_2ebrokenImport(b_0, a_1)); heff_drop(b_0); r_; });
}
Clo g_heff_2elsp_2elsp_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeptOf_entry, 1, 0};

V g_heff_2elsp_2elsp_2ekeptOf(V v_program_240) {
top: ;
  V v_x1_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_240)));
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_program_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2edriver_2etraceless(v_x_242));
    V v_t_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
    V v_xs_247 = (g_list_2edrop(MK_INT(1LL), v_t_246));
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_247));
    return (g_prelude_2e_2b_2b_24f738852651x284559611(v_t_245, v_t_248));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ekeptOf(a[0]);
}
V g_heff_2elsp_2elsp_2enubSources_24dps_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubSources_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_ss_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_s_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_248 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2enubSources_24dps_lam0, 1, 1, (V[]){v_s_242}), v_ss_243));
    V t_0 = v_t_248;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubSources_24dps(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2enubSources_24dps_lam0(V self, V *args) {
  V v_t_246 = args[0];
  V v_s_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ret_24bool = heff_bool(!heff_strEq_c(heff_dup(heff_rfield(v_t_246, 1)), heff_dup(heff_rfield(v_s_242, 1))));
  heff_drop_rec(v_t_246, 7);
  heff_drop_rec(v_s_242, 7);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str0, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str1, 8, "markdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str2, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str3, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str4, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str5, 4, "\012```");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str6, 11, "\012```\012\012---\012\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str7, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str8, 5, "value");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str9, 8, "contents");
Clo g_heff_2elsp_2elsp_2ehoverOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehoverOf_entry, 2, 0};

V g_heff_2elsp_2elsp_2ehoverOf(V v_a_240, V v_p_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_a_240, 2))));
  V v_t_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){v_x_243});
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop_rec(v_a_240, 3);
    heff_drop(v_p_241);
    return NTAG(TAG_JNull);
  }
  case TAG_Just: {
    V v_c_246 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    V v_t_247 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_dup(heff_rfield(v_a_240, 1)), heff_dup(v_p_241)));
    V v_t_248 = (g_heff_2ebuild_2equery_2etypeAt(v_c_246, v_t_247));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop_rec(v_a_240, 3);
      heff_drop(v_p_241);
      heff_drop_cell(v_ru_24t_245_24Just, 1);
      return NTAG(TAG_JNull);
    }
    case TAG_Just: {
      V v_t_249 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str0), heff_tag_at_n(v_ru_24t_245_24Just, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str1)})});
      V v_off_2411 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_take_field(v_a_240, 1), v_p_241));
      V v_t_2412 = (g_heff_2ebuild_2equery_2edefinitionAt(heff_get_n(v_a_240, 2, 3), v_off_2411));
      V v_doc_2419;
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nothing: {
        v_doc_2419 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str2);
        break;
      }
      case TAG_Just: {
        V v_d_2413 = heff_field(v_t_2412, 0);
        heff_take_n(v_t_2412, 1ULL, 1);
        V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_d_2413, 2)), 0, 2);
        V v_start_2415 = (g_heff_2ebuild_2equery_2elineStartOf(heff_dup(heff_rfield(v_d_2413, 1)), v_t_2414));
        V v_t_2416 = (g_heff_2ebuild_2equery_2ecommentAbove(heff_get_n(v_d_2413, 1, 3), v_start_2415, NTAG(TAG_Nil)));
        V v_t_2417 = (g_list_2emap_24s1819241345x1511673126(v_t_2416));
        V v_t_2418 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2417));
        v_doc_2419 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2ebuild_2equery_2edocMarkdown(a_0)); heff_drop(v_t_2418); r_; });
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      V v_t_2422;
      if (heff_strEq_c(heff_dup(v_doc_2419), ((V)&g_heff_2elsp_2elsp_2ehoverOf_str3))) {
        heff_drop(v_doc_2419);
        v_t_2422 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str4), heff_strAppend(v_t_249, ((V)&g_heff_2elsp_2elsp_2ehoverOf_str5)));
      } else {
        V v_t_2421 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str6), v_doc_2419));
        v_t_2422 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str7), v_t_2421);
      }
      V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str8), heff_tag_at_n(v_ru_24t_248_24Just, TAG_JString, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
      V v_t_2425 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str9), v_t_2425}), NTAG(TAG_Nil)});
      return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2426});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehoverOf(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_cs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_241), heff_hole()});
    V v_t_246 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2enubCheckedPaths_lam0, 1, 1, (V[]){v_c_241}), v_cs_242));
    V v_u_247 = (g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(v_t_246, heff_dup(v_cell_243)));
    heff_drop(v_u_247);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubCheckedPaths(a[0]);
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_lam0(V self, V *args) {
  V v_d_244 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ret_24bool = heff_bool(!heff_strEq_c(heff_dup(heff_rfield(v_d_244, 1)), heff_dup(heff_rfield(v_c_241, 1))));
  heff_drop_rec(v_d_244, 13);
  heff_drop_rec(v_c_241, 13);
  return v_ret_24bool;
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_248 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_lam0, 1, 1, (V[]){v_c_242}), v_cs_243));
    V t_0 = v_t_248;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_lam0(V self, V *args) {
  V v_d_246 = args[0];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ret_24bool = heff_bool(!heff_strEq_c(heff_dup(heff_rfield(v_d_246, 1)), heff_dup(heff_rfield(v_c_242, 1))));
  heff_drop_rec(v_d_246, 13);
  heff_drop_rec(v_c_242, 13);
  return v_ret_24bool;
}
V g_heff_2elsp_2elsp_2eshiftOf_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eshiftOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eshiftOf_entry, 3, 0};

V g_heff_2elsp_2elsp_2eshiftOf(V v_t_240, V v_new_241, V v_b_242) {
top: ;
  V v_t_243 = heff_strLength(heff_dup(heff_rfield(v_t_240, 2)));
  V v_t_244 = heff_intSub(heff_strLength(v_new_241), v_t_243);
  V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_clo_n(g_heff_2elsp_2elsp_2eshiftOf_lam0, 1, 2, (V[]){heff_dup(v_t_240), v_b_242}); V b_3 = heff_get_n(v_t_240, 3, 4); V r_ = (g_list_2efoldl_24f1992548173x1980409276(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  return heff_intMul(v_t_244, v_t_248);
}
V g_heff_2elsp_2elsp_2eshiftOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eshiftOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eshiftOf_lam0(V self, V *args) {
  V v_o_245 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_b_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_ret_24bool = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_o_245, 0)), heff_dup(heff_rfield(v_t_240, 0))) && ({ V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_o_245, 2)), 0, 2); int c_ = heff_intLt_c(heff_dup(v_t_247), heff_dup(heff_rfield(v_b_242, 0))); heff_drop(v_t_247); c_; })));
  heff_drop_rec(v_o_245, 4);
  heff_drop_rec(v_t_240, 4);
  heff_drop_rec(v_b_242, 2);
  return v_ret_24bool;
}
V g_heff_2elsp_2elsp_2enubRoots_24dps_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubRoots_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_2414 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2enubRoots_24dps_lam0, 1, 1, (V[]){v_r_242}), v_rs_243));
    V t_0 = v_t_2414;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubRoots_24dps(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2enubRoots_24dps_lam0(V self, V *args) {
  V v_q_246 = args[0];
  V v_r_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249;
  switch (heff_tag_of(v_q_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_q_246, 0);
    heff_take_n(v_q_246, 1ULL, 2);
    v_t_249 = v_x_247;
    break;
  }
  default: heff_nomatch(v_q_246);
  }
  V v_t_2412;
  switch (heff_tag_of(v_r_242)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_r_242, 0);
    heff_take_n(v_r_242, 1ULL, 2);
    v_t_2412 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_r_242);
  }
  V v_ret_24bool = heff_bool(!heff_strEq_c(heff_dup(v_t_249), heff_dup(v_t_2412)));
  heff_drop(v_t_249);
  heff_drop(v_t_2412);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str2, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str3, 10, "heff-watch");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str4, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str5, 25, "client/registerCapability");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str6, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str7, 10, "heff-watch");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str8, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str9, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str10, 11, "globPattern");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str11, 7, "**/*.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str12, 8, "watchers");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str13, 15, "registerOptions");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str14, 13, "registrations");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str15, 6, "params");

static V g_heff_2elsp_2elsp_2eregistration_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2eregistration_st;
static V g_heff_2elsp_2elsp_2eregistration_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str1)})});
  V v_t_241 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str2), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str3)})});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str4), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str5)})});
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str6), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str7)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str8), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str9)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str10), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str11)})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_246}), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str12), heff_tag_n(TAG_JArray, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str13), heff_tag_n(TAG_JObject, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str14), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str15), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_2417})});
  return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_2418})});
}
V g_heff_2elsp_2elsp_2eregistration_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2eregistration_st)) return g_heff_2elsp_2elsp_2eregistration_val;
  return heff_global(&g_heff_2elsp_2elsp_2eregistration_val, &g_heff_2elsp_2elsp_2eregistration_st, g_heff_2elsp_2elsp_2eregistration_init);
}
Clo g_heff_2elsp_2elsp_2echanged_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echanged_entry, 3, 0};

V g_heff_2elsp_2elsp_2echanged(V v_st_240, V v_f_241, V v_text_242) {
top: ;
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_f_241), heff_rfield(v_st_240, 0)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_f_241);
    heff_drop(v_text_242);
    return v_st_240;
  }
  case TAG_Just: {
    V v_d_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = ({ V rv_1 = v_text_242; V rr_ = heff_rec_reuse_nf(v_d_244, 1ULL, 2, shape_uri__text, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_d_246 = (g_map_2einsert_24s1341440536x470972936(v_f_241, v_t_245, heff_take_field(v_st_240, 0)));
    return ({ V rv_0 = v_d_246; V rr_ = heff_rec_reuse_nf(v_st_240, 126ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16380u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elsp_2elsp_2echanged_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echanged(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_str1, 12, "textDocument");
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam0, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam1, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam2, 1, 0};
Clo g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_entry, 1, 0};

V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(V v_p_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_str0), NTAG(TAG_Nil)});
  V v_it_242 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_str1), v_t_241}); V a_1 = v_p_240; V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam0_clo);
  }
  case TAG_Just: {
    V v_it1_245 = heff_field(v_it_242, 0);
    V v_ru_24it_242_24Just = heff_take_reuse_n(v_it_242, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_it1_245)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_249 = heff_field(v_it1_245, 0);
      heff_take_n(v_it1_245, 1ULL, 1);
      v_t_2412 = heff_tag_at_n(v_ru_24it_242_24Just, TAG_Just, 1, (V[]){v_s_249});
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_245);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      return ((V)&g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam1_clo);
    }
    case TAG_Just: {
      V v_u_2415 = heff_field(v_t_2412, 0);
      V v_ru_24t_2412_24Just = heff_take_reuse_n(v_t_2412, 1ULL, 1);
      V v_t_2417 = heff_tag_at_n(v_ru_24t_2412_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_UriPath, 2, (V[]){v_u_2415, ((V)&g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam2_clo)})});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      return heff_tail(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2418});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(a[0]);
}
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390_lam2(V self, V *args) {
  V v_p_2416 = args[0];
  return v_p_2416;
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_entry, 3, 0};

V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028(V v_st_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_c_241);
    return ((V)&g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam0_clo);
  }
  case TAG_Cons: {
    V v_y_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = (g_heff_2elsp_2elsp_2esymbolJson_24s685145883x1656190041(heff_dup(v_st_240), heff_dup(v_c_241), v_y_245));
    return heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam1, 2, 4, (V[]){v_c_247, v_st_240, v_c_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = (g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028(v_st_240, v_c_241, v_rest_246));
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam3, 1, 2, (V[]){v_k_249, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s1066026354x209923028_lam2, 1, 5, (V[]){v_st_240, v_c_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s328461436x637708390(heff_dup(v_p_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam0, 2, 3, (V[]){v_c_242, v_st_240, v_p_241});
}
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_f_247 = heff_env(self)[0];
  V v_d_2410 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2413 = (g_heff_2elsp_2elsp_2etargetIn(heff_take_field(v_x_2412, 0), v_f_247, v_d_2410, v_p_241, heff_get_n(v_x_2412, 1, 2)));
  V f_ = v_k_244;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_p_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    heff_drop(v_p_241);
    V v_t_246 = heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
    V f_ = v_k_244;
    args[0] = v_t_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    V v_t_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_f_247), heff_rfield(v_st_240, 0)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_hd_243);
      heff_drop(v_p_241);
      heff_drop(v_f_247);
      V v_t_249 = heff_rec_n(3, shape_st__off__target, (V[]){v_st_240, MK_INT(0LL), NTAG(TAG_Nothing)});
      V f_ = v_k_244;
      args[0] = v_t_249;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_d_2410 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      V v_c_2411 = (g_heff_2elsp_2elsp_2eproject_24s984786303x1390938215(v_st_240, heff_dup(v_f_247)));
      V f_ = v_c_2411;
      heff_room[0] = v_hd_243;
      heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam2, 1, 4, (V[]){v_f_247, v_d_2410, v_p_241, v_k_244});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799_lam1, 1, 4, (V[]){v_st_240, v_k_244, v_hd_243, v_p_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_str1, 5, "range");
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam0, 1, 0};
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_entry, 2, 0};

V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873(V v_st_240, V v_o_241) {
top: ;
  V v_p_242 = heff_dup(heff_rfield(v_o_241, 0));
  V v_t_243 = ({ V a_0 = heff_dup(v_p_242); V b_1 = heff_get_n(v_st_240, 0, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_c_2410;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_242, ((V)&g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam0_clo)})});
    V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    v_c_2410 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_246}));
    break;
  }
  case TAG_Just: {
    V v_d_247 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_p_242);
    v_c_2410 = heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam1, 2, 1, (V[]){v_d_247});
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam2, 2, 2, (V[]){v_c_2410, v_o_241});
}
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam0(V self, V *args) {
  V v_u_244 = args[0];
  return v_u_244;
}
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_get_n(v_d_247, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_o_241 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_str0), heff_tag_n(TAG_JString, 1, (V[]){v_x_2413})});
  V v_t_2415 = (g_heff_2elsp_2elsp_2erange(heff_take_field(v_o_241, 1), heff_get_n(v_o_241, 2, 4)));
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_str1), v_t_2415}), NTAG(TAG_Nil)});
  V v_x_2417 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2416})});
  V f_ = v_k_2412;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_o_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2410;
  args[0] = v_hd_2411;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s1245496834x263635873_lam3, 1, 2, (V[]){v_o_241, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str0, 10, "initialize");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str1, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str2, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str3, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str4, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str5, 19, "dynamicRegistration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str6, 9, "workspace");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str7, 21, "didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str8, 12, "capabilities");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str9, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str10, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str11, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str12, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str13, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str14, 18, "textDocument/hover");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str15, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str16, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str17, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str18, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str19, 23, "textDocument/definition");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str20, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str21, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str22, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str23, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str24, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str25, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str26, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str27, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str28, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str29, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str30, 23, "textDocument/completion");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str31, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str32, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str33, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str34, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str35, 27, "textDocument/documentSymbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str36, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str37, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str38, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str39, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str40, 16, "workspace/symbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str41, 5, "query");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str42, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str43, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str44, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str45, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str46, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str47, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str48, 23, "textDocument/references");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str49, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str50, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str51, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str52, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str53, 18, "includeDeclaration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str54, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str55, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str56, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str57, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str58, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str59, 26, "textDocument/prepareRename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str60, 19, "textDocument/rename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str61, 7, "newName");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str62, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str63, 23, "textDocument/formatting");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str64, 10, "no method ");
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam9(V self, V *args); static Clo g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam9, 1, 0};
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam16(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam15(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam14(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam19(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam20(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam18(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam17(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam25(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam24(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam23(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam22(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam21(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam28(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam30(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam29(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam31(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam27(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam26(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam33(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam32(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam35(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam34(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam37(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam36(V self, V *args);
Clo g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_entry, 4, 0};

V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277(V v_st_240, V v_m_241, V v_id_242, V v_p_243) {
top: ;
  if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str0))) {
    heff_drop(v_m_241);
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str1), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str2)})});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str3), heff_dup(g_heff_2elsp_2elsp_2ecapabilities_get())}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str4), v_id_242}), v_t_246});
    V v_t_248 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
    V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_248, 1); r_; });
    V v_a_2410 = heff_tag_n(TAG_Send, 2, (V[]){v_t_249, NTAG(TAG_MkUnit)});
    return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam0, 2, 3, (V[]){v_a_2410, v_p_243, v_st_240});
  } else {
    if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str9))) {
      heff_drop(v_m_241);
      heff_drop(v_p_243);
      V v_t_2430 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str10), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str11)})});
      V v_t_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str12), NTAG(TAG_JNull)});
      V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
      V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str13), v_id_242}), v_t_2432});
      V v_t_2434 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, v_t_2433})});
      V v_t_2435 = ({ V a_0 = v_t_2434; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2434, 1); r_; });
      V v_a_2436 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2435, NTAG(TAG_MkUnit)});
      return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam2, 2, 2, (V[]){v_a_2436, v_st_240});
    } else {
      if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str14))) {
        heff_drop(v_m_241);
        V v_c_2443 = (g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(v_st_240, heff_dup(v_p_243)));
        return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam4, 2, 3, (V[]){v_c_2443, v_p_243, v_id_242});
      } else {
        if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str19))) {
          heff_drop(v_m_241);
          V v_c_2457 = (g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(v_st_240, heff_dup(v_p_243)));
          return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam7, 2, 3, (V[]){v_c_2457, v_p_243, v_id_242});
        } else {
          if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str30))) {
            heff_drop(v_m_241);
            V v_c_2499 = (g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(v_st_240, heff_dup(v_p_243)));
            return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam14, 2, 3, (V[]){v_c_2499, v_p_243, v_id_242});
          } else {
            if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str35))) {
              heff_drop(v_m_241);
              V v_c_24119 = (g_heff_2elsp_2elsp_2ewithProgram_24s975201515x315883544(v_st_240, v_p_243));
              return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam17, 2, 2, (V[]){v_c_24119, v_id_242});
            } else {
              if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str40))) {
                heff_drop(v_m_241);
                V v_t_24139 = (g_map_2etoListOnto(heff_rfield(v_st_240, 0), NTAG(TAG_Nil)));
                V v_t_24140 = (g_list_2emap_24s1415906091x1371825187(v_t_24139));
                V v_c_24141 = (g_heff_2elsp_2elsp_2erootsOf_24s237736965x1211319005(heff_dup(v_st_240), v_t_24140));
                return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam21, 2, 4, (V[]){v_c_24141, v_st_240, v_p_243, v_id_242});
              } else {
                if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str48))) {
                  heff_drop(v_m_241);
                  V v_c_24174 = (g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799(v_st_240, heff_dup(v_p_243)));
                  return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam26, 2, 3, (V[]){v_c_24174, v_id_242, v_p_243});
                } else {
                  if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str59))) {
                    heff_drop(v_m_241);
                    V v_c_24217 = (g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799(v_st_240, v_p_243));
                    return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam32, 2, 2, (V[]){v_c_24217, v_id_242});
                  } else {
                    if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str60))) {
                      heff_drop(v_m_241);
                      V v_c_24222 = (g_heff_2elsp_2elsp_2ewithTarget_24s980354002x865167799(v_st_240, heff_dup(v_p_243)));
                      return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam34, 2, 3, (V[]){v_c_24222, v_p_243, v_id_242});
                    } else {
                      if (heff_strEq_c(heff_dup(v_m_241), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str63))) {
                        heff_drop(v_m_241);
                        return (g_heff_2elsp_2elsp_2eformatted_24s1878468145x184487493(v_st_240, v_id_242, v_p_243));
                      } else {
                        heff_drop(v_p_243);
                        V v_c_24239 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(v_id_242, MK_INT(-32601LL), heff_strAppend(((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str64), v_m_241)));
                        return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam36, 2, 2, (V[]){v_c_24239, v_st_240});
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str5), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str7), v_t_2415})});
  V v_it_2417 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str8), v_t_2416}); V a_1 = v_p_243; V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_2425;
  switch (heff_tag_of(v_it_2417)) {
  case TAG_Nothing: {
    v_x2_2425 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_2418 = heff_field(v_it_2417, 0);
    V v_ru_24it_2417_24Just = heff_take_reuse_n(v_it_2417, 1ULL, 1);
    switch (heff_tag_of(v_it1_2418)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_2417_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      V v_b_2419 = heff_field(v_it1_2418, 0);
      heff_take_n(v_it1_2418, 1ULL, 1);
      v_x2_2425 = heff_tag_at_n(v_ru_24it_2417_24Just, TAG_Just, 1, (V[]){v_b_2419});
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_2418, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2417_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_2418, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2417_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_it1_2418, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2417_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_2418, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2417_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_2418, 0ULL, 1);
      heff_drop_cell(v_ru_24it_2417_24Just, 1);
      v_x2_2425 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_2418);
    }
    break;
  }
  default: heff_nomatch(v_it_2417);
  }
  V v_w_2427;
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_Nothing: {
    v_w_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    heff_take_n(v_x2_2425, 1ULL, 1);
    v_w_2427 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_x2_2425);
  }
  V v_t_2428 = ({ V rv_4 = v_w_2427; V rr_ = heff_rec_reuse_nf(v_st_240, 111ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15615u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V f_ = v_k_2412;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_a_2410 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), v_hd_2411, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam1, 1, 3, (V[]){v_p_243, v_st_240, v_k_2412})));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam3(V self, V *args) {
  V v_x_2440 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2440);
  V v_t_2441 = ({ V rv_5 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_st_240, 95ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 13311u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
  V f_ = v_k_2438;
  args[0] = v_t_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam2(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_a_2436 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2436})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_hd_2437, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam3, 1, 2, (V[]){v_st_240, v_k_2438})));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam6(V self, V *args) {
  V v_x_2455 = args[0];
  V v_k_2445 = heff_env(self)[0];
  V v_x_2446 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2455);
  V f_ = v_k_2445;
  args[0] = heff_get_n(v_x_2446, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam5(V self, V *args) {
  V v_x_2446 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_2444 = heff_env(self)[2];
  V v_k_2445 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_result_2447 = (g_heff_2elsp_2elsp_2ehoverOf(heff_dup(v_x_2446), v_p_243));
  V v_t_2448 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str15), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str16)})});
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str17), v_result_2447}), NTAG(TAG_Nil)});
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str18), v_id_242}), v_t_2449});
  V v_t_2451 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, v_t_2450})});
  V v_t_2452 = ({ V a_0 = v_t_2451; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2451, 1); r_; });
  V v_a_2453 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2452, NTAG(TAG_MkUnit)});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2453})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), v_hd_2444, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam6, 1, 2, (V[]){v_k_2445, v_x_2446})));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam4(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_c_2443 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2443;
  args[0] = heff_dup(v_hd_2444);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam5, 1, 4, (V[]){v_p_243, v_id_242, v_hd_2444, v_k_2445});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam9(V self, V *args) {
  V v_u_2475 = args[0];
  return v_u_2475;
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam10(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  V v_d_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2479);
  V f_ = v_k_2480;
  args[0] = heff_get_n(v_d_2478, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam12(V self, V *args) {
  V v_x_2484 = args[0];
  V v_d_2471 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_2482 = heff_env(self)[2];
  V v_k_2483 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2485 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str24), heff_tag_n(TAG_JString, 1, (V[]){v_x_2484})});
  V v_t_2486 = (g_heff_2elsp_2elsp_2erange(heff_take_field(v_d_2471, 1), heff_get_n(v_d_2471, 2, 3)));
  V v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str25), v_t_2486}), NTAG(TAG_Nil)});
  V v_result_2488 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2485, v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str26), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str27)})});
  V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str28), v_result_2488}), NTAG(TAG_Nil)});
  V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str29), v_id_242}), v_t_2490});
  V v_t_2492 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, v_t_2491})});
  V v_t_2493 = ({ V a_0 = v_t_2492; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2492, 1); r_; });
  V v_a_2494 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2493, NTAG(TAG_MkUnit)});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2494})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2495}), v_hd_2482, v_k_2483));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam11(V self, V *args) {
  V v_hd_2482 = args[0];
  V v_k_2483 = args[1];
  V v_c_2481 = heff_env(self)[0];
  V v_d_2471 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2481;
  args[0] = heff_dup(v_hd_2482);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam12, 1, 4, (V[]){v_d_2471, v_id_242, v_hd_2482, v_k_2483});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam13(V self, V *args) {
  V v_x_2497 = args[0];
  V v_k_2459 = heff_env(self)[0];
  V v_x_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2497);
  V f_ = v_k_2459;
  args[0] = heff_get_n(v_x_2460, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam8(V self, V *args) {
  V v_x_2460 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_2458 = heff_env(self)[2];
  V v_k_2459 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2461 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_dup(heff_rfield(v_x_2460, 1)), v_p_243));
  V v_t_2462 = (g_heff_2ebuild_2equery_2edefinitionAt(heff_dup(heff_rfield(v_x_2460, 2)), v_t_2461));
  V v_c_2496;
  switch (heff_tag_of(v_t_2462)) {
  case TAG_Nothing: {
    V v_t_2463 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str20), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str21)})});
    V v_t_2464 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str22), NTAG(TAG_JNull)});
    V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
    V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str23), v_id_242}), v_t_2465});
    V v_t_2467 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, v_t_2466})});
    V v_t_2468 = ({ V a_0 = v_t_2467; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_2467, 1); r_; });
    V v_a_2469 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2468, NTAG(TAG_MkUnit)});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2469})});
    v_c_2496 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})}));
    break;
  }
  case TAG_Just: {
    V v_d_2471 = heff_field(v_t_2462, 0);
    V v_ru_24t_2462_24Just = heff_take_reuse_n(v_t_2462, 1ULL, 1);
    V v_p_2472 = heff_dup(heff_rfield(v_d_2471, 0));
    V v_t_2473 = heff_get_n(heff_dup(heff_rfield(v_x_2460, 0)), 0, 7);
    V v_t_2474 = ({ V a_0 = heff_dup(v_p_2472); V a_1 = v_t_2473; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2473); r_; });
    V v_c_2481;
    switch (heff_tag_of(v_t_2474)) {
    case TAG_Nothing: {
      V v_t_2476 = heff_tag_at_n(v_ru_24t_2462_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_2472, ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam9_clo)})});
      V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
      v_c_2481 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2477}));
      break;
    }
    case TAG_Just: {
      V v_d_2478 = heff_field(v_t_2474, 0);
      heff_take_n(v_t_2474, 1ULL, 1);
      heff_drop_cell(v_ru_24t_2462_24Just, 1);
      heff_drop(v_p_2472);
      v_c_2481 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam10, 2, 1, (V[]){v_d_2478});
      break;
    }
    default: heff_nomatch(v_t_2474);
    }
    v_c_2496 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam11, 2, 3, (V[]){v_c_2481, v_d_2471, v_id_242});
    break;
  }
  default: heff_nomatch(v_t_2462);
  }
  V f_ = v_c_2496;
  heff_room[0] = v_hd_2458;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam13, 1, 2, (V[]){v_k_2459, v_x_2460});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam7(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_c_2457 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2457;
  args[0] = heff_dup(v_hd_2458);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam8, 1, 4, (V[]){v_p_243, v_id_242, v_hd_2458, v_k_2459});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam16(V self, V *args) {
  V v_x_24117 = args[0];
  V v_k_24101 = heff_env(self)[0];
  V v_x_24102 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24117);
  V f_ = v_k_24101;
  args[0] = heff_get_n(v_x_24102, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam15(V self, V *args) {
  V v_x_24102 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_24100 = heff_env(self)[2];
  V v_k_24101 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24103 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_x_24102, 2))));
  V v_t_24108;
  switch (heff_tag_of(v_x1_24103)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    v_t_24108 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24104 = heff_field(v_x1_24103, 0);
    heff_take_n(v_x1_24103, 1ULL, 2);
    V v_t_24106 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_dup(heff_rfield(v_x_24102, 1)), v_p_243));
    V v_t_24107 = (g_heff_2ebuild_2equery_2ecompletionsAt(v_x_24104, v_t_24106));
    v_t_24108 = (g_list_2emap_24s4199228x1154005405(v_t_24107));
    break;
  }
  default: heff_nomatch(v_x1_24103);
  }
  V v_result_24109 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24108});
  V v_t_24110 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str31), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str32)})});
  V v_t_24111 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str33), v_result_24109}), NTAG(TAG_Nil)});
  V v_t_24112 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str34), v_id_242}), v_t_24111});
  V v_t_24113 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24110, v_t_24112})});
  V v_t_24114 = ({ V a_0 = v_t_24113; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_24113, 1); r_; });
  V v_a_24115 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24114, NTAG(TAG_MkUnit)});
  V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24115})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_24116}), v_hd_24100, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam16, 1, 2, (V[]){v_k_24101, v_x_24102})));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam14(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k_24101 = args[1];
  V v_c_2499 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2499;
  args[0] = heff_dup(v_hd_24100);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam15, 1, 4, (V[]){v_p_243, v_id_242, v_hd_24100, v_k_24101});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam19(V self, V *args) {
  V v_y_24127 = args[0];
  V v_x_24122 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2elsp_2elsp_2edocSymbol(heff_get_n(v_x_24122, 1, 3), v_y_24127));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam20(V self, V *args) {
  V v_x_24137 = args[0];
  V v_k_24121 = heff_env(self)[0];
  V v_x_24122 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24137);
  V f_ = v_k_24121;
  args[0] = heff_get_n(v_x_24122, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam18(V self, V *args) {
  V v_x_24122 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24120 = heff_env(self)[1];
  V v_k_24121 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24123 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_x_24122, 2))));
  V v_t_24128;
  switch (heff_tag_of(v_x1_24123)) {
  case TAG_Nil: {
    v_t_24128 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24124 = heff_field(v_x1_24123, 0);
    heff_take_n(v_x1_24123, 1ULL, 2);
    V v_t_24126 = (g_heff_2ebuild_2equery_2esymbols(v_x_24124));
    v_t_24128 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam19, 1, 1, (V[]){heff_dup(v_x_24122)}), v_t_24126));
    break;
  }
  default: heff_nomatch(v_x1_24123);
  }
  V v_result_24129 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24128});
  V v_t_24130 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str36), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str37)})});
  V v_t_24131 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str38), v_result_24129}), NTAG(TAG_Nil)});
  V v_t_24132 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str39), v_id_242}), v_t_24131});
  V v_t_24133 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24130, v_t_24132})});
  V v_t_24134 = ({ V a_0 = v_t_24133; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_24133, 1); r_; });
  V v_a_24135 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24134, NTAG(TAG_MkUnit)});
  V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24135})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_24136}), v_hd_24120, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam20, 1, 2, (V[]){v_k_24121, v_x_24122})));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam17(V self, V *args) {
  V v_hd_24120 = args[0];
  V v_k_24121 = args[1];
  V v_c_24119 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24119;
  args[0] = heff_dup(v_hd_24120);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam18, 1, 3, (V[]){v_id_242, v_hd_24120, v_k_24121});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam25(V self, V *args) {
  V v_x_24172 = args[0];
  V v_k_24143 = heff_env(self)[0];
  V v_x_24147 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24172);
  V f_ = v_k_24143;
  args[0] = heff_get_n(v_x_24147, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam24(V self, V *args) {
  V v_x_24163 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24142 = heff_env(self)[1];
  V v_k_24143 = heff_env(self)[2];
  V v_x_24147 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24164 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str44), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str45)})});
  V v_t_24165 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str46), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24163})});
  V v_t_24166 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24165, NTAG(TAG_Nil)});
  V v_t_24167 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str47), v_id_242}), v_t_24166});
  V v_t_24168 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24164, v_t_24167})});
  V v_t_24169 = ({ V a_0 = v_t_24168; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_24168, 1); r_; });
  V v_a_24170 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24169, NTAG(TAG_MkUnit)});
  V v_t_24171 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24170})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_24171}), v_hd_24142, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam25, 1, 2, (V[]){v_k_24143, v_x_24147})));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam23(V self, V *args) {
  V v_x_24147 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_hd_24142 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_k_24143 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24148 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str41), NTAG(TAG_Nil)});
  V v_it_24149 = ({ V a_0 = v_t_24148; V a_1 = v_p_243; V r_ = (g_heff_2eutil_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_24148, 2); r_; });
  V v_x2_24157;
  switch (heff_tag_of(v_it_24149)) {
  case TAG_Nothing: {
    v_x2_24157 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_24150 = heff_field(v_it_24149, 0);
    V v_ru_24it_24149_24Just = heff_take_reuse_n(v_it_24149, 1ULL, 1);
    switch (heff_tag_of(v_it1_24150)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_24149_24Just, 1);
      v_x2_24157 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_24150, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24149_24Just, 1);
      v_x2_24157 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_24150, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24149_24Just, 1);
      v_x2_24157 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_24150, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24149_24Just, 1);
      v_x2_24157 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_24154 = heff_field(v_it1_24150, 0);
      heff_take_n(v_it1_24150, 1ULL, 1);
      v_x2_24157 = heff_tag_at_n(v_ru_24it_24149_24Just, TAG_Just, 1, (V[]){v_s_24154});
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_24150, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24149_24Just, 1);
      v_x2_24157 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_24150, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24149_24Just, 1);
      v_x2_24157 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_24150);
    }
    break;
  }
  default: heff_nomatch(v_it_24149);
  }
  V v_s_24159;
  switch (heff_tag_of(v_x2_24157)) {
  case TAG_Nothing: {
    v_s_24159 = ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str42);
    break;
  }
  case TAG_Just: {
    V v_x_24158 = heff_field(v_x2_24157, 0);
    heff_take_n(v_x2_24157, 1ULL, 1);
    v_s_24159 = v_x_24158;
    break;
  }
  default: heff_nomatch(v_x2_24157);
  }
  V v_t_24160 = (g_heff_2elsp_2elsp_2elowerGo(v_s_24159, MK_INT(0LL), ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str43)));
  V v_t_24161 = (g_heff_2elsp_2elsp_2enubCheckedPaths(heff_dup(heff_rfield(v_x_24147, 1))));
  V v_c_24162 = ({ V a_0 = heff_dup(heff_rfield(v_x_24147, 0)); V a_1 = v_t_24160; V a_2 = v_t_24161; V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s1877205770x1143406573(a_0, a_1, a_2)); heff_drop(v_t_24161); r_; });
  V f_ = v_c_24162;
  heff_room[0] = heff_dup(v_hd_24142);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam24, 1, 4, (V[]){v_id_242, v_hd_24142, v_k_24143, v_x_24147});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam22(V self, V *args) {
  V v_x_24144 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_24142 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  V v_k_24143 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24145 = (g_heff_2elsp_2elsp_2enubRoots(v_x_24144));
  V v_c_24146 = ({ V a_0 = v_st_240; V a_1 = v_t_24145; V r_ = (g_heff_2elsp_2elsp_2eprojects_24s1783001825x240437576(a_0, a_1)); heff_drop(v_t_24145); r_; });
  V f_ = v_c_24146;
  heff_room[0] = heff_dup(v_hd_24142);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam23, 1, 4, (V[]){v_p_243, v_hd_24142, v_id_242, v_k_24143});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam21(V self, V *args) {
  V v_hd_24142 = args[0];
  V v_k_24143 = args[1];
  V v_c_24141 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24141;
  args[0] = heff_dup(v_hd_24142);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam22, 1, 5, (V[]){v_st_240, v_hd_24142, v_p_243, v_id_242, v_k_24143});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam28(V self, V *args) {
  V v_o_24188 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24189 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str53), NTAG(TAG_Nil)});
  V v_it_24190 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str54), v_t_24189}); V a_1 = v_p_243; V r_ = (g_heff_2eutil_2ejson_2eat(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_24198;
  switch (heff_tag_of(v_it_24190)) {
  case TAG_Nothing: {
    v_x2_24198 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_24191 = heff_field(v_it_24190, 0);
    V v_ru_24it_24190_24Just = heff_take_reuse_n(v_it_24190, 1ULL, 1);
    switch (heff_tag_of(v_it1_24191)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_24190_24Just, 1);
      v_x2_24198 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      V v_b_24192 = heff_field(v_it1_24191, 0);
      heff_take_n(v_it1_24191, 1ULL, 1);
      v_x2_24198 = heff_tag_at_n(v_ru_24it_24190_24Just, TAG_Just, 1, (V[]){v_b_24192});
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_24191, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24190_24Just, 1);
      v_x2_24198 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_24191, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24190_24Just, 1);
      v_x2_24198 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_it1_24191, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24190_24Just, 1);
      v_x2_24198 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_24191, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24190_24Just, 1);
      v_x2_24198 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_24191, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24190_24Just, 1);
      v_x2_24198 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_24191);
    }
    break;
  }
  default: heff_nomatch(v_it_24190);
  }
  switch (heff_tag_of(v_x2_24198)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_24188, 4);
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    V v_x_24199 = heff_field(v_x2_24198, 0);
    heff_take_n(v_x2_24198, 1ULL, 1);
    V v_ret_24bool = heff_bool(((heff_dup(v_x_24199) == NTAG(TAG_True)) || ({ V v_t_24200 = heff_dup(heff_rfield(v_o_24188, 3)); int c_ = !(heff_dup(v_t_24200) == NTAG(TAG_True)); heff_drop(v_t_24200); c_; })));
    heff_drop_rec(v_o_24188, 4);
    heff_drop(v_x_24199);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_x2_24198);
  }
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam30(V self, V *args) {
  V v_x_24205 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24203 = heff_env(self)[1];
  V v_k_24204 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24206 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str55), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str56)})});
  V v_t_24207 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str57), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24205})});
  V v_t_24208 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24207, NTAG(TAG_Nil)});
  V v_t_24209 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str58), v_id_242}), v_t_24208});
  V v_t_24210 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24206, v_t_24209})});
  V v_t_24211 = ({ V a_0 = v_t_24210; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_24210, 1); r_; });
  V v_a_24212 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24211, NTAG(TAG_MkUnit)});
  V v_t_24213 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24212})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_24213}), v_hd_24203, v_k_24204));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam29(V self, V *args) {
  V v_hd_24203 = args[0];
  V v_k_24204 = args[1];
  V v_c_24202 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24202;
  args[0] = heff_dup(v_hd_24203);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam30, 1, 3, (V[]){v_id_242, v_hd_24203, v_k_24204});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam31(V self, V *args) {
  V v_x_24215 = args[0];
  V v_k_24176 = heff_env(self)[0];
  V v_x_24177 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24215);
  V f_ = v_k_24176;
  args[0] = heff_get_n(v_x_24177, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam27(V self, V *args) {
  V v_x_24177 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_hd_24175 = heff_env(self)[2];
  V v_k_24176 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24178 = heff_dup(heff_rfield(v_x_24177, 2));
  V v_c_24214;
  switch (heff_tag_of(v_t_24178)) {
  case TAG_Nothing: {
    heff_drop(v_p_243);
    V v_t_24179 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str49), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str50)})});
    V v_t_24180 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str51), NTAG(TAG_JNull)});
    V v_t_24181 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24180, NTAG(TAG_Nil)});
    V v_t_24182 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str52), v_id_242}), v_t_24181});
    V v_t_24183 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24179, v_t_24182})});
    V v_t_24184 = ({ V a_0 = v_t_24183; V r_ = (g_heff_2eutil_2ejson_2estringify(a_0)); heff_drop_tag(v_t_24183, 1); r_; });
    V v_a_24185 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24184, NTAG(TAG_MkUnit)});
    V v_t_24186 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24185})});
    v_c_24214 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24186})}));
    break;
  }
  case TAG_Just: {
    V v_t_24187 = heff_field(v_t_24178, 0);
    heff_take_n(v_t_24178, 1ULL, 1);
    V v_t_24201 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam28, 1, 1, (V[]){v_p_243}), heff_get_n(v_t_24187, 3, 4)));
    V v_c_24202 = (g_heff_2elsp_2elsp_2elocations_24s1821933868x339923104(heff_dup(heff_rfield(v_x_24177, 0)), v_t_24201));
    v_c_24214 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam29, 2, 2, (V[]){v_c_24202, v_id_242});
    break;
  }
  default: heff_nomatch(v_t_24178);
  }
  V f_ = v_c_24214;
  heff_room[0] = v_hd_24175;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam31, 1, 2, (V[]){v_k_24176, v_x_24177});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam26(V self, V *args) {
  V v_hd_24175 = args[0];
  V v_k_24176 = args[1];
  V v_c_24174 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24174;
  args[0] = heff_dup(v_hd_24175);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam27, 1, 4, (V[]){v_id_242, v_p_243, v_hd_24175, v_k_24176});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam33(V self, V *args) {
  V v_x_24220 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24218 = heff_env(self)[1];
  V v_k_24219 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2elsp_2elsp_2eprepared_24s1011347481x332527574(v_id_242, v_x_24220, v_hd_24218, v_k_24219));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam32(V self, V *args) {
  V v_hd_24218 = args[0];
  V v_k_24219 = args[1];
  V v_c_24217 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24217;
  args[0] = heff_dup(v_hd_24218);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam33, 1, 3, (V[]){v_id_242, v_hd_24218, v_k_24219});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam35(V self, V *args) {
  V v_x_24225 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_hd_24223 = heff_env(self)[2];
  V v_k_24224 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24226 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str61), NTAG(TAG_Nil)});
  V v_it_24227 = ({ V a_0 = v_t_24226; V a_1 = v_p_243; V r_ = (g_heff_2eutil_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_24226, 2); r_; });
  V v_x2_24235;
  switch (heff_tag_of(v_it_24227)) {
  case TAG_Nothing: {
    v_x2_24235 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_24228 = heff_field(v_it_24227, 0);
    V v_ru_24it_24227_24Just = heff_take_reuse_n(v_it_24227, 1ULL, 1);
    switch (heff_tag_of(v_it1_24228)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_24227_24Just, 1);
      v_x2_24235 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24227_24Just, 1);
      v_x2_24235 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24227_24Just, 1);
      v_x2_24235 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24227_24Just, 1);
      v_x2_24235 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_24232 = heff_field(v_it1_24228, 0);
      heff_take_n(v_it1_24228, 1ULL, 1);
      v_x2_24235 = heff_tag_at_n(v_ru_24it_24227_24Just, TAG_Just, 1, (V[]){v_s_24232});
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24227_24Just, 1);
      v_x2_24235 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24it_24227_24Just, 1);
      v_x2_24235 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_24228);
    }
    break;
  }
  default: heff_nomatch(v_it_24227);
  }
  V v_t_24237;
  switch (heff_tag_of(v_x2_24235)) {
  case TAG_Nothing: {
    v_t_24237 = ((V)&g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_str62);
    break;
  }
  case TAG_Just: {
    V v_x_24236 = heff_field(v_x2_24235, 0);
    heff_take_n(v_x2_24235, 1ULL, 1);
    v_t_24237 = v_x_24236;
    break;
  }
  default: heff_nomatch(v_x2_24235);
  }
  return (g_heff_2elsp_2elsp_2erenamed_24s614769212x523450918(v_id_242, v_t_24237, v_x_24225, v_hd_24223, v_k_24224));
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam34(V self, V *args) {
  V v_hd_24223 = args[0];
  V v_k_24224 = args[1];
  V v_c_24222 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24222;
  args[0] = heff_dup(v_hd_24223);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam35, 1, 4, (V[]){v_p_243, v_id_242, v_hd_24223, v_k_24224});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam37(V self, V *args) {
  V v_x_24242 = args[0];
  V v_k_24241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24242);
  V f_ = v_k_24241;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam36(V self, V *args) {
  V v_hd_24240 = args[0];
  V v_k_24241 = args[1];
  V v_c_24239 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24239;
  args[0] = v_hd_24240;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277_lam37, 1, 2, (V[]){v_k_24241, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str0, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str1, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str2, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str3, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str4, 9, "shut down");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str5, 6, "params");
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_entry, 2, 0};

V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459(V v_st_240, V v_msg_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str0), NTAG(TAG_Nil)});
  V v_it_243 = ({ V a_0 = v_t_242; V a_1 = heff_dup(v_msg_241); V r_ = (g_heff_2eutil_2ejson_2eat(a_0, a_1)); heff_drop_tag(v_t_242, 2); r_; });
  V v_t_2411;
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Just = heff_take_reuse_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      V v_s_248 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 1);
      v_t_2411 = heff_tag_at_n(v_ru_24it_243_24Just, TAG_Just, 1, (V[]){v_s_248});
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop_cell(v_ru_24it_243_24Just, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_it1_244);
    }
    break;
  }
  default: heff_nomatch(v_it_243);
  }
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    heff_drop(v_msg_241);
    return heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Just: {
    V v_m_2414 = heff_field(v_t_2411, 0);
    V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 1ULL, 1);
    V v_t_2426;
    switch (heff_tag_of(v_msg_241)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_drop_cell(v_ru_24t_2411_24Just, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_2420 = heff_dup(heff_field(v_msg_241, 0));
      V v_t_2421 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str1); V a_1 = v_fs_2420; V r_ = (g_list_2efind_24s913819130x636901392(a_0, a_1)); heff_drop(v_fs_2420); r_; });
      switch (heff_tag_of(v_t_2421)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24t_2411_24Just, 1);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_p_2422 = heff_field(v_t_2421, 0);
        heff_take_n(v_t_2421, 1ULL, 1);
        V v_t_2425;
        switch (heff_tag_of(v_p_2422)) {
        case TAG_MkPair: {
          V v_y_2424 = heff_field(v_p_2422, 1);
          heff_take_n(v_p_2422, 2ULL, 2);
          v_t_2425 = v_y_2424;
          break;
        }
        default: heff_nomatch(v_p_2422);
        }
        v_t_2426 = heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Just, 1, (V[]){v_t_2425});
        break;
      }
      default: heff_nomatch(v_t_2421);
      }
      break;
    }
    default: heff_nomatch(v_msg_241);
    }
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nothing: {
      V v_x2_2438;
      switch (heff_tag_of(v_msg_241)) {
      case TAG_JNull: {
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_x2_2438 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        V v_fs_2432 = heff_field(v_msg_241, 0);
        V v_ru_24msg_241_24JObject = heff_take_reuse_n(v_msg_241, 1ULL, 1);
        V v_t_2433 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str2); V a_1 = v_fs_2432; V r_ = (g_list_2efind_24s913819130x636901392(a_0, a_1)); heff_drop(v_fs_2432); r_; });
        switch (heff_tag_of(v_t_2433)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24msg_241_24JObject, 1);
          v_x2_2438 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_p_2434 = heff_field(v_t_2433, 0);
          heff_take_n(v_t_2433, 1ULL, 1);
          V v_t_2437;
          switch (heff_tag_of(v_p_2434)) {
          case TAG_MkPair: {
            V v_y_2436 = heff_field(v_p_2434, 1);
            heff_take_n(v_p_2434, 2ULL, 2);
            v_t_2437 = v_y_2436;
            break;
          }
          default: heff_nomatch(v_p_2434);
          }
          v_x2_2438 = heff_tag_at_n(v_ru_24msg_241_24JObject, TAG_Just, 1, (V[]){v_t_2437});
          break;
        }
        default: heff_nomatch(v_t_2433);
        }
        break;
      }
      default: heff_nomatch(v_msg_241);
      }
      V v_t_2440;
      switch (heff_tag_of(v_x2_2438)) {
      case TAG_Nothing: {
        v_t_2440 = NTAG(TAG_JNull);
        break;
      }
      case TAG_Just: {
        V v_x_2439 = heff_field(v_x2_2438, 0);
        heff_take_n(v_x2_2438, 1ULL, 1);
        v_t_2440 = v_x_2439;
        break;
      }
      default: heff_nomatch(v_x2_2438);
      }
      return (g_heff_2elsp_2elsp_2enotification_24s270589690x602944811(v_st_240, v_m_2414, v_t_2440));
    }
    case TAG_Just: {
      V v_id_2441 = heff_field(v_t_2426, 0);
      V v_ru_24t_2426_24Just = heff_take_reuse_n(v_t_2426, 1ULL, 1);
      V v_t_2442 = heff_dup(heff_rfield(v_st_240, 5));
      V v_t_2444 = heff_bool(((heff_dup(v_t_2442) == NTAG(TAG_True)) && !heff_strEq_c(heff_dup(v_m_2414), ((V)&g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str3))));
      heff_drop(v_t_2442);
      if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
        heff_drop(v_msg_241);
        heff_drop(v_m_2414);
        heff_drop_cell(v_ru_24t_2426_24Just, 1);
        heff_drop(v_t_2444);
        V v_c_2445 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1269256372x854260223(v_id_2441, MK_INT(-32600LL), ((V)&g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str4)));
        return heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam1, 2, 2, (V[]){v_c_2445, v_st_240});
      } else {
        heff_drop(v_t_2444);
        V v_x2_2460;
        switch (heff_tag_of(v_msg_241)) {
        case TAG_JNull: {
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_msg_241, 0ULL, 1);
          heff_drop_cell(v_ru_24t_2426_24Just, 1);
          v_x2_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          V v_fs_2454 = heff_field(v_msg_241, 0);
          heff_take_n(v_msg_241, 1ULL, 1);
          V v_t_2455 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_str5); V a_1 = v_fs_2454; V r_ = (g_list_2efind_24s913819130x636901392(a_0, a_1)); heff_drop(v_fs_2454); r_; });
          switch (heff_tag_of(v_t_2455)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24t_2426_24Just, 1);
            v_x2_2460 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_p_2456 = heff_field(v_t_2455, 0);
            heff_take_n(v_t_2455, 1ULL, 1);
            V v_t_2459;
            switch (heff_tag_of(v_p_2456)) {
            case TAG_MkPair: {
              V v_y_2458 = heff_field(v_p_2456, 1);
              heff_take_n(v_p_2456, 2ULL, 2);
              v_t_2459 = v_y_2458;
              break;
            }
            default: heff_nomatch(v_p_2456);
            }
            v_x2_2460 = heff_tag_at_n(v_ru_24t_2426_24Just, TAG_Just, 1, (V[]){v_t_2459});
            break;
          }
          default: heff_nomatch(v_t_2455);
          }
          break;
        }
        default: heff_nomatch(v_msg_241);
        }
        V v_t_2462;
        switch (heff_tag_of(v_x2_2460)) {
        case TAG_Nothing: {
          v_t_2462 = NTAG(TAG_JNull);
          break;
        }
        case TAG_Just: {
          V v_x_2461 = heff_field(v_x2_2460, 0);
          heff_take_n(v_x2_2460, 1ULL, 1);
          v_t_2462 = v_x_2461;
          break;
        }
        default: heff_nomatch(v_x2_2460);
        }
        return (g_heff_2elsp_2elsp_2erequest_24s913932025x1037063277(v_st_240, v_m_2414, v_id_2441, v_t_2462));
      }
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam2(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_2447 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2448);
  V f_ = v_k_2447;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam1(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2445;
  args[0] = v_hd_2446;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s1262289773x1458835459_lam2, 1, 2, (V[]){v_k_2447, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_entry, 2, 0};

V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_map_2edelete_24s805420727x38051515(heff_dup(v_f_244), heff_rfield(v_st_240, 2)));
    V v_t_247 = heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(heff_rfield(v_st_240, 0)), heff_dup(heff_rfield(v_st_240, 1)), v_t_246, heff_dup(heff_rfield(v_st_240, 3)), heff_dup(heff_rfield(v_st_240, 4)), heff_dup(heff_rfield(v_st_240, 5)), heff_dup(heff_rfield(v_st_240, 6))});
    V v_c_248 = (g_heff_2elsp_2elsp_2echeck_24s2135530050x2048902711(v_t_247, heff_dup(v_f_244)));
    return heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam1, 2, 4, (V[]){v_c_248, v_st_240, heff_dup(v_f_244), heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414 = ({ V a_0 = v_x_2413; V a_1 = v_rest_245; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2414;
  heff_room[0] = v_hd_249;
  heff_room[1] = v_k_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412 = (g_heff_2elsp_2elsp_2edependentsOf(v_st_240, v_f_244));
  return ({ V a_0 = v_x_2411; V a_1 = v_t_2412; V a_2 = heff_dup(v_hd_249); V a_3 = heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam3, 1, 3, (V[]){v_rest_245, v_hd_249, v_k_2410}); V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1541228589x1982848878(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
}
V g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_244 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s1941527354x171632421_lam2, 1, 5, (V[]){v_st_240, v_f_244, v_hd_249, v_rest_245, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}