// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_PathUri 23459
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Throw 56084
#define LBL_code 9554612
#define LBL_current 1358797751
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_end 310101
#define LBL_imports 10411951
#define LBL_key 315609
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_severity 75955546
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_uri 325606
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2edriver_2etraceless(V);
V g_heff_2ebuild_2edriver_2etraceless_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etraceless_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
V g_heff_2ebuild_2equery_2edefinitionAt(V, V);
V g_heff_2ebuild_2equery_2edefinitionAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionAt_clo;
V g_heff_2ebuild_2equery_2edocMarkdownIn(V, V);
V g_heff_2ebuild_2equery_2edocMarkdownIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMarkdownIn_clo;
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL(V);
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2ehoverOf(V, V);
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578(V, V);
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_clo;
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949(V, V, V);
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_clo;
V g_heff_2elsp_2elsp_2enamedIn(V);
V g_heff_2elsp_2elsp_2enamedIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enamedIn_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_clo;
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417(V, V, V);
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2eundue(V, V);
V g_heff_2elsp_2elsp_2eundue_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eundue_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1027174601x1571638094(V, V, V, V);
V g_list_2eany_24s1027174601x1571638094_entry(V self, V *a);
extern Clo g_list_2eany_24s1027174601x1571638094_clo;
V g_list_2eany_24s1399422749x931279364(V, V);
V g_list_2eany_24s1399422749x931279364_entry(V self, V *a);
extern Clo g_list_2eany_24s1399422749x931279364_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1424316379x433407702_24cpr(V, V, V, V, V, V);
HeffT2 g_list_2efind_24s792771115x178990339_24cpr(V, V);
V g_list_2efoldl_24f2094160282x1876485468(V, V, V);
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2094160282x1876485468_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s1161549307x1906011635(V);
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1533895818x411093629(V);
V g_list_2emap_24s1533895818x411093629_entry(V self, V *a);
extern Clo g_list_2emap_24s1533895818x411093629_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str1, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str2, 7, "module ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str3, 2, " (");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str4, 22, ") does not elaborate: ");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str6, 1, "s");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagsOf_str7, 6, " error");
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ediagsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagsOf_entry, 3, 0};

V g_heff_2elsp_2elsp_2ediagsOf(V v_src_240, V v_program_241, V v_errors_242) {
top: ;
  V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_241)));
  V v_t_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    v_t_246 = heff_get_n(v_x_244, 6, 14);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam0, 1, 1, (V[]){heff_dup(v_src_240)}), v_errors_242));
  V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_241));
  V v_xs_2417 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2416; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2416); r_; });
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2417));
  V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2ediagsOf_lam1, 1, 1, (V[]){v_src_240}), v_t_2418));
  V v_t_2441 = (g_heff_2elsp_2elsp_2ecatMaybesL(v_t_2440));
  V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2441));
  return (g_prelude_2e_2b_2b(v_t_246, v_t_2442));
}
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ediagsOf(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ediagsOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_imports_249 = heff_get_n(v_t_248, 0, 4);
  HeffT2 v_t_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str0); V a_2 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str1); V a_3 = v_e_247; V b_4 = MK_INT(0LL); V a_5 = v_imports_249; HeffT2 r_ = (g_list_2efind_24s1424316379x433407702_24cpr(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(b_4); heff_drop(v_imports_249); r_; });
  V v_sp_2414;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_i_2413 = v_field_2412;
      v_sp_2414 = heff_get_n(v_i_2413, 2, 3);
    } else {
      heff_drop(v_field_2412);
      v_sp_2414 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
    }
  }
  return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_e_247, v_sp_2414, NTAG(TAG_Nothing)});
}
V g_heff_2elsp_2elsp_2ediagsOf_lam1(V self, V *args) {
  V v_c_2419 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_imports_2421 = heff_get_n(v_t_2420, 0, 4);
  V v_c_2422 = v_c_2419;
  V v_x1_2423 = (g_list_2ekeepIf_24s1161549307x1906011635(heff_dup(heff_rfield(v_c_2422, 6))));
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_Nil: {
    heff_drop(v_imports_2421);
    heff_drop_rec(v_c_2422, 14);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2423, 0ULL, 2);
    V v_t_2426 = (g_list_2eany_24s1399422749x931279364(heff_dup(v_c_2422), v_imports_2421));
    if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
      heff_drop(v_t_2426);
      HeffT2 v_t_2427 = ({ V a_0 = heff_rfield(v_c_2422, 0); V a_1 = v_imports_2421; HeffT2 r_ = (g_list_2efind_24s792771115x178990339_24cpr(a_0, a_1)); heff_drop(v_imports_2421); r_; });
      V v_sp_2431;
      {
        V v_field_2429 = v_t_2427.f[1];
        int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
        if ((v_tag_2428 == ((int64_t)0ULL))) {
          V v_i_2430 = v_field_2429;
          v_sp_2431 = heff_get_n(v_i_2430, 2, 3);
        } else {
          heff_drop(v_field_2429);
          v_sp_2431 = heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get());
        }
      }
      V v_t_2432 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2ediagsOf_str2), heff_take_field(v_c_2422, 0));
      V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2elsp_2elsp_2ediagsOf_str3)), heff_take_field(v_c_2422, 1));
      V v_t_2434 = (g_list_2efoldl_24f2094160282x1876485468(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_2422, 6)));
      V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2433, ((V)&g_heff_2elsp_2elsp_2ediagsOf_str4)), heff_intShow(v_t_2434));
      V v_t_2436 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_c_2422, 6, 14); V r_ = (g_list_2efoldl_24f2094160282x1876485468(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2437;
      if (heff_intEq_c(v_t_2436, MK_INT(1LL))) {
        v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str5);
      } else {
        v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ediagsOf_str6);
      }
      V v_msg_2438 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2elsp_2elsp_2ediagsOf_str7)), v_t_2437);
      V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SWarning), v_msg_2438, v_sp_2431, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2439});
    } else {
      heff_drop(v_imports_2421);
      heff_drop_rec(v_c_2422, 14);
      heff_drop(v_t_2426);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_x1_2423);
  }
}
Clo g_heff_2elsp_2elsp_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeptOf_entry, 1, 0};

V g_heff_2elsp_2elsp_2ekeptOf(V v_program_240) {
top: ;
  V v_x1_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_240)));
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_program_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
    V v_xs_245 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_244; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_244); r_; });
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
    V v_t_247 = (g_list_2emap_24s1533895818x411093629(v_t_246));
    V v_t_248 = (g_heff_2ebuild_2edriver_2etraceless(v_x_242));
    V v_t_249 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return (g_prelude_2e_2b_2b(v_t_247, v_t_249));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ekeptOf(a[0]);
}
Clo g_heff_2elsp_2elsp_2enamedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enamedIn_entry, 1, 0};

V g_heff_2elsp_2elsp_2enamedIn(V v_l_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2elsp_2elsp_2enamedIn_24cpr(v_l_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_start__end, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2elsp_2elsp_2enamedIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2enamedIn(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str0, 3, " : ");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str1, 10, "   (local)");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str2, 11, "   (global)");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str3, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str4, 8, "markdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str6, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str7, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str8, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str9, 4, "\012```");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str10, 8, "```heff\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str11, 11, "\012```\012\012---\012\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str12, 5, "value");
HEFF_LIT(g_heff_2elsp_2elsp_2ehoverOf_str13, 8, "contents");
Clo g_heff_2elsp_2elsp_2ehoverOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehoverOf_entry, 2, 0};

V g_heff_2elsp_2elsp_2ehoverOf(V v_a_240, V v_p_241) {
top: ;
  V v_program_242 = heff_take_field(v_a_240, 2);
  V v_text_243 = heff_get_n(v_a_240, 1, 3);
  V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_242)));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    heff_drop(v_program_242);
    heff_drop(v_text_243);
    return NTAG(TAG_JNull);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Cons = heff_take_reuse_n(v_x1_244, 1ULL, 2);
    V v_off_247 = (g_heff_2elsp_2elsp_2eoffsetIn(v_text_243, heff_dup(v_p_241)));
    HeffT2 v_t_248 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_x_245, v_off_247));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_i_2411 = v_field_2410;
        V v_name_2412 = heff_take_field(v_i_2411, 1);
        V v_ty_2413 = heff_take_field(v_i_2411, 4);
        V v_key_2414 = heff_get_n(v_i_2411, 2, 5);
        V v_t_2415 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_name_2412));
        V v_t_2416 = heff_tr(heff_call(v_ty_2413, 1, (V[]){NTAG(TAG_MkUnit)}));
        V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2elsp_2elsp_2ehoverOf_str0)), v_t_2416);
        V v_t_2419;
        switch (heff_tag_of(v_key_2414)) {
        case TAG_Nothing: {
          v_t_2419 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str1);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_key_2414, 0ULL, 1);
          v_t_2419 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str2);
          break;
        }
        default: heff_nomatch(v_key_2414);
        }
        V v_t_2420 = heff_strAppend(v_t_2417, v_t_2419);
        V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str3), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str4)})});
        V v_program_2422 = v_program_242;
        V v_off_2423 = ({ V a_0 = v_text_243; V a_1 = v_p_241; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(a_0, a_1)); heff_drop(v_text_243); r_; });
        V v_t_2424 = (g_heff_2ebuild_2equery_2edefinitionAt(v_program_2422, v_off_2423));
        V v_doc_2433;
        switch (heff_tag_of(v_t_2424)) {
        case TAG_Nothing: {
          v_doc_2433 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str5);
          break;
        }
        case TAG_Just: {
          V v_d_2425 = heff_field(v_t_2424, 0);
          heff_take_n(v_t_2424, 1ULL, 1);
          V v_source_2426 = heff_take_field(v_d_2425, 1);
          V v_span_2427 = heff_get_n(v_d_2425, 2, 3);
          V v_src_2428 = heff_dup(v_source_2426);
          V v_start_2429 = ({ V a_0 = v_source_2426; V a_1 = heff_get_n(v_span_2427, 0, 2); V r_ = (g_heff_2ebuild_2equery_2elineStartOf(a_0, a_1)); heff_drop(v_source_2426); r_; });
          V v_t_2430 = ({ V a_0 = v_src_2428; V a_1 = v_start_2429; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ecommentAbove(a_0, a_1, a_2)); heff_drop(v_src_2428); r_; });
          V v_t_2431 = (g_list_2emap_24s1819241345x1511673126(v_t_2430));
          V v_ls_2432 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2431));
          v_doc_2433 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ehoverOf_str6); V a_1 = v_ls_2432; V r_ = (g_heff_2ebuild_2equery_2edocMarkdownIn(a_0, a_1)); heff_drop(v_ls_2432); r_; });
          break;
        }
        default: heff_nomatch(v_t_2424);
        }
        V v_t_2435;
        if (heff_strEq_c_lent(v_doc_2433, ((V)&g_heff_2elsp_2elsp_2ehoverOf_str7), 2)) {
          heff_drop(v_doc_2433);
          v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str8), v_t_2420), ((V)&g_heff_2elsp_2elsp_2ehoverOf_str9));
        } else {
          V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2ehoverOf_str10), v_t_2420), ((V)&g_heff_2elsp_2elsp_2ehoverOf_str11));
          v_t_2435 = heff_strAppend(v_t_2434, v_doc_2433);
        }
        V v_t_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str12), heff_tag_n(TAG_JString, 1, (V[]){v_t_2435})});
        V v_t_2437 = heff_tag_at_n(v_ru_24x1_244_24Cons, TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
        V v_t_2438 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2437})});
        V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ehoverOf_str13), v_t_2438}), NTAG(TAG_Nil)});
        return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2439});
      } else {
        heff_drop(v_p_241);
        heff_drop(v_program_242);
        heff_drop(v_text_243);
        heff_drop_cell(v_ru_24x1_244_24Cons, 2);
        heff_drop(v_field_2410);
        return NTAG(TAG_JNull);
      }
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehoverOf(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2eundue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eundue_entry, 2, 0};

V g_heff_2elsp_2elsp_2eundue(V v_due_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_due_240;
  }
  case TAG_Cons: {
    V v_f_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(v_due_240, v_f_242));
    V t_0 = v_t_244;
    V t_1 = v_rest_243;
    v_due_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2eundue_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eundue(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_str0, 0, "");
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam0, 2, 0};
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam2, 1, 0};
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam3, 1, 0};
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam7(V self, V *args);
Clo g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_entry, 3, 0};

V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949(V v_st_240, V v_names_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_st_240, 7);
    return ((V)&g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 0), v_p_245));
    V v_c_2437;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_d_2410 = v_field_249;
        v_c_2437 = heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam1, 2, 1, (V[]){v_d_2410});
      } else {
        heff_drop(v_field_249);
        V v_path_2414 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_245)));
        V v_t_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2414; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2414); r_; });
        V v_a_2417 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_ReadFile, 2, (V[]){v_t_2415, ((V)&g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam2_clo)});
        V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2417})});
        V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
        V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
        V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
        V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
        V v_c_2430 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam3_clo)));
        v_c_2437 = heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam5, 2, 1, (V[]){v_c_2430});
      }
    }
    return heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam7, 2, 5, (V[]){v_c_2437, v_st_240, heff_dup(v_names_241), v_rest_246, v_p_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2411);
  V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2410, 1, 2)});
  V f_ = v_k_2412;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam2(V self, V *args) {
  V v_r_2416 = args[0];
  return v_r_2416;
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam4(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_x_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    V v_err_2425 = heff_field(v_x_2424, 0);
    V v_ru_24x_2424_24Left = heff_take_reuse_n(v_x_2424, 1ULL, 1);
    V v_t_2426 = heff_tag_at_n(v_ru_24x_2424_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2425})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2426));
  }
  case TAG_Right: {
    V v_x_2427 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    return heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam4, 2, 1, (V[]){v_x_2427});
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436;
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    heff_take_n(v_x_2433, 0ULL, 1);
    v_t_2436 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2435 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Right = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    v_t_2436 = heff_tag_at_n(v_ru_24x_2433_24Right, TAG_Just, 1, (V[]){v_y_2435});
    break;
  }
  default: heff_nomatch(v_x_2433);
  }
  V f_ = v_k_2432;
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam5(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2430;
  args[0] = v_hd_2431;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam6, 1, 1, (V[]){v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_x_2440 = heff_env(self)[0];
  V v_names_241 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_k_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2444;
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Nothing: {
    v_t_2444 = ((V)&g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2443 = heff_field(v_x_2440, 0);
    heff_take_n(v_x_2440, 1ULL, 1);
    v_t_2444 = v_x_2443;
    break;
  }
  default: heff_nomatch(v_x_2440);
  }
  V v_t_2445 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2444; V b_2 = MK_INT(0LL); V a_3 = v_names_241; V r_ = (g_list_2eany_24s1027174601x1571638094(a_0, a_1, b_2, a_3)); heff_drop(v_t_2444); heff_drop(b_2); heff_drop(v_names_241); r_; });
  V v_x_2446;
  if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
    heff_drop(v_t_2445);
    v_x_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_245, v_x_2442});
  } else {
    heff_drop(v_p_245);
    heff_drop(v_t_2445);
    v_x_2446 = v_x_2442;
  }
  V f_ = v_k_2439;
  args[0] = v_x_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_names_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2438 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  V v_k_2439 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2441 = (g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949(v_st_240, v_names_241, v_rest_246));
  V f_ = v_c_2441;
  heff_room[0] = v_hd_2438;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam9, 1, 4, (V[]){v_x_2440, v_names_241, v_p_245, v_k_2439});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam7(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_c_2437 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_names_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2437;
  args[0] = heff_dup(v_hd_2438);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_lam8, 1, 6, (V[]){v_st_240, v_names_241, v_rest_246, v_hd_2438, v_p_245, v_k_2439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_entry, 3, 0};

V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417(V v_st_240, V v_f_241, V v_names_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(heff_dup(heff_rfield(v_st_240, 6)), heff_dup(v_f_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_lam0, 2, 4, (V[]){v_c_243, v_st_240, v_f_241, v_names_242});
}
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_lam2(V self, V *args) {
  V v_n_2415 = args[0];
  V v_had_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_n_2415}));
  return ({ V a_0 = v_t_2416; V a_1 = v_had_2413; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_had_2413); r_; });
}
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_names_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_247 = heff_dup(heff_rfield(v_st_240, 3));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    return (g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468(v_st_240, heff_get_n(v_x_246, 0, 6), v_f_241, v_names_242, v_hd_244, v_k_245));
  }
  case TAG_Just: {
    V v_pr_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_current_249 = heff_take_field(v_pr_248, 3);
    V v_root_2410 = heff_take_field(v_pr_248, 0);
    V v_names_2411 = heff_take_field(v_pr_248, 1);
    V v_program_2412 = heff_get_n(v_pr_248, 2, 5);
    if ((heff_dup(v_current_249) == NTAG(TAG_True))) {
      heff_drop(v_current_249);
      if (heff_strEq_c(v_root_2410, heff_dup(heff_rfield(v_x_246, 0)))) {
        switch (heff_tag_of(v_names_2411)) {
        case TAG_Nothing: {
          heff_drop_rec(v_x_246, 6);
          heff_drop(v_f_241);
          heff_drop(v_names_242);
          heff_drop(v_hd_244);
          V f_ = v_k_245;
          args[0] = heff_rec_n(2, shape_st__program, (V[]){v_st_240, v_program_2412});
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_Just: {
          V v_had_2413 = heff_field(v_names_2411, 0);
          heff_take_n(v_names_2411, 1ULL, 1);
          switch (heff_tag_of(v_names_242)) {
          case TAG_Nothing: {
            heff_drop(v_program_2412);
            heff_drop(v_had_2413);
            return (g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468(v_st_240, heff_get_n(v_x_246, 0, 6), v_f_241, v_names_242, v_hd_244, v_k_245));
          }
          case TAG_Just: {
            V v_wanted_2414 = heff_dup(heff_field(v_names_242, 0));
            V v_t_2417 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_lam2, 1, 1, (V[]){v_had_2413}); V a_1 = v_wanted_2414; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_wanted_2414); r_; });
            if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
              heff_drop_rec(v_x_246, 6);
              heff_drop(v_f_241);
              heff_drop_tag(v_names_242, 1);
              heff_drop(v_hd_244);
              heff_drop(v_t_2417);
              V f_ = v_k_245;
              args[0] = heff_rec_n(2, shape_st__program, (V[]){v_st_240, v_program_2412});
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            } else {
              heff_drop(v_program_2412);
              heff_drop(v_t_2417);
              return (g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468(v_st_240, heff_get_n(v_x_246, 0, 6), v_f_241, v_names_242, v_hd_244, v_k_245));
            }
          }
          default: return heff_nomatch(v_names_242);
          }
        }
        default: return heff_nomatch(v_names_2411);
        }
      } else {
        heff_drop(v_names_2411);
        heff_drop(v_program_2412);
        return (g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468(v_st_240, heff_get_n(v_x_246, 0, 6), v_f_241, v_names_242, v_hd_244, v_k_245));
      }
    } else {
      heff_drop(v_current_249);
      heff_drop(v_root_2410);
      heff_drop(v_names_2411);
      heff_drop(v_program_2412);
      return (g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468(v_st_240, heff_get_n(v_x_246, 0, 6), v_f_241, v_names_242, v_hd_244, v_k_245));
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_names_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_lam1, 1, 5, (V[]){v_st_240, v_f_241, v_names_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_str1, 5, "range");
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam0, 2, 0};
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam2, 1, 0};
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam5(V self, V *args);
Clo g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_entry, 2, 0};

V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    return ((V)&g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_st_246 = heff_dup(v_st_240);
    V v_o_247 = v_o_244;
    V v_path_248 = heff_take_field(v_o_247, 0);
    V v_source_249 = heff_take_field(v_o_247, 1);
    V v_span_2410 = heff_get_n(v_o_247, 2, 4);
    V v_p_2411 = v_path_248;
    HeffT2 v_t_2412 = ({ V b_0 = heff_get_n(v_st_246, 0, 7); V a_1 = v_p_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2424;
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_p_2411);
        V v_d_2415 = v_field_2414;
        v_c_2424 = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam1, 2, 1, (V[]){v_d_2415});
      } else {
        heff_drop(v_field_2414);
        V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_PathUri, 2, (V[]){v_p_2411, ((V)&g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam2_clo)})});
        V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
        V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
        V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
        v_c_2424 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})}));
      }
    }
    V v_c_2432 = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam3, 2, 3, (V[]){v_c_2424, v_source_249, v_span_2410});
    return heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam5, 2, 3, (V[]){v_c_2432, v_st_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_d_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = heff_get_n(v_d_2415, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam2(V self, V *args) {
  V v_u_2418 = args[0];
  return v_u_2418;
}
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_source_249 = heff_env(self)[0];
  V v_span_2410 = heff_env(self)[1];
  V v_k_2426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_str0), heff_tag_n(TAG_JString, 1, (V[]){v_x_2427})});
  V v_t_2429 = ({ V a_0 = v_source_249; V a_1 = v_span_2410; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_249); r_; });
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_str1), v_t_2429}), NTAG(TAG_Nil)});
  V v_x_2431 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2430})});
  V f_ = v_k_2426;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_source_249 = heff_env(self)[1];
  V v_span_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam4, 1, 3, (V[]){v_source_249, v_span_2410, v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2434 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2435, v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2433 = heff_env(self)[2];
  V v_k_2434 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2436 = (g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578(v_st_240, v_rest_245));
  V f_ = v_c_2436;
  heff_room[0] = v_hd_2433;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam7, 1, 2, (V[]){v_k_2434, v_x_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam5(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_c_2432 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2432;
  args[0] = heff_dup(v_hd_2433);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_lam6, 1, 4, (V[]){v_st_240, v_rest_245, v_hd_2433, v_k_2434});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}