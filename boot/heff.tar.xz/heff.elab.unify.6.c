// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_Put 28059
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SMetaApp 2372
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9005
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_entries 787768015
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_meta 9843404
#define LBL_metas 305145640
#define LBL_mty 317996
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_pairs 307786995
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prefix 967031229
#define LBL_recovered 474271923
#define LBL_ren 322325
#define LBL_renEv 309756614
#define LBL_renEvTy 1323365525
#define LBL_renFlex 1323386232
#define LBL_renTy 309757082
#define LBL_rhs 322423
#define LBL_selfKey 62480824
#define LBL_sol 323594
#define LBL_solve 310977625
#define LBL_span 10032145
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_ubare 312426689
#define LBL_uel 325206
#define LBL_uty 325684
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_meta__prefix__rhs__pairs[] = {LBL_meta, LBL_prefix, LBL_rhs, LBL_pairs};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_uty__uel__ubare__solve__ren__renEv__renTy__renEvTy__renFlex[] = {LBL_uty, LBL_uel, LBL_ubare, LBL_solve, LBL_ren, LBL_renEv, LBL_renTy, LBL_renEvTy, LBL_renFlex};
V g_co_2eplus_24s973240257x441859337_get(void);
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_clo;
HeffT2 g_heff_2eelab_2eunify_2eapproxWith_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2eforU(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2eforU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eforU_clo;
V g_heff_2eelab_2eunify_2eforU_24s2039005770x132184836(V, V, V, V);
V g_heff_2eelab_2eunify_2eforU_24s2039005770x132184836_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eforU_24s2039005770x132184836_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
V g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179(V, V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179_clo;
HeffT2 g_heff_2eelab_2eunify_2epatStep_24cpr(V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474(V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_clo;
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_clo;
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_clo;
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_clo;
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_clo;
V g_heff_2eelab_2eunify_2espineRev(V);
V g_heff_2eelab_2eunify_2espineRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2espineRev_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102(V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_clo;
V g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740(V, V, V, V);
V g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_clo;
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_clo;
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_get(void);
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_get(void);
V g_heff_2eelab_2eunify_2ezipL(V, V);
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_clo;
V g_heff_2eelab_2eunify_2ezonkTermF(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2eisFixed(V, V);
V g_heff_2eelab_2evalue_2eisFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisFixed_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2ereplay(V, V);
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereplay_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1947501783x1475115781(V, V, V);
V g_list_2emap_24s1947501783x1475115781_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);

HeffT2 g_heff_2eelab_2eunify_2epatStep_24cpr(V v_selfKey_240, V v_v_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_v_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_rest_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_v_241)) {
    case TAG_VNeu: {
      V v_v1_244 = heff_field(v_v_241, 0);
      V v_v2_245 = heff_field(v_v_241, 1);
      heff_take_n(v_v_241, 3ULL, 5);
      switch (heff_tag_of(v_v1_244)) {
      case TAG_HLocal: {
        V v_l_249 = heff_field(v_v1_244, 0);
        heff_take_n(v_v1_244, 1ULL, 1);
        switch (heff_tag_of(v_v2_245)) {
        case TAG_SpId: {
          V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24Just, TAG_PVar, 1, (V[]){v_l_249}), v_rest_243});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2410}});
        }
        case TAG_SpApp: {
          heff_take_n(v_v2_245, 0ULL, 2);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          heff_drop(v_l_249);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SpProj: {
          heff_take_n(v_v2_245, 0ULL, 2);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          heff_drop(v_l_249);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SpSpec: {
          heff_take_n(v_v2_245, 0ULL, 3);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          heff_drop(v_l_249);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_v2_245)}});
        }
      }
      case TAG_HGlobal: {
        V v_k_2418 = heff_field(v_v1_244, 0);
        heff_take_n(v_v1_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        switch (heff_tag_of(v_v2_245)) {
        case TAG_SpId: {
          switch (heff_tag_of(v_selfKey_240)) {
          case TAG_Nothing: {
            heff_drop(v_rest_243);
            heff_drop(v_k_2418);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_sk_2419 = heff_field(v_selfKey_240, 0);
            if (heff_strEq_c_lent(v_sk_2419, v_k_2418, 2)) {
              V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_PSelf), v_rest_243});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2421}});
            } else {
              heff_drop(v_rest_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_selfKey_240)}});
          }
        }
        case TAG_SpApp: {
          heff_take_n(v_v2_245, 0ULL, 2);
          heff_drop(v_rest_243);
          heff_drop(v_k_2418);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SpProj: {
          heff_take_n(v_v2_245, 0ULL, 2);
          heff_drop(v_rest_243);
          heff_drop(v_k_2418);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SpSpec: {
          heff_take_n(v_v2_245, 0ULL, 3);
          heff_drop(v_rest_243);
          heff_drop(v_k_2418);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_v2_245)}});
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_v1_244, 0ULL, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_v2_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HError: {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_v2_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_v1_244)}});
      }
    }
    case TAG_VCode: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VLam: {
      heff_take_n(v_v_241, 0ULL, 2);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VCons: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VOpaque: {
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_v_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2eelab_2eunify_2eforU_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2eforU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eforU_entry, 7, 0};

V g_heff_2eelab_2eunify_2eforU(V v_w_240, V v_ms_241, V v_uf_242, V v_x1_243, V v_f_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    heff_drop(v_f_244);
    heff_drop(v_z_245);
    return heff_tail(v_z_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x1_243, 0);
    V v_xs_248 = heff_field(v_x1_243, 1);
    V v_c_249 = heff_tr(heff_call(heff_dup(v_f_244), 1, (V[]){heff_dup(v_x_247)}));
    return heff_tail(v_c_249, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2eforU_lam0, 1, 7, (V[]){heff_dup(v_w_240), heff_dup(v_ms_241), heff_dup(v_uf_242), heff_dup(v_xs_248), v_f_244, v_z_245, v_z_246})});
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2eelab_2eunify_2eforU_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2eunify_2eforU(a0, a1, a2, a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2eunify_2eforU_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_w_240 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_uf_242 = heff_env(self)[2];
  V v_xs_248 = heff_env(self)[3];
  V v_f_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2410);
  return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_xs_248; V a_4 = v_f_244; V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2eelab_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_w_240); heff_drop(v_ms_241); heff_drop(v_uf_242); heff_drop(v_xs_248); r_; });
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2ezonkTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTypeF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SDecode: {
    V v_e_244 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SDecode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_244}));
    return heff_tag_at_n(v_ru_24t_242_24SDecode, TAG_SDecode, 1, (V[]){v_t_245});
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_t_242, 0);
    V v_dom_247 = heff_field(v_t_242, 1);
    V v_cod_248 = heff_field(v_t_242, 2);
    V v_implicit_249 = heff_field(v_t_242, 3);
    V v_dflt_2410 = heff_field(v_t_242, 4);
    V v_ru_24t_242_24SFunction = heff_take_reuse_n(v_t_242, 31ULL, 5);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_dom_247}));
    V v_f_2412 = heff_take_field(v_r_240, 1);
    V v_t_2418;
    switch (heff_tag_of(v_cod_248)) {
    case TAG_MkAbs: {
      V v_x_2413 = heff_field(v_cod_248, 0);
      V v_b_2414 = heff_field(v_cod_248, 1);
      V v_ru_24cod_248_24MkAbs = heff_take_reuse_n(v_cod_248, 3ULL, 2);
      V v_t_2415 = heff_tr(heff_call(v_f_2412, 1, (V[]){v_b_2414}));
      v_t_2418 = heff_tag_at_n(v_ru_24cod_248_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2413, v_t_2415});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_cod_248, 0);
      V v_ru_24cod_248_24AbsConst = heff_take_reuse_n(v_cod_248, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_call(v_f_2412, 1, (V[]){v_b_2416}));
      v_t_2418 = heff_tag_at_n(v_ru_24cod_248_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2417});
      break;
    }
    default: heff_nomatch(v_cod_248);
    }
    V v_t_2421;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 2);
      v_t_2421 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_d_2419 = heff_field(v_dflt_2410, 0);
      V v_ru_24dflt_2410_24Just = heff_take_reuse_n(v_dflt_2410, 1ULL, 1);
      V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_2419}));
      v_t_2421 = heff_tag_at_n(v_ru_24dflt_2410_24Just, TAG_Just, 1, (V[]){v_t_2420});
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    return heff_tag_at_n(v_ru_24t_242_24SFunction, TAG_SFunction, 5, (V[]){v_level_246, v_t_2411, v_t_2418, v_implicit_249, v_t_2421});
  }
  case TAG_SRecord: {
    V v_level_2422 = heff_field(v_t_242, 0);
    V v_ft_2423 = heff_field(v_t_242, 1);
    V v_ds_2424 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SRecord = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_xs_2425 = heff_take_field(v_ft_2423, 2);
    V v_t_2428 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2425, 0), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam0, 1, 2, (V[]){v_xs_2425, heff_dup(v_r_240)}));
    V v_t_2429 = ({ V rv_2 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_ft_2423, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_xs_2430 = heff_take_field(v_ds_2424, 2);
    V v_t_2433 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2430, 0), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam1, 1, 2, (V[]){v_xs_2430, v_r_240}));
    V v_t_2434 = ({ V rv_2 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_ds_2424, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SRecord, TAG_SRecord, 3, (V[]){v_level_2422, v_t_2429, v_t_2434});
  }
  case TAG_SSum: {
    V v_vs_2435 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SSum = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2436 = heff_take_field(v_vs_2435, 2);
    V v_t_2441 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2436, 0), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam2, 1, 2, (V[]){v_xs_2436, v_r_240}));
    V v_t_2442 = ({ V rv_2 = v_t_2441; V rr_ = heff_rec_reuse_nf(v_vs_2435, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SSum, TAG_SSum, 1, (V[]){v_t_2442});
  }
  case TAG_SIsTy: {
    V v_a_2443 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIsTy = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2444 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_a_2443}));
    return heff_tag_at_n(v_ru_24t_242_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2444});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimArray: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2eunify_2ezonkTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTypeF(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam0(V self, V *args) {
  V v_i_2426 = args[0];
  V v_xs_2425 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_arrayIndex(v_xs_2425, v_i_2426);
  V f_ = heff_get_n(v_r_240, 1, 2);
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam1(V self, V *args) {
  V v_i_2431 = args[0];
  V v_xs_2430 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_arrayIndex(v_xs_2430, v_i_2431);
  V f_ = heff_get_n(v_r_240, 0, 2);
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam3(V self, V *args) {
  V v_i_2439 = args[0];
  V v_xs_2438 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_arrayIndex(v_xs_2438, v_i_2439);
  V f_ = heff_get_n(v_r_240, 1, 2);
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam2(V self, V *args) {
  V v_i_2437 = args[0];
  V v_xs_2436 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2438 = heff_arrayIndex(v_xs_2436, v_i_2437);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2438, 0), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam3, 1, 2, (V[]){v_xs_2438, v_r_240}));
}
V g_heff_2eelab_2eunify_2ezonker_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2ezonker_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2ezonker_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonker_entry, 1, 0};

V g_heff_2eelab_2eunify_2ezonker(V v_mc_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2ezonker_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2ezonker_lam1, 1, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2ezonker(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2ezonker_lam0(V self, V *args) {
  V v_t_241 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2eelab_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_242; V a_1 = v_mc_240; V a_2 = v_t_241; V r_ = (g_heff_2eelab_2eunify_2ezonkTermF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2eunify_2ezonker_lam1(V self, V *args) {
  V v_t_243 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eelab_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_t_243; V r_ = (g_heff_2eelab_2eunify_2ezonkTypeF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}

HeffT2 g_heff_2eelab_2eunify_2eapproxWith_24cpr(V v_g_240, V v_m_241, V v_k_242, V v_metaArgs_243, V v_key_244, V v_rigidArgs_245) {
top: ;
  if (heff_intLt_c_lent(v_k_242, MK_INT(1LL), 2)) {
    heff_drop_rec(v_g_240, 9);
    heff_drop(v_m_241);
    heff_drop(v_k_242);
    heff_drop(v_metaArgs_243);
    heff_drop(v_rigidArgs_245);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_rigidArgs_245));
    if (heff_intLt_c_lent(v_t_247, v_k_242, 1)) {
      heff_drop_rec(v_g_240, 9);
      heff_drop(v_m_241);
      heff_drop(v_k_242);
      heff_drop(v_metaArgs_243);
      heff_drop(v_rigidArgs_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      V v_t_249 = (g_list_2edrop(heff_dup(v_k_242), v_metaArgs_243));
      V v_t_2410 = (g_heff_2eelab_2eunify_2espineRev(v_t_249));
      HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_g_240, 1, 9); V a_1 = v_key_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2416;
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_e_2415 = v_field_2413;
          v_t_2416 = v_e_2415;
        } else {
          heff_drop(v_field_2413);
          v_t_2416 = heff_abandon();
        }
      }
      V v_t_2417 = (g_list_2edrop(heff_dup(v_k_242), v_rigidArgs_245));
      V v_t_2418 = (g_heff_2eelab_2eunify_2espineRev(v_t_2417));
      V v_t_2419 = ({ V a_0 = heff_get_n(v_t_2416, 2, 4); V a_1 = v_t_2418; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_t_2418); r_; });
      V v_t_2420 = (g_list_2etake(heff_dup(v_k_242), v_metaArgs_243));
      V v_t_2421 = (g_list_2etake(v_k_242, v_rigidArgs_245));
      V v_t_2422 = (g_heff_2eelab_2eunify_2ezipL(v_t_2420, v_t_2421));
      V v_f_2423 = heff_rec_n(4, shape_meta__prefix__rhs__pairs, (V[]){v_m_241, v_t_2410, v_t_2419, v_t_2422});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2423}});
    }
  }
}
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_str0, 5, "solve");
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_str1, 5, ") := ");
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_str2, 2, " (");
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_str3, 1, "\?");
V g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_entry, 4, 0};

V g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740(V v_m_240, V v_stx_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_lam0, 1, 2, (V[]){v_m_240, v_stx_241})})});
  V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2418}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_2419, heff_clo_n(g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_lam2, 1, 2, (V[]){v_hd_242, v_k_243})});
}
V g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_stx_241 = heff_env(self)[1];
  V v_e_249 = heff_env(self)[2];
  V v_m_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2410);
  V v_t_2411 = ({ V b_0 = heff_get_n(v_c_244, 3, 8); V r_ = (g_heff_2eelab_2eunify_2ezonker(b_0)); heff_drop(b_0); r_; });
  V v_e_2412 = heff_tr(heff_call(heff_get_n(v_t_2411, 0, 2), 1, (V[]){v_stx_241}));
  V v_t_2413 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_e_2412));
  V v_t_2414 = heff_strAppend(heff_get_n(v_e_249, 4, 6), heff_strAppend(((V)&g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_str1), v_t_2413));
  V v_t_2415 = heff_strAppend(heff_intShow(v_m_240), heff_strAppend(((V)&g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_str2), v_t_2414));
  return heff_strAppend(((V)&g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_str3), v_t_2415);
}
V g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_lam0(V self, V *args) {
  V v_c_244 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_stx_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_c_244, 3), heff_dup(v_m_240)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_e_249 = v_field_247;
      V v_t_2416 = heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(heff_rfield(v_e_249, 5)), ((V)&g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_str0), heff_clo_n(g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_lam1, 1, 4, (V[]){heff_dup(v_c_244), v_stx_241, v_e_249, v_m_240})});
      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_take_field(v_c_244, 6)});
      return ({ V rv_6 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_c_244, 191ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 53247u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
    } else {
      heff_drop(v_m_240);
      heff_drop(v_stx_241);
      heff_drop(v_field_247);
      return v_c_244;
    }
  }
}
V g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2420, NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})}));
  V f_ = heff_get_n(v_hd_242, 1, 3);
  heff_room[0] = v_t_2422;
  heff_room[1] = v_k_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890(V v_g_240, V v_occursM_241, V v_storeM_242, V v_entry_243, V v_n_244, V v_kept_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_dup(heff_rfield(v_entry_243, 3)), MK_INT(0LL), heff_dup(g_std_2emap_2eempty_get())});
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(heff_dup(v_g_240), v_occursM_241, v_t_248, heff_dup(heff_rfield(v_entry_243, 0)), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_lam0, 1, 7, (V[]){v_kept_245, v_g_240, v_entry_243, v_hd_246, v_n_244, v_storeM_242, v_k_247})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_v_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2430);
  V f_ = v_k_247;
  args[0] = v_v_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_storeM_242 = heff_env(self)[0];
  V v_t_2423 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_v_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2429);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740(v_storeM_242, v_t_2423, v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_lam3, 1, 2, (V[]){v_k_247, v_v_2428})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_n_244 = heff_env(self)[0];
  V v_kept_245 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_storeM_242 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2421 = (g_list_2emap_24s1947501783x1475115781(heff_dup(v_n_244), MK_INT(1LL), v_kept_245));
  V v_t_2422 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_x_2420, heff_arrayFromList(v_t_2421), v_x_249});
  V v_t_2423 = (g_heff_2eelab_2eunify_2elamsU(v_n_244, v_t_2422));
  V v_x1_2424 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2423), NTAG(TAG_LNil)));
  V v_v_2428;
  switch (heff_tag_of(v_x1_2424)) {
  case TAG_Nom: {
    V v_x_2425 = heff_field(v_x1_2424, 0);
    heff_take_n(v_x1_2424, 1ULL, 1);
    v_v_2428 = v_x_2425;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2424, 0ULL, 1);
    v_v_2428 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2427 = heff_field(v_x1_2424, 0);
    heff_take_n(v_x1_2424, 1ULL, 1);
    v_v_2428 = v_x_2427;
    break;
  }
  default: heff_nomatch(v_x1_2424);
  }
  return (g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102(heff_dup(v_storeM_242), heff_dup(v_v_2428), heff_dup(v_t_2423), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_lam2, 1, 5, (V[]){v_storeM_242, v_t_2423, v_hd_246, v_k_247, v_v_2428})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_kept_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_entry_243 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_n_244 = heff_env(self)[4];
  V v_storeM_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_kept_245));
  HeffT2 v_t_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_x_249), NTAG(TAG_LNil)));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    V v_t_2419;
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2413;
      v_t_2419 = v_x_2415;
    } else {
      if ((v_tag_2412 == ((int64_t)1ULL))) {
        V v_x11_2417 = v_field_2413;
        heff_drop(v_x11_2417);
        v_t_2419 = heff_abandon();
      } else {
        V v_x_2418 = v_field_2413;
        v_t_2419 = v_x_2418;
      }
    }
    return (g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179(v_entry_243, v_t_2410, v_t_2419, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_lam1, 1, 7, (V[]){v_n_244, v_kept_245, v_x_249, v_g_240, v_storeM_242, v_hd_246, v_k_247})));
  }
}
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam0, 4, 0};
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam1, 4, 0};
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam4, 4, 0};

static V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_val;
static HEFF_ONCE g_heff_2eelab_2eunify_2euk_24s506988832x820849616_st;
static V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_init(void) {
  return heff_rec_n(9, shape_uty__uel__ubare__solve__ren__renEv__renTy__renEvTy__renFlex, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam0_clo), ((V)&g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_clo), ((V)&g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_clo), ((V)&g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam1_clo), ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam4_clo), ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_clo)});
}
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eunify_2euk_24s506988832x820849616_st)) return g_heff_2eelab_2eunify_2euk_24s506988832x820849616_val;
  return heff_global(&g_heff_2eelab_2eunify_2euk_24s506988832x820849616_val, &g_heff_2eelab_2eunify_2euk_24s506988832x820849616_st, g_heff_2eelab_2eunify_2euk_24s506988832x820849616_init);
}
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_cs_241 = args[1];
  V v_a_242 = args[2];
  V v_b_243 = args[3];
  return (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s973240257x441859337_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s506988832x820849616_get()), v_g_240, v_cs_241, v_a_242, v_b_243));
}
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_g_244 = heff_env(self)[0];
  V v_m_245 = heff_env(self)[1];
  V v_pr_246 = heff_env(self)[2];
  V v_v_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(v_g_244, v_m_245, v_pr_246, v_v_2410, v_hd_2411, heff_clo_n(g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam3, 1, 1, (V[]){v_k_2412})));
}
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam1(V self, V *args) {
  V v_g_244 = args[0];
  V v_m_245 = args[1];
  V v_pr_246 = args[2];
  V v_v_247 = args[3];
  switch (heff_tag_of(v_v_247)) {
  case TAG_Nom: {
    V v_v_248 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo);
    args[0] = v_g_244;
    args[1] = v_m_245;
    args[2] = v_pr_246;
    args[3] = v_v_248;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Describe: {
    V v_v_249 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo);
    args[0] = v_g_244;
    args[1] = v_m_245;
    args[2] = v_pr_246;
    args[3] = v_v_249;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Become: {
    V v_v_2410 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    return heff_clo_n(g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam2, 2, 4, (V[]){v_g_244, v_m_245, v_pr_246, v_v_2410});
  }
  default: return heff_nomatch(v_v_247);
  }
}
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_g_2414 = heff_env(self)[0];
  V v_m_2415 = heff_env(self)[1];
  V v_pr_2416 = heff_env(self)[2];
  V v_a_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(v_g_2414, v_m_2415, v_pr_2416, v_a_2420, v_hd_2421, heff_clo_n(g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam6, 1, 1, (V[]){v_k_2422})));
}
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam4(V self, V *args) {
  V v_g_2414 = args[0];
  V v_m_2415 = args[1];
  V v_pr_2416 = args[2];
  V v_t_2417 = args[3];
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nom: {
    V v_a_2418 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo);
    args[0] = v_g_2414;
    args[1] = v_m_2415;
    args[2] = v_pr_2416;
    args[3] = v_a_2418;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Describe: {
    V v_a_2419 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo);
    args[0] = v_g_2414;
    args[1] = v_m_2415;
    args[2] = v_pr_2416;
    args[3] = v_a_2419;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Become: {
    V v_a_2420 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    return heff_clo_n(g_heff_2eelab_2eunify_2euk_24s506988832x820849616_lam5, 2, 4, (V[]){v_g_2414, v_m_2415, v_pr_2416, v_a_2420});
  }
  default: return heff_nomatch(v_t_2417);
  }
}
HEFF_LIT(g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_str0, 1, "x");
V g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842(V v_g_240, V v_cs_241, V v_a_242, V v_b_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    V v_u_246 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_u_27_247 = heff_dup(heff_field(v_b_243, 0));
      switch (heff_tag_of(v_u_246)) {
      case TAG_SmallU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          heff_drop_rec(v_cs_241, 2);
          heff_drop_tag(v_a_242, 1);
          heff_drop_tag(v_b_243, 1);
          heff_drop_rec(v_z_244, 3);
          return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        case TAG_LargeU: {
          V v_t_248 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
          V v_t_249 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})}));
          return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_249, v_z_245});
        }
        default: return heff_nomatch(v_u_27_247);
        }
      }
      case TAG_LargeU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          V v_t_2410 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
          V v_t_2411 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})}));
          return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2411, v_z_245});
        }
        case TAG_LargeU: {
          heff_drop_rec(v_cs_241, 2);
          heff_drop_tag(v_a_242, 1);
          heff_drop_tag(v_b_243, 1);
          heff_drop_rec(v_z_244, 3);
          return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        default: return heff_nomatch(v_u_27_247);
        }
      }
      default: return heff_nomatch(v_u_246);
      }
    }
    case TAG_VDecode: {
      heff_drop(v_u_246);
      V v_t_2417 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2418 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2418, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_u_246);
      V v_t_2424 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2425 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2425, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_u_246);
      V v_t_2430 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2431 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2431, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_u_246);
      V v_t_2433 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2434 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2434, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_u_246);
      V v_t_2435 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2436 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2436, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_u_246);
      V v_t_2437 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2438 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2438, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_u_246);
      V v_t_2439 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2440 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2440, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_u_246);
      V v_t_2441 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2442 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2442, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_u_246);
      V v_t_2444 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2445 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2445, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_u_246);
      V v_t_2447 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2448 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2448, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VDecode: {
    V v_h_2449 = heff_dup(heff_field(v_a_242, 0));
    V v_sp_2450 = heff_dup(heff_field(v_a_242, 1));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2455 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2456 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2456, v_z_245});
    }
    case TAG_VDecode: {
      V v_h_27_2457 = heff_field(v_b_243, 0);
      V v_sp_27_2458 = heff_field(v_b_243, 1);
      heff_take_n(v_b_243, 3ULL, 5);
      heff_drop_tag(v_a_242, 5);
      V v_t_2462 = (g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086(v_g_240, v_cs_241, v_h_2449, v_sp_2450, v_h_27_2457, v_sp_27_2458));
      return heff_tail(v_t_2462, 2, (V[]){v_z_244, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2468 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2469 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2469, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2474 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2475 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2475, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2477 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2478 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2478, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2479 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2480 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2480, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2481 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2482 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2482, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2483 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2484 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2484, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2485 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2486 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2486, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2488 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2489 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2489, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_h_2449);
      heff_drop(v_sp_2450);
      V v_t_2491 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2492 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2492, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VFunction: {
    V v_level_2493 = heff_dup(heff_field(v_a_242, 0));
    V v_dom_2494 = heff_dup(heff_field(v_a_242, 1));
    V v_cod_2495 = heff_dup(heff_field(v_a_242, 2));
    V v_implicit_2496 = heff_dup(heff_field(v_a_242, 3));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_2499 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24100 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2499})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24100, v_z_245});
    }
    case TAG_VDecode: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24106 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24107 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24106})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24107, v_z_245});
    }
    case TAG_VFunction: {
      V v_level_27_24108 = heff_dup(heff_field(v_b_243, 0));
      V v_dom_27_24109 = heff_dup(heff_field(v_b_243, 1));
      V v_cod_27_24110 = heff_dup(heff_field(v_b_243, 2));
      V v_implicit_27_24111 = heff_dup(heff_field(v_b_243, 3));
      V v_t_24113 = ({ V a_0 = v_level_2493; V a_1 = v_level_27_24108; V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, a_1)); heff_drop(v_level_2493); heff_drop(v_level_27_24108); r_; });
      V v_t_24114;
      if ((heff_dup(v_t_24113) == NTAG(TAG_True))) {
        heff_drop(v_t_24113);
        switch (heff_tag_of(v_implicit_2496)) {
        case TAG_Expl: {
          switch (heff_tag_of(v_implicit_27_24111)) {
          case TAG_Expl: {
            v_t_24114 = NTAG(TAG_True);
            break;
          }
          case TAG_Impl: {
            v_t_24114 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_24114 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24111);
          }
          break;
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_implicit_27_24111)) {
          case TAG_Expl: {
            v_t_24114 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_24114 = NTAG(TAG_True);
            break;
          }
          case TAG_Inst: {
            v_t_24114 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24111);
          }
          break;
        }
        case TAG_Inst: {
          switch (heff_tag_of(v_implicit_27_24111)) {
          case TAG_Expl: {
            v_t_24114 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_24114 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_24114 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_implicit_27_24111);
          }
          break;
        }
        default: heff_nomatch(v_implicit_2496);
        }
      } else {
        heff_drop(v_implicit_2496);
        heff_drop(v_implicit_27_24111);
        heff_drop(v_t_24113);
        v_t_24114 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_24114) == NTAG(TAG_True))) {
        heff_drop_tag(v_a_242, 5);
        heff_drop_tag(v_b_243, 5);
        heff_drop(v_t_24114);
        HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_dom_2494), v_dom_27_24109, heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_lam0, 1, 7, (V[]){v_cs_241, v_dom_2494, v_cod_2495, v_cod_27_24110, v_g_240, v_z_244, v_z_245}));
      } else {
        heff_drop(v_g_240);
        heff_drop(v_dom_2494);
        heff_drop(v_cod_2495);
        heff_drop(v_dom_27_24109);
        heff_drop(v_cod_27_24110);
        heff_drop(v_t_24114);
        V v_t_24146 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
        V v_t_24147 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24146})}));
        return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24147, v_z_245});
      }
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24152 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24153 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24152})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24153, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24155 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24156 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24155})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24156, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24157 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24158 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24157})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24158, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24159 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24160 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24159})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24160, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24161 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24162 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24161})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24162, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24163 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24164 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24163})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24164, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24166 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24167 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24166})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24167, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_level_2493);
      heff_drop(v_dom_2494);
      heff_drop(v_cod_2495);
      heff_drop(v_implicit_2496);
      V v_t_24169 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24170 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24169})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24170, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VRecord: {
    heff_drop(v_g_240);
    V v_t_24175 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    V v_t_24176 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24175})}));
    return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24176, v_z_245});
  }
  case TAG_VSum: {
    heff_drop(v_g_240);
    V v_t_24178 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    V v_t_24179 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24178})}));
    return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24179, v_z_245});
  }
  case TAG_VPrimInt: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24181 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24182 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24181})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24182, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24188 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24189 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24188})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24189, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24195 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24196 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24195})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24196, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24201 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24202 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24201})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24202, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24204 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24205 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24204})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24205, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimFloat: {
      V v_t_24206 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24207 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24206})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24207, v_z_245});
    }
    case TAG_VPrimString: {
      V v_t_24208 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24209 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24208})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24209, v_z_245});
    }
    case TAG_VPrimRune: {
      V v_t_24210 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24211 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24210})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24211, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24213 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24214 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24213})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24214, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24216 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24217 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24216})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24217, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimFloat: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24219 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24220 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24219})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24220, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24226 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24227 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24226})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24227, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24233 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24234 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24233})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24234, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24239 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24240 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24239})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24240, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24242 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24243 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24242})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24243, v_z_245});
    }
    case TAG_VPrimInt: {
      V v_t_24244 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24245 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24244})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24245, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimString: {
      V v_t_24246 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24247 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24246})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24247, v_z_245});
    }
    case TAG_VPrimRune: {
      V v_t_24248 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24249 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24248})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24249, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24251 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24252 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24251})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24252, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24254 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24255 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24254})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24255, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimString: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24257 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24258 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24257})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24258, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24264 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24265 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24264})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24265, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24271 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24272 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24271})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24272, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24277 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24278 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24277})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24278, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24280 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24281 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24280})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24281, v_z_245});
    }
    case TAG_VPrimInt: {
      V v_t_24282 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24283 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24282})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24283, v_z_245});
    }
    case TAG_VPrimFloat: {
      V v_t_24284 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24285 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24284})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24285, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimRune: {
      V v_t_24286 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24287 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24286})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24287, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24289 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24290 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24289})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24290, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24292 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24293 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24292})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24293, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimRune: {
    heff_drop(v_g_240);
    V v_t_24312;
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VFunction: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24312 = NTAG(TAG_True);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24312 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    if ((heff_dup(v_t_24312) == NTAG(TAG_True))) {
      heff_drop_rec(v_cs_241, 2);
      heff_drop(v_b_243);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_24312);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      heff_drop(v_t_24312);
      V v_t_24313 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24314 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24313})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24314, v_z_245});
    }
  }
  case TAG_VPrimArray: {
    V v_x_24315 = heff_dup(heff_field(v_a_242, 0));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24317 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24318 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24317})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24318, v_z_245});
    }
    case TAG_VDecode: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24324 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24325 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24324})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24325, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24331 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24332 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24331})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24332, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24337 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24338 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24337})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24338, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24340 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24341 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24340})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24341, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24342 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24343 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24342})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24343, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24344 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24345 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24344})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24345, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24346 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24347 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24346})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24347, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24348 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24349 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24348})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24349, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_y_24350 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      heff_drop_tag(v_a_242, 1);
      HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351(v_g_240, v_cs_241, v_x_24315, v_y_24350, v_z_244, v_z_245);
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_x_24315);
      V v_t_24352 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24353 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24352})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24353, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VFixed: {
    V v_w_24354 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    V v_t_24355 = ({ V a_0 = v_w_24354; V a_1 = v_b_243; V r_ = (g_heff_2eelab_2evalue_2eisFixed(a_0, a_1)); heff_drop(v_w_24354); r_; });
    if ((heff_dup(v_t_24355) == NTAG(TAG_True))) {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_tag(v_a_242, 1);
      heff_drop(v_b_243);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_24355);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      heff_drop(v_t_24355);
      V v_t_24356 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24357 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24356})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24357, v_z_245});
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_lam1(V self, V *args) {
  V v_u_24117 = args[0];
  V v_dom_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24117);
  return v_dom_2494;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_lam2(V self, V *args) {
  V v_w_24122 = args[0];
  V v_v_24118 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24122);
  return v_v_24118;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_lam3(V self, V *args) {
  V v_w_24132 = args[0];
  V v_v_24118 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24132);
  return v_v_24118;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_lam0(V self, V *args) {
  V v_x_24115 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_dom_2494 = heff_env(self)[1];
  V v_cod_2495 = heff_env(self)[2];
  V v_cod_27_24110 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_24115);
  V v_t_24116 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_241, 0))});
  V v_v_24118 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_24116, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_lam1, 1, 1, (V[]){v_dom_2494}), NTAG(TAG_Nothing)));
  V v_x1_24124;
  switch (heff_tag_of(v_cod_2495)) {
  case TAG_MkClo: {
    V v_vs_24120 = heff_dup(heff_field(v_cod_2495, 1));
    V v_body_24121 = heff_dup(heff_field(v_cod_2495, 2));
    v_x1_24124 = heff_tr(heff_call(v_body_24121, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24120, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_lam2, 1, 1, (V[]){heff_dup(v_v_24118)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24123 = heff_dup(heff_field(v_cod_2495, 0));
    v_x1_24124 = v_body_24123;
    break;
  }
  default: heff_nomatch(v_cod_2495);
  }
  V v_a_24128;
  switch (heff_tag_of(v_x1_24124)) {
  case TAG_Nom: {
    V v_x_24125 = heff_field(v_x1_24124, 0);
    heff_take_n(v_x1_24124, 1ULL, 1);
    v_a_24128 = v_x_24125;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24124, 0ULL, 1);
    v_a_24128 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24127 = heff_field(v_x1_24124, 0);
    heff_take_n(v_x1_24124, 1ULL, 1);
    v_a_24128 = v_x_24127;
    break;
  }
  default: heff_nomatch(v_x1_24124);
  }
  V v_x1_24134;
  switch (heff_tag_of(v_cod_27_24110)) {
  case TAG_MkClo: {
    V v_vs_24130 = heff_field(v_cod_27_24110, 1);
    V v_body_24131 = heff_field(v_cod_27_24110, 2);
    heff_take_n(v_cod_27_24110, 6ULL, 3);
    v_x1_24134 = heff_tr(heff_call(v_body_24131, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24130, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_lam3, 1, 1, (V[]){v_v_24118})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24133 = heff_field(v_cod_27_24110, 0);
    heff_take_n(v_cod_27_24110, 1ULL, 1);
    heff_drop(v_v_24118);
    v_x1_24134 = v_body_24133;
    break;
  }
  default: heff_nomatch(v_cod_27_24110);
  }
  V v_b_24138;
  switch (heff_tag_of(v_x1_24134)) {
  case TAG_Nom: {
    V v_x_24135 = heff_field(v_x1_24134, 0);
    heff_take_n(v_x1_24134, 1ULL, 1);
    v_b_24138 = v_x_24135;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24134, 0ULL, 1);
    v_b_24138 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24137 = heff_field(v_x1_24134, 0);
    heff_take_n(v_x1_24134, 1ULL, 1);
    v_b_24138 = v_x_24137;
    break;
  }
  default: heff_nomatch(v_x1_24134);
  }
  V v_t_24139 = heff_intAdd(heff_take_field(v_cs_241, 0), MK_INT(1LL));
  V v_t_24144;
  switch (heff_tag_of(v_cod_2495)) {
  case TAG_MkClo: {
    V v_n_24140 = heff_field(v_cod_2495, 0);
    heff_take_n(v_cod_2495, 1ULL, 3);
    v_t_24144 = v_n_24140;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2495, 0ULL, 1);
    v_t_24144 = ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s957510031x360636842_str0);
    break;
  }
  default: heff_nomatch(v_cod_2495);
  }
  V v_t_24145 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24144, heff_get_n(v_cs_241, 1, 2)});
  return (g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351(v_g_240, heff_rec_n(2, shape_len__names, (V[]){v_t_24139, v_t_24145}), v_a_24128, v_b_24138, v_z_244, v_z_245));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792(V v_g_240, V v_occursM_241, V v_storeM_242, V v_entry_243, V v_n_244, V v_kept_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_dup(heff_rfield(v_entry_243, 3)), MK_INT(0LL), heff_dup(g_std_2emap_2eempty_get())});
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(heff_dup(v_g_240), v_occursM_241, v_t_248, heff_dup(heff_rfield(v_entry_243, 0)), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_lam0, 1, 7, (V[]){v_kept_245, v_g_240, v_entry_243, v_hd_246, v_n_244, v_storeM_242, v_k_247})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_v_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2430);
  V f_ = v_k_247;
  args[0] = v_v_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_storeM_242 = heff_env(self)[0];
  V v_t_2423 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_v_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2429);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740(v_storeM_242, v_t_2423, v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_lam3, 1, 2, (V[]){v_k_247, v_v_2428})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_n_244 = heff_env(self)[0];
  V v_kept_245 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_storeM_242 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2421 = (g_list_2emap_24s1947501783x1475115781(heff_dup(v_n_244), MK_INT(1LL), v_kept_245));
  V v_t_2422 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_x_2420, heff_arrayFromList(v_t_2421), v_x_249});
  V v_t_2423 = (g_heff_2eelab_2eunify_2elamsU(v_n_244, v_t_2422));
  V v_x1_2424 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2423), NTAG(TAG_LNil)));
  V v_v_2428;
  switch (heff_tag_of(v_x1_2424)) {
  case TAG_Nom: {
    V v_x_2425 = heff_field(v_x1_2424, 0);
    heff_take_n(v_x1_2424, 1ULL, 1);
    v_v_2428 = v_x_2425;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2424, 0ULL, 1);
    v_v_2428 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2427 = heff_field(v_x1_2424, 0);
    heff_take_n(v_x1_2424, 1ULL, 1);
    v_v_2428 = v_x_2427;
    break;
  }
  default: heff_nomatch(v_x1_2424);
  }
  return (g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102(heff_dup(v_storeM_242), heff_dup(v_v_2428), heff_dup(v_t_2423), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_lam2, 1, 5, (V[]){v_storeM_242, v_t_2423, v_hd_246, v_k_247, v_v_2428})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_kept_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_entry_243 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_n_244 = heff_env(self)[4];
  V v_storeM_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_kept_245));
  HeffT2 v_t_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_x_249), NTAG(TAG_LNil)));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    V v_t_2419;
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2413;
      v_t_2419 = v_x_2415;
    } else {
      if ((v_tag_2412 == ((int64_t)1ULL))) {
        V v_x11_2417 = v_field_2413;
        heff_drop(v_x11_2417);
        v_t_2419 = heff_abandon();
      } else {
        V v_x_2418 = v_field_2413;
        v_t_2419 = v_x_2418;
      }
    }
    return (g_heff_2eelab_2eunify_2enewMetaFrom_24s117264527x1761182179(v_entry_243, v_t_2410, v_t_2419, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_lam1, 1, 7, (V[]){v_n_244, v_kept_245, v_x_249, v_g_240, v_storeM_242, v_hd_246, v_k_247})));
  }
}
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam0, 4, 0};
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam1, 4, 0};
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam4, 4, 0};

static V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_val;
static HEFF_ONCE g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_st;
static V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_init(void) {
  return heff_rec_n(9, shape_uty__uel__ubare__solve__ren__renEv__renTy__renEvTy__renFlex, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam0_clo), ((V)&g_heff_2eelab_2eunify_2euBareF_24s2126654479x750963545_clo), ((V)&g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319_clo), ((V)&g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam1_clo), ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam4_clo), ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_clo)});
}
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_st)) return g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_val;
  return heff_global(&g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_val, &g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_st, g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_init);
}
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_cs_241 = args[1];
  V v_a_242 = args[2];
  V v_b_243 = args[3];
  return (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s973240257x441859337_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_get()), v_g_240, v_cs_241, v_a_242, v_b_243));
}
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_g_244 = heff_env(self)[0];
  V v_m_245 = heff_env(self)[1];
  V v_pr_246 = heff_env(self)[2];
  V v_v_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445(v_g_244, v_m_245, v_pr_246, v_v_2410, v_hd_2411, heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam3, 1, 1, (V[]){v_k_2412})));
}
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam1(V self, V *args) {
  V v_g_244 = args[0];
  V v_m_245 = args[1];
  V v_pr_246 = args[2];
  V v_v_247 = args[3];
  switch (heff_tag_of(v_v_247)) {
  case TAG_Nom: {
    V v_v_248 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_clo);
    args[0] = v_g_244;
    args[1] = v_m_245;
    args[2] = v_pr_246;
    args[3] = v_v_248;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Describe: {
    V v_v_249 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_clo);
    args[0] = v_g_244;
    args[1] = v_m_245;
    args[2] = v_pr_246;
    args[3] = v_v_249;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Become: {
    V v_v_2410 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    return heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam2, 2, 4, (V[]){v_g_244, v_m_245, v_pr_246, v_v_2410});
  }
  default: return heff_nomatch(v_v_247);
  }
}
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_g_2414 = heff_env(self)[0];
  V v_m_2415 = heff_env(self)[1];
  V v_pr_2416 = heff_env(self)[2];
  V v_a_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(v_g_2414, v_m_2415, v_pr_2416, v_a_2420, v_hd_2421, heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam6, 1, 1, (V[]){v_k_2422})));
}
V g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam4(V self, V *args) {
  V v_g_2414 = args[0];
  V v_m_2415 = args[1];
  V v_pr_2416 = args[2];
  V v_t_2417 = args[3];
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nom: {
    V v_a_2418 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_clo);
    args[0] = v_g_2414;
    args[1] = v_m_2415;
    args[2] = v_pr_2416;
    args[3] = v_a_2418;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Describe: {
    V v_a_2419 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_clo);
    args[0] = v_g_2414;
    args[1] = v_m_2415;
    args[2] = v_pr_2416;
    args[3] = v_a_2419;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Become: {
    V v_a_2420 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    return heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_lam5, 2, 4, (V[]){v_g_2414, v_m_2415, v_pr_2416, v_a_2420});
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam4, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam7(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam7, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005(V v_g_240, V v_cs_241, V v_a0_242, V v_b0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam0, 1, 1, (V[]){v_a0_242})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam1, 1, 5, (V[]){v_b0_243, v_hd_244, v_cs_241, v_k_245, v_g_240})});
}
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_b0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2410, 3, 8); V a_1 = v_b0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam4(V self, V *args) {
  V v_c_2458 = args[0];
  return heff_get_n(v_c_2458, 3, 8);
}
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam7(V self, V *args) {
  V v_c_2465 = args[0];
  return heff_get_n(v_c_2465, 3, 8);
}
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam8(V self, V *args) {
  V v_x_2468 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2469 = ({ V a_0 = v_x_2468; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2468); r_; });
  V v_t_2470 = heff_tr(heff_call(heff_get_n(v_t_2469, 1, 3), 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_241, 0, 2), v_x_2413}));
  return ({ V a_0 = v_t_2470; V a_1 = v_hd_244; V a_2 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474(a_0, a_1, a_2)); heff_drop(v_t_2470); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam6(V self, V *args) {
  V v_x_2464 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2464);
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam7_clo)})});
  V v_t_2467 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2466}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2467;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam8, 1, 4, (V[]){v_cs_241, v_x_2413, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam5(V self, V *args) {
  V v_x_2461 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2462 = ({ V a_0 = v_x_2461; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2461); r_; });
  V v_t_2463 = heff_tr(heff_call(heff_get_n(v_t_2462, 1, 3), 3, (V[]){MK_INT(20LL), heff_dup(heff_rfield(v_cs_241, 0)), v_x_249}));
  return ({ V a_0 = v_t_2463; V a_1 = heff_dup(v_hd_244); V a_2 = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam6, 1, 4, (V[]){v_hd_244, v_cs_241, v_x_2413, v_k_245}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474(a_0, a_1, a_2)); heff_drop(v_t_2463); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2435;
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_2415 = heff_dup(heff_field(v_x_249, 0));
    switch (heff_tag_of(v_h_2415)) {
    case TAG_HLocal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2415);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_t_2457;
  if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
    heff_drop(v_t_2435);
    v_t_2457 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2435);
    switch (heff_tag_of(v_x_2413)) {
    case TAG_VU: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_2437 = heff_dup(heff_field(v_x_2413, 0));
      switch (heff_tag_of(v_h_2437)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2437, 0ULL, 1);
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2437, 0ULL, 1);
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2437, 0ULL, 1);
        v_t_2457 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2457 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2437);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
  }
  if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
    heff_drop(v_g_240);
    heff_drop(v_t_2457);
    V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam4_clo)})});
    V v_t_2460 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2459}));
    V f_ = heff_dup(heff_rfield(v_hd_244, 1));
    heff_room[0] = v_t_2460;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam5, 1, 5, (V[]){v_cs_241, v_x_249, v_hd_244, v_x_2413, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2457);
    V v_t_2492;
    switch (heff_tag_of(v_x_249)) {
    case TAG_VU: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2472 = heff_dup(heff_field(v_x_249, 0));
      V v_sp_2473 = heff_dup(heff_field(v_x_249, 1));
      switch (heff_tag_of(v_t1_2472)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2472, 0ULL, 1);
        heff_drop(v_sp_2473);
        v_t_2492 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2472, 0ULL, 1);
        heff_drop(v_sp_2473);
        v_t_2492 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2479 = heff_field(v_t1_2472, 0);
        V v_ru_24t1_2472_24HMeta = heff_take_reuse_n(v_t1_2472, 1ULL, 1);
        v_t_2492 = heff_tag_at_n(v_ru_24t1_2472_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2479, v_sp_2473})});
        break;
      }
      case TAG_HError: {
        heff_drop(v_sp_2473);
        v_t_2492 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t1_2472);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VRecord: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFixed: {
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    switch (heff_tag_of(v_t_2492)) {
    case TAG_Nothing: {
      V v_t_24114;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        V v_t1_2494 = heff_dup(heff_field(v_x_2413, 0));
        V v_sp_2495 = heff_dup(heff_field(v_x_2413, 1));
        switch (heff_tag_of(v_t1_2494)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_2494, 0ULL, 1);
          heff_drop(v_sp_2495);
          v_t_24114 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_2494, 0ULL, 1);
          heff_drop(v_sp_2495);
          v_t_24114 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HMeta: {
          V v_m_24101 = heff_field(v_t1_2494, 0);
          V v_ru_24t1_2494_24HMeta = heff_take_reuse_n(v_t1_2494, 1ULL, 1);
          v_t_24114 = heff_tag_at_n(v_ru_24t1_2494_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24101, v_sp_2495})});
          break;
        }
        case TAG_HError: {
          heff_drop(v_sp_2495);
          v_t_24114 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t1_2494);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VRecord: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_t_24114 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      switch (heff_tag_of(v_t_24114)) {
      case TAG_Nothing: {
        return (g_heff_2eelab_2eunify_2euTyRigid_24s334045790x1826110208(v_g_240, v_cs_241, v_x_249, v_x_2413, v_hd_244, v_k_245));
      }
      case TAG_Just: {
        V v_it1_24115 = heff_field(v_t_24114, 0);
        V v_ru_24t_24114_24Just = heff_take_reuse_n(v_t_24114, 1ULL, 1);
        switch (heff_tag_of(v_it1_24115)) {
        case TAG_MkPair: {
          V v_m_24116 = heff_field(v_it1_24115, 0);
          V v_sp_24117 = heff_field(v_it1_24115, 1);
          heff_take_n(v_it1_24115, 3ULL, 2);
          V v_rhs_24136;
          switch (heff_tag_of(v_x_249)) {
          case TAG_VU: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VDecode: {
            V v_el_24123 = heff_field(v_x_249, 4);
            heff_take_n(v_x_249, 16ULL, 5);
            heff_drop_cell(v_ru_24t_24114_24Just, 1);
            v_rhs_24136 = heff_tr(heff_call(v_el_24123, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VRecord: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VSum: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimInt: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimFloat: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimString: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimRune: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimArray: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VFixed: {
            v_rhs_24136 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          default: heff_nomatch(v_x_249);
          }
          V v_self_24155;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_VU: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VDecode: {
            V v_el_24142 = heff_field(v_x_2413, 4);
            heff_take_n(v_x_2413, 16ULL, 5);
            v_self_24155 = heff_tr(heff_call(v_el_24142, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VRecord: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VSum: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimInt: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimFloat: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimString: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimRune: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimArray: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VFixed: {
            v_self_24155 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          return (g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319(v_g_240, v_cs_241, v_m_24116, v_sp_24117, v_rhs_24136, v_self_24155, v_hd_244, v_k_245));
        }
        default: return heff_nomatch(v_it1_24115);
        }
      }
      default: return heff_nomatch(v_t_24114);
      }
    }
    case TAG_Just: {
      V v_it1_24156 = heff_field(v_t_2492, 0);
      V v_ru_24t_2492_24Just = heff_take_reuse_n(v_t_2492, 1ULL, 1);
      switch (heff_tag_of(v_it1_24156)) {
      case TAG_MkPair: {
        V v_m_24157 = heff_field(v_it1_24156, 0);
        V v_sp_24158 = heff_field(v_it1_24156, 1);
        heff_take_n(v_it1_24156, 3ULL, 2);
        V v_rhs_24177;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VU: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VDecode: {
          V v_el_24164 = heff_field(v_x_2413, 4);
          heff_take_n(v_x_2413, 16ULL, 5);
          heff_drop_cell(v_ru_24t_2492_24Just, 1);
          v_rhs_24177 = heff_tr(heff_call(v_el_24164, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VRecord: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VSum: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimInt: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimFloat: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimString: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimRune: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimArray: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VFixed: {
          v_rhs_24177 = heff_tag_at_n(v_ru_24t_2492_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        V v_self_24196;
        switch (heff_tag_of(v_x_249)) {
        case TAG_VU: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VDecode: {
          V v_el_24183 = heff_field(v_x_249, 4);
          heff_take_n(v_x_249, 16ULL, 5);
          v_self_24196 = heff_tr(heff_call(v_el_24183, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VRecord: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VSum: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimInt: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimFloat: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimString: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimRune: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimArray: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VFixed: {
          v_self_24196 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        default: heff_nomatch(v_x_249);
        }
        return (g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319(v_g_240, v_cs_241, v_m_24157, v_sp_24158, v_rhs_24177, v_self_24196, v_hd_244, v_k_245));
      }
      default: return heff_nomatch(v_it1_24156);
      }
    }
    default: return heff_nomatch(v_t_2492);
    }
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_b0_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam2, 1, 1, (V[]){v_b0_243})})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005_lam3, 1, 5, (V[]){v_x_249, v_hd_244, v_cs_241, v_k_245, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2eforU_24s2039005770x132184836_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2eforU_24s2039005770x132184836_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eforU_24s2039005770x132184836_entry, 4, 0};

V g_heff_2eelab_2eunify_2eforU_24s2039005770x132184836(V v_x1_240, V v_f_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){heff_dup(v_x_244)}));
    return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2eelab_2eunify_2eforU_24s2039005770x132184836_lam0, 1, 4, (V[]){heff_dup(v_xs_245), v_f_241, v_z_242, v_z_243})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eforU_24s2039005770x132184836_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2eforU_24s2039005770x132184836(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2eforU_24s2039005770x132184836_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_xs_245 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_247);
  return ({ V a_0 = v_xs_245; V a_1 = v_f_241; V a_2 = v_z_242; V a_3 = v_z_243; V r_ = (g_heff_2eelab_2eunify_2eforU_24s2039005770x132184836(a_0, a_1, a_2, a_3)); heff_drop(v_xs_245); r_; });
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam3(V self, V *args); static Clo g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam3, 2, 0};
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam4, 2, 0};
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam5(V self, V *args); static Clo g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam5, 2, 0};
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam6(V self, V *args); static Clo g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam6, 2, 0};
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam13(V self, V *args); static Clo g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam13, 1, 0};
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam14(V self, V *args);
Clo g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_entry, 6, 0};

V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640(V v_g_240, V v_cs_241, V v_self_242, V v_a_243, V v_hd_244, V v_k_245) {
top: ;
  V v_k_2476 = heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam0, 1, 6, (V[]){v_g_240, heff_dup(v_a_243), heff_dup(v_hd_244), v_cs_241, v_self_242, v_k_245});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam13_clo)})});
  V v_t_2479 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2478}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_2479, heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam14, 1, 3, (V[]){v_a_243, v_k_2476, v_hd_244})});
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_t_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k2_2420 = args[1];
  V v_t_2421 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_call(heff_take_field(v_hd_2419, 2), 1, (V[]){v_t_2422}));
  V f_ = heff_get_n(v_hd_2419, 1, 3);
  args[0] = v_t_2423;
  args[1] = v_k2_2420;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam4(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k2_2427 = args[1];
  V v_t_2428 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_2426, 2), 1, (V[]){v_t_2429}));
  V f_ = heff_get_n(v_hd_2426, 1, 3);
  args[0] = v_t_2430;
  args[1] = v_k2_2427;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam5(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_t_2434 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_call(heff_take_field(v_hd_2432, 2), 1, (V[]){v_t_2435}));
  V f_ = heff_get_n(v_hd_2432, 1, 3);
  args[0] = v_t_2436;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam6(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k2_2438 = args[1];
  V v_t_2439 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tr(heff_call(heff_take_field(v_hd_2437, 2), 1, (V[]){v_t_2440}));
  V f_ = heff_get_n(v_hd_2437, 1, 3);
  args[0] = v_t_2441;
  args[1] = v_k2_2438;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam10(V self, V *args) {
  V v_c_2455 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2456 = ({ V b_0 = heff_get_n(v_c_2455, 3, 8); V a_1 = heff_get_n(v_a_243, 0, 4); HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2458 = v_t_2456.f[1];
    int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
    if ((v_tag_2457 == ((int64_t)0ULL))) {
      V v_e_2460 = v_field_2458;
      V v_t_2461 = heff_get_n(v_e_2460, 1, 6);
      switch (heff_tag_of(v_t_2461)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        heff_take_n(v_t_2461, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_t_2461);
      }
    } else {
      heff_drop(v_field_2458);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam12(V self, V *args) {
  V v_p_2466 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2469;
  switch (heff_tag_of(v_p_2466)) {
  case TAG_MkPair: {
    V v_x_2467 = heff_dup(heff_field(v_p_2466, 0));
    v_t_2469 = v_x_2467;
    break;
  }
  default: heff_nomatch(v_p_2466);
  }
  V v_t_2472;
  switch (heff_tag_of(v_p_2466)) {
  case TAG_MkPair: {
    V v_y_2471 = heff_field(v_p_2466, 1);
    heff_take_n(v_p_2466, 2ULL, 2);
    v_t_2472 = v_y_2471;
    break;
  }
  default: heff_nomatch(v_p_2466);
  }
  return (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s973240257x441859337_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1671832624x1519965671_get()), v_g_240, v_cs_241, v_t_2469, v_t_2472));
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam11(V self, V *args) {
  V v_x_2465 = args[0];
  V v_a_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_dup(v_x_2465) == NTAG(TAG_True))) {
    heff_drop(v_x_2465);
    return ({ V b_0 = heff_get_n(v_a_243, 3, 4); V a_1 = heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam12, 1, 2, (V[]){v_g_240, v_cs_241}); V a_2 = v_hd_244; V a_3 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2eforU_24s2039005770x132184836(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
  } else {
    heff_drop(v_x_2465);
    heff_drop_rec(v_a_243, 4);
    heff_drop(v_g_240);
    heff_drop(v_cs_241);
    V v_t_2473 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2474}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2475;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_a_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2454);
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam10, 1, 1, (V[]){heff_dup(v_a_243)})})});
  V v_t_2464 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2463}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2464;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam11, 1, 5, (V[]){v_a_243, v_g_240, v_cs_241, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam8(V self, V *args) {
  V v_x_2453 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_a_243 = heff_env(self)[2];
  V v_self_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2453);
  return (g_heff_2eelab_2eunify_2esolveF_24s1521823541x1344180319(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(heff_rfield(v_a_243, 0)), heff_dup(heff_rfield(v_a_243, 1)), heff_dup(heff_rfield(v_a_243, 2)), v_self_242, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam9, 1, 5, (V[]){v_a_243, v_hd_244, v_g_240, v_cs_241, v_k_245})));
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_a_243 = heff_env(self)[4];
  V v_self_242 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  HeffT2 v_t_2444 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_240), NTAG(TAG_N), v_x_248, NTAG(TAG_LNil)));
  {
    V v_field_2446 = v_t_2444.f[1];
    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
    V v_a_2452;
    if ((v_tag_2445 == ((int64_t)0ULL))) {
      V v_x_2448 = v_field_2446;
      v_a_2452 = v_x_2448;
    } else {
      if ((v_tag_2445 == ((int64_t)1ULL))) {
        V v_x11_2450 = v_field_2446;
        heff_drop(v_x11_2450);
        v_a_2452 = heff_abandon();
      } else {
        V v_x_2451 = v_field_2446;
        v_a_2452 = v_x_2451;
      }
    }
    return (g_heff_2eelab_2eunify_2euTypeF_24s1116798609x289167005(heff_dup(v_g_240), heff_dup(v_cs_241), v_a_2452, v_x_2443, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam8, 1, 6, (V[]){v_g_240, v_cs_241, v_a_243, v_self_242, v_hd_244, v_k_245})));
  }
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_a_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_self_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_249 = heff_dup(heff_rfield(v_a_243, 2));
  V v_c_2442;
  switch (heff_tag_of(v_t_249)) {
  case TAG_VNeu: {
    V v_ty_2412 = heff_field(v_t_249, 2);
    heff_take_n(v_t_249, 4ULL, 5);
    V v_t_2415 = heff_tr(heff_call(v_ty_2412, 1, (V[]){NTAG(TAG_MkUnit)}));
    v_c_2442 = heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam2, 2, 1, (V[]){v_t_2415});
    break;
  }
  case TAG_VCode: {
    heff_take_n(v_t_249, 0ULL, 1);
    v_c_2442 = ((V)&g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam3_clo);
    break;
  }
  case TAG_VLam: {
    heff_take_n(v_t_249, 0ULL, 2);
    v_c_2442 = ((V)&g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam4_clo);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_t_249, 0ULL, 1);
    v_c_2442 = ((V)&g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam5_clo);
    break;
  }
  case TAG_VOpaque: {
    v_c_2442 = ((V)&g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam6_clo);
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V f_ = v_c_2442;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam7, 1, 7, (V[]){v_g_240, v_x_248, v_cs_241, v_hd_244, v_a_243, v_self_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_self_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_247 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_take_field(v_x_246, 3), MK_INT(0LL), heff_dup(g_std_2emap_2eempty_get())});
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(heff_dup(v_g_240), heff_dup(heff_rfield(v_a_243, 0)), v_t_247, heff_get_n(v_x_246, 0, 6), heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam1, 1, 6, (V[]){v_a_243, v_hd_244, v_g_240, v_cs_241, v_self_242, v_k_245})));
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam13(V self, V *args) {
  V v_c_2477 = args[0];
  return heff_get_n(v_c_2477, 3, 8);
}
V g_heff_2eelab_2eunify_2eapproxRun_24s2002999749x295775640_lam14(V self, V *args) {
  V v_x_2480 = args[0];
  V v_a_243 = heff_env(self)[0];
  V v_k_2476 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2481 = ({ V a_0 = v_x_2480; V a_1 = heff_get_n(v_a_243, 0, 4); HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2480); r_; });
  {
    V v_field_2483 = v_t_2481.f[1];
    int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
    if ((v_tag_2482 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_244, 3);
      V v_e_2485 = v_field_2483;
      V f_ = v_k_2476;
      args[0] = v_e_2485;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2483);
      V v_t_2486 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2486})});
      V v_t_2488 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2487}));
      V f_ = heff_get_n(v_hd_244, 1, 3);
      heff_room[0] = v_t_2488;
      heff_room[1] = v_k_2476;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}