// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_Describe 2650
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SOpaque 44226
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9005
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_entries 787768015
#define LBL_keys 9783995
#define LBL_malg 9839318
#define LBL_meta 9843404
#define LBL_metas 305145640
#define LBL_pairs 307786995
#define LBL_prefix 967031229
#define LBL_rhs 322423
#define LBL_ty 10476
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_meta__prefix__rhs__pairs[] = {LBL_meta, LBL_prefix, LBL_rhs, LBL_pairs};
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
HeffT2 g_heff_2eelab_2eunify_2eapproxWith_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2eforU(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2eforU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eforU_clo;
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142(V, V, V, V);
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_clo;
HeffT2 g_heff_2eelab_2eunify_2epatStep_24cpr(V, V, V);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_clo;
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo;
V g_heff_2eelab_2eunify_2espineRev(V);
V g_heff_2eelab_2eunify_2espineRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2espineRev_clo;
V g_heff_2eelab_2eunify_2ezipL(V, V);
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_clo;
V g_heff_2eelab_2eunify_2ezonkTermF(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2ereplay(V, V);
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereplay_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);

HeffT2 g_heff_2eelab_2eunify_2epatStep_24cpr(V v_selfKey_240, V v_v_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_v_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_rest_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_v_241)) {
    case TAG_VNeu: {
      V v_v1_244 = heff_field(v_v_241, 0);
      V v_v2_245 = heff_field(v_v_241, 1);
      heff_take_n(v_v_241, 3ULL, 5);
      switch (heff_tag_of(v_v1_244)) {
      case TAG_HLocal: {
        V v_l_249 = heff_field(v_v1_244, 0);
        heff_take_n(v_v1_244, 1ULL, 1);
        switch (heff_tag_of(v_v2_245)) {
        case TAG_SpId: {
          V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24Just, TAG_PVar, 1, (V[]){v_l_249}), v_rest_243});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2410}});
        }
        case TAG_SpApp: {
          heff_take_n(v_v2_245, 0ULL, 2);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          heff_drop(v_l_249);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SpProj: {
          heff_take_n(v_v2_245, 0ULL, 2);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          heff_drop(v_l_249);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SpSpec: {
          heff_take_n(v_v2_245, 0ULL, 3);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          heff_drop(v_l_249);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_v2_245)}});
        }
      }
      case TAG_HGlobal: {
        V v_k_2418 = heff_field(v_v1_244, 0);
        heff_take_n(v_v1_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        switch (heff_tag_of(v_v2_245)) {
        case TAG_SpId: {
          switch (heff_tag_of(v_selfKey_240)) {
          case TAG_Nothing: {
            heff_drop(v_rest_243);
            heff_drop(v_k_2418);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_sk_2419 = heff_field(v_selfKey_240, 0);
            if (heff_strEq_c_lent(v_sk_2419, v_k_2418, 2)) {
              V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_PSelf), v_rest_243});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2420}});
            } else {
              heff_drop(v_rest_243);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_selfKey_240)}});
          }
        }
        case TAG_SpApp: {
          heff_take_n(v_v2_245, 0ULL, 2);
          heff_drop(v_rest_243);
          heff_drop(v_k_2418);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SpProj: {
          heff_take_n(v_v2_245, 0ULL, 2);
          heff_drop(v_rest_243);
          heff_drop(v_k_2418);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SpSpec: {
          heff_take_n(v_v2_245, 0ULL, 3);
          heff_drop(v_rest_243);
          heff_drop(v_k_2418);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_v2_245)}});
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_v1_244, 0ULL, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_v2_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HError: {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_v2_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_v1_244)}});
      }
    }
    case TAG_VCode: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VLam: {
      heff_take_n(v_v_241, 0ULL, 2);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VCons: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VOpaque: {
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_v_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2eelab_2eunify_2eforU_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2eforU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eforU_entry, 7, 0};

V g_heff_2eelab_2eunify_2eforU(V v_w_240, V v_ms_241, V v_uf_242, V v_x1_243, V v_f_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    heff_drop(v_f_244);
    heff_drop(v_z_245);
    return heff_tail(v_z_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x1_243, 0);
    V v_xs_248 = heff_field(v_x1_243, 1);
    V v_c_249 = heff_tr(heff_call(heff_dup(v_f_244), 1, (V[]){heff_dup(v_x_247)}));
    return heff_tail(v_c_249, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2eforU_lam0, 1, 7, (V[]){heff_dup(v_w_240), heff_dup(v_ms_241), heff_dup(v_uf_242), heff_dup(v_xs_248), v_f_244, v_z_245, v_z_246})});
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2eelab_2eunify_2eforU_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2eunify_2eforU(a0, a1, a2, a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2eunify_2eforU_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_w_240 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_uf_242 = heff_env(self)[2];
  V v_xs_248 = heff_env(self)[3];
  V v_f_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2410);
  return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_xs_248; V a_4 = v_f_244; V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2eelab_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_w_240); heff_drop(v_ms_241); heff_drop(v_uf_242); heff_drop(v_xs_248); r_; });
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2ezonkTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTypeF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  V v_el_243 = heff_take_field(v_r_240, 0);
  V v_ty_244 = heff_get_n(v_r_240, 1, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return v_t_242;
  }
  case TAG_SDecode: {
    V v_e_246 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SDecode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    heff_drop(v_ty_244);
    V v_t_247 = heff_tr(heff_call(v_el_243, 1, (V[]){v_e_246}));
    return heff_tag_at_n(v_ru_24t_242_24SDecode, TAG_SDecode, 1, (V[]){v_t_247});
  }
  case TAG_SFunction: {
    V v_level_248 = heff_field(v_t_242, 0);
    V v_dom_249 = heff_field(v_t_242, 1);
    V v_cod_2410 = heff_field(v_t_242, 2);
    V v_implicit_2411 = heff_field(v_t_242, 3);
    V v_dflt_2412 = heff_field(v_t_242, 4);
    V v_ru_24t_242_24SFunction = heff_take_reuse_n(v_t_242, 31ULL, 5);
    V v_t_2413 = heff_tr(heff_call(heff_dup(v_ty_244), 1, (V[]){v_dom_249}));
    V v_f_2414 = v_ty_244;
    V v_t_2420;
    switch (heff_tag_of(v_cod_2410)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_cod_2410, 0);
      V v_b_2416 = heff_field(v_cod_2410, 1);
      V v_ru_24cod_2410_24MkAbs = heff_take_reuse_n(v_cod_2410, 3ULL, 2);
      V v_t_2417 = heff_tr(heff_call(v_f_2414, 1, (V[]){v_b_2416}));
      v_t_2420 = heff_tag_at_n(v_ru_24cod_2410_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2415, v_t_2417});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2418 = heff_field(v_cod_2410, 0);
      V v_ru_24cod_2410_24AbsConst = heff_take_reuse_n(v_cod_2410, 1ULL, 1);
      V v_t_2419 = heff_tr(heff_call(v_f_2414, 1, (V[]){v_b_2418}));
      v_t_2420 = heff_tag_at_n(v_ru_24cod_2410_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_cod_2410);
    }
    V v_t_2423;
    switch (heff_tag_of(v_dflt_2412)) {
    case TAG_Nothing: {
      heff_drop(v_el_243);
      v_t_2423 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_d_2421 = heff_field(v_dflt_2412, 0);
      V v_ru_24dflt_2412_24Just = heff_take_reuse_n(v_dflt_2412, 1ULL, 1);
      V v_t_2422 = heff_tr(heff_call(v_el_243, 1, (V[]){v_d_2421}));
      v_t_2423 = heff_tag_at_n(v_ru_24dflt_2412_24Just, TAG_Just, 1, (V[]){v_t_2422});
      break;
    }
    default: heff_nomatch(v_dflt_2412);
    }
    return heff_tag_at_n(v_ru_24t_242_24SFunction, TAG_SFunction, 5, (V[]){v_level_248, v_t_2413, v_t_2420, v_implicit_2411, v_t_2423});
  }
  case TAG_SRecord: {
    V v_level_2424 = heff_field(v_t_242, 0);
    V v_ft_2425 = heff_field(v_t_242, 1);
    V v_ds_2426 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SRecord = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_keys_2427 = heff_take_field(v_ds_2426, 0);
    V v_byName_2428 = heff_take_field(v_ds_2426, 1);
    V v_values_2429 = heff_get_n(v_ds_2426, 2, 3);
    V v_keys_2430 = heff_take_field(v_ft_2425, 0);
    V v_byName_2431 = heff_take_field(v_ft_2425, 1);
    V v_values_2432 = heff_get_n(v_ft_2425, 2, 3);
    V v_xs_2433 = v_values_2432;
    V v_t_2436 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2433, 0), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam0, 1, 2, (V[]){v_xs_2433, v_ty_244}));
    V v_xs_2437 = v_values_2429;
    V v_t_2440 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2437, 0), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam1, 1, 2, (V[]){v_xs_2437, v_el_243}));
    return heff_tag_at_n(v_ru_24t_242_24SRecord, TAG_SRecord, 3, (V[]){v_level_2424, heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_2430, v_byName_2431, v_t_2436}), heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_2427, v_byName_2428, v_t_2440})});
  }
  case TAG_SSum: {
    V v_vs_2441 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SSum = heff_take_reuse_n(v_t_242, 1ULL, 1);
    heff_drop(v_el_243);
    V v_keys_2442 = heff_take_field(v_vs_2441, 0);
    V v_byName_2443 = heff_take_field(v_vs_2441, 1);
    V v_values_2444 = heff_get_n(v_vs_2441, 2, 3);
    V v_xs_2445 = v_values_2444;
    V v_t_2450 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2445, 0), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam2, 1, 2, (V[]){v_xs_2445, v_ty_244}));
    return heff_tag_at_n(v_ru_24t_242_24SSum, TAG_SSum, 1, (V[]){heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_2442, v_byName_2443, v_t_2450})});
  }
  case TAG_SIsTy: {
    V v_a_2451 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIsTy = heff_take_reuse_n(v_t_242, 1ULL, 1);
    heff_drop(v_el_243);
    V v_t_2452 = heff_tr(heff_call(v_ty_244, 1, (V[]){v_a_2451}));
    return heff_tag_at_n(v_ru_24t_242_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2452});
  }
  case TAG_SPrimInt: {
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return v_t_242;
  }
  case TAG_SPrimFloat: {
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return v_t_242;
  }
  case TAG_SPrimString: {
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return v_t_242;
  }
  case TAG_SPrimRune: {
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return v_t_242;
  }
  case TAG_SPrimArray: {
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return v_t_242;
  }
  case TAG_SFixed: {
    heff_drop(v_el_243);
    heff_drop(v_ty_244);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2eunify_2ezonkTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTypeF(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam0(V self, V *args) {
  V v_i_2434 = args[0];
  V v_xs_2433 = heff_env(self)[0];
  V v_ty_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2435 = heff_arrayIndex(v_xs_2433, v_i_2434);
  V f_ = v_ty_244;
  args[0] = v_t_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam1(V self, V *args) {
  V v_i_2438 = args[0];
  V v_xs_2437 = heff_env(self)[0];
  V v_el_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_arrayIndex(v_xs_2437, v_i_2438);
  V f_ = v_el_243;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam3(V self, V *args) {
  V v_i_2448 = args[0];
  V v_xs_2447 = heff_env(self)[0];
  V v_ty_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2449 = heff_arrayIndex(v_xs_2447, v_i_2448);
  V f_ = v_ty_244;
  args[0] = v_t_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam2(V self, V *args) {
  V v_i_2446 = args[0];
  V v_xs_2445 = heff_env(self)[0];
  V v_ty_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2447 = heff_arrayIndex(v_xs_2445, v_i_2446);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2447, 0), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam3, 1, 2, (V[]){v_xs_2447, v_ty_244}));
}
V g_heff_2eelab_2eunify_2ezonker_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2ezonker_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2ezonker_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonker_entry, 1, 0};

V g_heff_2eelab_2eunify_2ezonker(V v_mc_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2ezonker_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2ezonker_lam1, 1, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2ezonker(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2ezonker_lam0(V self, V *args) {
  V v_t_241 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2eelab_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_242; V a_1 = v_mc_240; V a_2 = v_t_241; V r_ = (g_heff_2eelab_2eunify_2ezonkTermF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2eunify_2ezonker_lam1(V self, V *args) {
  V v_t_243 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eelab_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_t_243; V r_ = (g_heff_2eelab_2eunify_2ezonkTypeF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}

HeffT2 g_heff_2eelab_2eunify_2eapproxWith_24cpr(V v_g_240, V v_m_241, V v_k_242, V v_metaArgs_243, V v_key_244, V v_rigidArgs_245) {
top: ;
  if ((heff_intLt_c_lent(v_k_242, MK_INT(1LL), 2) || ({ V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_rigidArgs_245)); int c_ = heff_intLt_c_lent(v_t_2420, v_k_242, 0); heff_drop(v_t_2420); c_; }))) {
    heff_drop_rec(v_g_240, 8);
    heff_drop(v_m_241);
    heff_drop(v_k_242);
    heff_drop(v_metaArgs_243);
    heff_drop(v_rigidArgs_245);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    V v_t_246 = (g_list_2edrop(heff_dup(v_k_242), v_metaArgs_243));
    V v_t_247 = (g_heff_2eelab_2eunify_2espineRev(v_t_246));
    HeffT2 v_t_248 = ({ V b_0 = heff_get_n(v_g_240, 1, 8); V a_1 = v_key_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2412;
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_e_2411 = v_field_2410;
        v_t_2412 = v_e_2411;
      } else {
        heff_drop(v_field_2410);
        v_t_2412 = heff_abandon();
      }
    }
    V v_t_2413 = (g_list_2edrop(heff_dup(v_k_242), v_rigidArgs_245));
    V v_t_2414 = (g_heff_2eelab_2eunify_2espineRev(v_t_2413));
    V v_t_2415 = ({ V a_0 = heff_get_n(v_t_2412, 2, 4); V a_1 = v_t_2414; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_t_2414); r_; });
    V v_t_2416 = (g_list_2etake(heff_dup(v_k_242), v_metaArgs_243));
    V v_t_2417 = (g_list_2etake(v_k_242, v_rigidArgs_245));
    V v_t_2418 = (g_heff_2eelab_2eunify_2ezipL(v_t_2416, v_t_2417));
    V v_f_2419 = heff_rec_n(4, shape_meta__prefix__rhs__pairs, (V[]){v_m_241, v_t_247, v_t_2415, v_t_2418});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2419}});
  }
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(V v_g_240, V v_m_241, V v_pr_242, V v_v0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam0, 1, 1, (V[]){v_v0_243})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam1, 1, 5, (V[]){v_pr_242, v_hd_244, v_g_240, v_m_241, v_k_245})});
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_v0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_v0_243; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2418 = (g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2417));
  V f_ = v_t_2418;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = (g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2421));
  V f_ = v_t_2422;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2429 = (g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2428));
  V f_ = v_t_2429;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SCode, 1, (V[]){v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam7(V self, V *args) {
  V v_x_2451 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SLam, 2, (V[]){v_x_2435, v_x_2451});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_fty_2432 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_body_2433 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2436 = heff_tr(heff_call(v_fty_2432, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2437 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2436)));
  V v_t_2449;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2440 = heff_field(v_t_2437, 1);
    heff_take_n(v_t_2437, 2ULL, 4);
    heff_drop(v_t_2436);
    v_t_2449 = v_dom_2440;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2437, 0ULL, 3);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeInt: {
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeFloat: {
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeString: {
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeRune: {
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_NoRules: {
    v_t_2449 = v_t_2436;
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V v_c_2450 = (g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171(v_g_240, v_m_241, v_pr_242, v_t_2449, v_body_2433));
  V f_ = v_c_2450;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam7, 1, 2, (V[]){v_k_245, v_x_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam11(V self, V *args) {
  V v_x_2466 = args[0];
  V v_k_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2465;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2466});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam10(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2463 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(v_g_240, v_m_241, v_pr_242, v_v_2463, v_hd_2464, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam11, 1, 1, (V[]){v_k_2465})));
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam12(V self, V *args) {
  V v_x_2468 = args[0];
  V v_k_2460 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2460;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2457, v_x_2468});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam9(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k_2460 = args[1];
  V v_x_2458 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_k_2457 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2467;
  switch (heff_tag_of(v_x_2458)) {
  case TAG_Nom: {
    V v_v_2461 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    v_t_2467 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2461}));
    break;
  }
  case TAG_Describe: {
    V v_v_2462 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    v_t_2467 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2462}));
    break;
  }
  case TAG_Become: {
    V v_v_2463 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    v_t_2467 = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam10, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2463});
    break;
  }
  default: heff_nomatch(v_x_2458);
  }
  V f_ = v_t_2467;
  args[0] = v_hd_2459;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam12, 1, 2, (V[]){v_k_2460, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam8(V self, V *args) {
  V v_p_2456 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2456)) {
  case TAG_MkPair: {
    V v_k_2457 = heff_field(v_p_2456, 0);
    V v_x_2458 = heff_field(v_p_2456, 1);
    heff_take_n(v_p_2456, 3ULL, 2);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam9, 2, 5, (V[]){v_x_2458, v_g_240, v_m_241, v_pr_242, v_k_2457});
  }
  default: return heff_nomatch(v_p_2456);
  }
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam13(V self, V *args) {
  V v_x_2470 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2471 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2470)));
  V v_t_2472 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2470));
  V v_t_2473 = (g_list_2emap_24s1173914895x100384474(v_x_2470));
  V v_t_2474 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2471), v_t_2472, heff_arrayFromList(v_t_2473)});
  V v_x_2475 = heff_tag_n(TAG_SCons, 1, (V[]){v_t_2474});
  V f_ = v_k_245;
  args[0] = v_x_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VNeu: {
    V v_it1_2410 = heff_field(v_x_249, 0);
    V v_sp_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_HLocal: {
      V v_c_2416 = (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2416;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HGlobal: {
      V v_c_2420 = (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2420;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam3, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HMeta: {
      V v_m_27_2423 = heff_field(v_it1_2410, 0);
      V v_ru_24it1_2410_24HMeta = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
      if (heff_intEq_c_lent(v_m_27_2423, v_m_241, 0)) {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2411);
        heff_drop(v_m_27_2423);
        V v_t_2424 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2425 = heff_tag_at_n(v_ru_24it1_2410_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2425}));
        V f_ = heff_get_n(v_hd_244, 1, 3);
        heff_room[0] = v_t_2426;
        heff_room[1] = v_k_245;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_cell(v_ru_24it1_2410_24HMeta, 1);
        return (g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338(v_g_240, v_m_241, v_pr_242, v_m_27_2423, v_sp_2411, v_hd_244, v_k_245));
      }
    }
    case TAG_HError: {
      V v_c_2427 = (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2427;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  case TAG_VCode: {
    V v_t_2430 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(v_g_240, v_m_241, v_pr_242, v_t_2430, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam5, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VLam: {
    V v_fty_2432 = heff_field(v_x_249, 0);
    V v_body_2433 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_t_2434 = heff_tr(heff_call(heff_dup(v_fty_2432), 1, (V[]){NTAG(TAG_MkUnit)}));
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_t_2434, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam6, 1, 7, (V[]){v_fty_2432, v_g_240, v_m_241, v_pr_242, v_body_2433, v_hd_244, v_k_245})));
  }
  case TAG_VCons: {
    V v_d_2452 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_keys_2453 = heff_take_field(v_d_2452, 0);
    V v_values_2454 = heff_get_n(v_d_2452, 2, 3);
    V v_t_2455 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2453), heff_arrayToList(v_values_2454)));
    V v_c_2469 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam8, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2455));
    V f_ = v_c_2469;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam13, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VOpaque: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SOpaque);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_entry, 4, 0};

V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142(V v_x1_240, V v_f_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){heff_dup(v_x_244)}));
    return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_lam0, 1, 4, (V[]){heff_dup(v_xs_245), v_f_241, v_z_242, v_z_243})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_xs_245 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_247);
  return ({ V a_0 = v_xs_245; V a_1 = v_f_241; V a_2 = v_z_242; V a_3 = v_z_243; V r_ = (g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142(a_0, a_1, a_2, a_3)); heff_drop(v_xs_245); r_; });
}