// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2eabsOf_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2edk_get(void);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo;
V g_heff_2ebuild_2eserial_2etakeAlt(V, V, V);
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeAlt_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V, V);
V g_heff_2ebuild_2eserial_2etermOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_clo;
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_clo;
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    V v_t_246 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(v_lit_240, v_x_243));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, v_a_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str1, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str2, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str3, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str4, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str5, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str6, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str7, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str8, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str9, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str10, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str11, 1, "n");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str12, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str14, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str15, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str16, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str17, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str18, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str19, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str20, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str21, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str22, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str23, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str24, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str25, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str26, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str27, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str28, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str29, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str30, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str31, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str32, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str33, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str34, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str35, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str36, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str37, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str38, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str39, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str40, 2, "px");
Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V v_x2_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_x21_243 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_SmallU: {
      V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str0), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str1), v_rest_241})});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_244);
    }
    case TAG_LargeU: {
      V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str3), v_rest_241})});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_245);
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  case TAG_SDecode: {
    V v_e_246 = heff_field(v_x2_240, 0);
    V v_t_247 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_e_246), v_rest_241));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str4), v_t_247}));
  }
  case TAG_SFunction: {
    V v_level_248 = heff_field(v_x2_240, 0);
    V v_dom_249 = heff_field(v_x2_240, 1);
    V v_cod_2410 = heff_field(v_x2_240, 2);
    V v_implicit_2411 = heff_field(v_x2_240, 3);
    V v_dflt_2412 = heff_field(v_x2_240, 4);
    V v_t_2413;
    switch (heff_tag_of(v_level_248)) {
    case TAG_Small: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str5);
      break;
    }
    case TAG_Large: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str6);
      break;
    }
    case TAG_TopL: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str7);
      break;
    }
    default: heff_nomatch(v_level_248);
    }
    V v_t_2414;
    switch (heff_tag_of(v_implicit_2411)) {
    case TAG_Expl: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str8);
      break;
    }
    case TAG_Impl: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str9);
      break;
    }
    case TAG_Inst: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str10);
      break;
    }
    default: heff_nomatch(v_implicit_2411);
    }
    V v_t_2417;
    switch (heff_tag_of(v_dflt_2412)) {
    case TAG_Nothing: {
      v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str11), v_rest_241});
      break;
    }
    case TAG_Just: {
      V v_d_2415 = heff_field(v_dflt_2412, 0);
      V v_t_2416 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_d_2415), v_rest_241));
      v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str12), v_t_2416});
      break;
    }
    default: heff_nomatch(v_dflt_2412);
    }
    V v_rest_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2417});
    V v_rest_2426;
    switch (heff_tag_of(v_cod_2410)) {
    case TAG_MkAbs: {
      V v_x_2419 = heff_field(v_cod_2410, 0);
      V v_e_2420 = heff_field(v_cod_2410, 1);
      V v_t_2421 = heff_intShow(heff_strLength_lent(v_x_2419, 0));
      V v_t_2422 = heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str13), heff_dup(v_x_2419)));
      V v_t_2423 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2420, v_rest_2418));
      v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2423})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2424 = heff_field(v_cod_2410, 0);
      V v_t_2425 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2424, v_rest_2418));
      v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str15), v_t_2425});
      break;
    }
    default: heff_nomatch(v_cod_2410);
    }
    V v_t_2427 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_dom_249, v_rest_2426));
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2427})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2428);
  }
  case TAG_SRecord: {
    V v_level_2429 = heff_field(v_x2_240, 0);
    V v_fs_2430 = heff_field(v_x2_240, 1);
    V v_ds_2431 = heff_field(v_x2_240, 2);
    V v_t_2432;
    switch (heff_tag_of(v_level_2429)) {
    case TAG_Small: {
      v_t_2432 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str17);
      break;
    }
    case TAG_Large: {
      v_t_2432 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str18);
      break;
    }
    case TAG_TopL: {
      v_t_2432 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str19);
      break;
    }
    default: heff_nomatch(v_level_2429);
    }
    V v_t_2433 = heff_arrayToList(heff_dup(heff_rfield(v_ds_2431, 0)));
    V v_t_2434 = heff_arrayToList(heff_dup(heff_rfield(v_ds_2431, 2)));
    V v_xs_2435 = (g_heff_2eutil_2edict_2ezipKV(v_t_2433, v_t_2434));
    V v_i_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2435));
    V v_t_2437 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str20), v_xs_2435, v_rest_241));
    V v_rest_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2436), v_t_2437});
    V v_t_2439 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2430, 0)));
    V v_t_2440 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2430, 2)));
    V v_xs_2441 = (g_heff_2eutil_2edict_2ezipKV(v_t_2439, v_t_2440));
    V v_i_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2441));
    V v_t_2443 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str21), v_xs_2441, v_rest_2438));
    V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2442), v_t_2443});
    V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str22), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2444})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2445);
  }
  case TAG_SSum: {
    V v_vs_2446 = heff_field(v_x2_240, 0);
    V v_t_2447 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2446, 0)));
    V v_t_2448 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2446, 2)));
    V v_xs_2449 = (g_heff_2eutil_2edict_2ezipKV(v_t_2447, v_t_2448));
    V v_i_2450 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2449));
    V v_t_2451 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str23), MK_INT(1LL), MK_INT(0LL), v_xs_2449, v_rest_241));
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2450), v_t_2451});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str24), v_t_2452}));
  }
  case TAG_SIsTy: {
    V v_t2_2453 = heff_field(v_x2_240, 0);
    V v_cell_2454 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str25), heff_hole()});
    V v_u_2455 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2454));
    heff_drop(v_u_2455);
    V t_0 = v_t2_2453;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2454;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SPrimInt: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str26), v_rest_241}));
  }
  case TAG_SPrimFloat: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str27), v_rest_241}));
  }
  case TAG_SPrimString: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str28), v_rest_241}));
  }
  case TAG_SPrimRune: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str29), v_rest_241}));
  }
  case TAG_SPrimArray: {
    V v_t2_2456 = heff_field(v_x2_240, 0);
    V v_cell_2457 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str30), heff_hole()});
    V v_u_2458 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2457));
    heff_drop(v_u_2458);
    V t_0 = v_t2_2456;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2457;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SFixed: {
    V v_w_2459 = heff_field(v_x2_240, 0);
    V v_t_2460;
    switch (heff_tag_of(v_w_2459)) {
    case TAG_I8: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str31);
      break;
    }
    case TAG_I16: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str32);
      break;
    }
    case TAG_I32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str33);
      break;
    }
    case TAG_I64: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str34);
      break;
    }
    case TAG_U8: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str35);
      break;
    }
    case TAG_U16: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str36);
      break;
    }
    case TAG_U32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str37);
      break;
    }
    case TAG_U64: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str38);
      break;
    }
    case TAG_F32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str39);
      break;
    }
    default: heff_nomatch(v_w_2459);
    }
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2461);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_x_242), v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str1, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str2, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str3, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str4, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str5, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str6, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str7, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str8, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str9, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str10, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str11, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str12, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str13, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str14, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str15, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str16, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str17, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str18, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str19, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str20, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str23, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str24, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str25, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str26, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str27, 3, "f32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str28, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str29, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str31, 0, "");

HeffT2 g_heff_2ebuild_2eserial_2etermOf_24cpr(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 2);
    HeffT2 v_t_245 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2eint_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x31_249 = v_field_247;
        switch (heff_tag_of(v_x31_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x31_249, 0);
          V v_j_2411 = heff_field(v_x31_249, 1);
          V v_ru_24x31_249_24MkPair = heff_take_reuse_n(v_x31_249, 3ULL, 2);
          V v_t_2412 = heff_tag_at_n(v_ru_24x31_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_x_2410}), v_j_2411});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2412}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_249)}});
        }
      } else {
        heff_drop(v_field_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str1), 2)) {
      heff_drop_rec(v_k_240, 2);
      HeffT2 v_t_2414 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_x31_2418 = v_field_2416;
          switch (heff_tag_of(v_x31_2418)) {
          case TAG_MkPair: {
            V v_x_2419 = heff_field(v_x31_2418, 0);
            V v_j_2420 = heff_field(v_x31_2418, 1);
            V v_ru_24x31_2418_24MkPair = heff_take_reuse_n(v_x31_2418, 3ULL, 2);
            V v_t_2421 = heff_tag_at_n(v_ru_24x31_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2419}), v_j_2420});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2421}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2418)}});
          }
        } else {
          heff_drop(v_field_2416);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str2), 2)) {
        V v_x3_2423 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
        switch (heff_tag_of(v_x3_2423)) {
        case TAG_Nothing: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_x31_2424 = heff_field(v_x3_2423, 0);
          V v_ru_24x3_2423_24Just = heff_take_reuse_n(v_x3_2423, 1ULL, 1);
          switch (heff_tag_of(v_x31_2424)) {
          case TAG_MkPair: {
            V v_x_2425 = heff_field(v_x31_2424, 0);
            V v_j_2426 = heff_field(v_x31_2424, 1);
            V v_ru_24x31_2424_24MkPair = heff_take_reuse_n(v_x31_2424, 3ULL, 2);
            V v_t_2427 = heff_tag_at_n(v_ru_24x31_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2423_24Just, TAG_SCode, 1, (V[]){v_x_2425}), v_j_2426});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2427}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2424)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x3_2423)}});
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str3), 2)) {
          V v_x3_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
          switch (heff_tag_of(v_x3_2429)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_z_242);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2430 = heff_field(v_x3_2429, 0);
            heff_take_n(v_x3_2429, 1ULL, 1);
            switch (heff_tag_of(v_x31_2430)) {
            case TAG_MkPair: {
              V v_x_2431 = heff_field(v_x31_2430, 0);
              V v_j_2432 = heff_field(v_x31_2430, 1);
              V v_ru_24x31_2430_24MkPair = heff_take_reuse_n(v_x31_2430, 3ULL, 2);
              V v_x3_2433 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_2432}));
              switch (heff_tag_of(v_x3_2433)) {
              case TAG_Nothing: {
                heff_drop(v_x_2431);
                heff_drop_cell(v_ru_24x31_2430_24MkPair, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2434 = heff_field(v_x3_2433, 0);
                heff_take_n(v_x3_2433, 1ULL, 1);
                switch (heff_tag_of(v_x31_2434)) {
                case TAG_MkPair: {
                  V v_x_2435 = heff_field(v_x31_2434, 0);
                  V v_j_2436 = heff_field(v_x31_2434, 1);
                  heff_take_n(v_x31_2434, 3ULL, 2);
                  V v_t_2437 = heff_tag_at_n(v_ru_24x31_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_x_2431, v_x_2435}), v_j_2436});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2437}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2434)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2433)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2430)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x3_2429)}});
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str4), 2)) {
            V v_x3_2439 = heff_tr(heff_call(heff_take_field(v_k_240, 1), 2, (V[]){heff_dup(v_z_242), v_z_243}));
            switch (heff_tag_of(v_x3_2439)) {
            case TAG_Nothing: {
              heff_drop_rec(v_k_240, 2);
              heff_drop(v_z_242);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Just: {
              V v_x31_2440 = heff_field(v_x3_2439, 0);
              heff_take_n(v_x3_2439, 1ULL, 1);
              switch (heff_tag_of(v_x31_2440)) {
              case TAG_MkPair: {
                V v_x_2441 = heff_field(v_x31_2440, 0);
                V v_j_2442 = heff_field(v_x31_2440, 1);
                V v_ru_24x31_2440_24MkPair = heff_take_reuse_n(v_x31_2440, 3ULL, 2);
                HeffT2 v_t_2443 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_242, v_j_2442));
                {
                  V v_field_2445 = v_t_2443.f[1];
                  int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
                  if ((v_tag_2444 == ((int64_t)0ULL))) {
                    V v_x31_2447 = v_field_2445;
                    switch (heff_tag_of(v_x31_2447)) {
                    case TAG_MkPair: {
                      V v_x_2448 = heff_field(v_x31_2447, 0);
                      V v_j_2449 = heff_field(v_x31_2447, 1);
                      heff_take_n(v_x31_2447, 3ULL, 2);
                      HeffT2 v_t_2450 = ({ V a_0 = heff_get_n(v_k_240, 0, 2); V a_1 = v_x_2448; V a_2 = v_z_242; V a_3 = v_j_2449; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2448); r_; });
                      {
                        V v_field_2452 = v_t_2450.f[1];
                        int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
                        if ((v_tag_2451 == ((int64_t)0ULL))) {
                          V v_x31_2454 = v_field_2452;
                          switch (heff_tag_of(v_x31_2454)) {
                          case TAG_MkPair: {
                            V v_x_2455 = heff_field(v_x31_2454, 0);
                            V v_j_2456 = heff_field(v_x31_2454, 1);
                            heff_take_n(v_x31_2454, 3ULL, 2);
                            V v_t_2457 = heff_tag_at_n(v_ru_24x31_2440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_x_2441, v_x_2455}), v_j_2456});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2457}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2454)}});
                          }
                        } else {
                          heff_drop(v_x_2441);
                          heff_drop_cell(v_ru_24x31_2440_24MkPair, 2);
                          heff_drop(v_field_2452);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2447)}});
                    }
                  } else {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    heff_drop(v_x_2441);
                    heff_drop_cell(v_ru_24x31_2440_24MkPair, 2);
                    heff_drop(v_field_2445);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2440)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x3_2439)}});
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str5), 2)) {
              HeffT2 v_t_2459 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_get_n(v_k_240, 0, 2), v_z_242, v_z_243));
              {
                V v_field_2461 = v_t_2459.f[1];
                int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
                if ((v_tag_2460 == ((int64_t)0ULL))) {
                  V v_x31_2463 = v_field_2461;
                  switch (heff_tag_of(v_x31_2463)) {
                  case TAG_MkPair: {
                    V v_x_2464 = heff_field(v_x31_2463, 0);
                    V v_j_2465 = heff_field(v_x31_2463, 1);
                    V v_ru_24x31_2463_24MkPair = heff_take_reuse_n(v_x31_2463, 3ULL, 2);
                    V v_t_2466 = heff_tag_at_n(v_ru_24x31_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCons, 1, (V[]){v_x_2464}), v_j_2465});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2466}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2463)}});
                  }
                } else {
                  heff_drop(v_field_2461);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str6), 2)) {
                V v_x3_2468 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                switch (heff_tag_of(v_x3_2468)) {
                case TAG_Nothing: {
                  heff_drop(v_z_242);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_2469 = heff_field(v_x3_2468, 0);
                  heff_take_n(v_x3_2468, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2469)) {
                  case TAG_MkPair: {
                    V v_x_2470 = heff_field(v_x31_2469, 0);
                    V v_j_2471 = heff_field(v_x31_2469, 1);
                    V v_ru_24x31_2469_24MkPair = heff_take_reuse_n(v_x31_2469, 3ULL, 2);
                    HeffT2 v_t_2472 = ({ V a_0 = v_z_242; V a_1 = v_j_2471; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                    {
                      V v_field_2474 = v_t_2472.f[1];
                      int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
                      if ((v_tag_2473 == ((int64_t)0ULL))) {
                        V v_x31_2476 = v_field_2474;
                        switch (heff_tag_of(v_x31_2476)) {
                        case TAG_MkPair: {
                          V v_x_2477 = heff_field(v_x31_2476, 0);
                          V v_j_2478 = heff_field(v_x31_2476, 1);
                          heff_take_n(v_x31_2476, 3ULL, 2);
                          V v_t_2479 = heff_tag_at_n(v_ru_24x31_2469_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_x_2470, v_x_2477}), v_j_2478});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2479}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2476)}});
                        }
                      } else {
                        heff_drop(v_x_2470);
                        heff_drop_cell(v_ru_24x31_2469_24MkPair, 2);
                        heff_drop(v_field_2474);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2469)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x3_2468)}});
                }
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str7), 2)) {
                  HeffT2 v_t_2481 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                  {
                    V v_field_2483 = v_t_2481.f[1];
                    int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
                    if ((v_tag_2482 == ((int64_t)0ULL))) {
                      V v_x31_2485 = v_field_2483;
                      switch (heff_tag_of(v_x31_2485)) {
                      case TAG_MkPair: {
                        V v_x_2486 = heff_field(v_x31_2485, 0);
                        V v_j_2487 = heff_field(v_x31_2485, 1);
                        V v_ru_24x31_2485_24MkPair = heff_take_reuse_n(v_x31_2485, 3ULL, 2);
                        HeffT2 v_t_2488 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_2487));
                        {
                          V v_field_2490 = v_t_2488.f[1];
                          int64_t v_tag_2489 = ((int64_t)v_t_2488.f[0]);
                          if ((v_tag_2489 == ((int64_t)0ULL))) {
                            V v_x31_2492 = v_field_2490;
                            switch (heff_tag_of(v_x31_2492)) {
                            case TAG_MkPair: {
                              V v_x_2493 = heff_field(v_x31_2492, 0);
                              V v_j_2494 = heff_field(v_x31_2492, 1);
                              V v_ru_24x31_2492_24MkPair = heff_take_reuse_n(v_x31_2492, 3ULL, 2);
                              HeffT2 v_t_2495 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(heff_get_n(v_k_240, 0, 2), v_x_2493, v_z_242, v_j_2494));
                              {
                                V v_field_2497 = v_t_2495.f[1];
                                int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
                                if ((v_tag_2496 == ((int64_t)0ULL))) {
                                  V v_x31_2499 = v_field_2497;
                                  switch (heff_tag_of(v_x31_2499)) {
                                  case TAG_MkPair: {
                                    V v_x_24100 = heff_field(v_x31_2499, 0);
                                    V v_j_24101 = heff_field(v_x31_2499, 1);
                                    heff_take_n(v_x31_2499, 3ULL, 2);
                                    V v_t_24102 = heff_tag_at_n(v_ru_24x31_2492_24MkPair, TAG_STag, 2, (V[]){v_x_2486, heff_arrayFromList(v_x_24100)});
                                    V v_f_24103 = heff_tag_at_n(v_ru_24x31_2485_24MkPair, TAG_MkPair, 2, (V[]){v_t_24102, v_j_24101});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24103}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_2499)}});
                                  }
                                } else {
                                  heff_drop(v_x_2486);
                                  heff_drop_cell(v_ru_24x31_2485_24MkPair, 2);
                                  heff_drop_cell(v_ru_24x31_2492_24MkPair, 2);
                                  heff_drop(v_field_2497);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2492)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_z_242);
                            heff_drop(v_x_2486);
                            heff_drop_cell(v_ru_24x31_2485_24MkPair, 2);
                            heff_drop(v_field_2490);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2485)}});
                      }
                    } else {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      heff_drop(v_field_2483);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str8), 2)) {
                    V v_x3_24105 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                    switch (heff_tag_of(v_x3_24105)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_24106 = heff_field(v_x3_24105, 0);
                      heff_take_n(v_x3_24105, 1ULL, 1);
                      switch (heff_tag_of(v_x31_24106)) {
                      case TAG_MkPair: {
                        V v_x_24107 = heff_field(v_x31_24106, 0);
                        V v_j_24108 = heff_field(v_x31_24106, 1);
                        V v_ru_24x31_24106_24MkPair = heff_take_reuse_n(v_x31_24106, 3ULL, 2);
                        V v_t_24109 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2etakeAlt_clo), 1, (V[]){v_k_240}));
                        HeffT2 v_t_24110 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(v_t_24109, v_z_242, v_j_24108));
                        {
                          V v_field_24112 = v_t_24110.f[1];
                          int64_t v_tag_24111 = ((int64_t)v_t_24110.f[0]);
                          if ((v_tag_24111 == ((int64_t)0ULL))) {
                            V v_x31_24114 = v_field_24112;
                            switch (heff_tag_of(v_x31_24114)) {
                            case TAG_MkPair: {
                              V v_x_24115 = heff_field(v_x31_24114, 0);
                              V v_j_24116 = heff_field(v_x31_24114, 1);
                              heff_take_n(v_x31_24114, 3ULL, 2);
                              V v_t_24117 = heff_tag_at_n(v_ru_24x31_24106_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SMatch, 2, (V[]){v_x_24107, v_x_24115}), v_j_24116});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24117}});
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24114)}});
                            }
                          } else {
                            heff_drop(v_x_24107);
                            heff_drop_cell(v_ru_24x31_24106_24MkPair, 2);
                            heff_drop(v_field_24112);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_24106)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x3_24105)}});
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str9), 2)) {
                      V v_x3_24119 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                      switch (heff_tag_of(v_x3_24119)) {
                      case TAG_Nothing: {
                        heff_drop_rec(v_k_240, 2);
                        heff_drop(v_z_242);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Just: {
                        V v_x31_24120 = heff_field(v_x3_24119, 0);
                        heff_take_n(v_x3_24119, 1ULL, 1);
                        switch (heff_tag_of(v_x31_24120)) {
                        case TAG_MkPair: {
                          V v_x_24121 = heff_field(v_x31_24120, 0);
                          V v_j_24122 = heff_field(v_x31_24120, 1);
                          V v_ru_24x31_24120_24MkPair = heff_take_reuse_n(v_x31_24120, 3ULL, 2);
                          HeffT2 v_t_24123 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_24122));
                          {
                            V v_field_24125 = v_t_24123.f[1];
                            int64_t v_tag_24124 = ((int64_t)v_t_24123.f[0]);
                            if ((v_tag_24124 == ((int64_t)0ULL))) {
                              V v_x31_24127 = v_field_24125;
                              switch (heff_tag_of(v_x31_24127)) {
                              case TAG_MkPair: {
                                V v_x_24128 = heff_field(v_x31_24127, 0);
                                V v_j_24129 = heff_field(v_x31_24127, 1);
                                heff_take_n(v_x31_24127, 3ULL, 2);
                                V v_x3_24130 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_24129}));
                                switch (heff_tag_of(v_x3_24130)) {
                                case TAG_Nothing: {
                                  heff_drop(v_x_24121);
                                  heff_drop_cell(v_ru_24x31_24120_24MkPair, 2);
                                  heff_drop(v_x_24128);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24131 = heff_field(v_x3_24130, 0);
                                  heff_take_n(v_x3_24130, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24131)) {
                                  case TAG_MkPair: {
                                    V v_x_24132 = heff_field(v_x31_24131, 0);
                                    V v_j_24133 = heff_field(v_x31_24131, 1);
                                    heff_take_n(v_x31_24131, 3ULL, 2);
                                    V v_t_24134 = heff_tag_at_n(v_ru_24x31_24120_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_24121, v_x_24128, v_x_24132}), v_j_24133});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24134}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24131)}});
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x3_24130)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24127)}});
                              }
                            } else {
                              heff_drop_rec(v_k_240, 2);
                              heff_drop(v_z_242);
                              heff_drop(v_x_24121);
                              heff_drop_cell(v_ru_24x31_24120_24MkPair, 2);
                              heff_drop(v_field_24125);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_24120)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x3_24119)}});
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str10), 2)) {
                        V v_x3_24136 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
                        switch (heff_tag_of(v_x3_24136)) {
                        case TAG_Nothing: {
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_Just: {
                          V v_x31_24137 = heff_field(v_x3_24136, 0);
                          V v_ru_24x3_24136_24Just = heff_take_reuse_n(v_x3_24136, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24137)) {
                          case TAG_MkPair: {
                            V v_x_24138 = heff_field(v_x31_24137, 0);
                            V v_j_24139 = heff_field(v_x31_24137, 1);
                            V v_ru_24x31_24137_24MkPair = heff_take_reuse_n(v_x31_24137, 3ULL, 2);
                            V v_t_24140 = heff_tag_at_n(v_ru_24x31_24137_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24136_24Just, TAG_SIs, 1, (V[]){v_x_24138}), v_j_24139});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24140}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_24137)}});
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x3_24136)}});
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str11), 2)) {
                          heff_drop_rec(v_k_240, 2);
                          heff_drop(v_z_242);
                          V v_t_24142 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SOpaque), v_z_243});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24142}});
                        } else {
                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str12), 2)) {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_z_242);
                            V v_t_24144 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SAbandon), v_z_243});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24144}});
                          } else {
                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str13), 2)) {
                              V v_x3_24146 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
                              switch (heff_tag_of(v_x3_24146)) {
                              case TAG_Nothing: {
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_24147 = heff_field(v_x3_24146, 0);
                                V v_ru_24x3_24146_24Just = heff_take_reuse_n(v_x3_24146, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24147)) {
                                case TAG_MkPair: {
                                  V v_x_24148 = heff_field(v_x31_24147, 0);
                                  V v_j_24149 = heff_field(v_x31_24147, 1);
                                  V v_ru_24x31_24147_24MkPair = heff_take_reuse_n(v_x31_24147, 3ULL, 2);
                                  V v_t_24150 = heff_tag_at_n(v_ru_24x31_24147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24146_24Just, TAG_SRec, 1, (V[]){v_x_24148}), v_j_24149});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24150}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24147)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x3_24146)}});
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str14), 2)) {
                                V v_x3_24152 = heff_tr(heff_call(heff_take_field(v_k_240, 1), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                                switch (heff_tag_of(v_x3_24152)) {
                                case TAG_Nothing: {
                                  heff_drop_rec(v_k_240, 2);
                                  heff_drop(v_z_242);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24153 = heff_field(v_x3_24152, 0);
                                  heff_take_n(v_x3_24152, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24153)) {
                                  case TAG_MkPair: {
                                    V v_x_24154 = heff_field(v_x31_24153, 0);
                                    V v_j_24155 = heff_field(v_x31_24153, 1);
                                    V v_ru_24x31_24153_24MkPair = heff_take_reuse_n(v_x31_24153, 3ULL, 2);
                                    HeffT2 v_t_24156 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_242, v_j_24155));
                                    {
                                      V v_field_24158 = v_t_24156.f[1];
                                      int64_t v_tag_24157 = ((int64_t)v_t_24156.f[0]);
                                      if ((v_tag_24157 == ((int64_t)0ULL))) {
                                        V v_x31_24160 = v_field_24158;
                                        switch (heff_tag_of(v_x31_24160)) {
                                        case TAG_MkPair: {
                                          V v_x_24161 = heff_field(v_x31_24160, 0);
                                          V v_j_24162 = heff_field(v_x31_24160, 1);
                                          heff_take_n(v_x31_24160, 3ULL, 2);
                                          HeffT2 v_t_24163 = ({ V a_0 = heff_get_n(v_k_240, 0, 2); V a_1 = v_x_24161; V a_2 = v_z_242; V a_3 = v_j_24162; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_24161); r_; });
                                          {
                                            V v_field_24165 = v_t_24163.f[1];
                                            int64_t v_tag_24164 = ((int64_t)v_t_24163.f[0]);
                                            if ((v_tag_24164 == ((int64_t)0ULL))) {
                                              V v_x31_24167 = v_field_24165;
                                              switch (heff_tag_of(v_x31_24167)) {
                                              case TAG_MkPair: {
                                                V v_x_24168 = heff_field(v_x31_24167, 0);
                                                V v_j_24169 = heff_field(v_x31_24167, 1);
                                                heff_take_n(v_x31_24167, 3ULL, 2);
                                                V v_t_24170 = heff_tag_at_n(v_ru_24x31_24153_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFix, 2, (V[]){v_x_24154, v_x_24168}), v_j_24169});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24170}});
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24167)}});
                                              }
                                            } else {
                                              heff_drop(v_x_24154);
                                              heff_drop_cell(v_ru_24x31_24153_24MkPair, 2);
                                              heff_drop(v_field_24165);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24160)}});
                                        }
                                      } else {
                                        heff_drop_rec(v_k_240, 2);
                                        heff_drop(v_z_242);
                                        heff_drop(v_x_24154);
                                        heff_drop_cell(v_ru_24x31_24153_24MkPair, 2);
                                        heff_drop(v_field_24158);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24153)}});
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x3_24152)}});
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str15), 2)) {
                                  HeffT2 v_t_24172 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                  {
                                    V v_field_24174 = v_t_24172.f[1];
                                    int64_t v_tag_24173 = ((int64_t)v_t_24172.f[0]);
                                    if ((v_tag_24173 == ((int64_t)0ULL))) {
                                      V v_x31_24176 = v_field_24174;
                                      switch (heff_tag_of(v_x31_24176)) {
                                      case TAG_MkPair: {
                                        V v_x_24177 = heff_field(v_x31_24176, 0);
                                        V v_j_24178 = heff_field(v_x31_24176, 1);
                                        V v_ru_24x31_24176_24MkPair = heff_take_reuse_n(v_x31_24176, 3ULL, 2);
                                        V v_x3_24179 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_24178}));
                                        switch (heff_tag_of(v_x3_24179)) {
                                        case TAG_Nothing: {
                                          heff_drop(v_x_24177);
                                          heff_drop_cell(v_ru_24x31_24176_24MkPair, 2);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                        case TAG_Just: {
                                          V v_x31_24180 = heff_field(v_x3_24179, 0);
                                          heff_take_n(v_x3_24179, 1ULL, 1);
                                          switch (heff_tag_of(v_x31_24180)) {
                                          case TAG_MkPair: {
                                            V v_x_24181 = heff_field(v_x31_24180, 0);
                                            V v_j_24182 = heff_field(v_x31_24180, 1);
                                            heff_take_n(v_x31_24180, 3ULL, 2);
                                            V v_t_24183 = heff_tag_at_n(v_ru_24x31_24176_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SImplicit, 2, (V[]){v_x_24177, v_x_24181}), v_j_24182});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24183}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24180)}});
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x3_24179)}});
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24176)}});
                                      }
                                    } else {
                                      heff_drop_rec(v_k_240, 2);
                                      heff_drop(v_z_242);
                                      heff_drop(v_field_24174);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop_rec(v_k_240, 2);
                                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str16), 2)) {
                                    HeffT2 v_t_24185 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                    {
                                      V v_field_24187 = v_t_24185.f[1];
                                      int64_t v_tag_24186 = ((int64_t)v_t_24185.f[0]);
                                      if ((v_tag_24186 == ((int64_t)0ULL))) {
                                        V v_x31_24189 = v_field_24187;
                                        switch (heff_tag_of(v_x31_24189)) {
                                        case TAG_MkPair: {
                                          V v_x_24190 = heff_field(v_x31_24189, 0);
                                          V v_j_24191 = heff_field(v_x31_24189, 1);
                                          V v_ru_24x31_24189_24MkPair = heff_take_reuse_n(v_x31_24189, 3ULL, 2);
                                          V v_t_24192 = heff_tag_at_n(v_ru_24x31_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_24190}), v_j_24191});
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24192}});
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24189)}});
                                        }
                                      } else {
                                        heff_drop(v_field_24187);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str17), 2)) {
                                      HeffT2 v_t_24194 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                      {
                                        V v_field_24196 = v_t_24194.f[1];
                                        int64_t v_tag_24195 = ((int64_t)v_t_24194.f[0]);
                                        if ((v_tag_24195 == ((int64_t)0ULL))) {
                                          V v_x31_24198 = v_field_24196;
                                          switch (heff_tag_of(v_x31_24198)) {
                                          case TAG_MkPair: {
                                            V v_x_24199 = heff_field(v_x31_24198, 0);
                                            V v_j_24200 = heff_field(v_x31_24198, 1);
                                            V v_ru_24x31_24198_24MkPair = heff_take_reuse_n(v_x31_24198, 3ULL, 2);
                                            V v_t_24201 = ({ V a_0 = v_x_24199; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24199); r_; });
                                            V v_x_24202 = heff_tag_n(TAG_SLitInt, 1, (V[]){v_t_24201});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24198_24MkPair, TAG_MkPair, 2, (V[]){v_x_24202, v_j_24200})}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24198)}});
                                          }
                                        } else {
                                          heff_drop(v_field_24196);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str18), 2)) {
                                        HeffT2 v_t_24204 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                        {
                                          V v_field_24206 = v_t_24204.f[1];
                                          int64_t v_tag_24205 = ((int64_t)v_t_24204.f[0]);
                                          if ((v_tag_24205 == ((int64_t)0ULL))) {
                                            V v_x31_24208 = v_field_24206;
                                            switch (heff_tag_of(v_x31_24208)) {
                                            case TAG_MkPair: {
                                              V v_x_24209 = heff_field(v_x31_24208, 0);
                                              V v_j_24210 = heff_field(v_x31_24208, 1);
                                              V v_ru_24x31_24208_24MkPair = heff_take_reuse_n(v_x31_24208, 3ULL, 2);
                                              V v_x2_24211 = ({ V b_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str19); V a_1 = v_x_24209; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str20), v_x_24209, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_x_24209); r_; });
                                              V v_t_24214;
                                              switch (heff_tag_of(v_x2_24211)) {
                                              case TAG_Nil: {
                                                v_t_24214 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str21);
                                                break;
                                              }
                                              case TAG_Cons: {
                                                V v_x_24212 = heff_field(v_x2_24211, 0);
                                                V v_xs_24213 = heff_field(v_x2_24211, 1);
                                                heff_take_n(v_x2_24211, 3ULL, 2);
                                                v_t_24214 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str22); V a_1 = v_x_24212; V a_2 = v_xs_24213; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24213); r_; });
                                                break;
                                              }
                                              default: heff_nomatch(v_x2_24211);
                                              }
                                              double v_t_24215 = ({ V a_0 = v_t_24214; double r_ = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(a_0)); heff_drop(v_t_24214); r_; });
                                              V v_x_24216 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_t_24215)});
                                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24208_24MkPair, TAG_MkPair, 2, (V[]){v_x_24216, v_j_24210})}});
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24208)}});
                                            }
                                          } else {
                                            heff_drop(v_field_24206);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      } else {
                                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str23), 2)) {
                                          HeffT2 v_t_24218 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                          {
                                            V v_field_24220 = v_t_24218.f[1];
                                            int64_t v_tag_24219 = ((int64_t)v_t_24218.f[0]);
                                            if ((v_tag_24219 == ((int64_t)0ULL))) {
                                              V v_x31_24222 = v_field_24220;
                                              switch (heff_tag_of(v_x31_24222)) {
                                              case TAG_MkPair: {
                                                V v_x_24223 = heff_field(v_x31_24222, 0);
                                                V v_j_24224 = heff_field(v_x31_24222, 1);
                                                V v_ru_24x31_24222_24MkPair = heff_take_reuse_n(v_x31_24222, 3ULL, 2);
                                                V v_t_24225 = heff_tag_at_n(v_ru_24x31_24222_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_x_24223}), v_j_24224});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24225}});
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24222)}});
                                              }
                                            } else {
                                              heff_drop(v_field_24220);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str24), 2)) {
                                            HeffT2 v_t_24227 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                            {
                                              V v_field_24229 = v_t_24227.f[1];
                                              int64_t v_tag_24228 = ((int64_t)v_t_24227.f[0]);
                                              if ((v_tag_24228 == ((int64_t)0ULL))) {
                                                V v_x31_24231 = v_field_24229;
                                                switch (heff_tag_of(v_x31_24231)) {
                                                case TAG_MkPair: {
                                                  V v_x_24232 = heff_field(v_x31_24231, 0);
                                                  V v_j_24233 = heff_field(v_x31_24231, 1);
                                                  V v_ru_24x31_24231_24MkPair = heff_take_reuse_n(v_x31_24231, 3ULL, 2);
                                                  V v_t_24234 = heff_tag_at_n(v_ru_24x31_24231_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitBytes, 1, (V[]){v_x_24232}), v_j_24233});
                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24234}});
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24231)}});
                                                }
                                              } else {
                                                heff_drop(v_field_24229);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          } else {
                                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str25), 2)) {
                                              HeffT2 v_t_24236 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                              {
                                                V v_field_24238 = v_t_24236.f[1];
                                                int64_t v_tag_24237 = ((int64_t)v_t_24236.f[0]);
                                                if ((v_tag_24237 == ((int64_t)0ULL))) {
                                                  V v_x31_24240 = v_field_24238;
                                                  switch (heff_tag_of(v_x31_24240)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24241 = heff_field(v_x31_24240, 0);
                                                    V v_j_24242 = heff_field(v_x31_24240, 1);
                                                    V v_ru_24x31_24240_24MkPair = heff_take_reuse_n(v_x31_24240, 3ULL, 2);
                                                    V v_t_24243 = ({ V a_0 = v_x_24241; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24241); r_; });
                                                    V v_x_24244 = heff_tag_n(TAG_SLitRune, 1, (V[]){v_t_24243});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24240_24MkPair, TAG_MkPair, 2, (V[]){v_x_24244, v_j_24242})}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24240)}});
                                                  }
                                                } else {
                                                  heff_drop(v_field_24238);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str26), 2)) {
                                                HeffT2 v_t_24246 = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(v_z_242, v_z_243));
                                                {
                                                  V v_field_24248 = v_t_24246.f[1];
                                                  int64_t v_tag_24247 = ((int64_t)v_t_24246.f[0]);
                                                  if ((v_tag_24247 == ((int64_t)0ULL))) {
                                                    V v_x31_24250 = v_field_24248;
                                                    switch (heff_tag_of(v_x31_24250)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24251 = heff_field(v_x31_24250, 0);
                                                      V v_j_24252 = heff_field(v_x31_24250, 1);
                                                      V v_ru_24x31_24250_24MkPair = heff_take_reuse_n(v_x31_24250, 3ULL, 2);
                                                      HeffT2 v_t_24253 = ({ V a_0 = v_z_242; V a_1 = v_j_24252; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                                      {
                                                        V v_field_24255 = v_t_24253.f[1];
                                                        int64_t v_tag_24254 = ((int64_t)v_t_24253.f[0]);
                                                        if ((v_tag_24254 == ((int64_t)0ULL))) {
                                                          V v_x31_24257 = v_field_24255;
                                                          switch (heff_tag_of(v_x31_24257)) {
                                                          case TAG_MkPair: {
                                                            V v_x_24258 = heff_field(v_x31_24257, 0);
                                                            V v_j_24259 = heff_field(v_x31_24257, 1);
                                                            V v_ru_24x31_24257_24MkPair = heff_take_reuse_n(v_x31_24257, 3ULL, 2);
                                                            V v_t_24260 = ({ V a_0 = v_x_24258; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24258); r_; });
                                                            V v_x_24261 = heff_tag_at_n(v_ru_24x31_24257_24MkPair, TAG_SLitFixed, 2, (V[]){v_x_24251, v_t_24260});
                                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24250_24MkPair, TAG_MkPair, 2, (V[]){v_x_24261, v_j_24259})}});
                                                          }
                                                          default: return ((HeffT2){{heff_nomatch(v_x31_24257)}});
                                                          }
                                                        } else {
                                                          heff_drop(v_x_24251);
                                                          heff_drop_cell(v_ru_24x31_24250_24MkPair, 2);
                                                          heff_drop(v_field_24255);
                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                        }
                                                      }
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x31_24250)}});
                                                    }
                                                  } else {
                                                    heff_drop(v_z_242);
                                                    heff_drop(v_field_24248);
                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                  }
                                                }
                                              } else {
                                                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str27), 2)) {
                                                  HeffT2 v_t_24263 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                                  {
                                                    V v_field_24265 = v_t_24263.f[1];
                                                    int64_t v_tag_24264 = ((int64_t)v_t_24263.f[0]);
                                                    if ((v_tag_24264 == ((int64_t)0ULL))) {
                                                      V v_x31_24267 = v_field_24265;
                                                      switch (heff_tag_of(v_x31_24267)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24268 = heff_field(v_x31_24267, 0);
                                                        V v_j_24269 = heff_field(v_x31_24267, 1);
                                                        V v_ru_24x31_24267_24MkPair = heff_take_reuse_n(v_x31_24267, 3ULL, 2);
                                                        V v_x2_24270 = ({ V b_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str28); V a_1 = v_x_24268; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str29), v_x_24268, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_x_24268); r_; });
                                                        V v_t_24273;
                                                        switch (heff_tag_of(v_x2_24270)) {
                                                        case TAG_Nil: {
                                                          v_t_24273 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str30);
                                                          break;
                                                        }
                                                        case TAG_Cons: {
                                                          V v_x_24271 = heff_field(v_x2_24270, 0);
                                                          V v_xs_24272 = heff_field(v_x2_24270, 1);
                                                          heff_take_n(v_x2_24270, 3ULL, 2);
                                                          v_t_24273 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str31); V a_1 = v_x_24271; V a_2 = v_xs_24272; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24272); r_; });
                                                          break;
                                                        }
                                                        default: heff_nomatch(v_x2_24270);
                                                        }
                                                        double v_t_24274 = ({ V a_0 = v_t_24273; double r_ = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(a_0)); heff_drop(v_t_24273); r_; });
                                                        V v_x_24275 = heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24274)});
                                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24267_24MkPair, TAG_MkPair, 2, (V[]){v_x_24275, v_j_24269})}});
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_24267)}});
                                                      }
                                                    } else {
                                                      heff_drop(v_field_24265);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                  }
                                                } else {
                                                  return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2eserial_2edk_lam0(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edk_lam0, 2, 0};
V g_heff_2ebuild_2eserial_2edk_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edk_lam1, 2, 0};

static V g_heff_2ebuild_2eserial_2edk_val;
static HEFF_ONCE g_heff_2ebuild_2eserial_2edk_st;
static V g_heff_2ebuild_2eserial_2edk_init(void) {
  return heff_rec_n(2, shape_el__ty, (V[]){((V)&g_heff_2ebuild_2eserial_2edk_lam0_clo), ((V)&g_heff_2ebuild_2eserial_2edk_lam1_clo)});
}
V g_heff_2ebuild_2eserial_2edk_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eserial_2edk_st)) return g_heff_2ebuild_2eserial_2edk_val;
  return heff_global(&g_heff_2ebuild_2eserial_2edk_val, &g_heff_2ebuild_2eserial_2edk_st, g_heff_2ebuild_2eserial_2edk_init);
}
V g_heff_2ebuild_2eserial_2edk_lam0(V self, V *args) {
  V v_s_240 = args[0];
  V v_i_241 = args[1];
  V v_k_242 = heff_dup(g_heff_2ebuild_2eserial_2edk_get());
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_247 = v_field_245;
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        heff_take_n(v_x31_247, 3ULL, 2);
        return ({ V a_0 = v_k_242; V a_1 = v_x_248; V a_2 = v_s_240; V a_3 = v_j_249; V r_ = (g_heff_2ebuild_2eserial_2etermOf(a_0, a_1, a_2, a_3)); heff_drop(v_x_248); r_; });
      }
      default: return heff_nomatch(v_x31_247);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_k_242);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2edk_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_i_2411 = args[1];
  V v_k_2412 = heff_dup(g_heff_2ebuild_2eserial_2edk_get());
  HeffT2 v_t_2413 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_2410, v_i_2411));
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_x31_2417 = v_field_2415;
      switch (heff_tag_of(v_x31_2417)) {
      case TAG_MkPair: {
        V v_x_2418 = heff_field(v_x31_2417, 0);
        V v_j_2419 = heff_field(v_x31_2417, 1);
        heff_take_n(v_x31_2417, 3ULL, 2);
        return ({ V a_0 = v_k_2412; V a_1 = v_x_2418; V a_2 = v_s_2410; V a_3 = v_j_2419; V r_ = (g_heff_2ebuild_2eserial_2etypeOf(a_0, a_1, a_2, a_3)); heff_drop(v_x_2418); r_; });
      }
      default: return heff_nomatch(v_x31_2417);
      }
    } else {
      heff_drop(v_s_2410);
      heff_drop(v_k_2412);
      heff_drop(v_field_2415);
      return NTAG(TAG_Nothing);
    }
  }
}

HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(v_x_247, v_s_240, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2413 = v_field_2411;
            switch (heff_tag_of(v_x31_2413)) {
            case TAG_MkPair: {
              V v_x_2414 = heff_field(v_x31_2413, 0);
              V v_j_2415 = heff_field(v_x31_2413, 1);
              heff_take_n(v_x31_2413, 3ULL, 2);
              V v_t_2416 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2414)));
              V v_t_2417 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2414));
              V v_t_2418 = (g_list_2emap_24s1173914895x100384474(v_x_2414));
              V v_x_2419 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2416), v_t_2417, heff_arrayFromList(v_t_2418)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2419, v_j_2415})}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
            }
          } else {
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str1, 1, "n");

HeffT2 g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str0), 2)) {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_248 = v_field_246;
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x31_248, 0);
          V v_j_2410 = heff_field(v_x31_248, 1);
          V v_ru_24x31_248_24MkPair = heff_take_reuse_n(v_x31_248, 3ULL, 2);
          HeffT2 v_t_2411 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_249, v_z_241, v_j_2410));
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              V v_x31_2415 = v_field_2413;
              switch (heff_tag_of(v_x31_2415)) {
              case TAG_MkPair: {
                V v_x_2416 = heff_field(v_x31_2415, 0);
                V v_j_2417 = heff_field(v_x31_2415, 1);
                heff_take_n(v_x31_2415, 3ULL, 2);
                V v_t_2418 = heff_tag_at_n(v_ru_24x31_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2416}), v_j_2417});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2418}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2415)}});
              }
            } else {
              heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
              heff_drop(v_field_2413);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_248)}});
        }
      } else {
        heff_drop(v_z_241);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str1), 2)) {
      heff_drop(v_z_241);
      V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2420}});
    } else {
      return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
    }
  }
}