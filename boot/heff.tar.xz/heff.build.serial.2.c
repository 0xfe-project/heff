// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2eabsOf_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2edk_get(void);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo;
V g_heff_2ebuild_2eserial_2etakeAlt(V, V, V);
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeAlt_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V, V);
V g_heff_2ebuild_2eserial_2etermOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_clo;
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_clo;
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    V v_t_246 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(v_lit_240, v_x_243));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, v_a_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str1, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str2, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str3, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str4, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str5, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str6, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str7, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str8, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str9, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str10, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str11, 1, "n");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str12, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str14, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str15, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str16, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str17, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str18, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str19, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str20, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str21, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str22, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str23, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str24, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str25, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str26, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str27, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str28, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str29, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str30, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str31, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str32, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str33, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str34, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str35, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str36, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str37, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str38, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str39, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str40, 2, "px");
Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V v_x2_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_x21_243 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_SmallU: {
      V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str0), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str1), v_rest_241})});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_244);
    }
    case TAG_LargeU: {
      V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str3), v_rest_241})});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_245);
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  case TAG_SDecode: {
    V v_e_246 = heff_field(v_x2_240, 0);
    V v_t_247 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_e_246), v_rest_241));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str4), v_t_247}));
  }
  case TAG_SFunction: {
    V v_level_248 = heff_field(v_x2_240, 0);
    V v_dom_249 = heff_field(v_x2_240, 1);
    V v_cod_2410 = heff_field(v_x2_240, 2);
    V v_implicit_2411 = heff_field(v_x2_240, 3);
    V v_dflt_2412 = heff_field(v_x2_240, 4);
    V v_t_2413;
    switch (heff_tag_of(v_level_248)) {
    case TAG_Small: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str5);
      break;
    }
    case TAG_Large: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str6);
      break;
    }
    case TAG_TopL: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str7);
      break;
    }
    default: heff_nomatch(v_level_248);
    }
    V v_t_2414;
    switch (heff_tag_of(v_implicit_2411)) {
    case TAG_Expl: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str8);
      break;
    }
    case TAG_Impl: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str9);
      break;
    }
    case TAG_Inst: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str10);
      break;
    }
    default: heff_nomatch(v_implicit_2411);
    }
    V v_t_2417;
    switch (heff_tag_of(v_dflt_2412)) {
    case TAG_Nothing: {
      v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str11), v_rest_241});
      break;
    }
    case TAG_Just: {
      V v_d_2415 = heff_field(v_dflt_2412, 0);
      V v_t_2416 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_d_2415), v_rest_241));
      v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str12), v_t_2416});
      break;
    }
    default: heff_nomatch(v_dflt_2412);
    }
    V v_rest_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2417});
    V v_rest_2426;
    switch (heff_tag_of(v_cod_2410)) {
    case TAG_MkAbs: {
      V v_x_2419 = heff_field(v_cod_2410, 0);
      V v_e_2420 = heff_field(v_cod_2410, 1);
      V v_t_2421 = heff_intShow(heff_strLength_lent(v_x_2419, 0));
      V v_t_2422 = heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str13), heff_dup(v_x_2419)));
      V v_t_2423 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2420, v_rest_2418));
      v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2423})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2424 = heff_field(v_cod_2410, 0);
      V v_t_2425 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2424, v_rest_2418));
      v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str15), v_t_2425});
      break;
    }
    default: heff_nomatch(v_cod_2410);
    }
    V v_t_2427 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_dom_249, v_rest_2426));
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2427})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2428);
  }
  case TAG_SRecord: {
    V v_level_2429 = heff_field(v_x2_240, 0);
    V v_fs_2430 = heff_field(v_x2_240, 1);
    V v_ds_2431 = heff_field(v_x2_240, 2);
    V v_keys_2432 = heff_dup(heff_rfield(v_ds_2431, 0));
    V v_values_2433 = heff_dup(heff_rfield(v_ds_2431, 2));
    V v_keys_2434 = heff_dup(heff_rfield(v_fs_2430, 0));
    V v_values_2435 = heff_dup(heff_rfield(v_fs_2430, 2));
    V v_t_2436;
    switch (heff_tag_of(v_level_2429)) {
    case TAG_Small: {
      v_t_2436 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str17);
      break;
    }
    case TAG_Large: {
      v_t_2436 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str18);
      break;
    }
    case TAG_TopL: {
      v_t_2436 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str19);
      break;
    }
    default: heff_nomatch(v_level_2429);
    }
    V v_xs_2437 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2432), heff_arrayToList(v_values_2433)));
    V v_i_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2437));
    V v_t_2439 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str20), v_xs_2437, v_rest_241));
    V v_rest_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2438), v_t_2439});
    V v_xs_2441 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2434), heff_arrayToList(v_values_2435)));
    V v_i_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2441));
    V v_t_2443 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str21), v_xs_2441, v_rest_2440));
    V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2442), v_t_2443});
    V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str22), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_t_2444})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2445);
  }
  case TAG_SSum: {
    V v_vs_2446 = heff_field(v_x2_240, 0);
    V v_keys_2447 = heff_dup(heff_rfield(v_vs_2446, 0));
    V v_values_2448 = heff_dup(heff_rfield(v_vs_2446, 2));
    V v_xs_2449 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2447), heff_arrayToList(v_values_2448)));
    V v_i_2450 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2449));
    V v_t_2451 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str23), MK_INT(1LL), MK_INT(0LL), v_xs_2449, v_rest_241));
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2450), v_t_2451});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str24), v_t_2452}));
  }
  case TAG_SIsTy: {
    V v_t2_2453 = heff_field(v_x2_240, 0);
    V v_cell_2454 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str25), heff_hole()});
    V v_u_2455 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2454));
    heff_drop(v_u_2455);
    V t_0 = v_t2_2453;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2454;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SPrimInt: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str26), v_rest_241}));
  }
  case TAG_SPrimFloat: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str27), v_rest_241}));
  }
  case TAG_SPrimString: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str28), v_rest_241}));
  }
  case TAG_SPrimRune: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str29), v_rest_241}));
  }
  case TAG_SPrimArray: {
    V v_t2_2456 = heff_field(v_x2_240, 0);
    V v_cell_2457 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str30), heff_hole()});
    V v_u_2458 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2457));
    heff_drop(v_u_2458);
    V t_0 = v_t2_2456;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2457;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SFixed: {
    V v_w_2459 = heff_field(v_x2_240, 0);
    V v_t_2460;
    switch (heff_tag_of(v_w_2459)) {
    case TAG_I8: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str31);
      break;
    }
    case TAG_I16: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str32);
      break;
    }
    case TAG_I32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str33);
      break;
    }
    case TAG_I64: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str34);
      break;
    }
    case TAG_U8: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str35);
      break;
    }
    case TAG_U16: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str36);
      break;
    }
    case TAG_U32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str37);
      break;
    }
    case TAG_U64: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str38);
      break;
    }
    case TAG_F32: {
      v_t_2460 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str39);
      break;
    }
    default: heff_nomatch(v_w_2459);
    }
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2461);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_x_242), v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str1, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str2, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str3, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str4, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str5, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str6, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str7, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str8, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str9, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str10, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str11, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str12, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str13, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str14, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str15, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str16, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str17, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str18, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str19, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str20, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str23, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str24, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str25, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str26, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str27, 3, "f32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str28, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str29, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str31, 0, "");

HeffT2 g_heff_2ebuild_2eserial_2etermOf_24cpr(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 2);
    HeffT2 v_t_244 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2eint_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          V v_t_2410 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_x_248}), v_j_249});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2410}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str1), 2)) {
      heff_drop_rec(v_k_240, 2);
      HeffT2 v_t_2411 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_x31_2414 = v_field_2413;
          switch (heff_tag_of(v_x31_2414)) {
          case TAG_MkPair: {
            V v_x_2415 = heff_field(v_x31_2414, 0);
            V v_j_2416 = heff_field(v_x31_2414, 1);
            V v_ru_24x31_2414_24MkPair = heff_take_reuse_n(v_x31_2414, 3ULL, 2);
            V v_t_2417 = heff_tag_at_n(v_ru_24x31_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2415}), v_j_2416});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2417}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2414)}});
          }
        } else {
          heff_drop(v_field_2413);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str2), 2)) {
        V v_x3_2418 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
        switch (heff_tag_of(v_x3_2418)) {
        case TAG_Nothing: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_x31_2419 = heff_field(v_x3_2418, 0);
          V v_ru_24x3_2418_24Just = heff_take_reuse_n(v_x3_2418, 1ULL, 1);
          switch (heff_tag_of(v_x31_2419)) {
          case TAG_MkPair: {
            V v_x_2420 = heff_field(v_x31_2419, 0);
            V v_j_2421 = heff_field(v_x31_2419, 1);
            V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
            V v_t_2422 = heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2418_24Just, TAG_SCode, 1, (V[]){v_x_2420}), v_j_2421});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2422}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x3_2418)}});
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str3), 2)) {
          V v_x3_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
          switch (heff_tag_of(v_x3_2423)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_z_242);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2424 = heff_field(v_x3_2423, 0);
            heff_take_n(v_x3_2423, 1ULL, 1);
            switch (heff_tag_of(v_x31_2424)) {
            case TAG_MkPair: {
              V v_x_2425 = heff_field(v_x31_2424, 0);
              V v_j_2426 = heff_field(v_x31_2424, 1);
              V v_ru_24x31_2424_24MkPair = heff_take_reuse_n(v_x31_2424, 3ULL, 2);
              V v_x3_2427 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_2426}));
              switch (heff_tag_of(v_x3_2427)) {
              case TAG_Nothing: {
                heff_drop(v_x_2425);
                heff_drop_cell(v_ru_24x31_2424_24MkPair, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2428 = heff_field(v_x3_2427, 0);
                heff_take_n(v_x3_2427, 1ULL, 1);
                switch (heff_tag_of(v_x31_2428)) {
                case TAG_MkPair: {
                  V v_x_2429 = heff_field(v_x31_2428, 0);
                  V v_j_2430 = heff_field(v_x31_2428, 1);
                  heff_take_n(v_x31_2428, 3ULL, 2);
                  V v_t_2431 = heff_tag_at_n(v_ru_24x31_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_x_2425, v_x_2429}), v_j_2430});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2431}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2428)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2427)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2424)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x3_2423)}});
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str4), 2)) {
            V v_x3_2432 = heff_tr(heff_call(heff_take_field(v_k_240, 1), 2, (V[]){heff_dup(v_z_242), v_z_243}));
            switch (heff_tag_of(v_x3_2432)) {
            case TAG_Nothing: {
              heff_drop_rec(v_k_240, 2);
              heff_drop(v_z_242);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Just: {
              V v_x31_2433 = heff_field(v_x3_2432, 0);
              heff_take_n(v_x3_2432, 1ULL, 1);
              switch (heff_tag_of(v_x31_2433)) {
              case TAG_MkPair: {
                V v_x_2434 = heff_field(v_x31_2433, 0);
                V v_j_2435 = heff_field(v_x31_2433, 1);
                V v_ru_24x31_2433_24MkPair = heff_take_reuse_n(v_x31_2433, 3ULL, 2);
                HeffT2 v_t_2436 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_242, v_j_2435));
                {
                  V v_field_2438 = v_t_2436.f[1];
                  int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
                  if ((v_tag_2437 == ((int64_t)0ULL))) {
                    V v_x31_2439 = v_field_2438;
                    switch (heff_tag_of(v_x31_2439)) {
                    case TAG_MkPair: {
                      V v_x_2440 = heff_field(v_x31_2439, 0);
                      V v_j_2441 = heff_field(v_x31_2439, 1);
                      heff_take_n(v_x31_2439, 3ULL, 2);
                      HeffT2 v_t_2442 = ({ V a_0 = heff_get_n(v_k_240, 0, 2); V a_1 = v_x_2440; V a_2 = v_z_242; V a_3 = v_j_2441; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2440); r_; });
                      {
                        V v_field_2444 = v_t_2442.f[1];
                        int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
                        if ((v_tag_2443 == ((int64_t)0ULL))) {
                          V v_x31_2445 = v_field_2444;
                          switch (heff_tag_of(v_x31_2445)) {
                          case TAG_MkPair: {
                            V v_x_2446 = heff_field(v_x31_2445, 0);
                            V v_j_2447 = heff_field(v_x31_2445, 1);
                            heff_take_n(v_x31_2445, 3ULL, 2);
                            V v_t_2448 = heff_tag_at_n(v_ru_24x31_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_x_2434, v_x_2446}), v_j_2447});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2448}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2445)}});
                          }
                        } else {
                          heff_drop(v_x_2434);
                          heff_drop_cell(v_ru_24x31_2433_24MkPair, 2);
                          heff_drop(v_field_2444);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2439)}});
                    }
                  } else {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    heff_drop(v_x_2434);
                    heff_drop_cell(v_ru_24x31_2433_24MkPair, 2);
                    heff_drop(v_field_2438);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2433)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x3_2432)}});
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str5), 2)) {
              HeffT2 v_t_2449 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_get_n(v_k_240, 0, 2), v_z_242, v_z_243));
              {
                V v_field_2451 = v_t_2449.f[1];
                int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
                if ((v_tag_2450 == ((int64_t)0ULL))) {
                  V v_x31_2452 = v_field_2451;
                  switch (heff_tag_of(v_x31_2452)) {
                  case TAG_MkPair: {
                    V v_x_2453 = heff_field(v_x31_2452, 0);
                    V v_j_2454 = heff_field(v_x31_2452, 1);
                    V v_ru_24x31_2452_24MkPair = heff_take_reuse_n(v_x31_2452, 3ULL, 2);
                    V v_t_2455 = heff_tag_at_n(v_ru_24x31_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCons, 1, (V[]){v_x_2453}), v_j_2454});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2455}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2452)}});
                  }
                } else {
                  heff_drop(v_field_2451);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str6), 2)) {
                V v_x3_2456 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                switch (heff_tag_of(v_x3_2456)) {
                case TAG_Nothing: {
                  heff_drop(v_z_242);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_2457 = heff_field(v_x3_2456, 0);
                  heff_take_n(v_x3_2456, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2457)) {
                  case TAG_MkPair: {
                    V v_x_2458 = heff_field(v_x31_2457, 0);
                    V v_j_2459 = heff_field(v_x31_2457, 1);
                    V v_ru_24x31_2457_24MkPair = heff_take_reuse_n(v_x31_2457, 3ULL, 2);
                    HeffT2 v_t_2460 = ({ V a_0 = v_z_242; V a_1 = v_j_2459; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                    {
                      V v_field_2462 = v_t_2460.f[1];
                      int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
                      if ((v_tag_2461 == ((int64_t)0ULL))) {
                        V v_x31_2463 = v_field_2462;
                        switch (heff_tag_of(v_x31_2463)) {
                        case TAG_MkPair: {
                          V v_x_2464 = heff_field(v_x31_2463, 0);
                          V v_j_2465 = heff_field(v_x31_2463, 1);
                          heff_take_n(v_x31_2463, 3ULL, 2);
                          V v_t_2466 = heff_tag_at_n(v_ru_24x31_2457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_x_2458, v_x_2464}), v_j_2465});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2466}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2463)}});
                        }
                      } else {
                        heff_drop(v_x_2458);
                        heff_drop_cell(v_ru_24x31_2457_24MkPair, 2);
                        heff_drop(v_field_2462);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2457)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x3_2456)}});
                }
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str7), 2)) {
                  HeffT2 v_t_2467 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                  {
                    V v_field_2469 = v_t_2467.f[1];
                    int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
                    if ((v_tag_2468 == ((int64_t)0ULL))) {
                      V v_x31_2470 = v_field_2469;
                      switch (heff_tag_of(v_x31_2470)) {
                      case TAG_MkPair: {
                        V v_x_2471 = heff_field(v_x31_2470, 0);
                        V v_j_2472 = heff_field(v_x31_2470, 1);
                        V v_ru_24x31_2470_24MkPair = heff_take_reuse_n(v_x31_2470, 3ULL, 2);
                        HeffT2 v_t_2473 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_2472));
                        {
                          V v_field_2475 = v_t_2473.f[1];
                          int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
                          if ((v_tag_2474 == ((int64_t)0ULL))) {
                            V v_x31_2476 = v_field_2475;
                            switch (heff_tag_of(v_x31_2476)) {
                            case TAG_MkPair: {
                              V v_x_2477 = heff_field(v_x31_2476, 0);
                              V v_j_2478 = heff_field(v_x31_2476, 1);
                              V v_ru_24x31_2476_24MkPair = heff_take_reuse_n(v_x31_2476, 3ULL, 2);
                              HeffT2 v_t_2479 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(heff_get_n(v_k_240, 0, 2), v_x_2477, v_z_242, v_j_2478));
                              {
                                V v_field_2481 = v_t_2479.f[1];
                                int64_t v_tag_2480 = ((int64_t)v_t_2479.f[0]);
                                if ((v_tag_2480 == ((int64_t)0ULL))) {
                                  V v_x31_2482 = v_field_2481;
                                  switch (heff_tag_of(v_x31_2482)) {
                                  case TAG_MkPair: {
                                    V v_x_2483 = heff_field(v_x31_2482, 0);
                                    V v_j_2484 = heff_field(v_x31_2482, 1);
                                    heff_take_n(v_x31_2482, 3ULL, 2);
                                    V v_t_2485 = heff_tag_at_n(v_ru_24x31_2476_24MkPair, TAG_STag, 2, (V[]){v_x_2471, heff_arrayFromList(v_x_2483)});
                                    V v_f_2486 = heff_tag_at_n(v_ru_24x31_2470_24MkPair, TAG_MkPair, 2, (V[]){v_t_2485, v_j_2484});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2486}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_2482)}});
                                  }
                                } else {
                                  heff_drop(v_x_2471);
                                  heff_drop_cell(v_ru_24x31_2470_24MkPair, 2);
                                  heff_drop_cell(v_ru_24x31_2476_24MkPair, 2);
                                  heff_drop(v_field_2481);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2476)}});
                            }
                          } else {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_z_242);
                            heff_drop(v_x_2471);
                            heff_drop_cell(v_ru_24x31_2470_24MkPair, 2);
                            heff_drop(v_field_2475);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2470)}});
                      }
                    } else {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      heff_drop(v_field_2469);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str8), 2)) {
                    V v_x3_2487 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                    switch (heff_tag_of(v_x3_2487)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_2488 = heff_field(v_x3_2487, 0);
                      heff_take_n(v_x3_2487, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2488)) {
                      case TAG_MkPair: {
                        V v_x_2489 = heff_field(v_x31_2488, 0);
                        V v_j_2490 = heff_field(v_x31_2488, 1);
                        V v_ru_24x31_2488_24MkPair = heff_take_reuse_n(v_x31_2488, 3ULL, 2);
                        V v_t_2491 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2etakeAlt_clo), 1, (V[]){v_k_240}));
                        HeffT2 v_t_2492 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(v_t_2491, v_z_242, v_j_2490));
                        {
                          V v_field_2494 = v_t_2492.f[1];
                          int64_t v_tag_2493 = ((int64_t)v_t_2492.f[0]);
                          if ((v_tag_2493 == ((int64_t)0ULL))) {
                            V v_x31_2495 = v_field_2494;
                            switch (heff_tag_of(v_x31_2495)) {
                            case TAG_MkPair: {
                              V v_x_2496 = heff_field(v_x31_2495, 0);
                              V v_j_2497 = heff_field(v_x31_2495, 1);
                              heff_take_n(v_x31_2495, 3ULL, 2);
                              V v_t_2498 = heff_tag_at_n(v_ru_24x31_2488_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SMatch, 2, (V[]){v_x_2489, v_x_2496}), v_j_2497});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2498}});
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2495)}});
                            }
                          } else {
                            heff_drop(v_x_2489);
                            heff_drop_cell(v_ru_24x31_2488_24MkPair, 2);
                            heff_drop(v_field_2494);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2488)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x3_2487)}});
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str9), 2)) {
                      V v_x3_2499 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                      switch (heff_tag_of(v_x3_2499)) {
                      case TAG_Nothing: {
                        heff_drop_rec(v_k_240, 2);
                        heff_drop(v_z_242);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Just: {
                        V v_x31_24100 = heff_field(v_x3_2499, 0);
                        heff_take_n(v_x3_2499, 1ULL, 1);
                        switch (heff_tag_of(v_x31_24100)) {
                        case TAG_MkPair: {
                          V v_x_24101 = heff_field(v_x31_24100, 0);
                          V v_j_24102 = heff_field(v_x31_24100, 1);
                          V v_ru_24x31_24100_24MkPair = heff_take_reuse_n(v_x31_24100, 3ULL, 2);
                          HeffT2 v_t_24103 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_24102));
                          {
                            V v_field_24105 = v_t_24103.f[1];
                            int64_t v_tag_24104 = ((int64_t)v_t_24103.f[0]);
                            if ((v_tag_24104 == ((int64_t)0ULL))) {
                              V v_x31_24106 = v_field_24105;
                              switch (heff_tag_of(v_x31_24106)) {
                              case TAG_MkPair: {
                                V v_x_24107 = heff_field(v_x31_24106, 0);
                                V v_j_24108 = heff_field(v_x31_24106, 1);
                                heff_take_n(v_x31_24106, 3ULL, 2);
                                V v_x3_24109 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_24108}));
                                switch (heff_tag_of(v_x3_24109)) {
                                case TAG_Nothing: {
                                  heff_drop(v_x_24101);
                                  heff_drop_cell(v_ru_24x31_24100_24MkPair, 2);
                                  heff_drop(v_x_24107);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24110 = heff_field(v_x3_24109, 0);
                                  heff_take_n(v_x3_24109, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24110)) {
                                  case TAG_MkPair: {
                                    V v_x_24111 = heff_field(v_x31_24110, 0);
                                    V v_j_24112 = heff_field(v_x31_24110, 1);
                                    heff_take_n(v_x31_24110, 3ULL, 2);
                                    V v_t_24113 = heff_tag_at_n(v_ru_24x31_24100_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_24101, v_x_24107, v_x_24111}), v_j_24112});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24113}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24110)}});
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x3_24109)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24106)}});
                              }
                            } else {
                              heff_drop_rec(v_k_240, 2);
                              heff_drop(v_z_242);
                              heff_drop(v_x_24101);
                              heff_drop_cell(v_ru_24x31_24100_24MkPair, 2);
                              heff_drop(v_field_24105);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_24100)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x3_2499)}});
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str10), 2)) {
                        V v_x3_24114 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
                        switch (heff_tag_of(v_x3_24114)) {
                        case TAG_Nothing: {
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_Just: {
                          V v_x31_24115 = heff_field(v_x3_24114, 0);
                          V v_ru_24x3_24114_24Just = heff_take_reuse_n(v_x3_24114, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24115)) {
                          case TAG_MkPair: {
                            V v_x_24116 = heff_field(v_x31_24115, 0);
                            V v_j_24117 = heff_field(v_x31_24115, 1);
                            V v_ru_24x31_24115_24MkPair = heff_take_reuse_n(v_x31_24115, 3ULL, 2);
                            V v_t_24118 = heff_tag_at_n(v_ru_24x31_24115_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24114_24Just, TAG_SIs, 1, (V[]){v_x_24116}), v_j_24117});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24118}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_24115)}});
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x3_24114)}});
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str11), 2)) {
                          heff_drop_rec(v_k_240, 2);
                          heff_drop(v_z_242);
                          V v_t_24119 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SOpaque), v_z_243});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24119}});
                        } else {
                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str12), 2)) {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_z_242);
                            V v_t_24120 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SAbandon), v_z_243});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24120}});
                          } else {
                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str13), 2)) {
                              V v_x3_24121 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
                              switch (heff_tag_of(v_x3_24121)) {
                              case TAG_Nothing: {
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_24122 = heff_field(v_x3_24121, 0);
                                V v_ru_24x3_24121_24Just = heff_take_reuse_n(v_x3_24121, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24122)) {
                                case TAG_MkPair: {
                                  V v_x_24123 = heff_field(v_x31_24122, 0);
                                  V v_j_24124 = heff_field(v_x31_24122, 1);
                                  V v_ru_24x31_24122_24MkPair = heff_take_reuse_n(v_x31_24122, 3ULL, 2);
                                  V v_t_24125 = heff_tag_at_n(v_ru_24x31_24122_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24121_24Just, TAG_SRec, 1, (V[]){v_x_24123}), v_j_24124});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24125}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24122)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x3_24121)}});
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str14), 2)) {
                                V v_x3_24126 = heff_tr(heff_call(heff_take_field(v_k_240, 1), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                                switch (heff_tag_of(v_x3_24126)) {
                                case TAG_Nothing: {
                                  heff_drop_rec(v_k_240, 2);
                                  heff_drop(v_z_242);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24127 = heff_field(v_x3_24126, 0);
                                  heff_take_n(v_x3_24126, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24127)) {
                                  case TAG_MkPair: {
                                    V v_x_24128 = heff_field(v_x31_24127, 0);
                                    V v_j_24129 = heff_field(v_x31_24127, 1);
                                    V v_ru_24x31_24127_24MkPair = heff_take_reuse_n(v_x31_24127, 3ULL, 2);
                                    HeffT2 v_t_24130 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_242, v_j_24129));
                                    {
                                      V v_field_24132 = v_t_24130.f[1];
                                      int64_t v_tag_24131 = ((int64_t)v_t_24130.f[0]);
                                      if ((v_tag_24131 == ((int64_t)0ULL))) {
                                        V v_x31_24133 = v_field_24132;
                                        switch (heff_tag_of(v_x31_24133)) {
                                        case TAG_MkPair: {
                                          V v_x_24134 = heff_field(v_x31_24133, 0);
                                          V v_j_24135 = heff_field(v_x31_24133, 1);
                                          heff_take_n(v_x31_24133, 3ULL, 2);
                                          HeffT2 v_t_24136 = ({ V a_0 = heff_get_n(v_k_240, 0, 2); V a_1 = v_x_24134; V a_2 = v_z_242; V a_3 = v_j_24135; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_24134); r_; });
                                          {
                                            V v_field_24138 = v_t_24136.f[1];
                                            int64_t v_tag_24137 = ((int64_t)v_t_24136.f[0]);
                                            if ((v_tag_24137 == ((int64_t)0ULL))) {
                                              V v_x31_24139 = v_field_24138;
                                              switch (heff_tag_of(v_x31_24139)) {
                                              case TAG_MkPair: {
                                                V v_x_24140 = heff_field(v_x31_24139, 0);
                                                V v_j_24141 = heff_field(v_x31_24139, 1);
                                                heff_take_n(v_x31_24139, 3ULL, 2);
                                                V v_t_24142 = heff_tag_at_n(v_ru_24x31_24127_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFix, 2, (V[]){v_x_24128, v_x_24140}), v_j_24141});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24142}});
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24139)}});
                                              }
                                            } else {
                                              heff_drop(v_x_24128);
                                              heff_drop_cell(v_ru_24x31_24127_24MkPair, 2);
                                              heff_drop(v_field_24138);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24133)}});
                                        }
                                      } else {
                                        heff_drop_rec(v_k_240, 2);
                                        heff_drop(v_z_242);
                                        heff_drop(v_x_24128);
                                        heff_drop_cell(v_ru_24x31_24127_24MkPair, 2);
                                        heff_drop(v_field_24132);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24127)}});
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x3_24126)}});
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str15), 2)) {
                                  HeffT2 v_t_24143 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                  {
                                    V v_field_24145 = v_t_24143.f[1];
                                    int64_t v_tag_24144 = ((int64_t)v_t_24143.f[0]);
                                    if ((v_tag_24144 == ((int64_t)0ULL))) {
                                      V v_x31_24146 = v_field_24145;
                                      switch (heff_tag_of(v_x31_24146)) {
                                      case TAG_MkPair: {
                                        V v_x_24147 = heff_field(v_x31_24146, 0);
                                        V v_j_24148 = heff_field(v_x31_24146, 1);
                                        V v_ru_24x31_24146_24MkPair = heff_take_reuse_n(v_x31_24146, 3ULL, 2);
                                        V v_x3_24149 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_24148}));
                                        switch (heff_tag_of(v_x3_24149)) {
                                        case TAG_Nothing: {
                                          heff_drop(v_x_24147);
                                          heff_drop_cell(v_ru_24x31_24146_24MkPair, 2);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                        case TAG_Just: {
                                          V v_x31_24150 = heff_field(v_x3_24149, 0);
                                          heff_take_n(v_x3_24149, 1ULL, 1);
                                          switch (heff_tag_of(v_x31_24150)) {
                                          case TAG_MkPair: {
                                            V v_x_24151 = heff_field(v_x31_24150, 0);
                                            V v_j_24152 = heff_field(v_x31_24150, 1);
                                            heff_take_n(v_x31_24150, 3ULL, 2);
                                            V v_t_24153 = heff_tag_at_n(v_ru_24x31_24146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SImplicit, 2, (V[]){v_x_24147, v_x_24151}), v_j_24152});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24153}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24150)}});
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x3_24149)}});
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24146)}});
                                      }
                                    } else {
                                      heff_drop_rec(v_k_240, 2);
                                      heff_drop(v_z_242);
                                      heff_drop(v_field_24145);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop_rec(v_k_240, 2);
                                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str16), 2)) {
                                    HeffT2 v_t_24154 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                    {
                                      V v_field_24156 = v_t_24154.f[1];
                                      int64_t v_tag_24155 = ((int64_t)v_t_24154.f[0]);
                                      if ((v_tag_24155 == ((int64_t)0ULL))) {
                                        V v_x31_24157 = v_field_24156;
                                        switch (heff_tag_of(v_x31_24157)) {
                                        case TAG_MkPair: {
                                          V v_x_24158 = heff_field(v_x31_24157, 0);
                                          V v_j_24159 = heff_field(v_x31_24157, 1);
                                          V v_ru_24x31_24157_24MkPair = heff_take_reuse_n(v_x31_24157, 3ULL, 2);
                                          V v_t_24160 = heff_tag_at_n(v_ru_24x31_24157_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_24158}), v_j_24159});
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24160}});
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24157)}});
                                        }
                                      } else {
                                        heff_drop(v_field_24156);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str17), 2)) {
                                      HeffT2 v_t_24161 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                      {
                                        V v_field_24163 = v_t_24161.f[1];
                                        int64_t v_tag_24162 = ((int64_t)v_t_24161.f[0]);
                                        if ((v_tag_24162 == ((int64_t)0ULL))) {
                                          V v_x31_24164 = v_field_24163;
                                          switch (heff_tag_of(v_x31_24164)) {
                                          case TAG_MkPair: {
                                            V v_x_24165 = heff_field(v_x31_24164, 0);
                                            V v_j_24166 = heff_field(v_x31_24164, 1);
                                            V v_ru_24x31_24164_24MkPair = heff_take_reuse_n(v_x31_24164, 3ULL, 2);
                                            V v_t_24167 = ({ V a_0 = v_x_24165; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24165); r_; });
                                            V v_x_24168 = heff_tag_n(TAG_SLitInt, 1, (V[]){v_t_24167});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24164_24MkPair, TAG_MkPair, 2, (V[]){v_x_24168, v_j_24166})}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24164)}});
                                          }
                                        } else {
                                          heff_drop(v_field_24163);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str18), 2)) {
                                        HeffT2 v_t_24169 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                        {
                                          V v_field_24171 = v_t_24169.f[1];
                                          int64_t v_tag_24170 = ((int64_t)v_t_24169.f[0]);
                                          if ((v_tag_24170 == ((int64_t)0ULL))) {
                                            V v_x31_24172 = v_field_24171;
                                            switch (heff_tag_of(v_x31_24172)) {
                                            case TAG_MkPair: {
                                              V v_x_24173 = heff_field(v_x31_24172, 0);
                                              V v_j_24174 = heff_field(v_x31_24172, 1);
                                              V v_ru_24x31_24172_24MkPair = heff_take_reuse_n(v_x31_24172, 3ULL, 2);
                                              V v_x2_24175 = ({ V b_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str19); V a_1 = v_x_24173; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str20), v_x_24173, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_x_24173); r_; });
                                              V v_t_24178;
                                              switch (heff_tag_of(v_x2_24175)) {
                                              case TAG_Nil: {
                                                v_t_24178 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str21);
                                                break;
                                              }
                                              case TAG_Cons: {
                                                V v_x_24176 = heff_field(v_x2_24175, 0);
                                                V v_xs_24177 = heff_field(v_x2_24175, 1);
                                                heff_take_n(v_x2_24175, 3ULL, 2);
                                                v_t_24178 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str22); V a_1 = v_x_24176; V a_2 = v_xs_24177; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24177); r_; });
                                                break;
                                              }
                                              default: heff_nomatch(v_x2_24175);
                                              }
                                              double v_t_24179 = ({ V a_0 = v_t_24178; double r_ = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(a_0)); heff_drop(v_t_24178); r_; });
                                              V v_x_24180 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_t_24179)});
                                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24172_24MkPair, TAG_MkPair, 2, (V[]){v_x_24180, v_j_24174})}});
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24172)}});
                                            }
                                          } else {
                                            heff_drop(v_field_24171);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      } else {
                                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str23), 2)) {
                                          HeffT2 v_t_24181 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                          {
                                            V v_field_24183 = v_t_24181.f[1];
                                            int64_t v_tag_24182 = ((int64_t)v_t_24181.f[0]);
                                            if ((v_tag_24182 == ((int64_t)0ULL))) {
                                              V v_x31_24184 = v_field_24183;
                                              switch (heff_tag_of(v_x31_24184)) {
                                              case TAG_MkPair: {
                                                V v_x_24185 = heff_field(v_x31_24184, 0);
                                                V v_j_24186 = heff_field(v_x31_24184, 1);
                                                V v_ru_24x31_24184_24MkPair = heff_take_reuse_n(v_x31_24184, 3ULL, 2);
                                                V v_t_24187 = heff_tag_at_n(v_ru_24x31_24184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_x_24185}), v_j_24186});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24187}});
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24184)}});
                                              }
                                            } else {
                                              heff_drop(v_field_24183);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str24), 2)) {
                                            HeffT2 v_t_24188 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                            {
                                              V v_field_24190 = v_t_24188.f[1];
                                              int64_t v_tag_24189 = ((int64_t)v_t_24188.f[0]);
                                              if ((v_tag_24189 == ((int64_t)0ULL))) {
                                                V v_x31_24191 = v_field_24190;
                                                switch (heff_tag_of(v_x31_24191)) {
                                                case TAG_MkPair: {
                                                  V v_x_24192 = heff_field(v_x31_24191, 0);
                                                  V v_j_24193 = heff_field(v_x31_24191, 1);
                                                  V v_ru_24x31_24191_24MkPair = heff_take_reuse_n(v_x31_24191, 3ULL, 2);
                                                  V v_t_24194 = heff_tag_at_n(v_ru_24x31_24191_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitBytes, 1, (V[]){v_x_24192}), v_j_24193});
                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24194}});
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24191)}});
                                                }
                                              } else {
                                                heff_drop(v_field_24190);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          } else {
                                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str25), 2)) {
                                              HeffT2 v_t_24195 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                              {
                                                V v_field_24197 = v_t_24195.f[1];
                                                int64_t v_tag_24196 = ((int64_t)v_t_24195.f[0]);
                                                if ((v_tag_24196 == ((int64_t)0ULL))) {
                                                  V v_x31_24198 = v_field_24197;
                                                  switch (heff_tag_of(v_x31_24198)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24199 = heff_field(v_x31_24198, 0);
                                                    V v_j_24200 = heff_field(v_x31_24198, 1);
                                                    V v_ru_24x31_24198_24MkPair = heff_take_reuse_n(v_x31_24198, 3ULL, 2);
                                                    V v_t_24201 = ({ V a_0 = v_x_24199; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24199); r_; });
                                                    V v_x_24202 = heff_tag_n(TAG_SLitRune, 1, (V[]){v_t_24201});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24198_24MkPair, TAG_MkPair, 2, (V[]){v_x_24202, v_j_24200})}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24198)}});
                                                  }
                                                } else {
                                                  heff_drop(v_field_24197);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str26), 2)) {
                                                HeffT2 v_t_24203 = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(v_z_242, v_z_243));
                                                {
                                                  V v_field_24205 = v_t_24203.f[1];
                                                  int64_t v_tag_24204 = ((int64_t)v_t_24203.f[0]);
                                                  if ((v_tag_24204 == ((int64_t)0ULL))) {
                                                    V v_x31_24206 = v_field_24205;
                                                    switch (heff_tag_of(v_x31_24206)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24207 = heff_field(v_x31_24206, 0);
                                                      V v_j_24208 = heff_field(v_x31_24206, 1);
                                                      V v_ru_24x31_24206_24MkPair = heff_take_reuse_n(v_x31_24206, 3ULL, 2);
                                                      HeffT2 v_t_24209 = ({ V a_0 = v_z_242; V a_1 = v_j_24208; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                                      {
                                                        V v_field_24211 = v_t_24209.f[1];
                                                        int64_t v_tag_24210 = ((int64_t)v_t_24209.f[0]);
                                                        if ((v_tag_24210 == ((int64_t)0ULL))) {
                                                          V v_x31_24212 = v_field_24211;
                                                          switch (heff_tag_of(v_x31_24212)) {
                                                          case TAG_MkPair: {
                                                            V v_x_24213 = heff_field(v_x31_24212, 0);
                                                            V v_j_24214 = heff_field(v_x31_24212, 1);
                                                            V v_ru_24x31_24212_24MkPair = heff_take_reuse_n(v_x31_24212, 3ULL, 2);
                                                            V v_t_24215 = ({ V a_0 = v_x_24213; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24213); r_; });
                                                            V v_x_24216 = heff_tag_at_n(v_ru_24x31_24212_24MkPair, TAG_SLitFixed, 2, (V[]){v_x_24207, v_t_24215});
                                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24206_24MkPair, TAG_MkPair, 2, (V[]){v_x_24216, v_j_24214})}});
                                                          }
                                                          default: return ((HeffT2){{heff_nomatch(v_x31_24212)}});
                                                          }
                                                        } else {
                                                          heff_drop(v_x_24207);
                                                          heff_drop_cell(v_ru_24x31_24206_24MkPair, 2);
                                                          heff_drop(v_field_24211);
                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                        }
                                                      }
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x31_24206)}});
                                                    }
                                                  } else {
                                                    heff_drop(v_z_242);
                                                    heff_drop(v_field_24205);
                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                  }
                                                }
                                              } else {
                                                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str27), 2)) {
                                                  HeffT2 v_t_24217 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                                  {
                                                    V v_field_24219 = v_t_24217.f[1];
                                                    int64_t v_tag_24218 = ((int64_t)v_t_24217.f[0]);
                                                    if ((v_tag_24218 == ((int64_t)0ULL))) {
                                                      V v_x31_24220 = v_field_24219;
                                                      switch (heff_tag_of(v_x31_24220)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24221 = heff_field(v_x31_24220, 0);
                                                        V v_j_24222 = heff_field(v_x31_24220, 1);
                                                        V v_ru_24x31_24220_24MkPair = heff_take_reuse_n(v_x31_24220, 3ULL, 2);
                                                        V v_x2_24223 = ({ V b_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str28); V a_1 = v_x_24221; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str29), v_x_24221, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_x_24221); r_; });
                                                        V v_t_24226;
                                                        switch (heff_tag_of(v_x2_24223)) {
                                                        case TAG_Nil: {
                                                          v_t_24226 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str30);
                                                          break;
                                                        }
                                                        case TAG_Cons: {
                                                          V v_x_24224 = heff_field(v_x2_24223, 0);
                                                          V v_xs_24225 = heff_field(v_x2_24223, 1);
                                                          heff_take_n(v_x2_24223, 3ULL, 2);
                                                          v_t_24226 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str31); V a_1 = v_x_24224; V a_2 = v_xs_24225; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24225); r_; });
                                                          break;
                                                        }
                                                        default: heff_nomatch(v_x2_24223);
                                                        }
                                                        double v_t_24227 = ({ V a_0 = v_t_24226; double r_ = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(a_0)); heff_drop(v_t_24226); r_; });
                                                        V v_x_24228 = heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24227)});
                                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24220_24MkPair, TAG_MkPair, 2, (V[]){v_x_24228, v_j_24222})}});
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_24220)}});
                                                      }
                                                    } else {
                                                      heff_drop(v_field_24219);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                  }
                                                } else {
                                                  return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2eserial_2edk_lam0(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edk_lam0, 2, 0};
V g_heff_2ebuild_2eserial_2edk_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edk_lam1, 2, 0};

static V g_heff_2ebuild_2eserial_2edk_val;
static HEFF_ONCE g_heff_2ebuild_2eserial_2edk_st;
static V g_heff_2ebuild_2eserial_2edk_init(void) {
  return heff_rec_n(2, shape_el__ty, (V[]){((V)&g_heff_2ebuild_2eserial_2edk_lam0_clo), ((V)&g_heff_2ebuild_2eserial_2edk_lam1_clo)});
}
V g_heff_2ebuild_2eserial_2edk_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eserial_2edk_st)) return g_heff_2ebuild_2eserial_2edk_val;
  return heff_global(&g_heff_2ebuild_2eserial_2edk_val, &g_heff_2ebuild_2eserial_2edk_st, g_heff_2ebuild_2eserial_2edk_init);
}
V g_heff_2ebuild_2eserial_2edk_lam0(V self, V *args) {
  V v_s_240 = args[0];
  V v_i_241 = args[1];
  V v_k_242 = heff_dup(g_heff_2ebuild_2eserial_2edk_get());
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        heff_take_n(v_x31_246, 3ULL, 2);
        return ({ V a_0 = v_k_242; V a_1 = v_x_247; V a_2 = v_s_240; V a_3 = v_j_248; V r_ = (g_heff_2ebuild_2eserial_2etermOf(a_0, a_1, a_2, a_3)); heff_drop(v_x_247); r_; });
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_k_242);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2edk_lam1(V self, V *args) {
  V v_s_249 = args[0];
  V v_i_2410 = args[1];
  V v_k_2411 = heff_dup(g_heff_2ebuild_2eserial_2edk_get());
  HeffT2 v_t_2412 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_249, v_i_2410));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x31_2415 = v_field_2414;
      switch (heff_tag_of(v_x31_2415)) {
      case TAG_MkPair: {
        V v_x_2416 = heff_field(v_x31_2415, 0);
        V v_j_2417 = heff_field(v_x31_2415, 1);
        heff_take_n(v_x31_2415, 3ULL, 2);
        return ({ V a_0 = v_k_2411; V a_1 = v_x_2416; V a_2 = v_s_249; V a_3 = v_j_2417; V r_ = (g_heff_2ebuild_2eserial_2etypeOf(a_0, a_1, a_2, a_3)); heff_drop(v_x_2416); r_; });
      }
      default: return heff_nomatch(v_x31_2415);
      }
    } else {
      heff_drop(v_s_249);
      heff_drop(v_k_2411);
      heff_drop(v_field_2414);
      return NTAG(TAG_Nothing);
    }
  }
}

HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(v_x_246, v_s_240, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
              V v_t_2414 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x31_2411_24MkPair, heff_dup(v_x_2412)));
              V v_t_2415 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2412));
              V v_t_2416 = (g_list_2emap_24s1173914895x100384474(v_x_2412));
              V v_x_2417 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2414), v_t_2415, heff_arrayFromList(v_t_2416)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_2417, v_j_2413})}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2411)}});
            }
          } else {
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str1, 1, "n");

HeffT2 g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str0), 2)) {
    HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x31_246 = v_field_245;
        switch (heff_tag_of(v_x31_246)) {
        case TAG_MkPair: {
          V v_x_247 = heff_field(v_x31_246, 0);
          V v_j_248 = heff_field(v_x31_246, 1);
          V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
          HeffT2 v_t_249 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_247, v_z_241, v_j_248));
          {
            V v_field_2411 = v_t_249.f[1];
            int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
            if ((v_tag_2410 == ((int64_t)0ULL))) {
              V v_x31_2412 = v_field_2411;
              switch (heff_tag_of(v_x31_2412)) {
              case TAG_MkPair: {
                V v_x_2413 = heff_field(v_x31_2412, 0);
                V v_j_2414 = heff_field(v_x31_2412, 1);
                heff_take_n(v_x31_2412, 3ULL, 2);
                V v_t_2415 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2413}), v_j_2414});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2415}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2412)}});
              }
            } else {
              heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
              heff_drop(v_field_2411);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
        }
      } else {
        heff_drop(v_z_241);
        heff_drop(v_field_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str1), 2)) {
      heff_drop(v_z_241);
      V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
    } else {
      return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
    }
  }
}