// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_BDelayedBy 11524
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_Catch 6517
#define TAG_Get 18914
#define TAG_HLocal 25864
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_MkSt 48854
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SpId 35501
#define LBL_bind 9519364
#define LBL_ctx 308385
#define LBL_infos 301706655
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_selfKey 62480824
#define LBL_trace 311979359
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
V g_heff_2eenvironment_2ebindName(V, V, V);
V g_heff_2eenvironment_2ebindName_entry(V self, V *a);
extern Clo g_heff_2eenvironment_2ebindName_clo;
V g_heff_2eenvironment_2eemptyCore_get(void);
V g_heff_2eenvironment_2eemptyScope_get(void);
V g_heff_2eenvironment_2eemptySt_get(void);
V g_heff_2eenvironment_2emodify(V, V, V);
V g_heff_2eenvironment_2emodify_entry(V self, V *a);
extern Clo g_heff_2eenvironment_2emodify_clo;
V g_heff_2eenvironment_2emultiBind(V, V, V);
V g_heff_2eenvironment_2emultiBind_entry(V self, V *a);
extern Clo g_heff_2eenvironment_2emultiBind_clo;
V g_heff_2eenvironment_2etryE(V, V, V);
V g_heff_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eenvironment_2etryE_clo;
V g_heff_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eenvironment_2ewithBound_clo;
V g_heff_2evalue_2emkNeu_24s1912479565x1511825694(V, V, V, V);
V g_heff_2evalue_2emkNeu_24s1912479565x1511825694_entry(V self, V *a);
extern Clo g_heff_2evalue_2emkNeu_24s1912479565x1511825694_clo;
V g_map_2eempty_get(void);

static V g_heff_2eenvironment_2eemptyScope_val;
static int g_heff_2eenvironment_2eemptyScope_st;
static V g_heff_2eenvironment_2eemptyScope_init(void) {
  return heff_rec(4, shape_len__names__locals__ctx, (V[]){MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_LNil), NTAG(TAG_CEmpty)});
}
V g_heff_2eenvironment_2eemptyScope_get(void) {
  if (g_heff_2eenvironment_2eemptyScope_st == 2) return g_heff_2eenvironment_2eemptyScope_val;
  if (g_heff_2eenvironment_2eemptyScope_st == 1) heff_fail("defined by itself");
  g_heff_2eenvironment_2eemptyScope_st = 1;
  g_heff_2eenvironment_2eemptyScope_val = heff_tr(g_heff_2eenvironment_2eemptyScope_init());
  g_heff_2eenvironment_2eemptyScope_st = 2;
  return g_heff_2eenvironment_2eemptyScope_val;
}
V g_heff_2eenvironment_2ebindName_lam0(V self, V *args);
V g_heff_2eenvironment_2ebindName_lam1(V self, V *args);
Clo g_heff_2eenvironment_2ebindName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eenvironment_2ebindName_entry, 3, 0};

V g_heff_2eenvironment_2ebindName(V v_x_240, V v_a_241, V v_c_242) {
top: ;
  V v_t_243 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_242), LBL_len)});
  V v_v_245 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_243, NTAG(TAG_SpId), heff_clo(g_heff_2eenvironment_2ebindName_lam0, 1, 1, (V[]){heff_dup(v_a_241)}), NTAG(TAG_Nothing)));
  V v_t_246 = heff_intAdd(heff_get(heff_dup(v_c_242), LBL_len), MK_INT(1LL));
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){v_x_240, heff_get(heff_dup(v_c_242), LBL_names)});
  V v_t_249 = heff_tag(TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_242), LBL_locals), heff_clo(g_heff_2eenvironment_2ebindName_lam1, 1, 1, (V[]){v_v_245})});
  V v_t_2410 = heff_tag(TAG_CBind, 3, (V[]){heff_get(v_c_242, LBL_ctx), heff_tag(TAG_BDelayedBy, 1, (V[]){MK_INT(0LL)}), v_a_241});
  return heff_rec(4, shape_len__names__locals__ctx, (V[]){v_t_246, v_t_247, v_t_249, v_t_2410});
}
V g_heff_2eenvironment_2ebindName_entry(V self, V *a) {
  (void)self;
  return g_heff_2eenvironment_2ebindName(a[0], a[1], a[2]);
}
V g_heff_2eenvironment_2ebindName_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return v_a_241;
}
V g_heff_2eenvironment_2ebindName_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_v_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return v_v_245;
}
Clo g_heff_2eenvironment_2emultiBind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eenvironment_2emultiBind_entry, 3, 0};

V g_heff_2eenvironment_2emultiBind(V v_x1_240, V v_x2_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_s_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return v_s_242;
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x2_241, 0);
      V v_as_246 = heff_field(v_x2_241, 1);
      V v_t_247 = (g_heff_2eenvironment_2ebindName(heff_dup(v_x_243), heff_dup(v_a_245), v_s_242));
      V t_0 = v_xs_244;
      V t_1 = v_as_246;
      V t_2 = v_t_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_s_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eenvironment_2emultiBind_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eenvironment_2emultiBind(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2eenvironment_2ewithBound_lam0(V self, V *args);
V g_heff_2eenvironment_2ewithBound_lam1(V self, V *args);
V g_heff_2eenvironment_2ewithBound_lam2(V self, V *args);
Clo g_heff_2eenvironment_2ewithBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eenvironment_2ewithBound_entry, 4, 0};

V g_heff_2eenvironment_2ewithBound(V v_x_240, V v_a_241, V v_c_242, V v_action_243) {
top: ;
  V v_t_244 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_242), LBL_len)});
  V v_t_246 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_244, NTAG(TAG_SpId), heff_clo(g_heff_2eenvironment_2ewithBound_lam0, 1, 1, (V[]){heff_dup(v_a_241)}), NTAG(TAG_Nothing)));
  V v_t_247 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_242), LBL_len)});
  V v_v_249 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_247, NTAG(TAG_SpId), heff_clo(g_heff_2eenvironment_2ewithBound_lam1, 1, 1, (V[]){heff_dup(v_a_241)}), NTAG(TAG_Nothing)));
  V v_t_2410 = heff_intAdd(heff_get(heff_dup(v_c_242), LBL_len), MK_INT(1LL));
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_x_240, heff_get(heff_dup(v_c_242), LBL_names)});
  V v_t_2413 = heff_tag(TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_242), LBL_locals), heff_clo(g_heff_2eenvironment_2ewithBound_lam2, 1, 1, (V[]){v_v_249})});
  V v_t_2414 = heff_tag(TAG_CBind, 3, (V[]){heff_get(v_c_242, LBL_ctx), heff_tag(TAG_BDelayedBy, 1, (V[]){MK_INT(0LL)}), v_a_241});
  return heff_tail(v_action_243, 2, (V[]){v_t_246, heff_rec(4, shape_len__names__locals__ctx, (V[]){v_t_2410, v_t_2411, v_t_2413, v_t_2414})});
}
V g_heff_2eenvironment_2ewithBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2eenvironment_2ewithBound(a[0], a[1], a[2], a[3]);
}
V g_heff_2eenvironment_2ewithBound_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_245);
  return v_a_241;
}
V g_heff_2eenvironment_2ewithBound_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return v_a_241;
}
V g_heff_2eenvironment_2ewithBound_lam2(V self, V *args) {
  V v_u_2412 = args[0];
  V v_v_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_v_249;
}

static V g_heff_2eenvironment_2eemptyCore_val;
static int g_heff_2eenvironment_2eemptyCore_st;
static V g_heff_2eenvironment_2eemptyCore_init(void) {
  return heff_rec(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing)});
}
V g_heff_2eenvironment_2eemptyCore_get(void) {
  if (g_heff_2eenvironment_2eemptyCore_st == 2) return g_heff_2eenvironment_2eemptyCore_val;
  if (g_heff_2eenvironment_2eemptyCore_st == 1) heff_fail("defined by itself");
  g_heff_2eenvironment_2eemptyCore_st = 1;
  g_heff_2eenvironment_2eemptyCore_val = heff_tr(g_heff_2eenvironment_2eemptyCore_init());
  g_heff_2eenvironment_2eemptyCore_st = 2;
  return g_heff_2eenvironment_2eemptyCore_val;
}

static V g_heff_2eenvironment_2eemptySt_val;
static int g_heff_2eenvironment_2eemptySt_st;
static V g_heff_2eenvironment_2eemptySt_init(void) {
  return heff_tag(TAG_MkSt, 3, (V[]){heff_dup(g_heff_2eenvironment_2eemptyCore_get()), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2eenvironment_2eemptySt_get(void) {
  if (g_heff_2eenvironment_2eemptySt_st == 2) return g_heff_2eenvironment_2eemptySt_val;
  if (g_heff_2eenvironment_2eemptySt_st == 1) heff_fail("defined by itself");
  g_heff_2eenvironment_2eemptySt_st = 1;
  g_heff_2eenvironment_2eemptySt_val = heff_tr(g_heff_2eenvironment_2eemptySt_init());
  g_heff_2eenvironment_2eemptySt_st = 2;
  return g_heff_2eenvironment_2eemptySt_val;
}
V g_heff_2eenvironment_2emodify_lam0(V self, V *args);
Clo g_heff_2eenvironment_2emodify_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eenvironment_2emodify_entry, 3, 0};

V g_heff_2eenvironment_2emodify(V v_f_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){v_f_240})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_244}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2eenvironment_2emodify_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2eenvironment_2emodify_entry(V self, V *a) {
  (void)self;
  return g_heff_2eenvironment_2emodify(a[0], a[1], a[2]);
}
V g_heff_2eenvironment_2emodify_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag(TAG_Put, 2, (V[]){v_x_246, NTAG(TAG_MkUnit)});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_249, v_k_242});
}
V g_heff_2eenvironment_2etryE_lam0(V self, V *args);
V g_heff_2eenvironment_2etryE_lam1(V self, V *args);
Clo g_heff_2eenvironment_2etryE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eenvironment_2etryE_entry, 3, 0};

V g_heff_2eenvironment_2etryE(V v_m_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_244 = heff_tr(heff_apply(v_m_240, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2eenvironment_2etryE_lam0, 1, 1, (V[]){heff_dup(v_hd_241)})}));
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Catch, 2, (V[]){v_t_244, heff_clo(g_heff_2eenvironment_2etryE_lam1, 1, 1, (V[]){heff_dup(v_hd_241)})})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_248, v_k2_242});
}
V g_heff_2eenvironment_2etryE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eenvironment_2etryE(a[0], a[1], a[2]);
}
V g_heff_2eenvironment_2etryE_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_hd_241, LBL_ret);
  args[0] = heff_tag(TAG_Right, 1, (V[]){v_x_243});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eenvironment_2etryE_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get(v_hd_241, LBL_ret);
  args[0] = heff_tag(TAG_Left, 1, (V[]){v_s_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}