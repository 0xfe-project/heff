// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CloseFile 52884
#define TAG_Copy 17796
#define TAG_HandleStatus 481
#define TAG_MakeDirectory 16793
#define TAG_Move 53768
#define TAG_OpenPath 44468
#define TAG_PathStatus 29154
#define TAG_ReadChunk 39695
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_ReadLine 54539
#define TAG_ReadOnly 17623
#define TAG_RealPath 18882
#define TAG_Remove 9747
#define TAG_Replace 14236
#define TAG_Seek 25805
#define TAG_SetMode 203
#define TAG_Standard 18554
#define TAG_TemporaryDirectory 61563
#define TAG_TemporaryFile 11955
#define TAG_Writable 11315
#define TAG_WriteBytes 40855
#define TAG_WriteFile 62589
#define TAG_WriteString 34128
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_std_2efilesystem_2efilesystem_get(void);
V g_std_2efilesystem_2efilesystem_lam1(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam2(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam3(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam4(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam5(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam6(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam7(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam8(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam9(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam10(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam11(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam12(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam13(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam14(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam15(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam16(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam17(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam18(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam19(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam20(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam21(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam22(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam23(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam24(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam0(V self, V *args); static Clo g_std_2efilesystem_2efilesystem_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2efilesystem_lam0, 3, 0};
V g_std_2efilesystem_2efilesystem_lam25(V self, V *args); static Clo g_std_2efilesystem_2efilesystem_lam25_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2efilesystem_lam25, 4, 0};

static V g_std_2efilesystem_2efilesystem_val;
static HEFF_ONCE g_std_2efilesystem_2efilesystem_st;
static V g_std_2efilesystem_2efilesystem_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2efilesystem_2efilesystem_lam0_clo), ((V)&g_std_2efilesystem_2efilesystem_lam25_clo)});
}
V g_std_2efilesystem_2efilesystem_get(void) {
  if (HEFF_DONE(g_std_2efilesystem_2efilesystem_st)) return g_std_2efilesystem_2efilesystem_val;
  return heff_global(&g_std_2efilesystem_2efilesystem_val, &g_std_2efilesystem_2efilesystem_st, g_std_2efilesystem_2efilesystem_init);
}
V g_std_2efilesystem_2efilesystem_lam1(V self, V *args) {
  V v_t_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_k_244, 1, (V[]){v_t_245}));
  V f_ = v_g_241;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam2(V self, V *args) {
  V v_ok_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_tr(heff_call(v_k_249, 1, (V[]){v_ok_2410}));
  V f_ = v_g_241;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam3(V self, V *args) {
  V v_ok_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_k_2413, 1, (V[]){v_ok_2414}));
  V f_ = v_g_241;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam4(V self, V *args) {
  V v_ns_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_k_2417, 1, (V[]){v_ns_2418}));
  V f_ = v_g_241;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam5(V self, V *args) {
  V v_ok_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_call(v_k_2421, 1, (V[]){v_ok_2422}));
  V f_ = v_g_241;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam6(V self, V *args) {
  V v_ok_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_tr(heff_call(v_k_2425, 1, (V[]){v_ok_2426}));
  V f_ = v_g_241;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam7(V self, V *args) {
  V v_ok_2431 = args[0];
  V v_k_2430 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_tr(heff_call(v_k_2430, 1, (V[]){v_ok_2431}));
  V f_ = v_g_241;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam8(V self, V *args) {
  V v_ok_2436 = args[0];
  V v_k_2435 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_tr(heff_call(v_k_2435, 1, (V[]){v_ok_2436}));
  V f_ = v_g_241;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam9(V self, V *args) {
  V v_ok_2441 = args[0];
  V v_k_2440 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442 = heff_tr(heff_call(v_k_2440, 1, (V[]){v_ok_2441}));
  V f_ = v_g_241;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam10(V self, V *args) {
  V v_ok_2445 = args[0];
  V v_k_2444 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_tr(heff_call(v_k_2444, 1, (V[]){v_ok_2445}));
  V f_ = v_g_241;
  args[0] = v_t_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam11(V self, V *args) {
  V v_r_2450 = args[0];
  V v_k_2449 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_tr(heff_call(v_k_2449, 1, (V[]){v_r_2450}));
  V f_ = v_g_241;
  args[0] = v_t_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam12(V self, V *args) {
  V v_r_2455 = args[0];
  V v_k_2454 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2456 = heff_tr(heff_call(v_k_2454, 1, (V[]){v_r_2455}));
  V f_ = v_g_241;
  args[0] = v_t_2456;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam13(V self, V *args) {
  V v_r_2459 = args[0];
  V v_k_2458 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2460 = heff_tr(heff_call(v_k_2458, 1, (V[]){v_r_2459}));
  V f_ = v_g_241;
  args[0] = v_t_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam14(V self, V *args) {
  V v_r_2463 = args[0];
  V v_k_2462 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2464 = heff_tr(heff_call(v_k_2462, 1, (V[]){v_r_2463}));
  V f_ = v_g_241;
  args[0] = v_t_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam15(V self, V *args) {
  V v_r_2467 = args[0];
  V v_k_2466 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2468 = heff_tr(heff_call(v_k_2466, 1, (V[]){v_r_2467}));
  V f_ = v_g_241;
  args[0] = v_t_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam16(V self, V *args) {
  V v_r_2476 = args[0];
  V v_k_2475 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2477 = heff_tr(heff_call(v_k_2475, 1, (V[]){v_r_2476}));
  V f_ = v_g_241;
  args[0] = v_t_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam17(V self, V *args) {
  V v_h_2480 = args[0];
  V v_k_2479 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2481 = heff_tr(heff_call(v_k_2479, 1, (V[]){v_h_2480}));
  V f_ = v_g_241;
  args[0] = v_t_2481;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam18(V self, V *args) {
  V v_r_2485 = args[0];
  V v_k_2484 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2486 = heff_tr(heff_call(v_k_2484, 1, (V[]){v_r_2485}));
  V f_ = v_g_241;
  args[0] = v_t_2486;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam19(V self, V *args) {
  V v_r_2489 = args[0];
  V v_k_2488 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2490 = heff_tr(heff_call(v_k_2488, 1, (V[]){v_r_2489}));
  V f_ = v_g_241;
  args[0] = v_t_2490;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam20(V self, V *args) {
  V v_r_2494 = args[0];
  V v_k_2493 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2495 = heff_tr(heff_call(v_k_2493, 1, (V[]){v_r_2494}));
  V f_ = v_g_241;
  args[0] = v_t_2495;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam21(V self, V *args) {
  V v_r_2499 = args[0];
  V v_k_2498 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24100 = heff_tr(heff_call(v_k_2498, 1, (V[]){v_r_2499}));
  V f_ = v_g_241;
  args[0] = v_t_24100;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam22(V self, V *args) {
  V v_r_24105 = args[0];
  V v_k_24104 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24106 = heff_tr(heff_call(v_k_24104, 1, (V[]){v_r_24105}));
  V f_ = v_g_241;
  args[0] = v_t_24106;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam23(V self, V *args) {
  V v_r_24109 = args[0];
  V v_k_24108 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24110 = heff_tr(heff_call(v_k_24108, 1, (V[]){v_r_24109}));
  V f_ = v_g_241;
  args[0] = v_t_24110;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam24(V self, V *args) {
  V v_r_24113 = args[0];
  V v_k_24112 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24114 = heff_tr(heff_call(v_k_24112, 1, (V[]){v_r_24113}));
  V f_ = v_g_241;
  args[0] = v_t_24114;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_ReadFile: {
    V v_path_243 = heff_field(v_p_242, 0);
    V v_k_244 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadFile = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ReadFile, TAG_ReadFile, 2, (V[]){v_path_243, heff_clo_n(g_std_2efilesystem_2efilesystem_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
  }
  case TAG_WriteFile: {
    V v_path_247 = heff_field(v_p_242, 0);
    V v_str_248 = heff_field(v_p_242, 1);
    V v_k_249 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24WriteFile = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24WriteFile, TAG_WriteFile, 3, (V[]){v_path_247, v_str_248, heff_clo_n(g_std_2efilesystem_2efilesystem_lam2, 1, 2, (V[]){v_k_249, v_g_241})});
  }
  case TAG_MakeDirectory: {
    V v_path_2412 = heff_field(v_p_242, 0);
    V v_k_2413 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24MakeDirectory = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24MakeDirectory, TAG_MakeDirectory, 2, (V[]){v_path_2412, heff_clo_n(g_std_2efilesystem_2efilesystem_lam3, 1, 2, (V[]){v_k_2413, v_g_241})});
  }
  case TAG_ReadDirectory: {
    V v_path_2416 = heff_field(v_p_242, 0);
    V v_k_2417 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadDirectory = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ReadDirectory, TAG_ReadDirectory, 2, (V[]){v_path_2416, heff_clo_n(g_std_2efilesystem_2efilesystem_lam4, 1, 2, (V[]){v_k_2417, v_g_241})});
  }
  case TAG_Remove: {
    V v_path_2420 = heff_field(v_p_242, 0);
    V v_k_2421 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Remove = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Remove, TAG_Remove, 2, (V[]){v_path_2420, heff_clo_n(g_std_2efilesystem_2efilesystem_lam5, 1, 2, (V[]){v_k_2421, v_g_241})});
  }
  case TAG_ReadOnly: {
    V v_path_2424 = heff_field(v_p_242, 0);
    V v_k_2425 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadOnly = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ReadOnly, TAG_ReadOnly, 2, (V[]){v_path_2424, heff_clo_n(g_std_2efilesystem_2efilesystem_lam6, 1, 2, (V[]){v_k_2425, v_g_241})});
  }
  case TAG_Copy: {
    V v_path_2428 = heff_field(v_p_242, 0);
    V v_to_2429 = heff_field(v_p_242, 1);
    V v_k_2430 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Copy = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Copy, TAG_Copy, 3, (V[]){v_path_2428, v_to_2429, heff_clo_n(g_std_2efilesystem_2efilesystem_lam7, 1, 2, (V[]){v_k_2430, v_g_241})});
  }
  case TAG_Move: {
    V v_path_2433 = heff_field(v_p_242, 0);
    V v_to_2434 = heff_field(v_p_242, 1);
    V v_k_2435 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Move = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Move, TAG_Move, 3, (V[]){v_path_2433, v_to_2434, heff_clo_n(g_std_2efilesystem_2efilesystem_lam8, 1, 2, (V[]){v_k_2435, v_g_241})});
  }
  case TAG_Replace: {
    V v_path_2438 = heff_field(v_p_242, 0);
    V v_to_2439 = heff_field(v_p_242, 1);
    V v_k_2440 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Replace = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Replace, TAG_Replace, 3, (V[]){v_path_2438, v_to_2439, heff_clo_n(g_std_2efilesystem_2efilesystem_lam9, 1, 2, (V[]){v_k_2440, v_g_241})});
  }
  case TAG_Writable: {
    V v_path_2443 = heff_field(v_p_242, 0);
    V v_k_2444 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Writable = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Writable, TAG_Writable, 2, (V[]){v_path_2443, heff_clo_n(g_std_2efilesystem_2efilesystem_lam10, 1, 2, (V[]){v_k_2444, v_g_241})});
  }
  case TAG_PathStatus: {
    V v_path_2447 = heff_field(v_p_242, 0);
    V v_follow_2448 = heff_field(v_p_242, 1);
    V v_k_2449 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24PathStatus = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24PathStatus, TAG_PathStatus, 3, (V[]){v_path_2447, v_follow_2448, heff_clo_n(g_std_2efilesystem_2efilesystem_lam11, 1, 2, (V[]){v_k_2449, v_g_241})});
  }
  case TAG_SetMode: {
    V v_path_2452 = heff_field(v_p_242, 0);
    V v_mode_2453 = heff_field(v_p_242, 1);
    V v_k_2454 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24SetMode = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24SetMode, TAG_SetMode, 3, (V[]){v_path_2452, v_mode_2453, heff_clo_n(g_std_2efilesystem_2efilesystem_lam12, 1, 2, (V[]){v_k_2454, v_g_241})});
  }
  case TAG_RealPath: {
    V v_path_2457 = heff_field(v_p_242, 0);
    V v_k_2458 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24RealPath = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24RealPath, TAG_RealPath, 2, (V[]){v_path_2457, heff_clo_n(g_std_2efilesystem_2efilesystem_lam13, 1, 2, (V[]){v_k_2458, v_g_241})});
  }
  case TAG_TemporaryDirectory: {
    V v_prefix_2461 = heff_field(v_p_242, 0);
    V v_k_2462 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24TemporaryDirectory = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24TemporaryDirectory, TAG_TemporaryDirectory, 2, (V[]){v_prefix_2461, heff_clo_n(g_std_2efilesystem_2efilesystem_lam14, 1, 2, (V[]){v_k_2462, v_g_241})});
  }
  case TAG_TemporaryFile: {
    V v_prefix_2465 = heff_field(v_p_242, 0);
    V v_k_2466 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24TemporaryFile = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24TemporaryFile, TAG_TemporaryFile, 2, (V[]){v_prefix_2465, heff_clo_n(g_std_2efilesystem_2efilesystem_lam15, 1, 2, (V[]){v_k_2466, v_g_241})});
  }
  case TAG_OpenPath: {
    V v_path_2469 = heff_field(v_p_242, 0);
    V v_a_2470 = heff_field(v_p_242, 1);
    V v_c_2471 = heff_field(v_p_242, 2);
    V v_t_2472 = heff_field(v_p_242, 3);
    V v_x_2473 = heff_field(v_p_242, 4);
    V v_mode_2474 = heff_field(v_p_242, 5);
    V v_k_2475 = heff_field(v_p_242, 6);
    V v_ru_24p_242_24OpenPath = heff_take_reuse_n(v_p_242, 127ULL, 7);
    return heff_tag_at_n(v_ru_24p_242_24OpenPath, TAG_OpenPath, 7, (V[]){v_path_2469, v_a_2470, v_c_2471, v_t_2472, v_x_2473, v_mode_2474, heff_clo_n(g_std_2efilesystem_2efilesystem_lam16, 1, 2, (V[]){v_k_2475, v_g_241})});
  }
  case TAG_Standard: {
    V v_i_2478 = heff_field(v_p_242, 0);
    V v_k_2479 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Standard = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Standard, TAG_Standard, 2, (V[]){v_i_2478, heff_clo_n(g_std_2efilesystem_2efilesystem_lam17, 1, 2, (V[]){v_k_2479, v_g_241})});
  }
  case TAG_ReadChunk: {
    V v_h_2482 = heff_field(v_p_242, 0);
    V v_n_2483 = heff_field(v_p_242, 1);
    V v_k_2484 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24ReadChunk = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24ReadChunk, TAG_ReadChunk, 3, (V[]){v_h_2482, v_n_2483, heff_clo_n(g_std_2efilesystem_2efilesystem_lam18, 1, 2, (V[]){v_k_2484, v_g_241})});
  }
  case TAG_ReadLine: {
    V v_h_2487 = heff_field(v_p_242, 0);
    V v_k_2488 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadLine = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ReadLine, TAG_ReadLine, 2, (V[]){v_h_2487, heff_clo_n(g_std_2efilesystem_2efilesystem_lam19, 1, 2, (V[]){v_k_2488, v_g_241})});
  }
  case TAG_WriteBytes: {
    V v_h_2491 = heff_field(v_p_242, 0);
    V v_b_2492 = heff_field(v_p_242, 1);
    V v_k_2493 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24WriteBytes = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24WriteBytes, TAG_WriteBytes, 3, (V[]){v_h_2491, v_b_2492, heff_clo_n(g_std_2efilesystem_2efilesystem_lam20, 1, 2, (V[]){v_k_2493, v_g_241})});
  }
  case TAG_WriteString: {
    V v_h_2496 = heff_field(v_p_242, 0);
    V v_s_2497 = heff_field(v_p_242, 1);
    V v_k_2498 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24WriteString = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24WriteString, TAG_WriteString, 3, (V[]){v_h_2496, v_s_2497, heff_clo_n(g_std_2efilesystem_2efilesystem_lam21, 1, 2, (V[]){v_k_2498, v_g_241})});
  }
  case TAG_Seek: {
    V v_h_24101 = heff_field(v_p_242, 0);
    V v_from_24102 = heff_field(v_p_242, 1);
    V v_n_24103 = heff_field(v_p_242, 2);
    V v_k_24104 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24Seek = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24Seek, TAG_Seek, 4, (V[]){v_h_24101, v_from_24102, v_n_24103, heff_clo_n(g_std_2efilesystem_2efilesystem_lam22, 1, 2, (V[]){v_k_24104, v_g_241})});
  }
  case TAG_HandleStatus: {
    V v_h_24107 = heff_field(v_p_242, 0);
    V v_k_24108 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24HandleStatus = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24HandleStatus, TAG_HandleStatus, 2, (V[]){v_h_24107, heff_clo_n(g_std_2efilesystem_2efilesystem_lam23, 1, 2, (V[]){v_k_24108, v_g_241})});
  }
  case TAG_CloseFile: {
    V v_h_24111 = heff_field(v_p_242, 0);
    V v_k_24112 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24CloseFile = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24CloseFile, TAG_CloseFile, 2, (V[]){v_h_24111, heff_clo_n(g_std_2efilesystem_2efilesystem_lam24, 1, 2, (V[]){v_k_24112, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2efilesystem_2efilesystem_lam25(V self, V *args) {
  V v_m_24115 = args[0];
  V v_n_24116 = args[1];
  V v_nt_24117 = args[2];
  V v_p_24118 = args[3];
  heff_drop(v_m_24115);
  heff_drop(v_n_24116);
  heff_drop(v_nt_24117);
  switch (heff_tag_of(v_p_24118)) {
  case TAG_ReadFile: {
    V v_path_24119 = heff_field(v_p_24118, 0);
    V v_k_24120 = heff_field(v_p_24118, 1);
    V v_ru_24p_24118_24ReadFile = heff_take_reuse_n(v_p_24118, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_24118_24ReadFile, TAG_ReadFile, 2, (V[]){v_path_24119, v_k_24120});
  }
  case TAG_WriteFile: {
    V v_path_24121 = heff_field(v_p_24118, 0);
    V v_str_24122 = heff_field(v_p_24118, 1);
    V v_k_24123 = heff_field(v_p_24118, 2);
    V v_ru_24p_24118_24WriteFile = heff_take_reuse_n(v_p_24118, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_24118_24WriteFile, TAG_WriteFile, 3, (V[]){v_path_24121, v_str_24122, v_k_24123});
  }
  case TAG_MakeDirectory: {
    V v_path_24124 = heff_field(v_p_24118, 0);
    V v_k_24125 = heff_field(v_p_24118, 1);
    V v_ru_24p_24118_24MakeDirectory = heff_take_reuse_n(v_p_24118, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_24118_24MakeDirectory, TAG_MakeDirectory, 2, (V[]){v_path_24124, v_k_24125});
  }
  case TAG_ReadDirectory: {
    V v_path_24126 = heff_field(v_p_24118, 0);
    V v_k_24127 = heff_field(v_p_24118, 1);
    V v_ru_24p_24118_24ReadDirectory = heff_take_reuse_n(v_p_24118, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_24118_24ReadDirectory, TAG_ReadDirectory, 2, (V[]){v_path_24126, v_k_24127});
  }
  case TAG_Remove: {
    V v_path_24128 = heff_field(v_p_24118, 0);
    V v_k_24129 = heff_field(v_p_24118, 1);
    V v_ru_24p_24118_24Remove = heff_take_reuse_n(v_p_24118, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_24118_24Remove, TAG_Remove, 2, (V[]){v_path_24128, v_k_24129});
  }
  case TAG_ReadOnly: {
    V v_path_24130 = heff_field(v_p_24118, 0);
    V v_k_24131 = heff_field(v_p_24118, 1);
    V v_ru_24p_24118_24ReadOnly = heff_take_reuse_n(v_p_24118, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_24118_24ReadOnly, TAG_ReadOnly, 2, (V[]){v_path_24130, v_k_24131});
  }
  case TAG_Copy: {
    V v_path_24132 = heff_field(v_p_24118, 0);
    V v_to_24133 = heff_field(v_p_24118, 1);
    V v_k_24134 = heff_field(v_p_24118, 2);
    V v_ru_24p_24118_24Copy = heff_take_reuse_n(v_p_24118, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_24118_24Copy, TAG_Copy, 3, (V[]){v_path_24132, v_to_24133, v_k_24134});
  }
  case TAG_Move: {
    V v_path_24135 = heff_field(v_p_24118, 0);
    V v_to_24136 = heff_field(v_p_24118, 1);
    V v_k_24137 = heff_field(v_p_24118, 2);
    V v_ru_24p_24118_24Move = heff_take_reuse_n(v_p_24118, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_24118_24Move, TAG_Move, 3, (V[]){v_path_24135, v_to_24136, v_k_24137});
  }
  case TAG_Replace: {
    V v_path_24138 = heff_field(v_p_24118, 0);
    V v_to_24139 = heff_field(v_p_24118, 1);
    V v_k_24140 = heff_field(v_p_24118, 2);
    V v_ru_24p_24118_24Replace = heff_take_reuse_n(v_p_24118, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_24118_24Replace, TAG_Replace, 3, (V[]){v_path_24138, v_to_24139, v_k_24140});
  }
  case TAG_Writable: {
    V v_path_24141 = heff_field(v_p_24118, 0);
    V v_k_24142 = heff_field(v_p_24118, 1);
    V v_ru_24p_24118_24Writable = heff_take_reuse_n(v_p_24118, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_24118_24Writable, TAG_Writable, 2, (V[]){v_path_24141, v_k_24142});
  }
  case TAG_PathStatus: {
    V v_path_24143 = heff_field(v_p_24118, 0);
    V v_follow_24144 = heff_field(v_p_24118, 1);
    V v_k_24145 = heff_field(v_p_24118, 2);
    V v_ru_24p_24118_24PathStatus = heff_take_reuse_n(v_p_24118, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_24118_24PathStatus, TAG_PathStatus, 3, (V[]){v_path_24143, v_follow_24144, v_k_24145});
  }
  case TAG_SetMode: {
    V v_path_24146 = heff_field(v_p_24118, 0);
    V v_mode_24147 = heff_field(v_p_24118, 1);
    V v_k_24148 = heff_field(v_p_24118, 2);
    V v_ru_24p_24118_24SetMode = heff_take_reuse_n(v_p_24118, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_24118_24SetMode, TAG_SetMode, 3, (V[]){v_path_24146, v_mode_24147, v_k_24148});
  }
  case TAG_RealPath: {
    V v_path_24149 = heff_field(v_p_24118, 0);
    V v_k_24150 = heff_field(v_p_24118, 1);
    V v_ru_24p_24118_24RealPath = heff_take_reuse_n(v_p_24118, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_24118_24RealPath, TAG_RealPath, 2, (V[]){v_path_24149, v_k_24150});
  }
  case TAG_TemporaryDirectory: {
    V v_prefix_24151 = heff_field(v_p_24118, 0);
    V v_k_24152 = heff_field(v_p_24118, 1);
    V v_ru_24p_24118_24TemporaryDirectory = heff_take_reuse_n(v_p_24118, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_24118_24TemporaryDirectory, TAG_TemporaryDirectory, 2, (V[]){v_prefix_24151, v_k_24152});
  }
  case TAG_TemporaryFile: {
    V v_prefix_24153 = heff_field(v_p_24118, 0);
    V v_k_24154 = heff_field(v_p_24118, 1);
    V v_ru_24p_24118_24TemporaryFile = heff_take_reuse_n(v_p_24118, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_24118_24TemporaryFile, TAG_TemporaryFile, 2, (V[]){v_prefix_24153, v_k_24154});
  }
  case TAG_OpenPath: {
    V v_path_24155 = heff_field(v_p_24118, 0);
    V v_a_24156 = heff_field(v_p_24118, 1);
    V v_c_24157 = heff_field(v_p_24118, 2);
    V v_t_24158 = heff_field(v_p_24118, 3);
    V v_x_24159 = heff_field(v_p_24118, 4);
    V v_mode_24160 = heff_field(v_p_24118, 5);
    V v_k_24161 = heff_field(v_p_24118, 6);
    V v_ru_24p_24118_24OpenPath = heff_take_reuse_n(v_p_24118, 127ULL, 7);
    return heff_tag_at_n(v_ru_24p_24118_24OpenPath, TAG_OpenPath, 7, (V[]){v_path_24155, v_a_24156, v_c_24157, v_t_24158, v_x_24159, v_mode_24160, v_k_24161});
  }
  case TAG_Standard: {
    V v_i_24162 = heff_field(v_p_24118, 0);
    V v_k_24163 = heff_field(v_p_24118, 1);
    V v_ru_24p_24118_24Standard = heff_take_reuse_n(v_p_24118, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_24118_24Standard, TAG_Standard, 2, (V[]){v_i_24162, v_k_24163});
  }
  case TAG_ReadChunk: {
    V v_h_24164 = heff_field(v_p_24118, 0);
    V v_n_24165 = heff_field(v_p_24118, 1);
    V v_k_24166 = heff_field(v_p_24118, 2);
    V v_ru_24p_24118_24ReadChunk = heff_take_reuse_n(v_p_24118, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_24118_24ReadChunk, TAG_ReadChunk, 3, (V[]){v_h_24164, v_n_24165, v_k_24166});
  }
  case TAG_ReadLine: {
    V v_h_24167 = heff_field(v_p_24118, 0);
    V v_k_24168 = heff_field(v_p_24118, 1);
    V v_ru_24p_24118_24ReadLine = heff_take_reuse_n(v_p_24118, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_24118_24ReadLine, TAG_ReadLine, 2, (V[]){v_h_24167, v_k_24168});
  }
  case TAG_WriteBytes: {
    V v_h_24169 = heff_field(v_p_24118, 0);
    V v_b_24170 = heff_field(v_p_24118, 1);
    V v_k_24171 = heff_field(v_p_24118, 2);
    V v_ru_24p_24118_24WriteBytes = heff_take_reuse_n(v_p_24118, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_24118_24WriteBytes, TAG_WriteBytes, 3, (V[]){v_h_24169, v_b_24170, v_k_24171});
  }
  case TAG_WriteString: {
    V v_h_24172 = heff_field(v_p_24118, 0);
    V v_s_24173 = heff_field(v_p_24118, 1);
    V v_k_24174 = heff_field(v_p_24118, 2);
    V v_ru_24p_24118_24WriteString = heff_take_reuse_n(v_p_24118, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_24118_24WriteString, TAG_WriteString, 3, (V[]){v_h_24172, v_s_24173, v_k_24174});
  }
  case TAG_Seek: {
    V v_h_24175 = heff_field(v_p_24118, 0);
    V v_from_24176 = heff_field(v_p_24118, 1);
    V v_n_24177 = heff_field(v_p_24118, 2);
    V v_k_24178 = heff_field(v_p_24118, 3);
    V v_ru_24p_24118_24Seek = heff_take_reuse_n(v_p_24118, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_24118_24Seek, TAG_Seek, 4, (V[]){v_h_24175, v_from_24176, v_n_24177, v_k_24178});
  }
  case TAG_HandleStatus: {
    V v_h_24179 = heff_field(v_p_24118, 0);
    V v_k_24180 = heff_field(v_p_24118, 1);
    V v_ru_24p_24118_24HandleStatus = heff_take_reuse_n(v_p_24118, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_24118_24HandleStatus, TAG_HandleStatus, 2, (V[]){v_h_24179, v_k_24180});
  }
  case TAG_CloseFile: {
    V v_h_24181 = heff_field(v_p_24118, 0);
    V v_k_24182 = heff_field(v_p_24118, 1);
    V v_ru_24p_24118_24CloseFile = heff_take_reuse_n(v_p_24118, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_24118_24CloseFile, TAG_CloseFile, 2, (V[]){v_h_24181, v_k_24182});
  }
  default: return heff_nomatch(v_p_24118);
  }
}