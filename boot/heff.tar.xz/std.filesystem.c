// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Copy 17796
#define TAG_MkDir 57961
#define TAG_Move 53768
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_ReadOnly 17623
#define TAG_Remove 9747
#define TAG_Replace 14236
#define TAG_WriteFile 62589
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_std_2efilesystem_2efs_get(void);
V g_std_2efilesystem_2efs_lam1(V self, V *args);
V g_std_2efilesystem_2efs_lam2(V self, V *args);
V g_std_2efilesystem_2efs_lam3(V self, V *args);
V g_std_2efilesystem_2efs_lam4(V self, V *args);
V g_std_2efilesystem_2efs_lam5(V self, V *args);
V g_std_2efilesystem_2efs_lam6(V self, V *args);
V g_std_2efilesystem_2efs_lam7(V self, V *args);
V g_std_2efilesystem_2efs_lam8(V self, V *args);
V g_std_2efilesystem_2efs_lam9(V self, V *args);
V g_std_2efilesystem_2efs_lam0(V self, V *args); static Clo g_std_2efilesystem_2efs_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2efs_lam0, 3, 0};
V g_std_2efilesystem_2efs_lam10(V self, V *args); static Clo g_std_2efilesystem_2efs_lam10_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2efs_lam10, 2, 0};

static V g_std_2efilesystem_2efs_val;
static int g_std_2efilesystem_2efs_st;
static V g_std_2efilesystem_2efs_init(void) {
  return heff_rec(2, shape_hfmap__hmap, (V[]){((V)&g_std_2efilesystem_2efs_lam0_clo), ((V)&g_std_2efilesystem_2efs_lam10_clo)});
}
V g_std_2efilesystem_2efs_get(void) {
  if (g_std_2efilesystem_2efs_st == 2) return g_std_2efilesystem_2efs_val;
  if (g_std_2efilesystem_2efs_st == 1) heff_fail("defined by itself");
  g_std_2efilesystem_2efs_st = 1;
  g_std_2efilesystem_2efs_val = heff_tr(g_std_2efilesystem_2efs_init());
  g_std_2efilesystem_2efs_st = 2;
  return g_std_2efilesystem_2efs_val;
}
V g_std_2efilesystem_2efs_lam1(V self, V *args) {
  V v_t_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_apply(v_k_244, 1, (V[]){v_t_245}));
  V f_ = v_g_241;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efs_lam2(V self, V *args) {
  V v_ok_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_tr(heff_apply(v_k_249, 1, (V[]){v_ok_2410}));
  V f_ = v_g_241;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efs_lam3(V self, V *args) {
  V v_ok_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_apply(v_k_2413, 1, (V[]){v_ok_2414}));
  V f_ = v_g_241;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efs_lam4(V self, V *args) {
  V v_ns_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_apply(v_k_2417, 1, (V[]){v_ns_2418}));
  V f_ = v_g_241;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efs_lam5(V self, V *args) {
  V v_ok_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_apply(v_k_2421, 1, (V[]){v_ok_2422}));
  V f_ = v_g_241;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efs_lam6(V self, V *args) {
  V v_ok_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_tr(heff_apply(v_k_2425, 1, (V[]){v_ok_2426}));
  V f_ = v_g_241;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efs_lam7(V self, V *args) {
  V v_ok_2431 = args[0];
  V v_k_2430 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_tr(heff_apply(v_k_2430, 1, (V[]){v_ok_2431}));
  V f_ = v_g_241;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efs_lam8(V self, V *args) {
  V v_ok_2436 = args[0];
  V v_k_2435 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_tr(heff_apply(v_k_2435, 1, (V[]){v_ok_2436}));
  V f_ = v_g_241;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efs_lam9(V self, V *args) {
  V v_ok_2441 = args[0];
  V v_k_2440 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442 = heff_tr(heff_apply(v_k_2440, 1, (V[]){v_ok_2441}));
  V f_ = v_g_241;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efs_lam0(V self, V *args) {
  V v_fm_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_fm_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_ReadFile: {
    V v_path_243 = heff_field(v_p_242, 0);
    V v_k_244 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadFile = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at(v_ru_24p_242_24ReadFile, TAG_ReadFile, 2, (V[]){v_path_243, heff_clo(g_std_2efilesystem_2efs_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
  }
  case TAG_WriteFile: {
    V v_path_247 = heff_field(v_p_242, 0);
    V v_str_248 = heff_field(v_p_242, 1);
    V v_k_249 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24WriteFile = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at(v_ru_24p_242_24WriteFile, TAG_WriteFile, 3, (V[]){v_path_247, v_str_248, heff_clo(g_std_2efilesystem_2efs_lam2, 1, 2, (V[]){v_k_249, v_g_241})});
  }
  case TAG_MkDir: {
    V v_path_2412 = heff_field(v_p_242, 0);
    V v_k_2413 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24MkDir = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at(v_ru_24p_242_24MkDir, TAG_MkDir, 2, (V[]){v_path_2412, heff_clo(g_std_2efilesystem_2efs_lam3, 1, 2, (V[]){v_k_2413, v_g_241})});
  }
  case TAG_ReadDir: {
    V v_path_2416 = heff_field(v_p_242, 0);
    V v_k_2417 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadDir = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at(v_ru_24p_242_24ReadDir, TAG_ReadDir, 2, (V[]){v_path_2416, heff_clo(g_std_2efilesystem_2efs_lam4, 1, 2, (V[]){v_k_2417, v_g_241})});
  }
  case TAG_Remove: {
    V v_path_2420 = heff_field(v_p_242, 0);
    V v_k_2421 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Remove = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at(v_ru_24p_242_24Remove, TAG_Remove, 2, (V[]){v_path_2420, heff_clo(g_std_2efilesystem_2efs_lam5, 1, 2, (V[]){v_k_2421, v_g_241})});
  }
  case TAG_ReadOnly: {
    V v_path_2424 = heff_field(v_p_242, 0);
    V v_k_2425 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadOnly = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at(v_ru_24p_242_24ReadOnly, TAG_ReadOnly, 2, (V[]){v_path_2424, heff_clo(g_std_2efilesystem_2efs_lam6, 1, 2, (V[]){v_k_2425, v_g_241})});
  }
  case TAG_Copy: {
    V v_path_2428 = heff_field(v_p_242, 0);
    V v_to_2429 = heff_field(v_p_242, 1);
    V v_k_2430 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Copy = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at(v_ru_24p_242_24Copy, TAG_Copy, 3, (V[]){v_path_2428, v_to_2429, heff_clo(g_std_2efilesystem_2efs_lam7, 1, 2, (V[]){v_k_2430, v_g_241})});
  }
  case TAG_Move: {
    V v_path_2433 = heff_field(v_p_242, 0);
    V v_to_2434 = heff_field(v_p_242, 1);
    V v_k_2435 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Move = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at(v_ru_24p_242_24Move, TAG_Move, 3, (V[]){v_path_2433, v_to_2434, heff_clo(g_std_2efilesystem_2efs_lam8, 1, 2, (V[]){v_k_2435, v_g_241})});
  }
  case TAG_Replace: {
    V v_path_2438 = heff_field(v_p_242, 0);
    V v_to_2439 = heff_field(v_p_242, 1);
    V v_k_2440 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Replace = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at(v_ru_24p_242_24Replace, TAG_Replace, 3, (V[]){v_path_2438, v_to_2439, heff_clo(g_std_2efilesystem_2efs_lam9, 1, 2, (V[]){v_k_2440, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2efilesystem_2efs_lam10(V self, V *args) {
  V v_nt_2443 = args[0];
  V v_p_2444 = args[1];
  heff_drop(v_nt_2443);
  switch (heff_tag_of(v_p_2444)) {
  case TAG_ReadFile: {
    V v_path_2445 = heff_field(v_p_2444, 0);
    V v_k_2446 = heff_field(v_p_2444, 1);
    V v_ru_24p_2444_24ReadFile = heff_take_reuse_n(v_p_2444, 3ULL, 2);
    return heff_tag_at(v_ru_24p_2444_24ReadFile, TAG_ReadFile, 2, (V[]){v_path_2445, v_k_2446});
  }
  case TAG_WriteFile: {
    V v_path_2447 = heff_field(v_p_2444, 0);
    V v_str_2448 = heff_field(v_p_2444, 1);
    V v_k_2449 = heff_field(v_p_2444, 2);
    V v_ru_24p_2444_24WriteFile = heff_take_reuse_n(v_p_2444, 7ULL, 3);
    return heff_tag_at(v_ru_24p_2444_24WriteFile, TAG_WriteFile, 3, (V[]){v_path_2447, v_str_2448, v_k_2449});
  }
  case TAG_MkDir: {
    V v_path_2450 = heff_field(v_p_2444, 0);
    V v_k_2451 = heff_field(v_p_2444, 1);
    V v_ru_24p_2444_24MkDir = heff_take_reuse_n(v_p_2444, 3ULL, 2);
    return heff_tag_at(v_ru_24p_2444_24MkDir, TAG_MkDir, 2, (V[]){v_path_2450, v_k_2451});
  }
  case TAG_ReadDir: {
    V v_path_2452 = heff_field(v_p_2444, 0);
    V v_k_2453 = heff_field(v_p_2444, 1);
    V v_ru_24p_2444_24ReadDir = heff_take_reuse_n(v_p_2444, 3ULL, 2);
    return heff_tag_at(v_ru_24p_2444_24ReadDir, TAG_ReadDir, 2, (V[]){v_path_2452, v_k_2453});
  }
  case TAG_Remove: {
    V v_path_2454 = heff_field(v_p_2444, 0);
    V v_k_2455 = heff_field(v_p_2444, 1);
    V v_ru_24p_2444_24Remove = heff_take_reuse_n(v_p_2444, 3ULL, 2);
    return heff_tag_at(v_ru_24p_2444_24Remove, TAG_Remove, 2, (V[]){v_path_2454, v_k_2455});
  }
  case TAG_ReadOnly: {
    V v_path_2456 = heff_field(v_p_2444, 0);
    V v_k_2457 = heff_field(v_p_2444, 1);
    V v_ru_24p_2444_24ReadOnly = heff_take_reuse_n(v_p_2444, 3ULL, 2);
    return heff_tag_at(v_ru_24p_2444_24ReadOnly, TAG_ReadOnly, 2, (V[]){v_path_2456, v_k_2457});
  }
  case TAG_Copy: {
    V v_path_2458 = heff_field(v_p_2444, 0);
    V v_to_2459 = heff_field(v_p_2444, 1);
    V v_k_2460 = heff_field(v_p_2444, 2);
    V v_ru_24p_2444_24Copy = heff_take_reuse_n(v_p_2444, 7ULL, 3);
    return heff_tag_at(v_ru_24p_2444_24Copy, TAG_Copy, 3, (V[]){v_path_2458, v_to_2459, v_k_2460});
  }
  case TAG_Move: {
    V v_path_2461 = heff_field(v_p_2444, 0);
    V v_to_2462 = heff_field(v_p_2444, 1);
    V v_k_2463 = heff_field(v_p_2444, 2);
    V v_ru_24p_2444_24Move = heff_take_reuse_n(v_p_2444, 7ULL, 3);
    return heff_tag_at(v_ru_24p_2444_24Move, TAG_Move, 3, (V[]){v_path_2461, v_to_2462, v_k_2463});
  }
  case TAG_Replace: {
    V v_path_2464 = heff_field(v_p_2444, 0);
    V v_to_2465 = heff_field(v_p_2444, 1);
    V v_k_2466 = heff_field(v_p_2444, 2);
    V v_ru_24p_2444_24Replace = heff_take_reuse_n(v_p_2444, 7ULL, 3);
    return heff_tag_at(v_ru_24p_2444_24Replace, TAG_Replace, 3, (V[]){v_path_2464, v_to_2465, v_k_2466});
  }
  default: return heff_nomatch(v_p_2444);
  }
}