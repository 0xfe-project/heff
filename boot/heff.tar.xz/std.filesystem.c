// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_std_2efilesystem_2efs_lam1(V self, V *args);
V g_std_2efilesystem_2efs_lam2(V self, V *args);
V g_std_2efilesystem_2efs_lam3(V self, V *args);
V g_std_2efilesystem_2efs_lam4(V self, V *args);
V g_std_2efilesystem_2efs_lam5(V self, V *args);
V g_std_2efilesystem_2efs_lam6(V self, V *args);
V g_std_2efilesystem_2efs_lam0(V self, V *args); static Clo g_std_2efilesystem_2efs_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2efs_lam0, 3, 0};
V g_std_2efilesystem_2efs_lam7(V self, V *args); static Clo g_std_2efilesystem_2efs_lam7_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2efs_lam7, 2, 0};

static V g_std_2efilesystem_2efs_val;
static int g_std_2efilesystem_2efs_st;
static V g_std_2efilesystem_2efs_init(void) {
  return heff_rec(2, shape_119_121, (V[]){((V)&g_std_2efilesystem_2efs_lam0_clo), ((V)&g_std_2efilesystem_2efs_lam7_clo)});
}
V g_std_2efilesystem_2efs_get(void) {
  if (g_std_2efilesystem_2efs_st == 2) return g_std_2efilesystem_2efs_val;
  if (g_std_2efilesystem_2efs_st == 1) heff_fail("defined by itself");
  g_std_2efilesystem_2efs_st = 1;
  g_std_2efilesystem_2efs_val = heff_tr(g_std_2efilesystem_2efs_init());
  g_std_2efilesystem_2efs_st = 2;
  return g_std_2efilesystem_2efs_val;
}
V g_std_2efilesystem_2efs_lam1(V self, V *args) {
  V v_t_245 = args[0];
  V v_k_244 = heff_dup(heff_env(self)[0]);
  V v_g_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_246 = heff_tr(heff_apply(v_k_244, 1, (V[]){v_t_245}));
  return heff_tail(v_g_241, 1, (V[]){v_t_246});
}
V g_std_2efilesystem_2efs_lam2(V self, V *args) {
  V v_ok_2410 = args[0];
  V v_k_249 = heff_dup(heff_env(self)[0]);
  V v_g_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2411 = heff_tr(heff_apply(v_k_249, 1, (V[]){v_ok_2410}));
  return heff_tail(v_g_241, 1, (V[]){v_t_2411});
}
V g_std_2efilesystem_2efs_lam3(V self, V *args) {
  V v_ok_2414 = args[0];
  V v_k_2413 = heff_dup(heff_env(self)[0]);
  V v_g_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2415 = heff_tr(heff_apply(v_k_2413, 1, (V[]){v_ok_2414}));
  return heff_tail(v_g_241, 1, (V[]){v_t_2415});
}
V g_std_2efilesystem_2efs_lam4(V self, V *args) {
  V v_ns_2418 = args[0];
  V v_k_2417 = heff_dup(heff_env(self)[0]);
  V v_g_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2419 = heff_tr(heff_apply(v_k_2417, 1, (V[]){v_ns_2418}));
  return heff_tail(v_g_241, 1, (V[]){v_t_2419});
}
V g_std_2efilesystem_2efs_lam5(V self, V *args) {
  V v_ok_2422 = args[0];
  V v_k_2421 = heff_dup(heff_env(self)[0]);
  V v_g_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2423 = heff_tr(heff_apply(v_k_2421, 1, (V[]){v_ok_2422}));
  return heff_tail(v_g_241, 1, (V[]){v_t_2423});
}
V g_std_2efilesystem_2efs_lam6(V self, V *args) {
  V v_ok_2426 = args[0];
  V v_k_2425 = heff_dup(heff_env(self)[0]);
  V v_g_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2427 = heff_tr(heff_apply(v_k_2425, 1, (V[]){v_ok_2426}));
  return heff_tail(v_g_241, 1, (V[]){v_t_2427});
}
V g_std_2efilesystem_2efs_lam0(V self, V *args) {
  V v_fm_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(self);
  heff_drop(v_fm_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_ReadFile: {
    V v_path_243 = heff_field(v_p_242, 0);
    V v_k_244 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadFile = heff_take_reuse(v_p_242, 3ULL);
    return heff_tag_at(v_ru_24p_242_24ReadFile, TAG_ReadFile, 2, (V[]){v_path_243, heff_clo(g_std_2efilesystem_2efs_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
  }
  case TAG_WriteFile: {
    V v_path_247 = heff_field(v_p_242, 0);
    V v_str_248 = heff_field(v_p_242, 1);
    V v_k_249 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24WriteFile = heff_take_reuse(v_p_242, 7ULL);
    return heff_tag_at(v_ru_24p_242_24WriteFile, TAG_WriteFile, 3, (V[]){v_path_247, v_str_248, heff_clo(g_std_2efilesystem_2efs_lam2, 1, 2, (V[]){v_k_249, v_g_241})});
  }
  case TAG_MkDir: {
    V v_path_2412 = heff_field(v_p_242, 0);
    V v_k_2413 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24MkDir = heff_take_reuse(v_p_242, 3ULL);
    return heff_tag_at(v_ru_24p_242_24MkDir, TAG_MkDir, 2, (V[]){v_path_2412, heff_clo(g_std_2efilesystem_2efs_lam3, 1, 2, (V[]){v_k_2413, v_g_241})});
  }
  case TAG_ReadDir: {
    V v_path_2416 = heff_field(v_p_242, 0);
    V v_k_2417 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadDir = heff_take_reuse(v_p_242, 3ULL);
    return heff_tag_at(v_ru_24p_242_24ReadDir, TAG_ReadDir, 2, (V[]){v_path_2416, heff_clo(g_std_2efilesystem_2efs_lam4, 1, 2, (V[]){v_k_2417, v_g_241})});
  }
  case TAG_Remove: {
    V v_path_2420 = heff_field(v_p_242, 0);
    V v_k_2421 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Remove = heff_take_reuse(v_p_242, 3ULL);
    return heff_tag_at(v_ru_24p_242_24Remove, TAG_Remove, 2, (V[]){v_path_2420, heff_clo(g_std_2efilesystem_2efs_lam5, 1, 2, (V[]){v_k_2421, v_g_241})});
  }
  case TAG_ReadOnly: {
    V v_path_2424 = heff_field(v_p_242, 0);
    V v_k_2425 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadOnly = heff_take_reuse(v_p_242, 3ULL);
    return heff_tag_at(v_ru_24p_242_24ReadOnly, TAG_ReadOnly, 2, (V[]){v_path_2424, heff_clo(g_std_2efilesystem_2efs_lam6, 1, 2, (V[]){v_k_2425, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2efilesystem_2efs_lam7(V self, V *args) {
  V v_nt_2428 = args[0];
  V v_p_2429 = args[1];
  heff_drop(self);
  heff_drop(v_nt_2428);
  switch (heff_tag_of(v_p_2429)) {
  case TAG_ReadFile: {
    V v_path_2430 = heff_field(v_p_2429, 0);
    V v_k_2431 = heff_field(v_p_2429, 1);
    V v_ru_24p_2429_24ReadFile = heff_take_reuse(v_p_2429, 3ULL);
    return heff_tag_at(v_ru_24p_2429_24ReadFile, TAG_ReadFile, 2, (V[]){v_path_2430, v_k_2431});
  }
  case TAG_WriteFile: {
    V v_path_2432 = heff_field(v_p_2429, 0);
    V v_str_2433 = heff_field(v_p_2429, 1);
    V v_k_2434 = heff_field(v_p_2429, 2);
    V v_ru_24p_2429_24WriteFile = heff_take_reuse(v_p_2429, 7ULL);
    return heff_tag_at(v_ru_24p_2429_24WriteFile, TAG_WriteFile, 3, (V[]){v_path_2432, v_str_2433, v_k_2434});
  }
  case TAG_MkDir: {
    V v_path_2435 = heff_field(v_p_2429, 0);
    V v_k_2436 = heff_field(v_p_2429, 1);
    V v_ru_24p_2429_24MkDir = heff_take_reuse(v_p_2429, 3ULL);
    return heff_tag_at(v_ru_24p_2429_24MkDir, TAG_MkDir, 2, (V[]){v_path_2435, v_k_2436});
  }
  case TAG_ReadDir: {
    V v_path_2437 = heff_field(v_p_2429, 0);
    V v_k_2438 = heff_field(v_p_2429, 1);
    V v_ru_24p_2429_24ReadDir = heff_take_reuse(v_p_2429, 3ULL);
    return heff_tag_at(v_ru_24p_2429_24ReadDir, TAG_ReadDir, 2, (V[]){v_path_2437, v_k_2438});
  }
  case TAG_Remove: {
    V v_path_2439 = heff_field(v_p_2429, 0);
    V v_k_2440 = heff_field(v_p_2429, 1);
    V v_ru_24p_2429_24Remove = heff_take_reuse(v_p_2429, 3ULL);
    return heff_tag_at(v_ru_24p_2429_24Remove, TAG_Remove, 2, (V[]){v_path_2439, v_k_2440});
  }
  case TAG_ReadOnly: {
    V v_path_2441 = heff_field(v_p_2429, 0);
    V v_k_2442 = heff_field(v_p_2429, 1);
    V v_ru_24p_2429_24ReadOnly = heff_take_reuse(v_p_2429, 3ULL);
    return heff_tag_at(v_ru_24p_2429_24ReadOnly, TAG_ReadOnly, 2, (V[]){v_path_2441, v_k_2442});
  }
  default: return heff_nomatch(v_p_2429);
  }
}