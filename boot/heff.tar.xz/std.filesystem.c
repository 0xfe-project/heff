// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CloseFile 52884
#define TAG_Copy 17796
#define TAG_Directory 35277
#define TAG_FileStatus 2909
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_MakeDirectory 16793
#define TAG_Move 53768
#define TAG_OpenPath 44468
#define TAG_Other 45236
#define TAG_PathStatus 29154
#define TAG_ReadChunk 39695
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_ReadLine 54539
#define TAG_ReadLink 54545
#define TAG_ReadOnly 17623
#define TAG_RealPath 18882
#define TAG_Regular 40886
#define TAG_Remove 9747
#define TAG_Replace 14236
#define TAG_Right 62770
#define TAG_Seek 25805
#define TAG_SetMode 203
#define TAG_Standard 18554
#define TAG_TemporaryDirectory 61563
#define TAG_TemporaryFile 11955
#define TAG_Throw 56084
#define TAG_Writable 11315
#define TAG_WriteBytes 40855
#define TAG_WriteFile 62589
#define TAG_WriteString 34128
#define LBL_bind 9519364
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_kind 9787483
#define LBL_malg 9839318
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_co_2eop_24s1138723349x835120997(V, V, V);
V g_co_2eop_24s1138723349x835120997_entry(V self, V *a);
extern Clo g_co_2eop_24s1138723349x835120997_clo;
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1628839587x1321325607(V, V, V, V);
V g_co_2eop_24s1628839587x1321325607_entry(V self, V *a);
extern Clo g_co_2eop_24s1628839587x1321325607_clo;
V g_co_2eop_24s1876960293x1282655859(V, V, V);
V g_co_2eop_24s1876960293x1282655859_entry(V self, V *a);
extern Clo g_co_2eop_24s1876960293x1282655859_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_co_2eop_24s574817332x141721203(V);
V g_co_2eop_24s574817332x141721203_entry(V self, V *a);
extern Clo g_co_2eop_24s574817332x141721203_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_std_2efilesystem_2ecopy_24s1896001459x769612981(V, V);
V g_std_2efilesystem_2ecopy_24s1896001459x769612981_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ecopy_24s1896001459x769612981_clo;
V g_std_2efilesystem_2efilesystem_get(void);
V g_std_2efilesystem_2efromSystem_24s1003849434x1875331781(V);
V g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_entry(V self, V *a);
extern Clo g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_clo;
V g_std_2efilesystem_2eisDirectory_24s742424059x1763865794(V);
V g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_clo;
V g_std_2efilesystem_2eisFile(V, V, V);
V g_std_2efilesystem_2eisFile_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eisFile_clo;
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(V);
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_clo;
V g_std_2efilesystem_2emove_24s1656294343x318667886(V, V);
V g_std_2efilesystem_2emove_24s1656294343x318667886_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emove_24s1656294343x318667886_clo;
V g_std_2efilesystem_2epathStatus_24s1180173567x1248178148(V);
V g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_entry(V self, V *a);
extern Clo g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_clo;
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351(V, V, V);
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_clo;
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(V);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
V g_std_2efilesystem_2ereadFile_24s597359330x237736700(V, V, V);
V g_std_2efilesystem_2ereadFile_24s597359330x237736700_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s597359330x237736700_clo;
V g_std_2efilesystem_2ereadOnly_24s423320184x164941529(V);
V g_std_2efilesystem_2ereadOnly_24s423320184x164941529_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadOnly_24s423320184x164941529_clo;
V g_std_2efilesystem_2eremove_24s1441356369x419789784(V);
V g_std_2efilesystem_2eremove_24s1441356369x419789784_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eremove_24s1441356369x419789784_clo;
V g_std_2efilesystem_2ereplace_24s174842679x636132898(V, V);
V g_std_2efilesystem_2ereplace_24s174842679x636132898_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereplace_24s174842679x636132898_clo;
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(V, V);
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2efilesystem_2efilesystem_lam1(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam2(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam3(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam4(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam5(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam6(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam7(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam8(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam9(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam10(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam11(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam12(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam13(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam14(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam15(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam16(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam17(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam18(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam19(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam20(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam21(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam22(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam23(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam24(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam25(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam0(V self, V *args); static Clo g_std_2efilesystem_2efilesystem_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2efilesystem_lam0, 3, 0};
V g_std_2efilesystem_2efilesystem_lam26(V self, V *args); static Clo g_std_2efilesystem_2efilesystem_lam26_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2efilesystem_lam26, 4, 0};

static V g_std_2efilesystem_2efilesystem_val;
static HEFF_ONCE g_std_2efilesystem_2efilesystem_st;
static V g_std_2efilesystem_2efilesystem_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2efilesystem_2efilesystem_lam0_clo), ((V)&g_std_2efilesystem_2efilesystem_lam26_clo)});
}
V g_std_2efilesystem_2efilesystem_get(void) {
  if (HEFF_DONE(g_std_2efilesystem_2efilesystem_st)) return g_std_2efilesystem_2efilesystem_val;
  return heff_global(&g_std_2efilesystem_2efilesystem_val, &g_std_2efilesystem_2efilesystem_st, g_std_2efilesystem_2efilesystem_init);
}
V g_std_2efilesystem_2efilesystem_lam1(V self, V *args) {
  V v_t_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_k_244, 1, (V[]){v_t_245}));
  V f_ = v_g_241;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam2(V self, V *args) {
  V v_ok_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_tr(heff_call(v_k_249, 1, (V[]){v_ok_2410}));
  V f_ = v_g_241;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam3(V self, V *args) {
  V v_ok_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_k_2413, 1, (V[]){v_ok_2414}));
  V f_ = v_g_241;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam4(V self, V *args) {
  V v_ns_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_k_2417, 1, (V[]){v_ns_2418}));
  V f_ = v_g_241;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam5(V self, V *args) {
  V v_ok_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_call(v_k_2421, 1, (V[]){v_ok_2422}));
  V f_ = v_g_241;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam6(V self, V *args) {
  V v_ok_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_tr(heff_call(v_k_2425, 1, (V[]){v_ok_2426}));
  V f_ = v_g_241;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam7(V self, V *args) {
  V v_ok_2431 = args[0];
  V v_k_2430 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_tr(heff_call(v_k_2430, 1, (V[]){v_ok_2431}));
  V f_ = v_g_241;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam8(V self, V *args) {
  V v_ok_2436 = args[0];
  V v_k_2435 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_tr(heff_call(v_k_2435, 1, (V[]){v_ok_2436}));
  V f_ = v_g_241;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam9(V self, V *args) {
  V v_ok_2441 = args[0];
  V v_k_2440 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442 = heff_tr(heff_call(v_k_2440, 1, (V[]){v_ok_2441}));
  V f_ = v_g_241;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam10(V self, V *args) {
  V v_ok_2445 = args[0];
  V v_k_2444 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_tr(heff_call(v_k_2444, 1, (V[]){v_ok_2445}));
  V f_ = v_g_241;
  args[0] = v_t_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam11(V self, V *args) {
  V v_r_2450 = args[0];
  V v_k_2449 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_tr(heff_call(v_k_2449, 1, (V[]){v_r_2450}));
  V f_ = v_g_241;
  args[0] = v_t_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam12(V self, V *args) {
  V v_r_2455 = args[0];
  V v_k_2454 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2456 = heff_tr(heff_call(v_k_2454, 1, (V[]){v_r_2455}));
  V f_ = v_g_241;
  args[0] = v_t_2456;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam13(V self, V *args) {
  V v_r_2459 = args[0];
  V v_k_2458 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2460 = heff_tr(heff_call(v_k_2458, 1, (V[]){v_r_2459}));
  V f_ = v_g_241;
  args[0] = v_t_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam14(V self, V *args) {
  V v_r_2463 = args[0];
  V v_k_2462 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2464 = heff_tr(heff_call(v_k_2462, 1, (V[]){v_r_2463}));
  V f_ = v_g_241;
  args[0] = v_t_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam15(V self, V *args) {
  V v_r_2467 = args[0];
  V v_k_2466 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2468 = heff_tr(heff_call(v_k_2466, 1, (V[]){v_r_2467}));
  V f_ = v_g_241;
  args[0] = v_t_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam16(V self, V *args) {
  V v_r_2471 = args[0];
  V v_k_2470 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2472 = heff_tr(heff_call(v_k_2470, 1, (V[]){v_r_2471}));
  V f_ = v_g_241;
  args[0] = v_t_2472;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam17(V self, V *args) {
  V v_r_2480 = args[0];
  V v_k_2479 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2481 = heff_tr(heff_call(v_k_2479, 1, (V[]){v_r_2480}));
  V f_ = v_g_241;
  args[0] = v_t_2481;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam18(V self, V *args) {
  V v_h_2484 = args[0];
  V v_k_2483 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2485 = heff_tr(heff_call(v_k_2483, 1, (V[]){v_h_2484}));
  V f_ = v_g_241;
  args[0] = v_t_2485;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam19(V self, V *args) {
  V v_r_2489 = args[0];
  V v_k_2488 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2490 = heff_tr(heff_call(v_k_2488, 1, (V[]){v_r_2489}));
  V f_ = v_g_241;
  args[0] = v_t_2490;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam20(V self, V *args) {
  V v_r_2493 = args[0];
  V v_k_2492 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2494 = heff_tr(heff_call(v_k_2492, 1, (V[]){v_r_2493}));
  V f_ = v_g_241;
  args[0] = v_t_2494;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam21(V self, V *args) {
  V v_r_2498 = args[0];
  V v_k_2497 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2499 = heff_tr(heff_call(v_k_2497, 1, (V[]){v_r_2498}));
  V f_ = v_g_241;
  args[0] = v_t_2499;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam22(V self, V *args) {
  V v_r_24103 = args[0];
  V v_k_24102 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24104 = heff_tr(heff_call(v_k_24102, 1, (V[]){v_r_24103}));
  V f_ = v_g_241;
  args[0] = v_t_24104;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam23(V self, V *args) {
  V v_r_24109 = args[0];
  V v_k_24108 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24110 = heff_tr(heff_call(v_k_24108, 1, (V[]){v_r_24109}));
  V f_ = v_g_241;
  args[0] = v_t_24110;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam24(V self, V *args) {
  V v_r_24113 = args[0];
  V v_k_24112 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24114 = heff_tr(heff_call(v_k_24112, 1, (V[]){v_r_24113}));
  V f_ = v_g_241;
  args[0] = v_t_24114;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam25(V self, V *args) {
  V v_r_24117 = args[0];
  V v_k_24116 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24118 = heff_tr(heff_call(v_k_24116, 1, (V[]){v_r_24117}));
  V f_ = v_g_241;
  args[0] = v_t_24118;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_ReadFile: {
    V v_path_243 = heff_field(v_p_242, 0);
    V v_k_244 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadFile = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ReadFile, TAG_ReadFile, 2, (V[]){v_path_243, heff_clo_n(g_std_2efilesystem_2efilesystem_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
  }
  case TAG_WriteFile: {
    V v_path_247 = heff_field(v_p_242, 0);
    V v_str_248 = heff_field(v_p_242, 1);
    V v_k_249 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24WriteFile = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24WriteFile, TAG_WriteFile, 3, (V[]){v_path_247, v_str_248, heff_clo_n(g_std_2efilesystem_2efilesystem_lam2, 1, 2, (V[]){v_k_249, v_g_241})});
  }
  case TAG_MakeDirectory: {
    V v_path_2412 = heff_field(v_p_242, 0);
    V v_k_2413 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24MakeDirectory = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24MakeDirectory, TAG_MakeDirectory, 2, (V[]){v_path_2412, heff_clo_n(g_std_2efilesystem_2efilesystem_lam3, 1, 2, (V[]){v_k_2413, v_g_241})});
  }
  case TAG_ReadDirectory: {
    V v_path_2416 = heff_field(v_p_242, 0);
    V v_k_2417 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadDirectory = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ReadDirectory, TAG_ReadDirectory, 2, (V[]){v_path_2416, heff_clo_n(g_std_2efilesystem_2efilesystem_lam4, 1, 2, (V[]){v_k_2417, v_g_241})});
  }
  case TAG_Remove: {
    V v_path_2420 = heff_field(v_p_242, 0);
    V v_k_2421 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Remove = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Remove, TAG_Remove, 2, (V[]){v_path_2420, heff_clo_n(g_std_2efilesystem_2efilesystem_lam5, 1, 2, (V[]){v_k_2421, v_g_241})});
  }
  case TAG_ReadOnly: {
    V v_path_2424 = heff_field(v_p_242, 0);
    V v_k_2425 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadOnly = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ReadOnly, TAG_ReadOnly, 2, (V[]){v_path_2424, heff_clo_n(g_std_2efilesystem_2efilesystem_lam6, 1, 2, (V[]){v_k_2425, v_g_241})});
  }
  case TAG_Copy: {
    V v_path_2428 = heff_field(v_p_242, 0);
    V v_to_2429 = heff_field(v_p_242, 1);
    V v_k_2430 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Copy = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Copy, TAG_Copy, 3, (V[]){v_path_2428, v_to_2429, heff_clo_n(g_std_2efilesystem_2efilesystem_lam7, 1, 2, (V[]){v_k_2430, v_g_241})});
  }
  case TAG_Move: {
    V v_path_2433 = heff_field(v_p_242, 0);
    V v_to_2434 = heff_field(v_p_242, 1);
    V v_k_2435 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Move = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Move, TAG_Move, 3, (V[]){v_path_2433, v_to_2434, heff_clo_n(g_std_2efilesystem_2efilesystem_lam8, 1, 2, (V[]){v_k_2435, v_g_241})});
  }
  case TAG_Replace: {
    V v_path_2438 = heff_field(v_p_242, 0);
    V v_to_2439 = heff_field(v_p_242, 1);
    V v_k_2440 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Replace = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Replace, TAG_Replace, 3, (V[]){v_path_2438, v_to_2439, heff_clo_n(g_std_2efilesystem_2efilesystem_lam9, 1, 2, (V[]){v_k_2440, v_g_241})});
  }
  case TAG_Writable: {
    V v_path_2443 = heff_field(v_p_242, 0);
    V v_k_2444 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Writable = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Writable, TAG_Writable, 2, (V[]){v_path_2443, heff_clo_n(g_std_2efilesystem_2efilesystem_lam10, 1, 2, (V[]){v_k_2444, v_g_241})});
  }
  case TAG_PathStatus: {
    V v_path_2447 = heff_field(v_p_242, 0);
    V v_follow_2448 = heff_field(v_p_242, 1);
    V v_k_2449 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24PathStatus = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24PathStatus, TAG_PathStatus, 3, (V[]){v_path_2447, v_follow_2448, heff_clo_n(g_std_2efilesystem_2efilesystem_lam11, 1, 2, (V[]){v_k_2449, v_g_241})});
  }
  case TAG_SetMode: {
    V v_path_2452 = heff_field(v_p_242, 0);
    V v_mode_2453 = heff_field(v_p_242, 1);
    V v_k_2454 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24SetMode = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24SetMode, TAG_SetMode, 3, (V[]){v_path_2452, v_mode_2453, heff_clo_n(g_std_2efilesystem_2efilesystem_lam12, 1, 2, (V[]){v_k_2454, v_g_241})});
  }
  case TAG_RealPath: {
    V v_path_2457 = heff_field(v_p_242, 0);
    V v_k_2458 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24RealPath = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24RealPath, TAG_RealPath, 2, (V[]){v_path_2457, heff_clo_n(g_std_2efilesystem_2efilesystem_lam13, 1, 2, (V[]){v_k_2458, v_g_241})});
  }
  case TAG_ReadLink: {
    V v_path_2461 = heff_field(v_p_242, 0);
    V v_k_2462 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadLink = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ReadLink, TAG_ReadLink, 2, (V[]){v_path_2461, heff_clo_n(g_std_2efilesystem_2efilesystem_lam14, 1, 2, (V[]){v_k_2462, v_g_241})});
  }
  case TAG_TemporaryDirectory: {
    V v_prefix_2465 = heff_field(v_p_242, 0);
    V v_k_2466 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24TemporaryDirectory = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24TemporaryDirectory, TAG_TemporaryDirectory, 2, (V[]){v_prefix_2465, heff_clo_n(g_std_2efilesystem_2efilesystem_lam15, 1, 2, (V[]){v_k_2466, v_g_241})});
  }
  case TAG_TemporaryFile: {
    V v_prefix_2469 = heff_field(v_p_242, 0);
    V v_k_2470 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24TemporaryFile = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24TemporaryFile, TAG_TemporaryFile, 2, (V[]){v_prefix_2469, heff_clo_n(g_std_2efilesystem_2efilesystem_lam16, 1, 2, (V[]){v_k_2470, v_g_241})});
  }
  case TAG_OpenPath: {
    V v_path_2473 = heff_field(v_p_242, 0);
    V v_a_2474 = heff_field(v_p_242, 1);
    V v_c_2475 = heff_field(v_p_242, 2);
    V v_t_2476 = heff_field(v_p_242, 3);
    V v_x_2477 = heff_field(v_p_242, 4);
    V v_mode_2478 = heff_field(v_p_242, 5);
    V v_k_2479 = heff_field(v_p_242, 6);
    V v_ru_24p_242_24OpenPath = heff_take_reuse_n(v_p_242, 127ULL, 7);
    return heff_tag_at_n(v_ru_24p_242_24OpenPath, TAG_OpenPath, 7, (V[]){v_path_2473, v_a_2474, v_c_2475, v_t_2476, v_x_2477, v_mode_2478, heff_clo_n(g_std_2efilesystem_2efilesystem_lam17, 1, 2, (V[]){v_k_2479, v_g_241})});
  }
  case TAG_Standard: {
    V v_i_2482 = heff_field(v_p_242, 0);
    V v_k_2483 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Standard = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Standard, TAG_Standard, 2, (V[]){v_i_2482, heff_clo_n(g_std_2efilesystem_2efilesystem_lam18, 1, 2, (V[]){v_k_2483, v_g_241})});
  }
  case TAG_ReadChunk: {
    V v_h_2486 = heff_field(v_p_242, 0);
    V v_n_2487 = heff_field(v_p_242, 1);
    V v_k_2488 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24ReadChunk = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24ReadChunk, TAG_ReadChunk, 3, (V[]){v_h_2486, v_n_2487, heff_clo_n(g_std_2efilesystem_2efilesystem_lam19, 1, 2, (V[]){v_k_2488, v_g_241})});
  }
  case TAG_ReadLine: {
    V v_h_2491 = heff_field(v_p_242, 0);
    V v_k_2492 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadLine = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24ReadLine, TAG_ReadLine, 2, (V[]){v_h_2491, heff_clo_n(g_std_2efilesystem_2efilesystem_lam20, 1, 2, (V[]){v_k_2492, v_g_241})});
  }
  case TAG_WriteBytes: {
    V v_h_2495 = heff_field(v_p_242, 0);
    V v_b_2496 = heff_field(v_p_242, 1);
    V v_k_2497 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24WriteBytes = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24WriteBytes, TAG_WriteBytes, 3, (V[]){v_h_2495, v_b_2496, heff_clo_n(g_std_2efilesystem_2efilesystem_lam21, 1, 2, (V[]){v_k_2497, v_g_241})});
  }
  case TAG_WriteString: {
    V v_h_24100 = heff_field(v_p_242, 0);
    V v_s_24101 = heff_field(v_p_242, 1);
    V v_k_24102 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24WriteString = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24WriteString, TAG_WriteString, 3, (V[]){v_h_24100, v_s_24101, heff_clo_n(g_std_2efilesystem_2efilesystem_lam22, 1, 2, (V[]){v_k_24102, v_g_241})});
  }
  case TAG_Seek: {
    V v_h_24105 = heff_field(v_p_242, 0);
    V v_from_24106 = heff_field(v_p_242, 1);
    V v_n_24107 = heff_field(v_p_242, 2);
    V v_k_24108 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24Seek = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24Seek, TAG_Seek, 4, (V[]){v_h_24105, v_from_24106, v_n_24107, heff_clo_n(g_std_2efilesystem_2efilesystem_lam23, 1, 2, (V[]){v_k_24108, v_g_241})});
  }
  case TAG_FileStatus: {
    V v_h_24111 = heff_field(v_p_242, 0);
    V v_k_24112 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24FileStatus = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24FileStatus, TAG_FileStatus, 2, (V[]){v_h_24111, heff_clo_n(g_std_2efilesystem_2efilesystem_lam24, 1, 2, (V[]){v_k_24112, v_g_241})});
  }
  case TAG_CloseFile: {
    V v_h_24115 = heff_field(v_p_242, 0);
    V v_k_24116 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24CloseFile = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24CloseFile, TAG_CloseFile, 2, (V[]){v_h_24115, heff_clo_n(g_std_2efilesystem_2efilesystem_lam25, 1, 2, (V[]){v_k_24116, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2efilesystem_2efilesystem_lam26(V self, V *args) {
  V v_m_24119 = args[0];
  V v_n_24120 = args[1];
  V v_nt_24121 = args[2];
  V v_p_24122 = args[3];
  heff_drop(v_m_24119);
  heff_drop(v_n_24120);
  heff_drop(v_nt_24121);
  return v_p_24122;
}
V g_std_2efilesystem_2eisFile_lam0(V self, V *args); static Clo g_std_2efilesystem_2eisFile_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2eisFile_lam0, 1, 0};
V g_std_2efilesystem_2eisFile_lam2(V self, V *args);
V g_std_2efilesystem_2eisFile_lam1(V self, V *args);
Clo g_std_2efilesystem_2eisFile_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2eisFile_entry, 3, 0};

V g_std_2efilesystem_2eisFile(V v_e_240, V v_ev_241, V v_path_242) {
top: ;
  V v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_242; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_t_243, NTAG(TAG_True), ((V)&g_std_2efilesystem_2eisFile_lam0_clo)});
  V v_t_246 = heff_tr(heff_call(v_ev_241, 1, (V[]){v_t_245}));
  return heff_clo_n(g_std_2efilesystem_2eisFile_lam1, 2, 2, (V[]){v_e_240, v_t_246});
}
V g_std_2efilesystem_2eisFile_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2efilesystem_2eisFile(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_std_2efilesystem_2eisFile_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_std_2efilesystem_2eisFile_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    heff_take_n(v_x_249, 0ULL, 1);
    V f_ = v_k_248;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_2411 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2412 = heff_get_n(v_s_2411, 0, 4);
    V v_t_2413;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Regular: {
      v_t_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_Directory: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_Link: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V f_ = v_k_248;
    args[0] = v_t_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_std_2efilesystem_2eisFile_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_t_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_246, v_hd_247, heff_clo_n(g_std_2efilesystem_2eisFile_lam2, 1, 1, (V[]){v_k_248})));
}
V g_std_2efilesystem_2ereadFile_24s597359330x237736700_lam0(V self, V *args); static Clo g_std_2efilesystem_2ereadFile_24s597359330x237736700_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ereadFile_24s597359330x237736700_lam0, 1, 0};
V g_std_2efilesystem_2ereadFile_24s597359330x237736700_lam2(V self, V *args);
V g_std_2efilesystem_2ereadFile_24s597359330x237736700_lam1(V self, V *args);
Clo g_std_2efilesystem_2ereadFile_24s597359330x237736700_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ereadFile_24s597359330x237736700_entry, 3, 0};

V g_std_2efilesystem_2ereadFile_24s597359330x237736700(V v_lit_240, V v_ev_241, V v_path_242) {
top: ;
  V v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_242; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = heff_tr(heff_call(v_ev_241, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_243, ((V)&g_std_2efilesystem_2ereadFile_24s597359330x237736700_lam0_clo)})}));
  return heff_clo_n(g_std_2efilesystem_2ereadFile_24s597359330x237736700_lam1, 2, 2, (V[]){v_lit_240, v_t_245});
}
V g_std_2efilesystem_2ereadFile_24s597359330x237736700_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2efilesystem_2ereadFile_24s597359330x237736700(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_std_2efilesystem_2ereadFile_24s597359330x237736700_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_std_2efilesystem_2ereadFile_24s597359330x237736700_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Left: {
    V v_err_249 = heff_field(v_x_248, 0);
    V v_ru_24x_248_24Left = heff_take_reuse_n(v_x_248, 1ULL, 1);
    V v_t_2410 = heff_tag_at_n(v_ru_24x_248_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_249})});
    V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2410}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2411;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_x_2412 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    heff_drop_rec(v_hd_246, 3);
    V f_ = v_k_247;
    args[0] = v_x_2412;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_std_2efilesystem_2ereadFile_24s597359330x237736700_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s1628839587x1321325607(v_lit_240, v_t_245, heff_dup(v_hd_246), heff_clo_n(g_std_2efilesystem_2ereadFile_24s597359330x237736700_lam2, 1, 2, (V[]){v_hd_246, v_k_247})));
}
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam0(V self, V *args); static Clo g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam0, 1, 0};
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam3(V self, V *args);
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam4(V self, V *args);
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam6(V self, V *args);
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam5(V self, V *args);
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam2(V self, V *args);
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam1(V self, V *args);
Clo g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_entry, 3, 0};

V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351(V v_lit_240, V v_ev_241, V v_path_242) {
top: ;
  V v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_242; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = heff_tr(heff_call(v_ev_241, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_243, ((V)&g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam0_clo)})}));
  return heff_clo_n(g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam1, 2, 3, (V[]){v_lit_240, v_t_245, v_path_242});
}
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_entry(V self, V *a) {
  (void)self;
  return g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351(a[0], a[1], a[2]);
}
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam3(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k2_2411 = args[1];
  V v_err_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2412 = heff_take_field(v_hd_2410, 1);
  V v_malg_2413 = heff_get_n(v_hd_2410, 2, 3);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_249})});
  V v_t_2415 = heff_tr(heff_call(v_malg_2413, 1, (V[]){v_t_2414}));
  V f_ = v_bind_2412;
  args[0] = v_t_2415;
  args[1] = v_k2_2411;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam6(V self, V *args) {
  V v_n_2421 = args[0];
  V v_path_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_n_2421; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  return (g_std_2epath_2ejoin(v_path_242, v_t_2422));
}
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2423 = (g_list_2emap(heff_clo_n(g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam6, 1, 1, (V[]){v_path_242}), v_x_2420));
  V f_ = v_k_247;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_path_242 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Left: {
    V v_err_249 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    v_t_2419 = heff_clo_n(g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam3, 2, 1, (V[]){v_err_249});
    break;
  }
  case TAG_Right: {
    V v_x_2416 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    v_t_2419 = heff_clo_n(g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam4, 2, 1, (V[]){v_x_2416});
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V f_ = v_t_2419;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam5, 1, 2, (V[]){v_path_242, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s1628839587x1321325607(v_lit_240, v_t_245, heff_dup(v_hd_246), heff_clo_n(g_std_2efilesystem_2ereadDirectory_24s1433013395x1853737351_lam2, 1, 3, (V[]){v_hd_246, v_path_242, v_k_247})));
}
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_lam0(V self, V *args); static Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ereadFile_24s2092922012x215966209_lam0, 1, 0};
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_lam2(V self, V *args);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_lam1(V self, V *args);
Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry, 1, 0};

V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V v_path_240) {
top: ;
  V v_t_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_243 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_241, ((V)&g_std_2efilesystem_2ereadFile_24s2092922012x215966209_lam0_clo)});
  return heff_clo_n(g_std_2efilesystem_2ereadFile_24s2092922012x215966209_lam1, 2, 1, (V[]){v_a_243});
}
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a0); heff_drop(a0); return r;
}
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_lam0(V self, V *args) {
  V v_r_242 = args[0];
  return v_r_242;
}
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_t_2414 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2413})});
    return (g_co_2eop_24s1398690846x1918384825(v_t_2414, v_hd_244, v_k_245));
  }
  case TAG_Right: {
    V v_x_2415 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = v_x_2415;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_243})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_hd_244), heff_clo_n(g_std_2efilesystem_2ereadFile_24s2092922012x215966209_lam2, 1, 2, (V[]){v_hd_244, v_k_245})));
}
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam0(V self, V *args); static Clo g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam0, 1, 0};
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam3(V self, V *args);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam5(V self, V *args);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam4(V self, V *args);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam2(V self, V *args);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam1(V self, V *args);
Clo g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_entry, 1, 0};

V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(V v_path_240) {
top: ;
  V v_t_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_243 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_241, ((V)&g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam0_clo)});
  return heff_clo_n(g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam1, 2, 2, (V[]){v_a_243, v_path_240});
}
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_entry(V self, V *a) {
  (void)self;
  return g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(a[0]);
}
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam0(V self, V *args) {
  V v_r_242 = args[0];
  return v_r_242;
}
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam5(V self, V *args) {
  V v_n_2420 = args[0];
  V v_path_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_n_2420; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  return (g_std_2epath_2ejoin(v_path_240, v_t_2421));
}
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2422 = (g_list_2emap(heff_clo_n(g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam5, 1, 1, (V[]){v_path_240}), v_x_2419));
  V f_ = v_k_245;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_t_2414 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2413})});
    v_t_2418 = heff_tr(heff_call(((V)&g_co_2eop_24s1138723349x835120997_clo), 1, (V[]){v_t_2414}));
    break;
  }
  case TAG_Right: {
    V v_x_2415 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    v_t_2418 = heff_clo_n(g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam3, 2, 1, (V[]){v_x_2415});
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V f_ = v_t_2418;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam4, 1, 2, (V[]){v_path_240, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_a_243 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_243})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_hd_244), heff_clo_n(g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_lam2, 1, 3, (V[]){v_hd_244, v_path_240, v_k_245})));
}
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_lam0(V self, V *args); static Clo g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_lam0, 1, 0};
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_lam2(V self, V *args);
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_lam1(V self, V *args);
Clo g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_entry, 1, 0};

V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(V v_path_240) {
top: ;
  V v_t_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_243 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_241, ((V)&g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_lam0_clo)});
  return heff_clo_n(g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_lam1, 2, 1, (V[]){v_a_243});
}
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(a0); heff_drop(a0); return r;
}
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_lam0(V self, V *args) {
  V v_r_242 = args[0];
  return v_r_242;
}
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_t_2414 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2413})});
    return (g_co_2eop_24s1398690846x1918384825(v_t_2414, v_hd_244, v_k_245));
  }
  case TAG_Right: {
    V v_x_2415 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = v_x_2415;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_243})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_hd_244), heff_clo_n(g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_lam2, 1, 2, (V[]){v_hd_244, v_k_245})));
}
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_lam0(V self, V *args); static Clo g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_lam0, 1, 0};
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_lam2(V self, V *args);
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_lam1(V self, V *args);
Clo g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_entry, 2, 0};

V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(V v_path_240, V v_str_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_244 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_242, v_str_241, ((V)&g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_lam0_clo)});
  return heff_clo_n(g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_lam1, 2, 1, (V[]){v_a_244});
}
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a0, a[1]); heff_drop(a0); return r;
}
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_lam0(V self, V *args) {
  V v_r_243 = args[0];
  return v_r_243;
}
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2413_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2414})});
    return (g_co_2eop_24s1398690846x1918384825(v_t_2415, v_hd_245, v_k_246));
  }
  case TAG_Right: {
    V v_x_2416 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    heff_drop(v_hd_245);
    V f_ = v_k_246;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_a_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_244})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_hd_245), heff_clo_n(g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_lam2, 1, 2, (V[]){v_hd_245, v_k_246})));
}
V g_std_2efilesystem_2ereplace_24s174842679x636132898_lam0(V self, V *args); static Clo g_std_2efilesystem_2ereplace_24s174842679x636132898_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ereplace_24s174842679x636132898_lam0, 1, 0};
V g_std_2efilesystem_2ereplace_24s174842679x636132898_lam2(V self, V *args);
V g_std_2efilesystem_2ereplace_24s174842679x636132898_lam1(V self, V *args);
Clo g_std_2efilesystem_2ereplace_24s174842679x636132898_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ereplace_24s174842679x636132898_entry, 2, 0};

V g_std_2efilesystem_2ereplace_24s174842679x636132898(V v_path_240, V v_to_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_241; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_245 = heff_tag_n(TAG_Replace, 3, (V[]){v_t_242, v_t_243, ((V)&g_std_2efilesystem_2ereplace_24s174842679x636132898_lam0_clo)});
  return heff_clo_n(g_std_2efilesystem_2ereplace_24s174842679x636132898_lam1, 2, 1, (V[]){v_a_245});
}
V g_std_2efilesystem_2ereplace_24s174842679x636132898_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2efilesystem_2ereplace_24s174842679x636132898(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_std_2efilesystem_2ereplace_24s174842679x636132898_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_std_2efilesystem_2ereplace_24s174842679x636132898_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_err_2415 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_tag_at_n(v_ru_24x_2414_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2415})});
    return (g_co_2eop_24s1398690846x1918384825(v_t_2416, v_hd_246, v_k_247));
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    heff_drop(v_hd_246);
    V f_ = v_k_247;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_std_2efilesystem_2ereplace_24s174842679x636132898_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_245})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_246), heff_clo_n(g_std_2efilesystem_2ereplace_24s174842679x636132898_lam2, 1, 2, (V[]){v_hd_246, v_k_247})));
}
V g_std_2efilesystem_2eremove_24s1441356369x419789784_lam0(V self, V *args); static Clo g_std_2efilesystem_2eremove_24s1441356369x419789784_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2eremove_24s1441356369x419789784_lam0, 1, 0};
V g_std_2efilesystem_2eremove_24s1441356369x419789784_lam2(V self, V *args);
V g_std_2efilesystem_2eremove_24s1441356369x419789784_lam1(V self, V *args);
Clo g_std_2efilesystem_2eremove_24s1441356369x419789784_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2eremove_24s1441356369x419789784_entry, 1, 0};

V g_std_2efilesystem_2eremove_24s1441356369x419789784(V v_path_240) {
top: ;
  V v_t_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_243 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_241, ((V)&g_std_2efilesystem_2eremove_24s1441356369x419789784_lam0_clo)});
  return heff_clo_n(g_std_2efilesystem_2eremove_24s1441356369x419789784_lam1, 2, 1, (V[]){v_a_243});
}
V g_std_2efilesystem_2eremove_24s1441356369x419789784_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2efilesystem_2eremove_24s1441356369x419789784(a0); heff_drop(a0); return r;
}
V g_std_2efilesystem_2eremove_24s1441356369x419789784_lam0(V self, V *args) {
  V v_r_242 = args[0];
  return v_r_242;
}
V g_std_2efilesystem_2eremove_24s1441356369x419789784_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_t_2414 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2413})});
    return (g_co_2eop_24s1398690846x1918384825(v_t_2414, v_hd_244, v_k_245));
  }
  case TAG_Right: {
    V v_x_2415 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = v_x_2415;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_std_2efilesystem_2eremove_24s1441356369x419789784_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_243})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_hd_244), heff_clo_n(g_std_2efilesystem_2eremove_24s1441356369x419789784_lam2, 1, 2, (V[]){v_hd_244, v_k_245})));
}
V g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_lam0(V self, V *args); static Clo g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_lam0, 1, 0};
V g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_lam2(V self, V *args);
V g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_lam1(V self, V *args);
Clo g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_entry, 1, 0};

V g_std_2efilesystem_2epathStatus_24s1180173567x1248178148(V v_path_240) {
top: ;
  V v_t_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_243 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_t_241, NTAG(TAG_True), ((V)&g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_lam0_clo)});
  return heff_clo_n(g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_lam1, 2, 1, (V[]){v_a_243});
}
V g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2efilesystem_2epathStatus_24s1180173567x1248178148(a0); heff_drop(a0); return r;
}
V g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_lam0(V self, V *args) {
  V v_r_242 = args[0];
  return v_r_242;
}
V g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_t_2414 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2413})});
    return (g_co_2eop_24s1398690846x1918384825(v_t_2414, v_hd_244, v_k_245));
  }
  case TAG_Right: {
    V v_x_2415 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = v_x_2415;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_243})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_hd_244), heff_clo_n(g_std_2efilesystem_2epathStatus_24s1180173567x1248178148_lam2, 1, 2, (V[]){v_hd_244, v_k_245})));
}
V g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_lam1(V self, V *args);
V g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_lam0(V self, V *args); static Clo g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_lam0, 1, 0};
Clo g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_entry, 1, 0};

V g_std_2efilesystem_2efromSystem_24s1003849434x1875331781(V v_c_240) {
top: ;
  return heff_tail(v_c_240, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_lam0_clo)});
}
V g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_entry(V self, V *a) {
  (void)self;
  return g_std_2efilesystem_2efromSystem_24s1003849434x1875331781(a[0]);
}
V g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_246);
  V f_ = v_a_247;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_lam0(V self, V *args) {
  V v_x_241 = args[0];
  switch (heff_tag_of(v_x_241)) {
  case TAG_Left: {
    V v_err_242 = heff_field(v_x_241, 0);
    V v_ru_24x_241_24Left = heff_take_reuse_n(v_x_241, 1ULL, 1);
    V v_t_243 = heff_tag_at_n(v_ru_24x_241_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_242})});
    return (g_co_2eop_24s574817332x141721203(v_t_243));
  }
  case TAG_Right: {
    V v_x_244 = heff_field(v_x_241, 0);
    heff_take_n(v_x_241, 1ULL, 1);
    V v_x_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_244; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    return heff_clo_n(g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_lam1, 2, 1, (V[]){v_x_245});
  }
  default: return heff_nomatch(v_x_241);
  }
}
V g_std_2efilesystem_2ereadOnly_24s423320184x164941529_lam0(V self, V *args); static Clo g_std_2efilesystem_2ereadOnly_24s423320184x164941529_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ereadOnly_24s423320184x164941529_lam0, 1, 0};
V g_std_2efilesystem_2ereadOnly_24s423320184x164941529_lam2(V self, V *args);
V g_std_2efilesystem_2ereadOnly_24s423320184x164941529_lam1(V self, V *args);
Clo g_std_2efilesystem_2ereadOnly_24s423320184x164941529_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ereadOnly_24s423320184x164941529_entry, 1, 0};

V g_std_2efilesystem_2ereadOnly_24s423320184x164941529(V v_path_240) {
top: ;
  V v_t_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_243 = heff_tag_n(TAG_ReadOnly, 2, (V[]){v_t_241, ((V)&g_std_2efilesystem_2ereadOnly_24s423320184x164941529_lam0_clo)});
  return heff_clo_n(g_std_2efilesystem_2ereadOnly_24s423320184x164941529_lam1, 2, 1, (V[]){v_a_243});
}
V g_std_2efilesystem_2ereadOnly_24s423320184x164941529_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2efilesystem_2ereadOnly_24s423320184x164941529(a0); heff_drop(a0); return r;
}
V g_std_2efilesystem_2ereadOnly_24s423320184x164941529_lam0(V self, V *args) {
  V v_r_242 = args[0];
  return v_r_242;
}
V g_std_2efilesystem_2ereadOnly_24s423320184x164941529_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_err_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_t_2414 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2413})});
    return (g_co_2eop_24s1398690846x1918384825(v_t_2414, v_hd_244, v_k_245));
  }
  case TAG_Right: {
    V v_x_2415 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = v_x_2415;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_std_2efilesystem_2ereadOnly_24s423320184x164941529_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_243})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_hd_244), heff_clo_n(g_std_2efilesystem_2ereadOnly_24s423320184x164941529_lam2, 1, 2, (V[]){v_hd_244, v_k_245})));
}
V g_std_2efilesystem_2ecopy_24s1896001459x769612981_lam0(V self, V *args); static Clo g_std_2efilesystem_2ecopy_24s1896001459x769612981_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ecopy_24s1896001459x769612981_lam0, 1, 0};
V g_std_2efilesystem_2ecopy_24s1896001459x769612981_lam2(V self, V *args);
V g_std_2efilesystem_2ecopy_24s1896001459x769612981_lam1(V self, V *args);
Clo g_std_2efilesystem_2ecopy_24s1896001459x769612981_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2ecopy_24s1896001459x769612981_entry, 2, 0};

V g_std_2efilesystem_2ecopy_24s1896001459x769612981(V v_path_240, V v_to_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_241; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_245 = heff_tag_n(TAG_Copy, 3, (V[]){v_t_242, v_t_243, ((V)&g_std_2efilesystem_2ecopy_24s1896001459x769612981_lam0_clo)});
  return heff_clo_n(g_std_2efilesystem_2ecopy_24s1896001459x769612981_lam1, 2, 1, (V[]){v_a_245});
}
V g_std_2efilesystem_2ecopy_24s1896001459x769612981_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2efilesystem_2ecopy_24s1896001459x769612981(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_std_2efilesystem_2ecopy_24s1896001459x769612981_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_std_2efilesystem_2ecopy_24s1896001459x769612981_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_err_2415 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_tag_at_n(v_ru_24x_2414_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2415})});
    return (g_co_2eop_24s1398690846x1918384825(v_t_2416, v_hd_246, v_k_247));
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    heff_drop(v_hd_246);
    V f_ = v_k_247;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_std_2efilesystem_2ecopy_24s1896001459x769612981_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_245})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_246), heff_clo_n(g_std_2efilesystem_2ecopy_24s1896001459x769612981_lam2, 1, 2, (V[]){v_hd_246, v_k_247})));
}
V g_std_2efilesystem_2emove_24s1656294343x318667886_lam0(V self, V *args); static Clo g_std_2efilesystem_2emove_24s1656294343x318667886_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2emove_24s1656294343x318667886_lam0, 1, 0};
V g_std_2efilesystem_2emove_24s1656294343x318667886_lam2(V self, V *args);
V g_std_2efilesystem_2emove_24s1656294343x318667886_lam1(V self, V *args);
Clo g_std_2efilesystem_2emove_24s1656294343x318667886_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2emove_24s1656294343x318667886_entry, 2, 0};

V g_std_2efilesystem_2emove_24s1656294343x318667886(V v_path_240, V v_to_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_241; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_245 = heff_tag_n(TAG_Move, 3, (V[]){v_t_242, v_t_243, ((V)&g_std_2efilesystem_2emove_24s1656294343x318667886_lam0_clo)});
  return heff_clo_n(g_std_2efilesystem_2emove_24s1656294343x318667886_lam1, 2, 1, (V[]){v_a_245});
}
V g_std_2efilesystem_2emove_24s1656294343x318667886_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2efilesystem_2emove_24s1656294343x318667886(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_std_2efilesystem_2emove_24s1656294343x318667886_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_std_2efilesystem_2emove_24s1656294343x318667886_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_err_2415 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_tag_at_n(v_ru_24x_2414_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2415})});
    return (g_co_2eop_24s1398690846x1918384825(v_t_2416, v_hd_246, v_k_247));
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    heff_drop(v_hd_246);
    V f_ = v_k_247;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_std_2efilesystem_2emove_24s1656294343x318667886_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_245})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_246), heff_clo_n(g_std_2efilesystem_2emove_24s1656294343x318667886_lam2, 1, 2, (V[]){v_hd_246, v_k_247})));
}
V g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_lam0(V self, V *args); static Clo g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_lam0, 1, 0};
V g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_lam2(V self, V *args);
V g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_lam1(V self, V *args);
Clo g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_entry, 1, 0};

V g_std_2efilesystem_2eisDirectory_24s742424059x1763865794(V v_path_240) {
top: ;
  V v_t_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_243 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_t_241, NTAG(TAG_True), ((V)&g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_lam0_clo)});
  return heff_clo_n(g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_lam1, 2, 1, (V[]){v_a_243});
}
V g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2efilesystem_2eisDirectory_24s742424059x1763865794(a0); heff_drop(a0); return r;
}
V g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_lam0(V self, V *args) {
  V v_r_242 = args[0];
  return v_r_242;
}
V g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    heff_take_n(v_x_2412, 0ULL, 1);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_2414 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    V v_t_2415 = heff_get_n(v_s_2414, 0, 4);
    V v_t_2416;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Regular: {
      v_t_2416 = NTAG(TAG_False);
      break;
    }
    case TAG_Directory: {
      v_t_2416 = NTAG(TAG_True);
      break;
    }
    case TAG_Link: {
      v_t_2416 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_2416 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    V f_ = v_k_245;
    args[0] = v_t_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_243})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s1876960293x1282655859(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), v_hd_244, heff_clo_n(g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_lam2, 1, 1, (V[]){v_k_245})));
}