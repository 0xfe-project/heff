// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ATail 47533
#define TAG_ArgExplicit 50404
#define TAG_At 8900
#define TAG_CAbandon 30933
#define TAG_CBool 61457
#define TAG_CDecl 45531
#define TAG_CDouble 41794
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CInteger 35664
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CString 35384
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DoneOrErrno 39355
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ImplicitParam 51130
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_MkDrop 35958
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Plain 3036
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SetPath 11095
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_defines 1776893014
#define LBL_doc 309170
#define LBL_done 9584713
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_from 9647217
#define LBL_gs 10067
#define LBL_inl 313953
#define LBL_key 315609
#define LBL_label 304085774
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_next 9873338
#define LBL_params 951713969
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_result 1012715336
#define LBL_self 10021907
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_style 311138763
#define LBL_tags 10047712
#define LBL_task 10048076
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_total 311908190
#define LBL_ty 10476
#define LBL_used 10094724
#define LBL_vars 10107635
static uint32_t shape_path__source__span__defines[] = {LBL_path, LBL_source, LBL_span, LBL_defines};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_heff_2ebuild_2efetch_2enewerTagged(V, V, V);
V g_heff_2ebuild_2efetch_2enewerTagged_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2enewerTagged_clo;
V g_heff_2ecompile_2edefun_2eescape(V, V);
V g_heff_2ecompile_2edefun_2eescape_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eescape_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2eprimCloOf(V);
V g_heff_2ecompile_2eemitc_2eprimCloOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimCloOf_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
HeffT2 g_heff_2ecompile_2erefcount_2enthValue_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eflat(V);
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eflat_clo;
V g_heff_2ecompile_2esimplify_2esgFlat(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgFlat_clo;
V g_heff_2ecompile_2eworker_2enumericW(V);
V g_heff_2ecompile_2eworker_2enumericW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2enumericW_clo;
V g_heff_2eelab_2eprimitive_2ecompilerTable_get(void);
V g_heff_2eelab_2eprimitive_2elibraryTable_get(void);
V g_heff_2eelab_2eprint_2ecommaSep(V);
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2ecommaSep_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2epr_get(void);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_list_2eall_24s1461376987x321850093(V);
V g_list_2eall_24s1461376987x321850093_entry(V self, V *a);
extern Clo g_list_2eall_24s1461376987x321850093_clo;
V g_list_2eall_24s442836260x1032582242(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eall_24s442836260x1032582242_entry(V self, V *a);
extern Clo g_list_2eall_24s442836260x1032582242_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1022483754x1154500907(V);
V g_list_2eany_24s1022483754x1154500907_entry(V self, V *a);
extern Clo g_list_2eany_24s1022483754x1154500907_clo;
V g_list_2eany_24s1362258228x1848434975(V);
V g_list_2eany_24s1362258228x1848434975_entry(V self, V *a);
extern Clo g_list_2eany_24s1362258228x1848434975_clo;
V g_list_2ecollapse_24s1709454359x897477238(V, V, V, V);
V g_list_2ecollapse_24s1709454359x897477238_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s1709454359x897477238_clo;
V g_list_2edescending_24s1467056061x388427999(V, V, V, V, V);
V g_list_2edescending_24s1467056061x388427999_entry(V self, V *a);
extern Clo g_list_2edescending_24s1467056061x388427999_clo;
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24f928374809x1955888331(V, V);
V g_list_2efoldl_24f928374809x1955888331_entry(V self, V *a);
extern Clo g_list_2efoldl_24f928374809x1955888331_clo;
V g_list_2efoldl_24s1028839125x1033007016(V, V);
V g_list_2efoldl_24s1028839125x1033007016_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1028839125x1033007016_clo;
V g_list_2efoldl_24s1300477078x2058851060(V, V);
V g_list_2efoldl_24s1300477078x2058851060_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1300477078x2058851060_clo;
V g_list_2efoldl_24s1445201118x2106648802(V, V);
V g_list_2efoldl_24s1445201118x2106648802_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1445201118x2106648802_clo;
V g_list_2efoldl_24s1540385767x593157740(V, V);
V g_list_2efoldl_24s1540385767x593157740_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1540385767x593157740_clo;
V g_list_2efoldl_24s1769360958x1839054239(V, V);
V g_list_2efoldl_24s1769360958x1839054239_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1769360958x1839054239_clo;
V g_list_2efoldl_24s1788498486x1573409871(V, V, V);
V g_list_2efoldl_24s1788498486x1573409871_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1788498486x1573409871_clo;
V g_list_2efoldl_24s1788567467x1730846999(V, V);
V g_list_2efoldl_24s1788567467x1730846999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1788567467x1730846999_clo;
V g_list_2efoldl_24s2118756600x1920057229(V, V);
V g_list_2efoldl_24s2118756600x1920057229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2118756600x1920057229_clo;
V g_list_2efoldl_24s2118756600x1920057229_24scalars(V, V, V, V, V, V);
V g_list_2efoldl_24s2118756600x1920057229_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2118756600x1920057229_24scalars_clo;
V g_list_2efoldl_24s366449469x130665619(V, V);
V g_list_2efoldl_24s366449469x130665619_entry(V self, V *a);
extern Clo g_list_2efoldl_24s366449469x130665619_clo;
V g_list_2efoldl_24s41085868x1118058949(V, V);
V g_list_2efoldl_24s41085868x1118058949_entry(V self, V *a);
extern Clo g_list_2efoldl_24s41085868x1118058949_clo;
V g_list_2efoldl_24s537755658x300885499(V, V);
V g_list_2efoldl_24s537755658x300885499_entry(V self, V *a);
extern Clo g_list_2efoldl_24s537755658x300885499_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s744304057x1932700078(V, V);
V g_list_2efoldl_24s744304057x1932700078_entry(V self, V *a);
extern Clo g_list_2efoldl_24s744304057x1932700078_clo;
V g_list_2efoldl_24s890299851x180637966(V, V);
V g_list_2efoldl_24s890299851x180637966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s890299851x180637966_clo;
V g_list_2efoldl_24s932544939x1448830416(V, V);
V g_list_2efoldl_24s932544939x1448830416_entry(V self, V *a);
extern Clo g_list_2efoldl_24s932544939x1448830416_clo;
V g_list_2efoldl_24s932544939x1448830416_24scalars(V, V, V);
V g_list_2efoldl_24s932544939x1448830416_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s932544939x1448830416_24scalars_clo;
V g_list_2ekeepIf_24s110788034x1785682300(V);
V g_list_2ekeepIf_24s110788034x1785682300_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s110788034x1785682300_clo;
V g_list_2ekeepIf_24s110788034x1785682300_24dps(V, V);
V g_list_2ekeepIf_24s110788034x1785682300_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s110788034x1785682300_24dps_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1005417903x1119563692_24dps(V, V, V, V);
V g_list_2emap_24f1005417903x1119563692_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1005417903x1119563692_24dps_clo;
V g_list_2emap_24f1217399696x462307458(V, V, V);
V g_list_2emap_24f1217399696x462307458_entry(V self, V *a);
extern Clo g_list_2emap_24f1217399696x462307458_clo;
V g_list_2emap_24f1217399696x462307458_24dps(V, V, V, V);
V g_list_2emap_24f1217399696x462307458_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1217399696x462307458_24dps_clo;
V g_list_2emap_24f1619849299x1543923271(V);
V g_list_2emap_24f1619849299x1543923271_entry(V self, V *a);
extern Clo g_list_2emap_24f1619849299x1543923271_clo;
V g_list_2emap_24f1619849299x1543923271_24dps(V, V);
V g_list_2emap_24f1619849299x1543923271_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1619849299x1543923271_24dps_clo;
V g_list_2emap_24f1677329353x1774765664(V, V);
V g_list_2emap_24f1677329353x1774765664_entry(V self, V *a);
extern Clo g_list_2emap_24f1677329353x1774765664_clo;
V g_list_2emap_24f1677329353x1774765664_24tok2(V, V, V);
V g_list_2emap_24f1677329353x1774765664_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24f1677329353x1774765664_24tok2_clo;
V g_list_2emap_24f755592795x444686035(V, V, V, V, V, V);
V g_list_2emap_24f755592795x444686035_entry(V self, V *a);
extern Clo g_list_2emap_24f755592795x444686035_clo;
V g_list_2emap_24f755592795x444686035_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24f755592795x444686035_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f755592795x444686035_24dps_clo;
V g_list_2emap_24s1068270568x176847536(V);
V g_list_2emap_24s1068270568x176847536_entry(V self, V *a);
extern Clo g_list_2emap_24s1068270568x176847536_clo;
V g_list_2emap_24s1068270568x176847536_24dps(V, V);
V g_list_2emap_24s1068270568x176847536_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1068270568x176847536_24dps_clo;
V g_list_2emap_24s1093229560x1486136516(V);
V g_list_2emap_24s1093229560x1486136516_entry(V self, V *a);
extern Clo g_list_2emap_24s1093229560x1486136516_clo;
V g_list_2emap_24s1093229560x1486136516_24dps(V, V);
V g_list_2emap_24s1093229560x1486136516_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1093229560x1486136516_24dps_clo;
V g_list_2emap_24s1127556009x863725781_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24s1127556009x863725781_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1127556009x863725781_24dps_clo;
V g_list_2emap_24s1170504272x1852564147(V);
V g_list_2emap_24s1170504272x1852564147_entry(V self, V *a);
extern Clo g_list_2emap_24s1170504272x1852564147_clo;
V g_list_2emap_24s1170504272x1852564147_24dps(V, V);
V g_list_2emap_24s1170504272x1852564147_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1170504272x1852564147_24dps_clo;
V g_list_2emap_24s1243189782x897571843_24dps(V, V, V);
V g_list_2emap_24s1243189782x897571843_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_24dps_clo;
V g_list_2emap_24s1341404685x1564972929(V);
V g_list_2emap_24s1341404685x1564972929_entry(V self, V *a);
extern Clo g_list_2emap_24s1341404685x1564972929_clo;
V g_list_2emap_24s1341404685x1564972929_24dps(V, V);
V g_list_2emap_24s1341404685x1564972929_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1341404685x1564972929_24dps_clo;
V g_list_2emap_24s1392650298x1192381411_24dps(V, V, V, V);
V g_list_2emap_24s1392650298x1192381411_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1392650298x1192381411_24dps_clo;
V g_list_2emap_24s1512396752x1753792987(V, V, V);
V g_list_2emap_24s1512396752x1753792987_entry(V self, V *a);
extern Clo g_list_2emap_24s1512396752x1753792987_clo;
V g_list_2emap_24s1512396752x1753792987_24dps(V, V, V, V);
V g_list_2emap_24s1512396752x1753792987_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1512396752x1753792987_24dps_clo;
V g_list_2emap_24s1535007417x1587061701_24dps(V, V);
V g_list_2emap_24s1535007417x1587061701_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1535007417x1587061701_24dps_clo;
V g_list_2emap_24s1839428429x1874782624_24dps(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1839428429x1874782624_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1839428429x1874782624_24dps_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_list_2emap_24s1990719097x1419059608_24dps(V, V);
V g_list_2emap_24s1990719097x1419059608_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_24dps_clo;
V g_list_2emap_24s2007813875x1918122072(V);
V g_list_2emap_24s2007813875x1918122072_entry(V self, V *a);
extern Clo g_list_2emap_24s2007813875x1918122072_clo;
V g_list_2emap_24s2007813875x1918122072_24dps(V, V);
V g_list_2emap_24s2007813875x1918122072_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2007813875x1918122072_24dps_clo;
V g_list_2emap_24s2021078391x832341393_24dps(V, V, V, V);
V g_list_2emap_24s2021078391x832341393_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2021078391x832341393_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s296585291x885335139_24dps(V, V);
V g_list_2emap_24s296585291x885335139_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s296585291x885335139_24dps_clo;
V g_list_2emap_24s32026788x2029987799(V);
V g_list_2emap_24s32026788x2029987799_entry(V self, V *a);
extern Clo g_list_2emap_24s32026788x2029987799_clo;
V g_list_2emap_24s32026788x2029987799_24dps(V, V);
V g_list_2emap_24s32026788x2029987799_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s32026788x2029987799_24dps_clo;
V g_list_2emap_24s366989016x166432442(V);
V g_list_2emap_24s366989016x166432442_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_clo;
V g_list_2emap_24s366989016x166432442_24dps(V, V);
V g_list_2emap_24s366989016x166432442_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_24dps_clo;
V g_list_2emap_24s45270243x110012769(V);
V g_list_2emap_24s45270243x110012769_entry(V self, V *a);
extern Clo g_list_2emap_24s45270243x110012769_clo;
V g_list_2emap_24s45270243x110012769_24dps(V, V);
V g_list_2emap_24s45270243x110012769_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s45270243x110012769_24dps_clo;
V g_list_2emap_24s474585387x1072098790(V);
V g_list_2emap_24s474585387x1072098790_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_clo;
V g_list_2emap_24s474585387x1072098790_24dps(V, V);
V g_list_2emap_24s474585387x1072098790_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_24dps_clo;
V g_list_2emap_24s499193121x1224230698_24dps(V, V);
V g_list_2emap_24s499193121x1224230698_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s499193121x1224230698_24dps_clo;
V g_list_2emap_24s582709368x2113456071(V);
V g_list_2emap_24s582709368x2113456071_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_clo;
V g_list_2emap_24s582709368x2113456071_24dps(V, V);
V g_list_2emap_24s582709368x2113456071_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_24dps_clo;
V g_list_2emap_24s759871588x920431471_24dps(V, V);
V g_list_2emap_24s759871588x920431471_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_24dps_clo;
V g_list_2emap_24s784191759x2032889081_24dps(V, V);
V g_list_2emap_24s784191759x2032889081_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s784191759x2032889081_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emerge_24s1926973041x331495419(V, V);
V g_list_2emerge_24s1926973041x331495419_entry(V self, V *a);
extern Clo g_list_2emerge_24s1926973041x331495419_clo;
V g_list_2epushRun_24s2022155310x1483676144(V, V, V);
V g_list_2epushRun_24s2022155310x1483676144_entry(V self, V *a);
extern Clo g_list_2epushRun_24s2022155310x1483676144_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
V g_std_2eterminal_2ewidget_2ecolumns(V);
V g_std_2eterminal_2ewidget_2ecolumns_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecolumns_clo;

HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_x2_2410) {
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    V v_t_2413;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_I8: {
      v_t_2413 = heff_dup(v_lit_240);
      break;
    }
    case TAG_I16: {
      v_t_2413 = heff_dup(v_lit_241);
      break;
    }
    case TAG_I32: {
      v_t_2413 = heff_dup(v_lit_242);
      break;
    }
    case TAG_I64: {
      v_t_2413 = heff_dup(v_lit_243);
      break;
    }
    case TAG_U8: {
      v_t_2413 = heff_dup(v_lit_244);
      break;
    }
    case TAG_U16: {
      v_t_2413 = heff_dup(v_lit_245);
      break;
    }
    case TAG_U32: {
      v_t_2413 = heff_dup(v_lit_246);
      break;
    }
    case TAG_U64: {
      v_t_2413 = heff_dup(v_lit_247);
      break;
    }
    case TAG_F32: {
      v_t_2413 = heff_dup(v_lit_248);
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    if (heff_strEq_c_lent(v_t_2413, v_lit_249, 1)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_lit_247);
      heff_drop(v_lit_248);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_2411)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      V t_10 = v_xs_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_x2_2410 = t_10;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_2410)}});
  }
}
Clo g_list_2eany_24s1006624359x760861690_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1006624359x760861690_entry, 2, 0};

V g_list_2eany_24s1006624359x760861690(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_lit_240, v_x_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1006624359x760861690(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s32026788x2029987799_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s32026788x2029987799_entry, 1, 0};

V g_list_2emap_24s32026788x2029987799(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_start_243 = heff_take_field(v_x_241, 0);
    V v_end_244 = heff_take_field(v_x_241, 1);
    V v_text_245 = heff_get_n(v_x_241, 2, 3);
    V v_t_246 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){v_start_243, v_end_244, NTAG(TAG_Nothing), v_text_245, MK_INT(0LL), MK_INT(0LL)});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s32026788x2029987799_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s32026788x2029987799_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s32026788x2029987799(a[0]);
}
Clo g_list_2emap_24s1243189782x897571843_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1243189782x897571843_24dps_entry, 3, 0};

V g_list_2emap_24s1243189782x897571843_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_x_243}), heff_dup(v_lit_240)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1243189782x897571843_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1243189782x897571843_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s366989016x166432442_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366989016x166432442_entry, 1, 0};

V g_list_2emap_24s366989016x166432442(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_a_243)) {
      case TAG_SetPath: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_ru_24a_243_24SetPath = heff_take_reuse_n(v_a_243, 3ULL, 2);
        V v_t_2410;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_field(v_a_246, 0);
          V v_a_248 = heff_field(v_a_246, 1);
          heff_take_n(v_a_246, 3ULL, 2);
          V v_t_249 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_247));
          v_t_2410 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_249, v_a_248});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2411 = heff_tag_at_n(v_ru_24a_243_24SetPath, TAG_SetPath, 2, (V[]){v_a_245, v_t_2410});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = (g_list_2emap_24s366989016x166432442_24dps(v_xs_242, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366989016x166432442_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366989016x166432442(a[0]);
}
Clo g_list_2emap_24s474585387x1072098790_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s474585387x1072098790_entry, 1, 0};

V g_list_2emap_24s474585387x1072098790(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_ExplicitParam: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24ExplicitParam = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          V v_ru_24a_247_24At = heff_take_reuse_n(v_a_247, 3ULL, 2);
          v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24a_247_24At, v_a_249, v_a_248));
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_a_245, v_a_246, v_t_2410});
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_a_2412 = heff_field(v_a_243, 1);
        V v_a_2413 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24ImplicitParam = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2416;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          V v_ru_24a_2413_24At = heff_take_reuse_n(v_a_2413, 3ULL, 2);
          v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24a_2413_24At, v_a_2415, v_a_2414));
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_a_2411, v_a_2412, v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = (g_list_2emap_24s474585387x1072098790_24dps(v_xs_242, heff_dup(v_cell_2419)));
    heff_drop(v_u_2420);
    return v_cell_2419;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s474585387x1072098790_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s474585387x1072098790(a[0]);
}
Clo g_list_2efoldl_24s890299851x180637966_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s890299851x180637966_entry, 2, 0};

V g_list_2efoldl_24s890299851x180637966(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_key_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_body_245 = heff_dup(heff_rfield(v_x_242, 2));
    V v_t_246 = (g_heff_2ecompile_2esimplify_2eflat(v_body_245));
    V v_t_247 = ({ V a_0 = v_z_240; V a_1 = v_key_244; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2esimplify_2esgFlat(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s890299851x180637966_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s890299851x180637966(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s744304057x1932700078_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s744304057x1932700078_entry, 2, 0};

V g_list_2efoldl_24s744304057x1932700078(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, v_t_246, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s744304057x1932700078_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s744304057x1932700078(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s110788034x1785682300_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s110788034x1785682300_entry, 1, 0};

V g_list_2ekeepIf_24s110788034x1785682300(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_RepV: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_RepFix: {
      heff_take_n(v_t_245, 0ULL, 1);
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_248 = (g_list_2ekeepIf_24s110788034x1785682300_24dps(v_xs_242, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    case TAG_RepF64: {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2410 = (g_list_2ekeepIf_24s110788034x1785682300_24dps(v_xs_242, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    case TAG_RepInt: {
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2412 = (g_list_2ekeepIf_24s110788034x1785682300_24dps(v_xs_242, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s110788034x1785682300_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s110788034x1785682300(a[0]);
}
Clo g_list_2efoldl_24s1769360958x1839054239_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1769360958x1839054239_entry, 2, 0};

V g_list_2efoldl_24s1769360958x1839054239(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_m_244 = v_z_240;
    V v_d_245 = heff_dup(v_x_242);
    V v_body_246 = heff_take_field(v_d_245, 2);
    V v_key_247 = heff_get_n(v_d_245, 0, 3);
    V v_t_2449;
    switch (heff_tag_of(v_body_246)) {
    case TAG_EVar: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_ELam: {
      V v_xs_2410 = heff_field(v_body_246, 0);
      heff_take_n(v_body_246, 1ULL, 2);
      V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2410; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      V v_t_2413 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2412, MK_INT(1LL))));
      v_t_2449 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_244, v_key_247, v_t_2413));
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_body_246, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_body_246, 0ULL, 4);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_body_246, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_body_246, 0ULL, 3);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_body_246, 0ULL, 1);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_body_246, 0ULL, 2);
      heff_drop(v_key_247);
      v_t_2449 = v_m_244;
      break;
    }
    default: heff_nomatch(v_body_246);
    }
    V t_0 = v_t_2449;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1769360958x1839054239_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1769360958x1839054239(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1068270568x176847536_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1068270568x176847536_entry, 1, 0};

V g_list_2emap_24s1068270568x176847536(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_241, NTAG(TAG_Nothing)});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1068270568x176847536_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1068270568x176847536_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1068270568x176847536(a[0]);
}
Clo g_list_2emap_24s1341404685x1564972929_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1341404685x1564972929_entry, 1, 0};

V g_list_2emap_24s1341404685x1564972929(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 7ULL, 3);
      v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_a_244}), heff_tag_n(TAG_ATail, 1, (V[]){v_a_245})});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1341404685x1564972929_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1341404685x1564972929_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1341404685x1564972929(a[0]);
}
V g_list_2emap_24s1512396752x1753792987_lam0(V self, V *args);
Clo g_list_2emap_24s1512396752x1753792987_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1512396752x1753792987_entry, 3, 0};

V g_list_2emap_24s1512396752x1753792987(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_th_245 = heff_dup(v_lit_240);
    V v_tags_246 = heff_take_field(v_th_245, 1);
    V v_at_247 = heff_get_n(v_th_245, 0, 2);
    V v_go_248 = heff_dup(v_lit_241);
    V v_s_249 = v_x_243;
    V v_t_24142;
    switch (heff_tag_of(v_s_249)) {
    case TAG_CDrop: {
      heff_drop(v_tags_246);
      heff_drop(v_at_247);
      heff_drop(v_go_248);
      v_t_24142 = v_s_249;
      break;
    }
    case TAG_CLet: {
      heff_drop(v_tags_246);
      heff_drop(v_at_247);
      heff_drop(v_go_248);
      v_t_24142 = v_s_249;
      break;
    }
    case TAG_CDecl: {
      heff_drop(v_tags_246);
      heff_drop(v_at_247);
      heff_drop(v_go_248);
      v_t_24142 = v_s_249;
      break;
    }
    case TAG_CSet: {
      heff_drop(v_tags_246);
      heff_drop(v_at_247);
      heff_drop(v_go_248);
      v_t_24142 = v_s_249;
      break;
    }
    case TAG_CAbandon: {
      heff_drop(v_tags_246);
      heff_drop(v_at_247);
      heff_drop(v_go_248);
      v_t_24142 = v_s_249;
      break;
    }
    case TAG_CIf: {
      V v_c_2416 = heff_field(v_s_249, 0);
      V v_a_2417 = heff_field(v_s_249, 1);
      V v_b_2418 = heff_field(v_s_249, 2);
      V v_ru_24s_249_24CIf = heff_take_reuse_n(v_s_249, 7ULL, 3);
      heff_drop(v_tags_246);
      heff_drop(v_at_247);
      V v_t_2419 = heff_tr(heff_call(heff_dup(v_go_248), 1, (V[]){v_a_2417}));
      V v_t_2420 = heff_tr(heff_call(v_go_248, 1, (V[]){v_b_2418}));
      v_t_24142 = heff_tag_at_n(v_ru_24s_249_24CIf, TAG_CIf, 3, (V[]){v_c_2416, v_t_2419, v_t_2420});
      break;
    }
    case TAG_CSwitch: {
      V v_e_2421 = heff_field(v_s_249, 0);
      V v_arms_2422 = heff_field(v_s_249, 1);
      V v_r_2423 = heff_field(v_s_249, 2);
      V v_ru_24s_249_24CSwitch = heff_take_reuse_n(v_s_249, 7ULL, 3);
      heff_drop(v_tags_246);
      heff_drop(v_at_247);
      V v_t_2434 = (g_list_2emap(heff_clo_n(g_list_2emap_24s1512396752x1753792987_lam0, 1, 1, (V[]){v_go_248}), v_arms_2422));
      v_t_24142 = heff_tag_at_n(v_ru_24s_249_24CSwitch, TAG_CSwitch, 3, (V[]){v_e_2421, v_t_2434, v_r_2423});
      break;
    }
    case TAG_CReturn: {
      heff_drop(v_tags_246);
      heff_drop(v_at_247);
      heff_drop(v_go_248);
      v_t_24142 = v_s_249;
      break;
    }
    case TAG_CInPlace: {
      heff_drop(v_tags_246);
      heff_drop(v_at_247);
      heff_drop(v_go_248);
      v_t_24142 = v_s_249;
      break;
    }
    case TAG_CRoomed: {
      heff_drop(v_tags_246);
      heff_drop(v_at_247);
      heff_drop(v_go_248);
      v_t_24142 = v_s_249;
      break;
    }
    case TAG_CTail: {
      heff_drop(v_tags_246);
      heff_drop(v_at_247);
      heff_drop(v_go_248);
      v_t_24142 = v_s_249;
      break;
    }
    case TAG_CLoop: {
      V v_ps_2442 = heff_field(v_s_249, 0);
      V v_vs_2443 = heff_field(v_s_249, 1);
      V v_ru_24s_249_24CLoop = heff_take_reuse_n(v_s_249, 3ULL, 2);
      heff_drop(v_go_248);
      V v_ts_2444 = v_tags_246;
      HeffT2 v_t_2445 = (g_heff_2ecompile_2erefcount_2enthValue_24cpr(v_at_247, v_vs_2443));
      V v_x3_24133;
      {
        V v_field_2447 = v_t_2445.f[1];
        int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
        if ((v_tag_2446 == ((int64_t)0ULL))) {
          V v_v1_2448 = v_field_2447;
          switch (heff_tag_of(v_v1_2448)) {
          case TAG_RLocal: {
            heff_take_n(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RDup: {
            heff_take_n(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RClo: {
            heff_take_n(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGet: {
            heff_take_n(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetRaw: {
            heff_take_n(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RInt: {
            heff_take_n(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFloat: {
            heff_take_na(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RStr: {
            heff_take_n(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RBytes: {
            heff_take_n(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFixed: {
            heff_take_n(v_v1_2448, 0ULL, 2);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RF32: {
            heff_take_na(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RNTag: {
            V v_t_2461 = heff_field(v_v1_2448, 0);
            V v_ru_24v1_2448_24RNTag = heff_take_reuse_n(v_v1_2448, 1ULL, 1);
            V v_t_2462 = ({ V a_0 = v_t_2461; V a_1 = v_ts_2444; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_ts_2444); r_; });
            if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
              heff_drop(v_t_2462);
              v_x3_24133 = heff_tag_at_n(v_ru_24v1_2448_24RNTag, TAG_Just, 1, (V[]){v_t_2461});
            } else {
              heff_drop(v_t_2461);
              heff_drop_cell(v_ru_24v1_2448_24RNTag, 1);
              heff_drop(v_t_2462);
              v_x3_24133 = NTAG(TAG_Nothing);
            }
            break;
          }
          case TAG_RTag: {
            heff_take_n(v_v1_2448, 0ULL, 3);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RTagIn: {
            heff_take_n(v_v1_2448, 0ULL, 4);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RRec: {
            heff_take_n(v_v1_2448, 0ULL, 3);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RRecIn: {
            heff_take_n(v_v1_2448, 0ULL, 8);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RField: {
            heff_take_n(v_v1_2448, 0ULL, 2);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RDupE: {
            heff_take_n(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFieldV: {
            heff_take_n(v_v1_2448, 0ULL, 2);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetN: {
            heff_take_n(v_v1_2448, 0ULL, 3);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFieldU: {
            heff_take_n(v_v1_2448, 0ULL, 4);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetNU: {
            heff_take_n(v_v1_2448, 0ULL, 5);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RWord: {
            heff_take_n(v_v1_2448, 0ULL, 2);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RTakeField: {
            heff_take_n(v_v1_2448, 0ULL, 2);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetLabel: {
            heff_take_n(v_v1_2448, 0ULL, 2);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrimFn: {
            heff_take_n(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrim: {
            heff_take_n(v_v1_2448, 0ULL, 2);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RLam: {
            heff_take_n(v_v1_2448, 0ULL, 4);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RCall: {
            heff_take_n(v_v1_2448, 0ULL, 4);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RApply: {
            heff_take_n(v_v1_2448, 0ULL, 2);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RBool: {
            heff_take_n(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RAbandon: {
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RBox: {
            heff_take_n(v_v1_2448, 0ULL, 2);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RUnbox: {
            heff_take_n(v_v1_2448, 0ULL, 2);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPeek: {
            heff_take_n(v_v1_2448, 0ULL, 2);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrimU: {
            heff_take_n(v_v1_2448, 0ULL, 2);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrimAt: {
            heff_take_n(v_v1_2448, 0ULL, 3);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFixU: {
            heff_take_n(v_v1_2448, 0ULL, 2);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RF32U: {
            heff_take_na(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RF64U: {
            heff_take_na(v_v1_2448, 0ULL, 1);
            heff_drop(v_ts_2444);
            v_x3_24133 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_2448);
          }
        } else {
          heff_drop(v_ts_2444);
          heff_drop(v_field_2447);
          v_x3_24133 = NTAG(TAG_Nothing);
        }
      }
      switch (heff_tag_of(v_x3_24133)) {
      case TAG_Nothing: {
        v_t_24142 = heff_tag_at_n(v_ru_24s_249_24CLoop, TAG_CLoop, 2, (V[]){v_ps_2442, v_vs_2443});
        break;
      }
      case TAG_Just: {
        V v_t_24134 = heff_field(v_x3_24133, 0);
        heff_take_n(v_x3_24133, 1ULL, 1);
        heff_drop_cell(v_ru_24s_249_24CLoop, 2);
        v_t_24142 = heff_tag_n(TAG_CLoopTo, 3, (V[]){v_t_24134, v_ps_2442, v_vs_2443});
        break;
      }
      default: heff_nomatch(v_x3_24133);
      }
      break;
    }
    case TAG_CLoopTo: {
      heff_drop(v_tags_246);
      heff_drop(v_at_247);
      heff_drop(v_go_248);
      v_t_24142 = v_s_249;
      break;
    }
    case TAG_CLabel: {
      heff_drop(v_tags_246);
      heff_drop(v_at_247);
      heff_drop(v_go_248);
      v_t_24142 = v_s_249;
      break;
    }
    case TAG_CJump: {
      heff_drop(v_tags_246);
      heff_drop(v_at_247);
      heff_drop(v_go_248);
      v_t_24142 = v_s_249;
      break;
    }
    default: heff_nomatch(v_s_249);
    }
    V v_cell_24143 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_24142, heff_hole()});
    V v_u_24144 = (g_list_2emap_24s1512396752x1753792987_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_24143)));
    heff_drop(v_u_24144);
    return v_cell_24143;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1512396752x1753792987_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1512396752x1753792987(a[0], a[1], a[2]);
}
V g_list_2emap_24s1512396752x1753792987_lam0(V self, V *args) {
  V v_x2_2424 = args[0];
  V v_go_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkCArm: {
    V v_t_2425 = heff_field(v_x2_2424, 0);
    V v_fs_2426 = heff_field(v_x2_2424, 1);
    V v_fl_2427 = heff_field(v_x2_2424, 2);
    V v_su_2428 = heff_field(v_x2_2424, 3);
    V v_pl_2429 = heff_field(v_x2_2424, 4);
    V v_tk_2430 = heff_field(v_x2_2424, 5);
    V v_body_2431 = heff_field(v_x2_2424, 6);
    V v_lv_2432 = heff_field(v_x2_2424, 7);
    V v_ru_24x2_2424_24MkCArm = heff_take_reuse_n(v_x2_2424, 255ULL, 8);
    V v_t_2433 = heff_tr(heff_call(v_go_248, 1, (V[]){v_body_2431}));
    return heff_tag_at_n(v_ru_24x2_2424_24MkCArm, TAG_MkCArm, 8, (V[]){v_t_2425, v_fs_2426, v_fl_2427, v_su_2428, v_pl_2429, v_tk_2430, v_t_2433, v_lv_2432});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
Clo g_list_2emap_24s45270243x110012769_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s45270243x110012769_entry, 1, 0};

V g_list_2emap_24s45270243x110012769(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s45270243x110012769_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s45270243x110012769_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s45270243x110012769(a[0]);
}
Clo g_list_2efoldl_24s1788567467x1730846999_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1788567467x1730846999_entry, 2, 0};

V g_list_2efoldl_24s1788567467x1730846999(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2edefun_2eescape(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1788567467x1730846999_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1788567467x1730846999(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1540385767x593157740_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1540385767x593157740_entry, 2, 0};

V g_list_2efoldl_24s1540385767x593157740(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_t_246 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_a_245, 1), NTAG(TAG_Nil)));
      v_t_247 = (g_list_2emap_24f1677329353x1774765664(heff_dup(v_a_244), v_t_246));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_240));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1540385767x593157740_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1540385767x593157740(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1839428429x1874782624_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1839428429x1874782624_24dps_entry, 12, 0};

V g_list_2emap_24s1839428429x1874782624_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_x2_2410, V v_d_2411) {
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return heff_setField(v_d_2411, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2410, 0);
    V v_xs_2413 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24Cons = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2423;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_2412, 0);
      V v_a_2415 = heff_field(v_x_2412, 1);
      V v_ru_24x_2412_24MkPair = heff_take_reuse_n(v_x_2412, 3ULL, 2);
      V v_t_2416 = ({ V a_0 = v_a_2414; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_2414); r_; });
      V v_t_2417 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2416), heff_dup(v_lit_243));
      V v_t_2418 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_t_2417), heff_dup(v_lit_244));
      V v_a_2419 = (g_list_2emap_24tok2(v_ru_24x_2412_24MkPair, heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 1)), heff_arrayToList(v_a_2415)));
      V v_t_2420 = ({ V a_0 = v_a_2419; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_a_2419); r_; });
      V v_t_2421 = heff_strAppend(heff_strAppend(heff_dup(v_lit_246), v_t_2420), heff_dup(v_lit_247));
      V v_t_2422 = heff_strAppend(heff_strAppend(heff_dup(v_lit_245), v_t_2421), heff_dup(v_lit_248));
      v_t_2423 = heff_strAppend(heff_strAppend(v_t_2418, v_t_2422), heff_dup(v_lit_249));
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_2410_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = heff_setField(v_d_2411, MK_INT(1LL), heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_lit_249;
    V t_10 = v_xs_2413;
    V t_11 = v_cell_2424;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_lit_249 = t_9;
    v_x2_2410 = t_10;
    v_d_2411 = t_11;
    goto top;
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_list_2emap_24s1839428429x1874782624_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1839428429x1874782624_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
}
Clo g_list_2emap_24s2007813875x1918122072_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2007813875x1918122072_entry, 1, 0};

V g_list_2emap_24s2007813875x1918122072(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_False), v_x_241});
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s2007813875x1918122072_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2007813875x1918122072_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2007813875x1918122072(a[0]);
}
Clo g_list_2emap_24s1990719097x1419059608_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1990719097x1419059608_entry, 1, 0};

V g_list_2emap_24s1990719097x1419059608(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tr(heff_call(v_x_241, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1990719097x1419059608_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1990719097x1419059608(a[0]);
}
Clo g_list_2efoldl_24s366449469x130665619_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s366449469x130665619_entry, 2, 0};

V g_list_2efoldl_24s366449469x130665619(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_acc_244 = v_z_240;
    V v_s_245 = v_x_242;
    V v_t_24121;
    switch (heff_tag_of(v_s_245)) {
    case TAG_CDrop: {
      heff_take_n(v_s_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_24121 = v_acc_244;
      break;
    }
    case TAG_CLet: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_24121 = v_acc_244;
      break;
    }
    case TAG_CDecl: {
      heff_take_n(v_s_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_24121 = v_acc_244;
      break;
    }
    case TAG_CSet: {
      heff_take_n(v_s_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_24121 = v_acc_244;
      break;
    }
    case TAG_CAbandon: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_24121 = v_acc_244;
      break;
    }
    case TAG_CIf: {
      V v_a_2413 = heff_field(v_s_245, 1);
      V v_b_2414 = heff_field(v_s_245, 2);
      heff_take_n(v_s_245, 6ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      V v_t_2415 = (g_list_2efoldl_24s366449469x130665619(v_acc_244, v_a_2413));
      v_t_24121 = (g_list_2efoldl_24s366449469x130665619(v_t_2415, v_b_2414));
      break;
    }
    case TAG_CSwitch: {
      V v_arms_2417 = heff_field(v_s_245, 1);
      heff_take_n(v_s_245, 2ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_24121 = ({ V a_0 = v_acc_244; V a_1 = v_arms_2417; V r_ = (g_list_2efoldl_24s1445201118x2106648802(a_0, a_1)); heff_drop(v_arms_2417); r_; });
      break;
    }
    case TAG_CReturn: {
      V v_e_2419 = heff_field(v_s_245, 0);
      V v_ru_24s_245_24CReturn = heff_take_reuse_n(v_s_245, 1ULL, 1);
      switch (heff_tag_of(v_e_2419)) {
      case TAG_RAbandon: {
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop_cell(v_ru_24s_245_24CReturn, 1);
        v_t_24121 = v_acc_244;
        break;
      }
      default: {
        V v_e_2420 = v_e_2419;
        V v_t_24105;
        switch (heff_tag_of(v_e_2420)) {
        case TAG_RLocal: {
          heff_take_n(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RDup: {
          heff_take_n(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RClo: {
          heff_take_n(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RGet: {
          heff_take_n(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RGetRaw: {
          heff_take_n(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RInt: {
          heff_take_n(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RFloat: {
          heff_take_na(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RStr: {
          heff_take_n(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RBytes: {
          heff_take_n(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RFixed: {
          heff_take_n(v_e_2420, 0ULL, 2);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RF32: {
          heff_take_na(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RNTag: {
          heff_take_n(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RTag: {
          heff_take_n(v_e_2420, 0ULL, 3);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RTagIn: {
          heff_take_n(v_e_2420, 0ULL, 4);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RRec: {
          heff_take_n(v_e_2420, 0ULL, 3);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RRecIn: {
          heff_take_n(v_e_2420, 0ULL, 8);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RField: {
          heff_take_n(v_e_2420, 0ULL, 2);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RDupE: {
          heff_take_n(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RFieldV: {
          heff_take_n(v_e_2420, 0ULL, 2);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RGetN: {
          heff_take_n(v_e_2420, 0ULL, 3);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RFieldU: {
          heff_take_n(v_e_2420, 0ULL, 4);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RGetNU: {
          heff_take_n(v_e_2420, 0ULL, 5);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RWord: {
          heff_take_n(v_e_2420, 0ULL, 2);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RTakeField: {
          heff_take_n(v_e_2420, 0ULL, 2);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RGetLabel: {
          heff_take_n(v_e_2420, 0ULL, 2);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RPrimFn: {
          heff_take_n(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RPrim: {
          heff_take_n(v_e_2420, 0ULL, 2);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RLam: {
          heff_take_n(v_e_2420, 0ULL, 4);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RCall: {
          heff_take_n(v_e_2420, 0ULL, 4);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RApply: {
          heff_take_n(v_e_2420, 0ULL, 2);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RBool: {
          heff_take_n(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RAbandon: {
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RBox: {
          V v_r_2489 = heff_field(v_e_2420, 0);
          heff_take_n(v_e_2420, 1ULL, 2);
          switch (heff_tag_of(v_r_2489)) {
          case TAG_RepV: {
            heff_drop_cell(v_ru_24s_245_24CReturn, 1);
            v_t_24105 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RepFix: {
            v_t_24105 = heff_tag_at_n(v_ru_24s_245_24CReturn, TAG_Just, 1, (V[]){v_r_2489});
            break;
          }
          case TAG_RepF64: {
            v_t_24105 = heff_tag_at_n(v_ru_24s_245_24CReturn, TAG_Just, 1, (V[]){v_r_2489});
            break;
          }
          case TAG_RepInt: {
            heff_drop_cell(v_ru_24s_245_24CReturn, 1);
            v_t_24105 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_r_2489);
          }
          break;
        }
        case TAG_RUnbox: {
          heff_take_n(v_e_2420, 0ULL, 2);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RPeek: {
          heff_take_n(v_e_2420, 0ULL, 2);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RPrimU: {
          heff_take_n(v_e_2420, 0ULL, 2);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RPrimAt: {
          heff_take_n(v_e_2420, 0ULL, 3);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RFixU: {
          heff_take_n(v_e_2420, 0ULL, 2);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RF32U: {
          heff_take_na(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_RF64U: {
          heff_take_na(v_e_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24s_245_24CReturn, 1);
          v_t_24105 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_e_2420);
        }
        v_t_24121 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_24105, v_acc_244});
        break;
      }
      }
      break;
    }
    case TAG_CInPlace: {
      heff_take_n(v_s_245, 0ULL, 2);
      v_t_24121 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), v_acc_244});
      break;
    }
    case TAG_CRoomed: {
      heff_take_n(v_s_245, 0ULL, 2);
      v_t_24121 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), v_acc_244});
      break;
    }
    case TAG_CTail: {
      heff_take_n(v_s_245, 0ULL, 2);
      v_t_24121 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), v_acc_244});
      break;
    }
    case TAG_CLoop: {
      heff_take_n(v_s_245, 0ULL, 2);
      v_t_24121 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), v_acc_244});
      break;
    }
    case TAG_CLoopTo: {
      heff_take_n(v_s_245, 0ULL, 3);
      v_t_24121 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), v_acc_244});
      break;
    }
    case TAG_CLabel: {
      heff_take_n(v_s_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_24121 = v_acc_244;
      break;
    }
    case TAG_CJump: {
      heff_take_n(v_s_245, 0ULL, 3);
      v_t_24121 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), v_acc_244});
      break;
    }
    default: heff_nomatch(v_s_245);
    }
    V t_0 = v_t_24121;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s366449469x130665619_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s366449469x130665619(a[0], a[1]);
}
Clo g_list_2emap_24s784191759x2032889081_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s784191759x2032889081_24dps_entry, 2, 0};

V g_list_2emap_24s784191759x2032889081_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Given: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24Given = heff_take_reuse_n(v_x_242, 1ULL, 1);
      V v_t_245 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_a_244));
      v_t_2413 = heff_tag_at_n(v_ru_24x_242_24Given, TAG_Given, 1, (V[]){v_t_245});
      break;
    }
    case TAG_GivenU: {
      V v_a_246 = heff_field(v_x_242, 0);
      V v_a_247 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24GivenU = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_a_247));
      v_t_2413 = heff_tag_at_n(v_ru_24x_242_24GivenU, TAG_GivenU, 2, (V[]){v_a_246, v_t_248});
      break;
    }
    case TAG_LentVar: {
      v_t_2413 = v_x_242;
      break;
    }
    case TAG_LentValue: {
      V v_a_2411 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24LentValue = heff_take_reuse_n(v_x_242, 1ULL, 1);
      V v_t_2412 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_a_2411));
      v_t_2413 = heff_tag_at_n(v_ru_24x_242_24LentValue, TAG_LentValue, 1, (V[]){v_t_2412});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s784191759x2032889081_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s784191759x2032889081_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s932544939x1448830416_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s932544939x1448830416_entry, 2, 0};

V g_list_2efoldl_24s932544939x1448830416(V v_z_240, V v_x3_241) {
top: ;
  V v_params_242 = heff_take_field(v_z_240, 0);
  V v_result_243 = heff_get_n(v_z_240, 1, 2);
  return (g_list_2efoldl_24s932544939x1448830416_24scalars(v_params_242, v_result_243, v_x3_241));
}
V g_list_2efoldl_24s932544939x1448830416_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s932544939x1448830416(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2118756600x1920057229_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2118756600x1920057229_entry, 2, 0};

V g_list_2efoldl_24s2118756600x1920057229(V v_z_240, V v_x3_241) {
top: ;
  V v_gs_242 = heff_take_field(v_z_240, 0);
  V v_names_243 = heff_take_field(v_z_240, 1);
  V v_used_244 = heff_take_field(v_z_240, 2);
  V v_self_245 = heff_take_field(v_z_240, 3);
  V v_inl_246 = heff_get_n(v_z_240, 4, 5);
  return (g_list_2efoldl_24s2118756600x1920057229_24scalars(v_gs_242, v_names_243, v_used_244, v_self_245, v_inl_246, v_x3_241));
}
V g_list_2efoldl_24s2118756600x1920057229_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2118756600x1920057229(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1022483754x1154500907_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1022483754x1154500907_entry, 1, 0};

V g_list_2eany_24s1022483754x1154500907(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 3));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Gives: {
      heff_take_n(v_t_243, 0ULL, 1);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_GivesOrErrno: {
      heff_take_n(v_t_243, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_DoneOrErrno: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1022483754x1154500907_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1022483754x1154500907(a0); heff_drop(a0); return r;
}
Clo g_list_2eany_24s1362258228x1848434975_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1362258228x1848434975_entry, 1, 0};

V g_list_2eany_24s1362258228x1848434975(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_CInteger: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CDouble: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CBool: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CString: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CText: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_COwnedString: {
      return NTAG(TAG_True);
    }
    case TAG_CPointer: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CVoid: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1362258228x1848434975_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1362258228x1848434975(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s41085868x1118058949_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s41085868x1118058949_entry, 2, 0};

V g_list_2efoldl_24s41085868x1118058949(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    HeffT2 v_t_244 = ({ V b_0 = heff_dup(g_heff_2eelab_2eprimitive_2ecompilerTable_get()); V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2412;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      HeffT2 v_t_247 = ({ V b_0 = heff_dup(g_heff_2eelab_2eprimitive_2elibraryTable_get()); V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop(v_field_246);
          V v_a_2410 = v_field_249;
          v_t_2412 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2ecompile_2eemitc_2eprimCloOf(a_0)); heff_drop(v_a_2410); r_; });
        } else {
          heff_drop(v_field_249);
          if ((v_tag_245 == ((int64_t)0ULL))) {
            V v_a_2411 = v_field_246;
            v_t_2412 = ({ V a_0 = v_a_2411; V r_ = (g_heff_2ecompile_2eemitc_2eprimCloOf(a_0)); heff_drop(v_a_2411); r_; });
          } else {
            heff_drop(v_field_246);
            v_t_2412 = NTAG(TAG_Nil);
          }
        }
      }
    }
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s41085868x1118058949_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s41085868x1118058949(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1028839125x1033007016_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1028839125x1033007016_entry, 2, 0};

V g_list_2efoldl_24s1028839125x1033007016(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 1)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1028839125x1033007016_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1028839125x1033007016(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1127556009x863725781_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1127556009x863725781_24dps_entry, 7, 0};

V g_list_2emap_24s1127556009x863725781_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_244);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_249 = heff_strSlice(heff_dup(v_x_247), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    V v_t_2411;
    if (heff_strEq_c_lent(v_t_249, v_lit_242, 1)) {
      V v_t_2410 = ({ V a_0 = v_x_247; V a_1 = v_lit_243; V a_2 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2eidentAt(a_0, a_1, a_2)); heff_drop(v_x_247); r_; });
      v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
    } else {
      heff_drop(v_x_247);
      v_t_2411 = NTAG(TAG_Nothing);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_xs_248;
    V t_6 = v_cell_2412;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_x2_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s1127556009x863725781_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2emap_24s1127556009x863725781_24dps(a0, a1, a2, a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s537755658x300885499_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s537755658x300885499_entry, 2, 0};

V g_list_2efoldl_24s537755658x300885499(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2415;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 2ULL, 2);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2416 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, v_t_249, v_t_2415));
    V t_0 = v_t_2416;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s537755658x300885499_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s537755658x300885499(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1535007417x1587061701_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1535007417x1587061701_24dps_entry, 2, 0};

V g_list_2emap_24s1535007417x1587061701_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2426;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      V v_sp_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_244, 0ULL, 5);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_244, 0ULL, 5);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_244, 0ULL, 4);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2420 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x_242_24At, TAG_MkPair, 2, (V[]){v_x_2420, v_sp_245})});
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_244, 0ULL, 2);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_244, 0ULL, 1);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2427 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
    V v_u_2428 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2427));
    heff_drop(v_u_2428);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2427;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1535007417x1587061701_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1535007417x1587061701_24dps(a[0], a[1]);
}
Clo g_list_2edescending_24s1467056061x388427999_clo = {{0x80000000u, K_CLO, 0}, g_list_2edescending_24s1467056061x388427999_entry, 5, 0};

V g_list_2edescending_24s1467056061x388427999(V v_lit_240, V v_lit_241, V v_x_242, V v_acc_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop_rec(v_x_242, 10);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_245 = heff_field(v_x4_244, 0);
    V v_ys_246 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    V v_t_247 = heff_intSub(heff_dup(v_lit_240), heff_get_n(v_x_242, 0, 10));
    V v_t_248 = heff_intSub(heff_dup(v_lit_241), heff_dup(heff_rfield(v_y_245, 0)));
    if (heff_intLe_c(v_t_247, v_t_248)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, heff_tag_at_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, (V[]){v_y_245, v_ys_246})});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = heff_dup(v_y_245);
      V t_3 = heff_tag_at_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, (V[]){v_y_245, v_acc_243});
      V t_4 = v_ys_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x_242 = t_2;
      v_acc_243 = t_3;
      v_x4_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_list_2edescending_24s1467056061x388427999_entry(V self, V *a) {
  (void)self;
  return g_list_2edescending_24s1467056061x388427999(a[0], a[1], a[2], a[3], a[4]);
}
V g_list_2ecollapse_24s1709454359x897477238_lam0(V self, V *args);
Clo g_list_2ecollapse_24s1709454359x897477238_clo = {{0x80000000u, K_CLO, 0}, g_list_2ecollapse_24s1709454359x897477238_entry, 4, 0};

V g_list_2ecollapse_24s1709454359x897477238(V v_lit_240, V v_lit_241, V v_run_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_run_242;
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_rest_245 = heff_field(v_x3_243, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_below_247 = heff_field(v_x31_244, 1);
      V v_t_2411 = (g_list_2emerge(heff_clo_n(g_list_2ecollapse_24s1709454359x897477238_lam0, 2, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), heff_dup(v_below_247), v_run_242));
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_t_2411;
      V t_3 = v_rest_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_run_242 = t_2;
      v_x3_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2ecollapse_24s1709454359x897477238_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2ecollapse_24s1709454359x897477238(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_list_2ecollapse_24s1709454359x897477238_lam0(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_249 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2410 = heff_strCompare(heff_get_n(v_a_248, 0, 2), heff_get_n(v_a_249, 0, 2));
  V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_a_2410, v_lit_240, 0) || heff_intEq_c_lent(v_a_2410, v_lit_241, 0)));
  heff_drop(v_lit_240);
  heff_drop(v_lit_241);
  heff_drop(v_a_2410);
  return v_ret_24bool;
}
Clo g_list_2emap_24s1392650298x1192381411_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1392650298x1192381411_24dps_entry, 4, 0};

V g_list_2emap_24s1392650298x1192381411_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    heff_drop_rec(v_lit_241, 14);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_a_246 = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(heff_rfield(v_lit_240, 0))) && heff_intEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(heff_rfield(v_lit_240, 1)))));
    V v_t_247 = heff_rec_n(4, shape_path__source__span__defines, (V[]){heff_dup(heff_rfield(v_lit_241, 1)), heff_dup(heff_rfield(v_lit_241, 3)), v_x_244, v_a_246});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1392650298x1192381411_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1392650298x1192381411_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s759871588x920431471_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s759871588x920431471_24dps_entry, 2, 0};

V g_list_2emap_24s759871588x920431471_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 9), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s759871588x920431471_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s759871588x920431471_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2021078391x832341393_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2021078391x832341393_24dps_entry, 4, 0};

V g_list_2emap_24s2021078391x832341393_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_247;
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_240))) {
      V v_t_246 = heff_intAdd(heff_take_field(v_x_244, 3), heff_dup(v_lit_241));
      v_t_247 = ({ V rv_3 = v_t_246; V rr_ = heff_rec_reuse_nf(v_x_244, 23ULL, 5, shape_task__parent__name__done__total, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      v_t_247 = v_x_244;
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s2021078391x832341393_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2021078391x832341393_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eall_24s1461376987x321850093_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1461376987x321850093_entry, 1, 0};

V g_list_2eall_24s1461376987x321850093(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_n_243 = heff_dup(v_x_241);
    V v_t_246;
    if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_n_243, 0)))) {
      if (!(heff_unbox_word(heff_strByteAt_lent(v_n_243, MK_INT(0LL), 2)) == ((int64_t)46ULL))) {
        int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_n_243, 0)) - ((int64_t)1ULL));
        V v_t_245 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_244)));
        v_t_246 = ({ V a_0 = v_n_243; V a_1 = MK_INT(48LL); V a_2 = MK_INT(57LL); V a_3 = MK_INT(65LL); V a_4 = MK_INT(90LL); V a_5 = MK_INT(97LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(45LL); V a_8 = MK_INT(95LL); V a_9 = MK_INT(46LL); V a_10 = v_t_245; V r_ = (g_list_2eall_24s442836260x1032582242(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_n_243); heff_drop(v_t_245); r_; });
      } else {
        heff_drop(v_n_243);
        v_t_246 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_n_243);
      v_t_246 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1461376987x321850093_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1461376987x321850093(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1300477078x2058851060_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1300477078x2058851060_entry, 2, 0};

V g_list_2efoldl_24s1300477078x2058851060(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 3)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1300477078x2058851060_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1300477078x2058851060(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2epushRun_24s2022155310x1483676144_clo = {{0x80000000u, K_CLO, 0}, g_list_2epushRun_24s2022155310x1483676144_entry, 3, 0};

V g_list_2epushRun_24s2022155310x1483676144(V v_k_240, V v_run_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_j_245 = heff_field(v_x41_243, 0);
      V v_below_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24MkPair = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      if (heff_intEq_c_lent(v_j_245, v_k_240, 0)) {
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_j_245);
        heff_drop_cell(v_ru_24x41_243_24MkPair, 2);
        V v_t_247 = (g_list_2emerge_24s1926973041x331495419(v_below_246, v_run_241));
        V t_0 = heff_intAdd(v_k_240, MK_INT(1LL));
        V t_1 = v_t_247;
        V t_2 = v_rest_244;
        v_k_240 = t_0;
        v_run_241 = t_1;
        v_x4_242 = t_2;
        goto top;
      } else {
        V v_t_248 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_243_24MkPair, TAG_MkPair, 2, (V[]){v_j_245, v_below_246}), v_rest_244});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), v_t_248});
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2epushRun_24s2022155310x1483676144_entry(V self, V *a) {
  (void)self;
  return g_list_2epushRun_24s2022155310x1483676144(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1788498486x1573409871_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1788498486x1573409871_entry, 3, 0};

V g_list_2efoldl_24s1788498486x1573409871(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2efetch_2enewerTagged(heff_dup(v_lit_240), v_z_241, v_x_243));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1788498486x1573409871_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1788498486x1573409871(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1170504272x1852564147_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1170504272x1852564147_entry, 1, 0};

V g_list_2emap_24s1170504272x1852564147(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_ExplicitParam: {
        V v_x_245 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_245;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_248 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1170504272x1852564147_24dps(v_xs_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1170504272x1852564147_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1170504272x1852564147(a[0]);
}
Clo g_list_2emap_24s499193121x1224230698_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s499193121x1224230698_24dps_entry, 2, 0};

V g_list_2emap_24s499193121x1224230698_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2423;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_PatVar: {
        V v_x_246 = heff_field(v_x11_244, 0);
        V v_ru_24x11_244_24PatVar = heff_take_reuse_n(v_x11_244, 1ULL, 1);
        v_t_2423 = heff_tag_at_n(v_ru_24x11_244_24PatVar, TAG_Just, 1, (V[]){v_x_246});
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2424;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s499193121x1224230698_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s499193121x1224230698_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s582709368x2113456071_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s582709368x2113456071_entry, 1, 0};

V g_list_2emap_24s582709368x2113456071(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s582709368x2113456071_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s582709368x2113456071_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s582709368x2113456071(a[0]);
}
Clo g_list_2emap_24s296585291x885335139_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s296585291x885335139_24dps_entry, 2, 0};

V g_list_2emap_24s296585291x885335139_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_std_2ecli_2eheadOf(heff_dup(v_x_242)));
    V v_t_245 = (g_std_2ecli_2eline2(v_t_244, heff_get_n(v_x_242, 1, 4)));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s296585291x885335139_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s296585291x885335139_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1093229560x1486136516_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1093229560x1486136516_entry, 1, 0};

V g_list_2emap_24s1093229560x1486136516(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(2, shape_text__style, (V[]){v_x_241, NTAG(TAG_Plain)});
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1093229560x1486136516_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1093229560x1486136516_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1093229560x1486136516(a[0]);
}
Clo g_list_2emap_24f1619849299x1543923271_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1619849299x1543923271_entry, 1, 0};

V g_list_2emap_24f1619849299x1543923271(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_body_243 = heff_take_field(v_x_241, 2);
    V v_key_244 = heff_get_n(v_x_241, 0, 3);
    V v_t_2445;
    switch (heff_tag_of(v_body_243)) {
    case TAG_EVar: {
      heff_take_n(v_body_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_body_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      V v_t_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_body_243, NTAG(TAG_Nil)});
      v_t_2445 = (g_heff_2ecompile_2eworker_2enumericW(v_t_249));
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_body_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_body_243, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_body_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_body_243, 0ULL, 4);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_body_243, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_body_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_body_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_body_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_body_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_body_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_body_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_body_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_body_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_body_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_body_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_body_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_body_243, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_body_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_body_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_body_243);
    }
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop(v_t_2445);
      V v_cell_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_key_244, heff_hole()});
      V v_u_2447 = (g_list_2emap_24f1619849299x1543923271_24dps(v_xs_242, heff_dup(v_cell_2446)));
      heff_drop(v_u_2447);
      return v_cell_2446;
    } else {
      heff_drop(v_key_244);
      heff_drop(v_t_2445);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f1619849299x1543923271_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1619849299x1543923271(a[0]);
}
Clo g_list_2emap_24f1217399696x462307458_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1217399696x462307458_entry, 3, 0};

V g_list_2emap_24f1217399696x462307458(V v_lit_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return (g_list_2emap_24s231073986x752637537(v_lit_240, v_ys_242));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_243), heff_hole()});
    V v_u_246 = (g_list_2emap_24f1217399696x462307458_24dps(v_lit_240, v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2emap_24f1217399696x462307458_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1217399696x462307458(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f1005417903x1119563692_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1005417903x1119563692_24dps_entry, 4, 0};

V g_list_2emap_24f1005417903x1119563692_24dps(V v_lit_240, V v_a_241, V v_b_242, V v_d_243) {
top: ;
  if (heff_intLt_c_lent(v_b_242, v_a_241, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_244 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(heff_dup(v_a_241)));
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = heff_intAdd(v_a_241, MK_INT(1LL));
    V t_2 = v_b_242;
    V t_3 = v_cell_245;
    v_lit_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f1005417903x1119563692_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1005417903x1119563692_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f755592795x444686035_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f755592795x444686035_entry, 6, 0};

V g_list_2emap_24f755592795x444686035(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_shown_248 = heff_take_field(v_x_246, 2);
    V v_name_249 = heff_take_field(v_x_246, 0);
    V v_doc_2410 = heff_get_n(v_x_246, 1, 4);
    if (((heff_dup(v_shown_248) == NTAG(TAG_True)) && heff_strEq_c(heff_strSlice(heff_dup(v_name_249), heff_dup(v_lit_243), heff_strLength_lent(v_lit_244, 0)), heff_dup(v_lit_244)))) {
      heff_drop(v_shown_248);
      V v_a_2411 = v_name_249;
      V v_a_2412 = v_doc_2410;
      V v_t_2413;
      if (heff_strEq_c_lent(v_a_2412, v_lit_240, 0)) {
        heff_drop(v_a_2412);
        v_t_2413 = v_a_2411;
      } else {
        v_t_2413 = heff_strAppend(heff_strAppend(v_a_2411, heff_dup(v_lit_241)), v_a_2412);
      }
      V v_cell_2414 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, heff_dup(v_lit_242)), heff_hole()});
      V v_u_2415 = (g_list_2emap_24f755592795x444686035_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    } else {
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_shown_248);
      heff_drop(v_name_249);
      heff_drop(v_doc_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24f755592795x444686035_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V a4 = a[4]; V r = g_list_2emap_24f755592795x444686035(a0, a[1], a[2], a3, a4, a[5]); heff_drop(a0); heff_drop(a3); heff_drop(a4); return r;
}
Clo g_list_2efoldl_24f928374809x1955888331_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f928374809x1955888331_entry, 2, 0};

V g_list_2efoldl_24f928374809x1955888331(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_x_244 = (g_std_2eterminal_2ewidget_2ecolumns(heff_dup(v_x_242)));
    V t_0 = heff_intAdd(v_z_240, v_x_244);
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f928374809x1955888331_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f928374809x1955888331(a[0], a1); heff_drop(a1); return r;
}