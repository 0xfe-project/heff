// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ATail 47533
#define TAG_ArgExplicit 50404
#define TAG_At 8900
#define TAG_CBool 61457
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DoneOrErrno 39355
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_Flagged 28540
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_ImplicitParam 51130
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_PVar 52952
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Plain 3036
#define TAG_Positional 16703
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SError 24172
#define TAG_SetPath 11095
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_doc 309170
#define LBL_done 9584713
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_gs 10067
#define LBL_hash 9690581
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_inl 313953
#define LBL_key 315609
#define LBL_l 326
#define LBL_local 304503685
#define LBL_long 9823043
#define LBL_member 869372357
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_next 9873338
#define LBL_note 9882809
#define LBL_param 307795111
#define LBL_params 951713969
#define LBL_parent 951717845
#define LBL_part 9928890
#define LBL_path 9928940
#define LBL_renames 1324191545
#define LBL_result 1012715336
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_style 311138763
#define LBL_target 1066236092
#define LBL_task 10048076
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_total 311908190
#define LBL_used 10094724
#define LBL_v 336
#define LBL_version 583465758
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
static uint32_t shape_target__name__span[] = {LBL_target, LBL_name, LBL_span};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_heff_2ebuild_2ecommands_2erefusedReaching(V, V, V, V);
V g_heff_2ebuild_2ecommands_2erefusedReaching_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erefusedReaching_clo;
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eclosureGo(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclosureGo_clo;
V g_heff_2ebuild_2edriver_2eelabNeeding(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabNeeding_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNeeding_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ecompile_2eborrow_2eborAll(V, V);
V g_heff_2ecompile_2eborrow_2eborAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborAll_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeRes(V);
V g_heff_2ecompile_2eemit_2esafeRes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeRes_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2efuse_2earmKind(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2earmKind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2earmKind_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_clo;
V g_heff_2ecompile_2egenerate_2egivesSt_24s1231700486x2137372060(V, V);
V g_heff_2ecompile_2egenerate_2egivesSt_24s1231700486x2137372060_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egivesSt_24s1231700486x2137372060_clo;
V g_heff_2ecompile_2erefcount_2ethreadSt(V, V, V);
V g_heff_2ecompile_2erefcount_2ethreadSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ethreadSt_clo;
V g_heff_2ecompile_2esimplify_2earmOver(V, V, V);
V g_heff_2ecompile_2esimplify_2earmOver_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earmOver_clo;
V g_heff_2ecompile_2esimplify_2eflat(V);
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eflat_clo;
V g_heff_2ecompile_2esimplify_2emovesFirst(V, V);
V g_heff_2ecompile_2esimplify_2emovesFirst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emovesFirst_clo;
V g_heff_2ecompile_2esimplify_2esgFlat(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgFlat_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erules_2epatternCanFail(V, V);
V g_heff_2eelab_2erules_2epatternCanFail_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2epatternCanFail_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany_24s1022483754x1154500907(V);
V g_list_2eany_24s1022483754x1154500907_entry(V self, V *a);
extern Clo g_list_2eany_24s1022483754x1154500907_clo;
V g_list_2eany_24s1362258228x1848434975(V);
V g_list_2eany_24s1362258228x1848434975_entry(V self, V *a);
extern Clo g_list_2eany_24s1362258228x1848434975_clo;
V g_list_2eany_24s155774913x881635560(V, V, V);
V g_list_2eany_24s155774913x881635560_entry(V self, V *a);
extern Clo g_list_2eany_24s155774913x881635560_clo;
V g_list_2eany_24s1658412854x30850816(V, V);
V g_list_2eany_24s1658412854x30850816_entry(V self, V *a);
extern Clo g_list_2eany_24s1658412854x30850816_clo;
V g_list_2eany_24s1711939327x1502975912(V, V);
V g_list_2eany_24s1711939327x1502975912_entry(V self, V *a);
extern Clo g_list_2eany_24s1711939327x1502975912_clo;
V g_list_2eany_24s1742233102x56855645(V, V);
V g_list_2eany_24s1742233102x56855645_entry(V self, V *a);
extern Clo g_list_2eany_24s1742233102x56855645_clo;
V g_list_2eany_24s1875112453x1656618700(V, V);
V g_list_2eany_24s1875112453x1656618700_entry(V self, V *a);
extern Clo g_list_2eany_24s1875112453x1656618700_clo;
V g_list_2eany_24s1993301886x522650342(V, V);
V g_list_2eany_24s1993301886x522650342_entry(V self, V *a);
extern Clo g_list_2eany_24s1993301886x522650342_clo;
V g_list_2eany_24s930586707x1164893977(V, V);
V g_list_2eany_24s930586707x1164893977_entry(V self, V *a);
extern Clo g_list_2eany_24s930586707x1164893977_clo;
HeffT2 g_list_2efind_24s1541406305x377496150_24cpr(V, V);
HeffT2 g_list_2efind_24s52705367x722192183_24cpr(V, V);
HeffT2 g_list_2efind_24s727666736x1458251130_24cpr(V, V);
HeffT2 g_list_2efind_24s728994925x1501467390_24cpr(V, V);
HeffT2 g_list_2efind_24s945009177x1839852169_24cpr(V, V);
V g_list_2efoldl_24f1325733028x1311723093(V, V, V);
V g_list_2efoldl_24f1325733028x1311723093_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1325733028x1311723093_clo;
V g_list_2efoldl_24f1893121088x1729068047(V, V, V, V);
V g_list_2efoldl_24f1893121088x1729068047_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1893121088x1729068047_clo;
V g_list_2efoldl_24f545139853x5269120(V, V);
V g_list_2efoldl_24f545139853x5269120_entry(V self, V *a);
extern Clo g_list_2efoldl_24f545139853x5269120_clo;
V g_list_2efoldl_24f836170601x1639498774(V, V);
V g_list_2efoldl_24f836170601x1639498774_entry(V self, V *a);
extern Clo g_list_2efoldl_24f836170601x1639498774_clo;
V g_list_2efoldl_24f928374809x1955888331(V, V);
V g_list_2efoldl_24f928374809x1955888331_entry(V self, V *a);
extern Clo g_list_2efoldl_24f928374809x1955888331_clo;
V g_list_2efoldl_24s1028839125x1033007016(V, V);
V g_list_2efoldl_24s1028839125x1033007016_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1028839125x1033007016_clo;
V g_list_2efoldl_24s1271133029x1548514599(V, V);
V g_list_2efoldl_24s1271133029x1548514599_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1271133029x1548514599_clo;
V g_list_2efoldl_24s1300477078x2058851060(V, V);
V g_list_2efoldl_24s1300477078x2058851060_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1300477078x2058851060_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1606891938x229778616(V, V);
V g_list_2efoldl_24s1606891938x229778616_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1606891938x229778616_clo;
V g_list_2efoldl_24s1769360958x1839054239(V, V);
V g_list_2efoldl_24s1769360958x1839054239_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1769360958x1839054239_clo;
V g_list_2efoldl_24s2118756600x1920057229(V, V);
V g_list_2efoldl_24s2118756600x1920057229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2118756600x1920057229_clo;
V g_list_2efoldl_24s2118756600x1920057229_24scalars(V, V, V, V, V, V);
V g_list_2efoldl_24s2118756600x1920057229_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2118756600x1920057229_24scalars_clo;
V g_list_2efoldl_24s312236574x1326690653(V, V, V);
V g_list_2efoldl_24s312236574x1326690653_entry(V self, V *a);
extern Clo g_list_2efoldl_24s312236574x1326690653_clo;
V g_list_2efoldl_24s366449469x130665619(V, V);
V g_list_2efoldl_24s366449469x130665619_entry(V self, V *a);
extern Clo g_list_2efoldl_24s366449469x130665619_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s890299851x180637966(V, V);
V g_list_2efoldl_24s890299851x180637966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s890299851x180637966_clo;
V g_list_2efoldl_24s932544939x1448830416(V, V);
V g_list_2efoldl_24s932544939x1448830416_entry(V self, V *a);
extern Clo g_list_2efoldl_24s932544939x1448830416_clo;
V g_list_2efoldl_24s932544939x1448830416_24scalars(V, V, V);
V g_list_2efoldl_24s932544939x1448830416_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s932544939x1448830416_24scalars_clo;
V g_list_2ekeepIf_24f637868263x1584497112_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24f637868263x1584497112_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f637868263x1584497112_24dps_clo;
V g_list_2ekeepIf_24s110788034x1785682300(V);
V g_list_2ekeepIf_24s110788034x1785682300_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s110788034x1785682300_clo;
V g_list_2ekeepIf_24s110788034x1785682300_24dps(V, V);
V g_list_2ekeepIf_24s110788034x1785682300_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s110788034x1785682300_24dps_clo;
V g_list_2ekeepIf_24s176481989x1398310082(V, V);
V g_list_2ekeepIf_24s176481989x1398310082_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s176481989x1398310082_clo;
V g_list_2ekeepIf_24s176481989x1398310082_24dps(V, V, V);
V g_list_2ekeepIf_24s176481989x1398310082_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s176481989x1398310082_24dps_clo;
V g_list_2ekeepIf_24s41305598x2096901426(V, V);
V g_list_2ekeepIf_24s41305598x2096901426_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s41305598x2096901426_clo;
V g_list_2ekeepIf_24s41305598x2096901426_24dps(V, V, V);
V g_list_2ekeepIf_24s41305598x2096901426_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s41305598x2096901426_24dps_clo;
V g_list_2ekeepIf_24s625322158x634079572_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s625322158x634079572_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s625322158x634079572_24dps_clo;
V g_list_2ekeepIf_24s684755021x1118425975(V, V);
V g_list_2ekeepIf_24s684755021x1118425975_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s684755021x1118425975_clo;
V g_list_2ekeepIf_24s684755021x1118425975_24dps(V, V, V);
V g_list_2ekeepIf_24s684755021x1118425975_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s684755021x1118425975_24dps_clo;
V g_list_2ekeepIf_24s84893438x121839408_24dps(V, V, V, V);
V g_list_2ekeepIf_24s84893438x121839408_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s84893438x121839408_24dps_clo;
V g_list_2emap_24f1005417903x1119563692_24dps(V, V, V, V);
V g_list_2emap_24f1005417903x1119563692_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1005417903x1119563692_24dps_clo;
V g_list_2emap_24f1141799624x1826918381_24dps(V, V, V, V);
V g_list_2emap_24f1141799624x1826918381_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1141799624x1826918381_24dps_clo;
V g_list_2emap_24f1217399696x462307458(V, V, V);
V g_list_2emap_24f1217399696x462307458_entry(V self, V *a);
extern Clo g_list_2emap_24f1217399696x462307458_clo;
V g_list_2emap_24f1217399696x462307458_24dps(V, V, V, V);
V g_list_2emap_24f1217399696x462307458_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1217399696x462307458_24dps_clo;
V g_list_2emap_24f1293205645x619162872_24dps(V, V, V, V, V);
V g_list_2emap_24f1293205645x619162872_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1293205645x619162872_24dps_clo;
V g_list_2emap_24f1297529223x1960372761(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1297529223x1960372761_entry(V self, V *a);
extern Clo g_list_2emap_24f1297529223x1960372761_clo;
V g_list_2emap_24f1297529223x1960372761_24dps(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1297529223x1960372761_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1297529223x1960372761_24dps_clo;
V g_list_2emap_24f212342957x901221134(V, V, V, V, V);
V g_list_2emap_24f212342957x901221134_entry(V self, V *a);
extern Clo g_list_2emap_24f212342957x901221134_clo;
V g_list_2emap_24f212342957x901221134_24dps(V, V, V, V, V, V);
V g_list_2emap_24f212342957x901221134_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f212342957x901221134_24dps_clo;
V g_list_2emap_24f583754813x1054900711(V, V, V);
V g_list_2emap_24f583754813x1054900711_entry(V self, V *a);
extern Clo g_list_2emap_24f583754813x1054900711_clo;
V g_list_2emap_24f583754813x1054900711_24dps(V, V, V, V);
V g_list_2emap_24f583754813x1054900711_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f583754813x1054900711_24dps_clo;
V g_list_2emap_24f904804876x285797696_24dps(V, V, V, V);
V g_list_2emap_24f904804876x285797696_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f904804876x285797696_24dps_clo;
V g_list_2emap_24s1049096277x601353451(V);
V g_list_2emap_24s1049096277x601353451_entry(V self, V *a);
extern Clo g_list_2emap_24s1049096277x601353451_clo;
V g_list_2emap_24s1049096277x601353451_24dps(V, V);
V g_list_2emap_24s1049096277x601353451_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1049096277x601353451_24dps_clo;
V g_list_2emap_24s1093229560x1486136516(V);
V g_list_2emap_24s1093229560x1486136516_entry(V self, V *a);
extern Clo g_list_2emap_24s1093229560x1486136516_clo;
V g_list_2emap_24s1093229560x1486136516_24dps(V, V);
V g_list_2emap_24s1093229560x1486136516_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1093229560x1486136516_24dps_clo;
V g_list_2emap_24s1170504272x1852564147(V);
V g_list_2emap_24s1170504272x1852564147_entry(V self, V *a);
extern Clo g_list_2emap_24s1170504272x1852564147_clo;
V g_list_2emap_24s1170504272x1852564147_24dps(V, V);
V g_list_2emap_24s1170504272x1852564147_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1170504272x1852564147_24dps_clo;
V g_list_2emap_24s1171333510x402969237(V);
V g_list_2emap_24s1171333510x402969237_entry(V self, V *a);
extern Clo g_list_2emap_24s1171333510x402969237_clo;
V g_list_2emap_24s1171333510x402969237_24dps(V, V);
V g_list_2emap_24s1171333510x402969237_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1171333510x402969237_24dps_clo;
V g_list_2emap_24s1243189782x897571843_24dps(V, V, V);
V g_list_2emap_24s1243189782x897571843_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_24dps_clo;
V g_list_2emap_24s1341404685x1564972929(V);
V g_list_2emap_24s1341404685x1564972929_entry(V self, V *a);
extern Clo g_list_2emap_24s1341404685x1564972929_clo;
V g_list_2emap_24s1341404685x1564972929_24dps(V, V);
V g_list_2emap_24s1341404685x1564972929_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1341404685x1564972929_24dps_clo;
V g_list_2emap_24s1366476796x894764441(V, V);
V g_list_2emap_24s1366476796x894764441_entry(V self, V *a);
extern Clo g_list_2emap_24s1366476796x894764441_clo;
V g_list_2emap_24s1366476796x894764441_24dps(V, V, V);
V g_list_2emap_24s1366476796x894764441_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1366476796x894764441_24dps_clo;
V g_list_2emap_24s1412546768x2004463577_24dps(V, V, V, V, V);
V g_list_2emap_24s1412546768x2004463577_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1412546768x2004463577_24dps_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1415906091x1371825187_24dps(V, V);
V g_list_2emap_24s1415906091x1371825187_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_24dps_clo;
V g_list_2emap_24s1512396752x1753792987(V, V, V);
V g_list_2emap_24s1512396752x1753792987_entry(V self, V *a);
extern Clo g_list_2emap_24s1512396752x1753792987_clo;
V g_list_2emap_24s1512396752x1753792987_24dps(V, V, V, V);
V g_list_2emap_24s1512396752x1753792987_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1512396752x1753792987_24dps_clo;
V g_list_2emap_24s1524528409x1420927362(V);
V g_list_2emap_24s1524528409x1420927362_entry(V self, V *a);
extern Clo g_list_2emap_24s1524528409x1420927362_clo;
V g_list_2emap_24s1524528409x1420927362_24dps(V, V);
V g_list_2emap_24s1524528409x1420927362_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1524528409x1420927362_24dps_clo;
V g_list_2emap_24s1534167768x1221742344(V);
V g_list_2emap_24s1534167768x1221742344_entry(V self, V *a);
extern Clo g_list_2emap_24s1534167768x1221742344_clo;
V g_list_2emap_24s1534167768x1221742344_24dps(V, V);
V g_list_2emap_24s1534167768x1221742344_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1534167768x1221742344_24dps_clo;
V g_list_2emap_24s1535007417x1587061701_24dps(V, V);
V g_list_2emap_24s1535007417x1587061701_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1535007417x1587061701_24dps_clo;
V g_list_2emap_24s159228909x554161698_24dps(V, V, V, V, V);
V g_list_2emap_24s159228909x554161698_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s159228909x554161698_24dps_clo;
V g_list_2emap_24s1661513421x830177447_24dps(V, V, V, V);
V g_list_2emap_24s1661513421x830177447_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1661513421x830177447_24dps_clo;
V g_list_2emap_24s1675313341x192238134(V);
V g_list_2emap_24s1675313341x192238134_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_clo;
V g_list_2emap_24s1675313341x192238134_24dps(V, V);
V g_list_2emap_24s1675313341x192238134_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_24dps_clo;
V g_list_2emap_24s1791433880x1360378684_24dps(V, V);
V g_list_2emap_24s1791433880x1360378684_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1791433880x1360378684_24dps_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1817753698x509594538_24dps(V, V, V, V);
V g_list_2emap_24s1817753698x509594538_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1817753698x509594538_24dps_clo;
V g_list_2emap_24s1846289357x1055790465_24dps(V, V, V);
V g_list_2emap_24s1846289357x1055790465_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1846289357x1055790465_24dps_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24dps(V, V);
V g_list_2emap_24s1937570095x2110149801_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24dps_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_list_2emap_24s1990719097x1419059608_24dps(V, V);
V g_list_2emap_24s1990719097x1419059608_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_24dps_clo;
V g_list_2emap_24s2029274225x672412636(V, V, V, V);
V g_list_2emap_24s2029274225x672412636_entry(V self, V *a);
extern Clo g_list_2emap_24s2029274225x672412636_clo;
V g_list_2emap_24s2029274225x672412636_24dps(V, V, V, V, V);
V g_list_2emap_24s2029274225x672412636_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029274225x672412636_24dps_clo;
V g_list_2emap_24s2087317732x355496638_24dps(V, V);
V g_list_2emap_24s2087317732x355496638_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2087317732x355496638_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s296585291x885335139_24dps(V, V);
V g_list_2emap_24s296585291x885335139_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s296585291x885335139_24dps_clo;
V g_list_2emap_24s32026788x2029987799(V);
V g_list_2emap_24s32026788x2029987799_entry(V self, V *a);
extern Clo g_list_2emap_24s32026788x2029987799_clo;
V g_list_2emap_24s32026788x2029987799_24dps(V, V);
V g_list_2emap_24s32026788x2029987799_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s32026788x2029987799_24dps_clo;
V g_list_2emap_24s366989016x166432442(V);
V g_list_2emap_24s366989016x166432442_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_clo;
V g_list_2emap_24s366989016x166432442_24dps(V, V);
V g_list_2emap_24s366989016x166432442_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_24dps_clo;
V g_list_2emap_24s391650521x1406868658_24dps(V, V);
V g_list_2emap_24s391650521x1406868658_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s391650521x1406868658_24dps_clo;
V g_list_2emap_24s45270243x110012769(V);
V g_list_2emap_24s45270243x110012769_entry(V self, V *a);
extern Clo g_list_2emap_24s45270243x110012769_clo;
V g_list_2emap_24s45270243x110012769_24dps(V, V);
V g_list_2emap_24s45270243x110012769_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s45270243x110012769_24dps_clo;
V g_list_2emap_24s474585387x1072098790(V);
V g_list_2emap_24s474585387x1072098790_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_clo;
V g_list_2emap_24s474585387x1072098790_24dps(V, V);
V g_list_2emap_24s474585387x1072098790_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_24dps_clo;
V g_list_2emap_24s499193121x1224230698_24dps(V, V);
V g_list_2emap_24s499193121x1224230698_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s499193121x1224230698_24dps_clo;
V g_list_2emap_24s582709368x2113456071(V);
V g_list_2emap_24s582709368x2113456071_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_clo;
V g_list_2emap_24s582709368x2113456071_24dps(V, V);
V g_list_2emap_24s582709368x2113456071_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_24dps_clo;
V g_list_2emap_24s679881967x35917574_24dps(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s679881967x35917574_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s679881967x35917574_24dps_clo;
V g_list_2emap_24s759871588x920431471_24dps(V, V);
V g_list_2emap_24s759871588x920431471_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_24dps_clo;
V g_list_2emap_24s784191759x2032889081_24dps(V, V);
V g_list_2emap_24s784191759x2032889081_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s784191759x2032889081_24dps_clo;
V g_list_2emap_24s803586165x1676441765_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_24dps_clo;
V g_list_2emap_24s866308031x234213482_24dps(V, V, V, V, V, V);
V g_list_2emap_24s866308031x234213482_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s866308031x234213482_24dps_clo;
V g_list_2emerge_24dps(V, V, V, V);
V g_list_2emerge_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24dps_clo;
V g_list_2emerge_24s1037857700x2096250953_24dps(V, V, V);
V g_list_2emerge_24s1037857700x2096250953_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1037857700x2096250953_24dps_clo;
V g_list_2ezipWith_24s273466373x375450363(V, V);
V g_list_2ezipWith_24s273466373x375450363_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s273466373x375450363_clo;
V g_list_2ezipWith_24s273466373x375450363_24dps(V, V, V);
V g_list_2ezipWith_24s273466373x375450363_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s273466373x375450363_24dps_clo;
V g_list_2ezipWith_24s634456687x1151454243(V, V);
V g_list_2ezipWith_24s634456687x1151454243_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_clo;
V g_list_2ezipWith_24s634456687x1151454243_24dps(V, V, V);
V g_list_2ezipWith_24s634456687x1151454243_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2einteractive_2equoted(V);
V g_std_2ecli_2einteractive_2equoted_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2equoted_clo;
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
V g_std_2eterminal_2ewidget_2ecolumns(V);
V g_std_2eterminal_2ewidget_2ecolumns_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecolumns_clo;
Clo g_list_2efoldl_24s65689923x209800052_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s65689923x209800052_entry, 3, 0};

V g_list_2efoldl_24s65689923x209800052(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x3_242, 1);
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s65689923x209800052(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2eall_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_entry, 2, 0};

V g_list_2eall(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emerge_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24dps_entry, 4, 0};

V g_list_2emerge_24dps(V v_le_240, V v_x2_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return heff_setField(v_d_243, MK_INT(1LL), v_x3_242);
  }
  case TAG_Cons: {
    V v_x_244 = heff_dup(heff_field(v_x2_241, 0));
    V v_xs_245 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      return heff_setField(v_d_243, MK_INT(1LL), v_x2_241);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_242, 0);
      V v_ys_247 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      V v_t_248 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){heff_dup(v_x_244), heff_dup(v_y_246)}));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_cell_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = v_le_240;
        V t_1 = v_xs_245;
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_246, v_ys_247});
        V t_3 = v_cell_249;
        v_le_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_248);
        V v_cell_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_246, heff_hole()});
        V v_u_2412 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2411));
        heff_drop(v_u_2412);
        V t_0 = v_le_240;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_xs_245});
        V t_2 = v_ys_247;
        V t_3 = v_cell_2411;
        v_le_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emerge_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1415906091x1371825187_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1415906091x1371825187_entry, 1, 0};

V g_list_2emap_24s1415906091x1371825187(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1415906091x1371825187_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1415906091x1371825187(a[0]);
}
Clo g_list_2emap_24s1937570095x2110149801_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1937570095x2110149801_entry, 1, 0};

V g_list_2emap_24s1937570095x2110149801(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1937570095x2110149801_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1937570095x2110149801(a[0]);
}
Clo g_list_2efoldl_24s312236574x1326690653_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s312236574x1326690653_entry, 3, 0};

V g_list_2efoldl_24s312236574x1326690653(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2415;
    if (heff_intLe_c_lent(v_t_247, v_lit_240, 1)) {
      V v_a_2411;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_249 = heff_field(v_x_243, 0);
        v_a_2411 = heff_dup(v_a_249);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      switch (heff_tag_of(v_z_241)) {
      case TAG_Nothing: {
        v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_a_2411});
        break;
      }
      case TAG_Just: {
        V v_a_2412 = heff_field(v_z_241, 0);
        V v_ru_24z_241_24Just = heff_take_reuse_n(v_z_241, 1ULL, 1);
        V v_t_2414;
        if (heff_intLt_c_lent(v_a_2412, v_a_2411, 0)) {
          heff_drop(v_a_2412);
          v_t_2414 = v_a_2411;
        } else {
          heff_drop(v_a_2411);
          v_t_2414 = v_a_2412;
        }
        v_t_2415 = heff_tag_at_n(v_ru_24z_241_24Just, TAG_Just, 1, (V[]){v_t_2414});
        break;
      }
      default: heff_nomatch(v_z_241);
      }
    } else {
      v_t_2415 = v_z_241;
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2415;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s312236574x1326690653_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s312236574x1326690653(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s32026788x2029987799_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s32026788x2029987799_entry, 1, 0};

V g_list_2emap_24s32026788x2029987799(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_take_field(v_x_241, 0), heff_take_field(v_x_241, 1), NTAG(TAG_Nothing), heff_get_n(v_x_241, 2, 3), MK_INT(0LL), MK_INT(0LL)});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s32026788x2029987799_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s32026788x2029987799_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s32026788x2029987799(a[0]);
}
Clo g_list_2eany_24s930586707x1164893977_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s930586707x1164893977_entry, 2, 0};

V g_list_2eany_24s930586707x1164893977(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_lit_240, v_x_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s930586707x1164893977_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s930586707x1164893977(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1243189782x897571843_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1243189782x897571843_24dps_entry, 3, 0};

V g_list_2emap_24s1243189782x897571843_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_x_243}), heff_dup(v_lit_240)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1243189782x897571843_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1243189782x897571843_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s366989016x166432442_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366989016x166432442_entry, 1, 0};

V g_list_2emap_24s366989016x166432442(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_a_243)) {
      case TAG_SetPath: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_ru_24a_243_24SetPath = heff_take_reuse_n(v_a_243, 3ULL, 2);
        V v_t_2410;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_field(v_a_246, 0);
          V v_a_248 = heff_field(v_a_246, 1);
          heff_take_n(v_a_246, 3ULL, 2);
          V v_t_249 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_247));
          v_t_2410 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_249, v_a_248});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2411 = heff_tag_at_n(v_ru_24a_243_24SetPath, TAG_SetPath, 2, (V[]){v_a_245, v_t_2410});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = (g_list_2emap_24s366989016x166432442_24dps(v_xs_242, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366989016x166432442_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366989016x166432442(a[0]);
}
Clo g_list_2emap_24s474585387x1072098790_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s474585387x1072098790_entry, 1, 0};

V g_list_2emap_24s474585387x1072098790(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_ExplicitParam: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24ExplicitParam = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_249, v_a_248));
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_a_245, v_a_246, v_t_2410});
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_a_2412 = heff_field(v_a_243, 1);
        V v_a_2413 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24ImplicitParam = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2416;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_2415, v_a_2414));
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_a_2411, v_a_2412, v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = (g_list_2emap_24s474585387x1072098790_24dps(v_xs_242, heff_dup(v_cell_2419)));
    heff_drop(v_u_2420);
    return v_cell_2419;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s474585387x1072098790_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s474585387x1072098790(a[0]);
}
Clo g_list_2efoldl_24s890299851x180637966_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s890299851x180637966_entry, 2, 0};

V g_list_2efoldl_24s890299851x180637966(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2eflat(heff_dup(heff_rfield(v_x_242, 2))));
    V v_t_245 = ({ V a_0 = v_z_240; V a_1 = heff_dup(heff_rfield(v_x_242, 0)); V a_2 = v_t_244; V r_ = (g_heff_2ecompile_2esimplify_2esgFlat(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s890299851x180637966_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s890299851x180637966(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s155774913x881635560_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s155774913x881635560_entry, 3, 0};

V g_list_2eany_24s155774913x881635560(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = (g_heff_2ecompile_2esimplify_2earmOver(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_243));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s155774913x881635560_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eany_24s155774913x881635560(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1049096277x601353451_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1049096277x601353451_entry, 1, 0};

V g_list_2emap_24s1049096277x601353451(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2437;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_241, 0ULL, 4);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2438 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2437, heff_hole()});
    V v_u_2439 = (g_list_2emap_24s1049096277x601353451_24dps(v_xs_242, heff_dup(v_cell_2438)));
    heff_drop(v_u_2439);
    return v_cell_2438;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1049096277x601353451_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1049096277x601353451(a[0]);
}
Clo g_list_2eany_24s1742233102x56855645_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1742233102x56855645_entry, 2, 0};

V g_list_2eany_24s1742233102x56855645(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2emovesFirst(heff_dup(v_lit_240), v_x_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_lit_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1742233102x56855645_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1742233102x56855645(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s110788034x1785682300_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s110788034x1785682300_entry, 1, 0};

V g_list_2ekeepIf_24s110788034x1785682300(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_RepV: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_RepFix: {
      heff_take_n(v_t_245, 0ULL, 1);
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_248 = (g_list_2ekeepIf_24s110788034x1785682300_24dps(v_xs_242, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    case TAG_RepF64: {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2410 = (g_list_2ekeepIf_24s110788034x1785682300_24dps(v_xs_242, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    case TAG_RepInt: {
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2412 = (g_list_2ekeepIf_24s110788034x1785682300_24dps(v_xs_242, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s110788034x1785682300_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s110788034x1785682300(a[0]);
}
Clo g_list_2efoldl_24s1769360958x1839054239_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1769360958x1839054239_entry, 2, 0};

V g_list_2efoldl_24s1769360958x1839054239(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eborrow_2eborAll(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1769360958x1839054239_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1769360958x1839054239(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1341404685x1564972929_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1341404685x1564972929_entry, 1, 0};

V g_list_2emap_24s1341404685x1564972929(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 7ULL, 3);
      v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_a_244}), heff_tag_n(TAG_ATail, 1, (V[]){v_a_245})});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1341404685x1564972929_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1341404685x1564972929_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1341404685x1564972929(a[0]);
}
Clo g_list_2emap_24s1512396752x1753792987_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1512396752x1753792987_entry, 3, 0};

V g_list_2emap_24s1512396752x1753792987(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2erefcount_2ethreadSt(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1512396752x1753792987_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1512396752x1753792987_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1512396752x1753792987(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1512396752x1753792987_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1512396752x1753792987_24dps_entry, 4, 0};

V g_list_2emap_24s1512396752x1753792987_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2erefcount_2ethreadSt(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1512396752x1753792987_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1512396752x1753792987_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2ekeepIf_24s176481989x1398310082_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s176481989x1398310082_entry, 2, 0};

V g_list_2ekeepIf_24s176481989x1398310082(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_lit_240, v_t_246, 2)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_249 = (g_list_2ekeepIf_24s176481989x1398310082_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s176481989x1398310082_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s176481989x1398310082(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s45270243x110012769_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s45270243x110012769_entry, 1, 0};

V g_list_2emap_24s45270243x110012769(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s45270243x110012769_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s45270243x110012769_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s45270243x110012769(a[0]);
}

HeffT2 g_list_2efind_24s52705367x722192183_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 4);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2eany_24s1658412854x30850816_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1658412854x30850816_entry, 2, 0};

V g_list_2eany_24s1658412854x30850816(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 4);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_lit_240, 1)))) {
        heff_drop_rec(v_lit_240, 4);
        return NTAG(TAG_True);
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1658412854x30850816_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1658412854x30850816(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1606891938x229778616_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1606891938x229778616_entry, 2, 0};

V g_list_2efoldl_24s1606891938x229778616(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_dup(v_a_245)));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1606891938x229778616_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1606891938x229778616(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1990719097x1419059608_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1990719097x1419059608_entry, 1, 0};

V g_list_2emap_24s1990719097x1419059608(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tr(heff_call(v_x_241, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1990719097x1419059608_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1990719097x1419059608(a[0]);
}
Clo g_list_2ezipWith_24s273466373x375450363_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s273466373x375450363_entry, 2, 0};

V g_list_2ezipWith_24s273466373x375450363(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(v_y_244, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_247 = (g_heff_2eelab_2erules_2epatternCanFail(v_t_246, v_x_242));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s273466373x375450363_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s273466373x375450363_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s273466373x375450363(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s41305598x2096901426_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s41305598x2096901426_entry, 2, 0};

V g_list_2ekeepIf_24s41305598x2096901426(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_UpdateTo: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_2412 = v_a_244;
      break;
    }
    case TAG_UpdateIn: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 0));
      v_t_2412 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_2412, v_lit_240, 1)) {
      V v_cell_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2415 = (g_list_2ekeepIf_24s41305598x2096901426_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s41305598x2096901426_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s41305598x2096901426(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s866308031x234213482_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s866308031x234213482_24dps_entry, 6, 0};

V g_list_2emap_24s866308031x234213482_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_248 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = heff_dup(v_lit_242); V a_3 = v_lit_243; V a_4 = v_x_246; V r_ = (g_heff_2ecompile_2efuse_2earmKind(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_246); r_; });
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_xs_247;
    V t_5 = v_cell_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_x2_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s866308031x234213482_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2emap_24s866308031x234213482_24dps(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s366449469x130665619_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s366449469x130665619_entry, 2, 0};

V g_list_2efoldl_24s366449469x130665619(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2egenerate_2egivesSt_24s1231700486x2137372060(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s366449469x130665619_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s366449469x130665619(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1524528409x1420927362_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1524528409x1420927362_entry, 1, 0};

V g_list_2emap_24s1524528409x1420927362(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_Given: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24Given = heff_take_reuse_n(v_x_241, 1ULL, 1);
      V v_t_244 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_a_243));
      v_t_2412 = heff_tag_at_n(v_ru_24x_241_24Given, TAG_Given, 1, (V[]){v_t_244});
      break;
    }
    case TAG_GivenU: {
      V v_a_245 = heff_field(v_x_241, 0);
      V v_a_246 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24GivenU = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_a_246));
      v_t_2412 = heff_tag_at_n(v_ru_24x_241_24GivenU, TAG_GivenU, 2, (V[]){v_a_245, v_t_247});
      break;
    }
    case TAG_LentVar: {
      v_t_2412 = v_x_241;
      break;
    }
    case TAG_LentValue: {
      V v_a_2410 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24LentValue = heff_take_reuse_n(v_x_241, 1ULL, 1);
      V v_t_2411 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_a_2410));
      v_t_2412 = heff_tag_at_n(v_ru_24x_241_24LentValue, TAG_LentValue, 1, (V[]){v_t_2411});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = (g_list_2emap_24s1524528409x1420927362_24dps(v_xs_242, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1524528409x1420927362_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1524528409x1420927362(a[0]);
}
Clo g_list_2emap_24s784191759x2032889081_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s784191759x2032889081_24dps_entry, 2, 0};

V g_list_2emap_24s784191759x2032889081_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Given: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24Given = heff_take_reuse_n(v_x_242, 1ULL, 1);
      V v_t_245 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_a_244));
      v_t_2413 = heff_tag_at_n(v_ru_24x_242_24Given, TAG_Given, 1, (V[]){v_t_245});
      break;
    }
    case TAG_GivenU: {
      V v_a_246 = heff_field(v_x_242, 0);
      V v_a_247 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24GivenU = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_a_247));
      v_t_2413 = heff_tag_at_n(v_ru_24x_242_24GivenU, TAG_GivenU, 2, (V[]){v_a_246, v_t_248});
      break;
    }
    case TAG_LentVar: {
      v_t_2413 = v_x_242;
      break;
    }
    case TAG_LentValue: {
      V v_a_2411 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24LentValue = heff_take_reuse_n(v_x_242, 1ULL, 1);
      V v_t_2412 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_a_2411));
      v_t_2413 = heff_tag_at_n(v_ru_24x_242_24LentValue, TAG_LentValue, 1, (V[]){v_t_2412});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s784191759x2032889081_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s784191759x2032889081_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s391650521x1406868658_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s391650521x1406868658_24dps_entry, 2, 0};

V g_list_2emap_24s391650521x1406868658_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s391650521x1406868658_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s391650521x1406868658_24dps(a[0], a[1]);
}

HeffT2 g_list_2efind_24s945009177x1839852169_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 5);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s932544939x1448830416_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s932544939x1448830416_entry, 2, 0};

V g_list_2efoldl_24s932544939x1448830416(V v_z_240, V v_x3_241) {
top: ;
  return (g_list_2efoldl_24s932544939x1448830416_24scalars(heff_dup(heff_rfield(v_z_240, 0)), heff_get_n(v_z_240, 1, 2), v_x3_241));
}
V g_list_2efoldl_24s932544939x1448830416_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s932544939x1448830416(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2118756600x1920057229_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2118756600x1920057229_entry, 2, 0};

V g_list_2efoldl_24s2118756600x1920057229(V v_z_240, V v_x3_241) {
top: ;
  return (g_list_2efoldl_24s2118756600x1920057229_24scalars(heff_dup(heff_rfield(v_z_240, 0)), heff_dup(heff_rfield(v_z_240, 1)), heff_dup(heff_rfield(v_z_240, 2)), heff_dup(heff_rfield(v_z_240, 3)), heff_get_n(v_z_240, 4, 5), v_x3_241));
}
V g_list_2efoldl_24s2118756600x1920057229_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2118756600x1920057229(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1366476796x894764441_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1366476796x894764441_entry, 2, 0};

V g_list_2emap_24s1366476796x894764441(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_242, heff_dup(v_lit_240)), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1366476796x894764441_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1366476796x894764441_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1366476796x894764441(a[0], a[1]);
}
Clo g_list_2emap_24s679881967x35917574_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s679881967x35917574_24dps_entry, 11, 0};

V g_list_2emap_24s679881967x35917574_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_box_24lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_x2_249, V v_d_2410) {
  int64_t v_lit_244 = heff_unbox_word(v_box_24lit_244);
top: ;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_248);
    return heff_setField(v_d_2410, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_249, 0);
    V v_xs_2412 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24Cons = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_a_2413 = (g_prelude_2esplitFrom(v_lit_240, v_x_2411, heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_x_2411, v_lit_243, 0), NTAG(TAG_Nil)));
    V v_a_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_2413));
    V v_a_2417;
    switch (heff_tag_of(v_a_2414)) {
    case TAG_Nil: {
      v_a_2417 = v_x_2411;
      break;
    }
    case TAG_Cons: {
      V v_a_2415 = heff_field(v_a_2414, 0);
      heff_take_n(v_a_2414, 1ULL, 2);
      heff_drop(v_x_2411);
      v_a_2417 = v_a_2415;
      break;
    }
    default: heff_nomatch(v_a_2414);
    }
    int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_a_2417, 0)) - v_lit_244);
    V v_t_2419 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_a_2417, heff_box_word(v_t_2418)));
    V v_t_2420 = ({ V a_0 = v_a_2417; V a_1 = v_t_2419; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2419); r_; });
    V v_a_2421 = ({ V a_0 = v_t_2420; V a_1 = heff_dup(v_lit_245); V a_2 = heff_dup(v_lit_246); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
    V v_t_2423;
    if (heff_strEq_c_lent(v_a_2421, v_lit_247, 0)) {
      heff_drop(v_a_2421);
      v_t_2423 = heff_dup(v_lit_248);
    } else {
      v_t_2423 = v_a_2421;
    }
    V v_t_2424 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_2423));
    V v_cell_2425 = heff_tag_at_n(v_ru_24x2_249_24Cons, TAG_Cons, 2, (V[]){v_t_2424, heff_hole()});
    V v_u_2426 = heff_setField(v_d_2410, MK_INT(1LL), heff_dup(v_cell_2425));
    heff_drop(v_u_2426);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    int64_t t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_xs_2412;
    V t_10 = v_cell_2425;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_x2_249 = t_9;
    v_d_2410 = t_10;
    goto top;
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_list_2emap_24s679881967x35917574_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V a7 = a[7]; V r = g_list_2emap_24s679881967x35917574_24dps(a0, a[1], a2, a3, a[4], a[5], a[6], a7, a[8], a[9], a[10]); heff_drop(a0); heff_drop(a2); heff_drop(a3); heff_drop(a7); return r;
}
Clo g_list_2emap_24s803586165x1676441765_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s803586165x1676441765_24dps_entry, 8, 0};

V g_list_2emap_24s803586165x1676441765_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2410 = ({ V a_0 = v_lit_240; V a_1 = v_x_248; V a_2 = heff_dup(v_lit_241); V a_3 = heff_strFind_lent(v_lit_242, v_x_248, v_lit_243, 0); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_248); r_; });
    V v_a_2411 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2410));
    V v_t_2414;
    switch (heff_tag_of(v_a_2411)) {
    case TAG_Nil: {
      v_t_2414 = heff_dup(v_lit_244);
      break;
    }
    case TAG_Cons: {
      V v_a_2412 = heff_field(v_a_2411, 0);
      V v_a_2413 = heff_field(v_a_2411, 1);
      heff_take_n(v_a_2411, 3ULL, 2);
      v_t_2414 = ({ V a_0 = heff_dup(v_lit_245); V a_1 = v_a_2412; V a_2 = v_a_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2413); r_; });
      break;
    }
    default: heff_nomatch(v_a_2411);
    }
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2415;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s803586165x1676441765_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2emap_24s803586165x1676441765_24dps(a0, a[1], a2, a3, a[4], a[5], a[6], a[7]); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2ekeepIf_24s625322158x634079572_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s625322158x634079572_24dps_entry, 5, 0};

V g_list_2ekeepIf_24s625322158x634079572_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_245, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s625322158x634079572_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24s625322158x634079572_24dps(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2eany_24s1022483754x1154500907_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1022483754x1154500907_entry, 1, 0};

V g_list_2eany_24s1022483754x1154500907(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 3));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Gives: {
      heff_take_n(v_t_243, 0ULL, 1);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_GivesOrErrno: {
      heff_take_n(v_t_243, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_DoneOrErrno: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1022483754x1154500907_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1022483754x1154500907(a0); heff_drop(a0); return r;
}
Clo g_list_2eany_24s1362258228x1848434975_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1362258228x1848434975_entry, 1, 0};

V g_list_2eany_24s1362258228x1848434975(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_CInteger: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CDouble: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CBool: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CString: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CText: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_COwnedString: {
      return NTAG(TAG_True);
    }
    case TAG_CPointer: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CVoid: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1362258228x1848434975_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1362258228x1848434975(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1028839125x1033007016_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1028839125x1033007016_entry, 2, 0};

V g_list_2efoldl_24s1028839125x1033007016(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 1)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1028839125x1033007016_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1028839125x1033007016(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1846289357x1055790465_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1846289357x1055790465_24dps_entry, 3, 0};

V g_list_2emap_24s1846289357x1055790465_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1846289357x1055790465_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1846289357x1055790465_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s1534167768x1221742344_str0, 56, "only the library that goes with heff declares primitives");
Clo g_list_2emap_24s1534167768x1221742344_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1534167768x1221742344_entry, 1, 0};

V g_list_2emap_24s1534167768x1221742344(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(335LL), NTAG(TAG_SError), ((V)&g_list_2emap_24s1534167768x1221742344_str0), v_sp_244, NTAG(TAG_Nothing)});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1534167768x1221742344_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1534167768x1221742344_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1534167768x1221742344(a[0]);
}
Clo g_list_2emap_24s1535007417x1587061701_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1535007417x1587061701_24dps_entry, 2, 0};

V g_list_2emap_24s1535007417x1587061701_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2426;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      V v_sp_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_244, 0ULL, 5);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_244, 0ULL, 5);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_244, 0ULL, 4);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2420 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x_242_24At, TAG_MkPair, 2, (V[]){v_x_2420, v_sp_245})});
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_244, 0ULL, 2);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_244, 0ULL, 1);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2427 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
    V v_u_2428 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2427));
    heff_drop(v_u_2428);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2427;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1535007417x1587061701_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1535007417x1587061701_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1271133029x1548514599_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1271133029x1548514599_entry, 2, 0};

V g_list_2efoldl_24s1271133029x1548514599(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_x_242, 6)), heff_dup(heff_rfield(v_x_242, 4))));
    V v_a_245 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_x_242, 5), v_t_244));
    V v_t_246 = (g_list_2emap_24s1817208647x1282894070(heff_dup(heff_rfield(v_a_245, 0))));
    V v_a_247 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_246));
    V v_t_248 = (g_heff_2ebuild_2edriver_2eclosureGo(heff_dup(v_z_240), NTAG(TAG_Nil), v_a_247));
    V v_t_249 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_a_245; V b_3 = NTAG(TAG_Nothing); V a_4 = v_t_248; V r_ = (g_heff_2ebuild_2edriver_2eelabNeeding(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); heff_drop(v_t_248); r_; });
    V v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2ebuild_2edriver_2eappendD(v_z_240, v_t_2410));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1271133029x1548514599_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1271133029x1548514599(a[0], a[1]);
}
Clo g_list_2eany_24s1993301886x522650342_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1993301886x522650342_entry, 2, 0};

V g_list_2eany_24s1993301886x522650342(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_242), heff_dup(heff_rfield(v_lit_240, 1)))) {
      heff_drop_rec(v_lit_240, 2);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1993301886x522650342_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1993301886x522650342(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emerge_24s1037857700x2096250953_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1037857700x2096250953_24dps_entry, 3, 0};

V g_list_2emerge_24s1037857700x2096250953_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x3_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 5);
      heff_drop(v_xs_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x2_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 1, 2);
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 0, 2);
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_y_245, 0)), 1, 2);
      V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_y_245, 0)), 0, 2);
      if (heff_intLe_c(heff_intSub(v_t_247, v_t_248), heff_intSub(v_t_249, v_t_2410))) {
        V v_cell_2412 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
        heff_drop(v_u_2413);
        V t_0 = v_xs_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246});
        V t_2 = v_cell_2412;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_2414 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2415 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2414));
        heff_drop(v_u_2415);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244});
        V t_1 = v_ys_246;
        V t_2 = v_cell_2414;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s1037857700x2096250953_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1037857700x2096250953_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1817753698x509594538_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1817753698x509594538_24dps_entry, 4, 0};

V g_list_2emap_24s1817753698x509594538_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_rec_n(3, shape_key__member__local, (V[]){heff_dup(v_lit_240), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    V v_a_247 = heff_take_field(v_x_244, 0);
    V v_a_248 = heff_intSub(heff_dup(heff_rfield(v_x_244, 1)), heff_strLength_lent(v_lit_241, 0));
    V v_t_2410;
    if (heff_intLe_c_lent(v_a_247, v_a_248, 0)) {
      heff_drop(v_a_247);
      v_t_2410 = v_a_248;
    } else {
      heff_drop(v_a_248);
      v_t_2410 = v_a_247;
    }
    V v_t_2411 = ({ V rv_0 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_x_244, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_target__name__span, (V[]){v_t_246, heff_dup(v_lit_241), v_t_2411}), heff_hole()});
    V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_2412;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1817753698x509594538_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1817753698x509594538_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1675313341x192238134_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1675313341x192238134_entry, 1, 0};

V g_list_2emap_24s1675313341x192238134(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkEquation: {
        V v_fsp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 2ULL, 4);
        v_t_249 = v_fsp_246;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s1675313341x192238134_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1675313341x192238134_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1675313341x192238134(a[0]);
}
Clo g_list_2eany_24s1711939327x1502975912_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1711939327x1502975912_entry, 2, 0};

V g_list_2eany_24s1711939327x1502975912(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 2);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1711939327x1502975912_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1711939327x1502975912(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_list_2efind_24s728994925x1501467390_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 14);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s759871588x920431471_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s759871588x920431471_24dps_entry, 2, 0};

V g_list_2emap_24s759871588x920431471_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 9), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s759871588x920431471_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s759871588x920431471_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s634456687x1151454243_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s634456687x1151454243_entry, 2, 0};

V g_list_2ezipWith_24s634456687x1151454243(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_244, 0, 3), v_x_242});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s634456687x1151454243_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s634456687x1151454243_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s634456687x1151454243(a[0], a[1]);
}
Clo g_list_2emap_24s1791433880x1360378684_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1791433880x1360378684_24dps_entry, 2, 0};

V g_list_2emap_24s1791433880x1360378684_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1791433880x1360378684_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1791433880x1360378684_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2029274225x672412636_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029274225x672412636_entry, 4, 0};

V g_list_2emap_24s2029274225x672412636(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_take_field(v_x_244, 2), heff_dup(v_lit_242));
    V v_t_247 = heff_strAppend(heff_take_field(v_x_244, 1), heff_strAppend(heff_dup(v_lit_241), v_t_246));
    V v_t_248 = heff_strAppend(heff_get_n(v_x_244, 0, 3), heff_strAppend(heff_dup(v_lit_240), v_t_247));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s2029274225x672412636_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s2029274225x672412636_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029274225x672412636(a[0], a[1], a[2], a[3]);
}
Clo g_list_2ekeepIf_24s684755021x1118425975_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s684755021x1118425975_entry, 2, 0};

V g_list_2ekeepIf_24s684755021x1118425975(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2ekeepIf_24s684755021x1118425975_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s684755021x1118425975_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s684755021x1118425975(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s2087317732x355496638_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2087317732x355496638_24dps_entry, 2, 0};

V g_list_2emap_24s2087317732x355496638_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 5), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2087317732x355496638_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2087317732x355496638_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1661513421x830177447_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1661513421x830177447_24dps_entry, 4, 0};

V g_list_2emap_24s1661513421x830177447_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_248;
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_240))) {
      V v_t_247 = heff_intAdd(heff_take_field(v_x_244, 3), heff_dup(v_lit_241));
      v_t_248 = ({ V rv_3 = v_t_247; V rr_ = heff_rec_reuse_nf(v_x_244, 23ULL, 5, shape_task__parent__name__done__total, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      v_t_248 = v_x_244;
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1661513421x830177447_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1661513421x830177447_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s159228909x554161698_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s159228909x554161698_24dps_entry, 5, 0};

V g_list_2emap_24s159228909x554161698_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = (g_heff_2ebuild_2ecommands_2erefusedReaching(heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242, v_x_245));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s159228909x554161698_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s159228909x554161698_24dps(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s1300477078x2058851060_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1300477078x2058851060_entry, 2, 0};

V g_list_2efoldl_24s1300477078x2058851060(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 3)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1300477078x2058851060_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1300477078x2058851060(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1875112453x1656618700_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1875112453x1656618700_entry, 2, 0};

V g_list_2eany_24s1875112453x1656618700(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1875112453x1656618700_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1875112453x1656618700(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1170504272x1852564147_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1170504272x1852564147_entry, 1, 0};

V g_list_2emap_24s1170504272x1852564147(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_ExplicitParam: {
        V v_x_245 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_245;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_248 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1170504272x1852564147_24dps(v_xs_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1170504272x1852564147_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1170504272x1852564147(a[0]);
}
Clo g_list_2emap_24s499193121x1224230698_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s499193121x1224230698_24dps_entry, 2, 0};

V g_list_2emap_24s499193121x1224230698_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2423;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_PatVar: {
        V v_x_246 = heff_field(v_x11_244, 0);
        V v_ru_24x11_244_24PatVar = heff_take_reuse_n(v_x11_244, 1ULL, 1);
        v_t_2423 = heff_tag_at_n(v_ru_24x11_244_24PatVar, TAG_Just, 1, (V[]){v_x_246});
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_na(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2424;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s499193121x1224230698_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s499193121x1224230698_24dps(a[0], a[1]);
}

HeffT2 g_list_2efind_24s727666736x1458251130_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 3);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s582709368x2113456071_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s582709368x2113456071_entry, 1, 0};

V g_list_2emap_24s582709368x2113456071(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s582709368x2113456071_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s582709368x2113456071_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s582709368x2113456071(a[0]);
}
Clo g_list_2ekeepIf_24s84893438x121839408_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s84893438x121839408_24dps_entry, 4, 0};

V g_list_2ekeepIf_24s84893438x121839408_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_246, v_lit_241, 1)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s84893438x121839408_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2ekeepIf_24s84893438x121839408_24dps(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s296585291x885335139_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s296585291x885335139_24dps_entry, 2, 0};

V g_list_2emap_24s296585291x885335139_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_std_2ecli_2eheadOf(heff_dup(v_x_242)));
    V v_t_245 = (g_std_2ecli_2eline2(v_t_244, heff_get_n(v_x_242, 1, 4)));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s296585291x885335139_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s296585291x885335139_24dps(a[0], a[1]);
}

HeffT2 g_list_2efind_24s1541406305x377496150_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 4);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s1412546768x2004463577_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1412546768x2004463577_24dps_entry, 5, 0};

V g_list_2emap_24s1412546768x2004463577_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_245, 0));
      v_a_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_a_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 2ULL, 2);
      v_a_2412 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2414;
    if (heff_strEq_c_lent(v_a_2412, v_lit_240, 0)) {
      heff_drop(v_a_2412);
      v_t_2414 = v_a_249;
    } else {
      v_t_2414 = heff_strAppend(v_a_249, heff_strAppend(heff_dup(v_lit_241), v_a_2412));
    }
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2414, heff_dup(v_lit_242)), heff_hole()});
    V v_u_2416 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2415;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1412546768x2004463577_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1412546768x2004463577_24dps(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1171333510x402969237_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1171333510x402969237_entry, 1, 0};

V g_list_2emap_24s1171333510x402969237(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2einteractive_2equoted(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1171333510x402969237_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1171333510x402969237_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1171333510x402969237(a[0]);
}
Clo g_list_2emap_24s1093229560x1486136516_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1093229560x1486136516_entry, 1, 0};

V g_list_2emap_24s1093229560x1486136516(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(2, shape_text__style, (V[]){v_x_241, NTAG(TAG_Plain)});
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1093229560x1486136516_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1093229560x1486136516_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1093229560x1486136516(a[0]);
}
Clo g_list_2emap_24f212342957x901221134_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f212342957x901221134_entry, 5, 0};

V g_list_2emap_24f212342957x901221134(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_p_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = heff_tr(heff_call(heff_dup(v_p_243), 1, (V[]){heff_dup(v_x_245)}));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_t_248 = heff_strAppend(heff_take_field(v_x_245, 1), heff_dup(v_lit_242));
      V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 2), heff_get_n(v_x_245, 3, 7)});
      V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), heff_strAppend(heff_dup(v_lit_241), v_t_248), v_t_249, NTAG(TAG_Nothing)});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = (g_list_2emap_24f212342957x901221134_24dps(v_lit_240, v_lit_241, v_lit_242, v_p_243, v_xs_246, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    } else {
      heff_drop_rec(v_x_245, 7);
      heff_drop_cell(v_ru_24x2_244_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_p_243;
      V t_4 = v_xs_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_p_243 = t_3;
      v_x2_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f212342957x901221134_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f212342957x901221134(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24f836170601x1639498774_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f836170601x1639498774_entry, 2, 0};

V g_list_2efoldl_24f836170601x1639498774(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_x_247 = v_b_246;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f836170601x1639498774_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f836170601x1639498774(a[0], a[1]);
}
Clo g_list_2efoldl_24f1893121088x1729068047_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1893121088x1729068047_entry, 4, 0};

V g_list_2efoldl_24f1893121088x1729068047(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (heff_strEq_c_lent(v_x_244, v_lit_242, 0)) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f1893121088x1729068047_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_list_2efoldl_24f1893121088x1729068047(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f1325733028x1311723093_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1325733028x1311723093_entry, 3, 0};

V g_list_2efoldl_24f1325733028x1311723093(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if ((heff_dup(v_x_243) == NTAG(TAG_True))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1325733028x1311723093_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f1325733028x1311723093(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24f637868263x1584497112_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f637868263x1584497112_24dps_entry, 5, 0};

V g_list_2ekeepIf_24f637868263x1584497112_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x1_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_245 = heff_field(v_x1_243, 0);
    V v_xs_246 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24Cons = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x1_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
    case TAG_Just: {
      V v_x_247 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      if (heff_strEq_c(heff_strSlice_lent(v_x_247, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
        heff_drop_cell(v_ru_24x1_243_24Cons, 2);
        heff_drop(v_x_247);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_d_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x1_243 = t_3;
        v_d_244 = t_4;
        goto top;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24x1_243_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
        V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_246;
        V t_4 = v_cell_249;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x1_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_list_2ekeepIf_24f637868263x1584497112_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24f637868263x1584497112_24dps(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1293205645x619162872_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1293205645x619162872_24dps_entry, 5, 0};

V g_list_2emap_24f1293205645x619162872_24dps(V v_lit_240, V v_lit_241, V v_a_242, V v_b_243, V v_d_244) {
top: ;
  if (heff_intLt_c_lent(v_b_243, v_a_242, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_246 = heff_strAppend(heff_intShow(heff_dup(v_a_242)), heff_dup(v_lit_241));
    V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_246), heff_hole()});
    V v_u_248 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_intAdd(v_a_242, MK_INT(1LL));
    V t_3 = v_b_243;
    V t_4 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
}
V g_list_2emap_24f1293205645x619162872_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1293205645x619162872_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24f1217399696x462307458_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1217399696x462307458_entry, 3, 0};

V g_list_2emap_24f1217399696x462307458(V v_lit_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return (g_list_2emap_24s231073986x752637537(v_lit_240, v_ys_242));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_243), heff_hole()});
    V v_u_246 = (g_list_2emap_24f1217399696x462307458_24dps(v_lit_240, v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2emap_24f1217399696x462307458_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1217399696x462307458(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f1005417903x1119563692_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1005417903x1119563692_24dps_entry, 4, 0};

V g_list_2emap_24f1005417903x1119563692_24dps(V v_lit_240, V v_a_241, V v_b_242, V v_d_243) {
top: ;
  if (heff_intLt_c_lent(v_b_242, v_a_241, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(heff_dup(v_a_241)));
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = heff_intAdd(v_a_241, MK_INT(1LL));
    V t_2 = v_b_242;
    V t_3 = v_cell_246;
    v_lit_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f1005417903x1119563692_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1005417903x1119563692_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f583754813x1054900711_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f583754813x1054900711_entry, 3, 0};

V g_list_2emap_24f583754813x1054900711(V v_lit_240, V v_box_24lit_241, V v_x2_242) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if ((v_lit_241 < heff_unbox_word(heff_strLength_lent(v_x_243, 0)))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_243), heff_hole()});
      V v_u_247 = (g_list_2emap_24f583754813x1054900711_24dps(v_lit_240, heff_box_word(v_lit_241), v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f583754813x1054900711_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f583754813x1054900711(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f904804876x285797696_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f904804876x285797696_24dps_entry, 4, 0};

V g_list_2emap_24f904804876x285797696_24dps(V v_f_240, V v_box_24a_241, V v_box_24b_242, V v_d_243) {
  int64_t v_a_241 = heff_unbox_word(v_box_24a_241);
  int64_t v_b_242 = heff_unbox_word(v_box_24b_242);
top: ;
  if ((v_b_242 < v_a_241)) {
    heff_drop(v_f_240);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_box_word(v_a_241)}));
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_f_240;
    int64_t t_1 = (v_a_241 + ((int64_t)1ULL));
    int64_t t_2 = v_b_242;
    V t_3 = v_cell_246;
    v_f_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f904804876x285797696_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f904804876x285797696_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f1297529223x1960372761_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1297529223x1960372761_entry, 13, 0};

V g_list_2emap_24f1297529223x1960372761(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_x2_2412) {
top: ;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24Cons = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_x_2413, 0)) - heff_unbox_word(heff_strLength_lent(v_lit_247, 0)));
    V v_t_2416 = heff_strSlice(heff_dup(v_x_2413), heff_box_word(v_t_2415), heff_strLength_lent(v_x_2413, 0));
    if (heff_strEq_c_lent(v_t_2416, v_lit_248, 1)) {
      if (heff_strEq_c(heff_strSlice_lent(v_x_2413, v_lit_249, v_lit_2410, 0), heff_dup(v_lit_2411))) {
        heff_drop(v_x_2413);
        heff_drop_cell(v_ru_24x2_2412_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_lit_245;
        V t_6 = v_lit_246;
        V t_7 = v_lit_247;
        V t_8 = v_lit_248;
        V t_9 = v_lit_249;
        V t_10 = v_lit_2410;
        V t_11 = v_lit_2411;
        V t_12 = v_xs_2414;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_lit_245 = t_5;
        v_lit_246 = t_6;
        v_lit_247 = t_7;
        v_lit_248 = t_8;
        v_lit_249 = t_9;
        v_lit_2410 = t_10;
        v_lit_2411 = t_11;
        v_x2_2412 = t_12;
        goto top;
      } else {
        int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_x_2413, 0)) - heff_peek_word(v_lit_242));
        int64_t v_t_2420 = (heff_unbox_word(heff_strLength_lent(v_x_2413, 0)) - heff_peek_word(v_lit_245));
        V v_t_2421 = heff_strAppend(heff_strSlice_lent(v_x_2413, v_lit_244, heff_box_word(v_t_2420), 4), heff_dup(v_lit_246));
        V v_t_2422 = heff_strAppend(heff_strSlice_lent(v_x_2413, v_lit_241, heff_box_word(v_t_2419), 5), heff_strAppend(heff_dup(v_lit_243), v_t_2421));
        V v_cell_2423 = heff_tag_at_n(v_ru_24x2_2412_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2422), heff_hole()});
        V v_u_2424 = (g_list_2emap_24f1297529223x1960372761_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_249, v_lit_2410, v_lit_2411, v_xs_2414, heff_dup(v_cell_2423)));
        heff_drop(v_u_2424);
        return v_cell_2423;
      }
    } else {
      heff_drop(v_x_2413);
      heff_drop_cell(v_ru_24x2_2412_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      V t_10 = v_lit_2410;
      V t_11 = v_lit_2411;
      V t_12 = v_xs_2414;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_lit_2411 = t_11;
      v_x2_2412 = t_12;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_list_2emap_24f1297529223x1960372761_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V a7 = a[7]; V a8 = a[8]; V a9 = a[9]; V a10 = a[10]; V a11 = a[11]; V r = g_list_2emap_24f1297529223x1960372761(a[0], a1, a[2], a[3], a4, a[5], a[6], a7, a8, a9, a10, a11, a[12]); heff_drop(a1); heff_drop(a4); heff_drop(a7); heff_drop(a8); heff_drop(a9); heff_drop(a10); heff_drop(a11); return r;
}
Clo g_list_2emap_24f1141799624x1826918381_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1141799624x1826918381_24dps_entry, 4, 0};

V g_list_2emap_24f1141799624x1826918381_24dps(V v_lit_240, V v_p_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_244)}));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_244, 0, 8));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_248;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 8);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f1141799624x1826918381_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1141799624x1826918381_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f928374809x1955888331_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f928374809x1955888331_entry, 2, 0};

V g_list_2efoldl_24f928374809x1955888331(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_x_244 = (g_std_2eterminal_2ewidget_2ecolumns(heff_dup(v_x_242)));
    V t_0 = heff_intAdd(v_z_240, v_x_244);
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f928374809x1955888331_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f928374809x1955888331(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f545139853x5269120_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f545139853x5269120_entry, 2, 0};

V g_list_2efoldl_24f545139853x5269120(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 0));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Positional: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_z_240;
      V t_1 = v_xs_243;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Flagged: {
      heff_take_n(v_t_244, 0ULL, 1);
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_z_240});
      V t_1 = v_xs_243;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f545139853x5269120_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f545139853x5269120(a[0], a[1]);
}