// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ATail 47533
#define TAG_ArgExplicit 50404
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_CDrop 58400
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ImplicitParam 51130
#define TAG_Kept 49931
#define TAG_Literal 34173
#define TAG_Merge 54398
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_PVar 52952
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Pinned 8573
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unboxed 46787
#define TAG_Wants 58903
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_doc 309170
#define LBL_done 9584713
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_entries 787768015
#define LBL_field 298786068
#define LBL_first 298798794
#define LBL_groups 709681407
#define LBL_gs 10067
#define LBL_hash 9690581
#define LBL_holds 300818350
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_inl 313953
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_local 304503685
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_params 951713969
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_places 961367927
#define LBL_refs 9991943
#define LBL_renames 1324191545
#define LBL_result 1012715336
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_target 1066236092
#define LBL_task 10048076
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_tok 324554
#define LBL_total 311908190
#define LBL_ty 10476
#define LBL_used 10094724
#define LBL_version 583465758
#define LBL_watch 314261737
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_gs__names__used__self__inl[] = {LBL_gs, LBL_names, LBL_used, LBL_self, LBL_inl};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_instances};
static uint32_t shape_params__result[] = {LBL_params, LBL_result};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
static uint32_t shape_target__name__span[] = {LBL_target, LBL_name, LBL_span};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eclosureGo(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclosureGo_clo;
V g_heff_2ebuild_2edriver_2eelabNeeding(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabNeeding_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNeeding_clo;
V g_heff_2ebuild_2edriver_2elabelOfV(V);
V g_heff_2ebuild_2edriver_2elabelOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elabelOfV_clo;
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2eborrow_2eborAll(V, V);
V g_heff_2ecompile_2eborrow_2eborAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborAll_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2efuse_2econsumerOf(V, V);
V g_heff_2ecompile_2efuse_2econsumerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econsumerOf_clo;
V g_heff_2ecompile_2eimperative_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2esimplify_2eflat(V);
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eflat_clo;
V g_heff_2ecompile_2esimplify_2esgFlat(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgFlat_clo;
V g_heff_2eelab_2efixed_2efloat32Ops_get(void);
V g_heff_2eelab_2efixed_2eintOps_get(void);
V g_heff_2eelab_2eprint_2ecommaSep(V);
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2ecommaSep_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2epr_get(void);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_heff_2esyntax_2eimport_2espaces(V);
V g_heff_2esyntax_2eimport_2espaces_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2espaces_clo;
V g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164(V);
V g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629(V);
V g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2eany_24s1107779796x153132813(V);
V g_list_2eany_24s1107779796x153132813_entry(V self, V *a);
extern Clo g_list_2eany_24s1107779796x153132813_clo;
V g_list_2eany_24s1230506745x754542351(V, V);
V g_list_2eany_24s1230506745x754542351_entry(V self, V *a);
extern Clo g_list_2eany_24s1230506745x754542351_clo;
V g_list_2eany_24s1477556979x2117333027(V);
V g_list_2eany_24s1477556979x2117333027_entry(V self, V *a);
extern Clo g_list_2eany_24s1477556979x2117333027_clo;
V g_list_2eany_24s1711939327x1502975912(V, V);
V g_list_2eany_24s1711939327x1502975912_entry(V self, V *a);
extern Clo g_list_2eany_24s1711939327x1502975912_clo;
V g_list_2eany_24s1875112453x1656618700(V, V);
V g_list_2eany_24s1875112453x1656618700_entry(V self, V *a);
extern Clo g_list_2eany_24s1875112453x1656618700_clo;
V g_list_2eany_24s193691892x499187556(V, V, V, V);
V g_list_2eany_24s193691892x499187556_entry(V self, V *a);
extern Clo g_list_2eany_24s193691892x499187556_clo;
V g_list_2eany_24s406396256x713021373(V, V);
V g_list_2eany_24s406396256x713021373_entry(V self, V *a);
extern Clo g_list_2eany_24s406396256x713021373_clo;
V g_list_2eany_24s908966052x1460382280(V, V);
V g_list_2eany_24s908966052x1460382280_entry(V self, V *a);
extern Clo g_list_2eany_24s908966052x1460382280_clo;
V g_list_2eany_24s930586707x1164893977(V, V);
V g_list_2eany_24s930586707x1164893977_entry(V self, V *a);
extern Clo g_list_2eany_24s930586707x1164893977_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24dps(V, V, V);
V g_list_2efilter_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24dps_clo;
V g_list_2efilter_24f419751885x381357165_24dps(V, V, V);
V g_list_2efilter_24f419751885x381357165_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24f419751885x381357165_24dps_clo;
V g_list_2efilter_24s1109331425x852844386(V, V, V);
V g_list_2efilter_24s1109331425x852844386_entry(V self, V *a);
extern Clo g_list_2efilter_24s1109331425x852844386_clo;
V g_list_2efilter_24s1109331425x852844386_24dps(V, V, V, V);
V g_list_2efilter_24s1109331425x852844386_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1109331425x852844386_24dps_clo;
V g_list_2efilter_24s1200694983x1257685262(V, V);
V g_list_2efilter_24s1200694983x1257685262_entry(V self, V *a);
extern Clo g_list_2efilter_24s1200694983x1257685262_clo;
V g_list_2efilter_24s1200694983x1257685262_24dps(V, V, V);
V g_list_2efilter_24s1200694983x1257685262_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1200694983x1257685262_24dps_clo;
V g_list_2efilter_24s1392550889x861369760_24dps(V, V, V);
V g_list_2efilter_24s1392550889x861369760_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1392550889x861369760_24dps_clo;
V g_list_2efilter_24s1716878720x675187502_24dps(V, V, V);
V g_list_2efilter_24s1716878720x675187502_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1716878720x675187502_24dps_clo;
V g_list_2efilter_24s1771067298x678756798(V, V);
V g_list_2efilter_24s1771067298x678756798_entry(V self, V *a);
extern Clo g_list_2efilter_24s1771067298x678756798_clo;
V g_list_2efilter_24s1771067298x678756798_24dps(V, V, V);
V g_list_2efilter_24s1771067298x678756798_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1771067298x678756798_24dps_clo;
V g_list_2efilter_24s1855973232x1329676164(V, V, V, V);
V g_list_2efilter_24s1855973232x1329676164_entry(V self, V *a);
extern Clo g_list_2efilter_24s1855973232x1329676164_clo;
V g_list_2efilter_24s1855973232x1329676164_24dps(V, V, V, V, V);
V g_list_2efilter_24s1855973232x1329676164_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1855973232x1329676164_24dps_clo;
V g_list_2efilter_24s2016771181x401513202(V, V, V);
V g_list_2efilter_24s2016771181x401513202_entry(V self, V *a);
extern Clo g_list_2efilter_24s2016771181x401513202_clo;
V g_list_2efilter_24s2016771181x401513202_24dps(V, V, V, V);
V g_list_2efilter_24s2016771181x401513202_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2016771181x401513202_24dps_clo;
V g_list_2efilter_24s2101000672x961294372(V, V, V, V);
V g_list_2efilter_24s2101000672x961294372_entry(V self, V *a);
extern Clo g_list_2efilter_24s2101000672x961294372_clo;
V g_list_2efilter_24s2101000672x961294372_24dps(V, V, V, V, V);
V g_list_2efilter_24s2101000672x961294372_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2101000672x961294372_24dps_clo;
V g_list_2efilter_24s243175984x2038711596_24dps(V, V, V);
V g_list_2efilter_24s243175984x2038711596_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s243175984x2038711596_24dps_clo;
V g_list_2efilter_24s313075719x1688564285_24dps(V, V);
V g_list_2efilter_24s313075719x1688564285_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s313075719x1688564285_24dps_clo;
V g_list_2efilter_24s316268077x2111002396_24dps(V, V, V);
V g_list_2efilter_24s316268077x2111002396_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s316268077x2111002396_24dps_clo;
V g_list_2efilter_24s334334379x923000927(V, V);
V g_list_2efilter_24s334334379x923000927_entry(V self, V *a);
extern Clo g_list_2efilter_24s334334379x923000927_clo;
V g_list_2efilter_24s334334379x923000927_24dps(V, V, V);
V g_list_2efilter_24s334334379x923000927_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s334334379x923000927_24dps_clo;
V g_list_2efilter_24s33860258x1274478326(V);
V g_list_2efilter_24s33860258x1274478326_entry(V self, V *a);
extern Clo g_list_2efilter_24s33860258x1274478326_clo;
V g_list_2efilter_24s33860258x1274478326_24dps(V, V);
V g_list_2efilter_24s33860258x1274478326_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s33860258x1274478326_24dps_clo;
V g_list_2efilter_24s504691860x650330878_24dps(V, V);
V g_list_2efilter_24s504691860x650330878_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s504691860x650330878_24dps_clo;
V g_list_2efilter_24s561186959x2071570661(V, V, V);
V g_list_2efilter_24s561186959x2071570661_entry(V self, V *a);
extern Clo g_list_2efilter_24s561186959x2071570661_clo;
V g_list_2efilter_24s561186959x2071570661_24dps(V, V, V, V);
V g_list_2efilter_24s561186959x2071570661_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s561186959x2071570661_24dps_clo;
V g_list_2efilter_24s951260806x709953240(V, V);
V g_list_2efilter_24s951260806x709953240_entry(V self, V *a);
extern Clo g_list_2efilter_24s951260806x709953240_clo;
V g_list_2efilter_24s951260806x709953240_24dps(V, V, V);
V g_list_2efilter_24s951260806x709953240_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s951260806x709953240_24dps_clo;
V g_list_2efind_24s1250280863x1570195177(V, V);
V g_list_2efind_24s1250280863x1570195177_entry(V self, V *a);
extern Clo g_list_2efind_24s1250280863x1570195177_clo;
V g_list_2efind_24s487054388x274730225(V, V);
V g_list_2efind_24s487054388x274730225_entry(V self, V *a);
extern Clo g_list_2efind_24s487054388x274730225_clo;
V g_list_2efoldl_24f155552269x628597815(V, V, V);
V g_list_2efoldl_24f155552269x628597815_entry(V self, V *a);
extern Clo g_list_2efoldl_24f155552269x628597815_clo;
V g_list_2efoldl_24f226312210x181720981(V, V, V, V);
V g_list_2efoldl_24f226312210x181720981_entry(V self, V *a);
extern Clo g_list_2efoldl_24f226312210x181720981_clo;
V g_list_2efoldl_24f613246640x472569916(V, V, V, V);
V g_list_2efoldl_24f613246640x472569916_entry(V self, V *a);
extern Clo g_list_2efoldl_24f613246640x472569916_clo;
V g_list_2efoldl_24f836170601x1639498774(V, V);
V g_list_2efoldl_24f836170601x1639498774_entry(V self, V *a);
extern Clo g_list_2efoldl_24f836170601x1639498774_clo;
V g_list_2efoldl_24s1028839125x1033007016(V, V);
V g_list_2efoldl_24s1028839125x1033007016_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1028839125x1033007016_clo;
V g_list_2efoldl_24s1176174831x1580549308(V, V);
V g_list_2efoldl_24s1176174831x1580549308_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1176174831x1580549308_clo;
V g_list_2efoldl_24s1200572259x609044042(V, V);
V g_list_2efoldl_24s1200572259x609044042_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1200572259x609044042_clo;
V g_list_2efoldl_24s1318914558x1386196507(V, V);
V g_list_2efoldl_24s1318914558x1386196507_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1318914558x1386196507_clo;
V g_list_2efoldl_24s1338419564x1372663611(V, V);
V g_list_2efoldl_24s1338419564x1372663611_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1338419564x1372663611_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1539079705x882348967(V, V);
V g_list_2efoldl_24s1539079705x882348967_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1539079705x882348967_clo;
V g_list_2efoldl_24s1606891938x229778616(V, V);
V g_list_2efoldl_24s1606891938x229778616_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1606891938x229778616_clo;
V g_list_2efoldl_24s1620243413x998711352(V, V);
V g_list_2efoldl_24s1620243413x998711352_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1620243413x998711352_clo;
V g_list_2efoldl_24s1694506840x958926808(V, V);
V g_list_2efoldl_24s1694506840x958926808_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1694506840x958926808_clo;
V g_list_2efoldl_24s1735038056x329845490(V, V);
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1735038056x329845490_clo;
V g_list_2efoldl_24s1769360958x1839054239(V, V);
V g_list_2efoldl_24s1769360958x1839054239_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1769360958x1839054239_clo;
V g_list_2efoldl_24s1842223007x322637159(V, V);
V g_list_2efoldl_24s1842223007x322637159_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1842223007x322637159_clo;
V g_list_2efoldl_24s199835065x1975386105(V, V);
V g_list_2efoldl_24s199835065x1975386105_entry(V self, V *a);
extern Clo g_list_2efoldl_24s199835065x1975386105_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s209635602x622053613(V, V);
V g_list_2efoldl_24s209635602x622053613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s209635602x622053613_clo;
V g_list_2efoldl_24s2118756600x1920057229(V, V);
V g_list_2efoldl_24s2118756600x1920057229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2118756600x1920057229_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s890299851x180637966(V, V);
V g_list_2efoldl_24s890299851x180637966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s890299851x180637966_clo;
V g_list_2efoldl_24s932544939x1448830416(V, V);
V g_list_2efoldl_24s932544939x1448830416_entry(V self, V *a);
extern Clo g_list_2efoldl_24s932544939x1448830416_clo;
V g_list_2efoldl_24s947555161x768980202(V, V);
V g_list_2efoldl_24s947555161x768980202_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947555161x768980202_clo;
V g_list_2efoldl_24s950896375x422349662(V, V);
V g_list_2efoldl_24s950896375x422349662_entry(V self, V *a);
extern Clo g_list_2efoldl_24s950896375x422349662_clo;
V g_list_2efoldl_24s963266017x1719814548(V, V);
V g_list_2efoldl_24s963266017x1719814548_entry(V self, V *a);
extern Clo g_list_2efoldl_24s963266017x1719814548_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24dps(V, V, V);
V g_list_2emap_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24dps_clo;
V g_list_2emap_24f1217399696x462307458(V, V, V);
V g_list_2emap_24f1217399696x462307458_entry(V self, V *a);
extern Clo g_list_2emap_24f1217399696x462307458_clo;
V g_list_2emap_24f1217399696x462307458_24dps(V, V, V, V);
V g_list_2emap_24f1217399696x462307458_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1217399696x462307458_24dps_clo;
V g_list_2emap_24f1260271301x348779032(V, V);
V g_list_2emap_24f1260271301x348779032_entry(V self, V *a);
extern Clo g_list_2emap_24f1260271301x348779032_clo;
V g_list_2emap_24f1260271301x348779032_24dps(V, V, V);
V g_list_2emap_24f1260271301x348779032_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1260271301x348779032_24dps_clo;
V g_list_2emap_24f1293205645x619162872_24dps(V, V, V, V, V);
V g_list_2emap_24f1293205645x619162872_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1293205645x619162872_24dps_clo;
V g_list_2emap_24f1352858702x862623587_24dps(V, V, V, V, V, V);
V g_list_2emap_24f1352858702x862623587_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1352858702x862623587_24dps_clo;
V g_list_2emap_24f1690623035x874154762(V, V, V, V, V, V);
V g_list_2emap_24f1690623035x874154762_entry(V self, V *a);
extern Clo g_list_2emap_24f1690623035x874154762_clo;
V g_list_2emap_24f1690623035x874154762_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24f1690623035x874154762_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1690623035x874154762_24dps_clo;
V g_list_2emap_24f904804876x285797696_24dps(V, V, V, V);
V g_list_2emap_24f904804876x285797696_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f904804876x285797696_24dps_clo;
V g_list_2emap_24s1009200955x251267316(V);
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_clo;
V g_list_2emap_24s1009200955x251267316_24dps(V, V);
V g_list_2emap_24s1009200955x251267316_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_24dps_clo;
V g_list_2emap_24s1049096277x601353451(V);
V g_list_2emap_24s1049096277x601353451_entry(V self, V *a);
extern Clo g_list_2emap_24s1049096277x601353451_clo;
V g_list_2emap_24s1049096277x601353451_24dps(V, V);
V g_list_2emap_24s1049096277x601353451_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1049096277x601353451_24dps_clo;
V g_list_2emap_24s1170504272x1852564147(V);
V g_list_2emap_24s1170504272x1852564147_entry(V self, V *a);
extern Clo g_list_2emap_24s1170504272x1852564147_clo;
V g_list_2emap_24s1170504272x1852564147_24dps(V, V);
V g_list_2emap_24s1170504272x1852564147_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1170504272x1852564147_24dps_clo;
V g_list_2emap_24s1243189782x897571843_24dps(V, V, V);
V g_list_2emap_24s1243189782x897571843_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_24dps_clo;
V g_list_2emap_24s1341404685x1564972929(V);
V g_list_2emap_24s1341404685x1564972929_entry(V self, V *a);
extern Clo g_list_2emap_24s1341404685x1564972929_clo;
V g_list_2emap_24s1341404685x1564972929_24dps(V, V);
V g_list_2emap_24s1341404685x1564972929_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1341404685x1564972929_24dps_clo;
V g_list_2emap_24s1366476796x894764441(V, V);
V g_list_2emap_24s1366476796x894764441_entry(V self, V *a);
extern Clo g_list_2emap_24s1366476796x894764441_clo;
V g_list_2emap_24s1366476796x894764441_24dps(V, V, V);
V g_list_2emap_24s1366476796x894764441_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1366476796x894764441_24dps_clo;
V g_list_2emap_24s137457135x961689574(V);
V g_list_2emap_24s137457135x961689574_entry(V self, V *a);
extern Clo g_list_2emap_24s137457135x961689574_clo;
V g_list_2emap_24s137457135x961689574_24dps(V, V);
V g_list_2emap_24s137457135x961689574_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s137457135x961689574_24dps_clo;
V g_list_2emap_24s1412546768x2004463577_24dps(V, V, V, V, V);
V g_list_2emap_24s1412546768x2004463577_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1412546768x2004463577_24dps_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1415906091x1371825187_24dps(V, V);
V g_list_2emap_24s1415906091x1371825187_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_24dps_clo;
V g_list_2emap_24s1534167768x1221742344(V);
V g_list_2emap_24s1534167768x1221742344_entry(V self, V *a);
extern Clo g_list_2emap_24s1534167768x1221742344_clo;
V g_list_2emap_24s1534167768x1221742344_24dps(V, V);
V g_list_2emap_24s1534167768x1221742344_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1534167768x1221742344_24dps_clo;
V g_list_2emap_24s1535007417x1587061701_24dps(V, V);
V g_list_2emap_24s1535007417x1587061701_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1535007417x1587061701_24dps_clo;
V g_list_2emap_24s158244903x55062455_24dps(V, V);
V g_list_2emap_24s158244903x55062455_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_24dps_clo;
V g_list_2emap_24s1661513421x830177447_24dps(V, V, V, V);
V g_list_2emap_24s1661513421x830177447_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1661513421x830177447_24dps_clo;
V g_list_2emap_24s1675313341x192238134(V);
V g_list_2emap_24s1675313341x192238134_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_clo;
V g_list_2emap_24s1675313341x192238134_24dps(V, V);
V g_list_2emap_24s1675313341x192238134_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_24dps_clo;
V g_list_2emap_24s1688457226x2006118782(V);
V g_list_2emap_24s1688457226x2006118782_entry(V self, V *a);
extern Clo g_list_2emap_24s1688457226x2006118782_clo;
V g_list_2emap_24s1688457226x2006118782_24dps(V, V);
V g_list_2emap_24s1688457226x2006118782_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1688457226x2006118782_24dps_clo;
V g_list_2emap_24s170418522x132668694(V);
V g_list_2emap_24s170418522x132668694_entry(V self, V *a);
extern Clo g_list_2emap_24s170418522x132668694_clo;
V g_list_2emap_24s170418522x132668694_24dps(V, V);
V g_list_2emap_24s170418522x132668694_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s170418522x132668694_24dps_clo;
V g_list_2emap_24s1791433880x1360378684_24dps(V, V);
V g_list_2emap_24s1791433880x1360378684_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1791433880x1360378684_24dps_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24dps(V, V);
V g_list_2emap_24s1796125103x644876049_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24dps_clo;
V g_list_2emap_24s1816200867x1876638332(V);
V g_list_2emap_24s1816200867x1876638332_entry(V self, V *a);
extern Clo g_list_2emap_24s1816200867x1876638332_clo;
V g_list_2emap_24s1816200867x1876638332_24dps(V, V);
V g_list_2emap_24s1816200867x1876638332_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1816200867x1876638332_24dps_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1817208647x1282894070_24dps(V, V);
V g_list_2emap_24s1817208647x1282894070_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_24dps_clo;
V g_list_2emap_24s1817753698x509594538_24dps(V, V, V, V);
V g_list_2emap_24s1817753698x509594538_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1817753698x509594538_24dps_clo;
V g_list_2emap_24s1846289357x1055790465_24dps(V, V, V);
V g_list_2emap_24s1846289357x1055790465_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1846289357x1055790465_24dps_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24dps(V, V);
V g_list_2emap_24s1937570095x2110149801_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24dps_clo;
V g_list_2emap_24s1947501783x1475115781_24dps(V, V, V, V);
V g_list_2emap_24s1947501783x1475115781_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_24dps_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_list_2emap_24s1990719097x1419059608_24dps(V, V);
V g_list_2emap_24s1990719097x1419059608_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_24dps_clo;
V g_list_2emap_24s1992667171x110340492_24dps(V, V);
V g_list_2emap_24s1992667171x110340492_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_24dps_clo;
V g_list_2emap_24s2029274225x672412636(V, V, V, V);
V g_list_2emap_24s2029274225x672412636_entry(V self, V *a);
extern Clo g_list_2emap_24s2029274225x672412636_clo;
V g_list_2emap_24s2029274225x672412636_24dps(V, V, V, V, V);
V g_list_2emap_24s2029274225x672412636_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029274225x672412636_24dps_clo;
V g_list_2emap_24s214260857x938990544(V);
V g_list_2emap_24s214260857x938990544_entry(V self, V *a);
extern Clo g_list_2emap_24s214260857x938990544_clo;
V g_list_2emap_24s214260857x938990544_24dps(V, V);
V g_list_2emap_24s214260857x938990544_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s214260857x938990544_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s244350250x1728178626_24dps(V, V);
V g_list_2emap_24s244350250x1728178626_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_24dps_clo;
V g_list_2emap_24s249042484x1701682908(V);
V g_list_2emap_24s249042484x1701682908_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_clo;
V g_list_2emap_24s249042484x1701682908_24dps(V, V);
V g_list_2emap_24s249042484x1701682908_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_24dps_clo;
V g_list_2emap_24s296585291x885335139_24dps(V, V);
V g_list_2emap_24s296585291x885335139_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s296585291x885335139_24dps_clo;
V g_list_2emap_24s32026788x2029987799(V);
V g_list_2emap_24s32026788x2029987799_entry(V self, V *a);
extern Clo g_list_2emap_24s32026788x2029987799_clo;
V g_list_2emap_24s32026788x2029987799_24dps(V, V);
V g_list_2emap_24s32026788x2029987799_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s32026788x2029987799_24dps_clo;
V g_list_2emap_24s366989016x166432442(V);
V g_list_2emap_24s366989016x166432442_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_clo;
V g_list_2emap_24s366989016x166432442_24dps(V, V);
V g_list_2emap_24s366989016x166432442_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_24dps_clo;
V g_list_2emap_24s474585387x1072098790(V);
V g_list_2emap_24s474585387x1072098790_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_clo;
V g_list_2emap_24s474585387x1072098790_24dps(V, V);
V g_list_2emap_24s474585387x1072098790_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_24dps_clo;
V g_list_2emap_24s499193121x1224230698_24dps(V, V);
V g_list_2emap_24s499193121x1224230698_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s499193121x1224230698_24dps_clo;
V g_list_2emap_24s539093115x379698116(V);
V g_list_2emap_24s539093115x379698116_entry(V self, V *a);
extern Clo g_list_2emap_24s539093115x379698116_clo;
V g_list_2emap_24s539093115x379698116_24dps(V, V);
V g_list_2emap_24s539093115x379698116_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s539093115x379698116_24dps_clo;
V g_list_2emap_24s564507054x318389057_24dps(V, V, V);
V g_list_2emap_24s564507054x318389057_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s564507054x318389057_24dps_clo;
V g_list_2emap_24s570961906x1112476114(V);
V g_list_2emap_24s570961906x1112476114_entry(V self, V *a);
extern Clo g_list_2emap_24s570961906x1112476114_clo;
V g_list_2emap_24s570961906x1112476114_24dps(V, V);
V g_list_2emap_24s570961906x1112476114_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s570961906x1112476114_24dps_clo;
V g_list_2emap_24s582709368x2113456071(V);
V g_list_2emap_24s582709368x2113456071_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_clo;
V g_list_2emap_24s582709368x2113456071_24dps(V, V);
V g_list_2emap_24s582709368x2113456071_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_24dps_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s759871588x920431471_24dps(V, V);
V g_list_2emap_24s759871588x920431471_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_24dps_clo;
V g_list_2emap_24s777254429x1856211654_24dps(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s777254429x1856211654_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s777254429x1856211654_24dps_clo;
V g_list_2emerge_24dps(V, V, V, V);
V g_list_2emerge_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24dps_clo;
V g_list_2emerge_24s1037857700x2096250953_24dps(V, V, V);
V g_list_2emerge_24s1037857700x2096250953_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1037857700x2096250953_24dps_clo;
V g_list_2ezipWith_24s151204990x680105425(V, V);
V g_list_2ezipWith_24s151204990x680105425_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s151204990x680105425_clo;
V g_list_2ezipWith_24s151204990x680105425_24dps(V, V, V);
V g_list_2ezipWith_24s151204990x680105425_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s151204990x680105425_24dps_clo;
V g_list_2ezipWith_24s634456687x1151454243(V, V);
V g_list_2ezipWith_24s634456687x1151454243_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_clo;
V g_list_2ezipWith_24s634456687x1151454243_24dps(V, V, V);
V g_list_2ezipWith_24s634456687x1151454243_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_24dps_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1206589350x791019229(V, V, V);
V g_prelude_2e_2b_2b_24f1206589350x791019229_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1206589350x791019229_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
Clo g_list_2emap_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24dps_entry, 3, 0};

V g_list_2emap_24dps(V v_f_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_f_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1370882877x364361272_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1370882877x364361272_entry, 2, 0};

V g_list_2efoldl_24s1370882877x364361272(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V t_0 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1370882877x364361272(a[0], a[1]);
}
Clo g_list_2efilter_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_entry, 2, 0};

V g_list_2efilter(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24dps(v_p_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter(a[0], a[1]);
}
Clo g_list_2efilter_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24dps_entry, 3, 0};

V g_list_2efilter_24dps(V v_p_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s65689923x209800052_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s65689923x209800052_entry, 3, 0};

V g_list_2efoldl_24s65689923x209800052(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x3_242, 1);
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s65689923x209800052(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2eall_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_entry, 2, 0};

V g_list_2eall(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emerge_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24dps_entry, 4, 0};

V g_list_2emerge_24dps(V v_le_240, V v_xs_241, V v_ys_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_242);
  }
  case TAG_Cons: {
    V v_x_244 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_245 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_le_240);
      heff_drop(v_x_244);
      heff_drop(v_xs2_245);
      return heff_setField(v_d_243, MK_INT(1LL), v_xs_241);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_ys_242, 0);
      V v_ys2_247 = heff_field(v_ys_242, 1);
      V v_ru_24ys_242_24Cons = heff_take_reuse_n(v_ys_242, 3ULL, 2);
      heff_drop_tag(v_xs_241, 2);
      V v_t_248 = heff_tr(heff_call(heff_dup(v_le_240), 2, (V[]){heff_dup(v_x_244), heff_dup(v_y_246)}));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_cell_249 = heff_tag_at_n(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = v_le_240;
        V t_1 = v_xs2_245;
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_246, v_ys2_247});
        V t_3 = v_cell_249;
        v_le_240 = t_0;
        v_xs_241 = t_1;
        v_ys_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_248);
        V v_cell_2411 = heff_tag_at_n(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_y_246, heff_hole()});
        V v_u_2412 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2411));
        heff_drop(v_u_2412);
        V t_0 = v_le_240;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_xs2_245});
        V t_2 = v_ys2_247;
        V t_3 = v_cell_2411;
        v_le_240 = t_0;
        v_xs_241 = t_1;
        v_ys_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2emerge_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1415906091x1371825187_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1415906091x1371825187_entry, 1, 0};

V g_list_2emap_24s1415906091x1371825187(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1415906091x1371825187_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1415906091x1371825187(a[0]);
}
Clo g_list_2emap_24s1937570095x2110149801_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1937570095x2110149801_entry, 1, 0};

V g_list_2emap_24s1937570095x2110149801(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_x_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1937570095x2110149801_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1937570095x2110149801(a[0]);
}
Clo g_list_2efoldl_24s199835065x1975386105_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s199835065x1975386105_entry, 2, 0};

V g_list_2efoldl_24s199835065x1975386105(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244;
    switch (heff_tag_of(v_x_242)) {
    case TAG_I8: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I16: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I32: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I64: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U8: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U16: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U32: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U64: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_F32: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2efloat32Ops_get());
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_245 = (g_prelude_2e_2b_2b_24f1206589350x791019229(v_z_240, heff_dup(v_x_242), v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s199835065x1975386105_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s199835065x1975386105(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s32026788x2029987799_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s32026788x2029987799_entry, 1, 0};

V g_list_2emap_24s32026788x2029987799(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_take_field(v_x_241, 0), heff_take_field(v_x_241, 1), NTAG(TAG_Nothing), heff_get_n(v_x_241, 2, 3), MK_INT(0LL), MK_INT(0LL)});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s32026788x2029987799_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s32026788x2029987799_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s32026788x2029987799(a[0]);
}
Clo g_list_2emap_24s1243189782x897571843_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1243189782x897571843_24dps_entry, 3, 0};

V g_list_2emap_24s1243189782x897571843_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_x_243}), heff_dup(v_lit_240)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1243189782x897571843_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1243189782x897571843_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1688457226x2006118782_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1688457226x2006118782_entry, 1, 0};

V g_list_2emap_24s1688457226x2006118782(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1688457226x2006118782_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1688457226x2006118782_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1688457226x2006118782(a[0]);
}
Clo g_list_2emap_24s137457135x961689574_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s137457135x961689574_entry, 1, 0};

V g_list_2emap_24s137457135x961689574(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eupdateSetOf_24s1336657754x1446899796(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s137457135x961689574_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s137457135x961689574_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s137457135x961689574(a[0]);
}
Clo g_list_2emap_24s539093115x379698116_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s539093115x379698116_entry, 1, 0};

V g_list_2emap_24s539093115x379698116(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s539093115x379698116_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s539093115x379698116_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s539093115x379698116(a[0]);
}
Clo g_list_2emap_24s1992667171x110340492_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1992667171x110340492_24dps_entry, 2, 0};

V g_list_2emap_24s1992667171x110340492_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(v_a_244));
      v_t_247 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_246, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1992667171x110340492_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1992667171x110340492_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s158244903x55062455_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s158244903x55062455_24dps_entry, 2, 0};

V g_list_2emap_24s158244903x55062455_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_245, v_a_244));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s158244903x55062455_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s158244903x55062455_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s366989016x166432442_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s366989016x166432442_entry, 1, 0};

V g_list_2emap_24s366989016x166432442(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_a_243)) {
      case TAG_SetPath: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_ru_24a_243_24SetPath = heff_take_reuse_n(v_a_243, 3ULL, 2);
        V v_t_2410;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_field(v_a_246, 0);
          V v_a_248 = heff_field(v_a_246, 1);
          heff_take_n(v_a_246, 3ULL, 2);
          V v_t_249 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_247));
          v_t_2410 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_249, v_a_248});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2411 = heff_tag_at_n(v_ru_24a_243_24SetPath, TAG_SetPath, 2, (V[]){v_a_245, v_t_2410});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = (g_list_2emap_24s366989016x166432442_24dps(v_xs_242, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s366989016x166432442_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s366989016x166432442(a[0]);
}
Clo g_list_2emap_24s244350250x1728178626_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s244350250x1728178626_24dps_entry, 2, 0};

V g_list_2emap_24s244350250x1728178626_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24MkAlt = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_t_2411;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          V v_t_2410 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_248));
          v_t_2411 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2410, v_a_249});
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2412 = heff_tag_at_n(v_ru_24a_244_24MkAlt, TAG_MkAlt, 2, (V[]){v_a_246, v_t_2411});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s244350250x1728178626_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s244350250x1728178626_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s474585387x1072098790_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s474585387x1072098790_entry, 1, 0};

V g_list_2emap_24s474585387x1072098790(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_243)) {
      case TAG_ExplicitParam: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24ExplicitParam = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_249, v_a_248));
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_a_245, v_a_246, v_t_2410});
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_a_2412 = heff_field(v_a_243, 1);
        V v_a_2413 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24ImplicitParam = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2416;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_2415, v_a_2414));
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24a_243_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_a_2411, v_a_2412, v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2418 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2417, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = (g_list_2emap_24s474585387x1072098790_24dps(v_xs_242, heff_dup(v_cell_2419)));
    heff_drop(v_u_2420);
    return v_cell_2419;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s474585387x1072098790_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s474585387x1072098790(a[0]);
}
Clo g_list_2emap_24s249042484x1701682908_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s249042484x1701682908_entry, 1, 0};

V g_list_2emap_24s249042484x1701682908(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2415;
      switch (heff_tag_of(v_a_243)) {
      case TAG_SetField: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24SetField = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          v_t_2410 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_249, v_a_248));
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24a_243_24SetField, TAG_SetField, 3, (V[]){v_a_245, v_a_246, v_t_2410});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadFieldSet = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_a_2411)) {
        case TAG_At: {
          V v_a_2412 = heff_field(v_a_2411, 0);
          V v_a_2413 = heff_field(v_a_2411, 1);
          heff_take_n(v_a_2411, 3ULL, 2);
          v_t_2414 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_2413, v_a_2412));
          break;
        }
        default: heff_nomatch(v_a_2411);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24a_243_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2414});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2416 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2415, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = (g_list_2emap_24s249042484x1701682908_24dps(v_xs_242, heff_dup(v_cell_2417)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s249042484x1701682908_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s249042484x1701682908(a[0]);
}
Clo g_list_2efoldl_24s890299851x180637966_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s890299851x180637966_entry, 2, 0};

V g_list_2efoldl_24s890299851x180637966(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2eflat(heff_dup(heff_rfield(v_x_242, 2))));
    V v_t_245 = ({ V a_0 = v_z_240; V a_1 = heff_dup(heff_rfield(v_x_242, 0)); V a_2 = v_t_244; V r_ = (g_heff_2ecompile_2esimplify_2esgFlat(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s890299851x180637966_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s890299851x180637966(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1049096277x601353451_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1049096277x601353451_entry, 1, 0};

V g_list_2emap_24s1049096277x601353451(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2437;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_241, 0ULL, 4);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2438 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2437, heff_hole()});
    V v_u_2439 = (g_list_2emap_24s1049096277x601353451_24dps(v_xs_242, heff_dup(v_cell_2438)));
    heff_drop(v_u_2439);
    return v_cell_2438;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1049096277x601353451_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1049096277x601353451(a[0]);
}
Clo g_list_2eany_24s1107779796x153132813_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1107779796x153132813_entry, 1, 0};

V g_list_2eany_24s1107779796x153132813(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2440;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_x13_245 = heff_field(v_x_241, 2);
      switch (heff_tag_of(v_x13_245)) {
      case TAG_EVar: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2440 = NTAG(TAG_True);
        break;
      }
      case TAG_EMatch: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x13_245);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop(v_t_2440);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2440);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1107779796x153132813_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1107779796x153132813(a0); heff_drop(a0); return r;
}
Clo g_list_2eany_24s930586707x1164893977_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s930586707x1164893977_entry, 2, 0};

V g_list_2eany_24s930586707x1164893977(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_lit_240), heff_dup(v_x_242))) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s930586707x1164893977_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s930586707x1164893977(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1318914558x1386196507_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1318914558x1386196507_entry, 2, 0};

V g_list_2efoldl_24s1318914558x1386196507(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_a_246)));
      v_t_248 = ({ V a_0 = v_z_240; V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_247); r_; });
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1318914558x1386196507_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1318914558x1386196507(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1735038056x329845490_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1735038056x329845490_entry, 2, 0};

V g_list_2efoldl_24s1735038056x329845490(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eimperative_2evalNamesTop(v_x_242, v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1735038056x329845490(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1477556979x2117333027_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1477556979x2117333027_entry, 1, 0};

V g_list_2eany_24s1477556979x2117333027(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_RepV: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_RepFix: {
      return NTAG(TAG_True);
    }
    case TAG_RepF64: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1477556979x2117333027_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1477556979x2117333027(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1694506840x958926808_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1694506840x958926808_entry, 2, 0};

V g_list_2efoldl_24s1694506840x958926808(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2417;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Merge: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Boxed: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Unboxed: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Literal: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Wants: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Binds: {
      V v_x_2413 = heff_field(v_x_242, 0);
      v_t_2417 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_2413), NTAG(TAG_MkUnit), v_z_240));
      break;
    }
    case TAG_Pinned: {
      v_t_2417 = v_z_240;
      break;
    }
    case TAG_Kept: {
      v_t_2417 = v_z_240;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2417;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1694506840x958926808_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1694506840x958926808(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1176174831x1580549308_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1176174831x1580549308_entry, 2, 0};

V g_list_2efoldl_24s1176174831x1580549308(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_249;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_x_242, 0);
        v_t_249 = heff_dup(v_a_247);
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      v_t_2410 = (g_map_2einsert_24s1341440536x470972936(v_t_249, NTAG(TAG_MkUnit), v_z_240));
    } else {
      heff_drop(v_t_246);
      v_t_2410 = v_z_240;
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1176174831x1580549308_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1176174831x1580549308(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s33860258x1274478326_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s33860258x1274478326_entry, 1, 0};

V g_list_2efilter_24s33860258x1274478326(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_RepV: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_RepFix: {
      heff_take_n(v_t_245, 0ULL, 1);
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_248 = (g_list_2efilter_24s33860258x1274478326_24dps(v_xs_242, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    case TAG_RepF64: {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2410 = (g_list_2efilter_24s33860258x1274478326_24dps(v_xs_242, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s33860258x1274478326_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s33860258x1274478326(a[0]);
}
Clo g_list_2efoldl_24s1769360958x1839054239_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1769360958x1839054239_entry, 2, 0};

V g_list_2efoldl_24s1769360958x1839054239(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eborrow_2eborAll(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1769360958x1839054239_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1769360958x1839054239(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1947501783x1475115781_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1947501783x1475115781_24dps_entry, 4, 0};

V g_list_2emap_24s1947501783x1475115781_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_intSub(heff_intSub(heff_dup(v_lit_240), v_x_244), heff_dup(v_lit_241));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1947501783x1475115781_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1947501783x1475115781_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s777254429x1856211654_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s777254429x1856211654_24dps_entry, 12, 0};

V g_list_2emap_24s777254429x1856211654_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_x2_2410, V v_d_2411) {
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return heff_setField(v_d_2411, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2410, 0);
    V v_xs_2413 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24Cons = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2423;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_2412, 0);
      V v_a_2415 = heff_field(v_x_2412, 1);
      heff_take_n(v_x_2412, 3ULL, 2);
      V v_t_2416 = (g_heff_2eelab_2eprint_2eescFrom(v_a_2414, heff_dup(v_lit_242)));
      V v_t_2417 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2416, heff_dup(v_lit_243)));
      V v_a_2418 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 1)), heff_arrayToList(v_a_2415)));
      V v_t_2419 = ({ V a_0 = v_a_2418; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_a_2418); r_; });
      V v_t_2420 = heff_strAppend(heff_dup(v_lit_246), heff_strAppend(v_t_2419, heff_dup(v_lit_247)));
      V v_t_2421 = heff_strAppend(heff_dup(v_lit_245), heff_strAppend(v_t_2420, heff_dup(v_lit_248)));
      V v_t_2422 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2421, heff_dup(v_lit_249)));
      v_t_2423 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2417, v_t_2422));
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_2410_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = heff_setField(v_d_2411, MK_INT(1LL), heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_lit_249;
    V t_10 = v_xs_2413;
    V t_11 = v_cell_2424;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_lit_249 = t_9;
    v_x2_2410 = t_10;
    v_d_2411 = t_11;
    goto top;
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_list_2emap_24s777254429x1856211654_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s777254429x1856211654_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
}
Clo g_list_2efoldl_24s1606891938x229778616_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1606891938x229778616_entry, 2, 0};

V g_list_2efoldl_24s1606891938x229778616(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1606891938x229778616_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1606891938x229778616(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1990719097x1419059608_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1990719097x1419059608_entry, 1, 0};

V g_list_2emap_24s1990719097x1419059608(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tr(heff_call(v_x_241, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1990719097x1419059608_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1990719097x1419059608(a[0]);
}
Clo g_list_2efilter_24s504691860x650330878_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s504691860x650330878_24dps_entry, 2, 0};

V g_list_2efilter_24s504691860x650330878_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2410;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_249);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s504691860x650330878_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s504691860x650330878_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1200572259x609044042_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1200572259x609044042_entry, 2, 0};

V g_list_2efoldl_24s1200572259x609044042(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = (g_heff_2ecompile_2efuse_2econsumerOf(heff_dup(heff_rfield(v_x_242, 0)), heff_rfield(v_x_242, 2)));
    V v_t_246;
    switch (heff_tag_of(v_a_244)) {
    case TAG_Nothing: {
      v_t_246 = v_z_240;
      break;
    }
    case TAG_Just: {
      V v_a_245 = heff_field(v_a_244, 0);
      heff_take_n(v_a_244, 1ULL, 1);
      v_t_246 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_x_242, 0)), v_a_245, v_z_240));
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1200572259x609044042_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1200572259x609044042(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1796125103x644876049_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1796125103x644876049_entry, 1, 0};

V g_list_2emap_24s1796125103x644876049(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDrop, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1796125103x644876049_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1796125103x644876049(a[0]);
}
Clo g_list_2emap_24s1341404685x1564972929_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1341404685x1564972929_entry, 1, 0};

V g_list_2emap_24s1341404685x1564972929(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 7ULL, 3);
      v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_a_244}), heff_tag_n(TAG_ATail, 1, (V[]){v_a_245})});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1341404685x1564972929_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1341404685x1564972929_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1341404685x1564972929(a[0]);
}
Clo g_list_2emap_24s1341404685x1564972929_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1341404685x1564972929_24dps_entry, 2, 0};

V g_list_2emap_24s1341404685x1564972929_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_244, v_a_245}), heff_tag_n(TAG_ATail, 1, (V[]){v_a_246})});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1341404685x1564972929_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1341404685x1564972929_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s151204990x680105425_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s151204990x680105425_entry, 2, 0};

V g_list_2ezipWith_24s151204990x680105425(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_y_244; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_y_244); r_; });
      V v_t_247;
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        v_t_247 = v_x_242;
      } else {
        heff_drop(v_x_242);
        heff_drop(v_t_246);
        v_t_247 = NTAG(TAG_RepV);
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s151204990x680105425_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s151204990x680105425_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s151204990x680105425(a[0], a[1]);
}
Clo g_list_2efoldl_24s932544939x1448830416_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s932544939x1448830416_entry, 2, 0};

V g_list_2efoldl_24s932544939x1448830416(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2ezipWith_24s151204990x680105425(heff_take_field(v_z_240, 0), heff_dup(heff_rfield(v_x_242, 0))));
    V v_a_245 = heff_get_n(v_z_240, 1, 2);
    V v_t_246 = (g_heff_2ecompile_2erepr_2ereprEq(v_a_245, heff_rfield(v_x_242, 1)));
    V v_t_247;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      v_t_247 = v_a_245;
    } else {
      heff_drop(v_a_245);
      heff_drop(v_t_246);
      v_t_247 = NTAG(TAG_RepV);
    }
    V t_0 = heff_rec_n(2, shape_params__result, (V[]){v_t_244, v_t_247});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s932544939x1448830416_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s932544939x1448830416(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1539079705x882348967_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1539079705x882348967_entry, 2, 0};

V g_list_2efoldl_24s1539079705x882348967(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1539079705x882348967_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1539079705x882348967(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2118756600x1920057229_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2118756600x1920057229_entry, 2, 0};

V g_list_2efoldl_24s2118756600x1920057229(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_242), NTAG(TAG_MkUnit), heff_take_field(v_z_240, 2)));
    V v_t_245 = ({ V rv_2 = v_t_244; V rr_ = heff_rec_reuse_nf(v_z_240, 27ULL, 5, shape_gs__names__used__self__inl, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2118756600x1920057229_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2118756600x1920057229(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1366476796x894764441_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1366476796x894764441_entry, 2, 0};

V g_list_2emap_24s1366476796x894764441(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_242, heff_dup(v_lit_240)), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1366476796x894764441_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1366476796x894764441_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1366476796x894764441(a[0], a[1]);
}
Clo g_list_2efoldl_24s963266017x1719814548_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s963266017x1719814548_entry, 2, 0};

V g_list_2efoldl_24s963266017x1719814548(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(heff_get_n(v_t_246, 3, 5), v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s963266017x1719814548_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s963266017x1719814548(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s2101000672x961294372_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2101000672x961294372_entry, 4, 0};

V g_list_2efilter_24s2101000672x961294372(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242))) {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = (g_list_2efilter_24s2101000672x961294372_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s2101000672x961294372_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2101000672x961294372(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1009200955x251267316_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1009200955x251267316_entry, 1, 0};

V g_list_2emap_24s1009200955x251267316(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_t_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 3);
      v_t_246 = v_t_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1009200955x251267316_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1009200955x251267316(a[0]);
}
Clo g_list_2efoldl_24s1028839125x1033007016_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1028839125x1033007016_entry, 2, 0};

V g_list_2efoldl_24s1028839125x1033007016(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 1)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1028839125x1033007016_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1028839125x1033007016(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1842223007x322637159_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1842223007x322637159_entry, 2, 0};

V g_list_2efoldl_24s1842223007x322637159(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s950896375x422349662(v_z_240, heff_dup(heff_rfield(v_x_242, 0))));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1842223007x322637159_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1842223007x322637159(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s947555161x768980202_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s947555161x768980202_entry, 2, 0};

V g_list_2efoldl_24s947555161x768980202(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    V v_t_247 = (g_heff_2esyntax_2eimport_2espaces(heff_intSub(v_t_245, v_t_246)));
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2);
    V v_t_249 = heff_strSlice(heff_dup(v_z_240), v_t_248, heff_strLength(heff_dup(v_z_240)));
    V v_t_2410 = heff_strAppend(heff_strSlice(v_z_240, MK_INT(0LL), v_t_244), heff_strAppend(v_t_247, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s947555161x768980202_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s947555161x768980202(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1817208647x1282894070_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1817208647x1282894070_24dps_entry, 2, 0};

V g_list_2emap_24s1817208647x1282894070_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1817208647x1282894070_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1817208647x1282894070_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1846289357x1055790465_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1846289357x1055790465_24dps_entry, 3, 0};

V g_list_2emap_24s1846289357x1055790465_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1846289357x1055790465_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1846289357x1055790465_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s243175984x2038711596_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s243175984x2038711596_24dps_entry, 3, 0};

V g_list_2efilter_24s243175984x2038711596_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_x_243), heff_dup(v_lit_240))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s243175984x2038711596_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s243175984x2038711596_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1338419564x1372663611_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1338419564x1372663611_entry, 2, 0};

V g_list_2efoldl_24s1338419564x1372663611(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_242), NTAG(TAG_MkUnit), heff_take_field(v_z_240, 3)));
    V v_t_245 = ({ V rv_3 = v_t_244; V rr_ = heff_rec_reuse_nf(v_z_240, 119ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1338419564x1372663611_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1338419564x1372663611(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s334334379x923000927_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s334334379x923000927_entry, 2, 0};

V g_list_2efilter_24s334334379x923000927(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s334334379x923000927_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s334334379x923000927_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s334334379x923000927(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1534167768x1221742344_str0, 56, "only the library that goes with heff declares primitives");
Clo g_list_2emap_24s1534167768x1221742344_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1534167768x1221742344_entry, 1, 0};

V g_list_2emap_24s1534167768x1221742344(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_sp_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(335LL), NTAG(TAG_SError), ((V)&g_list_2emap_24s1534167768x1221742344_str0), v_sp_244, NTAG(TAG_Nothing)});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1534167768x1221742344_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1534167768x1221742344_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1534167768x1221742344(a[0]);
}
Clo g_list_2emap_24s1535007417x1587061701_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1535007417x1587061701_24dps_entry, 2, 0};

V g_list_2emap_24s1535007417x1587061701_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2426;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      V v_sp_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_244, 0ULL, 5);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_244, 0ULL, 5);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_244, 0ULL, 4);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2420 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 3);
        v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x_242_24At, TAG_MkPair, 2, (V[]){v_x_2420, v_sp_245})});
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_244, 0ULL, 2);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_244, 0ULL, 1);
        heff_drop(v_sp_245);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2427 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
    V v_u_2428 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2427));
    heff_drop(v_u_2428);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2427;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1535007417x1587061701_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1535007417x1587061701_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s214260857x938990544_str0, 0, "");
V g_list_2emap_24s214260857x938990544_lam0(V self, V *args); static Clo g_list_2emap_24s214260857x938990544_lam0_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_lam0, 1, 0};
Clo g_list_2emap_24s214260857x938990544_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_entry, 1, 0};

V g_list_2emap_24s214260857x938990544(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V rv_4 = ((V)&g_list_2emap_24s214260857x938990544_lam0_clo); V rr_ = heff_rec_reuse_nf(v_x_241, 15ULL, 5, shape_span__name__key__member__ty, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s214260857x938990544_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s214260857x938990544_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s214260857x938990544(a[0]);
}
V g_list_2emap_24s214260857x938990544_lam0(V self, V *args) {
  V v_u_243 = args[0];
  heff_drop(v_u_243);
  return ((V)&g_list_2emap_24s214260857x938990544_str0);
}
Clo g_list_2efoldl_24s209635602x622053613_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s209635602x622053613_entry, 2, 0};

V g_list_2efoldl_24s209635602x622053613(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_x_242, 5)), heff_dup(heff_rfield(v_x_242, 3))));
    V v_a_245 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_x_242, 4), v_t_244));
    V v_t_246 = (g_list_2emap_24s1817208647x1282894070(heff_dup(heff_rfield(v_a_245, 0))));
    V v_a_247 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_246));
    V v_t_248 = (g_heff_2ebuild_2edriver_2eclosureGo(v_z_240, NTAG(TAG_Nil), v_a_247));
    V v_t_249 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_a_245; V b_3 = NTAG(TAG_Nothing); V a_4 = v_t_248; V r_ = (g_heff_2ebuild_2edriver_2eelabNeeding(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); heff_drop(v_t_248); r_; });
    V v_t_2410 = (g_heff_2ebuild_2edriver_2elean(v_t_249));
    V v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    V v_t_2412 = (g_heff_2ebuild_2edriver_2eappendD(v_z_240, v_t_2411));
    V t_0 = v_t_2412;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s209635602x622053613_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s209635602x622053613(a[0], a[1]);
}
Clo g_list_2emap_24s570961906x1112476114_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s570961906x1112476114_entry, 1, 0};

V g_list_2emap_24s570961906x1112476114(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2edriver_2elabelOfV(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s570961906x1112476114_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s570961906x1112476114_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s570961906x1112476114(a[0]);
}
Clo g_list_2emap_24s564507054x318389057_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s564507054x318389057_24dps_entry, 3, 0};

V g_list_2emap_24s564507054x318389057_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_take_field(v_x_243, 1));
    V v_t_246 = heff_strAppend(heff_get_n(v_x_243, 0, 2), v_t_245);
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_247;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s564507054x318389057_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s564507054x318389057_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efind_24s487054388x274730225_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s487054388x274730225_entry, 2, 0};

V g_list_2efind_24s487054388x274730225(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s487054388x274730225_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s487054388x274730225(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1092144743x1559898298_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1092144743x1559898298_entry, 1, 0};

V g_list_2eany_24s1092144743x1559898298(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 6));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1092144743x1559898298(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s759871588x920431471_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s759871588x920431471_24dps_entry, 2, 0};

V g_list_2emap_24s759871588x920431471_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 9), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s759871588x920431471_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s759871588x920431471_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1816200867x1876638332_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1816200867x1876638332_entry, 1, 0};

V g_list_2emap_24s1816200867x1876638332(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1816200867x1876638332_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1816200867x1876638332_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1816200867x1876638332(a[0]);
}
Clo g_list_2ezipWith_24s634456687x1151454243_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s634456687x1151454243_entry, 2, 0};

V g_list_2ezipWith_24s634456687x1151454243(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_244, 0, 3), v_x_242});
      V v_cell_247 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s634456687x1151454243_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s634456687x1151454243_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s634456687x1151454243(a[0], a[1]);
}
Clo g_list_2emap_24s1791433880x1360378684_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1791433880x1360378684_24dps_entry, 2, 0};

V g_list_2emap_24s1791433880x1360378684_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1791433880x1360378684_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1791433880x1360378684_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2029274225x672412636_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029274225x672412636_entry, 4, 0};

V g_list_2emap_24s2029274225x672412636(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_take_field(v_x_244, 2), heff_dup(v_lit_242));
    V v_t_247 = heff_strAppend(heff_take_field(v_x_244, 1), heff_strAppend(heff_dup(v_lit_241), v_t_246));
    V v_t_248 = heff_strAppend(heff_get_n(v_x_244, 0, 3), heff_strAppend(heff_dup(v_lit_240), v_t_247));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s2029274225x672412636_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s2029274225x672412636_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029274225x672412636(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efilter_24s1200694983x1257685262_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1200694983x1257685262_entry, 2, 0};

V g_list_2efilter_24s1200694983x1257685262(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c(v_t_246, heff_dup(v_lit_240))) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_249 = (g_list_2efilter_24s1200694983x1257685262_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1200694983x1257685262_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1200694983x1257685262(a[0], a[1]);
}
Clo g_list_2efind_24s1250280863x1570195177_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1250280863x1570195177_entry, 2, 0};

V g_list_2efind_24s1250280863x1570195177(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1250280863x1570195177_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s1250280863x1570195177(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1771067298x678756798_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1771067298x678756798_entry, 2, 0};

V g_list_2efilter_24s1771067298x678756798(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s1771067298x678756798_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1771067298x678756798_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1771067298x678756798(a[0], a[1]);
}
Clo g_list_2emerge_24s1037857700x2096250953_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1037857700x2096250953_24dps_entry, 3, 0};

V g_list_2emerge_24s1037857700x2096250953_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 5);
      heff_drop(v_xs2_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_xs_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 1, 2);
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 0, 2);
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_y_245, 0)), 1, 2);
      V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_y_245, 0)), 0, 2);
      if (heff_intLe_c(heff_intSub(v_t_247, v_t_248), heff_intSub(v_t_249, v_t_2410))) {
        V v_cell_2412 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_2413 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2412));
        heff_drop(v_u_2413);
        V t_0 = v_xs2_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246});
        V t_2 = v_cell_2412;
        v_xs_240 = t_0;
        v_ys_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_2414 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2415 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2414));
        heff_drop(v_u_2415);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs2_244});
        V t_1 = v_ys2_246;
        V t_2 = v_cell_2414;
        v_xs_240 = t_0;
        v_ys_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1037857700x2096250953_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1037857700x2096250953_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s1109331425x852844386_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1109331425x852844386_entry, 3, 0};

V g_list_2efilter_24s1109331425x852844386(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 1, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 0, 2);
    V v_t_247 = heff_strLength(heff_dup(heff_rfield(v_x_243, 1)));
    if (heff_intLe_c(heff_intSub(v_t_245, v_t_246), heff_intAdd(v_t_247, heff_dup(v_lit_240)))) {
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 0, 2);
      if (heff_intLe_c(v_t_249, heff_dup(v_lit_241))) {
        V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 1, 2);
        if (heff_intLe_c(heff_dup(v_lit_241), v_t_2411)) {
          V v_cell_2413 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
          V v_u_2414 = (g_list_2efilter_24s1109331425x852844386_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_2413)));
          heff_drop(v_u_2414);
          return v_cell_2413;
        } else {
          heff_drop_rec(v_x_243, 5);
          heff_drop_cell(v_ru_24x2_242_24Cons, 2);
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_xs_244;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_x2_242 = t_2;
          goto top;
        }
      } else {
        heff_drop_rec(v_x_243, 5);
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_243, 5);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24s1109331425x852844386_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1109331425x852844386(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1817753698x509594538_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1817753698x509594538_24dps_entry, 4, 0};

V g_list_2emap_24s1817753698x509594538_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_rec_n(3, shape_key__member__local, (V[]){heff_dup(v_lit_240), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    V v_a_247 = heff_take_field(v_x_244, 0);
    V v_a_248 = heff_intSub(heff_dup(heff_rfield(v_x_244, 1)), heff_strLength(heff_dup(v_lit_241)));
    V v_t_2410;
    if (heff_intLe_c(heff_dup(v_a_247), heff_dup(v_a_248))) {
      heff_drop(v_a_247);
      v_t_2410 = v_a_248;
    } else {
      heff_drop(v_a_248);
      v_t_2410 = v_a_247;
    }
    V v_t_2411 = ({ V rv_0 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_x_244, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_target__name__span, (V[]){v_t_246, heff_dup(v_lit_241), v_t_2411}), heff_hole()});
    V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_2412;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1817753698x509594538_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1817753698x509594538_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1675313341x192238134_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1675313341x192238134_entry, 1, 0};

V g_list_2emap_24s1675313341x192238134(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkEquation: {
        V v_fsp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 2ULL, 4);
        v_t_249 = v_fsp_246;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s1675313341x192238134_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1675313341x192238134_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1675313341x192238134(a[0]);
}
Clo g_list_2eany_24s406396256x713021373_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s406396256x713021373_entry, 2, 0};

V g_list_2eany_24s406396256x713021373(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_a_245 = heff_dup(heff_rfield(v_lit_240, 1));
    if (heff_intEq_c(heff_dup(heff_rfield(v_a_244, 0)), heff_dup(heff_rfield(v_a_245, 0)))) {
      if (heff_intEq_c(heff_get_n(v_a_244, 1, 2), heff_get_n(v_a_245, 1, 2))) {
        heff_drop_rec(v_lit_240, 3);
        return NTAG(TAG_True);
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop_rec(v_a_244, 2);
      heff_drop_rec(v_a_245, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s406396256x713021373_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s406396256x713021373(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1711939327x1502975912_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1711939327x1502975912_entry, 2, 0};

V g_list_2eany_24s1711939327x1502975912(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 2);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1711939327x1502975912_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1711939327x1502975912(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s316268077x2111002396_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s316268077x2111002396_24dps_entry, 3, 0};

V g_list_2efilter_24s316268077x2111002396_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(heff_rfield(v_lit_240, 1)))) {
      heff_drop_rec(v_x_243, 13);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s316268077x2111002396_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s316268077x2111002396_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1620243413x998711352_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1620243413x998711352_entry, 2, 0};

V g_list_2efoldl_24s1620243413x998711352(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_StmtBind: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_248));
        break;
      }
      case TAG_StmtLet: {
        V v_a_2410 = heff_field(v_a_244, 1);
        v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2410));
        break;
      }
      case TAG_StmtExpr: {
        V v_a_2411 = heff_field(v_a_244, 0);
        v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2411));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1620243413x998711352_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1620243413x998711352(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1716878720x675187502_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1716878720x675187502_24dps_entry, 3, 0};

V g_list_2efilter_24s1716878720x675187502_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 0, 2);
    if (heff_intLe_c(heff_dup(heff_rfield(v_lit_240, 0)), v_t_245)) {
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 1, 2);
      if (heff_intLe_c(v_t_247, heff_dup(heff_rfield(v_lit_240, 1)))) {
        V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = v_lit_240;
        V t_1 = v_xs_244;
        V t_2 = v_cell_249;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop_rec(v_x_243, 3);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_xs_244;
        V t_2 = v_d_242;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1716878720x675187502_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1716878720x675187502_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1661513421x830177447_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1661513421x830177447_24dps_entry, 4, 0};

V g_list_2emap_24s1661513421x830177447_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_248;
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_240))) {
      V v_t_247 = heff_intAdd(heff_take_field(v_x_244, 3), heff_dup(v_lit_241));
      v_t_248 = ({ V rv_3 = v_t_247; V rr_ = heff_rec_reuse_nf(v_x_244, 23ULL, 5, shape_task__parent__name__done__total, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      v_t_248 = v_x_244;
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1661513421x830177447_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1661513421x830177447_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eany_24s1230506745x754542351_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1230506745x754542351_entry, 2, 0};

V g_list_2eany_24s1230506745x754542351(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c(v_t_246, heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1230506745x754542351_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1230506745x754542351(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1855973232x1329676164_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1855973232x1329676164_entry, 4, 0};

V g_list_2efilter_24s1855973232x1329676164(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_prelude_2esplitFrom(heff_dup(v_lit_240), heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_t_247 = (g_list_2emap_24s649333309x1802289391(v_t_246));
    V v_a_248 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_247));
    switch (heff_tag_of(v_a_248)) {
    case TAG_Nil: {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_2410 = (g_list_2efilter_24s1855973232x1329676164_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    case TAG_Cons: {
      V v_a_2411 = heff_field(v_a_248, 0);
      heff_take_n(v_a_248, 1ULL, 2);
      if (heff_strEq_c(v_a_2411, heff_dup(v_lit_242))) {
        V v_cell_2414 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_2415 = (g_list_2efilter_24s1855973232x1329676164_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2414)));
        heff_drop(v_u_2415);
        return v_cell_2414;
      } else {
        heff_drop_rec(v_x_244, 2);
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_245;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        goto top;
      }
    }
    default: return heff_nomatch(v_a_248);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s1855973232x1329676164_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1855973232x1329676164(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s170418522x132668694_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s170418522x132668694_entry, 1, 0};

V g_list_2emap_24s170418522x132668694(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 13), heff_hole()});
    V v_u_244 = (g_list_2emap_24s170418522x132668694_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s170418522x132668694_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s170418522x132668694(a[0]);
}
Clo g_list_2emap_24s170418522x132668694_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s170418522x132668694_24dps_entry, 2, 0};

V g_list_2emap_24s170418522x132668694_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 13), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s170418522x132668694_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s170418522x132668694_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s313075719x1688564285_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s313075719x1688564285_24dps_entry, 2, 0};

V g_list_2efilter_24s313075719x1688564285_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 6, 10);
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s313075719x1688564285_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s313075719x1688564285_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s1875112453x1656618700_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1875112453x1656618700_entry, 2, 0};

V g_list_2eany_24s1875112453x1656618700(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1875112453x1656618700_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1875112453x1656618700(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1170504272x1852564147_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1170504272x1852564147_entry, 1, 0};

V g_list_2emap_24s1170504272x1852564147(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_ExplicitParam: {
        V v_x_245 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_245;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_248 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1170504272x1852564147_24dps(v_xs_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1170504272x1852564147_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1170504272x1852564147(a[0]);
}
Clo g_list_2emap_24s499193121x1224230698_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s499193121x1224230698_24dps_entry, 2, 0};

V g_list_2emap_24s499193121x1224230698_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2423;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_PatVar: {
        V v_x_246 = heff_field(v_x11_244, 0);
        V v_ru_24x11_244_24PatVar = heff_take_reuse_n(v_x11_244, 1ULL, 1);
        v_t_2423 = heff_tag_at_n(v_ru_24x11_244_24PatVar, TAG_Just, 1, (V[]){v_x_246});
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_na(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2424;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s499193121x1224230698_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s499193121x1224230698_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s908966052x1460382280_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s908966052x1460382280_entry, 2, 0};

V g_list_2eany_24s908966052x1460382280(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s908966052x1460382280_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s908966052x1460382280(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1392550889x861369760_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1392550889x861369760_24dps_entry, 3, 0};

V g_list_2efilter_24s1392550889x861369760_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 7);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(heff_rfield(v_lit_240, 1)))) {
      heff_drop_rec(v_x_243, 7);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1392550889x861369760_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1392550889x861369760_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s582709368x2113456071_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s582709368x2113456071_entry, 1, 0};

V g_list_2emap_24s582709368x2113456071(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s582709368x2113456071_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s582709368x2113456071_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s582709368x2113456071(a[0]);
}
Clo g_list_2efilter_24s951260806x709953240_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s951260806x709953240_entry, 2, 0};

V g_list_2efilter_24s951260806x709953240(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_lit_240, 0);
      v_t_249 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    if (heff_strEq_c(v_t_246, v_t_249)) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2412 = (g_list_2efilter_24s951260806x709953240_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s951260806x709953240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efilter_24s951260806x709953240(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2eany_24s193691892x499187556_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s193691892x499187556_entry, 4, 0};

V g_list_2eany_24s193691892x499187556(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_strLength(heff_dup(heff_rfield(v_x_244, 1)));
    if (heff_intLt_c(heff_dup(v_lit_240), v_t_246)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      return NTAG(TAG_True);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_241))) {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_lit_242);
        return NTAG(TAG_True);
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_242))) {
          heff_drop(v_lit_240);
          heff_drop(v_lit_241);
          heff_drop(v_lit_242);
          return NTAG(TAG_True);
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_lit_242;
          V t_3 = v_xs_245;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_lit_242 = t_2;
          v_x2_243 = t_3;
          goto top;
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s193691892x499187556_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2eany_24s193691892x499187556(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efilter_24s561186959x2071570661_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s561186959x2071570661_entry, 3, 0};

V g_list_2efilter_24s561186959x2071570661(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strSlice(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240), heff_strLength(heff_dup(v_lit_241)));
    if (heff_strEq_c(v_t_245, heff_dup(v_lit_241))) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_248 = (g_list_2efilter_24s561186959x2071570661_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop_rec(v_x_243, 8);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24s561186959x2071570661_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s561186959x2071570661(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s296585291x885335139_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s296585291x885335139_24dps_entry, 2, 0};

V g_list_2emap_24s296585291x885335139_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_std_2ecli_2eheadOf(heff_dup(v_x_242)));
    V v_t_245 = (g_std_2ecli_2eline2(v_t_244, heff_get_n(v_x_242, 1, 4)));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s296585291x885335139_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s296585291x885335139_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s2016771181x401513202_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2016771181x401513202_entry, 3, 0};

V g_list_2efilter_24s2016771181x401513202(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_248 = heff_strSlice(v_t_247, heff_dup(v_lit_240), heff_strLength(heff_dup(v_lit_241)));
    if (heff_strEq_c(v_t_248, heff_dup(v_lit_241))) {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_2411 = (g_list_2efilter_24s2016771181x401513202_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24s2016771181x401513202_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2016771181x401513202(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1412546768x2004463577_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1412546768x2004463577_24dps_entry, 5, 0};

V g_list_2emap_24s1412546768x2004463577_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_245, 0));
      v_a_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_a_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 2ULL, 2);
      v_a_2412 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2414;
    if (heff_strEq_c(heff_dup(v_a_2412), heff_dup(v_lit_240))) {
      heff_drop(v_a_2412);
      v_t_2414 = v_a_249;
    } else {
      v_t_2414 = heff_strAppend(v_a_249, heff_strAppend(heff_dup(v_lit_241), v_a_2412));
    }
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2414, heff_dup(v_lit_242)), heff_hole()});
    V v_u_2416 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2415;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1412546768x2004463577_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1412546768x2004463577_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24f1352858702x862623587_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1352858702x862623587_24dps_entry, 6, 0};

V g_list_2emap_24f1352858702x862623587_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_x2_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_p_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_248 = heff_tr(heff_call(heff_dup(v_p_243), 1, (V[]){heff_dup(v_x_246)}));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = heff_strAppend(heff_take_field(v_x_246, 1), heff_dup(v_lit_242));
      V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_246, 2), heff_get_n(v_x_246, 3, 7)});
      V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), heff_strAppend(heff_dup(v_lit_241), v_t_249), v_t_2410, NTAG(TAG_Nothing)});
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2413 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_p_243;
      V t_4 = v_xs_247;
      V t_5 = v_cell_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_p_243 = t_3;
      v_x2_244 = t_4;
      v_d_245 = t_5;
      goto top;
    } else {
      heff_drop_rec(v_x_246, 7);
      heff_drop_cell(v_ru_24x2_244_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_p_243;
      V t_4 = v_xs_247;
      V t_5 = v_d_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_p_243 = t_3;
      v_x2_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f1352858702x862623587_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1352858702x862623587_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2efoldl_24f836170601x1639498774_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f836170601x1639498774_entry, 2, 0};

V g_list_2efoldl_24f836170601x1639498774(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_x_247 = v_b_246;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f836170601x1639498774_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f836170601x1639498774(a[0], a[1]);
}
Clo g_list_2efoldl_24f613246640x472569916_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f613246640x472569916_entry, 4, 0};

V g_list_2efoldl_24f613246640x472569916(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    switch (heff_tag_of(v_x_244)) {
    case TAG_PartVal: {
      V v_a_246 = heff_field(v_x_244, 0);
      V v_t_2430;
      switch (heff_tag_of(v_a_246)) {
      case TAG_SVar: {
        V v_a_247 = heff_field(v_a_246, 0);
        v_t_2430 = heff_strEq(heff_dup(v_lit_242), heff_dup(v_a_247));
        break;
      }
      case TAG_SGlobal: {
        v_t_2430 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        v_t_2430 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        v_t_2430 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        v_t_2430 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        v_t_2430 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        v_t_2430 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        v_t_2430 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2430 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        v_t_2430 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        v_t_2430 = NTAG(TAG_False);
        break;
      }
      case TAG_SRec: {
        v_t_2430 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        v_t_2430 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        v_t_2430 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
        heff_drop(v_t_2430);
        V t_0 = heff_dup(v_lit_240);
        V t_1 = heff_intAdd(v_z_241, v_lit_240);
        V t_2 = v_lit_242;
        V t_3 = v_xs_245;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_2430);
        V t_0 = v_lit_240;
        V t_1 = v_z_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_245;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        goto top;
      }
    }
    case TAG_PartOp: {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f613246640x472569916_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f613246640x472569916(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f155552269x628597815_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f155552269x628597815_entry, 3, 0};

V g_list_2efoldl_24f155552269x628597815(V v_z_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_ys_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      V v_ru_24ys_242_24Cons = heff_take_reuse_n(v_ys_242, 3ULL, 2);
      V v_x_247 = heff_tag_at_n(v_ru_24ys_242_24Cons, TAG_MkPair, 2, (V[]){v_x_243, v_y_245});
      V t_0 = heff_tag_at_n(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_240});
      V t_1 = v_xs2_244;
      V t_2 = v_ys2_246;
      v_z_240 = t_0;
      v_xs_241 = t_1;
      v_ys_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2efoldl_24f155552269x628597815_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f155552269x628597815(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f226312210x181720981_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f226312210x181720981_entry, 4, 0};

V g_list_2efoldl_24f226312210x181720981(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (heff_strEq_c(heff_dup(v_x_244), heff_dup(v_lit_242))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f226312210x181720981_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f226312210x181720981(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2emap_24f1293205645x619162872_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1293205645x619162872_24dps_entry, 5, 0};

V g_list_2emap_24f1293205645x619162872_24dps(V v_lit_240, V v_lit_241, V v_a_242, V v_b_243, V v_d_244) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_243), heff_dup(v_a_242))) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_246 = heff_strAppend(heff_intShow(heff_dup(v_a_242)), heff_dup(v_lit_241));
    V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_246), heff_hole()});
    V v_u_248 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_intAdd(v_a_242, MK_INT(1LL));
    V t_3 = v_b_243;
    V t_4 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
}
V g_list_2emap_24f1293205645x619162872_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1293205645x619162872_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24f1217399696x462307458_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1217399696x462307458_entry, 3, 0};

V g_list_2emap_24f1217399696x462307458(V v_lit_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return (g_list_2emap_24s231073986x752637537(v_lit_240, v_ys_242));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_243), heff_hole()});
    V v_u_246 = (g_list_2emap_24f1217399696x462307458_24dps(v_lit_240, v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2emap_24f1217399696x462307458_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1217399696x462307458(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f1260271301x348779032_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1260271301x348779032_entry, 2, 0};

V g_list_2emap_24f1260271301x348779032(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 13);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
      V v_u_246 = (g_list_2emap_24f1260271301x348779032_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1260271301x348779032_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1260271301x348779032(a[0], a[1]);
}
Clo g_list_2emap_24f904804876x285797696_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f904804876x285797696_24dps_entry, 4, 0};

V g_list_2emap_24f904804876x285797696_24dps(V v_f_240, V v_a_241, V v_b_242, V v_d_243) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_242), heff_dup(v_a_241))) {
    heff_drop(v_f_240);
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_a_241)}));
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_f_240;
    V t_1 = heff_intAdd(v_a_241, MK_INT(1LL));
    V t_2 = v_b_242;
    V t_3 = v_cell_246;
    v_f_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f904804876x285797696_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f904804876x285797696_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efilter_24f419751885x381357165_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24f419751885x381357165_24dps_entry, 3, 0};

V g_list_2efilter_24f419751885x381357165_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_get_n(v_x_243, 1, 8);
    if (heff_strEq_c(heff_dup(v_x_245), heff_dup(v_lit_240))) {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_x_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_247;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24f419751885x381357165_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24f419751885x381357165_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f1690623035x874154762_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1690623035x874154762_entry, 6, 0};

V g_list_2emap_24f1690623035x874154762(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_take_field(v_x_246, 2);
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = heff_strSlice(heff_dup(heff_rfield(v_x_246, 0)), heff_dup(v_lit_243), heff_strLength(heff_dup(v_lit_244)));
      if (heff_strEq_c(v_t_249, heff_dup(v_lit_244))) {
        V v_a_2411 = heff_take_field(v_x_246, 0);
        V v_a_2412 = heff_get_n(v_x_246, 1, 4);
        V v_t_2414;
        if (heff_strEq_c(heff_dup(v_a_2412), heff_dup(v_lit_240))) {
          heff_drop(v_a_2412);
          v_t_2414 = v_a_2411;
        } else {
          v_t_2414 = heff_strAppend(v_a_2411, heff_strAppend(heff_dup(v_lit_241), v_a_2412));
        }
        V v_cell_2415 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2414, heff_dup(v_lit_242)), heff_hole()});
        V v_u_2416 = (g_list_2emap_24f1690623035x874154762_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2415)));
        heff_drop(v_u_2416);
        return v_cell_2415;
      } else {
        heff_drop_rec(v_x_246, 4);
        heff_drop_cell(v_ru_24x2_245_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_247;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_246, 4);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24f1690623035x874154762_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1690623035x874154762(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24f1690623035x874154762_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1690623035x874154762_24dps_entry, 7, 0};

V g_list_2emap_24f1690623035x874154762_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_249 = heff_take_field(v_x_247, 2);
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_t_2410 = heff_strSlice(heff_dup(heff_rfield(v_x_247, 0)), heff_dup(v_lit_243), heff_strLength(heff_dup(v_lit_244)));
      if (heff_strEq_c(v_t_2410, heff_dup(v_lit_244))) {
        V v_a_2412 = heff_take_field(v_x_247, 0);
        V v_a_2413 = heff_get_n(v_x_247, 1, 4);
        V v_t_2415;
        if (heff_strEq_c(heff_dup(v_a_2413), heff_dup(v_lit_240))) {
          heff_drop(v_a_2413);
          v_t_2415 = v_a_2412;
        } else {
          v_t_2415 = heff_strAppend(v_a_2412, heff_strAppend(heff_dup(v_lit_241), v_a_2413));
        }
        V v_cell_2416 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2415, heff_dup(v_lit_242)), heff_hole()});
        V v_u_2417 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2416));
        heff_drop(v_u_2417);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_248;
        V t_6 = v_cell_2416;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        v_d_246 = t_6;
        goto top;
      } else {
        heff_drop_rec(v_x_247, 4);
        heff_drop_cell(v_ru_24x2_245_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_248;
        V t_6 = v_d_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        v_d_246 = t_6;
        goto top;
      }
    } else {
      heff_drop_rec(v_x_247, 4);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_t_249);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_248;
      V t_6 = v_d_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      v_d_246 = t_6;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24f1690623035x874154762_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1690623035x874154762_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}