// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"

static V g_heff_2efmt_2elayout_2eblankMark_val;
static int g_heff_2efmt_2elayout_2eblankMark_st;
static V g_heff_2efmt_2elayout_2eblankMark_init(void) {
  return heff_strFromCharCode(MK_INT(1LL));
}
V g_heff_2efmt_2elayout_2eblankMark_get(void) {
  if (g_heff_2efmt_2elayout_2eblankMark_st == 2) return g_heff_2efmt_2elayout_2eblankMark_val;
  if (g_heff_2efmt_2elayout_2eblankMark_st == 1) heff_fail("defined by itself");
  g_heff_2efmt_2elayout_2eblankMark_st = 1;
  g_heff_2efmt_2elayout_2eblankMark_val = heff_tr(g_heff_2efmt_2elayout_2eblankMark_init());
  g_heff_2efmt_2elayout_2eblankMark_st = 2;
  return g_heff_2efmt_2elayout_2eblankMark_val;
}

static V g_heff_2efmt_2elayout_2enewlineMark_val;
static int g_heff_2efmt_2elayout_2enewlineMark_st;
static V g_heff_2efmt_2elayout_2enewlineMark_init(void) {
  return heff_strFromCharCode(MK_INT(2LL));
}
V g_heff_2efmt_2elayout_2enewlineMark_get(void) {
  if (g_heff_2efmt_2elayout_2enewlineMark_st == 2) return g_heff_2efmt_2elayout_2enewlineMark_val;
  if (g_heff_2efmt_2elayout_2enewlineMark_st == 1) heff_fail("defined by itself");
  g_heff_2efmt_2elayout_2enewlineMark_st = 1;
  g_heff_2efmt_2elayout_2enewlineMark_val = heff_tr(g_heff_2efmt_2elayout_2enewlineMark_init());
  g_heff_2efmt_2elayout_2enewlineMark_st = 2;
  return g_heff_2efmt_2elayout_2enewlineMark_val;
}
Clo g_heff_2efmt_2elayout_2ertrimEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2ertrimEnd_entry, 2, 0};

V g_heff_2efmt_2elayout_2ertrimEnd(V v_s_240, V v_e_241) {
top: ;
  V v_t_242 = heff_intLt(MK_INT(0LL), heff_dup(v_e_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_t_242);
    V v_t_243 = heff_strCharCode(heff_dup(v_s_240), heff_intSub(heff_dup(v_e_241), MK_INT(1LL)));
    V v_t_244 = heff_intEq(v_t_243, MK_INT(32LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_t_244);
      V t_0 = v_s_240;
      V t_1 = heff_intSub(v_e_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_e_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_t_244);
      V v_t_245 = heff_strCharCode(heff_dup(v_s_240), heff_intSub(heff_dup(v_e_241), MK_INT(1LL)));
      V v_t_246 = heff_intEq(v_t_245, MK_INT(9LL));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_t_246);
        V t_0 = v_s_240;
        V t_1 = heff_intSub(v_e_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_t_246);
        V v_t_247 = heff_strCharCode(heff_dup(v_s_240), heff_intSub(heff_dup(v_e_241), MK_INT(1LL)));
        V v_t_248 = heff_intEq(v_t_247, MK_INT(13LL));
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          heff_drop(v_t_248);
          V t_0 = v_s_240;
          V t_1 = heff_intSub(v_e_241, MK_INT(1LL));
          v_s_240 = t_0;
          v_e_241 = t_1;
          goto top;
        }
        case TAG_False: {
          heff_drop(v_s_240);
          heff_drop(v_t_248);
          return v_e_241;
        }
        default: return heff_nomatch(v_t_248);
        }
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_False: {
    heff_drop(v_s_240);
    heff_drop(v_t_242);
    return v_e_241;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2efmt_2elayout_2ertrimEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elayout_2ertrimEnd(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2eblankLine_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};

static V g_heff_2efmt_2elayout_2eblankLine_val;
static int g_heff_2efmt_2elayout_2eblankLine_st;
static V g_heff_2efmt_2elayout_2eblankLine_init(void) {
  V v_t_240 = heff_strEq(heff_dup(g_heff_2efmt_2elayout_2eblankMark_get()), ((V)&g_heff_2efmt_2elayout_2eblankLine_str0));
  V v_t_241;
  switch (heff_tag_of(v_t_240)) {
  case TAG_True: {
    heff_drop(v_t_240);
    v_t_241 = NTAG(TAG_None);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_240);
    v_t_241 = heff_tag(TAG_Text, 1, (V[]){heff_dup(g_heff_2efmt_2elayout_2eblankMark_get())});
    break;
  }
  default: heff_nomatch(v_t_240);
  }
  return (g_std_2edoc_2e_3c_3e(v_t_241, heff_dup(g_std_2edoc_2ehardline_get())));
}
V g_heff_2efmt_2elayout_2eblankLine_get(void) {
  if (g_heff_2efmt_2elayout_2eblankLine_st == 2) return g_heff_2efmt_2elayout_2eblankLine_val;
  if (g_heff_2efmt_2elayout_2eblankLine_st == 1) heff_fail("defined by itself");
  g_heff_2efmt_2elayout_2eblankLine_st = 1;
  g_heff_2efmt_2elayout_2eblankLine_val = heff_tr(g_heff_2efmt_2elayout_2eblankLine_init());
  g_heff_2efmt_2elayout_2eblankLine_st = 2;
  return g_heff_2efmt_2elayout_2eblankLine_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2etrailOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2etrailOf_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2etrailOf_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2etrailOf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_heff_2efmt_2elayout_2etrailOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2etrailOf_entry, 2, 0};

V g_heff_2efmt_2elayout_2etrailOf(V v_env_240, V v_t_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_get(v_t_241, LBL_ix); V b_1 = heff_get(v_env_240, LBL_trail); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_t_242);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_c_243 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse(v_t_242, 1ULL);
    V v_x2_244 = (g_prelude_2esplitFrom(((V)&g_heff_2efmt_2elayout_2etrailOf_str0), v_c_243, MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      heff_drop(v_x2_244);
      v_s_247 = ((V)&g_heff_2efmt_2elayout_2etrailOf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take(v_x2_244, 3ULL);
      v_s_247 = ({ V a_0 = v_x_245; V a_1 = v_xs_246; V r_ = (g_prelude_2efoldl_24s703(a_0, a_1)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = heff_strEq(heff_dup(v_s_247), ((V)&g_heff_2efmt_2elayout_2etrailOf_str2));
    V v_t_249;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_ru_24t_242_24Just);
      heff_drop(v_s_247);
      heff_drop(v_t_248);
      v_t_249 = NTAG(TAG_None);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_248);
      v_t_249 = heff_tag_at(v_ru_24t_242_24Just, TAG_Text, 1, (V[]){v_s_247});
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_dup(g_std_2edoc_2ehardline_get())));
    return (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2etrailOf_str3)}), v_t_2410));
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2efmt_2elayout_2etrailOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elayout_2etrailOf(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2etok_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2efmt_2elayout_2etok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2etok_entry, 2, 0};

V g_heff_2efmt_2elayout_2etok(V v_env_240, V v_t_241) {
top: ;
  V v_t_242 = heff_intEq(heff_get(heff_dup(v_t_241), LBL_ix), heff_get(heff_dup(v_env_240), LBL_noLead));
  V v_x1_245;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_t_242);
    v_x1_245 = NTAG(TAG_Nil);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_242);
    V v_x2_243 = ({ V a_0 = heff_get(heff_dup(v_t_241), LBL_ix); V b_1 = heff_get(heff_dup(v_env_240), LBL_lead); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nothing: {
      heff_drop(v_x2_243);
      v_x1_245 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x2_243, 0);
      heff_take(v_x2_243, 1ULL);
      v_x1_245 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_2414;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nil: {
    heff_drop(v_x1_245);
    v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Cons: {
    heff_take(v_x1_245, 0ULL);
    V v_t_248 = heff_intEq(heff_get(heff_dup(v_t_241), LBL_ix), heff_get(heff_dup(v_env_240), LBL_noLead));
    V v_t_2411;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_t_248);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_248);
      V v_x2_249 = ({ V a_0 = heff_get(heff_dup(v_t_241), LBL_ix); V b_1 = heff_get(heff_dup(v_env_240), LBL_lead); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        heff_drop(v_x2_249);
        v_t_2411 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        heff_take(v_x2_249, 1ULL);
        v_t_2411 = v_x_2410;
        break;
      }
      default: heff_nomatch(v_x2_249);
      }
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_ds_2412 = (g_prelude_2emap_24s705(v_t_2411));
    V v_t_2413 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2412; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_2412); r_; });
    v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2413, heff_dup(g_std_2edoc_2ehardline_get())));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  V v_x2_2415 = ({ V a_0 = heff_get(heff_dup(v_t_241), LBL_ix); V b_1 = heff_get(heff_dup(v_env_240), LBL_inline); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2417;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nothing: {
    heff_drop(v_x2_2415);
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    heff_take(v_x2_2415, 1ULL);
    v_t_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_ds_2418 = (g_prelude_2emap_24s706(v_t_2417));
  V v_t_2419 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2418; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_2418); r_; });
  V v_s_2420 = heff_get(heff_dup(v_t_241), LBL_raw);
  V v_t_2421 = heff_strEq(heff_dup(v_s_2420), ((V)&g_heff_2efmt_2elayout_2etok_str0));
  V v_t_2422;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_True: {
    heff_drop(v_s_2420);
    heff_drop(v_t_2421);
    v_t_2422 = NTAG(TAG_None);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2421);
    v_t_2422 = heff_tag(TAG_Text, 1, (V[]){v_s_2420});
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  V v_t_2423 = heff_intEq(heff_get(heff_dup(v_t_241), LBL_ix), heff_get(heff_dup(v_env_240), LBL_noTrail));
  V v_t_2424;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_True: {
    heff_drop(v_env_240);
    heff_drop(v_t_241);
    heff_drop(v_t_2423);
    v_t_2424 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2423);
    v_t_2424 = (g_heff_2efmt_2elayout_2etrailOf(v_env_240, v_t_241));
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2422, v_t_2424));
  V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2425));
  return (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2426));
}
V g_heff_2efmt_2elayout_2etok_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elayout_2etok(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2eleadDocs_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2eleadDocs_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2eleadDocs_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2efmt_2elayout_2eleadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2eleadDocs_entry, 2, 0};

V g_heff_2efmt_2elayout_2eleadDocs(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_intLt(MK_INT(0LL), heff_dup(v_i_241));
    V v_t_246;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_t_244);
      V v_t_245 = heff_get(heff_dup(v_c_242), LBL_blank);
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_heff_2efmt_2elayout_2eblankLine_get());
        break;
      }
      case TAG_False: {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_t_244);
      v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_x2_247 = (g_prelude_2esplitFrom(((V)&g_heff_2efmt_2elayout_2eleadDocs_str0), heff_get(heff_dup(v_c_242), LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      heff_drop(v_x2_247);
      v_s_2410 = ((V)&g_heff_2efmt_2elayout_2eleadDocs_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take(v_x2_247, 3ULL);
      v_s_2410 = ({ V a_0 = v_x_248; V a_1 = v_xs_249; V r_ = (g_prelude_2efoldl_24s703(a_0, a_1)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2411 = heff_strEq(heff_dup(v_s_2410), ((V)&g_heff_2efmt_2elayout_2eleadDocs_str2));
    V v_t_2412;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      heff_drop(v_s_2410);
      heff_drop(v_t_2411);
      v_t_2412 = NTAG(TAG_None);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_2411);
      v_t_2412 = heff_tag(TAG_Text, 1, (V[]){v_s_2410});
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    V v_t_2413 = (g_heff_2efmt_2elayout_2eleadDocs(v_cs_243, heff_intAdd(v_i_241, MK_INT(1LL))));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
    V v_t_2415 = (g_std_2edoc_2e_3c_3e(v_t_2412, v_t_2414));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2415));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2efmt_2elayout_2eleadDocs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2eleadDocs(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2efmt_2elayout_2eitem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2eitem_entry, 4, 0};

V g_heff_2efmt_2elayout_2eitem(V v_env_240, V v_first_241, V v_last2_242, V v_body_243) {
top: ;
  V v_x2_244 = ({ V a_0 = heff_get(heff_dup(v_first_241), LBL_ix); V b_1 = heff_get(heff_dup(v_env_240), LBL_lead); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    heff_drop(v_x2_244);
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take(v_x2_244, 1ULL);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = MK_INT(0LL); V r_ = (g_heff_2efmt_2elayout_2eleadDocs(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_x2_248 = ({ V a_0 = heff_get(heff_dup(v_first_241), LBL_ix); V b_1 = heff_get(heff_dup(v_env_240), LBL_lead); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x1_2410;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    heff_drop(v_x2_248);
    v_x1_2410 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x2_248, 0);
    heff_take(v_x2_248, 1ULL);
    v_x1_2410 = v_x_249;
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  V v_x1_2413;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nil: {
    heff_drop(v_x1_2410);
    v_x1_2413 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take(v_x1_2410, 0ULL);
    v_x1_2413 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  V v_t_2415;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_True: {
    heff_drop(v_x1_2413);
    v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_False: {
    heff_drop(v_x1_2413);
    V v_t_2414 = heff_get(heff_dup(v_first_241), LBL_blank);
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      heff_drop(v_t_2414);
      v_t_2415 = heff_dup(g_heff_2efmt_2elayout_2eblankLine_get());
      break;
    }
    case TAG_False: {
      heff_drop(v_t_2414);
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    break;
  }
  default: heff_nomatch(v_x1_2413);
  }
  V v_t_2416 = heff_rec(7, shape_302_158_136_332_195_196_97, (V[]){heff_get(heff_dup(v_env_240), LBL_src), heff_get(heff_dup(v_env_240), LBL_lead), heff_get(heff_dup(v_env_240), LBL_inline), heff_get(heff_dup(v_env_240), LBL_trail), heff_get(v_first_241, LBL_ix), heff_get(heff_dup(v_last2_242), LBL_ix), heff_get(heff_dup(v_env_240), LBL_fix)});
  V v_t_2417 = heff_tr(heff_apply(v_body_243, 1, (V[]){v_t_2416}));
  V v_t_2418 = heff_intEq(heff_get(heff_dup(v_last2_242), LBL_ix), heff_get(heff_dup(v_env_240), LBL_noTrail));
  V v_t_2419;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    heff_drop(v_env_240);
    heff_drop(v_last2_242);
    heff_drop(v_t_2418);
    v_t_2419 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2418);
    v_t_2419 = (g_heff_2efmt_2elayout_2etrailOf(v_env_240, v_last2_242));
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V v_d_2420 = (g_std_2edoc_2e_3c_3e(v_t_2417, v_t_2419));
  V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2415, heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2420})));
  return (g_std_2edoc_2e_3c_3e(v_t_247, v_t_2421));
}
V g_heff_2efmt_2elayout_2eitem_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elayout_2eitem(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2efmt_2elayout_2ehangs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2ehangs_entry, 1, 0};

V g_heff_2efmt_2elayout_2ehangs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    V v_body_2459 = heff_field(v_e_240, 3);
    V t_0 = v_body_2459;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2efmt_2elayout_2ehangs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2ehangs(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2efmt_2elayout_2esameOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2esameOp_entry, 2, 0};

V g_heff_2efmt_2elayout_2esameOp(V v_op_240, V v_other_241) {
top: ;
  switch (heff_tag_of(v_other_241)) {
  case TAG_Nil: {
    heff_drop(v_op_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_other1_242 = heff_field(v_other_241, 0);
    switch (heff_tag_of(v_other1_242)) {
    case TAG_Atom: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_EParen: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_Named: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_Tup: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_Braces: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_InstB: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_EFSet: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_Sum: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_ECon: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_EField: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_App: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_Op: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_Ops: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_OpRhs: {
      V v_op2_2445 = heff_field(v_other1_242, 0);
      return heff_strEq(heff_get(heff_dup(v_op2_2445), LBL_text), heff_get(v_op_240, LBL_text));
    }
    case TAG_Ann: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_BVar: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_BImp: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_BAnn: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_Lam: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_Case: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_EAlt: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_If: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_Do: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_ESBind: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_op_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_other1_242);
    }
  }
  default: return heff_nomatch(v_other_241);
  }
}
V g_heff_2efmt_2elayout_2esameOp_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2esameOp(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2efmt_2elayout_2echain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2echain_entry, 1, 0};

V g_heff_2efmt_2elayout_2echain(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EParen: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Named: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Tup: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Braces: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_InstB: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFSet: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Sum: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ECon: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EField: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_App: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Op: {
    V v_a_2437 = heff_field(v_e_240, 0);
    V v_op_2438 = heff_field(v_e_240, 1);
    V v_b_2439 = heff_field(v_e_240, 2);
    heff_take(v_e_240, 7ULL);
    V v_x4_2440 = (g_heff_2efmt_2elayout_2echain(heff_dup(v_b_2439)));
    switch (heff_tag_of(v_x4_2440)) {
    case TAG_MkChain: {
      V v_bf_2441 = heff_field(v_x4_2440, 0);
      V v_rest_2442 = heff_field(v_x4_2440, 1);
      V v_ru_24x4_2440_24MkChain = heff_take_reuse(v_x4_2440, 3ULL);
      V v_t_2443 = (g_heff_2efmt_2elayout_2esameOp(heff_dup(v_op_2438), v_rest_2442));
      switch (heff_tag_of(v_t_2443)) {
      case TAG_True: {
        heff_drop(v_b_2439);
        heff_drop(v_t_2443);
        V v_t_2444 = heff_tag_at(v_ru_24x4_2440_24MkChain, TAG_Cons, 2, (V[]){heff_tag(TAG_OpRhs, 2, (V[]){v_op_2438, v_bf_2441}), v_rest_2442});
        return heff_tag(TAG_MkChain, 2, (V[]){v_a_2437, v_t_2444});
      }
      case TAG_False: {
        heff_drop(v_bf_2441);
        heff_drop(v_rest_2442);
        heff_drop(v_t_2443);
        V v_t_2445 = heff_tag_at(v_ru_24x4_2440_24MkChain, TAG_Cons, 2, (V[]){heff_tag(TAG_OpRhs, 2, (V[]){v_op_2438, v_b_2439}), NTAG(TAG_Nil)});
        return heff_tag(TAG_MkChain, 2, (V[]){v_a_2437, v_t_2445});
      }
      default: return heff_nomatch(v_t_2443);
      }
    }
    default: return heff_nomatch(v_x4_2440);
    }
  }
  case TAG_Ops: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_OpRhs: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Ann: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BVar: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BImp: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BAnn: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Lam: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Case: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EAlt: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_If: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Do: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ESBind: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ELet: {
    return heff_tag(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2efmt_2elayout_2echain_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elayout_2echain(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2efmt_2elayout_2eanyArrow_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 62}};
Clo g_heff_2efmt_2elayout_2eanyArrow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2eanyArrow_entry, 1, 0};

V g_heff_2efmt_2elayout_2eanyArrow(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Atom: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ECon: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EField: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_OpRhs: {
      V v_op_2444 = heff_field(v_x11_241, 0);
      V v_t_2446 = heff_strEq(heff_get(heff_dup(v_op_2444), LBL_text), ((V)&g_heff_2efmt_2elayout_2eanyArrow_str0));
      switch (heff_tag_of(v_t_2446)) {
      case TAG_True: {
        heff_drop(v_t_2446);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        heff_drop(v_t_2446);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_t_2446);
      }
    }
    case TAG_Ann: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2efmt_2elayout_2eanyArrow_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2eanyArrow(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epListGo_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_heff_2efmt_2elayout_2epListGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2epListGo_entry, 5, 0};

V g_heff_2efmt_2elayout_2epListGo(V v_env_240, V v_pOne_241, V v_x3_242, V v_commas_243, V v_isFirst_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_pOne_241);
    heff_drop(v_commas_243);
    heff_drop(v_isFirst_244);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_ps_246 = heff_field(v_x3_242, 1);
    V v_t_2410;
    switch (heff_tag_of(v_isFirst_244)) {
    case TAG_True: {
      v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_False: {
      switch (heff_tag_of(v_commas_243)) {
      case TAG_Nil: {
        v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_dup(heff_field(v_commas_243, 0));
        V v_t_249 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_247));
        v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epListGo_str0)})));
        break;
      }
      default: heff_nomatch(v_commas_243);
      }
      break;
    }
    default: heff_nomatch(v_isFirst_244);
    }
    V v_t_2411 = heff_tr(heff_apply(heff_dup(v_pOne_241), 1, (V[]){heff_dup(v_p_245)}));
    V v_t_2412;
    switch (heff_tag_of(v_isFirst_244)) {
    case TAG_True: {
      heff_drop(v_isFirst_244);
      v_t_2412 = v_commas_243;
      break;
    }
    case TAG_False: {
      heff_drop(v_isFirst_244);
      v_t_2412 = (g_prelude_2edrop(MK_INT(1LL), v_commas_243));
      break;
    }
    default: heff_nomatch(v_isFirst_244);
    }
    V v_t_2413 = (g_heff_2efmt_2elayout_2epListGo(v_env_240, v_pOne_241, v_ps_246, v_t_2412, NTAG(TAG_False)));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2413));
    return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2efmt_2elayout_2epListGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2epListGo(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epP_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epP_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epP_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epP_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epP_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epP_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epP_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
V g_heff_2efmt_2elayout_2epP_lam0(V self, V *args);
V g_heff_2efmt_2elayout_2epP_lam1(V self, V *args);
V g_heff_2efmt_2elayout_2epP_lam2(V self, V *args);
Clo g_heff_2efmt_2elayout_2epP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2epP_entry, 2, 0};

V g_heff_2efmt_2elayout_2epP(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_args_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_c_242)));
    V v_ds_247 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2epP_lam0, 1, 1, (V[]){v_env_240}), heff_dup(v_args_243)));
    V v_t_248 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_247; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_247); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_244, v_t_248));
  }
  case TAG_PAtom: {
    V v_t_249 = heff_field(v_x2_241, 0);
    return (g_heff_2efmt_2elayout_2etok(v_env_240, heff_dup(v_t_249)));
  }
  case TAG_PParen: {
    V v_o_2410 = heff_field(v_x2_241, 0);
    V v_p_2411 = heff_field(v_x2_241, 1);
    V v_c_2412 = heff_field(v_x2_241, 2);
    V v_t_2413 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2410)));
    V v_t_2414 = (g_heff_2efmt_2elayout_2epP(heff_dup(v_env_240), v_p_2411));
    V v_t_2415 = (g_heff_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2412)));
    V v_t_2416 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2415));
    return (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2416));
  }
  case TAG_PList: {
    V v_o_2417 = heff_field(v_x2_241, 0);
    V v_ps_2418 = heff_field(v_x2_241, 1);
    V v_commas_2419 = heff_field(v_x2_241, 2);
    V v_c_2420 = heff_field(v_x2_241, 3);
    V v_t_2421 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2417)));
    V v_t_2423 = (g_heff_2efmt_2elayout_2epListGo(heff_dup(v_env_240), heff_clo(g_heff_2efmt_2elayout_2epP_lam1, 1, 1, (V[]){heff_dup(v_env_240)}), v_ps_2418, heff_dup(v_commas_2419), NTAG(TAG_True)));
    V v_t_2424 = (g_heff_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2420)));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2423, v_t_2424));
    return (g_std_2edoc_2e_3c_3e(v_t_2421, v_t_2425));
  }
  case TAG_POp: {
    V v_l_2426 = heff_field(v_x2_241, 0);
    V v_op_2427 = heff_field(v_x2_241, 1);
    V v_r_2428 = heff_field(v_x2_241, 2);
    V v_a_2429 = (g_heff_2efmt_2elayout_2epP(heff_dup(v_env_240), v_l_2426));
    V v_a_2430 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_op_2427)));
    V v_b_2431 = (g_heff_2efmt_2elayout_2epP(v_env_240, v_r_2428));
    V v_t_2432 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epP_str1)}), v_b_2431));
    V v_b_2433 = (g_std_2edoc_2e_3c_3e(v_a_2430, v_t_2432));
    V v_t_2434 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epP_str2)}), v_b_2433));
    return (g_std_2edoc_2e_3c_3e(v_a_2429, v_t_2434));
  }
  case TAG_PRec: {
    V v_o_2435 = heff_field(v_x2_241, 0);
    V v_fs_2436 = heff_field(v_x2_241, 1);
    V v_commas_2437 = heff_field(v_x2_241, 2);
    V v_c_2438 = heff_field(v_x2_241, 3);
    V v_a_2439 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2435)));
    V v_a_2441 = (g_heff_2efmt_2elayout_2epListGo(heff_dup(v_env_240), heff_clo(g_heff_2efmt_2elayout_2epP_lam2, 1, 1, (V[]){heff_dup(v_env_240)}), v_fs_2436, heff_dup(v_commas_2437), NTAG(TAG_True)));
    V v_b_2442 = (g_heff_2efmt_2elayout_2etok(v_env_240, heff_dup(v_c_2438)));
    V v_t_2443 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epP_str3)}), v_b_2442));
    V v_b_2444 = (g_std_2edoc_2e_3c_3e(v_a_2441, v_t_2443));
    V v_t_2445 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epP_str4)}), v_b_2444));
    return (g_std_2edoc_2e_3c_3e(v_a_2439, v_t_2445));
  }
  case TAG_PField: {
    V v_x_2446 = heff_field(v_x2_241, 0);
    V v_eq_2447 = heff_field(v_x2_241, 1);
    V v_p_2448 = heff_field(v_x2_241, 2);
    V v_a_2449 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_2446)));
    V v_a_2450 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2447)));
    V v_b_2451 = (g_heff_2efmt_2elayout_2epP(v_env_240, v_p_2448));
    V v_t_2452 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epP_str5)}), v_b_2451));
    V v_b_2453 = (g_std_2edoc_2e_3c_3e(v_a_2450, v_t_2452));
    V v_t_2454 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epP_str6)}), v_b_2453));
    return (g_std_2edoc_2e_3c_3e(v_a_2449, v_t_2454));
  }
  case TAG_PAs: {
    V v_x_2455 = heff_field(v_x2_241, 0);
    V v_at_2456 = heff_field(v_x2_241, 1);
    V v_p_2457 = heff_field(v_x2_241, 2);
    V v_t_2458 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_2455)));
    V v_t_2459 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_at_2456)));
    V v_t_2460 = (g_heff_2efmt_2elayout_2epP(v_env_240, v_p_2457));
    V v_t_2461 = (g_std_2edoc_2e_3c_3e(v_t_2459, v_t_2460));
    return (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2461));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2efmt_2elayout_2epP_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2epP(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2efmt_2elayout_2epP_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_246 = ({ V a_0 = v_env_240; V a_1 = v_p_245; V r_ = (g_heff_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_245); r_; });
  return (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epP_str0)}), v_t_246));
}
V g_heff_2efmt_2elayout_2epP_lam1(V self, V *args) {
  V v_p2_2422 = args[0];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V a_0 = v_env_240; V a_1 = v_p2_2422; V r_ = (g_heff_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p2_2422); r_; });
}
V g_heff_2efmt_2elayout_2epP_lam2(V self, V *args) {
  V v_p2_2440 = args[0];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V a_0 = v_env_240; V a_1 = v_p2_2440; V r_ = (g_heff_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p2_2440); r_; });
}
V g_heff_2efmt_2elayout_2eopsOf_lam0(V self, V *args);
Clo g_heff_2efmt_2elayout_2eopsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2eopsOf_entry, 2, 0};

V g_heff_2efmt_2elayout_2eopsOf(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_x2_241);
    return heff_tag(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse(v_x2_241, 3ULL);
    switch (heff_tag_of(v_r_242)) {
    case TAG_Atom: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_EParen: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_Named: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_Tup: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_Braces: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_InstB: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFSet: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_Sum: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECon: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_EField: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_App: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_Op: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_Ops: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpRhs: {
      V v_op_2445 = heff_field(v_r_242, 0);
      heff_take(v_r_242, 1ULL);
      V v_t_2449 = ({ V a_0 = heff_clo(g_heff_2efmt_2elayout_2eopsOf_lam0, 1, 1, (V[]){heff_dup(v_op_2445)}); V b_1 = heff_get(heff_dup(v_f_240), LBL_groups); V r_ = (g_heff_2efixity_2efindG(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2449)) {
      case TAG_Nothing: {
        heff_drop(v_f_240);
        heff_drop(v_rs_243);
        heff_drop(v_ru_24x2_241_24Cons);
        heff_drop(v_op_2445);
        heff_drop(v_t_2449);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_ru_24t_2449_24Just = heff_take_reuse(v_t_2449, 0ULL);
        V v_x2_2451 = (g_heff_2efmt_2elayout_2eopsOf(v_f_240, v_rs_243));
        switch (heff_tag_of(v_x2_2451)) {
        case TAG_Nothing: {
          heff_drop(v_ru_24x2_241_24Cons);
          heff_drop(v_op_2445);
          heff_drop(v_ru_24t_2449_24Just);
          heff_drop(v_x2_2451);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_ops_2452 = heff_field(v_x2_2451, 0);
          heff_take(v_x2_2451, 1ULL);
          V v_t_2453 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get(v_op_2445, LBL_text), v_ops_2452});
          return heff_tag_at(v_ru_24t_2449_24Just, TAG_Just, 1, (V[]){v_t_2453});
        }
        default: return heff_nomatch(v_x2_2451);
        }
      }
      default: return heff_nomatch(v_t_2449);
      }
    }
    case TAG_Ann: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_BVar: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_BImp: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_BAnn: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_Lam: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_Case: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAlt: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_If: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_Do: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESBind: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take(v_r_242, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_rs_243);
      heff_drop(v_ru_24x2_241_24Cons);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_r_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2efmt_2elayout_2eopsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elayout_2eopsOf(a[0], a[1]);
}
V g_heff_2efmt_2elayout_2eopsOf_lam0(V self, V *args) {
  V v_g_2447 = args[0];
  V v_op_2445 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2448 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_op_2445, LBL_text)}));
  return ({ V a_0 = v_t_2448; V b_1 = heff_get(v_g_2447, LBL_ops); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
Clo g_heff_2efmt_2elayout_2eloosestGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2eloosestGo_entry, 3, 0};

V g_heff_2efmt_2elayout_2eloosestGo(V v_f_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return heff_tag(TAG_Just, 1, (V[]){v_m_241});
  }
  case TAG_Cons: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_os_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2efixity_2erelate(heff_dup(v_f_240), heff_dup(v_m_241), heff_dup(v_o_243)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Tighter: {
      heff_drop(v_m_241);
      heff_drop(v_t_245);
      V t_0 = v_f_240;
      V t_1 = heff_dup(v_o_243);
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Looser: {
      heff_drop(v_t_245);
      V t_0 = v_f_240;
      V t_1 = v_m_241;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Same: {
      heff_take(v_t_245, 0ULL);
      V t_0 = v_f_240;
      V t_1 = v_m_241;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Unrelated: {
      heff_drop(v_f_240);
      heff_drop(v_m_241);
      heff_drop(v_t_245);
      return NTAG(TAG_Nothing);
    }
    case TAG_Undeclared: {
      heff_take(v_t_245, 0ULL);
      heff_drop(v_f_240);
      heff_drop(v_m_241);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2efmt_2elayout_2eloosestGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2eloosestGo(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2efmt_2elayout_2eisSameIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2eisSameIn_entry, 3, 0};

V g_heff_2efmt_2elayout_2eisSameIn(V v_f_240, V v_m_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Atom: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_App: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    V v_op_2444 = heff_field(v_r_242, 0);
    V v_t_2446 = (g_heff_2efixity_2erelate(v_f_240, v_m_241, heff_get(heff_dup(v_op_2444), LBL_text)));
    switch (heff_tag_of(v_t_2446)) {
    case TAG_Tighter: {
      heff_drop(v_t_2446);
      return NTAG(TAG_False);
    }
    case TAG_Looser: {
      heff_drop(v_t_2446);
      return NTAG(TAG_False);
    }
    case TAG_Same: {
      heff_take(v_t_2446, 0ULL);
      return NTAG(TAG_True);
    }
    case TAG_Unrelated: {
      heff_drop(v_t_2446);
      return NTAG(TAG_False);
    }
    case TAG_Undeclared: {
      heff_take(v_t_2446, 0ULL);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2446);
    }
  }
  case TAG_Ann: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_If: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2efmt_2elayout_2eisSameIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2eisSameIn(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2efmt_2elayout_2eitemsGo_24s708_24s709_lam0(V self, V *args);
Clo g_heff_2efmt_2elayout_2eitemsGo_24s708_24s709_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2eitemsGo_24s708_24s709_entry, 3, 0};

V g_heff_2efmt_2elayout_2eitemsGo_24s708_24s709(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_245 = heff_intLt(MK_INT(0LL), heff_dup(v_i_241));
    V v_t_2413;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2ecst_2efirstE(v_x_243));
      V v_x2_247 = ({ V a_0 = heff_get(heff_dup(v_t_246), LBL_ix); V b_1 = heff_get(heff_dup(v_env_240), LBL_lead); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
      V v_x1_249;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        heff_drop(v_x2_247);
        v_x1_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take(v_x2_247, 1ULL);
        v_x1_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2412;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_Nil: {
        heff_drop(v_x1_249);
        v_t_2412 = heff_get(v_t_246, LBL_blank);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_x1_249, 0);
        heff_take(v_x1_249, 1ULL);
        heff_drop(v_t_246);
        v_t_2412 = heff_get(v_x_2410, LBL_blank);
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2efmt_2elayout_2eblankLine_get());
        break;
      }
      case TAG_False: {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_t_245);
      v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2414 = (g_heff_2ecst_2efirstE(v_x_243));
    V v_t_2415 = (g_heff_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2417 = (g_heff_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2414, v_t_2415, heff_clo(g_heff_2efmt_2elayout_2eitemsGo_24s708_24s709_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2418 = (g_heff_2efmt_2elayout_2eitemsGo_24s708_24s709(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2419 = (g_std_2edoc_2e_3c_3e(v_t_2417, v_t_2418));
    V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2419));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2420));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2efmt_2elayout_2eitemsGo_24s708_24s709_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2eitemsGo_24s708_24s709(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2efmt_2elayout_2eitemsGo_24s708_24s709_lam0(V self, V *args) {
  V v_e_2416 = args[0];
  V v_x_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_altDoc), 2, (V[]){v_e_2416, v_x_243});
}
V g_heff_2efmt_2elayout_2eitemsGo_24s708_24s710_lam0(V self, V *args);
Clo g_heff_2efmt_2elayout_2eitemsGo_24s708_24s710_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2eitemsGo_24s708_24s710_entry, 3, 0};

V g_heff_2efmt_2elayout_2eitemsGo_24s708_24s710(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_245 = heff_intLt(MK_INT(0LL), heff_dup(v_i_241));
    V v_t_2413;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2ecst_2efirstE(v_x_243));
      V v_x2_247 = ({ V a_0 = heff_get(heff_dup(v_t_246), LBL_ix); V b_1 = heff_get(heff_dup(v_env_240), LBL_lead); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
      V v_x1_249;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        heff_drop(v_x2_247);
        v_x1_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take(v_x2_247, 1ULL);
        v_x1_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2412;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_Nil: {
        heff_drop(v_x1_249);
        v_t_2412 = heff_get(v_t_246, LBL_blank);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_x1_249, 0);
        heff_take(v_x1_249, 1ULL);
        heff_drop(v_t_246);
        v_t_2412 = heff_get(v_x_2410, LBL_blank);
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2efmt_2elayout_2eblankLine_get());
        break;
      }
      case TAG_False: {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_t_245);
      v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2414 = (g_heff_2ecst_2efirstE(v_x_243));
    V v_t_2415 = (g_heff_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2417 = (g_heff_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2414, v_t_2415, heff_clo(g_heff_2efmt_2elayout_2eitemsGo_24s708_24s710_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2418 = (g_heff_2efmt_2elayout_2eitemsGo_24s708_24s710(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2419 = (g_std_2edoc_2e_3c_3e(v_t_2417, v_t_2418));
    V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2419));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2420));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2efmt_2elayout_2eitemsGo_24s708_24s710_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2eitemsGo_24s708_24s710(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2efmt_2elayout_2eitemsGo_24s708_24s710_lam0(V self, V *args) {
  V v_e_2416 = args[0];
  V v_x_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_stmtDoc), 2, (V[]){v_e_2416, v_x_243});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str41 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str42 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str43 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str45 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str47 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str48 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str49 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str50 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str52 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str53 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str54 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str55 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str56 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str57 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str58 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str59 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str60 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str61 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str62 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str63 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str64 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str65 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str66 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str67 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str68 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str69 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str70 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str71 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str72 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str73 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str74 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str75 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str76 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str77 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str78 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str79 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str80 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str81 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str82 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str83 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str84 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str85 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str86 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str87 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str88 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2elay_str89 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
V g_heff_2efmt_2elayout_2elay_lam2(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2efmt_2elayout_2elay_lam16(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam16, 2, 0};
V g_heff_2efmt_2elayout_2elay_lam17(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam17, 6, 0};
V g_heff_2efmt_2elayout_2elay_lam18(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam18, 8, 0};
V g_heff_2efmt_2elayout_2elay_lam19(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam19, 5, 0};
V g_heff_2efmt_2elayout_2elay_lam20(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam20, 3, 0};
V g_heff_2efmt_2elayout_2elay_lam22(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam23(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam24(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam25(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam26(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam27(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam28(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam29(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam30(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam31(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam32(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam33(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam34(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam35(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam36(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam37(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam38(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam39(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam40(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam41(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam42(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam43(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam44(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam45(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam46(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam47(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam48(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam49(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam50(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam51(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam52(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam53(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam54(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam55(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam56(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam57(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam58(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam59(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam60(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam61(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam62(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam63(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam64(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam65(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam66(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam67(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam68(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam69(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam70(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam71(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam21(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam21, 3, 0};
V g_heff_2efmt_2elayout_2elay_lam72(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam72_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam72, 3, 0};
V g_heff_2efmt_2elayout_2elay_lam73(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam73_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam73, 2, 0};
V g_heff_2efmt_2elayout_2elay_lam74(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam74_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam74, 3, 0};
V g_heff_2efmt_2elayout_2elay_lam75(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam75_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam75, 2, 0};
V g_heff_2efmt_2elayout_2elay_lam77(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam78(V self, V *args);
V g_heff_2efmt_2elayout_2elay_lam76(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam76_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam76, 3, 0};
V g_heff_2efmt_2elayout_2elay_lam79(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam79_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam79, 5, 0};
V g_heff_2efmt_2elayout_2elay_lam80(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam80_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam80, 2, 0};
V g_heff_2efmt_2elayout_2elay_lam81(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam81_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam81, 2, 0};
V g_heff_2efmt_2elayout_2elay_lam82(V self, V *args); static Clo g_heff_2efmt_2elayout_2elay_lam82_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2elay_lam82, 2, 0};

static V g_heff_2efmt_2elayout_2elay_val;
static int g_heff_2efmt_2elayout_2elay_st;
static V g_heff_2efmt_2elayout_2elay_init(void) {
  return heff_rec(16, shape_219_270_163_164_126_77_9_36_22_207_212_210_211_6_308_269, (V[]){((V)&g_heff_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam16_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam17_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam18_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam19_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam20_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam21_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam72_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam73_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam74_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam75_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam76_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam79_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam80_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam81_clo), ((V)&g_heff_2efmt_2elayout_2elay_lam82_clo)});
}
V g_heff_2efmt_2elayout_2elay_get(void) {
  if (g_heff_2efmt_2elayout_2elay_st == 2) return g_heff_2efmt_2elayout_2elay_val;
  if (g_heff_2efmt_2elayout_2elay_st == 1) heff_fail("defined by itself");
  g_heff_2efmt_2elayout_2elay_st = 1;
  g_heff_2efmt_2elayout_2elay_val = heff_tr(g_heff_2efmt_2elayout_2elay_init());
  g_heff_2efmt_2elayout_2elay_st = 2;
  return g_heff_2efmt_2elayout_2elay_val;
}
V g_heff_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_i_2410 = args[0];
  V v_k_249 = heff_dup(heff_env(self)[0]);
  V v_d_247 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_i_2411 = heff_intSub(v_k_249, v_i_2410);
  V v_t_2412 = heff_intEq(heff_dup(v_i_2411), MK_INT(0LL));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_i_2411);
    heff_drop(v_t_2412);
    return v_d_247;
  }
  case TAG_False: {
    heff_drop(v_t_2412);
    return heff_tag(TAG_Nest, 2, (V[]){v_i_2411, v_d_247});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_d_247 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tag(TAG_Nesting, 1, (V[]){heff_clo(g_heff_2efmt_2elayout_2elay_lam2, 1, 2, (V[]){v_k_249, v_d_247})});
}
V g_heff_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_comma_2440 = args[0];
  V v_e_2441 = args[1];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_a_2442 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2440));
  V v_b_2443 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_240, v_e_2441}));
  V v_t_2444 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str3)}), v_b_2443));
  V v_t_2445 = (g_std_2edoc_2e_3c_3e(v_a_2442, v_t_2444));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2445));
}
V g_heff_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_i_2455 = args[0];
  V v_k_2454 = heff_dup(heff_env(self)[0]);
  V v_d_2453 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_i_2456 = heff_intSub(v_k_2454, v_i_2455);
  V v_t_2457 = heff_intEq(heff_dup(v_i_2456), MK_INT(0LL));
  switch (heff_tag_of(v_t_2457)) {
  case TAG_True: {
    heff_drop(v_i_2456);
    heff_drop(v_t_2457);
    return v_d_2453;
  }
  case TAG_False: {
    heff_drop(v_t_2457);
    return heff_tag(TAG_Nest, 2, (V[]){v_i_2456, v_d_2453});
  }
  default: return heff_nomatch(v_t_2457);
  }
}
V g_heff_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_k_2454 = args[0];
  V v_d_2453 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tag(TAG_Nesting, 1, (V[]){heff_clo(g_heff_2efmt_2elayout_2elay_lam5, 1, 2, (V[]){v_k_2454, v_d_2453})});
}
V g_heff_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_comma_2471 = args[0];
  V v_f_2472 = args[1];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_a_2473 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2471));
  V v_d_2474 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_rhsField), 2, (V[]){v_env_240, v_f_2472}));
  V v_b_2475 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2474});
  V v_t_2476 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str5)}), v_b_2475));
  V v_t_2477 = (g_std_2edoc_2e_3c_3e(v_a_2473, v_t_2476));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2477));
}
V g_heff_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_i_2485 = args[0];
  V v_k_2484 = heff_dup(heff_env(self)[0]);
  V v_d_2483 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_i_2486 = heff_intSub(v_k_2484, v_i_2485);
  V v_t_2487 = heff_intEq(heff_dup(v_i_2486), MK_INT(0LL));
  switch (heff_tag_of(v_t_2487)) {
  case TAG_True: {
    heff_drop(v_i_2486);
    heff_drop(v_t_2487);
    return v_d_2483;
  }
  case TAG_False: {
    heff_drop(v_t_2487);
    return heff_tag(TAG_Nest, 2, (V[]){v_i_2486, v_d_2483});
  }
  default: return heff_nomatch(v_t_2487);
  }
}
V g_heff_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_k_2484 = args[0];
  V v_d_2483 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tag(TAG_Nesting, 1, (V[]){heff_clo(g_heff_2efmt_2elayout_2elay_lam8, 1, 2, (V[]){v_k_2484, v_d_2483})});
}
V g_heff_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_bar_24127 = args[0];
  V v_a_24128 = args[1];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_a_24129 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24127));
  V v_b_24130 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_240, v_a_24128}));
  V v_t_24131 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str10)}), v_b_24130));
  V v_t_24132 = (g_std_2edoc_2e_3c_3e(v_a_24129, v_t_24131));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24132));
}
V g_heff_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_i_24140 = args[0];
  V v_k_24139 = heff_dup(heff_env(self)[0]);
  V v_d_24138 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_i_24141 = heff_intSub(v_k_24139, v_i_24140);
  V v_t_24142 = heff_intEq(heff_dup(v_i_24141), MK_INT(0LL));
  switch (heff_tag_of(v_t_24142)) {
  case TAG_True: {
    heff_drop(v_i_24141);
    heff_drop(v_t_24142);
    return v_d_24138;
  }
  case TAG_False: {
    heff_drop(v_t_24142);
    return heff_tag(TAG_Nest, 2, (V[]){v_i_24141, v_d_24138});
  }
  default: return heff_nomatch(v_t_24142);
  }
}
V g_heff_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_k_24139 = args[0];
  V v_d_24138 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tag(TAG_Nesting, 1, (V[]){heff_clo(g_heff_2efmt_2elayout_2elay_lam11, 1, 2, (V[]){v_k_24139, v_d_24138})});
}
V g_heff_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_a_24148 = args[0];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24149 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_240, v_a_24148}));
  return (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str13)}), v_t_24149));
}
V g_heff_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_r_24165 = args[0];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  V v_rest_24163 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_24166 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opRhsDoc), 3, (V[]){v_env_240, v_rest_24163, v_r_24165}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24166));
}
V g_heff_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_i_24363 = args[0];
  V v_k_24362 = heff_dup(heff_env(self)[0]);
  V v_d_24361 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_i_24364 = heff_intSub(v_k_24362, v_i_24363);
  V v_t_24365 = heff_intEq(heff_dup(v_i_24364), MK_INT(0LL));
  switch (heff_tag_of(v_t_24365)) {
  case TAG_True: {
    heff_drop(v_i_24364);
    heff_drop(v_t_24365);
    return v_d_24361;
  }
  case TAG_False: {
    heff_drop(v_t_24365);
    return heff_tag(TAG_Nest, 2, (V[]){v_i_24364, v_d_24361});
  }
  default: return heff_nomatch(v_t_24365);
  }
}
V g_heff_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_k_24362 = args[0];
  V v_d_24361 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tag(TAG_Nesting, 1, (V[]){heff_clo(g_heff_2efmt_2elayout_2elay_lam15, 1, 2, (V[]){v_k_24362, v_d_24361})});
}
V g_heff_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  heff_drop(self);
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_242 = heff_field(v_e0_241, 0);
    heff_take(v_e0_241, 1ULL);
    return (g_heff_2efmt_2elayout_2etok(v_env_240, v_t_242));
  }
  case TAG_EParen: {
    V v_o_243 = heff_field(v_e0_241, 0);
    V v_e_244 = heff_field(v_e0_241, 1);
    V v_c_245 = heff_field(v_e0_241, 2);
    heff_take(v_e0_241, 7ULL);
    V v_t_246 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_243));
    V v_d_247 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_240), v_e_244}));
    V v_t_248 = (g_heff_2efmt_2elayout_2etok(v_env_240, v_c_245));
    V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Column, 1, (V[]){heff_clo(g_heff_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_d_247})}), v_t_248));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2413));
  }
  case TAG_Named: {
    V v_o_2414 = heff_field(v_e0_241, 0);
    V v_x_2415 = heff_field(v_e0_241, 1);
    V v_k_2416 = heff_field(v_e0_241, 2);
    V v_e_2417 = heff_field(v_e0_241, 3);
    V v_c_2418 = heff_field(v_e0_241, 4);
    heff_take(v_e0_241, 31ULL);
    V v_t_2419 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2414));
    V v_a_2420 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2415));
    V v_a_2421 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_2416));
    V v_b_2422 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_240), v_e_2417}));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str0)}), v_b_2422));
    V v_b_2424 = (g_std_2edoc_2e_3c_3e(v_a_2421, v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str1)}), v_b_2424));
    V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2425));
    V v_t_2427 = (g_heff_2efmt_2elayout_2etok(v_env_240, v_c_2418));
    V v_t_2428 = (g_std_2edoc_2e_3c_3e(v_t_2426, v_t_2427));
    return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2428));
  }
  case TAG_Tup: {
    V v_o_2429 = heff_field(v_e0_241, 0);
    V v_es_2430 = heff_field(v_e0_241, 1);
    V v_commas_2431 = heff_field(v_e0_241, 2);
    V v_c_2432 = heff_field(v_e0_241, 3);
    heff_take(v_e0_241, 15ULL);
    switch (heff_tag_of(v_es_2430)) {
    case TAG_Nil: {
      heff_drop(v_es_2430);
      heff_drop(v_commas_2431);
      V v_t_2433 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2434 = (g_heff_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      return (g_std_2edoc_2e_3c_3e(v_t_2433, v_t_2434));
    }
    case TAG_Cons: {
      V v_e1_2435 = heff_field(v_es_2430, 0);
      V v_more_2436 = heff_field(v_es_2430, 1);
      V v_ru_24es_2430_24Cons = heff_take_reuse(v_es_2430, 3ULL);
      V v_t_2437 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2438 = heff_tag_at(v_ru_24es_2430_24Cons, TAG_FlatAlt, 2, (V[]){heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str2)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_t_2439 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_240), v_e1_2435}));
      V v_ds_2446 = (g_prelude_2ezipWith(heff_clo(g_heff_2efmt_2elayout_2elay_lam3, 2, 1, (V[]){heff_dup(v_env_240)}), v_commas_2431, v_more_2436));
      V v_t_2447 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2446; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_2446); r_; });
      V v_t_2448 = (g_heff_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      V v_t_2449 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2448));
      V v_t_2450 = (g_std_2edoc_2e_3c_3e(v_t_2447, v_t_2449));
      V v_t_2451 = (g_std_2edoc_2e_3c_3e(v_t_2439, v_t_2450));
      V v_t_2452 = (g_std_2edoc_2e_3c_3e(v_t_2438, v_t_2451));
      V v_d_2453 = (g_std_2edoc_2e_3c_3e(v_t_2437, v_t_2452));
      return (g_std_2edoc_2egroup(heff_tag(TAG_Column, 1, (V[]){heff_clo(g_heff_2efmt_2elayout_2elay_lam4, 1, 1, (V[]){v_d_2453})})));
    }
    default: return heff_nomatch(v_es_2430);
    }
  }
  case TAG_Braces: {
    V v_o_2458 = heff_field(v_e0_241, 0);
    V v_fs_2459 = heff_field(v_e0_241, 1);
    V v_commas_2460 = heff_field(v_e0_241, 2);
    V v_c_2461 = heff_field(v_e0_241, 3);
    heff_take(v_e0_241, 15ULL);
    switch (heff_tag_of(v_fs_2459)) {
    case TAG_Nil: {
      heff_drop(v_fs_2459);
      heff_drop(v_commas_2460);
      V v_t_2462 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2458));
      V v_t_2463 = (g_heff_2efmt_2elayout_2etok(v_env_240, v_c_2461));
      return (g_std_2edoc_2e_3c_3e(v_t_2462, v_t_2463));
    }
    case TAG_Cons: {
      V v_f1_2464 = heff_field(v_fs_2459, 0);
      V v_more_2465 = heff_field(v_fs_2459, 1);
      V v_ru_24fs_2459_24Cons = heff_take_reuse(v_fs_2459, 3ULL);
      V v_a_2466 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2458));
      V v_d_2467 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_rhsField), 2, (V[]){heff_dup(v_env_240), v_f1_2464}));
      V v_b_2468 = heff_tag_at(v_ru_24fs_2459_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2467});
      V v_t_2469 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str4)}), v_b_2468));
      V v_t_2470 = (g_std_2edoc_2e_3c_3e(v_a_2466, v_t_2469));
      V v_ds_2478 = (g_prelude_2ezipWith(heff_clo(g_heff_2efmt_2elayout_2elay_lam6, 2, 1, (V[]){heff_dup(v_env_240)}), v_commas_2460, v_more_2465));
      V v_t_2479 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2478; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_2478); r_; });
      V v_t_2480 = (g_heff_2efmt_2elayout_2etok(v_env_240, v_c_2461));
      V v_t_2481 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_2480));
      V v_t_2482 = (g_std_2edoc_2e_3c_3e(v_t_2479, v_t_2481));
      V v_d_2483 = (g_std_2edoc_2e_3c_3e(v_t_2470, v_t_2482));
      return (g_std_2edoc_2egroup(heff_tag(TAG_Column, 1, (V[]){heff_clo(g_heff_2efmt_2elayout_2elay_lam7, 1, 1, (V[]){v_d_2483})})));
    }
    default: return heff_nomatch(v_fs_2459);
    }
  }
  case TAG_InstB: {
    V v_o_2488 = heff_field(v_e0_241, 0);
    V v_o2_2489 = heff_field(v_e0_241, 1);
    V v_d_2490 = heff_field(v_e0_241, 2);
    V v_c1_2491 = heff_field(v_e0_241, 3);
    V v_c_2492 = heff_field(v_e0_241, 4);
    heff_take(v_e0_241, 31ULL);
    V v_t_2493 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2488));
    V v_t_2494 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o2_2489));
    V v_t_2495 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_240), v_d_2490}));
    V v_t_2496 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c1_2491));
    V v_t_2497 = (g_heff_2efmt_2elayout_2etok(v_env_240, v_c_2492));
    V v_t_2498 = (g_std_2edoc_2e_3c_3e(v_t_2496, v_t_2497));
    V v_t_2499 = (g_std_2edoc_2e_3c_3e(v_t_2495, v_t_2498));
    V v_t_24100 = (g_std_2edoc_2e_3c_3e(v_t_2494, v_t_2499));
    return (g_std_2edoc_2e_3c_3e(v_t_2493, v_t_24100));
  }
  case TAG_EFSet: {
    V v_x_24101 = heff_field(v_e0_241, 0);
    V v_eq_24102 = heff_field(v_e0_241, 1);
    V v_e_24103 = heff_field(v_e0_241, 2);
    heff_take(v_e0_241, 7ULL);
    V v_a_24104 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24101));
    V v_b_24105 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24102));
    V v_t_24106 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str6)}), v_b_24105));
    V v_t_24107 = (g_std_2edoc_2e_3c_3e(v_a_24104, v_t_24106));
    V v_t_24108 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_rhsOf), 2, (V[]){v_env_240, v_e_24103}));
    return (g_std_2edoc_2e_3c_3e(v_t_24107, v_t_24108));
  }
  case TAG_Sum: {
    V v_kw_24109 = heff_field(v_e0_241, 0);
    V v_o_24110 = heff_field(v_e0_241, 1);
    V v_alts_24111 = heff_field(v_e0_241, 2);
    V v_bars_24112 = heff_field(v_e0_241, 3);
    V v_c_24113 = heff_field(v_e0_241, 4);
    heff_take(v_e0_241, 31ULL);
    switch (heff_tag_of(v_alts_24111)) {
    case TAG_Nil: {
      heff_drop(v_alts_24111);
      heff_drop(v_bars_24112);
      V v_a_24114 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24109));
      V v_a_24115 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24110));
      V v_b_24116 = (g_heff_2efmt_2elayout_2etok(v_env_240, v_c_24113));
      V v_t_24117 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str7)}), v_b_24116));
      V v_b_24118 = (g_std_2edoc_2e_3c_3e(v_a_24115, v_t_24117));
      V v_t_24119 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str8)}), v_b_24118));
      return (g_std_2edoc_2e_3c_3e(v_a_24114, v_t_24119));
    }
    case TAG_Cons: {
      V v_a1_24120 = heff_field(v_alts_24111, 0);
      V v_more_24121 = heff_field(v_alts_24111, 1);
      heff_take(v_alts_24111, 3ULL);
      V v_a_24122 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24109));
      V v_a_24123 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24110));
      V v_b_24124 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_240), v_a1_24120}));
      V v_t_24125 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str9)}), v_b_24124));
      V v_t_24126 = (g_std_2edoc_2e_3c_3e(v_a_24123, v_t_24125));
      V v_ds_24133 = (g_prelude_2ezipWith(heff_clo(g_heff_2efmt_2elayout_2elay_lam9, 2, 1, (V[]){heff_dup(v_env_240)}), v_bars_24112, v_more_24121));
      V v_a_24134 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24133; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24133); r_; });
      V v_b_24135 = (g_heff_2efmt_2elayout_2etok(v_env_240, v_c_24113));
      V v_t_24136 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str11)}), v_b_24135));
      V v_t_24137 = (g_std_2edoc_2e_3c_3e(v_a_24134, v_t_24136));
      V v_d_24138 = (g_std_2edoc_2e_3c_3e(v_t_24126, v_t_24137));
      V v_b_24143 = (g_std_2edoc_2egroup(heff_tag(TAG_Column, 1, (V[]){heff_clo(g_heff_2efmt_2elayout_2elay_lam10, 1, 1, (V[]){v_d_24138})})));
      V v_t_24144 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str12)}), v_b_24143));
      return (g_std_2edoc_2e_3c_3e(v_a_24122, v_t_24144));
    }
    default: return heff_nomatch(v_alts_24111);
    }
  }
  case TAG_ECon: {
    V v_c_24145 = heff_field(v_e0_241, 0);
    V v_args_24146 = heff_field(v_e0_241, 1);
    heff_take(v_e0_241, 3ULL);
    V v_t_24147 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_24145));
    V v_ds_24150 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam12, 1, 1, (V[]){v_env_240}), v_args_24146));
    V v_t_24151 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24150; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24150); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24147, v_t_24151));
  }
  case TAG_EField: {
    V v_e_24152 = heff_field(v_e0_241, 0);
    V v_f_24153 = heff_field(v_e0_241, 1);
    heff_take(v_e0_241, 3ULL);
    V v_t_24154 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_240), v_e_24152}));
    V v_t_24155 = (g_heff_2efmt_2elayout_2etok(v_env_240, v_f_24153));
    return (g_std_2edoc_2e_3c_3e(v_t_24154, v_t_24155));
  }
  case TAG_App: {
    V v_h_24156 = heff_field(v_e0_241, 0);
    V v_args_24157 = heff_field(v_e0_241, 1);
    heff_take(v_e0_241, 3ULL);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_appDoc), 3, (V[]){v_env_240, v_h_24156, v_args_24157});
  }
  case TAG_Op: {
    V v_a_24158 = heff_field(v_e0_241, 0);
    V v_op_24159 = heff_field(v_e0_241, 1);
    V v_b_24160 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24Op = heff_take_reuse(v_e0_241, 7ULL);
    V v_t_24161 = (g_heff_2efmt_2elayout_2echain(heff_tag_at(v_ru_24e0_241_24Op, TAG_Op, 3, (V[]){v_a_24158, v_op_24159, v_b_24160})));
    switch (heff_tag_of(v_t_24161)) {
    case TAG_MkChain: {
      V v_first_24162 = heff_field(v_t_24161, 0);
      V v_rest_24163 = heff_field(v_t_24161, 1);
      heff_take(v_t_24161, 3ULL);
      V v_t_24164 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_chainOperand), 3, (V[]){heff_dup(v_env_240), heff_dup(v_rest_24163), v_first_24162}));
      V v_ds_24167 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam13, 1, 2, (V[]){v_env_240, heff_dup(v_rest_24163)}), v_rest_24163));
      V v_t_24168 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24167; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24167); r_; });
      V v_t_24169 = (g_std_2edoc_2e_3c_3e(v_t_24164, v_t_24168));
      return (g_std_2edoc_2egroup(v_t_24169));
    }
    default: return heff_nomatch(v_t_24161);
    }
  }
  case TAG_Ops: {
    V v_a_24170 = heff_field(v_e0_241, 0);
    V v_rest_24171 = heff_field(v_e0_241, 1);
    heff_take(v_e0_241, 3ULL);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsChainDoc), 3, (V[]){v_env_240, v_a_24170, v_rest_24171});
  }
  case TAG_OpRhs: {
    V v_op_24172 = heff_field(v_e0_241, 0);
    V v_e_24173 = heff_field(v_e0_241, 1);
    heff_take(v_e0_241, 3ULL);
    V v_a_24174 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_op_24172));
    V v_b_24175 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_240, v_e_24173}));
    V v_t_24176 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str14)}), v_b_24175));
    return (g_std_2edoc_2e_3c_3e(v_a_24174, v_t_24176));
  }
  case TAG_Ann: {
    V v_e_24177 = heff_field(v_e0_241, 0);
    V v_cc_24178 = heff_field(v_e0_241, 1);
    V v_ty_24179 = heff_field(v_e0_241, 2);
    heff_take(v_e0_241, 7ULL);
    V v_a_24180 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_240), v_e_24177}));
    V v_b_24181 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24178));
    V v_t_24182 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str15)}), v_b_24181));
    V v_t_24183 = (g_std_2edoc_2e_3c_3e(v_a_24180, v_t_24182));
    V v_t_24184 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_240, v_ty_24179}));
    V v_d_24185 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24184));
    V v_t_24186 = (g_std_2edoc_2e_3c_3e(v_t_24183, heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24185})));
    return (g_std_2edoc_2egroup(v_t_24186));
  }
  case TAG_BVar: {
    V v_t_24187 = heff_field(v_e0_241, 0);
    heff_take(v_e0_241, 1ULL);
    return (g_heff_2efmt_2elayout_2etok(v_env_240, v_t_24187));
  }
  case TAG_BImp: {
    V v_o_24188 = heff_field(v_e0_241, 0);
    V v_x_24189 = heff_field(v_e0_241, 1);
    V v_c_24190 = heff_field(v_e0_241, 2);
    heff_take(v_e0_241, 7ULL);
    V v_t_24191 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24188));
    V v_t_24192 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24189));
    V v_t_24193 = (g_heff_2efmt_2elayout_2etok(v_env_240, v_c_24190));
    V v_t_24194 = (g_std_2edoc_2e_3c_3e(v_t_24192, v_t_24193));
    return (g_std_2edoc_2e_3c_3e(v_t_24191, v_t_24194));
  }
  case TAG_BAnn: {
    V v_o_24195 = heff_field(v_e0_241, 0);
    V v_x_24196 = heff_field(v_e0_241, 1);
    V v_cc_24197 = heff_field(v_e0_241, 2);
    V v_ty_24198 = heff_field(v_e0_241, 3);
    V v_c_24199 = heff_field(v_e0_241, 4);
    heff_take(v_e0_241, 31ULL);
    V v_t_24200 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24195));
    V v_a_24201 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24196));
    V v_a_24202 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24197));
    V v_b_24203 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_240), v_ty_24198}));
    V v_t_24204 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str16)}), v_b_24203));
    V v_b_24205 = (g_std_2edoc_2e_3c_3e(v_a_24202, v_t_24204));
    V v_t_24206 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str17)}), v_b_24205));
    V v_t_24207 = (g_std_2edoc_2e_3c_3e(v_a_24201, v_t_24206));
    V v_t_24208 = (g_heff_2efmt_2elayout_2etok(v_env_240, v_c_24199));
    V v_t_24209 = (g_std_2edoc_2e_3c_3e(v_t_24207, v_t_24208));
    return (g_std_2edoc_2e_3c_3e(v_t_24200, v_t_24209));
  }
  case TAG_Lam: {
    V v_bs_24210 = heff_field(v_e0_241, 0);
    V v_binders_24211 = heff_field(v_e0_241, 1);
    V v_arrow_24212 = heff_field(v_e0_241, 2);
    V v_body_24213 = heff_field(v_e0_241, 3);
    heff_take(v_e0_241, 15ULL);
    V v_t_24214 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bs_24210));
    V v_t_24215 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_binderDoc), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_24216 = (g_prelude_2emap(v_t_24215, v_binders_24211));
    V v_a_24217 = ({ V a_0 = v_t_24216; V r_ = (g_std_2edoc_2econcatWith_24s707(a_0)); heff_drop(v_t_24216); r_; });
    V v_b_24218 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24212));
    V v_t_24219 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str18)}), v_b_24218));
    V v_t_24220 = (g_std_2edoc_2e_3c_3e(v_a_24217, v_t_24219));
    V v_t_24304;
    switch (heff_tag_of(v_body_24213)) {
    case TAG_Atom: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_EParen: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_Named: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_Tup: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_Braces: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_InstB: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_EFSet: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_Sum: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_ECon: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_EField: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_App: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_Op: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_Ops: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_OpRhs: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_Ann: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_BVar: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_BImp: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_BAnn: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_Lam: {
      v_t_24304 = NTAG(TAG_True);
      break;
    }
    case TAG_Case: {
      v_t_24304 = NTAG(TAG_True);
      break;
    }
    case TAG_EAlt: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_If: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_Do: {
      v_t_24304 = NTAG(TAG_True);
      break;
    }
    case TAG_ESBind: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_body_24213);
    }
    V v_t_24308;
    switch (heff_tag_of(v_t_24304)) {
    case TAG_True: {
      heff_drop(v_t_24304);
      V v_t_24305 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_240, v_body_24213}));
      v_t_24308 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str19)}), v_t_24305));
      break;
    }
    case TAG_False: {
      heff_drop(v_t_24304);
      V v_t_24306 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_240, v_body_24213}));
      V v_d_24307 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24306));
      v_t_24308 = (g_std_2edoc_2egroup(heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24307})));
      break;
    }
    default: heff_nomatch(v_t_24304);
    }
    V v_t_24309 = (g_std_2edoc_2e_3c_3e(v_t_24220, v_t_24308));
    return (g_std_2edoc_2e_3c_3e(v_t_24214, v_t_24309));
  }
  case TAG_Case: {
    V v_kw_24310 = heff_field(v_e0_241, 0);
    V v_scrut_24311 = heff_field(v_e0_241, 1);
    V v_of2_24312 = heff_field(v_e0_241, 2);
    V v_alts_24313 = heff_field(v_e0_241, 3);
    heff_take(v_e0_241, 15ULL);
    V v_a_24314 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24310));
    V v_a_24315 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_240), v_scrut_24311}));
    V v_b_24316 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_of2_24312));
    V v_t_24317 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str20)}), v_b_24316));
    V v_b_24318 = (g_std_2edoc_2e_3c_3e(v_a_24315, v_t_24317));
    V v_t_24319 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str21)}), v_b_24318));
    V v_t_24320 = (g_std_2edoc_2e_3c_3e(v_a_24314, v_t_24319));
    V v_t_24321 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_alts_24313; V r_ = (g_heff_2efmt_2elayout_2eitemsGo_24s708_24s709(a_0, a_1, a_2)); heff_drop(v_alts_24313); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24320, v_t_24321));
  }
  case TAG_EAlt: {
    V v_p_24322 = heff_field(v_e0_241, 0);
    V v_arrow_24323 = heff_field(v_e0_241, 1);
    V v_body_24324 = heff_field(v_e0_241, 2);
    heff_take(v_e0_241, 7ULL);
    V v_a_24325 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24322; V r_ = (g_heff_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24322); r_; });
    V v_b_24326 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24323));
    V v_t_24327 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str22)}), v_b_24326));
    V v_t_24328 = (g_std_2edoc_2e_3c_3e(v_a_24325, v_t_24327));
    V v_t_24329 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_rhsOf), 2, (V[]){v_env_240, v_body_24324}));
    return (g_std_2edoc_2e_3c_3e(v_t_24328, v_t_24329));
  }
  case TAG_If: {
    V v_kw_24330 = heff_field(v_e0_241, 0);
    V v_c_24331 = heff_field(v_e0_241, 1);
    V v_th_24332 = heff_field(v_e0_241, 2);
    V v_a_24333 = heff_field(v_e0_241, 3);
    V v_el_24334 = heff_field(v_e0_241, 4);
    V v_b_24335 = heff_field(v_e0_241, 5);
    heff_take(v_e0_241, 63ULL);
    V v_t_24336 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_ifLink), 5, (V[]){heff_dup(v_env_240), v_kw_24330, v_c_24331, v_th_24332, v_a_24333}));
    V v_t_24337 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_elseOf), 3, (V[]){v_env_240, v_el_24334, v_b_24335}));
    V v_t_24338 = (g_std_2edoc_2e_3c_3e(v_t_24336, v_t_24337));
    return (g_std_2edoc_2egroup(v_t_24338));
  }
  case TAG_Do: {
    V v_kw_24339 = heff_field(v_e0_241, 0);
    V v_stmts_24340 = heff_field(v_e0_241, 1);
    heff_take(v_e0_241, 3ULL);
    V v_t_24341 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24339));
    V v_t_24342 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24340; V r_ = (g_heff_2efmt_2elayout_2eitemsGo_24s708_24s710(a_0, a_1, a_2)); heff_drop(v_stmts_24340); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24341, v_t_24342));
  }
  case TAG_ESBind: {
    V v_x_24343 = heff_field(v_e0_241, 0);
    V v_arrow_24344 = heff_field(v_e0_241, 1);
    V v_e_24345 = heff_field(v_e0_241, 2);
    heff_take(v_e0_241, 7ULL);
    V v_a_24346 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24343));
    V v_b_24347 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24344));
    V v_t_24348 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str23)}), v_b_24347));
    V v_t_24349 = (g_std_2edoc_2e_3c_3e(v_a_24346, v_t_24348));
    V v_t_24350 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_rhsOf), 2, (V[]){v_env_240, v_e_24345}));
    return (g_std_2edoc_2e_3c_3e(v_t_24349, v_t_24350));
  }
  case TAG_ELet: {
    V v_kw_24351 = heff_field(v_e0_241, 0);
    V v_p_24352 = heff_field(v_e0_241, 1);
    V v_ann_24353 = heff_field(v_e0_241, 2);
    V v_eq_24354 = heff_field(v_e0_241, 3);
    V v_e_24355 = heff_field(v_e0_241, 4);
    V v_body_24356 = heff_field(v_e0_241, 5);
    heff_take(v_e0_241, 63ULL);
    switch (heff_tag_of(v_body_24356)) {
    case TAG_Nothing: {
      heff_drop(v_body_24356);
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_letHead), 6, (V[]){v_env_240, v_kw_24351, v_p_24352, v_ann_24353, v_eq_24354, v_e_24355});
    }
    case TAG_Just: {
      V v_it1_24357 = heff_field(v_body_24356, 0);
      V v_ru_24body_24356_24Just = heff_take_reuse(v_body_24356, 1ULL);
      switch (heff_tag_of(v_it1_24357)) {
      case TAG_MkPair: {
        V v_i_24358 = heff_field(v_it1_24357, 0);
        V v_b_24359 = heff_field(v_it1_24357, 1);
        heff_take(v_it1_24357, 3ULL);
        V v_t_24360 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_letLink), 8, (V[]){v_env_240, v_kw_24351, v_p_24352, v_ann_24353, v_eq_24354, v_e_24355, v_i_24358, v_b_24359}));
        V v_d_24361 = (g_std_2edoc_2egroup(v_t_24360));
        return heff_tag_at(v_ru_24body_24356_24Just, TAG_Column, 1, (V[]){heff_clo(g_heff_2efmt_2elayout_2elay_lam14, 1, 1, (V[]){v_d_24361})});
      }
      default: return heff_nomatch(v_it1_24357);
      }
    }
    default: return heff_nomatch(v_body_24356);
    }
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_env_24366 = args[0];
  V v_e_24367 = args[1];
  heff_drop(self);
  V v_t_24451;
  switch (heff_tag_of(v_e_24367)) {
  case TAG_Atom: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_EParen: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_Named: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_Tup: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_Braces: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_InstB: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_EFSet: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_Sum: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_ECon: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_EField: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_App: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_Op: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_Ops: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_OpRhs: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_Ann: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_BVar: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_BImp: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_BAnn: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_Lam: {
    v_t_24451 = NTAG(TAG_True);
    break;
  }
  case TAG_Case: {
    v_t_24451 = NTAG(TAG_True);
    break;
  }
  case TAG_EAlt: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_If: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_Do: {
    v_t_24451 = NTAG(TAG_True);
    break;
  }
  case TAG_ESBind: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_24451 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_e_24367);
  }
  switch (heff_tag_of(v_t_24451)) {
  case TAG_True: {
    heff_drop(v_t_24451);
    V v_t_24452 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24366, v_e_24367}));
    return (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str24)}), v_t_24452));
  }
  case TAG_False: {
    heff_drop(v_t_24451);
    V v_t_24453 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24366, v_e_24367}));
    V v_t_24454 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24453));
    return (g_std_2edoc_2egroup(v_t_24454));
  }
  default: return heff_nomatch(v_t_24451);
  }
}
V g_heff_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_env_24455 = args[0];
  V v_kw_24456 = args[1];
  V v_p_24457 = args[2];
  V v_ann_24458 = args[3];
  V v_eq_24459 = args[4];
  V v_e_24460 = args[5];
  heff_drop(self);
  V v_a_24461 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24455), v_kw_24456));
  V v_b_24462 = ({ V a_0 = heff_dup(v_env_24455); V a_1 = v_p_24457; V r_ = (g_heff_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24457); r_; });
  V v_t_24463 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str25)}), v_b_24462));
  V v_t_24464 = (g_std_2edoc_2e_3c_3e(v_a_24461, v_t_24463));
  V v_a_24472;
  switch (heff_tag_of(v_ann_24458)) {
  case TAG_Nothing: {
    heff_drop(v_ann_24458);
    v_a_24472 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24465 = heff_field(v_ann_24458, 0);
    V v_ru_24ann_24458_24Just = heff_take_reuse(v_ann_24458, 1ULL);
    switch (heff_tag_of(v_it1_24465)) {
    case TAG_MkPair: {
      V v_cc_24466 = heff_field(v_it1_24465, 0);
      V v_ty_24467 = heff_field(v_it1_24465, 1);
      heff_take(v_it1_24465, 3ULL);
      V v_a_24468 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24455), v_cc_24466));
      V v_b_24469 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24455), v_ty_24467}));
      V v_t_24470 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24ann_24458_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str26)}), v_b_24469));
      V v_t_24471 = (g_std_2edoc_2e_3c_3e(v_a_24468, v_t_24470));
      v_a_24472 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str27)}), v_t_24471));
      break;
    }
    default: heff_nomatch(v_it1_24465);
    }
    break;
  }
  default: heff_nomatch(v_ann_24458);
  }
  V v_b_24473 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24455), v_eq_24459));
  V v_t_24474 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str28)}), v_b_24473));
  V v_t_24475 = (g_std_2edoc_2e_3c_3e(v_a_24472, v_t_24474));
  V v_t_24476 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_rhsOf), 2, (V[]){v_env_24455, v_e_24460}));
  V v_t_24477 = (g_std_2edoc_2e_3c_3e(v_t_24475, v_t_24476));
  return (g_std_2edoc_2e_3c_3e(v_t_24464, v_t_24477));
}
V g_heff_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_env_24478 = args[0];
  V v_kw_24479 = args[1];
  V v_p_24480 = args[2];
  V v_ann_24481 = args[3];
  V v_eq_24482 = args[4];
  V v_e_24483 = args[5];
  V v_i_24484 = args[6];
  V v_b_24485 = args[7];
  heff_drop(self);
  V v_d_24486 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_letHead), 6, (V[]){heff_dup(v_env_24478), v_kw_24479, v_p_24480, v_ann_24481, v_eq_24482, v_e_24483}));
  V v_a_24487 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24478), v_i_24484));
  V v_b_24574;
  switch (heff_tag_of(v_b_24485)) {
  case TAG_Atom: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_EParen: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_Named: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_Tup: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_Braces: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_InstB: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_EFSet: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_Sum: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_ECon: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_EField: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_App: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_Op: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_Ops: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_OpRhs: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_Ann: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_BVar: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_BImp: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_BAnn: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_Lam: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_Case: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_EAlt: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_If: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_Do: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_ESBind: {
    v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
    break;
  }
  case TAG_ELet: {
    V v_kw2_24565 = heff_dup(heff_field(v_b_24485, 0));
    V v_p2_24566 = heff_dup(heff_field(v_b_24485, 1));
    V v_ann2_24567 = heff_dup(heff_field(v_b_24485, 2));
    V v_eq2_24568 = heff_dup(heff_field(v_b_24485, 3));
    V v_e2_24569 = heff_dup(heff_field(v_b_24485, 4));
    V v_it6_24570 = heff_dup(heff_field(v_b_24485, 5));
    switch (heff_tag_of(v_it6_24570)) {
    case TAG_Nothing: {
      heff_drop(v_kw2_24565);
      heff_drop(v_p2_24566);
      heff_drop(v_ann2_24567);
      heff_drop(v_eq2_24568);
      heff_drop(v_e2_24569);
      heff_drop(v_it6_24570);
      v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24478, v_b_24485}));
      break;
    }
    case TAG_Just: {
      V v_it61_24571 = heff_field(v_it6_24570, 0);
      heff_take(v_it6_24570, 1ULL);
      heff_drop(v_b_24485);
      switch (heff_tag_of(v_it61_24571)) {
      case TAG_MkPair: {
        V v_i2_24572 = heff_field(v_it61_24571, 0);
        V v_b2_24573 = heff_field(v_it61_24571, 1);
        heff_take(v_it61_24571, 3ULL);
        v_b_24574 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_letLink), 8, (V[]){v_env_24478, v_kw2_24565, v_p2_24566, v_ann2_24567, v_eq2_24568, v_e2_24569, v_i2_24572, v_b2_24573}));
        break;
      }
      default: heff_nomatch(v_it61_24571);
      }
      break;
    }
    default: heff_nomatch(v_it6_24570);
    }
    break;
  }
  default: heff_nomatch(v_b_24485);
  }
  V v_t_24575 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str29)}), v_b_24574));
  V v_t_24576 = (g_std_2edoc_2e_3c_3e(v_a_24487, v_t_24575));
  V v_t_24577 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24576));
  return (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24486}), v_t_24577));
}
V g_heff_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_env_24578 = args[0];
  V v_kw_24579 = args[1];
  V v_c_24580 = args[2];
  V v_th_24581 = args[3];
  V v_a_24582 = args[4];
  heff_drop(self);
  V v_a_24583 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24578), v_kw_24579));
  V v_b_24584 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24578), v_c_24580}));
  V v_t_24585 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str30)}), v_b_24584));
  V v_t_24586 = (g_std_2edoc_2e_3c_3e(v_a_24583, v_t_24585));
  V v_a_24587 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24578), v_th_24581));
  V v_d_24588 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24578, v_a_24582}));
  V v_b_24589 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24588});
  V v_t_24590 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str31)}), v_b_24589));
  V v_t_24591 = (g_std_2edoc_2e_3c_3e(v_a_24587, v_t_24590));
  V v_d_24592 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24591));
  V v_t_24593 = (g_std_2edoc_2e_3c_3e(v_t_24586, heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24592})));
  return (g_std_2edoc_2egroup(v_t_24593));
}
V g_heff_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_env_24594 = args[0];
  V v_el_24595 = args[1];
  V v_b_24596 = args[2];
  heff_drop(self);
  switch (heff_tag_of(v_b_24596)) {
  case TAG_Atom: {
    V v_a_24598 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24599 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24600 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24599});
    V v_t_24601 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str32)}), v_b_24600));
    V v_t_24602 = (g_std_2edoc_2e_3c_3e(v_a_24598, v_t_24601));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24602));
  }
  case TAG_EParen: {
    V v_a_24606 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24607 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24608 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24607});
    V v_t_24609 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str33)}), v_b_24608));
    V v_t_24610 = (g_std_2edoc_2e_3c_3e(v_a_24606, v_t_24609));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24610));
  }
  case TAG_Named: {
    V v_a_24616 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24617 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24618 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24617});
    V v_t_24619 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str34)}), v_b_24618));
    V v_t_24620 = (g_std_2edoc_2e_3c_3e(v_a_24616, v_t_24619));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24620));
  }
  case TAG_Tup: {
    V v_a_24625 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24626 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24627 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24626});
    V v_t_24628 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str35)}), v_b_24627));
    V v_t_24629 = (g_std_2edoc_2e_3c_3e(v_a_24625, v_t_24628));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24629));
  }
  case TAG_Braces: {
    V v_a_24634 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24635 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24636 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24635});
    V v_t_24637 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str36)}), v_b_24636));
    V v_t_24638 = (g_std_2edoc_2e_3c_3e(v_a_24634, v_t_24637));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24638));
  }
  case TAG_InstB: {
    V v_a_24644 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24645 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24646 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24645});
    V v_t_24647 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str37)}), v_b_24646));
    V v_t_24648 = (g_std_2edoc_2e_3c_3e(v_a_24644, v_t_24647));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24648));
  }
  case TAG_EFSet: {
    V v_a_24652 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24653 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24654 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24653});
    V v_t_24655 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str38)}), v_b_24654));
    V v_t_24656 = (g_std_2edoc_2e_3c_3e(v_a_24652, v_t_24655));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24656));
  }
  case TAG_Sum: {
    V v_a_24662 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24663 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24664 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24663});
    V v_t_24665 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str39)}), v_b_24664));
    V v_t_24666 = (g_std_2edoc_2e_3c_3e(v_a_24662, v_t_24665));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24666));
  }
  case TAG_ECon: {
    V v_a_24669 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24670 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24671 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24670});
    V v_t_24672 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str40)}), v_b_24671));
    V v_t_24673 = (g_std_2edoc_2e_3c_3e(v_a_24669, v_t_24672));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24673));
  }
  case TAG_EField: {
    V v_a_24676 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24677 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24678 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24677});
    V v_t_24679 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str41)}), v_b_24678));
    V v_t_24680 = (g_std_2edoc_2e_3c_3e(v_a_24676, v_t_24679));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24680));
  }
  case TAG_App: {
    V v_a_24683 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24684 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24685 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24684});
    V v_t_24686 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str42)}), v_b_24685));
    V v_t_24687 = (g_std_2edoc_2e_3c_3e(v_a_24683, v_t_24686));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24687));
  }
  case TAG_Op: {
    V v_a_24691 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24692 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24693 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24692});
    V v_t_24694 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str43)}), v_b_24693));
    V v_t_24695 = (g_std_2edoc_2e_3c_3e(v_a_24691, v_t_24694));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24695));
  }
  case TAG_Ops: {
    V v_a_24698 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24699 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24700 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24699});
    V v_t_24701 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str44)}), v_b_24700));
    V v_t_24702 = (g_std_2edoc_2e_3c_3e(v_a_24698, v_t_24701));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24702));
  }
  case TAG_OpRhs: {
    V v_a_24705 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24706 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24707 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24706});
    V v_t_24708 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str45)}), v_b_24707));
    V v_t_24709 = (g_std_2edoc_2e_3c_3e(v_a_24705, v_t_24708));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24709));
  }
  case TAG_Ann: {
    V v_a_24713 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24714 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24715 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24714});
    V v_t_24716 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str46)}), v_b_24715));
    V v_t_24717 = (g_std_2edoc_2e_3c_3e(v_a_24713, v_t_24716));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24717));
  }
  case TAG_BVar: {
    V v_a_24719 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24720 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24721 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24720});
    V v_t_24722 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str47)}), v_b_24721));
    V v_t_24723 = (g_std_2edoc_2e_3c_3e(v_a_24719, v_t_24722));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24723));
  }
  case TAG_BImp: {
    V v_a_24727 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24728 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24729 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24728});
    V v_t_24730 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str48)}), v_b_24729));
    V v_t_24731 = (g_std_2edoc_2e_3c_3e(v_a_24727, v_t_24730));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24731));
  }
  case TAG_BAnn: {
    V v_a_24737 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24738 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24739 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24738});
    V v_t_24740 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str49)}), v_b_24739));
    V v_t_24741 = (g_std_2edoc_2e_3c_3e(v_a_24737, v_t_24740));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24741));
  }
  case TAG_Lam: {
    V v_a_24746 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24747 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24748 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24747});
    V v_t_24749 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str50)}), v_b_24748));
    V v_t_24750 = (g_std_2edoc_2e_3c_3e(v_a_24746, v_t_24749));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24750));
  }
  case TAG_Case: {
    V v_a_24755 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24756 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24757 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24756});
    V v_t_24758 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str51)}), v_b_24757));
    V v_t_24759 = (g_std_2edoc_2e_3c_3e(v_a_24755, v_t_24758));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24759));
  }
  case TAG_EAlt: {
    V v_a_24763 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24764 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24765 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24764});
    V v_t_24766 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str52)}), v_b_24765));
    V v_t_24767 = (g_std_2edoc_2e_3c_3e(v_a_24763, v_t_24766));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24767));
  }
  case TAG_If: {
    V v_kw_24768 = heff_field(v_b_24596, 0);
    V v_c_24769 = heff_field(v_b_24596, 1);
    V v_th_24770 = heff_field(v_b_24596, 2);
    V v_a_24771 = heff_field(v_b_24596, 3);
    V v_el2_24772 = heff_field(v_b_24596, 4);
    V v_b2_24773 = heff_field(v_b_24596, 5);
    heff_take(v_b_24596, 63ULL);
    V v_a_24774 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_b_24775 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_ifLink), 5, (V[]){heff_dup(v_env_24594), v_kw_24768, v_c_24769, v_th_24770, v_a_24771}));
    V v_t_24776 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str53)}), v_b_24775));
    V v_t_24777 = (g_std_2edoc_2e_3c_3e(v_a_24774, v_t_24776));
    V v_t_24778 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_elseOf), 3, (V[]){v_env_24594, v_el2_24772, v_b2_24773}));
    V v_t_24779 = (g_std_2edoc_2e_3c_3e(v_t_24777, v_t_24778));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24779));
  }
  case TAG_Do: {
    V v_a_24782 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24783 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24784 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24783});
    V v_t_24785 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str54)}), v_b_24784));
    V v_t_24786 = (g_std_2edoc_2e_3c_3e(v_a_24782, v_t_24785));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24786));
  }
  case TAG_ESBind: {
    V v_a_24790 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24791 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24792 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24791});
    V v_t_24793 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str55)}), v_b_24792));
    V v_t_24794 = (g_std_2edoc_2e_3c_3e(v_a_24790, v_t_24793));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24794));
  }
  case TAG_ELet: {
    V v_a_24801 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24594), v_el_24595));
    V v_d_24802 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24594, v_b_24596}));
    V v_b_24803 = heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24802});
    V v_t_24804 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str56)}), v_b_24803));
    V v_t_24805 = (g_std_2edoc_2e_3c_3e(v_a_24801, v_t_24804));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24805));
  }
  default: return heff_nomatch(v_b_24596);
  }
}
V g_heff_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_a_24820 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24821 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24820}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24821));
}
V g_heff_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_a_24829 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24830 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24829}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24830));
}
V g_heff_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_a_24839 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24840 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24839}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24840));
}
V g_heff_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_a_24852 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24853 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24852}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24853));
}
V g_heff_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_a_24864 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24865 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24864}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24865));
}
V g_heff_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_a_24873 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24874 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24873}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24874));
}
V g_heff_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_a_24884 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24885 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24884}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24885));
}
V g_heff_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_a_24893 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24894 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24893}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24894));
}
V g_heff_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_a_24904 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24905 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24904}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24905));
}
V g_heff_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_a_24913 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24914 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24913}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24914));
}
V g_heff_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_a_24925 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24926 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24925}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24926));
}
V g_heff_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_a_24934 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24935 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24934}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24935));
}
V g_heff_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_a_24944 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24945 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24944}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24945));
}
V g_heff_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_a_24953 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24954 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24953}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24954));
}
V g_heff_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_a_24965 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24966 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24965}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24966));
}
V g_heff_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_a_24974 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24975 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24974}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24975));
}
V g_heff_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_a_24983 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24984 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24983}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24984));
}
V g_heff_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_a_24992 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_24993 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_24992}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24993));
}
V g_heff_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_a_241001 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241002 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241001}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241002));
}
V g_heff_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_a_241010 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241011 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241010}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241011));
}
V g_heff_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_a_241019 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241020 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241019}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241020));
}
V g_heff_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_a_241028 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241029 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241028}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241029));
}
V g_heff_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_a_241038 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241039 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241038}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241039));
}
V g_heff_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_a_241047 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241048 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241047}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241048));
}
V g_heff_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_a_241056 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241057 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241056}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241057));
}
V g_heff_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_a_241065 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241066 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241065}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241066));
}
V g_heff_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_a_241074 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241075 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241074}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241075));
}
V g_heff_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_a_241083 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241084 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241083}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241084));
}
V g_heff_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_a_241093 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241094 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241093}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241094));
}
V g_heff_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_a_241102 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241103 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241102}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241103));
}
V g_heff_2efmt_2elayout_2elay_lam52(V self, V *args) {
  V v_a_241110 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241111 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241110}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241111));
}
V g_heff_2efmt_2elayout_2elay_lam53(V self, V *args) {
  V v_a_241119 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241120 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241119}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241120));
}
V g_heff_2efmt_2elayout_2elay_lam54(V self, V *args) {
  V v_a_241129 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241130 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241129}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241130));
}
V g_heff_2efmt_2elayout_2elay_lam55(V self, V *args) {
  V v_a_241138 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241139 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241138}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241139));
}
V g_heff_2efmt_2elayout_2elay_lam56(V self, V *args) {
  V v_a_241150 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241151 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241150}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241151));
}
V g_heff_2efmt_2elayout_2elay_lam57(V self, V *args) {
  V v_a_241159 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241160 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241159}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241160));
}
V g_heff_2efmt_2elayout_2elay_lam58(V self, V *args) {
  V v_a_241170 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241171 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241170}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241171));
}
V g_heff_2efmt_2elayout_2elay_lam59(V self, V *args) {
  V v_a_241179 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241180 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241179}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241180));
}
V g_heff_2efmt_2elayout_2elay_lam60(V self, V *args) {
  V v_a_241190 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241191 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241190}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241191));
}
V g_heff_2efmt_2elayout_2elay_lam61(V self, V *args) {
  V v_a_241199 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241200 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241199}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241200));
}
V g_heff_2efmt_2elayout_2elay_lam62(V self, V *args) {
  V v_a_241209 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241210 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241209}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241210));
}
V g_heff_2efmt_2elayout_2elay_lam63(V self, V *args) {
  V v_a_241218 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241219 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241218}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241219));
}
V g_heff_2efmt_2elayout_2elay_lam64(V self, V *args) {
  V v_a_241231 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241232 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241231}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241232));
}
V g_heff_2efmt_2elayout_2elay_lam65(V self, V *args) {
  V v_a_241240 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241241 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241240}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241241));
}
V g_heff_2efmt_2elayout_2elay_lam66(V self, V *args) {
  V v_a_241249 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241250 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241249}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241250));
}
V g_heff_2efmt_2elayout_2elay_lam67(V self, V *args) {
  V v_a_241258 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241259 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241258}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241259));
}
V g_heff_2efmt_2elayout_2elay_lam68(V self, V *args) {
  V v_a_241268 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241269 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241268}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241269));
}
V g_heff_2efmt_2elayout_2elay_lam69(V self, V *args) {
  V v_a_241277 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241278 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241277}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241278));
}
V g_heff_2efmt_2elayout_2elay_lam70(V self, V *args) {
  V v_a_241290 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241291 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241290}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241291));
}
V g_heff_2efmt_2elayout_2elay_lam71(V self, V *args) {
  V v_a_241299 = args[0];
  V v_env_24806 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241300 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_a_241299}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241300));
}
V g_heff_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_env_24806 = args[0];
  V v_h_24807 = args[1];
  V v_args_24808 = args[2];
  heff_drop(self);
  V v_x1_24809 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_args_24808)));
  V v_t_24813;
  switch (heff_tag_of(v_x1_24809)) {
  case TAG_Nil: {
    heff_drop(v_x1_24809);
    v_t_24813 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_24810 = heff_field(v_x1_24809, 0);
    V v_rev_24811 = heff_field(v_x1_24809, 1);
    V v_ru_24x1_24809_24Cons = heff_take_reuse(v_x1_24809, 3ULL);
    V v_t_24812 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_rev_24811));
    v_t_24813 = heff_tag(TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x1_24809_24Cons, TAG_MkPair, 2, (V[]){v_t_24812, v_x_24810})});
    break;
  }
  default: heff_nomatch(v_x1_24809);
  }
  switch (heff_tag_of(v_t_24813)) {
  case TAG_Nothing: {
    heff_drop(v_args_24808);
    heff_drop(v_t_24813);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_h_24807});
  }
  case TAG_Just: {
    V v_pr_24814 = heff_field(v_t_24813, 0);
    V v_ru_24t_24813_24Just = heff_take_reuse(v_t_24813, 1ULL);
    switch (heff_tag_of(v_pr_24814)) {
    case TAG_MkPair: {
      V v_init2_24815 = heff_field(v_pr_24814, 0);
      V v_lastA_24816 = heff_field(v_pr_24814, 1);
      V v_ru_24pr_24814_24MkPair = heff_take_reuse(v_pr_24814, 3ULL);
      switch (heff_tag_of(v_lastA_24816)) {
      case TAG_Atom: {
        V v_t_24818 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_24818)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_24818);
          V v_t_24819 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24822 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam22, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_24823 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24822; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24822); r_; });
          V v_t_24824 = (g_std_2edoc_2e_3c_3e(v_t_24819, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24823})));
          V v_a_24825 = (g_std_2edoc_2egroup(v_t_24824));
          V v_b_24826 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_24827 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str57)}), v_b_24826));
          return (g_std_2edoc_2e_3c_3e(v_a_24825, v_t_24827));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_24818);
          V v_t_24828 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24831 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam23, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_24832 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24831; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24831); r_; });
          V v_t_24833 = (g_std_2edoc_2e_3c_3e(v_t_24828, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24832})));
          return (g_std_2edoc_2egroup(v_t_24833));
        }
        default: return heff_nomatch(v_t_24818);
        }
      }
      case TAG_EParen: {
        V v_o_24834 = heff_field(v_lastA_24816, 0);
        V v_e_24835 = heff_field(v_lastA_24816, 1);
        V v_c_24836 = heff_field(v_lastA_24816, 2);
        heff_take(v_lastA_24816, 7ULL);
        V v_t_24837 = (g_heff_2efmt_2elayout_2ehangs(v_e_24835));
        switch (heff_tag_of(v_t_24837)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_24837);
          V v_t_24838 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24841 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam24, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_24842 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24841; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24841); r_; });
          V v_t_24843 = (g_std_2edoc_2e_3c_3e(v_t_24838, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24842})));
          V v_a_24844 = (g_std_2edoc_2egroup(v_t_24843));
          V v_b_24845 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_24806), v_o_24834));
          V v_t_24846 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str58)}), v_b_24845));
          V v_t_24847 = (g_std_2edoc_2e_3c_3e(v_a_24844, v_t_24846));
          V v_t_24848 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_e_24835}));
          V v_t_24849 = (g_heff_2efmt_2elayout_2etok(v_env_24806, v_c_24836));
          V v_t_24850 = (g_std_2edoc_2e_3c_3e(v_t_24848, v_t_24849));
          return (g_std_2edoc_2e_3c_3e(v_t_24847, v_t_24850));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_o_24834);
          heff_drop(v_e_24835);
          heff_drop(v_c_24836);
          heff_drop(v_t_24837);
          V v_t_24851 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24854 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam25, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_24855 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24854; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24854); r_; });
          V v_t_24856 = (g_std_2edoc_2e_3c_3e(v_t_24851, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24855})));
          return (g_std_2edoc_2egroup(v_t_24856));
        }
        default: return heff_nomatch(v_t_24837);
        }
      }
      case TAG_Named: {
        V v_t_24862 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_24862)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_24862);
          V v_t_24863 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24866 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam26, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_24867 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24866; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24866); r_; });
          V v_t_24868 = (g_std_2edoc_2e_3c_3e(v_t_24863, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24867})));
          V v_a_24869 = (g_std_2edoc_2egroup(v_t_24868));
          V v_b_24870 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_24871 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str59)}), v_b_24870));
          return (g_std_2edoc_2e_3c_3e(v_a_24869, v_t_24871));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_24862);
          V v_t_24872 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24875 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam27, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_24876 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24875; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24875); r_; });
          V v_t_24877 = (g_std_2edoc_2e_3c_3e(v_t_24872, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24876})));
          return (g_std_2edoc_2egroup(v_t_24877));
        }
        default: return heff_nomatch(v_t_24862);
        }
      }
      case TAG_Tup: {
        V v_t_24882 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_24882)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_24882);
          V v_t_24883 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24886 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam28, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_24887 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24886; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24886); r_; });
          V v_t_24888 = (g_std_2edoc_2e_3c_3e(v_t_24883, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24887})));
          V v_a_24889 = (g_std_2edoc_2egroup(v_t_24888));
          V v_b_24890 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_24891 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str60)}), v_b_24890));
          return (g_std_2edoc_2e_3c_3e(v_a_24889, v_t_24891));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_24882);
          V v_t_24892 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24895 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam29, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_24896 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24895; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24895); r_; });
          V v_t_24897 = (g_std_2edoc_2e_3c_3e(v_t_24892, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24896})));
          return (g_std_2edoc_2egroup(v_t_24897));
        }
        default: return heff_nomatch(v_t_24882);
        }
      }
      case TAG_Braces: {
        V v_t_24902 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_24902)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_24902);
          V v_t_24903 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24906 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam30, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_24907 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24906; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24906); r_; });
          V v_t_24908 = (g_std_2edoc_2e_3c_3e(v_t_24903, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24907})));
          V v_a_24909 = (g_std_2edoc_2egroup(v_t_24908));
          V v_b_24910 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_24911 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str61)}), v_b_24910));
          return (g_std_2edoc_2e_3c_3e(v_a_24909, v_t_24911));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_24902);
          V v_t_24912 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24915 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam31, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_24916 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24915; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24915); r_; });
          V v_t_24917 = (g_std_2edoc_2e_3c_3e(v_t_24912, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24916})));
          return (g_std_2edoc_2egroup(v_t_24917));
        }
        default: return heff_nomatch(v_t_24902);
        }
      }
      case TAG_InstB: {
        V v_t_24923 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_24923)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_24923);
          V v_t_24924 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24927 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam32, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_24928 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24927; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24927); r_; });
          V v_t_24929 = (g_std_2edoc_2e_3c_3e(v_t_24924, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24928})));
          V v_a_24930 = (g_std_2edoc_2egroup(v_t_24929));
          V v_b_24931 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_24932 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str62)}), v_b_24931));
          return (g_std_2edoc_2e_3c_3e(v_a_24930, v_t_24932));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_24923);
          V v_t_24933 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24936 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam33, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_24937 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24936; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24936); r_; });
          V v_t_24938 = (g_std_2edoc_2e_3c_3e(v_t_24933, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24937})));
          return (g_std_2edoc_2egroup(v_t_24938));
        }
        default: return heff_nomatch(v_t_24923);
        }
      }
      case TAG_EFSet: {
        V v_t_24942 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_24942)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_24942);
          V v_t_24943 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24946 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam34, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_24947 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24946; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24946); r_; });
          V v_t_24948 = (g_std_2edoc_2e_3c_3e(v_t_24943, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24947})));
          V v_a_24949 = (g_std_2edoc_2egroup(v_t_24948));
          V v_b_24950 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_24951 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str63)}), v_b_24950));
          return (g_std_2edoc_2e_3c_3e(v_a_24949, v_t_24951));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_24942);
          V v_t_24952 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24955 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam35, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_24956 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24955; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24955); r_; });
          V v_t_24957 = (g_std_2edoc_2e_3c_3e(v_t_24952, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24956})));
          return (g_std_2edoc_2egroup(v_t_24957));
        }
        default: return heff_nomatch(v_t_24942);
        }
      }
      case TAG_Sum: {
        V v_t_24963 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_24963)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_24963);
          V v_t_24964 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24967 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam36, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_24968 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24967; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24967); r_; });
          V v_t_24969 = (g_std_2edoc_2e_3c_3e(v_t_24964, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24968})));
          V v_a_24970 = (g_std_2edoc_2egroup(v_t_24969));
          V v_b_24971 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_24972 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str64)}), v_b_24971));
          return (g_std_2edoc_2e_3c_3e(v_a_24970, v_t_24972));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_24963);
          V v_t_24973 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24976 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam37, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_24977 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24976; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24976); r_; });
          V v_t_24978 = (g_std_2edoc_2e_3c_3e(v_t_24973, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24977})));
          return (g_std_2edoc_2egroup(v_t_24978));
        }
        default: return heff_nomatch(v_t_24963);
        }
      }
      case TAG_ECon: {
        V v_t_24981 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_24981)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_24981);
          V v_t_24982 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24985 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam38, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_24986 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24985; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24985); r_; });
          V v_t_24987 = (g_std_2edoc_2e_3c_3e(v_t_24982, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24986})));
          V v_a_24988 = (g_std_2edoc_2egroup(v_t_24987));
          V v_b_24989 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_24990 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str65)}), v_b_24989));
          return (g_std_2edoc_2e_3c_3e(v_a_24988, v_t_24990));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_24981);
          V v_t_24991 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_24994 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam39, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_24995 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24994; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_24994); r_; });
          V v_t_24996 = (g_std_2edoc_2e_3c_3e(v_t_24991, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24995})));
          return (g_std_2edoc_2egroup(v_t_24996));
        }
        default: return heff_nomatch(v_t_24981);
        }
      }
      case TAG_EField: {
        V v_t_24999 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_24999)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_24999);
          V v_t_241000 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241003 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam40, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241004 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241003; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241003); r_; });
          V v_t_241005 = (g_std_2edoc_2e_3c_3e(v_t_241000, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241004})));
          V v_a_241006 = (g_std_2edoc_2egroup(v_t_241005));
          V v_b_241007 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241008 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str66)}), v_b_241007));
          return (g_std_2edoc_2e_3c_3e(v_a_241006, v_t_241008));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_24999);
          V v_t_241009 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241012 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam41, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241013 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241012; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241012); r_; });
          V v_t_241014 = (g_std_2edoc_2e_3c_3e(v_t_241009, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241013})));
          return (g_std_2edoc_2egroup(v_t_241014));
        }
        default: return heff_nomatch(v_t_24999);
        }
      }
      case TAG_App: {
        V v_t_241017 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241017)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241017);
          V v_t_241018 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241021 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam42, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241022 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241021; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241021); r_; });
          V v_t_241023 = (g_std_2edoc_2e_3c_3e(v_t_241018, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241022})));
          V v_a_241024 = (g_std_2edoc_2egroup(v_t_241023));
          V v_b_241025 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241026 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str67)}), v_b_241025));
          return (g_std_2edoc_2e_3c_3e(v_a_241024, v_t_241026));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241017);
          V v_t_241027 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241030 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam43, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241031 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241030; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241030); r_; });
          V v_t_241032 = (g_std_2edoc_2e_3c_3e(v_t_241027, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241031})));
          return (g_std_2edoc_2egroup(v_t_241032));
        }
        default: return heff_nomatch(v_t_241017);
        }
      }
      case TAG_Op: {
        V v_t_241036 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241036)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241036);
          V v_t_241037 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241040 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam44, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241041 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241040; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241040); r_; });
          V v_t_241042 = (g_std_2edoc_2e_3c_3e(v_t_241037, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241041})));
          V v_a_241043 = (g_std_2edoc_2egroup(v_t_241042));
          V v_b_241044 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241045 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str68)}), v_b_241044));
          return (g_std_2edoc_2e_3c_3e(v_a_241043, v_t_241045));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241036);
          V v_t_241046 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241049 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam45, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241050 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241049; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241049); r_; });
          V v_t_241051 = (g_std_2edoc_2e_3c_3e(v_t_241046, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241050})));
          return (g_std_2edoc_2egroup(v_t_241051));
        }
        default: return heff_nomatch(v_t_241036);
        }
      }
      case TAG_Ops: {
        V v_t_241054 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241054)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241054);
          V v_t_241055 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241058 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam46, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241059 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241058; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241058); r_; });
          V v_t_241060 = (g_std_2edoc_2e_3c_3e(v_t_241055, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241059})));
          V v_a_241061 = (g_std_2edoc_2egroup(v_t_241060));
          V v_b_241062 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241063 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str69)}), v_b_241062));
          return (g_std_2edoc_2e_3c_3e(v_a_241061, v_t_241063));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241054);
          V v_t_241064 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241067 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam47, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241068 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241067; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241067); r_; });
          V v_t_241069 = (g_std_2edoc_2e_3c_3e(v_t_241064, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241068})));
          return (g_std_2edoc_2egroup(v_t_241069));
        }
        default: return heff_nomatch(v_t_241054);
        }
      }
      case TAG_OpRhs: {
        V v_t_241072 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241072)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241072);
          V v_t_241073 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241076 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam48, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241077 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241076; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241076); r_; });
          V v_t_241078 = (g_std_2edoc_2e_3c_3e(v_t_241073, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241077})));
          V v_a_241079 = (g_std_2edoc_2egroup(v_t_241078));
          V v_b_241080 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241081 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str70)}), v_b_241080));
          return (g_std_2edoc_2e_3c_3e(v_a_241079, v_t_241081));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241072);
          V v_t_241082 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241085 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam49, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241086 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241085; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241085); r_; });
          V v_t_241087 = (g_std_2edoc_2e_3c_3e(v_t_241082, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241086})));
          return (g_std_2edoc_2egroup(v_t_241087));
        }
        default: return heff_nomatch(v_t_241072);
        }
      }
      case TAG_Ann: {
        V v_t_241091 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241091)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241091);
          V v_t_241092 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241095 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam50, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241096 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241095; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241095); r_; });
          V v_t_241097 = (g_std_2edoc_2e_3c_3e(v_t_241092, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241096})));
          V v_a_241098 = (g_std_2edoc_2egroup(v_t_241097));
          V v_b_241099 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241100 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str71)}), v_b_241099));
          return (g_std_2edoc_2e_3c_3e(v_a_241098, v_t_241100));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241091);
          V v_t_241101 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241104 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam51, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241105 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241104; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241104); r_; });
          V v_t_241106 = (g_std_2edoc_2e_3c_3e(v_t_241101, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241105})));
          return (g_std_2edoc_2egroup(v_t_241106));
        }
        default: return heff_nomatch(v_t_241091);
        }
      }
      case TAG_BVar: {
        V v_t_241108 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241108)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241108);
          V v_t_241109 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241112 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam52, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241113 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241112; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241112); r_; });
          V v_t_241114 = (g_std_2edoc_2e_3c_3e(v_t_241109, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241113})));
          V v_a_241115 = (g_std_2edoc_2egroup(v_t_241114));
          V v_b_241116 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241117 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str72)}), v_b_241116));
          return (g_std_2edoc_2e_3c_3e(v_a_241115, v_t_241117));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241108);
          V v_t_241118 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241121 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam53, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241122 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241121; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241121); r_; });
          V v_t_241123 = (g_std_2edoc_2e_3c_3e(v_t_241118, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241122})));
          return (g_std_2edoc_2egroup(v_t_241123));
        }
        default: return heff_nomatch(v_t_241108);
        }
      }
      case TAG_BImp: {
        V v_t_241127 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241127)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241127);
          V v_t_241128 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241131 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam54, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241132 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241131; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241131); r_; });
          V v_t_241133 = (g_std_2edoc_2e_3c_3e(v_t_241128, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241132})));
          V v_a_241134 = (g_std_2edoc_2egroup(v_t_241133));
          V v_b_241135 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241136 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str73)}), v_b_241135));
          return (g_std_2edoc_2e_3c_3e(v_a_241134, v_t_241136));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241127);
          V v_t_241137 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241140 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam55, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241141 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241140; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241140); r_; });
          V v_t_241142 = (g_std_2edoc_2e_3c_3e(v_t_241137, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241141})));
          return (g_std_2edoc_2egroup(v_t_241142));
        }
        default: return heff_nomatch(v_t_241127);
        }
      }
      case TAG_BAnn: {
        V v_t_241148 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241148)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241148);
          V v_t_241149 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241152 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam56, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241153 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241152; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241152); r_; });
          V v_t_241154 = (g_std_2edoc_2e_3c_3e(v_t_241149, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241153})));
          V v_a_241155 = (g_std_2edoc_2egroup(v_t_241154));
          V v_b_241156 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241157 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str74)}), v_b_241156));
          return (g_std_2edoc_2e_3c_3e(v_a_241155, v_t_241157));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241148);
          V v_t_241158 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241161 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam57, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241162 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241161; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241161); r_; });
          V v_t_241163 = (g_std_2edoc_2e_3c_3e(v_t_241158, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241162})));
          return (g_std_2edoc_2egroup(v_t_241163));
        }
        default: return heff_nomatch(v_t_241148);
        }
      }
      case TAG_Lam: {
        V v_t_241168 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241168)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241168);
          V v_t_241169 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241172 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam58, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241173 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241172; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241172); r_; });
          V v_t_241174 = (g_std_2edoc_2e_3c_3e(v_t_241169, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241173})));
          V v_a_241175 = (g_std_2edoc_2egroup(v_t_241174));
          V v_b_241176 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241177 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str75)}), v_b_241176));
          return (g_std_2edoc_2e_3c_3e(v_a_241175, v_t_241177));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241168);
          V v_t_241178 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241181 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam59, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241182 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241181; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241181); r_; });
          V v_t_241183 = (g_std_2edoc_2e_3c_3e(v_t_241178, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241182})));
          return (g_std_2edoc_2egroup(v_t_241183));
        }
        default: return heff_nomatch(v_t_241168);
        }
      }
      case TAG_Case: {
        V v_t_241188 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241188)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241188);
          V v_t_241189 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241192 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam60, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241193 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241192; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241192); r_; });
          V v_t_241194 = (g_std_2edoc_2e_3c_3e(v_t_241189, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241193})));
          V v_a_241195 = (g_std_2edoc_2egroup(v_t_241194));
          V v_b_241196 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241197 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str76)}), v_b_241196));
          return (g_std_2edoc_2e_3c_3e(v_a_241195, v_t_241197));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241188);
          V v_t_241198 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241201 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam61, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241202 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241201; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241201); r_; });
          V v_t_241203 = (g_std_2edoc_2e_3c_3e(v_t_241198, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241202})));
          return (g_std_2edoc_2egroup(v_t_241203));
        }
        default: return heff_nomatch(v_t_241188);
        }
      }
      case TAG_EAlt: {
        V v_t_241207 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241207)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241207);
          V v_t_241208 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241211 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam62, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241212 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241211; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241211); r_; });
          V v_t_241213 = (g_std_2edoc_2e_3c_3e(v_t_241208, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241212})));
          V v_a_241214 = (g_std_2edoc_2egroup(v_t_241213));
          V v_b_241215 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241216 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str77)}), v_b_241215));
          return (g_std_2edoc_2e_3c_3e(v_a_241214, v_t_241216));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241207);
          V v_t_241217 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241220 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam63, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241221 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241220; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241220); r_; });
          V v_t_241222 = (g_std_2edoc_2e_3c_3e(v_t_241217, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241221})));
          return (g_std_2edoc_2egroup(v_t_241222));
        }
        default: return heff_nomatch(v_t_241207);
        }
      }
      case TAG_If: {
        V v_t_241229 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241229)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241229);
          V v_t_241230 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241233 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam64, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241234 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241233; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241233); r_; });
          V v_t_241235 = (g_std_2edoc_2e_3c_3e(v_t_241230, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241234})));
          V v_a_241236 = (g_std_2edoc_2egroup(v_t_241235));
          V v_b_241237 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241238 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str78)}), v_b_241237));
          return (g_std_2edoc_2e_3c_3e(v_a_241236, v_t_241238));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241229);
          V v_t_241239 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241242 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam65, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241243 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241242; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241242); r_; });
          V v_t_241244 = (g_std_2edoc_2e_3c_3e(v_t_241239, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241243})));
          return (g_std_2edoc_2egroup(v_t_241244));
        }
        default: return heff_nomatch(v_t_241229);
        }
      }
      case TAG_Do: {
        V v_t_241247 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241247)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241247);
          V v_t_241248 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241251 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam66, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241252 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241251; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241251); r_; });
          V v_t_241253 = (g_std_2edoc_2e_3c_3e(v_t_241248, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241252})));
          V v_a_241254 = (g_std_2edoc_2egroup(v_t_241253));
          V v_b_241255 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241256 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str79)}), v_b_241255));
          return (g_std_2edoc_2e_3c_3e(v_a_241254, v_t_241256));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241247);
          V v_t_241257 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241260 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam67, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241261 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241260; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241260); r_; });
          V v_t_241262 = (g_std_2edoc_2e_3c_3e(v_t_241257, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241261})));
          return (g_std_2edoc_2egroup(v_t_241262));
        }
        default: return heff_nomatch(v_t_241247);
        }
      }
      case TAG_ESBind: {
        V v_t_241266 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241266)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241266);
          V v_t_241267 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241270 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam68, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241271 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241270; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241270); r_; });
          V v_t_241272 = (g_std_2edoc_2e_3c_3e(v_t_241267, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241271})));
          V v_a_241273 = (g_std_2edoc_2egroup(v_t_241272));
          V v_b_241274 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241275 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str80)}), v_b_241274));
          return (g_std_2edoc_2e_3c_3e(v_a_241273, v_t_241275));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241266);
          V v_t_241276 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241279 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam69, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241280 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241279; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241279); r_; });
          V v_t_241281 = (g_std_2edoc_2e_3c_3e(v_t_241276, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241280})));
          return (g_std_2edoc_2egroup(v_t_241281));
        }
        default: return heff_nomatch(v_t_241266);
        }
      }
      case TAG_ELet: {
        V v_t_241288 = (g_heff_2efmt_2elayout_2ehangs(v_lastA_24816));
        switch (heff_tag_of(v_t_241288)) {
        case TAG_True: {
          heff_drop(v_args_24808);
          heff_drop(v_t_241288);
          V v_t_241289 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241292 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam70, 1, 1, (V[]){heff_dup(v_env_24806)}), v_init2_24815));
          V v_d_241293 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241292; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241292); r_; });
          V v_t_241294 = (g_std_2edoc_2e_3c_3e(v_t_241289, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241293})));
          V v_a_241295 = (g_std_2edoc_2egroup(v_t_241294));
          V v_b_241296 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_24806, v_lastA_24816}));
          V v_t_241297 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24t_24813_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str81)}), v_b_241296));
          return (g_std_2edoc_2e_3c_3e(v_a_241295, v_t_241297));
        }
        case TAG_False: {
          heff_drop(v_ru_24t_24813_24Just);
          heff_drop(v_init2_24815);
          heff_drop(v_lastA_24816);
          heff_drop(v_t_241288);
          V v_t_241298 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_24806), v_h_24807}));
          V v_ds_241301 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam71, 1, 1, (V[]){v_env_24806}), v_args_24808));
          V v_d_241302 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241301; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241301); r_; });
          V v_t_241303 = (g_std_2edoc_2e_3c_3e(v_t_241298, heff_tag_at(v_ru_24pr_24814_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241302})));
          return (g_std_2edoc_2egroup(v_t_241303));
        }
        default: return heff_nomatch(v_t_241288);
        }
      }
      default: return heff_nomatch(v_lastA_24816);
      }
    }
    default: return heff_nomatch(v_pr_24814);
    }
  }
  default: return heff_nomatch(v_t_24813);
  }
}
V g_heff_2efmt_2elayout_2elay_lam72(V self, V *args) {
  V v_env_241304 = args[0];
  V v_rest_241305 = args[1];
  V v_e_241306 = args[2];
  heff_drop(self);
  switch (heff_tag_of(v_e_241306)) {
  case TAG_Atom: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_EParen: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_Named: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_Tup: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_Braces: {
    V v_o_241320 = heff_field(v_e_241306, 0);
    V v_fs_241321 = heff_field(v_e_241306, 1);
    V v_commas_241322 = heff_field(v_e_241306, 2);
    V v_c_241323 = heff_field(v_e_241306, 3);
    heff_take(v_e_241306, 15ULL);
    switch (heff_tag_of(v_fs_241321)) {
    case TAG_Nil: {
      heff_drop(v_rest_241305);
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, heff_tag(TAG_Braces, 4, (V[]){v_o_241320, v_fs_241321, v_commas_241322, v_c_241323})});
    }
    case TAG_Cons: {
      V v_d_241324 = heff_dup(heff_field(v_fs_241321, 0));
      V v_rest2_241325 = heff_dup(heff_field(v_fs_241321, 1));
      V v_t_241328;
      switch (heff_tag_of(v_rest2_241325)) {
      case TAG_Nil: {
        heff_drop(v_rest2_241325);
        v_t_241328 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take(v_rest2_241325, 0ULL);
        v_t_241328 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_rest2_241325);
      }
      switch (heff_tag_of(v_t_241328)) {
      case TAG_True: {
        heff_drop(v_t_241328);
        V v_t_241329 = ({ V a_0 = v_rest_241305; V r_ = (g_heff_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_241305); r_; });
        switch (heff_tag_of(v_t_241329)) {
        case TAG_True: {
          heff_drop(v_t_241329);
          V v_x1_241413;
          switch (heff_tag_of(v_d_241324)) {
          case TAG_Atom: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_EParen: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_Named: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_Tup: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_Braces: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_InstB: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_EFSet: {
            v_x1_241413 = NTAG(TAG_True);
            break;
          }
          case TAG_Sum: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_ECon: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_EField: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_App: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_Op: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_Ops: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_OpRhs: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_Ann: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_BVar: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_BImp: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_BAnn: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_Lam: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_Case: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_EAlt: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_If: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_Do: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_ESBind: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          case TAG_ELet: {
            v_x1_241413 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_d_241324);
          }
          switch (heff_tag_of(v_x1_241413)) {
          case TAG_True: {
            heff_drop(v_d_241324);
            heff_drop(v_x1_241413);
            return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, heff_tag(TAG_Braces, 4, (V[]){v_o_241320, v_fs_241321, v_commas_241322, v_c_241323})});
          }
          case TAG_False: {
            heff_drop(v_x1_241413);
            switch (heff_tag_of(v_commas_241322)) {
            case TAG_Nil: {
              heff_drop(v_fs_241321);
              heff_drop(v_commas_241322);
              V v_t_241414 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_241304), v_o_241320));
              V v_t_241415 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_241304), v_d_241324}));
              V v_t_241416 = (g_heff_2efmt_2elayout_2etok(v_env_241304, v_c_241323));
              V v_t_241417 = (g_std_2edoc_2e_3c_3e(v_t_241415, v_t_241416));
              return (g_std_2edoc_2e_3c_3e(v_t_241414, v_t_241417));
            }
            case TAG_Cons: {
              heff_drop(v_d_241324);
              return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, heff_tag(TAG_Braces, 4, (V[]){v_o_241320, v_fs_241321, v_commas_241322, v_c_241323})});
            }
            default: return heff_nomatch(v_commas_241322);
            }
          }
          default: return heff_nomatch(v_x1_241413);
          }
        }
        case TAG_False: {
          heff_drop(v_d_241324);
          heff_drop(v_t_241329);
          return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, heff_tag(TAG_Braces, 4, (V[]){v_o_241320, v_fs_241321, v_commas_241322, v_c_241323})});
        }
        default: return heff_nomatch(v_t_241329);
        }
      }
      case TAG_False: {
        heff_drop(v_rest_241305);
        heff_drop(v_d_241324);
        heff_drop(v_t_241328);
        return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, heff_tag(TAG_Braces, 4, (V[]){v_o_241320, v_fs_241321, v_commas_241322, v_c_241323})});
      }
      default: return heff_nomatch(v_t_241328);
      }
    }
    default: return heff_nomatch(v_fs_241321);
    }
  }
  case TAG_InstB: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_EFSet: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_Sum: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_ECon: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_EField: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_App: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_Op: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_Ops: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_OpRhs: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_Ann: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_BVar: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_BImp: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_BAnn: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_Lam: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_Case: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_EAlt: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_If: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_Do: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_ESBind: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  case TAG_ELet: {
    heff_drop(v_rest_241305);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241304, v_e_241306});
  }
  default: return heff_nomatch(v_e_241306);
  }
}
V g_heff_2efmt_2elayout_2elay_lam73(V self, V *args) {
  V v_env_241486 = args[0];
  V v_b_241487 = args[1];
  heff_drop(self);
  switch (heff_tag_of(v_b_241487)) {
  case TAG_Atom: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_EParen: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_Named: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_Tup: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_Braces: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_InstB: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_EFSet: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_Sum: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_ECon: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_EField: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_App: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_Op: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_Ops: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_OpRhs: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_Ann: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_BVar: {
    V v_t_241534 = heff_field(v_b_241487, 0);
    heff_take(v_b_241487, 1ULL);
    return (g_heff_2efmt_2elayout_2etok(v_env_241486, v_t_241534));
  }
  case TAG_BImp: {
    V v_o_241535 = heff_field(v_b_241487, 0);
    V v_x_241536 = heff_field(v_b_241487, 1);
    V v_c_241537 = heff_field(v_b_241487, 2);
    heff_take(v_b_241487, 7ULL);
    V v_t_241538 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_241486), v_o_241535));
    V v_t_241539 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_241486), v_x_241536));
    V v_t_241540 = (g_heff_2efmt_2elayout_2etok(v_env_241486, v_c_241537));
    V v_t_241541 = (g_std_2edoc_2e_3c_3e(v_t_241539, v_t_241540));
    return (g_std_2edoc_2e_3c_3e(v_t_241538, v_t_241541));
  }
  case TAG_BAnn: {
    V v_o_241542 = heff_field(v_b_241487, 0);
    V v_x_241543 = heff_field(v_b_241487, 1);
    V v_cc_241544 = heff_field(v_b_241487, 2);
    V v_ty_241545 = heff_field(v_b_241487, 3);
    V v_c_241546 = heff_field(v_b_241487, 4);
    heff_take(v_b_241487, 31ULL);
    V v_t_241547 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_241486), v_o_241542));
    V v_a_241548 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_241486), v_x_241543));
    V v_a_241549 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_241486), v_cc_241544));
    V v_b_241550 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_241486), v_ty_241545}));
    V v_t_241551 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str82)}), v_b_241550));
    V v_b_241552 = (g_std_2edoc_2e_3c_3e(v_a_241549, v_t_241551));
    V v_t_241553 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str83)}), v_b_241552));
    V v_t_241554 = (g_std_2edoc_2e_3c_3e(v_a_241548, v_t_241553));
    V v_t_241555 = (g_heff_2efmt_2elayout_2etok(v_env_241486, v_c_241546));
    V v_t_241556 = (g_std_2edoc_2e_3c_3e(v_t_241554, v_t_241555));
    return (g_std_2edoc_2e_3c_3e(v_t_241547, v_t_241556));
  }
  case TAG_Lam: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_Case: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_EAlt: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_If: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_Do: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_ESBind: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  case TAG_ELet: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241486, v_b_241487});
  }
  default: return heff_nomatch(v_b_241487);
  }
}
V g_heff_2efmt_2elayout_2elay_lam74(V self, V *args) {
  V v_env_241585 = args[0];
  V v_rest_241586 = args[1];
  V v_r_241587 = args[2];
  heff_drop(self);
  switch (heff_tag_of(v_r_241587)) {
  case TAG_Atom: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_EParen: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_Named: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_Tup: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_Braces: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_InstB: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_EFSet: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_Sum: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_ECon: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_EField: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_App: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_Op: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_Ops: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_OpRhs: {
    V v_op_241629 = heff_field(v_r_241587, 0);
    V v_e_241630 = heff_field(v_r_241587, 1);
    heff_take(v_r_241587, 3ULL);
    V v_a_241631 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_241585), v_op_241629));
    V v_b_241632 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_chainOperand), 3, (V[]){v_env_241585, v_rest_241586, v_e_241630}));
    V v_t_241633 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str84)}), v_b_241632));
    return (g_std_2edoc_2e_3c_3e(v_a_241631, v_t_241633));
  }
  case TAG_Ann: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_BVar: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_BImp: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_BAnn: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_Lam: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_Case: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_EAlt: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_If: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_Do: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_ESBind: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  case TAG_ELet: {
    heff_drop(v_rest_241586);
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241585, v_r_241587});
  }
  default: return heff_nomatch(v_r_241587);
  }
}
V g_heff_2efmt_2elayout_2elay_lam75(V self, V *args) {
  V v_env_241674 = args[0];
  V v_r_241675 = args[1];
  heff_drop(self);
  switch (heff_tag_of(v_r_241675)) {
  case TAG_Atom: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_EParen: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_Named: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_Tup: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_Braces: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_InstB: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_EFSet: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_Sum: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_ECon: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_EField: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_App: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_Op: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_Ops: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_OpRhs: {
    V v_op_241717 = heff_field(v_r_241675, 0);
    V v_e_241718 = heff_field(v_r_241675, 1);
    heff_take(v_r_241675, 3ULL);
    V v_a_241719 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_241674), v_op_241717));
    V v_b_241720 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_e_241718}));
    V v_t_241721 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str85)}), v_b_241720));
    return (g_std_2edoc_2e_3c_3e(v_a_241719, v_t_241721));
  }
  case TAG_Ann: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_BVar: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_BImp: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_BAnn: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_Lam: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_Case: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_EAlt: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_If: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_Do: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_ESBind: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  case TAG_ELet: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241674, v_r_241675});
  }
  default: return heff_nomatch(v_r_241675);
  }
}
V g_heff_2efmt_2elayout_2elay_lam77(V self, V *args) {
  V v_r_241772 = args[0];
  V v_env_241762 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241773 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsRhsDoc), 2, (V[]){v_env_241762, v_r_241772}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241773));
}
V g_heff_2efmt_2elayout_2elay_lam78(V self, V *args) {
  V v_r_241781 = args[0];
  V v_env_241762 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_241782 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsRhsDoc), 2, (V[]){v_env_241762, v_r_241781}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241782));
}
V g_heff_2efmt_2elayout_2elay_lam76(V self, V *args) {
  V v_env_241762 = args[0];
  V v_first_241763 = args[1];
  V v_rest_241764 = args[2];
  heff_drop(self);
  V v_f_241765 = heff_get(heff_dup(v_env_241762), LBL_fix);
  V v_it_241766 = (g_heff_2efmt_2elayout_2eopsOf(heff_dup(v_f_241765), heff_dup(v_rest_241764)));
  V v_t_241770;
  switch (heff_tag_of(v_it_241766)) {
  case TAG_Nothing: {
    heff_drop(v_f_241765);
    heff_drop(v_it_241766);
    v_t_241770 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_241767 = heff_field(v_it_241766, 0);
    heff_take(v_it_241766, 1ULL);
    switch (heff_tag_of(v_it1_241767)) {
    case TAG_Nil: {
      heff_drop(v_f_241765);
      heff_drop(v_it1_241767);
      v_t_241770 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_o_241768 = heff_field(v_it1_241767, 0);
      V v_os_241769 = heff_field(v_it1_241767, 1);
      heff_take(v_it1_241767, 3ULL);
      v_t_241770 = ({ V a_0 = v_f_241765; V a_1 = v_o_241768; V a_2 = v_os_241769; V r_ = (g_heff_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_os_241769); r_; });
      break;
    }
    default: heff_nomatch(v_it1_241767);
    }
    break;
  }
  default: heff_nomatch(v_it_241766);
  }
  switch (heff_tag_of(v_t_241770)) {
  case TAG_Nothing: {
    heff_drop(v_t_241770);
    V v_t_241771 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_241762), v_first_241763}));
    V v_ds_241774 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam77, 1, 1, (V[]){v_env_241762}), v_rest_241764));
    V v_t_241775 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241774; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241774); r_; });
    V v_t_241776 = (g_std_2edoc_2e_3c_3e(v_t_241771, v_t_241775));
    return (g_std_2edoc_2egroup(v_t_241776));
  }
  case TAG_Just: {
    V v_m_241777 = heff_field(v_t_241770, 0);
    heff_take(v_t_241770, 1ULL);
    V v_t_241778 = heff_tr(heff_apply(((V)&g_heff_2efmt_2elayout_2eisSameIn_clo), 2, (V[]){heff_get(heff_dup(v_env_241762), LBL_fix), heff_dup(v_m_241777)}));
    V v_t_241779 = (g_prelude_2eall(v_t_241778, v_rest_241764));
    switch (heff_tag_of(v_t_241779)) {
    case TAG_True: {
      heff_drop(v_m_241777);
      heff_drop(v_t_241779);
      V v_t_241780 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_241762), v_first_241763}));
      V v_ds_241783 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2elay_lam78, 1, 1, (V[]){v_env_241762}), v_rest_241764));
      V v_t_241784 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241783; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_241783); r_; });
      V v_t_241785 = (g_std_2edoc_2e_3c_3e(v_t_241780, v_t_241784));
      return (g_std_2edoc_2egroup(v_t_241785));
    }
    case TAG_False: {
      heff_drop(v_t_241779);
      V v_t_241786 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241762, v_m_241777, v_first_241763, NTAG(TAG_Nil), v_rest_241764}));
      return (g_std_2edoc_2egroup(v_t_241786));
    }
    default: return heff_nomatch(v_t_241779);
    }
  }
  default: return heff_nomatch(v_t_241770);
  }
}
V g_heff_2efmt_2elayout_2elay_lam79(V self, V *args) {
  V v_env_241787 = args[0];
  V v_m_241788 = args[1];
  V v_f_241789 = args[2];
  V v_acc_241790 = args[3];
  V v_rs_241791 = args[4];
  heff_drop(self);
  switch (heff_tag_of(v_rs_241791)) {
  case TAG_Nil: {
    heff_drop(v_m_241788);
    heff_drop(v_rs_241791);
    V v_t_241792 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241790));
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsChainDoc), 3, (V[]){v_env_241787, v_f_241789, v_t_241792});
  }
  case TAG_Cons: {
    V v_r_241793 = heff_field(v_rs_241791, 0);
    V v_rest2_241794 = heff_field(v_rs_241791, 1);
    heff_take(v_rs_241791, 3ULL);
    switch (heff_tag_of(v_r_241793)) {
    case TAG_Atom: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_EParen: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_Named: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_Tup: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_Braces: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_InstB: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_EFSet: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_Sum: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_ECon: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_EField: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_App: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_Op: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_Ops: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_OpRhs: {
      V v_op_241836 = heff_dup(heff_field(v_r_241793, 0));
      V v_e_241837 = heff_dup(heff_field(v_r_241793, 1));
      V v_t_241838 = (g_heff_2efixity_2erelate(heff_get(heff_dup(v_env_241787), LBL_fix), heff_dup(v_m_241788), heff_get(heff_dup(v_op_241836), LBL_text)));
      V v_t_241841;
      switch (heff_tag_of(v_t_241838)) {
      case TAG_Tighter: {
        heff_drop(v_t_241838);
        v_t_241841 = NTAG(TAG_False);
        break;
      }
      case TAG_Looser: {
        heff_drop(v_t_241838);
        v_t_241841 = NTAG(TAG_False);
        break;
      }
      case TAG_Same: {
        heff_take(v_t_241838, 0ULL);
        v_t_241841 = NTAG(TAG_True);
        break;
      }
      case TAG_Unrelated: {
        heff_drop(v_t_241838);
        v_t_241841 = NTAG(TAG_False);
        break;
      }
      case TAG_Undeclared: {
        heff_take(v_t_241838, 0ULL);
        v_t_241841 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_241838);
      }
      switch (heff_tag_of(v_t_241841)) {
      case TAG_True: {
        heff_drop(v_r_241793);
        heff_drop(v_t_241841);
        V v_t_241842 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241790));
        V v_t_241843 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsChainDoc), 3, (V[]){heff_dup(v_env_241787), v_f_241789, v_t_241842}));
        V v_a_241844 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_241787), v_op_241836));
        V v_b_241845 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_e_241837, NTAG(TAG_Nil), v_rest2_241794}));
        V v_t_241846 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str86)}), v_b_241845));
        V v_t_241847 = (g_std_2edoc_2e_3c_3e(v_a_241844, v_t_241846));
        V v_t_241848 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241847));
        return (g_std_2edoc_2e_3c_3e(v_t_241843, v_t_241848));
      }
      case TAG_False: {
        heff_drop(v_op_241836);
        heff_drop(v_e_241837);
        heff_drop(v_t_241841);
        return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
      }
      default: return heff_nomatch(v_t_241841);
      }
    }
    case TAG_Ann: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_BVar: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_BImp: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_BAnn: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_Lam: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_Case: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_EAlt: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_If: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_Do: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_ESBind: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    case TAG_ELet: {
      return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_opsCut), 5, (V[]){v_env_241787, v_m_241788, v_f_241789, heff_tag(TAG_Cons, 2, (V[]){v_r_241793, v_acc_241790}), v_rest2_241794});
    }
    default: return heff_nomatch(v_r_241793);
    }
  }
  default: return heff_nomatch(v_rs_241791);
  }
}
V g_heff_2efmt_2elayout_2elay_lam80(V self, V *args) {
  V v_env_241889 = args[0];
  V v_a_241890 = args[1];
  heff_drop(self);
  switch (heff_tag_of(v_a_241890)) {
  case TAG_Atom: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_EParen: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_Named: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_Tup: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_Braces: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_InstB: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_EFSet: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_Sum: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_ECon: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_EField: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_App: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_Op: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_Ops: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_OpRhs: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_Ann: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_BVar: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_BImp: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_BAnn: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_Lam: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_Case: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_EAlt: {
    V v_p_241954 = heff_field(v_a_241890, 0);
    V v_arrow_241955 = heff_field(v_a_241890, 1);
    V v_body_241956 = heff_field(v_a_241890, 2);
    heff_take(v_a_241890, 7ULL);
    V v_a_241957 = ({ V a_0 = heff_dup(v_env_241889); V a_1 = v_p_241954; V r_ = (g_heff_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_241954); r_; });
    V v_b_241958 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_241889), v_arrow_241955));
    V v_t_241959 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str87)}), v_b_241958));
    V v_t_241960 = (g_std_2edoc_2e_3c_3e(v_a_241957, v_t_241959));
    V v_t_241961 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_rhsOf), 2, (V[]){v_env_241889, v_body_241956}));
    return (g_std_2edoc_2e_3c_3e(v_t_241960, v_t_241961));
  }
  case TAG_If: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_Do: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_ESBind: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  case TAG_ELet: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241889, v_a_241890});
  }
  default: return heff_nomatch(v_a_241890);
  }
}
V g_heff_2efmt_2elayout_2elay_lam81(V self, V *args) {
  V v_env_241979 = args[0];
  V v_s_241980 = args[1];
  heff_drop(self);
  switch (heff_tag_of(v_s_241980)) {
  case TAG_Atom: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_EParen: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_Named: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_Tup: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_Braces: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_InstB: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_EFSet: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_Sum: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_ECon: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_EField: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_App: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_Op: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_Ops: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_OpRhs: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_Ann: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_BVar: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_BImp: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_BAnn: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_Lam: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_Case: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_EAlt: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_If: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_Do: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  case TAG_ESBind: {
    V v_x_242055 = heff_field(v_s_241980, 0);
    V v_arrow_242056 = heff_field(v_s_241980, 1);
    V v_e_242057 = heff_field(v_s_241980, 2);
    heff_take(v_s_241980, 7ULL);
    V v_a_242058 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_241979), v_x_242055));
    V v_b_242059 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_241979), v_arrow_242056));
    V v_t_242060 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str88)}), v_b_242059));
    V v_t_242061 = (g_std_2edoc_2e_3c_3e(v_a_242058, v_t_242060));
    V v_t_242062 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_rhsOf), 2, (V[]){v_env_241979, v_e_242057}));
    return (g_std_2edoc_2e_3c_3e(v_t_242061, v_t_242062));
  }
  case TAG_ELet: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_241979, v_s_241980});
  }
  default: return heff_nomatch(v_s_241980);
  }
}
V g_heff_2efmt_2elayout_2elay_lam82(V self, V *args) {
  V v_env_242069 = args[0];
  V v_f_242070 = args[1];
  heff_drop(self);
  switch (heff_tag_of(v_f_242070)) {
  case TAG_Atom: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_EParen: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_Named: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_Tup: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_Braces: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_InstB: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_EFSet: {
    V v_x_242093 = heff_field(v_f_242070, 0);
    V v_eq_242094 = heff_field(v_f_242070, 1);
    V v_e_242095 = heff_field(v_f_242070, 2);
    heff_take(v_f_242070, 7ULL);
    V v_a_242096 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_242069), v_x_242093));
    V v_b_242097 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_242069), v_eq_242094));
    V v_t_242098 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2elay_str89)}), v_b_242097));
    V v_t_242099 = (g_std_2edoc_2e_3c_3e(v_a_242096, v_t_242098));
    V v_t_242100 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_rhsOf), 2, (V[]){v_env_242069, v_e_242095}));
    return (g_std_2edoc_2e_3c_3e(v_t_242099, v_t_242100));
  }
  case TAG_Sum: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_ECon: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_EField: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_App: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_Op: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_Ops: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_OpRhs: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_Ann: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_BVar: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_BImp: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_BAnn: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_Lam: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_Case: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_EAlt: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_If: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_Do: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_ESBind: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  case TAG_ELet: {
    return heff_tail(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_242069, v_f_242070});
  }
  default: return heff_nomatch(v_f_242070);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2esig_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
V g_heff_2efmt_2elayout_2esig_lam1(V self, V *args);
V g_heff_2efmt_2elayout_2esig_lam0(V self, V *args);
Clo g_heff_2efmt_2elayout_2esig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2esig_entry, 3, 0};

V g_heff_2efmt_2elayout_2esig(V v_env_240, V v_cc_241, V v_ty_242) {
top: ;
  V v_a_243 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_241));
  V v_b_244 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_240, v_ty_242}));
  V v_t_245 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2esig_str0)}), v_b_244));
  V v_d_246 = (g_std_2edoc_2e_3c_3e(v_a_243, v_t_245));
  return heff_tag(TAG_Column, 1, (V[]){heff_clo(g_heff_2efmt_2elayout_2esig_lam0, 1, 1, (V[]){v_d_246})});
}
V g_heff_2efmt_2elayout_2esig_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elayout_2esig(a[0], a[1], a[2]);
}
V g_heff_2efmt_2elayout_2esig_lam1(V self, V *args) {
  V v_i_248 = args[0];
  V v_k_247 = heff_dup(heff_env(self)[0]);
  V v_d_246 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_i_249 = heff_intSub(v_k_247, v_i_248);
  V v_t_2410 = heff_intEq(heff_dup(v_i_249), MK_INT(0LL));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_i_249);
    heff_drop(v_t_2410);
    return v_d_246;
  }
  case TAG_False: {
    heff_drop(v_t_2410);
    return heff_tag(TAG_Nest, 2, (V[]){v_i_249, v_d_246});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2efmt_2elayout_2esig_lam0(V self, V *args) {
  V v_k_247 = args[0];
  V v_d_246 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_tag(TAG_Nesting, 1, (V[]){heff_clo(g_heff_2efmt_2elayout_2esig_lam1, 1, 2, (V[]){v_k_247, v_d_246})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2edataAltsDoc_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2edataAltsDoc_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
V g_heff_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    heff_drop(v_x2_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse(v_x2_241, 1ULL);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_alts_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take(v_x21_242, 7ULL);
      switch (heff_tag_of(v_alts_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop(v_ru_24x2_241_24Just);
        heff_drop(v_eq_243);
        heff_drop(v_alts_244);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_alts_244, 0);
        V v_more_247 = heff_field(v_alts_244, 1);
        heff_take(v_alts_244, 3ULL);
        V v_a_248 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_243));
        V v_b_249 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2410 = (g_std_2edoc_2e_3c_3e(heff_tag_at(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_249));
        V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_a_248, v_t_2410));
        V v_ds_2418 = (g_prelude_2ezipWith(heff_clo(g_heff_2efmt_2elayout_2edataAltsDoc_lam0, 2, 1, (V[]){v_env_240}), v_bars_245, v_more_247));
        V v_t_2419 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2418; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_2418); r_; });
        V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2419));
        V v_t_2421 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_2420));
        return (g_std_2edoc_2egroup(v_t_2421));
      }
      default: return heff_nomatch(v_alts_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2412 = args[0];
  V v_a_2413 = args[1];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_a_2414 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2412));
  V v_b_2415 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_240, v_a_2413}));
  V v_t_2416 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2415));
  V v_t_2417 = (g_std_2edoc_2e_3c_3e(v_a_2414, v_t_2416));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_2417));
}
V g_heff_2efmt_2elayout_2edeclsGo_24s712_lam0(V self, V *args);
Clo g_heff_2efmt_2elayout_2edeclsGo_24s712_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2edeclsGo_24s712_entry, 3, 0};

V g_heff_2efmt_2elayout_2edeclsGo_24s712(V v_env_240, V v_i_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x4_242, 0);
    V v_ds_244 = heff_field(v_x4_242, 1);
    V v_t_245 = heff_intLt(MK_INT(0LL), heff_dup(v_i_241));
    V v_t_2414;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2ecst_2efirstD(v_d_243));
      V v_x2_247 = ({ V a_0 = heff_get(heff_dup(v_t_246), LBL_ix); V b_1 = heff_get(heff_dup(v_env_240), LBL_lead); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
      V v_x1_249;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        heff_drop(v_x2_247);
        v_x1_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take(v_x2_247, 1ULL);
        v_x1_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2412;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_Nil: {
        heff_drop(v_x1_249);
        v_t_2412 = heff_get(v_t_246, LBL_blank);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_x1_249, 0);
        heff_take(v_x1_249, 1ULL);
        heff_drop(v_t_246);
        v_t_2412 = heff_get(v_x_2410, LBL_blank);
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      V v_t_2413;
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2efmt_2elayout_2eblankLine_get());
        break;
      }
      case TAG_False: {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      v_t_2414 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
      break;
    }
    case TAG_False: {
      heff_drop(v_t_245);
      v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2415 = (g_heff_2ecst_2efirstD(v_d_243));
    V v_t_2416 = (g_heff_2ecst_2elastD(heff_dup(v_d_243)));
    V v_t_2418 = (g_heff_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2415, v_t_2416, heff_clo(g_heff_2efmt_2elayout_2edeclsGo_24s712_lam0, 1, 1, (V[]){heff_dup(v_d_243)})));
    V v_t_2419 = (g_heff_2efmt_2elayout_2edeclsGo_24s712(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_ds_244));
    V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2418, v_t_2419));
    return (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2420));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2efmt_2elayout_2edeclsGo_24s712_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2edeclsGo_24s712(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2efmt_2elayout_2edeclsGo_24s712_lam0(V self, V *args) {
  V v_e_2417 = args[0];
  V v_d_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V a_0 = v_e_2417; V a_1 = v_d_243; V r_ = (g_heff_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_243); r_; });
}
Clo g_heff_2efmt_2elayout_2ewhereDoc_24s711_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2ewhereDoc_24s711_entry, 3, 0};

V g_heff_2efmt_2elayout_2ewhereDoc_24s711(V v_env_240, V v_rhsLast_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    heff_drop(v_rhsLast_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_kw_244 = heff_field(v_x41_243, 0);
      V v_ds_245 = heff_field(v_x41_243, 1);
      V v_t_246 = ({ V a_0 = heff_get(heff_dup(v_rhsLast_241), LBL_ix); V b_1 = heff_get(heff_dup(v_env_240), LBL_trail); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_248;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        heff_drop(v_rhsLast_241);
        heff_drop(v_t_246);
        v_t_248 = heff_dup(g_std_2edoc_2ehardline_get());
        break;
      }
      case TAG_Just: {
        heff_take(v_t_246, 0ULL);
        v_t_248 = (g_heff_2efmt_2elayout_2etrailOf(heff_dup(v_env_240), v_rhsLast_241));
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      V v_t_249 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_244)));
      V v_t_2410 = (g_heff_2efmt_2elayout_2edeclsGo_24s712(v_env_240, MK_INT(0LL), v_ds_245));
      V v_d_2411 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2410));
      V v_t_2412 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2411})));
      return (g_std_2edoc_2e_3c_3e(v_t_248, v_t_2412));
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2efmt_2elayout_2ewhereDoc_24s711_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2ewhereDoc_24s711(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
V g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714_lam0(V self, V *args);
Clo g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714_entry, 3, 0};

V g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_245 = heff_intLt(MK_INT(0LL), heff_dup(v_i_241));
    V v_t_2416;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_245);
      V v_t_249;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkTF: {
        V v_x_246 = heff_field(v_x_243, 0);
        v_t_249 = heff_dup(v_x_246);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_x2_2410 = ({ V a_0 = heff_get(heff_dup(v_t_249), LBL_ix); V b_1 = heff_get(heff_dup(v_env_240), LBL_lead); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
      V v_x1_2412;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nothing: {
        heff_drop(v_x2_2410);
        v_x1_2412 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        heff_take(v_x2_2410, 1ULL);
        v_x1_2412 = v_x_2411;
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      V v_t_2415;
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_Nil: {
        heff_drop(v_x1_2412);
        v_t_2415 = heff_get(v_t_249, LBL_blank);
        break;
      }
      case TAG_Cons: {
        V v_x_2413 = heff_field(v_x1_2412, 0);
        heff_take(v_x1_2412, 1ULL);
        heff_drop(v_t_249);
        v_t_2415 = heff_get(v_x_2413, LBL_blank);
        break;
      }
      default: heff_nomatch(v_x1_2412);
      }
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop(v_t_2415);
        v_t_2416 = heff_dup(g_heff_2efmt_2elayout_2eblankLine_get());
        break;
      }
      case TAG_False: {
        heff_drop(v_t_2415);
        v_t_2416 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      default: heff_nomatch(v_t_2415);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_t_245);
      v_t_2416 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2420;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_x_2417 = heff_field(v_x_243, 0);
      v_t_2420 = heff_dup(v_x_2417);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2424;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_ty_2423 = heff_field(v_x_243, 2);
      v_t_2424 = (g_heff_2ecst_2elastE(heff_dup(v_ty_2423)));
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2432 = (g_heff_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2420, v_t_2424, heff_clo(g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2433 = (g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2434 = (g_std_2edoc_2e_3c_3e(v_t_2432, v_t_2433));
    V v_t_2435 = (g_std_2edoc_2e_3c_3e(v_t_2416, v_t_2434));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2435));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714_lam0(V self, V *args) {
  V v_e_2425 = args[0];
  V v_x_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  switch (heff_tag_of(v_x_243)) {
  case TAG_MkTF: {
    V v_x_2426 = heff_field(v_x_243, 0);
    V v_cc_2427 = heff_field(v_x_243, 1);
    V v_ty_2428 = heff_field(v_x_243, 2);
    heff_take(v_x_243, 7ULL);
    V v_a_2429 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_e_2425), v_x_2426));
    V v_b_2430 = (g_heff_2efmt_2elayout_2esig(v_e_2425, v_cc_2427, v_ty_2428));
    V v_t_2431 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714_str0)}), v_b_2430));
    return (g_std_2edoc_2e_3c_3e(v_a_2429, v_t_2431));
  }
  default: return heff_nomatch(v_x_243);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str19 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2epD_str20 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2efmt_2elayout_2epD_lam0(V self, V *args);
V g_heff_2efmt_2elayout_2epD_lam1(V self, V *args);
V g_heff_2efmt_2elayout_2epD_lam2(V self, V *args);
V g_heff_2efmt_2elayout_2epD_lam3(V self, V *args);
V g_heff_2efmt_2elayout_2epD_lam4(V self, V *args);
Clo g_heff_2efmt_2elayout_2epD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2epD_entry, 2, 0};

V g_heff_2efmt_2elayout_2epD(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_DImport: {
    V v_t_242 = heff_field(v_x2_241, 0);
    return (g_heff_2efmt_2elayout_2etok(v_env_240, heff_dup(v_t_242)));
  }
  case TAG_DFixity: {
    V v_kw_243 = heff_field(v_x2_241, 0);
    V v_ts_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_243)));
    V v_ds_248 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2epD_lam0, 1, 1, (V[]){v_env_240}), heff_dup(v_ts_244)));
    V v_t_249 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_248; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_248); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_245, v_t_249));
  }
  case TAG_DSig: {
    V v_n_2410 = heff_field(v_x2_241, 0);
    V v_cc_2411 = heff_field(v_x2_241, 1);
    V v_ty_2412 = heff_field(v_x2_241, 2);
    V v_t_2413 = heff_tr(heff_apply(((V)&g_heff_2efmt_2elayout_2etok_clo), 1, (V[]){heff_dup(v_env_240)}));
    V v_ds_2414 = (g_prelude_2emap(v_t_2413, heff_dup(v_n_2410)));
    V v_a_2415 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2414; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_2414); r_; });
    V v_b_2416 = (g_heff_2efmt_2elayout_2esig(v_env_240, heff_dup(v_cc_2411), heff_dup(v_ty_2412)));
    V v_t_2417 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str1)}), v_b_2416));
    return (g_std_2edoc_2e_3c_3e(v_a_2415, v_t_2417));
  }
  case TAG_DEqn: {
    V v_n_2418 = heff_field(v_x2_241, 0);
    V v_pats_2419 = heff_field(v_x2_241, 1);
    V v_eq_2420 = heff_field(v_x2_241, 2);
    V v_rhs_2421 = heff_field(v_x2_241, 3);
    V v_w_2422 = heff_field(v_x2_241, 4);
    V v_t_2423 = heff_tr(heff_apply(((V)&g_heff_2efmt_2elayout_2etok_clo), 1, (V[]){heff_dup(v_env_240)}));
    V v_ds_2424 = (g_prelude_2emap(v_t_2423, heff_dup(v_n_2418)));
    V v_t_2425 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2424; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_2424); r_; });
    V v_ds_2428 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2epD_lam1, 1, 1, (V[]){heff_dup(v_env_240)}), heff_dup(v_pats_2419)));
    V v_a_2429 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2428; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_2428); r_; });
    V v_b_2430 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2420)));
    V v_t_2431 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str3)}), v_b_2430));
    V v_t_2432 = (g_std_2edoc_2e_3c_3e(v_a_2429, v_t_2431));
    V v_rhsLast_2433 = (g_heff_2ecst_2elastE(heff_dup(v_rhs_2421)));
    V v_t_2435;
    switch (heff_tag_of(v_w_2422)) {
    case TAG_Nothing: {
      heff_drop(v_rhsLast_2433);
      v_t_2435 = heff_dup(v_env_240);
      break;
    }
    case TAG_Just: {
      v_t_2435 = heff_rec(7, shape_302_158_136_332_195_196_97, (V[]){heff_get(heff_dup(v_env_240), LBL_src), heff_get(heff_dup(v_env_240), LBL_lead), heff_get(heff_dup(v_env_240), LBL_inline), heff_get(heff_dup(v_env_240), LBL_trail), heff_get(heff_dup(v_env_240), LBL_noLead), heff_get(v_rhsLast_2433, LBL_ix), heff_get(heff_dup(v_env_240), LBL_fix)});
      break;
    }
    default: heff_nomatch(v_w_2422);
    }
    V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_rhsOf), 2, (V[]){v_t_2435, heff_dup(v_rhs_2421)}));
    V v_t_2437 = (g_heff_2ecst_2elastE(heff_dup(v_rhs_2421)));
    V v_t_2438 = (g_heff_2efmt_2elayout_2ewhereDoc_24s711(v_env_240, v_t_2437, v_w_2422));
    V v_t_2439 = (g_std_2edoc_2e_3c_3e(v_t_2436, v_t_2438));
    V v_t_2440 = (g_std_2edoc_2e_3c_3e(v_t_2432, v_t_2439));
    return (g_std_2edoc_2e_3c_3e(v_t_2425, v_t_2440));
  }
  case TAG_DData: {
    V v_kw_2441 = heff_field(v_x2_241, 0);
    V v_name_2442 = heff_field(v_x2_241, 1);
    V v_params_2443 = heff_field(v_x2_241, 2);
    V v_universe_2444 = heff_field(v_x2_241, 3);
    V v_alts_2445 = heff_field(v_x2_241, 4);
    V v_a_2446 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2441)));
    V v_b_2447 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2442)));
    V v_t_2448 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str4)}), v_b_2447));
    V v_t_2449 = (g_std_2edoc_2e_3c_3e(v_a_2446, v_t_2448));
    V v_ds_2453 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2epD_lam2, 1, 1, (V[]){heff_dup(v_env_240)}), heff_dup(v_params_2443)));
    V v_t_2454 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2453; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_2453); r_; });
    V v_t_2462;
    switch (heff_tag_of(v_universe_2444)) {
    case TAG_Nothing: {
      v_t_2462 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_x21_2455 = heff_field(v_universe_2444, 0);
      switch (heff_tag_of(v_x21_2455)) {
      case TAG_MkPair: {
        V v_cc_2456 = heff_field(v_x21_2455, 0);
        V v_u_2457 = heff_field(v_x21_2455, 1);
        V v_a_2458 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_cc_2456)));
        V v_b_2459 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){heff_dup(v_env_240), heff_dup(v_u_2457)}));
        V v_t_2460 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str6)}), v_b_2459));
        V v_t_2461 = (g_std_2edoc_2e_3c_3e(v_a_2458, v_t_2460));
        v_t_2462 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str7)}), v_t_2461));
        break;
      }
      default: heff_nomatch(v_x21_2455);
      }
      break;
    }
    default: heff_nomatch(v_universe_2444);
    }
    V v_t_2463 = (g_heff_2efmt_2elayout_2edataAltsDoc(v_env_240, heff_dup(v_alts_2445)));
    V v_t_2464 = (g_std_2edoc_2e_3c_3e(v_t_2462, v_t_2463));
    V v_t_2465 = (g_std_2edoc_2e_3c_3e(v_t_2454, v_t_2464));
    return (g_std_2edoc_2e_3c_3e(v_t_2449, v_t_2465));
  }
  case TAG_DType: {
    V v_kw_2466 = heff_field(v_x2_241, 0);
    V v_name_2467 = heff_field(v_x2_241, 1);
    V v_params_2468 = heff_field(v_x2_241, 2);
    V v_eq_2469 = heff_field(v_x2_241, 3);
    V v_body_2470 = heff_field(v_x2_241, 4);
    V v_a_2471 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2466)));
    V v_b_2472 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2467)));
    V v_t_2473 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str8)}), v_b_2472));
    V v_t_2474 = (g_std_2edoc_2e_3c_3e(v_a_2471, v_t_2473));
    V v_ds_2478 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2epD_lam3, 1, 1, (V[]){heff_dup(v_env_240)}), heff_dup(v_params_2468)));
    V v_a_2479 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2478; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_2478); r_; });
    V v_b_2480 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_2469)));
    V v_t_2481 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str10)}), v_b_2480));
    V v_t_2482 = (g_std_2edoc_2e_3c_3e(v_a_2479, v_t_2481));
    V v_t_2483 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_rhsOf), 2, (V[]){v_env_240, heff_dup(v_body_2470)}));
    V v_t_2484 = (g_std_2edoc_2e_3c_3e(v_t_2482, v_t_2483));
    return (g_std_2edoc_2e_3c_3e(v_t_2474, v_t_2484));
  }
  case TAG_DTheory: {
    V v_kw_2485 = heff_field(v_x2_241, 0);
    V v_name_2486 = heff_field(v_x2_241, 1);
    V v_params_2487 = heff_field(v_x2_241, 2);
    V v_w_2488 = heff_field(v_x2_241, 3);
    V v_fields_2489 = heff_field(v_x2_241, 4);
    V v_a_2490 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_2485)));
    V v_b_2491 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_name_2486)));
    V v_t_2492 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str11)}), v_b_2491));
    V v_t_2493 = (g_std_2edoc_2e_3c_3e(v_a_2490, v_t_2492));
    V v_ds_2497 = (g_prelude_2emap(heff_clo(g_heff_2efmt_2elayout_2epD_lam4, 1, 1, (V[]){heff_dup(v_env_240)}), heff_dup(v_params_2487)));
    V v_a_2498 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2497; V r_ = (g_prelude_2efoldl_24s704(a_0, a_1)); heff_drop(v_ds_2497); r_; });
    V v_b_2499 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_w_2488)));
    V v_t_24100 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str13)}), v_b_2499));
    V v_t_24101 = (g_std_2edoc_2e_3c_3e(v_a_2498, v_t_24100));
    V v_t_24102 = (g_heff_2efmt_2elayout_2eitemsGo_24s713_24s714(v_env_240, MK_INT(0LL), v_fields_2489));
    V v_t_24103 = (g_std_2edoc_2e_3c_3e(v_t_24101, v_t_24102));
    return (g_std_2edoc_2e_3c_3e(v_t_2493, v_t_24103));
  }
  case TAG_DForeign: {
    V v_kw_24104 = heff_field(v_x2_241, 0);
    V v_imp_24105 = heff_field(v_x2_241, 1);
    V v_x_24106 = heff_field(v_x2_241, 2);
    V v_cc_24107 = heff_field(v_x2_241, 3);
    V v_ty_24108 = heff_field(v_x2_241, 4);
    V v_a_24109 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_24104)));
    V v_a_24110 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_imp_24105)));
    V v_a_24111 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_x_24106)));
    V v_b_24112 = (g_heff_2efmt_2elayout_2esig(v_env_240, heff_dup(v_cc_24107), heff_dup(v_ty_24108)));
    V v_t_24113 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str14)}), v_b_24112));
    V v_b_24114 = (g_std_2edoc_2e_3c_3e(v_a_24111, v_t_24113));
    V v_t_24115 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str15)}), v_b_24114));
    V v_b_24116 = (g_std_2edoc_2e_3c_3e(v_a_24110, v_t_24115));
    V v_t_24117 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str16)}), v_b_24116));
    return (g_std_2edoc_2e_3c_3e(v_a_24109, v_t_24117));
  }
  case TAG_DTest: {
    V v_kw_24118 = heff_field(v_x2_241, 0);
    V v_x_24119 = heff_field(v_x2_241, 1);
    V v_a_24120 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_kw_24118)));
    V v_b_24121 = (g_heff_2efmt_2elayout_2etok(v_env_240, heff_dup(v_x_24119)));
    V v_t_24122 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str17)}), v_b_24121));
    return (g_std_2edoc_2e_3c_3e(v_a_24120, v_t_24122));
  }
  case TAG_DWatch: {
    V v_w_24123 = heff_field(v_x2_241, 0);
    V v_e_24124 = heff_field(v_x2_241, 1);
    V v_t_24125 = (g_heff_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_w_24123)));
    V v_t_24126 = (g_heff_2ecst_2elastE(heff_dup(v_e_24124)));
    V v_b_24127 = heff_get(v_t_24126, LBL_end);
    V v_s_24128 = heff_strSlice(heff_get(v_env_240, LBL_src), heff_get(heff_dup(v_w_24123), LBL_end), v_b_24127);
    V v_x2_24129 = (g_prelude_2esplitFrom(((V)&g_heff_2efmt_2elayout_2epD_str18), v_s_24128, MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_24132;
    switch (heff_tag_of(v_x2_24129)) {
    case TAG_Nil: {
      heff_drop(v_x2_24129);
      v_s_24132 = ((V)&g_heff_2efmt_2elayout_2epD_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_24130 = heff_field(v_x2_24129, 0);
      V v_xs_24131 = heff_field(v_x2_24129, 1);
      heff_take(v_x2_24129, 3ULL);
      v_s_24132 = ({ V a_0 = v_x_24130; V a_1 = v_xs_24131; V r_ = (g_prelude_2efoldl_24s703(a_0, a_1)); heff_drop(v_xs_24131); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24129);
    }
    V v_t_24133 = heff_strEq(heff_dup(v_s_24132), ((V)&g_heff_2efmt_2elayout_2epD_str20));
    V v_t_24134;
    switch (heff_tag_of(v_t_24133)) {
    case TAG_True: {
      heff_drop(v_s_24132);
      heff_drop(v_t_24133);
      v_t_24134 = NTAG(TAG_None);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_24133);
      v_t_24134 = heff_tag(TAG_Text, 1, (V[]){v_s_24132});
      break;
    }
    default: heff_nomatch(v_t_24133);
    }
    return (g_std_2edoc_2e_3c_3e(v_t_24125, v_t_24134));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2efmt_2elayout_2epD_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2epD(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2efmt_2elayout_2epD_lam0(V self, V *args) {
  V v_t_246 = args[0];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_247 = (g_heff_2efmt_2elayout_2etok(v_env_240, v_t_246));
  return (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str0)}), v_t_247));
}
V g_heff_2efmt_2elayout_2epD_lam1(V self, V *args) {
  V v_p_2426 = args[0];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2427 = ({ V a_0 = v_env_240; V a_1 = v_p_2426; V r_ = (g_heff_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_2426); r_; });
  return (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str2)}), v_t_2427));
}
V g_heff_2efmt_2elayout_2epD_lam2(V self, V *args) {
  V v_p_2450 = args[0];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_240, v_p_2450}));
  V v_t_2452 = (g_std_2edoc_2eflatten(v_t_2451));
  return (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str5)}), v_t_2452));
}
V g_heff_2efmt_2elayout_2epD_lam3(V self, V *args) {
  V v_p_2475 = args[0];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2476 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_240, v_p_2475}));
  V v_t_2477 = (g_std_2edoc_2eflatten(v_t_2476));
  return (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str9)}), v_t_2477));
}
V g_heff_2efmt_2elayout_2epD_lam4(V self, V *args) {
  V v_p_2494 = args[0];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2495 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2efmt_2elayout_2elay_get()), LBL_pE), 2, (V[]){v_env_240, v_p_2494}));
  V v_t_2496 = (g_std_2edoc_2eflatten(v_t_2495));
  return (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){((V)&g_heff_2efmt_2elayout_2epD_str12)}), v_t_2496));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2eeofLeadDocs_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2eeofLeadDocs_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2eeofLeadDocs_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2efmt_2elayout_2eeofLeadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2eeofLeadDocs_entry, 2, 0};

V g_heff_2efmt_2elayout_2eeofLeadDocs(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_cs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_get(heff_dup(v_c_242), LBL_blank);
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_t_244);
      v_t_245 = heff_dup(g_heff_2efmt_2elayout_2eblankLine_get());
      break;
    }
    case TAG_False: {
      heff_drop(v_t_244);
      v_t_245 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_x2_246 = (g_prelude_2esplitFrom(((V)&g_heff_2efmt_2elayout_2eeofLeadDocs_str0), heff_get(heff_dup(v_c_242), LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      heff_drop(v_x2_246);
      v_s_249 = ((V)&g_heff_2efmt_2elayout_2eeofLeadDocs_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take(v_x2_246, 3ULL);
      v_s_249 = ({ V a_0 = v_x_247; V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s703(a_0, a_1)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_t_2410 = heff_strEq(heff_dup(v_s_249), ((V)&g_heff_2efmt_2elayout_2eeofLeadDocs_str2));
    V v_t_2411;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      heff_drop(v_s_249);
      heff_drop(v_t_2410);
      v_t_2411 = NTAG(TAG_None);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_2410);
      v_t_2411 = heff_tag(TAG_Text, 1, (V[]){v_s_249});
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2412 = (g_heff_2efmt_2elayout_2eeofLeadDocs(v_env_240, v_cs_243));
    V v_t_2413 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2412));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_245, v_t_2413));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2414));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2eeofLeadDocs(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2efmt_2elayout_2edeclsGo_24s715_lam0(V self, V *args);
Clo g_heff_2efmt_2elayout_2edeclsGo_24s715_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2edeclsGo_24s715_entry, 3, 0};

V g_heff_2efmt_2elayout_2edeclsGo_24s715(V v_env_240, V v_i_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x4_242, 0);
    V v_ds_244 = heff_field(v_x4_242, 1);
    V v_t_245 = heff_intLt(MK_INT(0LL), heff_dup(v_i_241));
    V v_t_2414;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2ecst_2efirstD(v_d_243));
      V v_x2_247 = ({ V a_0 = heff_get(heff_dup(v_t_246), LBL_ix); V b_1 = heff_get(heff_dup(v_env_240), LBL_lead); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
      V v_x1_249;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        heff_drop(v_x2_247);
        v_x1_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take(v_x2_247, 1ULL);
        v_x1_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2412;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_Nil: {
        heff_drop(v_x1_249);
        v_t_2412 = heff_get(v_t_246, LBL_blank);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_x1_249, 0);
        heff_take(v_x1_249, 1ULL);
        heff_drop(v_t_246);
        v_t_2412 = heff_get(v_x_2410, LBL_blank);
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      V v_t_2413;
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2efmt_2elayout_2eblankLine_get());
        break;
      }
      case TAG_False: {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      v_t_2414 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
      break;
    }
    case TAG_False: {
      heff_drop(v_t_245);
      v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_2415 = (g_heff_2ecst_2efirstD(v_d_243));
    V v_t_2416 = (g_heff_2ecst_2elastD(heff_dup(v_d_243)));
    V v_t_2418 = (g_heff_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2415, v_t_2416, heff_clo(g_heff_2efmt_2elayout_2edeclsGo_24s715_lam0, 1, 1, (V[]){heff_dup(v_d_243)})));
    V v_t_2419 = (g_heff_2efmt_2elayout_2edeclsGo_24s715(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_ds_244));
    V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2418, v_t_2419));
    return (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2420));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2efmt_2elayout_2edeclsGo_24s715_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efmt_2elayout_2edeclsGo_24s715(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2efmt_2elayout_2edeclsGo_24s715_lam0(V self, V *args) {
  V v_e_2417 = args[0];
  V v_d_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V a_0 = v_e_2417; V a_1 = v_d_243; V r_ = (g_heff_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_243); r_; });
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2ekeptLines_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2ekeptLines_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2efmt_2elayout_2ekeptLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2ekeptLines_entry, 1, 0};

V g_heff_2efmt_2elayout_2ekeptLines(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_241 = heff_field(v_x1_240, 0);
    V v_ls_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_243 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), MK_INT(0LL), MK_INT(1LL)));
    V v_t_244 = heff_intSub(heff_strLength(heff_dup(v_l_241)), MK_INT(1LL));
    V v_t_245 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), v_t_244, MK_INT(-1LL)));
    V v_t_246 = heff_strSlice(heff_dup(v_l_241), v_t_243, heff_intAdd(v_t_245, MK_INT(1LL)));
    V v_t_247 = heff_strEq(v_t_246, heff_dup(g_heff_2efmt_2elayout_2eblankMark_get()));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_l_241);
      heff_drop(v_t_247);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2efmt_2elayout_2ekeptLines_str0), (g_heff_2efmt_2elayout_2ekeptLines(v_ls_242))});
    }
    case TAG_False: {
      heff_drop(v_t_247);
      V v_t_248 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), MK_INT(0LL), MK_INT(1LL)));
      V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_l_241)), MK_INT(1LL));
      V v_t_2410 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), v_t_249, MK_INT(-1LL)));
      V v_t_2411 = heff_strSlice(heff_dup(v_l_241), v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
      V v_t_2412 = heff_strEq(v_t_2411, ((V)&g_heff_2efmt_2elayout_2ekeptLines_str1));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_l_241);
        heff_drop(v_ru_24x1_240_24Cons);
        heff_drop(v_t_2412);
        V t_0 = v_ls_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_t_2412);
        return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_241, (g_heff_2efmt_2elayout_2ekeptLines(v_ls_242))});
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2efmt_2elayout_2ekeptLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elayout_2ekeptLines(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2erender2_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2erender2_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2erender2_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2erender2_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2erender2_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2efmt_2elayout_2erender2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2erender2_entry, 1, 0};

V g_heff_2efmt_2elayout_2erender2(V v_d_240) {
top: ;
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){MK_INT(0LL), v_d_240}), NTAG(TAG_Nil)});
  V v_s_242 = (g_std_2edoc_2ebest(MK_INT(80LL), MK_INT(0LL), MK_INT(0LL), v_t_241));
  V v_s_243 = (g_std_2edoc_2edisplayInto(((V)&g_heff_2efmt_2elayout_2erender2_str0), v_s_242));
  V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2efmt_2elayout_2erender2_str1), v_s_243, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_245 = (g_prelude_2emap_24s716(v_t_244));
  V v_x2_246 = (g_heff_2efmt_2elayout_2ekeptLines(v_t_245));
  V v_s_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_x2_246);
    v_s_249 = ((V)&g_heff_2efmt_2elayout_2erender2_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take(v_x2_246, 3ULL);
    v_s_249 = ({ V a_0 = v_x_247; V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = heff_intEq(heff_strLength(heff_dup(g_heff_2efmt_2elayout_2enewlineMark_get())), MK_INT(0LL));
  V v_x2_2411;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_t_2410);
    v_x2_2411 = heff_tag(TAG_Cons, 2, (V[]){v_s_249, NTAG(TAG_Nil)});
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2410);
    v_x2_2411 = (g_prelude_2esplitFrom(heff_dup(g_heff_2efmt_2elayout_2enewlineMark_get()), v_s_249, MK_INT(0LL), NTAG(TAG_Nil)));
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    heff_drop(v_x2_2411);
    v_t_2414 = ((V)&g_heff_2efmt_2elayout_2erender2_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take(v_x2_2411, 3ULL);
    v_t_2414 = ({ V a_0 = v_x_2412; V a_1 = v_xs_2413; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  return heff_strAppend(v_t_2414, ((V)&g_heff_2efmt_2elayout_2erender2_str4));
}
V g_heff_2efmt_2elayout_2erender2_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elayout_2erender2(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2efmt_2elayout_2efmtParsed_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2efmtParsed_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2elayout_2efmtParsed_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2efmt_2elayout_2efmtParsed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2efmtParsed_entry, 2, 0};

V g_heff_2efmt_2elayout_2efmtParsed(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Left: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Left = heff_take_reuse(v_x2_241, 1ULL);
    heff_drop(v_at_240);
    return heff_tag_at(v_ru_24x2_241_24Left, TAG_Left, 1, (V[]){v_e_242});
  }
  case TAG_Right: {
    V v_ds_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Right = heff_take_reuse(v_x2_241, 1ULL);
    V v_env_244 = heff_get(heff_dup(v_at_240), LBL_env);
    V v_ts_245 = heff_get(v_at_240, LBL_toks);
    V v_t_246 = heff_intLt(MK_INT(0LL), heff_arrayLength(heff_dup(v_ts_245)));
    V v_eof_248;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_t_246);
      V v_t_247 = heff_intSub(heff_arrayLength(heff_dup(v_ts_245)), MK_INT(1LL));
      v_eof_248 = heff_arrayIndex(v_ts_245, v_t_247);
      break;
    }
    case TAG_False: {
      heff_drop(v_ts_245);
      heff_drop(v_t_246);
      v_eof_248 = heff_rec(9, shape_147_321_254_305_78_45_96_142_24, (V[]){((V)&g_heff_2efmt_2elayout_2efmtParsed_str0), ((V)&g_heff_2efmt_2elayout_2efmtParsed_str1), ((V)&g_heff_2efmt_2elayout_2efmtParsed_str2), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_249 = ({ V a_0 = heff_dup(v_env_244); V a_1 = MK_INT(0LL); V a_2 = v_ds_243; V r_ = (g_heff_2efmt_2elayout_2edeclsGo_24s715(a_0, a_1, a_2)); heff_drop(v_ds_243); r_; });
    V v_x2_2410 = ({ V a_0 = heff_get(v_eof_248, LBL_ix); V b_1 = heff_get(heff_dup(v_env_244), LBL_lead); V r_ = (g_map_2elookup_24s12(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2412;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nothing: {
      heff_drop(v_x2_2410);
      v_t_2412 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      heff_take(v_x2_2410, 1ULL);
      v_t_2412 = v_x_2411;
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    V v_t_2413 = ({ V a_0 = v_env_244; V a_1 = v_t_2412; V r_ = (g_heff_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop(v_env_244); heff_drop(v_t_2412); r_; });
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_249, v_t_2413));
    return heff_tag_at(v_ru_24x2_241_24Right, TAG_Right, 1, (V[]){(g_heff_2efmt_2elayout_2erender2(v_t_2414))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2efmt_2elayout_2efmtParsed_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elayout_2efmtParsed(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2efmt_2elayout_2efmtLexed_str0 = {{0x80000000u, K_STR, 0}, 21, 21, {116, 104, 101, 32, 102, 105, 108, 101, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 108, 101, 120}};
Clo g_heff_2efmt_2elayout_2efmtLexed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2efmtLexed_entry, 4, 0};

V g_heff_2efmt_2elayout_2efmtLexed(V v_f_240, V v_src_241, V v_hdr_242, V v_l_243) {
top: ;
  V v_t_244 = heff_get(heff_dup(v_l_243), LBL_errors);
  V v_x1_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop(v_t_244);
    v_x1_247 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take(v_t_244, 0ULL);
    v_x1_247 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_248;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_True: {
    heff_drop(v_x1_247);
    v_t_248 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    heff_drop(v_x1_247);
    v_t_248 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    heff_drop(v_f_240);
    heff_drop(v_src_241);
    heff_drop(v_hdr_242);
    heff_drop(v_l_243);
    heff_drop(v_t_248);
    return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2efmt_2elayout_2efmtLexed_str0)});
  }
  case TAG_False: {
    heff_drop(v_t_248);
    V v_t_249 = (g_prelude_2emap_24s213(heff_get(v_hdr_242, LBL_imports)));
    V v_t_2410 = (g_prelude_2econcatList(v_t_249, heff_get(heff_dup(v_l_243), LBL_tokens)));
    V v_t_2411 = (g_prelude_2esortBy_24s211(v_t_2410));
    V v_at_2412 = (g_heff_2efmt_2etoks_2eattach(v_src_241, v_t_2411, heff_get(v_l_243, LBL_comments)));
    V v_t_2413 = heff_get(heff_get(heff_dup(v_at_2412), LBL_env), LBL_src);
    V v_t_2414 = heff_get(heff_get(heff_dup(v_at_2412), LBL_env), LBL_lead);
    V v_t_2415 = heff_get(heff_get(heff_dup(v_at_2412), LBL_env), LBL_inline);
    V v_t_2416 = heff_get(heff_get(heff_dup(v_at_2412), LBL_env), LBL_trail);
    V v_t_2417 = heff_get(heff_get(heff_dup(v_at_2412), LBL_env), LBL_noLead);
    V v_t_2418 = heff_get(heff_get(heff_dup(v_at_2412), LBL_env), LBL_noTrail);
    V v_at_2419 = heff_rec(2, shape_327_82, (V[]){heff_get(v_at_2412, LBL_toks), heff_rec(7, shape_302_158_136_332_195_196_97, (V[]){v_t_2413, v_t_2414, v_t_2415, v_t_2416, v_t_2417, v_t_2418, v_f_240})});
    V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    V v_t_2421 = heff_rec(5, shape_327_123_329_304_305, (V[]){heff_get(heff_dup(v_at_2419), LBL_toks), MK_INT(0LL), MK_INT(0LL), v_t_2420, MK_INT(0LL)});
    V v_t_2422 = (g_heff_2ecst_2eprogramGo(v_t_2421, NTAG(TAG_Nil)));
    return (g_heff_2efmt_2elayout_2efmtParsed(v_at_2419, v_t_2422));
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2efmt_2elayout_2efmtLexed_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elayout_2efmtLexed(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2efmt_2elayout_2eformatUncheckedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2elayout_2eformatUncheckedIn_entry, 2, 0};

V g_heff_2efmt_2elayout_2eformatUncheckedIn(V v_f_240, V v_src_241) {
top: ;
  V v_imps_242 = (g_heff_2efmt_2eimports_2ereadGo(heff_dup(v_src_241), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_243 = (g_prelude_2efoldl_24s210(heff_dup(v_src_241), v_imps_242));
  V v_hdr_244 = heff_rec(2, shape_130_321, (V[]){v_imps_242, v_t_243});
  V v_t_245 = heff_rec(7, shape_123_167_168_96_325_83_42, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_246 = (g_heff_2efmt_2elex_2elexGo(heff_get(heff_dup(v_hdr_244), LBL_text), v_t_245, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  return (g_heff_2efmt_2elayout_2efmtLexed(v_f_240, v_src_241, v_hdr_244, v_t_246));
}
V g_heff_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2elayout_2eformatUncheckedIn(a[0], a[1]);
}