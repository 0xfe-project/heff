// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_Kept 49931
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_defs 9574869
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kp 10188
#define LBL_madeFresh 950075604
#define LBL_match 305026527
#define LBL_plain 308106724
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_sgSafe 1042218796
#define LBL_sgTotal 97882005
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_vers 10111479
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eallPure_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24tok2_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eargPure_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved(V, V);
V g_heff_2ecompile_2esimplify_2ebeforeMoved_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebeforeMoved_clo;
V g_heff_2ecompile_2esimplify_2ebuilds(V, V, V);
V g_heff_2ecompile_2esimplify_2ebuilds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuilds_clo;
V g_heff_2ecompile_2esimplify_2ebuilds_24tok2(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ebuilds_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuilds_24tok2_clo;
V g_heff_2ecompile_2esimplify_2ebuiltBy(V, V);
V g_heff_2ecompile_2esimplify_2ebuiltBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltBy_clo;
V g_heff_2ecompile_2esimplify_2ecaseOfCase(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_clo;
V g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eetaArg(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaArg_clo;
V g_heff_2ecompile_2esimplify_2eetaFor(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaFor_clo;
V g_heff_2ecompile_2esimplify_2eetaLets(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLets_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLets_clo;
V g_heff_2ecompile_2esimplify_2eetaLoop(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaLoop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaLoop_clo;
V g_heff_2ecompile_2esimplify_2eetaWanted(V, V);
V g_heff_2ecompile_2esimplify_2eetaWanted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaWanted_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efieldIn_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efindArm_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eflat(V);
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eflat_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2einlinedCall(V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlinedCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlinedCall_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eknownField_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2eletsOf_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_24dps_clo;
V g_heff_2ecompile_2esimplify_2ematchOn(V, V, V);
V g_heff_2ecompile_2esimplify_2ematchOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchOn_clo;
V g_heff_2ecompile_2esimplify_2emovesFirst(V, V);
V g_heff_2ecompile_2esimplify_2emovesFirst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emovesFirst_clo;
V g_heff_2ecompile_2esimplify_2epureOrPartial(V, V);
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erefsMade_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgFlat_clo;
V g_heff_2ecompile_2esimplify_2esgItem(V, V);
V g_heff_2ecompile_2esimplify_2esgItem_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgItem_clo;
V g_heff_2ecompile_2esimplify_2eunLam(V, V);
V g_heff_2ecompile_2esimplify_2eunLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunLam_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_list_2eany_24s392952474x1351014279(V, V);
V g_list_2eany_24s392952474x1351014279_entry(V self, V *a);
extern Clo g_list_2eany_24s392952474x1351014279_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1112048172x371485672(V);
V g_list_2emap_24s1112048172x371485672_entry(V self, V *a);
extern Clo g_list_2emap_24s1112048172x371485672_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
Clo g_heff_2ecompile_2esimplify_2eletsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletsOf_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eletsOf_24dps(V v_x1_240, V v_body_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(2LL), v_body_241);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x11_243, 0);
      V v_a_246 = heff_field(v_x11_243, 1);
      V v_cell_247 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_245), heff_dup(v_a_246), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_rest_244;
      V t_1 = v_body_241;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_body_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eletsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eletsOf_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2ebuiltBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebuiltBy_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ebuiltBy(V v_all_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    V v_argv_247 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_249 = heff_field(v_x21_246, 0);
      V v_t_2410 = (g_list_2emap_24s1112048172x371485672(heff_dup(v_argv_247)));
      V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2410); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_247));
        V v_t_2413 = (g_std_2emap_2elookup_24s1930949324x2078207031(v_all_240, v_g_249));
        return ({ V a_0 = v_g_249; V a_1 = v_t_2412; V a_2 = v_t_2413; V r_ = (g_heff_2ecompile_2esimplify_2ebuilds(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
      } else {
        heff_drop(v_t_2411);
        return NTAG(TAG_False);
      }
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ebuiltBy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ebuiltBy(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eetaLets_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaLets_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eetaLets(V v_r_240, V v_x2_241, V v_x3_242, V v_rest_243, V v_z_244) {
top: ;
  if ((heff_dup(v_x2_241) == NTAG(TAG_True))) {
    switch (heff_tag_of(v_x3_242)) {
    case TAG_MkPair: {
      V v_bds_245 = heff_field(v_x3_242, 0);
      V v_a_246 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      V v_x2_247 = ({ V a_0 = v_r_240; V b_1 = NTAG(TAG_True); V a_2 = v_a_246; V a_3 = v_rest_243; V a_4 = v_z_244; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2eetaArg(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_x2_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_s_249 = heff_field(v_x2_247, 1);
        V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
        V v_x_2413;
        switch (heff_tag_of(v_x_248)) {
        case TAG_MkPair: {
          V v_rest_2410 = heff_field(v_x_248, 0);
          V v_argv_2411 = heff_field(v_x_248, 1);
          V v_ru_24x_248_24MkPair = heff_take_reuse_n(v_x_248, 3ULL, 2);
          V v_t_2412 = (g_heff_2ecompile_2esimplify_2eappendL_24tok2(v_ru_24x_248_24MkPair, v_bds_245, v_rest_2410));
          v_x_2413 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_t_2412, v_argv_2411});
          break;
        }
        default: heff_nomatch(v_x_248);
        }
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_2413, v_s_249});
      }
      default: return heff_nomatch(v_x2_247);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  } else {
    heff_drop(v_r_240);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_MkPair: {
      V v_bds_2414 = heff_field(v_x3_242, 0);
      V v_a_2415 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_rest_243)) {
      case TAG_MkPair: {
        V v_x_2416 = heff_dup(heff_field(v_rest_243, 0));
        v_t_2418 = v_x_2416;
        break;
      }
      default: heff_nomatch(v_rest_243);
      }
      V v_t_2419 = ({ V a_0 = v_bds_2414; V a_1 = v_a_2415; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_bds_2414); r_; });
      V v_t_2422;
      switch (heff_tag_of(v_rest_243)) {
      case TAG_MkPair: {
        V v_y_2421 = heff_field(v_rest_243, 1);
        heff_take_n(v_rest_243, 2ULL, 2);
        v_t_2422 = v_y_2421;
        break;
      }
      default: heff_nomatch(v_rest_243);
      }
      V v_x_2423 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_t_2418, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2422})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2423, v_z_244});
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eetaLets_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eetaLets(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2eargPure_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    V v_f_243 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_243, v_p_241}});
  }
  case TAG_EGlobal: {
    V v_f_245 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_245, v_p_241}});
  }
  case TAG_ELam: {
    V v_f_248 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_248, v_p_241}});
  }
  case TAG_EApp: {
    V v_f_2411 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_2411, v_p_241}});
  }
  case TAG_ELet: {
    V v_a_2413 = heff_field(v_x1_240, 1);
    V v_e_2414 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_x_2415 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_a_2413; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop(v_a_2413); r_; });
    if ((heff_dup(v_x_2415) == NTAG(TAG_True))) {
      heff_drop(v_x_2415);
      V t_0 = v_e_2414;
      V t_1 = v_p_241;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      goto top;
    } else {
      heff_drop(v_e_2414);
      heff_drop(v_x_2415);
      return ((HeffT2){{NTAG(TAG_False), v_p_241}});
    }
  }
  case TAG_ERecord: {
    V v_f_2418 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_2418, v_p_241}});
  }
  case TAG_EProj: {
    V v_f_2423 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 4); r_; });
    return ((HeffT2){{v_f_2423, v_p_241}});
  }
  case TAG_ETag: {
    V v_f_2427 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 3); r_; });
    return ((HeffT2){{v_f_2427, v_p_241}});
  }
  case TAG_EMatch: {
    V v_f_2430 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_2430, v_p_241}});
  }
  case TAG_EPrim: {
    V v_f_2432 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_2432, v_p_241}});
  }
  case TAG_EPrimCall: {
    V v_f_2435 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_2435, v_p_241}});
  }
  case TAG_ECall: {
    V v_f_2438 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_2438, v_p_241}});
  }
  case TAG_EInt: {
    V v_f_2440 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_2440, v_p_241}});
  }
  case TAG_EFloat: {
    V v_f_2442 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_2442, v_p_241}});
  }
  case TAG_EStr: {
    V v_f_2444 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_2444, v_p_241}});
  }
  case TAG_EBytes: {
    V v_f_2446 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_2446, v_p_241}});
  }
  case TAG_EFixed: {
    V v_f_2449 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_2449, v_p_241}});
  }
  case TAG_EFloat32: {
    V v_f_2451 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_2451, v_p_241}});
  }
  case TAG_EAbandon: {
    V v_f_2452 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_p_241), v_x1_240));
    return ((HeffT2){{v_f_2452, v_p_241}});
  }
  case TAG_EBool: {
    V v_f_2454 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_2454, v_p_241}});
  }
  case TAG_ESet: {
    V v_f_2458 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 3); r_; });
    return ((HeffT2){{v_f_2458, v_p_241}});
  }
  case TAG_EValues: {
    V v_f_2460 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 1); r_; });
    return ((HeffT2){{v_f_2460, v_p_241}});
  }
  case TAG_EFix: {
    V v_f_2463 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_x1_240; V r_ = (g_heff_2ecompile_2esimplify_2epureOrPartial(a_0, a_1)); heff_drop_tag(v_x1_240, 2); r_; });
    return ((HeffT2){{v_f_2463, v_p_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2emovesFirst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emovesFirst_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emovesFirst(V v_s_240, V v_a_241) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_ELet: {
    heff_drop(v_s_240);
    return NTAG(TAG_True);
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EMatch: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EBool: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_ESet: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaWanted(v_s_240, v_a_241);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2emovesFirst_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emovesFirst(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eetaFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaFor_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2eetaFor(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_argv_244, V v_s_245) {
top: ;
  V v_t_246 = (g_list_2eany_24s392952474x1351014279(heff_dup(v_s_245), v_argv_244));
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_t_247 = (g_heff_2ecompile_2esimplify_2ebeforeMoved(heff_dup(v_s_245), heff_dup(v_argv_244)));
    HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2eallPure_24cpr(v_t_247, v_s_245));
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_x_2411 = v_field_249;
      V v_s_2412 = v_field_2410;
      return ({ V a_0 = v_r_240; V a_1 = v_g_241; V a_2 = v_xs_242; V a_3 = v_b_243; V a_4 = v_argv_244; V a_5 = v_x_2411; V a_6 = v_s_2412; V r_ = (g_heff_2ecompile_2esimplify_2eetaLoop(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2411); r_; });
    }
  } else {
    heff_drop(v_r_240);
    heff_drop(v_g_241);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_t_246);
    V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_argv_244});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_s_245});
  }
}
V g_heff_2ecompile_2esimplify_2eetaFor_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eetaFor(a[0], a[1], a[2], a[3], a[4], a[5]);
}

HeffT2 g_heff_2ecompile_2esimplify_2eknownField_24cpr(V v_g_240, V v_l_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_g_240; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_it1_247 = v_field_246;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_EVar: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_ELam: {
        heff_take_n(v_it1_247, 0ULL, 2);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EApp: {
        heff_take_n(v_it1_247, 0ULL, 2);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_247, 0ULL, 3);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_ERecord: {
        V v_fs_2417 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 2);
        HeffT2 v_t_2419 = (g_heff_2ecompile_2esimplify_2efieldIn_24cpr(v_l_241, v_fs_2417));
        {
          V v_field_2421 = v_t_2419.f[1];
          int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
          if ((v_tag_2420 == ((int64_t)0ULL))) {
            V v_v_2422 = v_field_2421;
            V v_t_2423 = (g_heff_2ecompile_2eir_2eisValue(v_v_2422));
            if (((heff_dup(v_t_2423) == NTAG(TAG_True)) && heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 1))))) {
              heff_drop(v_t_2423);
              V v_t_2424 = heff_intSub(heff_take_field(v_s_242, 1), MK_INT(1LL));
              V v_t_2425 = ({ V rv_1 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_s_242, 509ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              HeffT2 v_t_2426 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(v_v_2422, v_t_2425));
              {
                V v_field_2427 = v_t_2426.f[0];
                V v_field_2428 = v_t_2426.f[1];
                V v_x_2429 = v_field_2427;
                V v_s_2430 = v_field_2428;
                return ((HeffT2){{heff_tag_n(TAG_Just, 1, (V[]){v_x_2429}), v_s_2430}});
              }
            } else {
              heff_drop(v_v_2422);
              heff_drop(v_t_2423);
              return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
            }
          } else {
            heff_drop(v_field_2421);
            return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
          }
        }
      }
      case TAG_EProj: {
        heff_take_n(v_it1_247, 0ULL, 4);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_ETag: {
        heff_take_n(v_it1_247, 0ULL, 3);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_247, 0ULL, 2);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_247, 0ULL, 2);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_ECall: {
        heff_take_n(v_it1_247, 0ULL, 2);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EFloat: {
        heff_take_na(v_it1_247, 0ULL, 1);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_247, 0ULL, 2);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_247, 0ULL, 1);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EAbandon: {
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EBool: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_ESet: {
        heff_take_n(v_it1_247, 0ULL, 3);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EValues: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      case TAG_EFix: {
        heff_take_n(v_it1_247, 0ULL, 2);
        return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_247)}});
      }
    } else {
      heff_drop(v_field_246);
      return ((HeffT2){{NTAG(TAG_Nothing), v_s_242}});
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ematchOn_str0, 6, "MkLazy");
V g_heff_2ecompile_2esimplify_2ematchOn_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchOn_lam21(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ematchOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ematchOn_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ematchOn(V v_r_240, V v_s_241, V v_arms_242) {
top: ;
  switch (heff_tag_of(v_s_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam0, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_dup(heff_field(v_s_241, 0));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam1, 1, 4, (V[]){v_g_245, v_s_241, v_arms_242, v_r_240});
  }
  case TAG_ELam: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam2, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EApp: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam3, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ELet: {
    V v_x_2459 = heff_field(v_s_241, 0);
    V v_a_2460 = heff_field(v_s_241, 1);
    V v_b_2461 = heff_field(v_s_241, 2);
    heff_take_n(v_s_241, 7ULL, 3);
    V v_m_2462 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 4), 2, (V[]){v_b_2461, v_arms_242}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam4, 1, 3, (V[]){v_m_2462, v_x_2459, v_a_2460});
  }
  case TAG_ERecord: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam5, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EProj: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam6, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ETag: {
    V v_t_2475 = heff_dup(heff_field(v_s_241, 0));
    V v_argv_2476 = heff_dup(heff_field(v_s_241, 1));
    HeffT2 v_t_2478 = ({ V a_0 = v_t_2475; V a_1 = heff_dup(v_arms_242); HeffT2 r_ = (g_heff_2ecompile_2esimplify_2efindArm_24cpr(a_0, a_1)); heff_drop(v_t_2475); r_; });
    {
      V v_field_2480 = v_t_2478.f[1];
      int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
      if ((v_tag_2479 == ((int64_t)0ULL))) {
        heff_drop_tag(v_s_241, 3);
        heff_drop(v_arms_242);
        V v_it1_2481 = v_field_2480;
        switch (heff_tag_of(v_it1_2481)) {
        case TAG_MkArm: {
          V v_vs_2483 = heff_field(v_it1_2481, 1);
          V v_b_2484 = heff_field(v_it1_2481, 2);
          heff_take_n(v_it1_2481, 6ULL, 3);
          V v_t_2485 = (g_heff_2ecompile_2esimplify_2ezipL(v_vs_2483, v_argv_2476));
          V v_t_2486 = ({ V a_0 = v_t_2485; V a_1 = v_b_2484; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2485); r_; });
          return heff_tail(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_t_2486});
        }
        default: return heff_nomatch(v_it1_2481);
        }
      } else {
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_argv_2476);
        heff_drop(v_field_2480);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam7, 1, 2, (V[]){v_s_241, v_arms_242});
      }
    }
  }
  case TAG_EMatch: {
    V v_s2_2488 = heff_field(v_s_241, 0);
    V v_arms2_2489 = heff_field(v_s_241, 1);
    V v_ru_24s_241_24EMatch = heff_take_reuse_n(v_s_241, 3ULL, 2);
    return (g_heff_2ecompile_2esimplify_2ecaseOfCase_24tok2(v_ru_24s_241_24EMatch, v_r_240, v_s2_2488, v_arms2_2489, v_arms_242));
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam8, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam9, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam10, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam11, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam12, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam13, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam14, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam15, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam16, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam17, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EBool: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam18, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ESet: {
    V v_xs_24114 = heff_field(v_s_241, 0);
    V v_a_24115 = heff_field(v_s_241, 1);
    V v_b_24116 = heff_field(v_s_241, 2);
    heff_take_n(v_s_241, 7ULL, 3);
    V v_m_24117 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 4), 2, (V[]){v_b_24116, v_arms_242}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam19, 1, 3, (V[]){v_m_24117, v_xs_24114, v_a_24115});
  }
  case TAG_EValues: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam20, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchOn_lam21, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  default: return heff_nomatch(v_s_241);
  }
}
V g_heff_2ecompile_2esimplify_2ematchOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ematchOn(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_244});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_arms_242 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = ({ V a_0 = heff_rfield(v_s_246, 2); V a_1 = v_g_245; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, a_1)); heff_drop(v_g_245); r_; });
  HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_247, v_s_246));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_x_2411 = v_field_249;
    V v_s_2412 = v_field_2410;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
    }
    case TAG_Just: {
      V v_it1_2413 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 1);
      switch (heff_tag_of(v_it1_2413)) {
      case TAG_EVar: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_ELam: {
        V v_ru_24it1_2413_24ELam = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24it1_2413_24ELam, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EApp: {
        V v_ru_24it1_2413_24EApp = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24it1_2413_24EApp, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_2413, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_ERecord: {
        V v_ru_24it1_2413_24ERecord = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24it1_2413_24ERecord, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_2413, 0ULL, 4);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_ETag: {
        V v_t2_2429 = heff_field(v_it1_2413, 0);
        V v_as2_2430 = heff_field(v_it1_2413, 1);
        V v_ts2_2431 = heff_field(v_it1_2413, 2);
        heff_take_n(v_it1_2413, 7ULL, 3);
        if (heff_strEq_c_lent(v_t2_2429, ((V)&g_heff_2ecompile_2esimplify_2ematchOn_str0), 2)) {
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_t2_2429);
          heff_drop(v_as2_2430);
          heff_drop(v_ts2_2431);
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
        } else {
          heff_drop_tag(v_s_241, 1);
          V f_ = heff_get_n(v_r_240, 3, 4);
          heff_room[0] = heff_tag_n(TAG_ETag, 3, (V[]){v_t2_2429, v_as2_2430, v_ts2_2431});
          heff_room[1] = v_arms_242;
          heff_room[2] = v_s_2412;
          if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
        }
      }
      case TAG_EMatch: {
        V v_ru_24it1_2413_24EMatch = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it1_2413_24EMatch, TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EPrimCall: {
        V v_ru_24it1_2413_24EPrimCall = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24it1_2413_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_ECall: {
        V v_ru_24it1_2413_24ECall = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24it1_2413_24ECall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EFloat: {
        heff_take_na(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EBytes: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EFixed: {
        V v_ru_24it1_2413_24EFixed = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24it1_2413_24EFixed, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EFloat32: {
        heff_take_na(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EBool: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_ESet: {
        heff_take_n(v_it1_2413, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EValues: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      case TAG_EFix: {
        V v_ru_24it1_2413_24EFix = heff_take_reuse_n(v_it1_2413, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24it1_2413_24EFix, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2412});
      }
      default: return heff_nomatch(v_it1_2413);
      }
    }
    default: return heff_nomatch(v_x_2411);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam2(V self, V *args) {
  V v_s_2455 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2455});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam3(V self, V *args) {
  V v_s_2458 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2458});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam4(V self, V *args) {
  V v_s_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  V v_x_2459 = heff_env(self)[1];
  V v_a_2460 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_s_2463}));
  switch (heff_tag_of(v_x2_2464)) {
  case TAG_MkPair: {
    V v_x_2465 = heff_field(v_x2_2464, 0);
    V v_s_2466 = heff_field(v_x2_2464, 1);
    V v_ru_24x2_2464_24MkPair = heff_take_reuse_n(v_x2_2464, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2459, v_a_2460, v_x_2465}), v_s_2466});
  }
  default: return heff_nomatch(v_x2_2464);
  }
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam5(V self, V *args) {
  V v_s_2469 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2469});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam6(V self, V *args) {
  V v_s_2474 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2474});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam7(V self, V *args) {
  V v_s_2487 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2487});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam8(V self, V *args) {
  V v_s_2491 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2491});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam9(V self, V *args) {
  V v_s_2494 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2494});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam10(V self, V *args) {
  V v_s_2497 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2497});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam11(V self, V *args) {
  V v_s_2499 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2499});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam12(V self, V *args) {
  V v_s_24101 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24101});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam13(V self, V *args) {
  V v_s_24103 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24103});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam14(V self, V *args) {
  V v_s_24105 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24105});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam15(V self, V *args) {
  V v_s_24108 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24108});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam16(V self, V *args) {
  V v_s_24110 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24110});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam17(V self, V *args) {
  V v_s_24111 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24111});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam18(V self, V *args) {
  V v_s_24113 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24113});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam19(V self, V *args) {
  V v_s_24118 = args[0];
  V v_m_24117 = heff_env(self)[0];
  V v_xs_24114 = heff_env(self)[1];
  V v_a_24115 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24119 = heff_tr(heff_call(v_m_24117, 1, (V[]){v_s_24118}));
  switch (heff_tag_of(v_x2_24119)) {
  case TAG_MkPair: {
    V v_x_24120 = heff_field(v_x2_24119, 0);
    V v_s_24121 = heff_field(v_x2_24119, 1);
    V v_ru_24x2_24119_24MkPair = heff_take_reuse_n(v_x2_24119, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24114, v_a_24115, v_x_24120}), v_s_24121});
  }
  default: return heff_nomatch(v_x2_24119);
  }
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam20(V self, V *args) {
  V v_s_24123 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24123});
}
V g_heff_2ecompile_2esimplify_2ematchOn_lam21(V self, V *args) {
  V v_s_24126 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_24126});
}
V g_heff_2ecompile_2esimplify_2erefsMade_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2esimplify_2erefsMade_24cpr(V v_x1_240, V v_h_241, V v_b_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    V v_t_244 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_242));
    V v_hs_245 = (g_heff_2ecompile_2eir_2enubI(v_t_244));
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_p_243, 8)), 4, 5);
    HeffT2 v_t_247 = ({ V a_0 = v_t_246; V a_1 = v_h_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_f_2428;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_t_2411;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_x_2410 = v_field_249;
        v_t_2411 = v_x_2410;
      } else {
        heff_drop(v_field_249);
        v_t_2411 = NTAG(TAG_Nil);
      }
      V v_t_2419 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2erefsMade_24cpr_lam0, 2, 1, (V[]){heff_dup(v_p_243)}); V a_1 = v_t_2411; V a_2 = v_hs_245; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_hs_245); r_; });
      V v_k_2420 = heff_take_field(v_p_243, 8);
      V v_vers_2421 = heff_take_field(v_k_2420, 0);
      V v_kept_2422 = heff_take_field(v_k_2420, 1);
      V v_touched_2423 = heff_take_field(v_k_2420, 2);
      V v_fresh_2424 = heff_take_field(v_k_2420, 3);
      V v_madeFresh_2425 = heff_get_n(v_k_2420, 4, 5);
      V v_t_2426 = (g_std_2emap_2einsert_24s93785294x875597928(v_madeFresh_2425, v_h_241, v_t_2419));
      V v_k_2427 = heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_vers_2421, v_kept_2422, v_touched_2423, v_fresh_2424, v_t_2426});
      v_f_2428 = ({ V rv_8 = v_k_2427; V rr_ = heff_rec_reuse_nf(v_p_243, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2428}});
  }
  case TAG_Just: {
    heff_drop(v_h_241);
    heff_drop(v_b_242);
    return ((HeffT2){{NTAG(TAG_MkUnit), v_p_243}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2esimplify_2erefsMade_24cpr_lam0(V self, V *args) {
  V v_acc_2412 = args[0];
  V v_h_2413 = args[1];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_get_n(heff_get_n(v_p_243, 7, 9), 2, 7);
  HeffT2 v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_h_2413; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_t_2414); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2417;
      heff_drop(v_x_2418);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_h_2413, v_acc_2412});
    } else {
      heff_drop(v_h_2413);
      heff_drop(v_field_2417);
      return v_acc_2412;
    }
  }
}
Clo g_heff_2ecompile_2esimplify_2einlinedCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einlinedCall_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2einlinedCall(V v_h_240, V v_lam1_241, V v_argv_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_lam1_241)) {
  case TAG_EVar: {
    V v_ru_24lam1_241_24EVar = heff_take_reuse_n(v_lam1_241, 0ULL, 1);
    V v_t_245 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EVar, TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_z_243});
  }
  case TAG_EGlobal: {
    V v_ru_24lam1_241_24EGlobal = heff_take_reuse_n(v_lam1_241, 0ULL, 1);
    V v_t_247 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EGlobal, TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_z_243});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_lam1_241, 0);
    V v_b_249 = heff_field(v_lam1_241, 1);
    V v_ru_24lam1_241_24ELam = heff_take_reuse_n(v_lam1_241, 3ULL, 2);
    V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_242));
    V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
    if (heff_intEq_c(v_t_2410, v_t_2411)) {
      heff_drop(v_h_240);
      HeffT2 v_t_2412 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(heff_tag_at_n(v_ru_24lam1_241_24ELam, TAG_ELam, 2, (V[]){v_xs_248, v_b_249}), v_z_243));
      {
        V v_field_2413 = v_t_2412.f[0];
        V v_field_2414 = v_t_2412.f[1];
        V v_x_2415 = v_field_2413;
        V v_s_2416 = v_field_2414;
        V v_x_2417 = (g_heff_2ecompile_2esimplify_2eunLam(v_x_2415, v_argv_242));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_s_2416});
      }
    } else {
      heff_drop(v_xs_248);
      heff_drop(v_b_249);
      heff_drop_cell(v_ru_24lam1_241_24ELam, 2);
      V v_t_2418 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_z_243});
    }
  }
  case TAG_EApp: {
    V v_ru_24lam1_241_24EApp = heff_take_reuse_n(v_lam1_241, 0ULL, 2);
    V v_t_2421 = heff_tag_at_n(v_ru_24lam1_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, v_z_243});
  }
  case TAG_ELet: {
    heff_take_n(v_lam1_241, 0ULL, 3);
    V v_t_2425 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2425, v_z_243});
  }
  case TAG_ERecord: {
    V v_ru_24lam1_241_24ERecord = heff_take_reuse_n(v_lam1_241, 0ULL, 2);
    V v_t_2428 = heff_tag_at_n(v_ru_24lam1_241_24ERecord, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2428, v_z_243});
  }
  case TAG_EProj: {
    heff_take_n(v_lam1_241, 0ULL, 4);
    V v_t_2433 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_z_243});
  }
  case TAG_ETag: {
    heff_take_n(v_lam1_241, 0ULL, 3);
    V v_t_2437 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, v_z_243});
  }
  case TAG_EMatch: {
    V v_ru_24lam1_241_24EMatch = heff_take_reuse_n(v_lam1_241, 0ULL, 2);
    V v_t_2440 = heff_tag_at_n(v_ru_24lam1_241_24EMatch, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2440, v_z_243});
  }
  case TAG_EPrim: {
    V v_ru_24lam1_241_24EPrim = heff_take_reuse_n(v_lam1_241, 0ULL, 1);
    V v_t_2442 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EPrim, TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2442, v_z_243});
  }
  case TAG_EPrimCall: {
    V v_ru_24lam1_241_24EPrimCall = heff_take_reuse_n(v_lam1_241, 0ULL, 2);
    V v_t_2445 = heff_tag_at_n(v_ru_24lam1_241_24EPrimCall, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2445, v_z_243});
  }
  case TAG_ECall: {
    V v_ru_24lam1_241_24ECall = heff_take_reuse_n(v_lam1_241, 0ULL, 2);
    V v_t_2448 = heff_tag_at_n(v_ru_24lam1_241_24ECall, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2448, v_z_243});
  }
  case TAG_EInt: {
    V v_ru_24lam1_241_24EInt = heff_take_reuse_n(v_lam1_241, 0ULL, 1);
    V v_t_2450 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EInt, TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2450, v_z_243});
  }
  case TAG_EFloat: {
    V v_ru_24lam1_241_24EFloat = heff_take_reuse_na(v_lam1_241, 0ULL, 1);
    V v_t_2452 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EFloat, TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2452, v_z_243});
  }
  case TAG_EStr: {
    V v_ru_24lam1_241_24EStr = heff_take_reuse_n(v_lam1_241, 0ULL, 1);
    V v_t_2454 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EStr, TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2454, v_z_243});
  }
  case TAG_EBytes: {
    V v_ru_24lam1_241_24EBytes = heff_take_reuse_n(v_lam1_241, 0ULL, 1);
    V v_t_2456 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EBytes, TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2456, v_z_243});
  }
  case TAG_EFixed: {
    V v_ru_24lam1_241_24EFixed = heff_take_reuse_n(v_lam1_241, 0ULL, 2);
    V v_t_2459 = heff_tag_at_n(v_ru_24lam1_241_24EFixed, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2459, v_z_243});
  }
  case TAG_EFloat32: {
    V v_ru_24lam1_241_24EFloat32 = heff_take_reuse_na(v_lam1_241, 0ULL, 1);
    V v_t_2461 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EFloat32, TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2461, v_z_243});
  }
  case TAG_EAbandon: {
    V v_t_2462 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2462, v_z_243});
  }
  case TAG_EBool: {
    V v_ru_24lam1_241_24EBool = heff_take_reuse_n(v_lam1_241, 0ULL, 1);
    V v_t_2464 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EBool, TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2464, v_z_243});
  }
  case TAG_ESet: {
    heff_take_n(v_lam1_241, 0ULL, 3);
    V v_t_2468 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2468, v_z_243});
  }
  case TAG_EValues: {
    V v_ru_24lam1_241_24EValues = heff_take_reuse_n(v_lam1_241, 0ULL, 1);
    V v_t_2470 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24lam1_241_24EValues, TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2470, v_z_243});
  }
  case TAG_EFix: {
    V v_ru_24lam1_241_24EFix = heff_take_reuse_n(v_lam1_241, 0ULL, 2);
    V v_t_2473 = heff_tag_at_n(v_ru_24lam1_241_24EFix, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_240}), v_argv_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2473, v_z_243});
  }
  default: return heff_nomatch(v_lam1_241);
  }
}
V g_heff_2ecompile_2esimplify_2einlinedCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2einlinedCall(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2esgItem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esgItem_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esgItem(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Fresh: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_key_243 = heff_dup(heff_rfield(v_d_242, 0));
    V v_body_244 = heff_dup(heff_rfield(v_d_242, 2));
    V v_t_245 = (g_heff_2ecompile_2esimplify_2eflat(v_body_244));
    return ({ V a_0 = v_acc_240; V a_1 = v_key_243; V a_2 = v_t_245; V r_ = (g_heff_2ecompile_2esimplify_2esgFlat(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  }
  case TAG_Kept: {
    V v_k_246 = heff_field(v_x2_241, 0);
    V v_sgSafe_248 = heff_dup(heff_rfield(v_k_246, 5));
    V v_key_249 = heff_dup(heff_rfield(v_k_246, 0));
    V v_sgTotal_2410 = heff_dup(heff_rfield(v_k_246, 6));
    V v_t_2411;
    if ((heff_dup(v_sgSafe_248) == NTAG(TAG_True))) {
      heff_drop(v_sgSafe_248);
      v_t_2411 = (g_std_2emap_2einsert_24s93785294x875597928(heff_dup(heff_rfield(v_acc_240, 0)), heff_dup(v_key_249), NTAG(TAG_MkUnit)));
    } else {
      heff_drop(v_sgSafe_248);
      v_t_2411 = heff_dup(heff_rfield(v_acc_240, 0));
    }
    V v_t_2412;
    if (heff_intLe_c_lent(MK_INT(0LL), v_sgTotal_2410, 1)) {
      v_t_2412 = (g_std_2emap_2einsert_24s93785294x875597928(heff_get_n(v_acc_240, 1, 2), v_key_249, v_sgTotal_2410));
    } else {
      heff_drop(v_key_249);
      heff_drop(v_sgTotal_2410);
      v_t_2412 = heff_get_n(v_acc_240, 1, 2);
    }
    return heff_rec_n(2, shape_safe__total, (V[]){v_t_2411, v_t_2412});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2esgItem_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2esgItem(a[0], a1); heff_drop(a1); return r;
}