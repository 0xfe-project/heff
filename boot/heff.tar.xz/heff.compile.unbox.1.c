// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_GivenOther 31238
#define TAG_GivenSame 9069
#define TAG_GivenTag 49870
#define TAG_ManyTags 51265
#define TAG_MkArm 55352
#define TAG_NoTag 1821
#define TAG_OneTag 13947
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_last 9809757
#define LBL_name 9869138
#define LBL_param 307795111
#define LBL_slots 310891087
#define LBL_tag 324116
#define LBL_tys 324872
#define LBL_vars 10107635
static uint32_t shape_at__param__tag__tys__vars[] = {LBL_at, LBL_param, LBL_tag, LBL_tys, LBL_vars};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__slots[] = {LBL_key, LBL_slots};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_heff_2ecompile_2eunbox_2eargsRw(V, V, V, V);
V g_heff_2ecompile_2eunbox_2eargsRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eargsRw_clo;
V g_heff_2ecompile_2eunbox_2ecallerCall(V, V, V, V);
V g_heff_2ecompile_2eunbox_2ecallerCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallerCall_clo;
V g_heff_2ecompile_2eunbox_2ecallerCall_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2ecallerCall_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallerCall_24tok2_clo;
V g_heff_2ecompile_2eunbox_2ecallersRw(V, V);
V g_heff_2ecompile_2eunbox_2ecallersRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallersRw_clo;
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps(V, V, V, V);
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallersRw_24dps_clo;
V g_heff_2ecompile_2eunbox_2ecallsLoopW(V, V);
V g_heff_2ecompile_2eunbox_2ecallsLoopW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallsLoopW_clo;
V g_heff_2ecompile_2eunbox_2ecallsW(V, V, V);
V g_heff_2ecompile_2eunbox_2ecallsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallsW_clo;
V g_heff_2ecompile_2eunbox_2edefWith(V, V);
V g_heff_2ecompile_2eunbox_2edefWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2edefWith_clo;
V g_heff_2ecompile_2eunbox_2eexitsWhole(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2eexitsWhole_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eexitsWhole_clo;
V g_heff_2ecompile_2eunbox_2efirstApart(V, V, V, V);
V g_heff_2ecompile_2eunbox_2efirstApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2efirstApart_clo;
V g_heff_2ecompile_2eunbox_2egivenOf(V, V);
V g_heff_2ecompile_2eunbox_2egivenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2egivenOf_clo;
V g_heff_2ecompile_2eunbox_2eisBuilt(V, V);
V g_heff_2ecompile_2eunbox_2eisBuilt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eisBuilt_clo;
V g_heff_2ecompile_2eunbox_2ejustsOf_24dps(V, V);
V g_heff_2ecompile_2eunbox_2ejustsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ejustsOf_24dps_clo;
V g_heff_2ecompile_2eunbox_2elamWholeW(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2elamWholeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2elamWholeW_clo;
V g_heff_2ecompile_2eunbox_2eloopDefs(V, V, V, V);
V g_heff_2ecompile_2eunbox_2eloopDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eloopDefs_clo;
V g_heff_2ecompile_2eunbox_2ematchRw(V, V, V, V);
V g_heff_2ecompile_2eunbox_2ematchRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ematchRw_clo;
V g_heff_2ecompile_2eunbox_2ematchRw_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2ematchRw_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ematchRw_24tok2_clo;
V g_heff_2ecompile_2eunbox_2eparamsRw(V, V, V);
V g_heff_2ecompile_2eunbox_2eparamsRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eparamsRw_clo;
V g_heff_2ecompile_2eunbox_2erw(V, V);
V g_heff_2ecompile_2eunbox_2erw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2erw_clo;
V g_heff_2ecompile_2eunbox_2erw_24dps(V, V, V, V);
V g_heff_2ecompile_2eunbox_2erw_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2erw_24dps_clo;
V g_heff_2ecompile_2eunbox_2eslotFor(V, V, V);
V g_heff_2ecompile_2eunbox_2eslotFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eslotFor_clo;
V g_heff_2ecompile_2eunbox_2eslotWith(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2eslotWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eslotWith_clo;
V g_heff_2ecompile_2eunbox_2esomeApart(V, V);
V g_heff_2ecompile_2eunbox_2esomeApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2esomeApart_clo;
V g_heff_2ecompile_2eunbox_2espread(V, V, V);
V g_heff_2ecompile_2eunbox_2espread_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2espread_clo;
V g_heff_2ecompile_2eunbox_2etakesApart(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2etakesApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2etakesApart_clo;
V g_heff_2ecompile_2eunbox_2ewholeW(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2ewholeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ewholeW_clo;
V g_heff_2ecompile_2eunbox_2ewithVars(V);
V g_heff_2ecompile_2eunbox_2ewithVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ewithVars_clo;
V g_heff_2ecompile_2eunbox_2ewrapArgs(V, V, V);
V g_heff_2ecompile_2eunbox_2ewrapArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ewrapArgs_clo;
V g_heff_2ecompile_2eunbox_2ewrapBody(V, V, V);
V g_heff_2ecompile_2eunbox_2ewrapBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ewrapBody_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s1371286946x1388406575_24cpr(V, V);
V g_list_2efind_24s1734629631x1085593985(V, V);
V g_list_2efind_24s1734629631x1085593985_entry(V self, V *a);
extern Clo g_list_2efind_24s1734629631x1085593985_clo;
HeffT2 g_list_2efind_24s1734629631x1085593985_24cpr(V, V);
V g_list_2efind_24s1734629631x1085593985_24tok1(V, V, V);
V g_list_2efind_24s1734629631x1085593985_24tok1_entry(V self, V *a);
extern Clo g_list_2efind_24s1734629631x1085593985_24tok1_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f237374790x641547121(V, V, V);
V g_list_2efoldl_24f237374790x641547121_entry(V self, V *a);
extern Clo g_list_2efoldl_24f237374790x641547121_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s825077203x853965193(V, V);
V g_list_2efoldl_24s825077203x853965193_entry(V self, V *a);
extern Clo g_list_2efoldl_24s825077203x853965193_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_prelude_2etraverse_24s1435890225x1582751312(V, V, V, V);
V g_prelude_2etraverse_24s1435890225x1582751312_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1435890225x1582751312_clo;
HeffT2 g_prelude_2etraverse_24s1512790070x1159539918_24cpr(V, V);
V g_prelude_2etraverse_24s350379375x322835164(V);
V g_prelude_2etraverse_24s350379375x322835164_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s350379375x322835164_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
Clo g_heff_2ecompile_2eunbox_2ecallsW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ecallsW_entry, 3, 0};

V g_heff_2ecompile_2eunbox_2ecallsW(V v_f_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_g_249 = heff_field(v_x31_243, 0);
      V v_argv_2410 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EApp = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_243_24EApp, v_argv_2410, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_g_249, v_t_2411});
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2413 = heff_field(v_x31_243, 1);
      V v_b_2414 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2414, v_rest_244})});
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2415;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2416 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      V v_t_2418 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x3_242_24Cons, v_fs_2416, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2418;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2419 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2419, v_rest_244});
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2424 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      V v_t_2426 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2424, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2426;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2427 = heff_field(v_x31_243, 0);
      V v_arms_2428 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2429 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2428, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2427, v_t_2429});
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2432 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V v_t_2433 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_argv_2432, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2433;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_g_2434 = heff_field(v_x31_243, 0);
      V v_argv_2435 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ECall = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_t_2436;
      if (heff_strEq_c_lent(v_g_2434, v_f_240, 1)) {
        v_t_2436 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_argv_2435), v_acc_241});
      } else {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2436 = v_acc_241;
      }
      V v_t_2437 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_243_24ECall, v_argv_2435, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_t_2436;
      V t_2 = v_t_2437;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2445 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2446 = ({ V a_0 = v_c_2445; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2445); r_; });
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2446;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2448 = heff_field(v_x31_243, 1);
      V v_b_2449 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2450 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2448, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2449, v_rest_244})});
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2450;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2451 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2452 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_es_2451, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2452;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eunbox_2ecallsW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eunbox_2ecallsW(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eunbox_2etakesApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2etakesApart_entry, 5, 0};

V g_heff_2ecompile_2eunbox_2etakesApart(V v_p_240, V v_t_241, V v_k_242, V v_s_243, V v_arms_244) {
top: ;
  switch (heff_tag_of(v_s_243)) {
  case TAG_EVar: {
    V v_y_245 = heff_field(v_s_243, 0);
    if (heff_strEq_c_lent(v_p_240, v_y_245, 0)) {
      switch (heff_tag_of(v_arms_244)) {
      case TAG_Nil: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_arms1_246 = heff_field(v_arms_244, 0);
        V v_arms2_247 = heff_field(v_arms_244, 1);
        switch (heff_tag_of(v_arms1_246)) {
        case TAG_MkArm: {
          V v_t2_248 = heff_field(v_arms1_246, 0);
          V v_vs_249 = heff_field(v_arms1_246, 1);
          switch (heff_tag_of(v_arms2_247)) {
          case TAG_Nil: {
            V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_t_241, v_t2_248, 0) && ({ V v_t_2451 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_249)); int c_ = heff_intEq_c_lent(v_t_2451, v_k_242, 0); heff_drop(v_t_2451); c_; })));
            heff_drop(v_k_242);
            return v_ret_24bool;
          }
          case TAG_Cons: {
            heff_drop(v_k_242);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_arms2_247);
          }
        }
        default: return heff_nomatch(v_arms1_246);
        }
      }
      default: return heff_nomatch(v_arms_244);
      }
    } else {
      heff_drop(v_k_242);
      return NTAG(TAG_False);
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_s_243);
  }
}
V g_heff_2ecompile_2eunbox_2etakesApart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2eunbox_2etakesApart(a0, a1, a[2], a3, a4); heff_drop(a0); heff_drop(a1); heff_drop(a3); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2eunbox_2ewholeW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ewholeW_entry, 5, 0};

V g_heff_2ecompile_2eunbox_2ewholeW(V v_p_240, V v_t_241, V v_k_242, V v_n_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_k_242);
    return v_n_243;
  }
  case TAG_Cons: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_EVar: {
      V v_y_247 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V v_t_248;
      if (heff_strEq_c_lent(v_y_247, v_p_240, 1)) {
        v_t_248 = heff_intAdd(v_n_243, MK_INT(1LL));
      } else {
        v_t_248 = v_n_243;
      }
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_t_248;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ELam: {
      V v_b_2411 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_b_2411, v_rest_246});
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2412 = heff_field(v_x51_245, 0);
      V v_argv_2413 = heff_field(v_x51_245, 1);
      V v_ru_24x51_245_24EApp = heff_take_reuse_n(v_x51_245, 3ULL, 2);
      V v_t_2414 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x51_245_24EApp, v_argv_2413, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_f_2412, v_t_2414});
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2416 = heff_field(v_x51_245, 1);
      V v_b_2417 = heff_field(v_x51_245, 2);
      heff_take_n(v_x51_245, 6ULL, 3);
      V v_t_2418 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_a_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2417, v_rest_246})});
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2418;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2419 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 2);
      V v_t_2421 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x5_244_24Cons, v_fs_2419, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2421;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2422 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 4);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_e_2422, v_rest_246});
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2427 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 3);
      V v_t_2429 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x5_244_24Cons, v_argv_2427, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2429;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2430 = heff_field(v_x51_245, 0);
      V v_arms_2431 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 3ULL, 2);
      V v_t_2432 = (g_heff_2ecompile_2eunbox_2etakesApart(v_p_240, v_t_241, heff_dup(v_k_242), v_s_2430, v_arms_2431));
      if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_s_2430);
        heff_drop(v_t_2432);
        V v_t_2433 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2431, v_rest_246));
        V t_0 = v_p_240;
        V t_1 = v_t_241;
        V t_2 = v_k_242;
        V t_3 = v_n_243;
        V t_4 = v_t_2433;
        v_p_240 = t_0;
        v_t_241 = t_1;
        v_k_242 = t_2;
        v_n_243 = t_3;
        v_x5_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_2432);
        V v_t_2434 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2431, v_rest_246));
        V t_0 = v_p_240;
        V t_1 = v_t_241;
        V t_2 = v_k_242;
        V t_3 = v_n_243;
        V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_s_2430, v_t_2434});
        v_p_240 = t_0;
        v_t_241 = t_1;
        v_k_242 = t_2;
        v_n_243 = t_3;
        v_x5_244 = t_4;
        goto top;
      }
    }
    case TAG_EPrim: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2437 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 2);
      V v_t_2438 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x5_244_24Cons, v_argv_2437, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2438;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_2440 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 2);
      V v_t_2441 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x5_244_24Cons, v_argv_2440, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2441;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x51_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2449 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V v_t_2450 = ({ V a_0 = v_c_2449; V a_1 = v_rest_246; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2449); r_; });
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2450;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2452 = heff_field(v_x51_245, 1);
      V v_b_2453 = heff_field(v_x51_245, 2);
      heff_take_n(v_x51_245, 6ULL, 3);
      V v_t_2454 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_a_2452, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2453, v_rest_246})});
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2454;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2455 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 1);
      V v_t_2456 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x5_244_24Cons, v_es_2455, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2456;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x51_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2eunbox_2ewholeW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eunbox_2ewholeW(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eunbox_2elamWholeW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2elamWholeW_entry, 5, 0};

V g_heff_2ecompile_2eunbox_2elamWholeW(V v_p_240, V v_t_241, V v_k_242, V v_n_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_k_242);
    return v_n_243;
  }
  case TAG_Cons: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_EVar: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ELam: {
      V v_b_2410 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 2);
      V v_t_2411 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_b_2410, NTAG(TAG_Nil)});
      V v_t_2412 = (g_heff_2ecompile_2eunbox_2ewholeW(v_p_240, v_t_241, heff_dup(v_k_242), v_n_243, v_t_2411));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_t_2412;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2413 = heff_field(v_x51_245, 0);
      V v_argv_2414 = heff_field(v_x51_245, 1);
      V v_ru_24x51_245_24EApp = heff_take_reuse_n(v_x51_245, 3ULL, 2);
      V v_t_2415 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x51_245_24EApp, v_argv_2414, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_f_2413, v_t_2415});
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2417 = heff_field(v_x51_245, 1);
      V v_b_2418 = heff_field(v_x51_245, 2);
      heff_take_n(v_x51_245, 6ULL, 3);
      V v_t_2419 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_a_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2418, v_rest_246})});
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2419;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2420 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 2);
      V v_t_2422 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x5_244_24Cons, v_fs_2420, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2422;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2423 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 4);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_e_2423, v_rest_246});
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2428 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 3);
      V v_t_2430 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x5_244_24Cons, v_argv_2428, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2430;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2431 = heff_field(v_x51_245, 0);
      V v_arms_2432 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 3ULL, 2);
      V v_t_2433 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2432, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_s_2431, v_t_2433});
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2436 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 2);
      V v_t_2437 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x5_244_24Cons, v_argv_2436, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2437;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_2439 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 2ULL, 2);
      V v_t_2440 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x5_244_24Cons, v_argv_2439, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2440;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x51_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x51_245, 0ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2448 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V v_t_2449 = ({ V a_0 = v_c_2448; V a_1 = v_rest_246; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2448); r_; });
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2449;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2451 = heff_field(v_x51_245, 1);
      V v_b_2452 = heff_field(v_x51_245, 2);
      heff_take_n(v_x51_245, 6ULL, 3);
      V v_t_2453 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_a_2451, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2452, v_rest_246})});
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2453;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2454 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 1);
      V v_t_2455 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x5_244_24Cons, v_es_2454, v_rest_246));
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_t_2455;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x51_245, 0ULL, 2);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_n_243;
      V t_4 = v_rest_246;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2eunbox_2elamWholeW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eunbox_2elamWholeW(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eunbox_2eexitsWhole_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2eexitsWhole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eexitsWhole_entry, 5, 0};

V g_heff_2ecompile_2eunbox_2eexitsWhole(V v_f_240, V v_p_241, V v_t_242, V v_k_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_246);
  }
  case TAG_EGlobal: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_248);
  }
  case TAG_ELam: {
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2411);
  }
  case TAG_EApp: {
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2414);
  }
  case TAG_ELet: {
    V v_b_2417 = heff_field(v_e_244, 2);
    heff_take_n(v_e_244, 4ULL, 3);
    V t_0 = v_f_240;
    V t_1 = v_p_241;
    V t_2 = v_t_242;
    V t_3 = v_k_243;
    V t_4 = v_b_2417;
    v_f_240 = t_0;
    v_p_241 = t_1;
    v_t_242 = t_2;
    v_k_243 = t_3;
    v_e_244 = t_4;
    goto top;
  }
  case TAG_ERecord: {
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2420);
  }
  case TAG_EProj: {
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2425);
  }
  case TAG_ETag: {
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2429);
  }
  case TAG_EMatch: {
    V v_arms_2431 = heff_field(v_e_244, 1);
    heff_take_n(v_e_244, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eunbox_2eexitsWhole_lam0, 2, 4, (V[]){heff_dup(v_f_240), heff_dup(v_p_241), heff_dup(v_t_242), v_k_243}); V a_1 = MK_INT(0LL); V a_2 = v_arms_2431; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_arms_2431); r_; });
  }
  case TAG_EPrim: {
    V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2440);
  }
  case TAG_EPrimCall: {
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2443);
  }
  case TAG_ECall: {
    V v_g_2444 = heff_field(v_e_244, 0);
    V v_argv_2445 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ECall = heff_take_reuse_n(v_e_244, 3ULL, 2);
    if (heff_strEq_c_lent(v_g_2444, v_f_240, 0)) {
      heff_drop(v_k_243);
      heff_drop(v_g_2444);
      heff_drop(v_argv_2445);
      heff_drop_cell(v_ru_24e_244_24ECall, 2);
      return MK_INT(0LL);
    } else {
      V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e_244_24ECall, TAG_ECall, 2, (V[]){v_g_2444, v_argv_2445}), NTAG(TAG_Nil)});
      HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2446);
    }
  }
  case TAG_EInt: {
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2448);
  }
  case TAG_EFloat: {
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2450);
  }
  case TAG_EStr: {
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2452);
  }
  case TAG_EBytes: {
    V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2454);
  }
  case TAG_EFixed: {
    V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2457);
  }
  case TAG_EFloat32: {
    V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2459);
  }
  case TAG_EAbandon: {
    V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2460);
  }
  case TAG_EBool: {
    V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2462);
  }
  case TAG_ESet: {
    V v_b_2465 = heff_field(v_e_244, 2);
    heff_take_n(v_e_244, 4ULL, 3);
    V t_0 = v_f_240;
    V t_1 = v_p_241;
    V t_2 = v_t_242;
    V t_3 = v_k_243;
    V t_4 = v_b_2465;
    v_f_240 = t_0;
    v_p_241 = t_1;
    v_t_242 = t_2;
    v_k_243 = t_3;
    v_e_244 = t_4;
    goto top;
  }
  case TAG_EValues: {
    V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2467);
  }
  case TAG_EFix: {
    V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2eunbox_2ewholeW(v_p_241, v_t_242, v_k_243, MK_INT(0LL), v_t_2470);
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ecompile_2eunbox_2eexitsWhole_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eunbox_2eexitsWhole(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eunbox_2eexitsWhole_lam0(V self, V *args) {
  V v_n_2432 = args[0];
  V v_arm_2433 = args[1];
  V v_f_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2437;
  switch (heff_tag_of(v_arm_2433)) {
  case TAG_MkArm: {
    V v_b_2436 = heff_field(v_arm_2433, 2);
    heff_take_n(v_arm_2433, 4ULL, 3);
    v_t_2437 = v_b_2436;
    break;
  }
  default: heff_nomatch(v_arm_2433);
  }
  V v_t_2438 = ({ V a_0 = v_f_240; V a_1 = v_p_241; V a_2 = v_t_242; V a_3 = v_k_243; V a_4 = v_t_2437; V r_ = (g_heff_2ecompile_2eunbox_2eexitsWhole(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_f_240); heff_drop(v_p_241); heff_drop(v_t_242); r_; });
  return heff_intAdd(v_n_2432, v_t_2438);
}
V g_heff_2ecompile_2eunbox_2esomeApart_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2esomeApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2esomeApart_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2esomeApart(V v_p_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    V v_t_2411 = (g_heff_2ecompile_2eir_2eisValue(v_a_249));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V t_0 = v_p_240;
      V t_1 = v_b_2410;
      v_p_240 = t_0;
      v_e_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_2411);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2421 = heff_field(v_e_241, 0);
    V v_arms_2422 = heff_field(v_e_241, 1);
    V v_t_2466;
    switch (heff_tag_of(v_s_2421)) {
    case TAG_EVar: {
      V v_y_2423 = heff_field(v_s_2421, 0);
      if (heff_strEq_c_lent(v_p_240, v_y_2423, 0)) {
        switch (heff_tag_of(v_arms_2422)) {
        case TAG_Nil: {
          v_t_2466 = NTAG(TAG_False);
          break;
        }
        case TAG_Cons: {
          V v_arms2_2425 = heff_field(v_arms_2422, 1);
          switch (heff_tag_of(v_arms2_2425)) {
          case TAG_Nil: {
            v_t_2466 = NTAG(TAG_True);
            break;
          }
          case TAG_Cons: {
            v_t_2466 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_arms2_2425);
          }
          break;
        }
        default: heff_nomatch(v_arms_2422);
        }
      } else {
        v_t_2466 = NTAG(TAG_False);
      }
      break;
    }
    case TAG_EGlobal: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2421);
    }
    if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
      heff_drop(v_t_2466);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2466);
      switch (heff_tag_of(v_s_2421)) {
      case TAG_EVar: {
        switch (heff_tag_of(v_arms_2422)) {
        case TAG_Nil: {
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          HEFF_LAST return g_list_2eall(heff_clo_n(g_heff_2ecompile_2eunbox_2esomeApart_lam0, 1, 1, (V[]){heff_dup(v_p_240)}), v_arms_2422);
        }
        default: return heff_nomatch(v_arms_2422);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_s_2421);
      }
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eunbox_2esomeApart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eunbox_2esomeApart(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eunbox_2esomeApart_lam0(V self, V *args) {
  V v_a_2470 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2474;
  switch (heff_tag_of(v_a_2470)) {
  case TAG_MkArm: {
    V v_b_2473 = heff_field(v_a_2470, 2);
    heff_take_n(v_a_2470, 4ULL, 3);
    v_t_2474 = v_b_2473;
    break;
  }
  default: heff_nomatch(v_a_2470);
  }
  return ({ V a_0 = v_p_240; V a_1 = v_t_2474; V r_ = (g_heff_2ecompile_2eunbox_2esomeApart(a_0, a_1)); heff_drop(v_p_240); heff_drop(v_t_2474); r_; });
}
V g_heff_2ecompile_2eunbox_2egivenOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2egivenOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2egivenOf_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2egivenOf(V v_p_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_y_242 = heff_field(v_e_241, 0);
    if (heff_strEq_c_lent(v_y_242, v_p_240, 0)) {
      return NTAG(TAG_GivenSame);
    } else {
      return NTAG(TAG_GivenOther);
    }
  }
  case TAG_EGlobal: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_ELam: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EApp: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_ELet: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_ERecord: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EProj: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_ETag: {
    V v_t_2417 = heff_field(v_e_241, 0);
    V v_argv_2418 = heff_field(v_e_241, 1);
    V v_ts_2419 = heff_field(v_e_241, 2);
    V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2418));
    V v_t_2421 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2420, MK_INT(1LL))));
    V v_t_2423 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2egivenOf_lam0, 1, 1, (V[]){heff_dup(v_ts_2419)}), v_t_2421));
    return heff_tag_n(TAG_GivenTag, 2, (V[]){heff_dup(v_t_2417), v_t_2423});
  }
  case TAG_EMatch: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EPrim: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_ECall: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EInt: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EFloat: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EStr: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EBytes: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EFixed: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EBool: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_ESet: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EValues: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EFix: {
    return NTAG(TAG_GivenOther);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eunbox_2egivenOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eunbox_2egivenOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eunbox_2egivenOf_lam0(V self, V *args) {
  V v_i_2422 = args[0];
  V v_ts_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2422; V a_1 = v_ts_2419; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2419); r_; });
}
Clo g_heff_2ecompile_2eunbox_2eslotWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eslotWith_entry, 5, 0};

V g_heff_2ecompile_2eunbox_2eslotWith(V v_c_240, V v_i_241, V v_p_242, V v_sames_243, V v_g_244) {
top: ;
  V v_body_245 = heff_take_field(v_c_240, 1);
  V v_last_246 = heff_take_field(v_c_240, 2);
  V v_key_247 = heff_get_n(v_c_240, 0, 4);
  switch (heff_tag_of(v_g_244)) {
  case TAG_NoTag: {
    heff_drop(v_i_241);
    heff_drop(v_p_242);
    heff_drop(v_sames_243);
    heff_drop(v_body_245);
    heff_drop(v_last_246);
    heff_drop(v_key_247);
    return NTAG(TAG_Nothing);
  }
  case TAG_OneTag: {
    V v_t_248 = heff_field(v_g_244, 0);
    V v_ts_249 = heff_field(v_g_244, 1);
    V v_ru_24g_244_24OneTag = heff_take_reuse_n(v_g_244, 3ULL, 2);
    V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_249));
    V v_t_2426;
    if (heff_intLe_c(v_t_2410, MK_INT(8LL))) {
      V v_t_2443;
      switch (heff_tag_of(v_ts_249)) {
      case TAG_Nil: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_ts_249);
      }
      switch (heff_tag_of(v_t_2443)) {
      case TAG_True: {
        if (({ V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_249)); int c_ = ({ V v_c_2448 = (g_heff_2ecompile_2eunbox_2efirstApart(v_p_242, v_t_248, heff_dup(v_t_2413), v_body_245)); int c_ = (heff_dup(v_c_2448) == NTAG(TAG_True)); heff_drop(v_c_2448); c_; }); heff_drop(v_t_2413); c_; })) {
          if (({ V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_249)); int c_ = ({ V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_body_245), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2452 = (g_heff_2ecompile_2eunbox_2elamWholeW(v_p_242, v_t_248, heff_dup(v_t_2414), MK_INT(0LL), heff_dup(v_t_2415))); int c_ = heff_intEq_c_lent(v_t_2452, MK_INT(0LL), 2); heff_drop(v_t_2452); c_; }); heff_drop(v_t_2415); c_; }); heff_drop(v_t_2414); c_; })) {
            V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_249));
            V v_t_2417 = heff_tag_at_n(v_ru_24g_244_24OneTag, TAG_Cons, 2, (V[]){heff_dup(v_body_245), NTAG(TAG_Nil)});
            V v_t_2453 = (g_heff_2ecompile_2eunbox_2ewholeW(v_p_242, v_t_248, v_t_2416, MK_INT(0LL), v_t_2417));
            V v_k_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_249));
            V v_t_2419;
            if ((heff_dup(v_last_246) == NTAG(TAG_True))) {
              heff_drop(v_last_246);
              v_t_2419 = ({ V a_0 = v_key_247; V a_1 = v_p_242; V a_2 = v_t_248; V a_3 = v_k_2418; V a_4 = v_body_245; V r_ = (g_heff_2ecompile_2eunbox_2eexitsWhole(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_key_247); r_; });
            } else {
              heff_drop(v_body_245);
              heff_drop(v_last_246);
              heff_drop(v_key_247);
              heff_drop(v_k_2418);
              v_t_2419 = MK_INT(0LL);
            }
            V v_t_2454 = heff_intAdd(v_sames_243, v_t_2419);
            v_t_2426 = heff_intEq(v_t_2453, v_t_2454);
          } else {
            heff_drop(v_sames_243);
            heff_drop(v_body_245);
            heff_drop(v_last_246);
            heff_drop(v_key_247);
            heff_drop_cell(v_ru_24g_244_24OneTag, 2);
            v_t_2426 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_sames_243);
          heff_drop(v_body_245);
          heff_drop(v_last_246);
          heff_drop(v_key_247);
          heff_drop_cell(v_ru_24g_244_24OneTag, 2);
          v_t_2426 = NTAG(TAG_False);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_sames_243);
        heff_drop(v_body_245);
        heff_drop(v_last_246);
        heff_drop(v_key_247);
        heff_drop_cell(v_ru_24g_244_24OneTag, 2);
        v_t_2426 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2443);
      }
    } else {
      heff_drop(v_sames_243);
      heff_drop(v_body_245);
      heff_drop(v_last_246);
      heff_drop(v_key_247);
      heff_drop_cell(v_ru_24g_244_24OneTag, 2);
      v_t_2426 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2426)) {
    case TAG_True: {
      V v_t_2420 = heff_rec_n(5, shape_at__param__tag__tys__vars, (V[]){v_i_241, v_p_242, v_t_248, v_ts_249, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
    }
    case TAG_False: {
      heff_drop(v_i_241);
      heff_drop(v_p_242);
      heff_drop(v_t_248);
      heff_drop(v_ts_249);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  case TAG_ManyTags: {
    heff_drop(v_i_241);
    heff_drop(v_p_242);
    heff_drop(v_sames_243);
    heff_drop(v_body_245);
    heff_drop(v_last_246);
    heff_drop(v_key_247);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_g_244);
  }
}
V g_heff_2ecompile_2eunbox_2eslotWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eslotWith(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eunbox_2eslotFor_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2eslotFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eslotFor_entry, 3, 0};

V g_heff_2ecompile_2eunbox_2eslotFor(V v_c_240, V v_p_241, V v_i_242) {
top: ;
  V v_gs_2411 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2eslotFor_lam0, 1, 2, (V[]){heff_dup(v_i_242), heff_dup(v_p_241)}), heff_dup(heff_rfield(v_c_240, 3))));
  V v_t_2412 = (g_list_2efoldl_24f237374790x641547121(MK_INT(1LL), MK_INT(0LL), v_gs_2411));
  V v_t_2413 = ({ V a_0 = NTAG(TAG_NoTag); V a_1 = v_gs_2411; V r_ = (g_list_2efoldl_24s825077203x853965193(a_0, a_1)); heff_drop(v_gs_2411); r_; });
  return (g_heff_2ecompile_2eunbox_2eslotWith(v_c_240, v_i_242, v_p_241, v_t_2412, v_t_2413));
}
V g_heff_2ecompile_2eunbox_2eslotFor_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eslotFor(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eunbox_2eslotFor_lam0(V self, V *args) {
  V v_argv_243 = args[0];
  V v_i_242 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT3 v_t_244 = ({ V a_0 = v_i_242; V a_1 = v_argv_243; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_argv_243); r_; });
  V v_t_2410;
  {
    V v_field_246 = v_t_244.f[1];
    V v_field_247 = v_t_244.f[2];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_246;
      V v_x12_249 = v_field_247;
      heff_drop(v_x12_249);
      v_t_2410 = v_x_248;
    } else {
      heff_drop(v_field_246);
      heff_drop(v_field_247);
      v_t_2410 = NTAG(TAG_EAbandon);
    }
  }
  return ({ V a_0 = v_p_241; V a_1 = v_t_2410; V r_ = (g_heff_2ecompile_2eunbox_2egivenOf(a_0, a_1)); heff_drop(v_p_241); heff_drop(v_t_2410); r_; });
}
Clo g_heff_2ecompile_2eunbox_2ejustsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ejustsOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2ejustsOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_ms_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_s_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_ms_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eunbox_2ejustsOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2ejustsOf_24dps(a[0], a[1]);
}
Clo g_heff_2ecompile_2eunbox_2eargsRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eargsRw_entry, 4, 0};

V g_heff_2ecompile_2eunbox_2eargsRw(V v_go_240, V v_ss_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_ss_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x4_243, 0);
    V v_argv_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    HeffT2 v_t_246 = (g_list_2efind_24s1371286946x1388406575_24cpr(heff_dup(v_i_242), heff_dup(v_ss_241)));
    V v_t_2411;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        V v_s_249 = v_field_248;
        v_t_2411 = ({ V a_0 = heff_dup(v_go_240); V a_1 = v_s_249; V a_2 = v_a_244; V r_ = (g_heff_2ecompile_2eunbox_2espread(a_0, a_1, a_2)); heff_drop(v_a_244); r_; });
      } else {
        heff_drop(v_field_248);
        V v_t_2410 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_244}));
        v_t_2411 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      }
    }
    V v_t_2412 = (g_heff_2ecompile_2eunbox_2eargsRw(v_go_240, v_ss_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_argv_245));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2411, v_t_2412));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eunbox_2eargsRw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eargsRw(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eunbox_2erw_24dps_str0, 6, "$unbox");
V g_heff_2ecompile_2eunbox_2erw_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2erw_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2erw_24dps_entry, 4, 0};

V g_heff_2ecompile_2eunbox_2erw_24dps(V v_lp_240, V v_x2_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EVar = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_245 = (g_list_2efind_24s1734629631x1085593985_24cpr(v_x_244, heff_get_n(v_lp_240, 1, 2)));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_244);
        V v_s_248 = v_field_247;
        V v_tag_249 = heff_take_field(v_s_248, 2);
        V v_vars_2410 = heff_take_field(v_s_248, 4);
        V v_tys_2411 = heff_get_n(v_s_248, 3, 5);
        V v_t_2412 = (g_list_2emap_24s1809017761x1063871171_24tok1(v_ru_24x2_241_24EVar, v_vars_2410));
        return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ETag, 3, (V[]){v_tag_249, v_t_2412, v_tys_2411}));
      } else {
        heff_drop_cell(v_ru_24x2_241_24EVar, 1);
        heff_drop(v_field_247);
        return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EVar, 1, (V[]){v_x_244}));
      }
    }
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_ELam: {
    V v_xs_2414 = heff_field(v_x2_241, 0);
    V v_b_2415 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_xs_2414, heff_hole()});
    V v_u_2417 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2416));
    heff_drop(v_u_2417);
    V t_0 = v_lp_240;
    V t_1 = v_b_2415;
    V t_2 = v_cell_2416;
    V t_3 = MK_INT(1LL);
    v_lp_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2418 = heff_field(v_x2_241, 0);
    V v_argv_2419 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2420 = heff_tr(g_heff_2ecompile_2eunbox_2erw(heff_dup(v_lp_240), v_f_2418));
    V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2422 = (g_list_2emap_24tok2(v_ru_24x2_241_24EApp, v_t_2421, v_argv_2419));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2420, v_t_2422}));
  }
  case TAG_ELet: {
    V v_x_2423 = heff_field(v_x2_241, 0);
    V v_a_2424 = heff_field(v_x2_241, 1);
    V v_b_2425 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2426 = heff_tr(g_heff_2ecompile_2eunbox_2erw(heff_dup(v_lp_240), v_a_2424));
    V v_cell_2427 = heff_tag_at_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, (V[]){v_x_2423, v_t_2426, heff_hole()});
    V v_u_2428 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2427));
    heff_drop(v_u_2428);
    V t_0 = v_lp_240;
    V t_1 = v_b_2425;
    V t_2 = v_cell_2427;
    V t_3 = MK_INT(2LL);
    v_lp_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2429 = heff_field(v_x2_241, 0);
    V v_ts_2430 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2439 = (g_list_2emap_24tok2(v_ru_24x2_241_24ERecord, heff_clo_n(g_heff_2ecompile_2eunbox_2erw_24dps_lam0, 1, 1, (V[]){v_lp_240}), v_fs_2429));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2439, v_ts_2430}));
  }
  case TAG_EProj: {
    V v_e_2440 = heff_field(v_x2_241, 0);
    V v_l_2441 = heff_field(v_x2_241, 1);
    V v_sh_2442 = heff_field(v_x2_241, 2);
    V v_t_2443 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_2444 = heff_tr(g_heff_2ecompile_2eunbox_2erw(v_lp_240, v_e_2440));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2444, v_l_2441, v_sh_2442, v_t_2443}));
  }
  case TAG_ETag: {
    V v_t_2445 = heff_field(v_x2_241, 0);
    V v_argv_2446 = heff_field(v_x2_241, 1);
    V v_ts_2447 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2448 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2449 = (g_list_2emap(v_t_2448, v_argv_2446));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2445, v_t_2449, v_ts_2447}));
  }
  case TAG_EMatch: {
    V v_s_2450 = heff_field(v_x2_241, 0);
    V v_arms_2451 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2452 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
    V v_t_2492;
    switch (heff_tag_of(v_s_2450)) {
    case TAG_EVar: {
      V v_x_2453 = heff_dup(heff_field(v_s_2450, 0));
      v_t_2492 = ({ V a_0 = v_x_2453; V a_1 = heff_get_n(v_lp_240, 1, 2); V r_ = (g_list_2efind_24s1734629631x1085593985(a_0, a_1)); heff_drop(v_x_2453); r_; });
      break;
    }
    case TAG_EGlobal: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBytes: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBool: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ESet: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EValues: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_s_2450);
    }
    V v_t_2493 = ({ V a_0 = v_ru_24x2_241_24EMatch; V a_1 = v_t_2452; V a_2 = v_s_2450; V a_3 = v_arms_2451; V a_4 = v_t_2492; V r_ = heff_tr(g_heff_2ecompile_2eunbox_2ematchRw_24tok2(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2492); r_; });
    return heff_setField(v_d_242, v_i_243, v_t_2493);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EPrimCall: {
    V v_p_2495 = heff_field(v_x2_241, 0);
    V v_argv_2496 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EPrimCall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2497 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2498 = (g_list_2emap_24tok2(v_ru_24x2_241_24EPrimCall, v_t_2497, v_argv_2496));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2495, v_t_2498}));
  }
  case TAG_ECall: {
    V v_g_2499 = heff_field(v_x2_241, 0);
    V v_argv_24100 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_2499), heff_dup(heff_rfield(v_lp_240, 0)))) {
      V v_t_24101 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
      V v_t_24102 = (g_heff_2ecompile_2eunbox_2eargsRw(v_t_24101, heff_get_n(v_lp_240, 1, 2), MK_INT(0LL), v_argv_24100));
      V v_t_24103 = heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){heff_strAppend(v_g_2499, ((V)&g_heff_2ecompile_2eunbox_2erw_24dps_str0)), v_t_24102});
      return heff_setField(v_d_242, v_i_243, v_t_24103);
    } else {
      V v_t_24104 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
      V v_t_24105 = (g_list_2emap_24tok2(v_ru_24x2_241_24ECall, v_t_24104, v_argv_24100));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ECall, 2, (V[]){v_g_2499, v_t_24105}));
    }
  }
  case TAG_EInt: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EStr: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EBool: {
    V v_c_24113 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24114 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_24115 = (g_heff_2ecompile_2eir_2econdMap(v_t_24114, v_c_24113));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EBool, 1, (V[]){v_t_24115}));
  }
  case TAG_ESet: {
    V v_xs_24116 = heff_field(v_x2_241, 0);
    V v_a_24117 = heff_field(v_x2_241, 1);
    V v_b_24118 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ESet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_24119 = heff_tr(g_heff_2ecompile_2eunbox_2erw(heff_dup(v_lp_240), v_a_24117));
    V v_cell_24120 = heff_tag_at_n(v_ru_24x2_241_24ESet, TAG_ESet, 3, (V[]){v_xs_24116, v_t_24119, heff_hole()});
    V v_u_24121 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_24120));
    heff_drop(v_u_24121);
    V t_0 = v_lp_240;
    V t_1 = v_b_24118;
    V t_2 = v_cell_24120;
    V t_3 = MK_INT(2LL);
    v_lp_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EValues: {
    V v_es_24122 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24123 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_24124 = (g_list_2emap(v_t_24123, v_es_24122));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EValues, 1, (V[]){v_t_24124}));
  }
  case TAG_EFix: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eunbox_2erw_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2erw_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eunbox_2erw_24dps_lam0(V self, V *args) {
  V v_p_2431 = args[0];
  V v_lp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434;
  switch (heff_tag_of(v_p_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_dup(heff_field(v_p_2431, 0));
    v_t_2434 = v_x_2432;
    break;
  }
  default: heff_nomatch(v_p_2431);
  }
  V v_t_2437;
  switch (heff_tag_of(v_p_2431)) {
  case TAG_MkPair: {
    V v_y_2436 = heff_field(v_p_2431, 1);
    heff_take_n(v_p_2431, 2ULL, 2);
    v_t_2437 = v_y_2436;
    break;
  }
  default: heff_nomatch(v_p_2431);
  }
  V v_t_2438 = heff_tr(g_heff_2ecompile_2eunbox_2erw(v_lp_240, v_t_2437));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2434, v_t_2438});
}
Clo g_heff_2ecompile_2eunbox_2ewrapArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ewrapArgs_entry, 3, 0};

V g_heff_2ecompile_2eunbox_2ewrapArgs(V v_ss_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ss_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_ys_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_list_2efind_24s1371286946x1388406575_24cpr(heff_dup(v_i_241), heff_dup(v_ss_240)));
    V v_t_249;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_y_243);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_s_248 = v_field_247;
        v_t_249 = (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_248, 4, 5)));
      } else {
        heff_drop(v_field_247);
        v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_243}), NTAG(TAG_Nil)});
      }
    }
    V v_t_2410 = (g_heff_2ecompile_2eunbox_2ewrapArgs(v_ss_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_ys_244));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_249, v_t_2410));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eunbox_2ewrapArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2ewrapArgs(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eunbox_2ewithVars_lam0(V self, V *args);
V g_heff_2ecompile_2eunbox_2ewithVars_lam1(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ewithVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ewithVars_entry, 1, 0};

V g_heff_2ecompile_2eunbox_2ewithVars(V v_s_240) {
top: ;
  V v_param_241 = heff_take_field(v_s_240, 1);
  V v_tys_242 = heff_take_field(v_s_240, 3);
  V v_at_243 = heff_take_field(v_s_240, 0);
  V v_tag_244 = heff_get_n(v_s_240, 2, 5);
  V v_t_246 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ewithVars_lam0, 1, 1, (V[]){heff_dup(v_param_241)}), heff_dup(v_tys_242)));
  return heff_clo_n(g_heff_2ecompile_2eunbox_2ewithVars_lam1, 1, 5, (V[]){v_t_246, v_at_243, v_param_241, v_tag_244, v_tys_242});
}
V g_heff_2ecompile_2eunbox_2ewithVars_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2ewithVars(a[0]);
}
V g_heff_2ecompile_2eunbox_2ewithVars_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_param_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_245);
  return (g_heff_2ecompile_2eir_2ebaseGo(v_param_241, MK_INT(0LL)));
}
V g_heff_2ecompile_2eunbox_2ewithVars_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_t_246 = heff_env(self)[0];
  V v_at_243 = heff_env(self)[1];
  V v_param_241 = heff_env(self)[2];
  V v_tag_244 = heff_env(self)[3];
  V v_tys_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  HeffT2 v_t_248 = (g_prelude_2etraverse_24s1512790070x1159539918_24cpr(v_t_246, v_n_247));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_x_2411 = v_field_249;
    V v_n_2412 = v_field_2410;
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_rec_n(5, shape_at__param__tag__tys__vars, (V[]){v_at_243, v_param_241, v_tag_244, v_tys_242, v_x_2411}), v_n_2412});
  }
}
HEFF_LIT(g_heff_2ecompile_2eunbox_2eloopDefs_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eunbox_2eloopDefs_str1, 6, "$unbox");
HEFF_LIT(g_heff_2ecompile_2eunbox_2eloopDefs_str2, 6, "$unbox");
V g_heff_2ecompile_2eunbox_2eloopDefs_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2eloopDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eloopDefs_entry, 4, 0};

V g_heff_2ecompile_2eunbox_2eloopDefs(V v_d_240, V v_xs_241, V v_b_242, V v_ss0_243) {
top: ;
  V v_key_244 = heff_take_field(v_d_240, 0);
  V v_name_245 = heff_get_n(v_d_240, 1, 3);
  V v_m_246 = (g_prelude_2etraverse_24s350379375x322835164(heff_dup(v_ss0_243)));
  return heff_clo_n(g_heff_2ecompile_2eunbox_2eloopDefs_lam0, 1, 6, (V[]){v_m_246, v_ss0_243, v_xs_241, v_key_244, v_b_242, v_name_245});
}
V g_heff_2ecompile_2eunbox_2eloopDefs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eloopDefs(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eunbox_2eloopDefs_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_ss0_243 = heff_env(self)[1];
  V v_xs_241 = heff_env(self)[2];
  V v_key_244 = heff_env(self)[3];
  V v_b_242 = heff_env(self)[4];
  V v_name_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_m_2411 = (g_prelude_2etraverse_24s350379375x322835164(v_ss0_243));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_n_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      V v_m_2415 = (g_prelude_2etraverse_24s1435890225x1582751312(MK_INT(0LL), ((V)&g_heff_2ecompile_2eunbox_2eloopDefs_str0), MK_INT(1LL), heff_dup(v_xs_241)));
      V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2414}));
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_MkPair: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_n_2418 = heff_field(v_x2_2416, 1);
        V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
        V v_t_2419 = (g_heff_2ecompile_2eunbox_2eparamsRw(heff_dup(v_x_249), MK_INT(0LL), v_xs_241));
        V v_t_2420 = heff_tr(g_heff_2ecompile_2eunbox_2erw(heff_rec_n(2, shape_key__slots, (V[]){heff_dup(v_key_244), v_x_249}), v_b_242));
        V v_body_2421 = heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_ELam, 2, (V[]){v_t_2419, v_t_2420});
        V v_t_2422 = heff_rec_n(3, shape_key__name__body, (V[]){heff_strAppend(heff_dup(v_key_244), ((V)&g_heff_2ecompile_2eunbox_2eloopDefs_str1)), heff_dup(v_name_245), v_body_2421});
        V v_t_2423 = (g_heff_2ecompile_2eunbox_2ewrapArgs(heff_dup(v_x_2413), MK_INT(0LL), heff_dup(v_x_2417)));
        V v_t_2424 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_ECall, 2, (V[]){heff_strAppend(heff_dup(v_key_244), ((V)&g_heff_2ecompile_2eunbox_2eloopDefs_str2)), v_t_2423});
        V v_t_2425 = (g_heff_2ecompile_2eunbox_2ewrapBody(v_x_2417, v_x_2413, v_t_2424));
        V v_body_2426 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2417, v_t_2425});
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){v_key_244, v_name_245, v_body_2426}), NTAG(TAG_Nil)});
        V v_x_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2427});
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2428, v_n_2418});
      }
      default: return heff_nomatch(v_x2_2416);
      }
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eunbox_2edefWith_lam0(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam1(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam2(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam3(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam4(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam5(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam6(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam7(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam8(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam9(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam10(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam11(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam12(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam13(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam14(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam15(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam16(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam17(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam18(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam19(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam20(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam21(V self, V *args);
V g_heff_2ecompile_2eunbox_2edefWith_lam22(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2edefWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2edefWith_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2edefWith(V v_d_240, V v_ss_241) {
top: ;
  switch (heff_tag_of(v_ss_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam0, 1, 1, (V[]){v_d_240});
  }
  case TAG_Cons: {
    V v_t_246 = heff_dup(heff_rfield(v_d_240, 2));
    switch (heff_tag_of(v_t_246)) {
    case TAG_EVar: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam1, 1, 1, (V[]){v_d_240});
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam2, 1, 1, (V[]){v_d_240});
    }
    case TAG_ELam: {
      V v_xs_2413 = heff_field(v_t_246, 0);
      V v_b_2414 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      return (g_heff_2ecompile_2eunbox_2eloopDefs(v_d_240, v_xs_2413, v_b_2414, v_ss_241));
    }
    case TAG_EApp: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam3, 1, 1, (V[]){v_d_240});
    }
    case TAG_ELet: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam4, 1, 1, (V[]){v_d_240});
    }
    case TAG_ERecord: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam5, 1, 1, (V[]){v_d_240});
    }
    case TAG_EProj: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam6, 1, 1, (V[]){v_d_240});
    }
    case TAG_ETag: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam7, 1, 1, (V[]){v_d_240});
    }
    case TAG_EMatch: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam8, 1, 1, (V[]){v_d_240});
    }
    case TAG_EPrim: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam9, 1, 1, (V[]){v_d_240});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam10, 1, 1, (V[]){v_d_240});
    }
    case TAG_ECall: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam11, 1, 1, (V[]){v_d_240});
    }
    case TAG_EInt: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam12, 1, 1, (V[]){v_d_240});
    }
    case TAG_EFloat: {
      heff_take_na(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam13, 1, 1, (V[]){v_d_240});
    }
    case TAG_EStr: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam14, 1, 1, (V[]){v_d_240});
    }
    case TAG_EBytes: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam15, 1, 1, (V[]){v_d_240});
    }
    case TAG_EFixed: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam16, 1, 1, (V[]){v_d_240});
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam17, 1, 1, (V[]){v_d_240});
    }
    case TAG_EAbandon: {
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam18, 1, 1, (V[]){v_d_240});
    }
    case TAG_EBool: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam19, 1, 1, (V[]){v_d_240});
    }
    case TAG_ESet: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam20, 1, 1, (V[]){v_d_240});
    }
    case TAG_EValues: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam21, 1, 1, (V[]){v_d_240});
    }
    case TAG_EFix: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      return heff_clo_n(g_heff_2ecompile_2eunbox_2edefWith_lam22, 1, 1, (V[]){v_d_240});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_ss_241);
  }
}
V g_heff_2ecompile_2eunbox_2edefWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2edefWith(a[0], a[1]);
}
V g_heff_2ecompile_2eunbox_2edefWith_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_n_242});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam1(V self, V *args) {
  V v_n_248 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_n_248});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam2(V self, V *args) {
  V v_n_2411 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, v_n_2411});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam3(V self, V *args) {
  V v_n_2417 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_n_2417});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam4(V self, V *args) {
  V v_n_2422 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_n_2422});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam5(V self, V *args) {
  V v_n_2426 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2427, v_n_2426});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam6(V self, V *args) {
  V v_n_2432 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_n_2432});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam7(V self, V *args) {
  V v_n_2437 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, v_n_2437});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam8(V self, V *args) {
  V v_n_2441 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2442, v_n_2441});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam9(V self, V *args) {
  V v_n_2444 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2445, v_n_2444});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam10(V self, V *args) {
  V v_n_2448 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2449, v_n_2448});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam11(V self, V *args) {
  V v_n_2452 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2453, v_n_2452});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam12(V self, V *args) {
  V v_n_2455 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2456, v_n_2455});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam13(V self, V *args) {
  V v_n_2458 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2459, v_n_2458});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam14(V self, V *args) {
  V v_n_2461 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2462, v_n_2461});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam15(V self, V *args) {
  V v_n_2464 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2465, v_n_2464});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam16(V self, V *args) {
  V v_n_2468 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2469, v_n_2468});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam17(V self, V *args) {
  V v_n_2471 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2472, v_n_2471});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam18(V self, V *args) {
  V v_n_2473 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2474, v_n_2473});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam19(V self, V *args) {
  V v_n_2476 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2477, v_n_2476});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam20(V self, V *args) {
  V v_n_2481 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2482, v_n_2481});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam21(V self, V *args) {
  V v_n_2484 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2485, v_n_2484});
}
V g_heff_2ecompile_2eunbox_2edefWith_lam22(V self, V *args) {
  V v_n_2488 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2489, v_n_2488});
}
Clo g_heff_2ecompile_2eunbox_2eisBuilt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eisBuilt_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2eisBuilt(V v_s_240, V v_e_241) {
top: ;
  V v_tag_242 = heff_take_field(v_s_240, 2);
  V v_tys_243 = heff_get_n(v_s_240, 3, 5);
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2419 = heff_field(v_e_241, 0);
    V v_fs_2420 = heff_field(v_e_241, 1);
    V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_t_2419, v_tag_242, 0) && ({ V v_t_2443 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2420)); int c_ = ({ V v_t_2444 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_tys_243)); int c_ = heff_intEq_c_lent(v_t_2443, v_t_2444, 0); heff_drop(v_t_2444); c_; }); heff_drop(v_t_2443); c_; })));
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return v_ret_24bool;
  }
  case TAG_EMatch: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_tag_242);
    heff_drop(v_tys_243);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eunbox_2eisBuilt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eunbox_2eisBuilt(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps_lam1(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ecallersRw_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ecallersRw_24dps_entry, 4, 0};

V g_heff_2ecompile_2eunbox_2ecallersRw_24dps(V v_m_240, V v_x2_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EGlobal: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_xs_246, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_m_240;
    V t_1 = v_b_247;
    V t_2 = v_cell_248;
    V t_3 = MK_INT(1LL);
    v_m_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2410 = heff_field(v_x2_241, 0);
    V v_argv_2411 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2412 = (g_heff_2ecompile_2eunbox_2ecallersRw(heff_dup(v_m_240), v_f_2410));
    V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2414 = (g_list_2emap_24tok2(v_ru_24x2_241_24EApp, v_t_2413, v_argv_2411));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2412, v_t_2414}));
  }
  case TAG_ELet: {
    V v_x_2415 = heff_field(v_x2_241, 0);
    V v_a_2416 = heff_field(v_x2_241, 1);
    V v_b_2417 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2418 = (g_heff_2ecompile_2eunbox_2ecallersRw(heff_dup(v_m_240), v_a_2416));
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, (V[]){v_x_2415, v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_m_240;
    V t_1 = v_b_2417;
    V t_2 = v_cell_2419;
    V t_3 = MK_INT(2LL);
    v_m_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2421 = heff_field(v_x2_241, 0);
    V v_ts_2422 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2431 = (g_list_2emap_24tok2(v_ru_24x2_241_24ERecord, heff_clo_n(g_heff_2ecompile_2eunbox_2ecallersRw_24dps_lam0, 1, 1, (V[]){v_m_240}), v_fs_2421));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2431, v_ts_2422}));
  }
  case TAG_EProj: {
    V v_e_2432 = heff_field(v_x2_241, 0);
    V v_l_2433 = heff_field(v_x2_241, 1);
    V v_sh_2434 = heff_field(v_x2_241, 2);
    V v_t_2435 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_2436 = (g_heff_2ecompile_2eunbox_2ecallersRw(v_m_240, v_e_2432));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2436, v_l_2433, v_sh_2434, v_t_2435}));
  }
  case TAG_ETag: {
    V v_t_2437 = heff_field(v_x2_241, 0);
    V v_argv_2438 = heff_field(v_x2_241, 1);
    V v_ts_2439 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2440 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2441 = (g_list_2emap(v_t_2440, v_argv_2438));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2437, v_t_2441, v_ts_2439}));
  }
  case TAG_EMatch: {
    V v_s_2442 = heff_field(v_x2_241, 0);
    V v_arms_2443 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2444 = (g_heff_2ecompile_2eunbox_2ecallersRw(heff_dup(v_m_240), v_s_2442));
    V v_go_2445 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2460 = (g_list_2emap_24tok2(v_ru_24x2_241_24EMatch, heff_clo_n(g_heff_2ecompile_2eunbox_2ecallersRw_24dps_lam1, 1, 1, (V[]){v_go_2445}), v_arms_2443));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2444, v_t_2460}));
  }
  case TAG_EPrim: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EPrimCall: {
    V v_p_2462 = heff_field(v_x2_241, 0);
    V v_argv_2463 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EPrimCall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2465 = (g_list_2emap_24tok2(v_ru_24x2_241_24EPrimCall, v_t_2464, v_argv_2463));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2462, v_t_2465}));
  }
  case TAG_ECall: {
    V v_g_2466 = heff_field(v_x2_241, 0);
    V v_argv_2467 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){heff_dup(v_m_240)}));
    V v_t_2469 = ({ V a_0 = v_m_240; V a_1 = v_g_2466; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, a_1)); heff_drop(v_m_240); r_; });
    V v_t_2470 = ({ V a_0 = v_ru_24x2_241_24ECall; V a_1 = v_t_2468; V a_2 = v_g_2466; V a_3 = v_argv_2467; V a_4 = v_t_2469; V r_ = (g_heff_2ecompile_2eunbox_2ecallerCall_24tok2(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2469); r_; });
    return heff_setField(v_d_242, v_i_243, v_t_2470);
  }
  case TAG_EInt: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFloat: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EStr: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EBytes: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFixed: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFloat32: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EAbandon: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EBool: {
    V v_c_2478 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2479 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2480 = (g_heff_2ecompile_2eir_2econdMap(v_t_2479, v_c_2478));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EBool, 1, (V[]){v_t_2480}));
  }
  case TAG_ESet: {
    V v_xs_2481 = heff_field(v_x2_241, 0);
    V v_a_2482 = heff_field(v_x2_241, 1);
    V v_b_2483 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ESet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2484 = (g_heff_2ecompile_2eunbox_2ecallersRw(heff_dup(v_m_240), v_a_2482));
    V v_cell_2485 = heff_tag_at_n(v_ru_24x2_241_24ESet, TAG_ESet, 3, (V[]){v_xs_2481, v_t_2484, heff_hole()});
    V v_u_2486 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2485));
    heff_drop(v_u_2486);
    V t_0 = v_m_240;
    V t_1 = v_b_2483;
    V t_2 = v_cell_2485;
    V t_3 = MK_INT(2LL);
    v_m_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EValues: {
    V v_es_2487 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2488 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2489 = (g_list_2emap(v_t_2488, v_es_2487));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EValues, 1, (V[]){v_t_2489}));
  }
  case TAG_EFix: {
    heff_drop(v_m_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2ecallersRw_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps_lam0(V self, V *args) {
  V v_p_2423 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426;
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_dup(heff_field(v_p_2423, 0));
    v_t_2426 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_p_2423);
  }
  V v_t_2429;
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkPair: {
    V v_y_2428 = heff_field(v_p_2423, 1);
    heff_take_n(v_p_2423, 2ULL, 2);
    v_t_2429 = v_y_2428;
    break;
  }
  default: heff_nomatch(v_p_2423);
  }
  V v_t_2430 = (g_heff_2ecompile_2eunbox_2ecallersRw(v_m_240, v_t_2429));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_t_2430});
}
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps_lam1(V self, V *args) {
  V v_a_2446 = args[0];
  V v_go_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450;
  switch (heff_tag_of(v_a_2446)) {
  case TAG_MkArm: {
    V v_t_2447 = heff_dup(heff_field(v_a_2446, 0));
    v_t_2450 = v_t_2447;
    break;
  }
  default: heff_nomatch(v_a_2446);
  }
  V v_t_2454;
  switch (heff_tag_of(v_a_2446)) {
  case TAG_MkArm: {
    V v_vs_2452 = heff_dup(heff_field(v_a_2446, 1));
    v_t_2454 = v_vs_2452;
    break;
  }
  default: heff_nomatch(v_a_2446);
  }
  V v_t_2458;
  switch (heff_tag_of(v_a_2446)) {
  case TAG_MkArm: {
    V v_b_2457 = heff_field(v_a_2446, 2);
    heff_take_n(v_a_2446, 4ULL, 3);
    v_t_2458 = v_b_2457;
    break;
  }
  default: heff_nomatch(v_a_2446);
  }
  V v_t_2459 = heff_tr(heff_call(v_go_2445, 1, (V[]){v_t_2458}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2450, v_t_2454, v_t_2459});
}
Clo g_heff_2ecompile_2eunbox_2ecallsLoopW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ecallsLoopW_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2ecallsLoopW(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_argv_249 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24EApp, v_argv_249, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2410});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = v_m_240;
      V t_1 = v_t_2414;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2417 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x2_241_24Cons, v_fs_2415, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2417;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2418, v_rest_243});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2423 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      V v_t_2425 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2423, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2425;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2426 = heff_field(v_x21_242, 0);
      V v_arms_2427 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2428 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2426, v_t_2428});
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2431 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2432 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2431, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2432;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_g_2433 = heff_field(v_x21_242, 0);
      V v_argv_2434 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      HeffT2 v_t_2435 = ({ V a_0 = v_m_240; V a_1 = v_g_2433; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_g_2433); r_; });
      {
        V v_field_2437 = v_t_2435.f[1];
        int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
        if ((v_tag_2436 == ((int64_t)0ULL))) {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_argv_2434);
          V v_x_2438 = v_field_2437;
          heff_drop(v_x_2438);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_field_2437);
          V v_t_2439 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2434, v_rest_243));
          V t_0 = v_m_240;
          V t_1 = v_t_2439;
          v_m_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2447 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2448 = ({ V a_0 = v_c_2447; V a_1 = v_rest_243; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2447); r_; });
      V t_0 = v_m_240;
      V t_1 = v_t_2448;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2450 = heff_field(v_x21_242, 1);
      V v_b_2451 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2452 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2450, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2451, v_rest_243})});
      V t_0 = v_m_240;
      V t_1 = v_t_2452;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2453 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2454 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_es_2453, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2454;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_m_240;
      V t_1 = v_rest_243;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eunbox_2ecallsLoopW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eunbox_2ecallsLoopW(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eunbox_2ecallerCall_24tok2_str0, 6, "$unbox");
V g_heff_2ecompile_2eunbox_2ecallerCall_24tok2_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ecallerCall_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ecallerCall_24tok2_entry, 5, 0};

V g_heff_2ecompile_2eunbox_2ecallerCall_24tok2(V v_tok_240, V v_go_241, V v_g_242, V v_argv_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_list_2emap(v_go_241, v_argv_243));
    return heff_tag_at_n(v_tok_240, TAG_ECall, 2, (V[]){v_g_242, v_t_245});
  }
  case TAG_Just: {
    V v_ss_246 = heff_field(v_x4_244, 0);
    V v_t_2415 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2eunbox_2ecallerCall_24tok2_lam0, 1, 1, (V[]){heff_dup(v_argv_243)}), v_ss_246));
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_t_2415);
      V v_t_2416 = (g_heff_2ecompile_2eunbox_2eargsRw(v_go_241, heff_dup(v_ss_246), MK_INT(0LL), v_argv_243));
      return heff_tag_at_n(v_tok_240, TAG_ECall, 2, (V[]){heff_strAppend(v_g_242, ((V)&g_heff_2ecompile_2eunbox_2ecallerCall_24tok2_str0)), v_t_2416});
    } else {
      heff_drop(v_t_2415);
      V v_t_2417 = (g_list_2emap(v_go_241, v_argv_243));
      return heff_tag_at_n(v_tok_240, TAG_ECall, 2, (V[]){v_g_242, v_t_2417});
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_heff_2ecompile_2eunbox_2ecallerCall_24tok2_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2eunbox_2ecallerCall_24tok2(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ecompile_2eunbox_2ecallerCall_24tok2_lam0(V self, V *args) {
  V v_s_247 = args[0];
  V v_argv_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT3 v_t_248 = ({ V a_0 = heff_dup(heff_rfield(v_s_247, 0)); V a_1 = v_argv_243; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_argv_243); r_; });
  V v_t_2414;
  {
    V v_field_2410 = v_t_248.f[1];
    V v_field_2411 = v_t_248.f[2];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x_2412 = v_field_2410;
      V v_x12_2413 = v_field_2411;
      heff_drop(v_x12_2413);
      v_t_2414 = v_x_2412;
    } else {
      heff_drop(v_field_2410);
      heff_drop(v_field_2411);
      v_t_2414 = NTAG(TAG_EAbandon);
    }
  }
  return ({ V a_0 = v_s_247; V a_1 = v_t_2414; V r_ = (g_heff_2ecompile_2eunbox_2eisBuilt(a_0, a_1)); heff_drop(v_t_2414); r_; });
}