// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_Describe 2650
#define TAG_ForNominative 23095
#define TAG_MkSyn 7342
#define TAG_Nom 25944
#define TAG_SIs 29577
#define LBL_elabFor 712452832
#define LBL_evidence 1128105991
#define LBL_globals 352931696
#define LBL_insts 301719303
#define LBL_lams 9809570
#define LBL_named 305943379
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_stx 323761
#define LBL_val 326043
static uint32_t shape_scope__globals__elabFor__lams__self__insts__named__evidence[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts, LBL_named, LBL_evidence};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2erules_2eapplyResultFirst_2eheadEnv_240(V, V);
V g_heff_2eelab_2erules_2eapplyResultFirst_2eheadEnv_240_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapplyResultFirst_2eheadEnv_240_clo;
V g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241(V, V);
V g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_clo;
Clo g_heff_2eelab_2erules_2eapplyResultFirst_2eheadEnv_240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapplyResultFirst_2eheadEnv_240_entry, 2, 0};

V g_heff_2eelab_2erules_2eapplyResultFirst_2eheadEnv_240(V v_nominal_240, V v_e_241) {
top: ;
  if ((heff_dup(v_nominal_240) == NTAG(TAG_True))) {
    return ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_241, 251ULL, 8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  } else {
    return v_e_241;
  }
}
V g_heff_2eelab_2erules_2eapplyResultFirst_2eheadEnv_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eapplyResultFirst_2eheadEnv_240(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_entry, 2, 0};

V g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241(V v_nominal_240, V v_s_241) {
top: ;
  if ((heff_dup(v_nominal_240) == NTAG(TAG_True))) {
    return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_lam0, 1, 1, (V[]){v_s_241})});
  } else {
    return v_s_241;
  }
}
V g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_lam3(V self, V *args) {
  V v_u_2413 = args[0];
  V v_val_2412 = heff_env(self)[0];
  heff_drop(v_u_2413);
  heff_clo_take(self, 1);
  V v_x1_2414 = heff_tr(heff_call(v_val_2412, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2418;
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_Nom: {
    V v_x_2415 = heff_field(v_x1_2414, 0);
    heff_take_n(v_x1_2414, 1ULL, 1);
    v_t_2418 = v_x_2415;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2414, 0ULL, 1);
    v_t_2418 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2417 = heff_field(v_x1_2414, 0);
    heff_take_n(v_x1_2414, 1ULL, 1);
    v_t_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x1_2414);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2418});
}
V g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_res_249 = heff_field(v_x_248, 0);
    V v_t_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_stx_2411 = heff_take_field(v_res_249, 0);
    V v_val_2412 = heff_take_field(v_res_249, 1);
    V v_t_2419 = ({ V rv_0 = heff_tag_n(TAG_SIs, 1, (V[]){v_stx_2411}); V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_lam3, 1, 1, (V[]){v_val_2412}); V rr_ = heff_rec_reuse_nf(v_res_249, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    heff_clo_take(self, 1);
    V f_ = v_k_247;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, v_t_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_lam2, 1, 1, (V[]){v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_c_245;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_243 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    V v_t_244 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_242, 251ULL, 8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_245 = heff_tr(heff_call(v_f_243, 1, (V[]){v_t_244}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eapplyResultFirst_2emarkedIf_241_lam1, 2, 1, (V[]){v_c_245});
}