// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_blank 295177582
#define LBL_col 308218
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_env 310119
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_inl 313953
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_k 325
#define LBL_kind 9787483
#define LBL_lastTok 184780060
#define LBL_lead 9813027
#define LBL_line 9817275
#define LBL_n 328
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_offset 927361982
#define LBL_out 319944
#define LBL_pending 1696753626
#define LBL_prevEnd 2061122539
#define LBL_raw 322210
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_toks 10061290
#define LBL_trail 311979552
static uint32_t shape_ix__line[] = {LBL_ix, LBL_line};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_line__offset__out[] = {LBL_line, LBL_offset, LBL_out};
static uint32_t shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k[] = {LBL_prevEnd, LBL_n, LBL_toks, LBL_pending, LBL_inl, LBL_lead, LBL_inline, LBL_trail, LBL_lastTok, LBL_k};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
static uint32_t shape_text__blank[] = {LBL_text, LBL_blank};
static uint32_t shape_toks__env[] = {LBL_toks, LBL_env};
V g_array_2efoldlFrom_24s2074357832x1065736523(V, V, V, V, V);
V g_array_2efoldlFrom_24s2074357832x1065736523_entry(V self, V *a);
extern Clo g_array_2efoldlFrom_24s2074357832x1065736523_clo;
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void);
V g_heff_2esyntax_2efmt_2etokens_2eattach(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eattach_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2eattach_clo;
V g_heff_2esyntax_2efmt_2etokens_2ecountNl(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2ecountNl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2ecountNl_clo;
V g_heff_2esyntax_2efmt_2etokens_2eemptyStA_get(void);
V g_heff_2esyntax_2efmt_2etokens_2einlineAt(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2einlineAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2einlineAt_clo;
V g_heff_2esyntax_2efmt_2etokens_2elineElem(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2elineElem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2elineElem_clo;
V g_heff_2esyntax_2efmt_2etokens_2eplainGo(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2eplainGo_clo;
V g_heff_2esyntax_2efmt_2etokens_2estep(V, V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2estep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2estep_clo;
V g_heff_2esyntax_2efmt_2etokens_2estepCmt(V, V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2estepCmt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2estepCmt_clo;
V g_heff_2esyntax_2efmt_2etokens_2estepTok(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2estepTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2estepTok_clo;
V g_heff_2esyntax_2efmt_2etokens_2estepTrail(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2estepTrail_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2estepTrail_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1872971975x1696014049(V, V, V);
V g_list_2efoldl_24s1872971975x1696014049_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1872971975x1696014049_clo;
V g_list_2emap_24s1409451498x400757684(V);
V g_list_2emap_24s1409451498x400757684_entry(V self, V *a);
extern Clo g_list_2emap_24s1409451498x400757684_clo;
V g_list_2emap_24s32026788x2029987799(V);
V g_list_2emap_24s32026788x2029987799_entry(V self, V *a);
extern Clo g_list_2emap_24s32026788x2029987799_clo;
V g_list_2esortBy_24s655524619x299640735(V);
V g_list_2esortBy_24s655524619x299640735_entry(V self, V *a);
extern Clo g_list_2esortBy_24s655524619x299640735_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
Clo g_heff_2esyntax_2efmt_2etokens_2ecountNl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2etokens_2ecountNl_entry, 3, 0};

V g_heff_2esyntax_2efmt_2etokens_2ecountNl(V v_s_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_b_242), heff_dup(v_a_241))) {
    heff_drop(v_s_240);
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return MK_INT(0LL);
  } else {
    V v_t_245;
    if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_a_241, 0), MK_INT(10LL))) {
      v_t_245 = MK_INT(1LL);
    } else {
      v_t_245 = MK_INT(0LL);
    }
    V v_t_246 = (g_heff_2esyntax_2efmt_2etokens_2ecountNl(v_s_240, heff_intAdd(v_a_241, MK_INT(1LL)), v_b_242));
    return heff_intAdd(v_t_245, v_t_246);
  }
}
V g_heff_2esyntax_2efmt_2etokens_2ecountNl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2etokens_2ecountNl(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2etokens_2einlineAt_str0, 2, "{-");
Clo g_heff_2esyntax_2efmt_2etokens_2einlineAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2etokens_2einlineAt_entry, 3, 0};

V g_heff_2esyntax_2efmt_2etokens_2einlineAt(V v_elems_240, V v_k_241, V v_e_242) {
top: ;
  V v_t_243 = heff_strSlice(heff_take_field(v_e_242, 3), MK_INT(0LL), MK_INT(2LL));
  if (heff_strEq_c(v_t_243, ((V)&g_heff_2esyntax_2efmt_2etokens_2einlineAt_str0))) {
    V v_i_245 = heff_intAdd(v_k_241, MK_INT(1LL));
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_245))) {
      if (heff_intLt_c(heff_dup(v_i_245), heff_arrayLength_lent(v_elems_240, 0))) {
        V v_n_248 = heff_arrayIndex(v_elems_240, v_i_245);
        V v_t_249 = heff_take_field(v_n_248, 2);
        switch (heff_tag_of(v_t_249)) {
        case TAG_Nothing: {
          heff_drop_rec(v_e_242, 6);
          heff_drop_rec(v_n_248, 6);
          return NTAG(TAG_False);
        }
        case TAG_Just: {
          heff_take_n(v_t_249, 0ULL, 1);
          return heff_intEq(heff_get_n(v_n_248, 4, 6), heff_get_n(v_e_242, 5, 6));
        }
        default: return heff_nomatch(v_t_249);
        }
      } else {
        heff_drop(v_elems_240);
        heff_drop_rec(v_e_242, 6);
        heff_drop(v_i_245);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_elems_240);
      heff_drop_rec(v_e_242, 6);
      heff_drop(v_i_245);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_elems_240);
    heff_drop(v_k_241);
    heff_drop_rec(v_e_242, 6);
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2efmt_2etokens_2einlineAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2etokens_2einlineAt(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2etokens_2estepTok_str0, 6, "import");
Clo g_heff_2esyntax_2efmt_2etokens_2estepTok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2etokens_2estepTok_entry, 5, 0};

V g_heff_2esyntax_2efmt_2etokens_2estepTok(V v_src_240, V v_st_241, V v_e_242, V v_blank_243, V v_t_244) {
top: ;
  V v_t_245 = heff_intAdd(heff_dup(heff_rfield(v_st_241, 1)), MK_INT(1LL));
  V v_t_2411;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_244, 0)), ((V)&g_heff_2esyntax_2efmt_2etokens_2estepTok_str0))) {
    V v_s_247 = heff_strSlice(v_src_240, heff_dup(heff_rfield(v_t_244, 2)), heff_dup(heff_rfield(v_t_244, 3)));
    V v_t_248 = (g_prelude_2eskipSpaces(heff_dup(v_s_247), MK_INT(0LL), MK_INT(1LL)));
    V v_t_249 = heff_intSub(heff_strLength_lent(v_s_247, 0), MK_INT(1LL));
    V v_t_2410 = (g_prelude_2eskipSpaces(heff_dup(v_s_247), v_t_249, MK_INT(-1LL)));
    v_t_2411 = heff_strSlice(v_s_247, v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
  } else {
    v_t_2411 = heff_strSlice(v_src_240, heff_dup(heff_rfield(v_t_244, 2)), heff_dup(heff_rfield(v_t_244, 3)));
  }
  V v_t_2412 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){heff_take_field(v_t_244, 0), heff_take_field(v_t_244, 1), v_t_2411, heff_take_field(v_t_244, 2), heff_take_field(v_t_244, 3), heff_take_field(v_t_244, 5), heff_get_n(v_t_244, 6, 7), heff_dup(heff_rfield(v_st_241, 1)), v_blank_243});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, heff_take_field(v_st_241, 2)});
  V v_t_2414 = heff_dup(heff_rfield(v_st_241, 3));
  V v_t_2418;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nil: {
    v_t_2418 = heff_dup(heff_rfield(v_st_241, 5));
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2414, 0ULL, 2);
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_st_241, 3))));
    v_t_2418 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(heff_rfield(v_st_241, 1)), v_t_2417, heff_dup(heff_rfield(v_st_241, 5))));
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_t_2419 = heff_dup(heff_rfield(v_st_241, 4));
  V v_t_2423;
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Nil: {
    v_t_2423 = heff_dup(heff_rfield(v_st_241, 6));
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2419, 0ULL, 2);
    V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_st_241, 4))));
    v_t_2423 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(heff_rfield(v_st_241, 1)), v_t_2422, heff_dup(heff_rfield(v_st_241, 6))));
    break;
  }
  default: heff_nomatch(v_t_2419);
  }
  V v_t_2424 = heff_rec_n(2, shape_ix__line, (V[]){heff_take_field(v_st_241, 1), heff_dup(heff_rfield(v_e_242, 5))});
  V v_t_2425 = heff_intAdd(heff_take_field(v_st_241, 9), MK_INT(1LL));
  return ({ V rv_0 = heff_get_n(v_e_242, 5, 6); V rv_1 = v_t_245; V rv_2 = v_t_2413; V rv_3 = NTAG(TAG_Nil); V rv_4 = NTAG(TAG_Nil); V rv_5 = v_t_2418; V rv_6 = v_t_2423; V rv_8 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2424}); V rv_9 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_st_241, 128ULL, 10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, 49152u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2esyntax_2efmt_2etokens_2estepTok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2etokens_2estepTok(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2etokens_2estepTrail_str0, 1, " ");
Clo g_heff_2esyntax_2efmt_2etokens_2estepTrail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2etokens_2estepTrail_entry, 3, 0};

V g_heff_2esyntax_2efmt_2etokens_2estepTrail(V v_st_240, V v_e_241, V v_lt_242) {
top: ;
  V v_m_243 = heff_take_field(v_st_240, 7);
  V v_ix_244 = heff_dup(heff_rfield(v_lt_242, 0));
  V v_text_245 = heff_take_field(v_e_241, 3);
  V v_t_246 = (g_map_2elookup_24s567992785x1569911877(heff_dup(v_ix_244), v_m_243));
  V v_t_249;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_t_249 = (g_map_2einsert_24s1689409319x1710080871(v_ix_244, v_text_245, v_m_243));
    break;
  }
  case TAG_Just: {
    V v_old_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    V v_t_248 = heff_strAppend(v_old_247, heff_strAppend(((V)&g_heff_2esyntax_2efmt_2etokens_2estepTrail_str0), v_text_245));
    v_t_249 = (g_map_2einsert_24s1689409319x1710080871(v_ix_244, v_t_248, v_m_243));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_2410 = ({ V rv_1 = heff_dup(heff_rfield(v_e_241, 5)); V rr_ = heff_rec_reuse_nf(v_lt_242, 1ULL, 2, shape_ix__line, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2411 = heff_intAdd(heff_take_field(v_st_240, 9), MK_INT(1LL));
  return ({ V rv_0 = heff_get_n(v_e_241, 5, 6); V rv_7 = v_t_249; V rv_8 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2410}); V rv_9 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_st_240, 126ULL, 10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, 16380u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2esyntax_2efmt_2etokens_2estepTrail_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2etokens_2estepTrail(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2efmt_2etokens_2estepCmt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2etokens_2estepCmt_entry, 4, 0};

V g_heff_2esyntax_2efmt_2etokens_2estepCmt(V v_elems_240, V v_st_241, V v_e_242, V v_blank_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2efmt_2etokens_2einlineAt(v_elems_240, heff_dup(heff_rfield(v_st_241, 9)), heff_dup(v_e_242)));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_blank_243);
    heff_drop(v_t_244);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_e_242, 3), heff_take_field(v_st_241, 4)});
    V v_t_246 = heff_intAdd(heff_take_field(v_st_241, 9), MK_INT(1LL));
    return ({ V rv_0 = heff_get_n(v_e_242, 5, 6); V rv_4 = v_t_245; V rv_9 = v_t_246; V rr_ = heff_rec_reuse_nf(v_st_241, 494ULL, 10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, 261372u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 9) = rv_9; rr_; });
  } else {
    heff_drop(v_t_244);
    V v_t_247 = heff_dup(heff_rfield(v_st_241, 8));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      V v_t_248 = heff_rec_n(2, shape_text__blank, (V[]){heff_take_field(v_e_242, 3), v_blank_243});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_take_field(v_st_241, 3)});
      V v_t_2410 = heff_intAdd(heff_take_field(v_st_241, 9), MK_INT(1LL));
      return ({ V rv_0 = heff_get_n(v_e_242, 5, 6); V rv_3 = v_t_249; V rv_9 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_st_241, 502ULL, 10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, 261948u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 9) = rv_9; rr_; });
    }
    case TAG_Just: {
      V v_lt_2411 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      if (heff_intEq_c(heff_dup(heff_rfield(v_lt_2411, 1)), heff_dup(heff_rfield(v_e_242, 4)))) {
        V v_t_2413 = heff_dup(heff_rfield(v_st_241, 3));
        switch (heff_tag_of(v_t_2413)) {
        case TAG_Nil: {
          V v_t_2414 = heff_dup(heff_rfield(v_st_241, 4));
          switch (heff_tag_of(v_t_2414)) {
          case TAG_Nil: {
            heff_drop(v_blank_243);
            return (g_heff_2esyntax_2efmt_2etokens_2estepTrail(v_st_241, v_e_242, v_lt_2411));
          }
          case TAG_Cons: {
            V v_ru_24t_2414_24Cons = heff_take_reuse_n(v_t_2414, 0ULL, 2);
            heff_drop_rec(v_lt_2411, 2);
            V v_t_2417 = heff_rec_n(2, shape_text__blank, (V[]){heff_take_field(v_e_242, 3), v_blank_243});
            V v_t_2418 = heff_tag_at_n(v_ru_24t_2414_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_dup(heff_rfield(v_st_241, 3))});
            V v_t_2419 = heff_intAdd(heff_take_field(v_st_241, 9), MK_INT(1LL));
            return ({ V rv_0 = heff_get_n(v_e_242, 5, 6); V rv_3 = v_t_2418; V rv_9 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_st_241, 502ULL, 10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, 261948u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 9) = rv_9; rr_; });
          }
          default: return heff_nomatch(v_t_2414);
          }
        }
        case TAG_Cons: {
          V v_ru_24t_2413_24Cons = heff_take_reuse_n(v_t_2413, 0ULL, 2);
          heff_drop_rec(v_lt_2411, 2);
          V v_t_2422 = heff_rec_n(2, shape_text__blank, (V[]){heff_take_field(v_e_242, 3), v_blank_243});
          V v_t_2423 = heff_tag_at_n(v_ru_24t_2413_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_dup(heff_rfield(v_st_241, 3))});
          V v_t_2424 = heff_intAdd(heff_take_field(v_st_241, 9), MK_INT(1LL));
          return ({ V rv_0 = heff_get_n(v_e_242, 5, 6); V rv_3 = v_t_2423; V rv_9 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_st_241, 502ULL, 10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, 261948u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 9) = rv_9; rr_; });
        }
        default: return heff_nomatch(v_t_2413);
        }
      } else {
        heff_drop_rec(v_lt_2411, 2);
        V v_t_2425 = heff_rec_n(2, shape_text__blank, (V[]){heff_take_field(v_e_242, 3), v_blank_243});
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, heff_take_field(v_st_241, 3)});
        V v_t_2427 = heff_intAdd(heff_take_field(v_st_241, 9), MK_INT(1LL));
        return ({ V rv_0 = heff_get_n(v_e_242, 5, 6); V rv_3 = v_t_2426; V rv_9 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_st_241, 502ULL, 10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, 261948u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 9) = rv_9; rr_; });
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
}
V g_heff_2esyntax_2efmt_2etokens_2estepCmt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2etokens_2estepCmt(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2efmt_2etokens_2estep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2etokens_2estep_entry, 4, 0};

V g_heff_2esyntax_2efmt_2etokens_2estep(V v_src_240, V v_elems_241, V v_st_242, V v_e_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_e_243, 2));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_src_240);
    V v_t_247 = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_st_242, 0))) && ({ V v_t_246 = heff_intSub(heff_dup(heff_rfield(v_e_243, 4)), heff_dup(heff_rfield(v_st_242, 0))); int c_ = heff_intLe_c(MK_INT(2LL), heff_dup(v_t_246)); heff_drop(v_t_246); c_; })));
    HEFF_LAST return g_heff_2esyntax_2efmt_2etokens_2estepCmt(v_elems_241, v_st_242, v_e_243, v_t_247);
  }
  case TAG_Just: {
    V v_t_248 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_elems_241);
    V v_t_2411 = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_st_242, 0))) && ({ V v_t_2410 = heff_intSub(heff_dup(heff_rfield(v_e_243, 4)), heff_dup(heff_rfield(v_st_242, 0))); int c_ = heff_intLe_c(MK_INT(2LL), heff_dup(v_t_2410)); heff_drop(v_t_2410); c_; })));
    return (g_heff_2esyntax_2efmt_2etokens_2estepTok(v_src_240, v_st_242, v_e_243, v_t_2411, v_t_248));
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2efmt_2etokens_2estep_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2etokens_2estep(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2efmt_2etokens_2elineElem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2etokens_2elineElem_entry, 3, 0};

V g_heff_2esyntax_2efmt_2etokens_2elineElem(V v_src_240, V v_acc_241, V v_e_242) {
top: ;
  V v_t_243 = (g_heff_2esyntax_2efmt_2etokens_2ecountNl(heff_dup(v_src_240), heff_dup(heff_rfield(v_acc_241, 1)), heff_dup(heff_rfield(v_e_242, 0))));
  V v_t_244 = heff_intAdd(heff_dup(heff_rfield(v_acc_241, 0)), v_t_243);
  V v_t_245 = (g_heff_2esyntax_2efmt_2etokens_2ecountNl(heff_dup(v_src_240), heff_dup(heff_rfield(v_e_242, 0)), heff_dup(heff_rfield(v_e_242, 1))));
  V v_t_246 = (g_heff_2esyntax_2efmt_2etokens_2ecountNl(heff_dup(v_src_240), heff_dup(heff_rfield(v_acc_241, 1)), heff_dup(heff_rfield(v_e_242, 0))));
  V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_acc_241, 0)), v_t_246);
  V v_t_248 = (g_heff_2esyntax_2efmt_2etokens_2ecountNl(heff_dup(v_src_240), heff_take_field(v_acc_241, 1), heff_dup(heff_rfield(v_e_242, 0))));
  V v_t_249 = heff_intAdd(heff_take_field(v_acc_241, 0), v_t_248);
  V v_t_2410 = (g_heff_2esyntax_2efmt_2etokens_2ecountNl(v_src_240, heff_dup(heff_rfield(v_e_242, 0)), heff_dup(heff_rfield(v_e_242, 1))));
  V v_t_2411 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_take_field(v_e_242, 0), heff_dup(heff_rfield(v_e_242, 1)), heff_take_field(v_e_242, 2), heff_take_field(v_e_242, 3), v_t_247, heff_intAdd(v_t_249, v_t_2410)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_get_n(v_acc_241, 2, 3)});
  return heff_rec_n(3, shape_line__offset__out, (V[]){heff_intAdd(v_t_244, v_t_245), heff_get_n(v_e_242, 1, 6), v_t_2412});
}
V g_heff_2esyntax_2efmt_2etokens_2elineElem_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2etokens_2elineElem(a[0], a[1], a[2]);
}

static V g_heff_2esyntax_2efmt_2etokens_2eemptyStA_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2etokens_2eemptyStA_st;
static V g_heff_2esyntax_2efmt_2etokens_2eemptyStA_init(void) {
  return heff_rec_n(10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, (V[]){MK_INT(-1LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nothing), MK_INT(0LL)});
}
V g_heff_2esyntax_2efmt_2etokens_2eemptyStA_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2etokens_2eemptyStA_st)) return g_heff_2esyntax_2efmt_2etokens_2eemptyStA_val;
  return heff_global(&g_heff_2esyntax_2efmt_2etokens_2eemptyStA_val, &g_heff_2esyntax_2efmt_2etokens_2eemptyStA_st, g_heff_2esyntax_2efmt_2etokens_2eemptyStA_init);
}
Clo g_heff_2esyntax_2efmt_2etokens_2eattach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2etokens_2eattach_entry, 3, 0};

V g_heff_2esyntax_2efmt_2etokens_2eattach(V v_src_240, V v_toks_241, V v_comments_242) {
top: ;
  V v_t_243 = (g_list_2emap_24s1409451498x400757684(v_toks_241));
  V v_t_244 = (g_list_2emap_24s32026788x2029987799(v_comments_242));
  V v_t_245 = (g_prelude_2e_2b_2b(v_t_243, v_t_244));
  V v_es_246 = (g_list_2esortBy_24s655524619x299640735(v_t_245));
  V v_t_247 = heff_rec_n(3, shape_line__offset__out, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)});
  V v_l_248 = ({ V a_0 = heff_dup(v_src_240); V a_1 = v_t_247; V a_2 = v_es_246; V r_ = (g_list_2efoldl_24s1872971975x1696014049(a_0, a_1, a_2)); heff_drop(v_es_246); r_; });
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_l_248, 2, 3)));
  V v_elems_2410 = heff_arrayFromList(v_t_249);
  V v_r_2411 = (g_array_2efoldlFrom_24s2074357832x1065736523(heff_dup(v_src_240), heff_dup(v_elems_2410), MK_INT(0LL), heff_dup(g_heff_2esyntax_2efmt_2etokens_2eemptyStA_get()), v_elems_2410));
  V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_r_2411, 2)));
  V v_t_2413 = heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){v_src_240, heff_take_field(v_r_2411, 5), heff_take_field(v_r_2411, 6), heff_get_n(v_r_2411, 7, 10), MK_INT(-1LL), MK_INT(-1LL), heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get())});
  return heff_rec_n(2, shape_toks__env, (V[]){heff_arrayFromList(v_t_2412), v_t_2413});
}
V g_heff_2esyntax_2efmt_2etokens_2eattach_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2etokens_2eattach(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2efmt_2etokens_2eplainGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry, 3, 0};

V g_heff_2esyntax_2efmt_2etokens_2eplainGo(V v_n_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){heff_take_field(v_t_243, 0), heff_dup(heff_rfield(v_t_243, 1)), heff_dup(heff_rfield(v_t_243, 1)), heff_take_field(v_t_243, 2), heff_take_field(v_t_243, 3), heff_take_field(v_t_243, 5), heff_get_n(v_t_243, 6, 7), heff_dup(v_n_240), NTAG(TAG_False)});
    V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
    V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_acc_241});
    V t_2 = v_rest_244;
    v_n_240 = t_0;
    v_acc_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2etokens_2eplainGo(a[0], a[1], a[2]);
}