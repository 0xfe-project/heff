// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_blank 295177582
#define LBL_col 308218
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_first 298798794
#define LBL_inl 313953
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_k 325
#define LBL_kind 9787483
#define LBL_lastTok 184780060
#define LBL_lead 9813027
#define LBL_line 9817275
#define LBL_n 328
#define LBL_pending 1696753626
#define LBL_prevEnd 2061122539
#define LBL_raw 322210
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_toks 10061290
#define LBL_trail 311979552
static uint32_t shape_ix__line[] = {LBL_ix, LBL_line};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k[] = {LBL_prevEnd, LBL_n, LBL_toks, LBL_pending, LBL_inl, LBL_lead, LBL_inline, LBL_trail, LBL_lastTok, LBL_k};
static uint32_t shape_text__blank[] = {LBL_text, LBL_blank};
V g_heff_2esyntax_2efmt_2etokens_2ecountNl(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2ecountNl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2ecountNl_clo;
V g_heff_2esyntax_2efmt_2etokens_2eemptyStA_get(void);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2eplainGo_clo;
V g_heff_2esyntax_2efmt_2etokens_2estepCmt(V, V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2estepCmt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2estepCmt_clo;
V g_heff_2esyntax_2efmt_2etokens_2estepTok(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2estepTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2estepTok_clo;
V g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
Clo g_heff_2esyntax_2efmt_2etokens_2ecountNl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2etokens_2ecountNl_entry, 3, 0};

V g_heff_2esyntax_2efmt_2etokens_2ecountNl(V v_s_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_intLe_c_lent(v_b_242, v_a_241, 0)) {
    heff_drop(v_a_241);
    return MK_INT(0LL);
  } else {
    V v_t_243;
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_a_241, 0)) == ((int64_t)10ULL))) {
      v_t_243 = MK_INT(1LL);
    } else {
      v_t_243 = MK_INT(0LL);
    }
    V v_t_244 = (g_heff_2esyntax_2efmt_2etokens_2ecountNl(v_s_240, heff_intAdd(v_a_241, MK_INT(1LL)), v_b_242));
    return heff_intAdd(v_t_243, v_t_244);
  }
}
V g_heff_2esyntax_2efmt_2etokens_2ecountNl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2etokens_2ecountNl(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2etokens_2estepTok_str0, 6, "import");
HEFF_LIT(g_heff_2esyntax_2efmt_2etokens_2estepTok_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2etokens_2estepTok_str2, 6, "import");
Clo g_heff_2esyntax_2efmt_2etokens_2estepTok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2etokens_2estepTok_entry, 5, 0};

V g_heff_2esyntax_2efmt_2etokens_2estepTok(V v_src_240, V v_st_241, V v_e_242, V v_blank_243, V v_t_244) {
top: ;
  V v_kind_245 = heff_take_field(v_t_244, 0);
  V v_text_246 = heff_take_field(v_t_244, 1);
  V v_start_247 = heff_take_field(v_t_244, 2);
  V v_end_248 = heff_take_field(v_t_244, 3);
  V v_col_249 = heff_take_field(v_t_244, 5);
  V v_first_2410 = heff_get_n(v_t_244, 6, 7);
  V v_t_2415;
  if ((heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2efmt_2etokens_2estepTok_str0), 2) && !heff_strEq_c_lent(v_text_246, ((V)&g_heff_2esyntax_2efmt_2etokens_2estepTok_str1), 2))) {
    v_t_2415 = heff_dup(v_text_246);
  } else {
    if (heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2efmt_2etokens_2estepTok_str2), 2)) {
      V v_s_2411 = heff_strSlice_lent(v_src_240, v_start_247, v_end_248, 0);
      V v_t_2412 = (g_prelude_2eskipSpaces(v_s_2411, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2413 = (heff_unbox_word(heff_strLength_lent(v_s_2411, 0)) - ((int64_t)1ULL));
      V v_t_2414 = (g_prelude_2eskipSpaces(v_s_2411, heff_box_word(v_t_2413), MK_INT(-1LL)));
      v_t_2415 = heff_strSlice(v_s_2411, v_t_2412, heff_intAdd(v_t_2414, MK_INT(1LL)));
    } else {
      v_t_2415 = heff_strSlice_lent(v_src_240, v_start_247, v_end_248, 0);
    }
  }
  V v_t_2416 = heff_dup(heff_rfield(v_st_241, 3));
  V v_t_2420;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Nil: {
    v_t_2420 = heff_dup(heff_rfield(v_st_241, 5));
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2416, 0ULL, 2);
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_st_241, 3))));
    v_t_2420 = ({ V a_0 = heff_dup(heff_rfield(v_st_241, 5)); V a_1 = heff_rfield(v_st_241, 1); V a_2 = v_t_2419; V r_ = (g_std_2eordmap_2einsert_24s1703101629x493626677(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_t_2421 = heff_dup(heff_rfield(v_st_241, 4));
  V v_t_2425;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nil: {
    v_t_2425 = heff_dup(heff_rfield(v_st_241, 6));
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2421, 0ULL, 2);
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_st_241, 4))));
    v_t_2425 = ({ V a_0 = heff_dup(heff_rfield(v_st_241, 6)); V a_1 = heff_rfield(v_st_241, 1); V a_2 = v_t_2424; V r_ = (g_std_2eordmap_2einsert_24s1703101629x493626677(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  V v_t_2426 = heff_intAdd(heff_dup(heff_rfield(v_st_241, 1)), MK_INT(1LL));
  V v_t_2427 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){v_kind_245, v_text_246, v_t_2415, v_start_247, v_end_248, v_col_249, v_first_2410, heff_dup(heff_rfield(v_st_241, 1)), v_blank_243});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, heff_take_field(v_st_241, 2)});
  V v_t_2429 = heff_rec_n(2, shape_ix__line, (V[]){heff_take_field(v_st_241, 1), heff_dup(heff_rfield(v_e_242, 5))});
  V v_t_2430 = heff_intAdd(heff_take_field(v_st_241, 9), MK_INT(1LL));
  return ({ V rv_0 = heff_get_n(v_e_242, 5, 6); V rv_1 = v_t_2426; V rv_2 = v_t_2428; V rv_3 = NTAG(TAG_Nil); V rv_4 = NTAG(TAG_Nil); V rv_5 = v_t_2420; V rv_6 = v_t_2425; V rv_8 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2429}); V rv_9 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_st_241, 128ULL, 10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, 49152u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2esyntax_2efmt_2etokens_2estepTok_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2etokens_2estepTok(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2etokens_2estepCmt_str0, 2, "{-");
HEFF_LIT(g_heff_2esyntax_2efmt_2etokens_2estepCmt_str1, 1, " ");
Clo g_heff_2esyntax_2efmt_2etokens_2estepCmt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2etokens_2estepCmt_entry, 4, 0};

V g_heff_2esyntax_2efmt_2etokens_2estepCmt(V v_elems_240, V v_st_241, V v_e_242, V v_blank_243) {
top: ;
  V v_elems_244 = v_elems_240;
  V v_k_245 = heff_dup(heff_rfield(v_st_241, 9));
  V v_e_246 = heff_dup(v_e_242);
  V v_text_247 = heff_take_field(v_e_246, 3);
  V v_endLine_248 = heff_get_n(v_e_246, 5, 6);
  V v_t_2415;
  if (heff_strEq_c(heff_strSlice(v_text_247, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2esyntax_2efmt_2etokens_2estepCmt_str0))) {
    V v_i_249 = heff_intAdd(v_k_245, MK_INT(1LL));
    if ((heff_intLe_c_lent(MK_INT(0LL), v_i_249, 1) && heff_intLt_c_lent(v_i_249, heff_arrayLength_lent(v_elems_244, 0), 2))) {
      V v_n_2410 = heff_arrayIndex(v_elems_244, v_i_249);
      V v_tok_2411 = heff_take_field(v_n_2410, 2);
      V v_startLine_2412 = heff_get_n(v_n_2410, 4, 6);
      V v_t_2413 = v_tok_2411;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        heff_drop(v_endLine_248);
        heff_drop(v_startLine_2412);
        v_t_2415 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_t_2413, 0ULL, 1);
        v_t_2415 = heff_bool(heff_intEq_c_lent(v_startLine_2412, v_endLine_248, 0));
        heff_drop(v_endLine_248);
        heff_drop(v_startLine_2412);
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
    } else {
      heff_drop(v_elems_244);
      heff_drop(v_endLine_248);
      heff_drop(v_i_249);
      v_t_2415 = NTAG(TAG_False);
    }
  } else {
    heff_drop(v_elems_244);
    heff_drop(v_k_245);
    heff_drop(v_endLine_248);
    v_t_2415 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_blank_243);
    heff_drop(v_t_2415);
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_e_242, 3), heff_take_field(v_st_241, 4)});
    V v_t_2417 = heff_intAdd(heff_take_field(v_st_241, 9), MK_INT(1LL));
    return ({ V rv_0 = heff_get_n(v_e_242, 5, 6); V rv_4 = v_t_2416; V rv_9 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_st_241, 494ULL, 10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, 261372u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 9) = rv_9; rr_; });
  } else {
    heff_drop(v_t_2415);
    V v_t_2418 = heff_dup(heff_rfield(v_st_241, 8));
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      V v_t_2419 = heff_rec_n(2, shape_text__blank, (V[]){heff_take_field(v_e_242, 3), v_blank_243});
      V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_take_field(v_st_241, 3)});
      V v_t_2421 = heff_intAdd(heff_take_field(v_st_241, 9), MK_INT(1LL));
      return ({ V rv_0 = heff_get_n(v_e_242, 5, 6); V rv_3 = v_t_2420; V rv_9 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_st_241, 502ULL, 10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, 261948u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 9) = rv_9; rr_; });
    }
    case TAG_Just: {
      V v_lt_2422 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      V v_t_2429;
      if (heff_intEq_c(heff_dup(heff_rfield(v_lt_2422, 1)), heff_dup(heff_rfield(v_e_242, 4)))) {
        V v_t_2423 = heff_dup(heff_rfield(v_st_241, 3));
        switch (heff_tag_of(v_t_2423)) {
        case TAG_Nil: {
          V v_t_2424 = heff_dup(heff_rfield(v_st_241, 4));
          switch (heff_tag_of(v_t_2424)) {
          case TAG_Nil: {
            v_t_2429 = NTAG(TAG_True);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_t_2424, 0ULL, 2);
            v_t_2429 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_t_2424);
          }
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2423, 0ULL, 2);
          v_t_2429 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2423);
        }
      } else {
        v_t_2429 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
        heff_drop(v_blank_243);
        heff_drop(v_t_2429);
        V v_st_2430 = v_st_241;
        V v_e_2431 = v_e_242;
        V v_text_2432 = heff_take_field(v_e_2431, 3);
        V v_endLine_2433 = heff_get_n(v_e_2431, 5, 6);
        V v_lt_2434 = v_lt_2422;
        V v_m_2435 = heff_take_field(v_st_2430, 7);
        V v_ix_2436 = heff_dup(heff_rfield(v_lt_2434, 0));
        V v_text_2437 = v_text_2432;
        HeffT2 v_t_2438 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(v_m_2435, v_ix_2436));
        {
          V v_field_2440 = v_t_2438.f[1];
          int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
          V v_t_2443;
          if ((v_tag_2439 == ((int64_t)0ULL))) {
            V v_old_2441 = v_field_2440;
            V v_t_2442 = heff_strAppend(heff_strAppend(v_old_2441, ((V)&g_heff_2esyntax_2efmt_2etokens_2estepCmt_str1)), v_text_2437);
            v_t_2443 = ({ V a_0 = v_m_2435; V a_1 = v_ix_2436; V a_2 = v_t_2442; V r_ = (g_std_2eordmap_2einsert_24s1703101629x493626677(a_0, a_1, a_2)); heff_drop(v_ix_2436); heff_drop(v_t_2442); r_; });
          } else {
            heff_drop(v_field_2440);
            v_t_2443 = ({ V a_0 = v_m_2435; V a_1 = v_ix_2436; V a_2 = v_text_2437; V r_ = (g_std_2eordmap_2einsert_24s1703101629x493626677(a_0, a_1, a_2)); heff_drop(v_ix_2436); heff_drop(v_text_2437); r_; });
          }
          V v_t_2444 = ({ V rv_1 = heff_dup(v_endLine_2433); V rr_ = heff_rec_reuse_nf(v_lt_2434, 1ULL, 2, shape_ix__line, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2445 = heff_intAdd(heff_take_field(v_st_2430, 9), MK_INT(1LL));
          return ({ V rv_0 = v_endLine_2433; V rv_7 = v_t_2443; V rv_8 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2444}); V rv_9 = v_t_2445; V rr_ = heff_rec_reuse_nf(v_st_2430, 126ULL, 10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, 16380u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
        }
      } else {
        heff_drop_rec(v_lt_2422, 2);
        heff_drop(v_t_2429);
        V v_t_2446 = heff_rec_n(2, shape_text__blank, (V[]){heff_take_field(v_e_242, 3), v_blank_243});
        V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, heff_take_field(v_st_241, 3)});
        V v_t_2448 = heff_intAdd(heff_take_field(v_st_241, 9), MK_INT(1LL));
        return ({ V rv_0 = heff_get_n(v_e_242, 5, 6); V rv_3 = v_t_2447; V rv_9 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_st_241, 502ULL, 10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, 261948u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 9) = rv_9; rr_; });
      }
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
}
V g_heff_2esyntax_2efmt_2etokens_2estepCmt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2etokens_2estepCmt(a[0], a[1], a[2], a[3]);
}

static V g_heff_2esyntax_2efmt_2etokens_2eemptyStA_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2etokens_2eemptyStA_st;
static V g_heff_2esyntax_2efmt_2etokens_2eemptyStA_init(void) {
  return heff_rec_n(10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, (V[]){MK_INT(-1LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nothing), MK_INT(0LL)});
}
V g_heff_2esyntax_2efmt_2etokens_2eemptyStA_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2etokens_2eemptyStA_st)) return g_heff_2esyntax_2efmt_2etokens_2eemptyStA_val;
  return heff_global(&g_heff_2esyntax_2efmt_2etokens_2eemptyStA_val, &g_heff_2esyntax_2efmt_2etokens_2eemptyStA_st, g_heff_2esyntax_2efmt_2etokens_2eemptyStA_init);
}
Clo g_heff_2esyntax_2efmt_2etokens_2eplainGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry, 3, 0};

V g_heff_2esyntax_2efmt_2etokens_2eplainGo(V v_n_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_kind_245 = heff_take_field(v_t_243, 0);
    V v_text_246 = heff_take_field(v_t_243, 1);
    V v_start_247 = heff_take_field(v_t_243, 2);
    V v_end_248 = heff_take_field(v_t_243, 3);
    V v_col_249 = heff_take_field(v_t_243, 5);
    V v_first_2410 = heff_get_n(v_t_243, 6, 7);
    V v_t_2411 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){v_kind_245, heff_dup(v_text_246), v_text_246, v_start_247, v_end_248, v_col_249, v_first_2410, heff_dup(v_n_240), NTAG(TAG_False)});
    V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
    V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2411, v_acc_241});
    V t_2 = v_rest_244;
    v_n_240 = t_0;
    v_acc_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2etokens_2eplainGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1_str0, 6, "import");
HEFF_LIT(g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1_str2, 6, "import");
Clo g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1_entry, 6, 0};

V g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1(V v_tok_240, V v_src_241, V v_st_242, V v_e_243, V v_blank_244, V v_t_245) {
top: ;
  heff_drop_cell(v_tok_240, 1);
  V v_kind_246 = heff_take_field(v_t_245, 0);
  V v_text_247 = heff_take_field(v_t_245, 1);
  V v_start_248 = heff_take_field(v_t_245, 2);
  V v_end_249 = heff_take_field(v_t_245, 3);
  V v_col_2410 = heff_take_field(v_t_245, 5);
  V v_first_2411 = heff_get_n(v_t_245, 6, 7);
  V v_t_2416;
  if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1_str0), 2) && !heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1_str1), 2))) {
    v_t_2416 = heff_dup(v_text_247);
  } else {
    if (heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1_str2), 2)) {
      V v_s_2412 = heff_strSlice_lent(v_src_241, v_start_248, v_end_249, 0);
      V v_t_2413 = (g_prelude_2eskipSpaces(v_s_2412, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_s_2412, 0)) - ((int64_t)1ULL));
      V v_t_2415 = (g_prelude_2eskipSpaces(v_s_2412, heff_box_word(v_t_2414), MK_INT(-1LL)));
      v_t_2416 = heff_strSlice(v_s_2412, v_t_2413, heff_intAdd(v_t_2415, MK_INT(1LL)));
    } else {
      v_t_2416 = heff_strSlice_lent(v_src_241, v_start_248, v_end_249, 0);
    }
  }
  V v_t_2417 = heff_dup(heff_rfield(v_st_242, 3));
  V v_t_2421;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nil: {
    v_t_2421 = heff_dup(heff_rfield(v_st_242, 5));
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2417, 0ULL, 2);
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_st_242, 3))));
    v_t_2421 = ({ V a_0 = heff_dup(heff_rfield(v_st_242, 5)); V a_1 = heff_rfield(v_st_242, 1); V a_2 = v_t_2420; V r_ = (g_std_2eordmap_2einsert_24s1703101629x493626677(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  V v_t_2422 = heff_dup(heff_rfield(v_st_242, 4));
  V v_t_2426;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Nil: {
    v_t_2426 = heff_dup(heff_rfield(v_st_242, 6));
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2422, 0ULL, 2);
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_st_242, 4))));
    v_t_2426 = ({ V a_0 = heff_dup(heff_rfield(v_st_242, 6)); V a_1 = heff_rfield(v_st_242, 1); V a_2 = v_t_2425; V r_ = (g_std_2eordmap_2einsert_24s1703101629x493626677(a_0, a_1, a_2)); heff_drop(v_t_2425); r_; });
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  V v_t_2427 = heff_intAdd(heff_dup(heff_rfield(v_st_242, 1)), MK_INT(1LL));
  V v_t_2428 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){v_kind_246, v_text_247, v_t_2416, v_start_248, v_end_249, v_col_2410, v_first_2411, heff_dup(heff_rfield(v_st_242, 1)), v_blank_244});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, heff_take_field(v_st_242, 2)});
  V v_t_2430 = heff_rec_n(2, shape_ix__line, (V[]){heff_take_field(v_st_242, 1), heff_dup(heff_rfield(v_e_243, 5))});
  V v_t_2431 = heff_intAdd(heff_take_field(v_st_242, 9), MK_INT(1LL));
  return ({ V rv_0 = heff_get_n(v_e_243, 5, 6); V rv_1 = v_t_2427; V rv_2 = v_t_2429; V rv_3 = NTAG(TAG_Nil); V rv_4 = NTAG(TAG_Nil); V rv_5 = v_t_2421; V rv_6 = v_t_2426; V rv_8 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2430}); V rv_9 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_st_242, 128ULL, 10, shape_prevEnd__n__toks__pending__inl__lead__inline__trail__lastTok__k, 49152u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}