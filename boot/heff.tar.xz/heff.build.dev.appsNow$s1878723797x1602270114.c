// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Start 63542
#define LBL_apps 9496377
#define LBL_bad 306815
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0(V, V, V, V);
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_str0, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_str2, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_str3, 1, ".");
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam3, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam4(V self, V *args);
Clo g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_entry, 4, 0};

V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0(V v_hd_240, V v_st_241, V v_k_242, V v_x_243) {
top: ;
  switch (heff_tag_of(v_x_243)) {
  case TAG_Left: {
    V v_ru_24x_243_24Left = heff_take_reuse_n(v_x_243, 0ULL, 1);
    V v_t_246 = heff_tag_at_n(v_ru_24x_243_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam0_clo)})});
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
    return (g_co_2eop_24s535099379x685970669(v_t_247, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam1, 1, 3, (V[]){v_st_241, v_hd_240, v_k_242})));
  }
  case TAG_Right: {
    V v_y_2413 = heff_field(v_x_243, 0);
    V v_ru_24x_243_24Right = heff_take_reuse_n(v_x_243, 1ULL, 1);
    V v_total_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_y_2413));
    V v_t_2416 = heff_tag_at_n(v_ru_24x_243_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_str2), v_total_2414, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam3_clo)})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s535099379x685970669(v_t_2417, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam4, 1, 4, (V[]){v_st_241, v_y_2413, v_hd_240, v_k_242})));
  }
  default: return heff_nomatch(v_x_243);
  }
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam0(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_drop(v_x_2412);
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = (g_heff_2ebuild_2ecommands_2ebuildTarget(v_st_241, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_str1)));
  heff_drop(v_t_249);
  V v_t_2410 = heff_tag_n(TAG_End, 2, (V[]){v_x_248, NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), v_hd_240, heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam2, 1, 1, (V[]){v_k_242})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam3(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_bad_2422 = heff_env(self)[0];
  V v_apps_2423 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_drop(v_x_2426);
  V v_t_2427;
  heff_clo_take(self, 3);
  if (heff_intLt_c(MK_INT(0LL), v_bad_2422)) {
    heff_drop(v_apps_2423);
    v_t_2427 = NTAG(TAG_Nil);
  } else {
    v_t_2427 = v_apps_2423;
  }
  V f_ = v_k_242;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_bad_2422 = heff_take_field(v_x_2421, 1);
  V v_apps_2423 = heff_get_n(v_x_2421, 0, 2);
  heff_clo_take(self, 3);
  V v_t_2424 = heff_tag_n(TAG_End, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_hd_240, heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam6, 1, 3, (V[]){v_bad_2422, v_apps_2423, v_k_242})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_y_2413 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_t_2419 = (g_heff_2ebuild_2ecommands_2ebuildTarget(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_str3)));
  V v_t_2420 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323(v_st_241, v_t_2419, heff_dup(v_x_2418), v_t_2420, v_y_2413, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1878723797x1602270114_2ek_24l0_lam5, 1, 3, (V[]){v_x_2418, v_hd_240, v_k_242})));
}