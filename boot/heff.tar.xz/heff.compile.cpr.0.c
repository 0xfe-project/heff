// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CRel 55099
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_NoShape 40346
#define TAG_RepFix 59335
#define TAG_Tip 31527
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_body 9524841
#define LBL_cons 9554936
#define LBL_defs 9574869
#define LBL_group 299987609
#define LBL_index 301704428
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_labels 836724522
#define LBL_lets 9813631
#define LBL_name 9869138
#define LBL_numbered 1006183371
#define LBL_places 961367927
#define LBL_record 1012233084
#define LBL_supply 1056026650
#define LBL_tag 324116
#define LBL_tuple 312083426
#define LBL_tuples 1084651734
#define LBL_tys 324872
#define LBL_vals 10107449
static uint32_t shape_defs__supply__tuples[] = {LBL_defs, LBL_supply, LBL_tuples};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_kinds__cons[] = {LBL_kinds, LBL_cons};
static uint32_t shape_kinds__places[] = {LBL_kinds, LBL_places};
static uint32_t shape_lets__vals[] = {LBL_lets, LBL_vals};
static uint32_t shape_tag__index__tys__places[] = {LBL_tag, LBL_index, LBL_tys, LBL_places};
static uint32_t shape_tuple__numbered__kinds__record__labels__cons__group[] = {LBL_tuple, LBL_numbered, LBL_kinds, LBL_record, LBL_labels, LBL_cons, LBL_group};
V g_heff_2ecompile_2ecpr_2eapartW(V, V, V, V);
V g_heff_2ecompile_2ecpr_2eapartW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eapartW_clo;
V g_heff_2ecompile_2ecpr_2earmBodyAs(V, V, V, V);
V g_heff_2ecompile_2ecpr_2earmBodyAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2earmBodyAs_clo;
V g_heff_2ecompile_2ecpr_2earmOf(V, V);
V g_heff_2ecompile_2ecpr_2earmOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2earmOf_clo;
HeffT2 g_heff_2ecompile_2ecpr_2earmOf_24cpr(V, V);
V g_heff_2ecompile_2ecpr_2eboundOne(V, V);
V g_heff_2ecompile_2ecpr_2eboundOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eboundOne_clo;
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2(V, V, V, V);
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_clo;
V g_heff_2ecompile_2ecpr_2ebuiltOut(V, V, V);
V g_heff_2ecompile_2ecpr_2ebuiltOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ebuiltOut_clo;
V g_heff_2ecompile_2ecpr_2ecalledApart(V, V, V, V);
V g_heff_2ecompile_2ecpr_2ecalledApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ecalledApart_clo;
V g_heff_2ecompile_2ecpr_2ecandOne(V, V);
V g_heff_2ecompile_2ecpr_2ecandOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ecandOne_clo;
V g_heff_2ecompile_2ecpr_2echosen(V, V, V);
V g_heff_2ecompile_2ecpr_2echosen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2echosen_clo;
V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(V, V, V, V);
V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_clo;
V g_heff_2ecompile_2ecpr_2ecprWith(V, V, V);
V g_heff_2ecompile_2ecpr_2ecprWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ecprWith_clo;
V g_heff_2ecompile_2ecpr_2edefWith(V, V, V);
V g_heff_2ecompile_2ecpr_2edefWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2edefWith_clo;
V g_heff_2ecompile_2ecpr_2edropCalling(V);
V g_heff_2ecompile_2ecpr_2edropCalling_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2edropCalling_clo;
HeffT2 g_heff_2ecompile_2ecpr_2efieldAt_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2ecpr_2efitting_24cpr(V);
V g_heff_2ecompile_2ecpr_2ekeptGo(V, V);
V g_heff_2ecompile_2ecpr_2ekeptGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ekeptGo_clo;
V g_heff_2ecompile_2ecpr_2elayTag(V, V);
V g_heff_2ecompile_2ecpr_2elayTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2elayTag_clo;
V g_heff_2ecompile_2ecpr_2elayoutsAt(V, V, V);
V g_heff_2ecompile_2ecpr_2elayoutsAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2elayoutsAt_clo;
V g_heff_2ecompile_2ecpr_2ematchCallIn(V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2ematchCallIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ematchCallIn_clo;
V g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2_clo;
V g_heff_2ecompile_2ecpr_2ematchRw_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2ematchRw_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ematchRw_24tok2_clo;
V g_heff_2ecompile_2ecpr_2emergeTy(V, V);
V g_heff_2ecompile_2ecpr_2emergeTy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2emergeTy_clo;
V g_heff_2ecompile_2ecpr_2eoutRw(V, V);
V g_heff_2ecompile_2ecpr_2eoutRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eoutRw_clo;
V g_heff_2ecompile_2ecpr_2eoutsW(V, V);
V g_heff_2ecompile_2ecpr_2eoutsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eoutsW_clo;
V g_heff_2ecompile_2ecpr_2eplacedAt(V, V, V);
V g_heff_2ecompile_2ecpr_2eplacedAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eplacedAt_clo;
V g_heff_2ecompile_2ecpr_2erw(V, V);
V g_heff_2ecompile_2ecpr_2erw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2erw_clo;
V g_heff_2ecompile_2ecpr_2esameLabels(V, V);
V g_heff_2ecompile_2ecpr_2esameLabels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esameLabels_clo;
V g_heff_2ecompile_2ecpr_2eshapesOf(V, V);
V g_heff_2ecompile_2ecpr_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eshapesOf_clo;
V g_heff_2ecompile_2ecpr_2esiteLet(V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2esiteLet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esiteLet_clo;
V g_heff_2ecompile_2ecpr_2esiteLetIn_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2esiteLetIn_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esiteLetIn_24tok2_clo;
V g_heff_2ecompile_2ecpr_2esiteMatch(V, V, V, V);
V g_heff_2ecompile_2ecpr_2esiteMatch_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esiteMatch_clo;
V g_heff_2ecompile_2ecpr_2esiteMatchIn(V, V, V);
V g_heff_2ecompile_2ecpr_2esiteMatchIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esiteMatchIn_clo;
V g_heff_2ecompile_2ecpr_2esiteMatchIn_24tok2(V, V, V, V);
V g_heff_2ecompile_2ecpr_2esiteMatchIn_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esiteMatchIn_24tok2_clo;
V g_heff_2ecompile_2ecpr_2esited(V, V);
V g_heff_2ecompile_2ecpr_2esited_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esited_clo;
V g_heff_2ecompile_2ecpr_2esitesW(V, V, V);
V g_heff_2ecompile_2ecpr_2esitesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esitesW_clo;
HeffT2 g_heff_2ecompile_2ecpr_2etagLayout_24cpr(V, V, V);
V g_heff_2ecompile_2ecpr_2ewrapperOf(V, V, V);
V g_heff_2ecompile_2ecpr_2ewrapperOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ewrapperOf_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2erepr_2erootFrom(V, V, V);
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2erootFrom_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1630057461x1822494873(V);
V g_list_2eany_24s1630057461x1822494873_entry(V self, V *a);
extern Clo g_list_2eany_24s1630057461x1822494873_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s558881959x1385112442_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f155552269x628597815(V, V, V);
V g_list_2efoldl_24f155552269x628597815_entry(V self, V *a);
extern Clo g_list_2efoldl_24f155552269x628597815_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1766906699x9526323(V, V);
V g_list_2efoldl_24s1766906699x9526323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1766906699x9526323_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s465028312x319285028(V, V);
V g_list_2efoldl_24s465028312x319285028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s465028312x319285028_clo;
V g_list_2efoldl_24s571527232x333134686(V, V);
V g_list_2efoldl_24s571527232x333134686_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571527232x333134686_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s2090270526x1588636862(V);
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_clo;
V g_list_2emap_24s273193875x235978955(V, V, V, V);
V g_list_2emap_24s273193875x235978955_entry(V self, V *a);
extern Clo g_list_2emap_24s273193875x235978955_clo;
V g_list_2emap_24s45270243x110012769(V);
V g_list_2emap_24s45270243x110012769_entry(V self, V *a);
extern Clo g_list_2emap_24s45270243x110012769_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2etraverse_24s1400036078x174253642_24cpr(V, V, V, V, V, V, V, V);
V g_prelude_2etraverse_24s1673840189x4008143(V, V);
V g_prelude_2etraverse_24s1673840189x4008143_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1673840189x4008143_clo;
V g_prelude_2etraverse_24s247294553x1909820037(V, V, V, V);
V g_prelude_2etraverse_24s247294553x1909820037_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s247294553x1909820037_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2ecpr_2esameLabels_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esameLabels_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2esameLabels(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_args_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_a_244, v_b_246, 0)) {
        V t_0 = v_args_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecpr_2esameLabels_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2esameLabels(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecpr_2ecandOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ecandOne_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2ecandOne(V v_m_240, V v_d_241) {
top: ;
  V v_body_242 = heff_take_field(v_d_241, 2);
  V v_key_243 = heff_get_n(v_d_241, 0, 3);
  switch (heff_tag_of(v_body_242)) {
  case TAG_EVar: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_b_247 = heff_field(v_body_242, 1);
    V v_ru_24body_242_24ELam = heff_take_reuse_n(v_body_242, 2ULL, 2);
    V v_t_248 = heff_tag_at_n(v_ru_24body_242_24ELam, TAG_Cons, 2, (V[]){v_b_247, NTAG(TAG_Nil)});
    V v_os_249 = (g_heff_2ecompile_2ecpr_2eoutsW(NTAG(TAG_Nil), v_t_248));
    V v_t_2410 = (g_list_2eany_24s1630057461x1822494873(v_os_249));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_key_243);
      heff_drop(v_os_249);
      heff_drop(v_t_2410);
      return v_m_240;
    } else {
      heff_drop(v_t_2410);
      return (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_key_243, v_os_249));
    }
  }
  case TAG_EApp: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_body_242, 0ULL, 4);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EBool: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_ESet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EValues: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_key_243);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_key_243);
    return v_m_240;
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2ecompile_2ecpr_2ecandOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ecandOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecpr_2ekeptGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ekeptGo_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2ekeptGo(V v_m_240, V v_m2_241) {
top: ;
  V v_t_242 = (g_std_2emap_2esize(v_m2_241));
  V v_t_243 = (g_std_2emap_2esize(v_m_240));
  if (heff_intEq_c(v_t_242, v_t_243)) {
    heff_drop(v_m2_241);
    return v_m_240;
  } else {
    heff_drop(v_m_240);
    V v_t_244 = (g_heff_2ecompile_2ecpr_2edropCalling(v_m2_241));
    V t_0 = v_m2_241;
    V t_1 = v_t_244;
    v_m_240 = t_0;
    v_m2_241 = t_1;
    goto top;
  }
}
V g_heff_2ecompile_2ecpr_2ekeptGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ekeptGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str11, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str12, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str13, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str14, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str15, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str16, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str17, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str18, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str19, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str20, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str21, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str22, 1, "_");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str23, 1, "\?");
Clo g_heff_2ecompile_2ecpr_2emergeTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2emergeTy_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2emergeTy(V v_a_240, V v_b_241) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_a_240)) {
  case TAG_FtFloat: {
    v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str0);
    break;
  }
  case TAG_FtFixed: {
    V v_w_242 = heff_dup(heff_field(v_a_240, 0));
    switch (heff_tag_of(v_w_242)) {
    case TAG_I8: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str1);
      break;
    }
    case TAG_I16: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str2);
      break;
    }
    case TAG_I32: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str3);
      break;
    }
    case TAG_I64: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str4);
      break;
    }
    case TAG_U8: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str5);
      break;
    }
    case TAG_U16: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str6);
      break;
    }
    case TAG_U32: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str7);
      break;
    }
    case TAG_U64: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str8);
      break;
    }
    case TAG_F32: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str9);
      break;
    }
    default: heff_nomatch(v_w_242);
    }
    break;
  }
  case TAG_FtOther: {
    v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str10);
    break;
  }
  case TAG_FtAny: {
    v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str11);
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  V v_t_245;
  switch (heff_tag_of(v_b_241)) {
  case TAG_FtFloat: {
    v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str12);
    break;
  }
  case TAG_FtFixed: {
    V v_w_244 = heff_field(v_b_241, 0);
    switch (heff_tag_of(v_w_244)) {
    case TAG_I8: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str13);
      break;
    }
    case TAG_I16: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str14);
      break;
    }
    case TAG_I32: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str15);
      break;
    }
    case TAG_I64: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str16);
      break;
    }
    case TAG_U8: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str17);
      break;
    }
    case TAG_U16: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str18);
      break;
    }
    case TAG_U32: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str19);
      break;
    }
    case TAG_U64: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str20);
      break;
    }
    case TAG_F32: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str21);
      break;
    }
    default: heff_nomatch(v_w_244);
    }
    break;
  }
  case TAG_FtOther: {
    v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str22);
    break;
  }
  case TAG_FtAny: {
    v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str23);
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  if (heff_strEq_c(v_t_243, v_t_245)) {
    return v_a_240;
  } else {
    heff_drop(v_a_240);
    return NTAG(TAG_FtOther);
  }
}
V g_heff_2ecompile_2ecpr_2emergeTy_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2emergeTy(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2eshapesOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eshapesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eshapesOf_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eshapesOf(V v_parent_240, V v_m_241) {
top: ;
  V v_t_242 = (g_std_2emap_2etoListOnto(v_m_241, NTAG(TAG_Nil)));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2eshapesOf_lam0, 2, 1, (V[]){heff_dup(v_parent_240)}); V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2ecompile_2ecpr_2eshapesOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2eshapesOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2eshapesOf_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_p_244 = args[1];
  V v_parent_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_247;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_p_244, 0));
    v_x_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_248 = (g_std_2emap_2elookup_24s1930949324x2078207031(v_parent_240, v_x_247));
  V v_root_249 = ({ V a_0 = v_parent_240; V a_1 = v_x_247; V a_2 = v_t_248; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_240); r_; });
  HeffT2 v_t_2410 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_acc_243, v_root_249));
  V v_t_2414;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2413 = v_field_2412;
      v_t_2414 = v_x_2413;
    } else {
      heff_drop(v_field_2412);
      v_t_2414 = NTAG(TAG_NoShape);
    }
  }
  V v_t_2417;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_p_244, 1);
    heff_take_n(v_p_244, 2ULL, 2);
    v_t_2417 = v_y_2416;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_2418 = ({ V a_0 = v_t_2414; V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1766906699x9526323(a_0, a_1)); heff_drop(v_t_2417); r_; });
  return (g_std_2emap_2einsert_24s93785294x875597928(v_acc_243, v_root_249, v_t_2418));
}
Clo g_heff_2ecompile_2ecpr_2eplacedAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eplacedAt_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2eplacedAt(V v_p_240, V v_k_241, V v_x3_242) {
top: ;
  V v_kinds_243 = heff_take_field(v_p_240, 0);
  V v_places_244 = heff_get_n(v_p_240, 1, 2);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_k_241, NTAG(TAG_Nil)});
    V v_t_246 = (g_prelude_2e_2b_2b(heff_dup(v_kinds_243), v_t_245));
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_kinds_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_kinds_243); r_; });
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = (g_prelude_2e_2b_2b(v_places_244, v_t_248));
    return heff_rec_n(2, shape_kinds__places, (V[]){v_t_246, v_t_249});
  }
  case TAG_Just: {
    V v_i_2410 = heff_field(v_x3_242, 0);
    heff_drop(v_k_241);
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_i_2410), NTAG(TAG_Nil)});
    V v_t_2412 = (g_prelude_2e_2b_2b(v_places_244, v_t_2411));
    return heff_rec_n(2, shape_kinds__places, (V[]){v_kinds_243, v_t_2412});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2eplacedAt_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2eplacedAt(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecpr_2elayTag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2elayTag_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2elayTag(V v_acc_240, V v_x2_241) {
top: ;
  V v_kinds_242 = heff_take_field(v_acc_240, 0);
  V v_cons_243 = heff_get_n(v_acc_240, 1, 2);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_t_244 = heff_field(v_x2_241, 0);
    V v_ts_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246 = heff_rec_n(2, shape_kinds__places, (V[]){v_kinds_242, NTAG(TAG_Nil)});
    V v_p_247 = (g_list_2efoldl_24s465028312x319285028(v_t_246, v_ts_245));
    V v_kinds_248 = heff_take_field(v_p_247, 0);
    V v_places_249 = heff_get_n(v_p_247, 1, 2);
    V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_cons_243));
    V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(4, shape_tag__index__tys__places, (V[]){v_t_244, v_t_2410, v_ts_245, v_places_249}), NTAG(TAG_Nil)});
    V v_t_2412 = (g_prelude_2e_2b_2b(v_cons_243, v_t_2411));
    return heff_rec_n(2, shape_kinds__cons, (V[]){v_kinds_248, v_t_2412});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecpr_2elayTag_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2elayTag(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str2, 1, "#");

HeffT2 g_heff_2ecompile_2ecpr_2etagLayout_24cpr(V v_root_240, V v_numbered_241, V v_l_242) {
top: ;
  V v_kinds_243 = heff_take_field(v_l_242, 0);
  V v_cons_244 = heff_get_n(v_l_242, 1, 2);
  V v_t_246;
  if ((heff_dup(v_numbered_241) == NTAG(TAG_True))) {
    V v_t_245 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_dup(v_kinds_243)});
  } else {
    v_t_246 = heff_dup(v_kinds_243);
  }
  V v_x2_247 = (g_list_2emap_24s2090270526x1588636862(v_t_246));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str1); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = heff_rec_n(7, shape_tuple__numbered__kinds__record__labels__cons__group, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str2), v_t_2410), v_numbered_241, v_kinds_243, NTAG(TAG_False), NTAG(TAG_Nil), v_cons_244, v_root_240});
  return (g_heff_2ecompile_2ecpr_2efitting_24cpr(v_t_2411));
}
V g_heff_2ecompile_2ecpr_2elayoutsAt_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2elayoutsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2elayoutsAt_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2elayoutsAt(V v_parent_240, V v_ls_241, V v_m_242) {
top: ;
  V v_t_243 = (g_std_2emap_2etoListOnto(v_m_242, NTAG(TAG_Nil)));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2elayoutsAt_lam0, 2, 2, (V[]){heff_dup(v_parent_240), heff_dup(v_ls_241)}); V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_t_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
}
V g_heff_2ecompile_2ecpr_2elayoutsAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2elayoutsAt(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecpr_2elayoutsAt_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_p_245 = args[1];
  V v_parent_240 = heff_env(self)[0];
  V v_ls_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_dup(heff_field(v_p_245, 0));
    v_x_248 = v_x_246;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_249 = (g_std_2emap_2elookup_24s1930949324x2078207031(v_parent_240, v_x_248));
  V v_t_2410 = ({ V a_0 = v_parent_240; V a_1 = v_x_248; V a_2 = v_t_249; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_240); r_; });
  HeffT2 v_t_2411 = ({ V a_0 = v_ls_241; V a_1 = v_t_2410; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_ls_241); heff_drop(v_t_2410); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_lay_2414 = v_field_2413;
      V v_t_2417;
      switch (heff_tag_of(v_p_245)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_p_245, 0);
        heff_take_n(v_p_245, 1ULL, 2);
        v_t_2417 = v_x_2415;
        break;
      }
      default: heff_nomatch(v_p_245);
      }
      return (g_std_2emap_2einsert_24s93785294x875597928(v_acc_244, v_t_2417, v_lay_2414));
    } else {
      heff_drop(v_p_245);
      heff_drop(v_field_2413);
      return v_acc_244;
    }
  }
}
Clo g_heff_2ecompile_2ecpr_2earmOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2earmOf_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2earmOf(V v_t_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2ecpr_2earmOf_24cpr(v_t_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2ecpr_2earmOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2earmOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecpr_2esiteMatchIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2esiteMatchIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esiteMatchIn_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2esiteMatchIn(V v_acc_240, V v_arms_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_arms_241);
    return v_acc_240;
  }
  case TAG_Just: {
    V v_lay_243 = heff_field(v_x3_242, 0);
    V v_record_244 = heff_dup(heff_rfield(v_lay_243, 3));
    V v_cons_245 = heff_dup(heff_rfield(v_lay_243, 5));
    V v_group_246 = heff_dup(heff_rfield(v_lay_243, 6));
    if (!(heff_dup(v_record_244) == NTAG(TAG_True))) {
      heff_drop(v_record_244);
      V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2esiteMatchIn_lam0, 1, 1, (V[]){v_arms_241}); V a_1 = v_cons_245; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_cons_245); r_; });
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        return heff_tag_n(TAG_Cons, 2, (V[]){v_group_246, v_acc_240});
      } else {
        heff_drop(v_group_246);
        heff_drop(v_t_2412);
        return v_acc_240;
      }
    } else {
      heff_drop(v_arms_241);
      heff_drop(v_record_244);
      heff_drop(v_cons_245);
      heff_drop(v_group_246);
      return v_acc_240;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2esiteMatchIn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2esiteMatchIn(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecpr_2esiteMatchIn_lam0(V self, V *args) {
  V v_c_247 = args[0];
  V v_arms_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_248 = ({ V b_0 = heff_get_n(v_c_247, 0, 4); V a_1 = v_arms_241; HeffT2 r_ = (g_heff_2ecompile_2ecpr_2earmOf_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_249 == ((int64_t)0ULL)) && ({ V v_x11_2411 = heff_dup(v_field_2410); int c_ = 1; heff_drop(v_x11_2411); c_; })));
    heff_drop(v_field_2410);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2ecpr_2esiteMatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esiteMatch_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2esiteMatch(V v_k_240, V v_acc_241, V v_s_242, V v_arms_243) {
top: ;
  switch (heff_tag_of(v_s_242)) {
  case TAG_EVar: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_ELam: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EApp: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_ELet: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_ERecord: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EProj: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_ETag: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EMatch: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EPrim: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EPrimCall: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_ECall: {
    V v_g_2427 = heff_field(v_s_242, 0);
    V v_t_2429 = (g_std_2emap_2elookup_24s1930949324x2078207031(v_k_240, v_g_2427));
    return ({ V a_0 = v_acc_241; V a_1 = v_arms_243; V a_2 = v_t_2429; V r_ = (g_heff_2ecompile_2ecpr_2esiteMatchIn(a_0, a_1, a_2)); heff_drop(v_t_2429); r_; });
  }
  case TAG_EInt: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EFloat: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EStr: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EBytes: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EFixed: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EFloat32: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EBool: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_ESet: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EValues: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  case TAG_EFix: {
    heff_drop(v_arms_243);
    return v_acc_241;
  }
  default: return heff_nomatch(v_s_242);
  }
}
V g_heff_2ecompile_2ecpr_2esiteMatch_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2esiteMatch(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecpr_2esitesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esitesW_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2esitesW(V v_k_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_249 = heff_field(v_x31_243, 0);
      V v_args_2410 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EApp = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_243_24EApp, v_args_2410, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_249, v_t_2411});
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_x_2412 = heff_field(v_x31_243, 0);
      V v_a_2413 = heff_field(v_x31_243, 1);
      V v_b_2414 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_t_2415 = ({ V a_0 = v_k_240; V a_1 = v_acc_241; V a_2 = v_x_2412; V a_3 = v_a_2413; V a_4 = heff_dup(v_b_2414); V r_ = (g_heff_2ecompile_2ecpr_2esiteLet(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2412); r_; });
      V v_t_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2414, v_rest_244})});
      V t_0 = v_k_240;
      V t_1 = v_t_2415;
      V t_2 = v_t_2416;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2417 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      V v_t_2419 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x3_242_24Cons, v_fs_2417, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2419;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2420 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2420, v_rest_244});
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_args_2425 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      V v_t_2427 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2425, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2427;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2428 = heff_field(v_x31_243, 0);
      V v_arms_2429 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2430 = (g_heff_2ecompile_2ecpr_2esiteMatch(v_k_240, v_acc_241, v_s_2428, heff_dup(v_arms_2429)));
      V v_t_2431 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2429, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_t_2430;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2428, v_t_2431});
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2434 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V v_t_2435 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2434, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2435;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_args_2437 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V v_t_2438 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2437, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2438;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2446 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2447 = ({ V a_0 = v_c_2446; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2446); r_; });
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2447;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2449 = heff_field(v_x31_243, 1);
      V v_b_2450 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2451 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2449, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2450, v_rest_244})});
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2451;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2452 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2453 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_es_2452, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2453;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2esitesW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2esitesW(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecpr_2esited_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2esited_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esited_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2esited(V v_defs_240, V v_k_241) {
top: ;
  V v_t_242 = (g_list_2emap_24s45270243x110012769(v_defs_240));
  V v_t_243 = (g_heff_2ecompile_2ecpr_2esitesW(v_k_241, NTAG(TAG_Nil), v_t_242));
  V v_groups_244 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_std_2emap_2etoListOnto(v_k_241, NTAG(TAG_Nil)));
  V v_ps_2414 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2ecpr_2esited_lam0, 1, 1, (V[]){v_groups_244}), v_t_245));
  return ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2414; V r_ = (g_list_2efoldl_24s571527232x333134686(a_0, a_1)); heff_drop(v_ps_2414); r_; });
}
V g_heff_2ecompile_2ecpr_2esited_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2esited(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2esited_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_groups_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249;
  switch (heff_tag_of(v_p_246)) {
  case TAG_MkPair: {
    V v_y_248 = heff_field(v_p_246, 1);
    heff_take_n(v_p_246, 2ULL, 2);
    v_t_249 = v_y_248;
    break;
  }
  default: heff_nomatch(v_p_246);
  }
  HeffT2 v_t_2410 = ({ V a_0 = v_groups_244; V b_1 = heff_get_n(v_t_249, 6, 7); HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, b_1)); heff_drop(v_groups_244); heff_drop(b_1); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2411 == ((int64_t)0ULL)) && ({ V v_x_2413 = heff_dup(v_field_2412); int c_ = 1; heff_drop(v_x_2413); c_; })));
    heff_drop(v_field_2412);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2earmBodyAs_str0, 0, "");
V g_heff_2ecompile_2ecpr_2earmBodyAs_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2earmBodyAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2earmBodyAs_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2earmBodyAs(V v_lay_240, V v_vs_241, V v_c_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop_rec(v_c_242, 4);
    return NTAG(TAG_EAbandon);
  }
  case TAG_Just: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkArm: {
      V v_ws_246 = heff_field(v_x41_244, 1);
      V v_b_247 = heff_field(v_x41_244, 2);
      heff_take_n(v_x41_244, 6ULL, 3);
      V v_t_248 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_ws_246, heff_get_n(v_c_242, 3, 4)));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2earmBodyAs_lam0, 2, 2, (V[]){v_lay_240, heff_dup(v_vs_241)}); V a_1 = v_b_247; V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecpr_2earmBodyAs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2earmBodyAs(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2earmBodyAs_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_lay_240 = heff_env(self)[0];
  V v_vs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_dup(heff_field(v_x_2410, 0));
    v_t_2413 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_i_2416;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_y_2415 = heff_field(v_x_2410, 1);
    heff_take_n(v_x_2410, 2ULL, 2);
    v_i_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2417 = heff_get_n(v_lay_240, 1, 7);
  V v_t_2418;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_t_2417);
    v_t_2418 = heff_intAdd(v_i_2416, MK_INT(1LL));
  } else {
    heff_drop(v_t_2417);
    v_t_2418 = v_i_2416;
  }
  HeffT3 v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = v_vs_241; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_241); r_; });
  V v_t_2425;
  {
    V v_field_2421 = v_t_2419.f[1];
    V v_field_2422 = v_t_2419.f[2];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_x_2423 = v_field_2421;
      V v_x12_2424 = v_field_2422;
      heff_drop(v_x12_2424);
      v_t_2425 = v_x_2423;
    } else {
      heff_drop(v_field_2421);
      heff_drop(v_field_2422);
      v_t_2425 = ((V)&g_heff_2ecompile_2ecpr_2earmBodyAs_str0);
    }
  }
  return heff_tag_n(TAG_ELet, 3, (V[]){v_t_2413, heff_tag_n(TAG_EVar, 1, (V[]){v_t_2425}), v_acc_249});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_str1, 7, "int64Eq");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_str3, 5, "False");
Clo g_heff_2ecompile_2ecpr_2echosen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2echosen_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2echosen(V v_vs_240, V v_way_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_way_241);
    return NTAG(TAG_EAbandon);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_x32_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x32_244)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_tail(v_way_241, 1, (V[]){v_c_243});
    }
    case TAG_Cons: {
      V v_yes_247 = heff_tr(heff_call(heff_dup(v_way_241), 1, (V[]){heff_dup(v_c_243)}));
      V v_no_248 = heff_tr(g_heff_2ecompile_2ecpr_2echosen(v_vs_240, v_way_241, v_x32_244));
      V v_t_2411;
      switch (heff_tag_of(v_vs_240)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2ecompile_2ecpr_2echosen_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_vs_240, 0);
        v_t_2411 = heff_dup(v_x_249);
        break;
      }
      default: heff_nomatch(v_vs_240);
      }
      V v_t_2412 = heff_tag_n(TAG_EFixed, 2, (V[]){NTAG(TAG_I64), heff_get_n(v_c_243, 1, 4)});
      V v_t_2413 = heff_tag_n(TAG_CRel, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_str1), heff_tag_n(TAG_EVar, 1, (V[]){v_t_2411}), v_t_2412});
      V v_t_2414 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_str2), NTAG(TAG_Nil), v_yes_247});
      V v_t_2415 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_str3), NTAG(TAG_Nil), v_no_248});
      V v_t_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_t_2413}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2416})});
    }
    default: return heff_nomatch(v_x32_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2echosen_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2echosen(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecpr_2ematchCallIn_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2ematchCallIn_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2ematchCallIn_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ematchCallIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ematchCallIn_entry, 5, 0};

V g_heff_2ecompile_2ecpr_2ematchCallIn(V v_g_240, V v_args_241, V v_arms_242, V v_x4_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_245 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_240, v_args_241}), v_arms_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_z_244});
  }
  case TAG_Just: {
    V v_lay_246 = heff_field(v_x4_243, 0);
    if (!(heff_dup(heff_rfield(v_lay_246, 3)) == NTAG(TAG_True))) {
      V v_t_2412 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2ecpr_2ematchCallIn_lam0, 1, 1, (V[]){heff_dup(v_arms_242)}), heff_rfield(v_lay_246, 5)));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        V v_t_2416 = (g_heff_2ecompile_2ecpr_2ecalledApart(heff_dup(v_lay_246), v_g_240, v_args_241, heff_clo_n(g_heff_2ecompile_2ecpr_2ematchCallIn_lam1, 1, 2, (V[]){v_arms_242, heff_dup(v_lay_246)})));
        return heff_tail(v_t_2416, 1, (V[]){v_z_244});
      } else {
        heff_drop(v_t_2412);
        V v_t_2417 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_240, v_args_241}), v_arms_242});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_z_244});
      }
    } else {
      V v_t_2418 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_240, v_args_241}), v_arms_242});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_z_244});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecpr_2ematchCallIn_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2ecpr_2ematchCallIn(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2ecpr_2ematchCallIn_lam0(V self, V *args) {
  V v_c_247 = args[0];
  V v_arms_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_248 = ({ V b_0 = heff_get_n(v_c_247, 0, 4); V a_1 = v_arms_242; HeffT2 r_ = (g_heff_2ecompile_2ecpr_2earmOf_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_249 == ((int64_t)0ULL)) && ({ V v_x11_2411 = heff_dup(v_field_2410); int c_ = 1; heff_drop(v_x11_2411); c_; })));
    heff_drop(v_field_2410);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2ematchCallIn_lam2(V self, V *args) {
  V v_c_2414 = args[0];
  V v_arms_242 = heff_env(self)[0];
  V v_lay_246 = heff_env(self)[1];
  V v_vs_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = (g_heff_2ecompile_2ecpr_2earmOf(heff_rfield(v_c_2414, 0), v_arms_242));
  return ({ V a_0 = v_lay_246; V a_1 = v_vs_2413; V a_2 = v_c_2414; V a_3 = v_t_2415; V r_ = (g_heff_2ecompile_2ecpr_2earmBodyAs(a_0, a_1, a_2, a_3)); heff_drop(v_vs_2413); r_; });
}
V g_heff_2ecompile_2ecpr_2ematchCallIn_lam1(V self, V *args) {
  V v_vs_2413 = args[0];
  V v_arms_242 = heff_env(self)[0];
  V v_lay_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_vs_2413; V a_1 = heff_clo_n(g_heff_2ecompile_2ecpr_2ematchCallIn_lam2, 1, 3, (V[]){v_arms_242, heff_dup(v_lay_246), heff_dup(v_vs_2413)}); V a_2 = heff_get_n(v_lay_246, 5, 7); V r_ = (g_heff_2ecompile_2ecpr_2echosen(a_0, a_1, a_2)); heff_drop(v_vs_2413); r_; });
}

HeffT2 g_heff_2ecompile_2ecpr_2efieldAt_24cpr(V v_i_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x2_241, 0);
    V v_ps_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_i_240);
      heff_drop(v_p_243);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_e_245 = heff_field(v_x3_242, 0);
      V v_es_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      if (heff_intEq_c_lent(v_p_243, v_i_240, 1)) {
        heff_drop(v_i_240);
        heff_drop(v_ps_244);
        heff_drop(v_es_246);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_245}});
      } else {
        heff_drop(v_e_245);
        V t_0 = v_i_240;
        V t_1 = v_ps_244;
        V t_2 = v_es_246;
        v_i_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2eboundOne_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecpr_2eboundOne_str1, 1, "f");
V g_heff_2ecompile_2ecpr_2eboundOne_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eboundOne_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eboundOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eboundOne_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eboundOne(V v_b_240, V v_e_241) {
top: ;
  V v_lets_242 = heff_take_field(v_b_240, 0);
  V v_vals_243 = heff_get_n(v_b_240, 1, 2);
  V v_t_244 = (g_heff_2ecompile_2eir_2eisValue(v_e_241));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    V v_t_246 = (g_prelude_2e_2b_2b(v_vals_243, v_t_245));
    V v_x_247 = heff_rec_n(2, shape_lets__vals, (V[]){v_lets_242, v_t_246});
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eboundOne_lam0, 1, 1, (V[]){v_x_247});
  } else {
    heff_drop(v_t_244);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eboundOne_lam1, 1, 3, (V[]){v_e_241, v_lets_242, v_vals_243});
  }
}
V g_heff_2ecompile_2ecpr_2eboundOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eboundOne(a[0], a[1]);
}
V g_heff_2ecompile_2ecpr_2eboundOne_lam0(V self, V *args) {
  V v_n_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_n_248});
}
V g_heff_2ecompile_2ecpr_2eboundOne_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_lets_242 = heff_env(self)[1];
  V v_vals_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2ecpr_2eboundOne_str0), heff_intShow(heff_dup(v_n_249)));
  V v_x_2411 = heff_strAppend(((V)&g_heff_2ecompile_2ecpr_2eboundOne_str1), v_t_2410);
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2411), v_e_241}), NTAG(TAG_Nil)});
  V v_t_2413 = (g_prelude_2e_2b_2b(v_lets_242, v_t_2412));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_2411}), NTAG(TAG_Nil)});
  V v_t_2415 = (g_prelude_2e_2b_2b(v_vals_243, v_t_2414));
  V v_x_2416 = heff_rec_n(2, shape_lets__vals, (V[]){v_t_2413, v_t_2415});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2416, heff_intAdd(v_n_249, MK_INT(1LL))});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2eoutRw_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2eoutRw_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2eoutRw_str2, 4, "$cpr");
V g_heff_2ecompile_2ecpr_2eoutRw_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam3(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam4(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam5(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam7(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam6(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam8(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam9(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam10(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam11(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam12(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam13(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam14(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam15(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam16(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam17(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam18(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam19(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam20(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam21(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam22(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eoutRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eoutRw_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eoutRw(V v_lay_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam0, 1, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam1, 1, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam2, 1, 1, (V[]){v_e_241});
  }
  case TAG_EApp: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam3, 1, 1, (V[]){v_e_241});
  }
  case TAG_ELet: {
    V v_x_2412 = heff_field(v_e_241, 0);
    V v_a_2413 = heff_field(v_e_241, 1);
    V v_b_2414 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2415 = (g_heff_2ecompile_2ecpr_2eoutRw(v_lay_240, v_b_2414));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam4, 1, 3, (V[]){v_m_2415, v_x_2412, v_a_2413});
  }
  case TAG_ERecord: {
    V v_fs_2420 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 1ULL, 2);
    HeffT2 v_t_2422 = ({ V b_0 = ((V)&g_heff_2ecompile_2ecpr_2eoutRw_str0); V a_1 = heff_dup(heff_rfield(v_lay_240, 5)); HeffT2 r_ = (g_list_2efind_24s558881959x1385112442_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2426;
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        V v_x_2425 = v_field_2424;
        v_t_2426 = v_x_2425;
      } else {
        heff_drop(v_field_2424);
        v_t_2426 = heff_rec_n(4, shape_tag__index__tys__places, (V[]){((V)&g_heff_2ecompile_2ecpr_2eoutRw_str1), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
    }
    V v_t_2427 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24e_241_24ERecord, v_fs_2420));
    return ({ V a_0 = v_lay_240; V a_1 = v_t_2426; V a_2 = v_t_2427; V r_ = (g_heff_2ecompile_2ecpr_2ebuiltOut(a_0, a_1, a_2)); heff_drop(v_t_2427); r_; });
  }
  case TAG_EProj: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam5, 1, 1, (V[]){v_e_241});
  }
  case TAG_ETag: {
    V v_t_2433 = heff_field(v_e_241, 0);
    V v_args_2434 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 3);
    HeffT2 v_t_2436 = (g_list_2efind_24s558881959x1385112442_24cpr(v_t_2433, heff_dup(heff_rfield(v_lay_240, 5))));
    V v_t_2440;
    {
      V v_field_2438 = v_t_2436.f[1];
      int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
      if ((v_tag_2437 == ((int64_t)0ULL))) {
        heff_drop(v_t_2433);
        V v_x_2439 = v_field_2438;
        v_t_2440 = v_x_2439;
      } else {
        heff_drop(v_field_2438);
        v_t_2440 = heff_rec_n(4, shape_tag__index__tys__places, (V[]){v_t_2433, MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
    }
    return ({ V a_0 = v_lay_240; V a_1 = v_t_2440; V a_2 = v_args_2434; V r_ = (g_heff_2ecompile_2ecpr_2ebuiltOut(a_0, a_1, a_2)); heff_drop(v_args_2434); r_; });
  }
  case TAG_EMatch: {
    V v_s_2441 = heff_field(v_e_241, 0);
    V v_arms_2442 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_go_2443 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eoutRw_clo), 1, (V[]){v_lay_240}));
    V v_m_2453 = (g_prelude_2etraverse_24s1673840189x4008143(heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam6, 1, 1, (V[]){v_go_2443}), v_arms_2442));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam8, 1, 2, (V[]){v_m_2453, v_s_2441});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam9, 1, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam10, 1, 1, (V[]){v_e_241});
  }
  case TAG_ECall: {
    V v_g_2463 = heff_field(v_e_241, 0);
    V v_args_2464 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam11, 1, 2, (V[]){v_g_2463, v_args_2464});
  }
  case TAG_EInt: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam12, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam13, 1, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam14, 1, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam15, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam16, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam17, 1, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam18, 1, 1, (V[]){v_e_241});
  }
  case TAG_EBool: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam19, 1, 1, (V[]){v_e_241});
  }
  case TAG_ESet: {
    V v_xs_2483 = heff_field(v_e_241, 0);
    V v_a_2484 = heff_field(v_e_241, 1);
    V v_b_2485 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2486 = (g_heff_2ecompile_2ecpr_2eoutRw(v_lay_240, v_b_2485));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam20, 1, 3, (V[]){v_m_2486, v_xs_2483, v_a_2484});
  }
  case TAG_EValues: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam21, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam22, 1, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2ecpr_2eoutRw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eoutRw(a[0], a[1]);
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_243});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_245});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_248});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam3(V self, V *args) {
  V v_n_2411 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2411});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam4(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_a_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2412, v_a_2413, v_x_2418}), v_n_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam5(V self, V *args) {
  V v_n_2432 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2432});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam7(V self, V *args) {
  V v_n_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_t_2445 = heff_env(self)[1];
  V v_ws_2446 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_n_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_n_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2445, v_ws_2446, v_x_2451}), v_n_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam6(V self, V *args) {
  V v_x2_2444 = args[0];
  V v_go_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2444)) {
  case TAG_MkArm: {
    V v_t_2445 = heff_field(v_x2_2444, 0);
    V v_ws_2446 = heff_field(v_x2_2444, 1);
    V v_b_2447 = heff_field(v_x2_2444, 2);
    heff_take_n(v_x2_2444, 7ULL, 3);
    V v_m_2448 = heff_tr(heff_call(v_go_2443, 1, (V[]){v_b_2447}));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam7, 1, 3, (V[]){v_m_2448, v_t_2445, v_ws_2446});
  }
  default: return heff_nomatch(v_x2_2444);
  }
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam8(V self, V *args) {
  V v_n_2454 = args[0];
  V v_m_2453 = heff_env(self)[0];
  V v_s_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2455 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_n_2454}));
  switch (heff_tag_of(v_x2_2455)) {
  case TAG_MkPair: {
    V v_x_2456 = heff_field(v_x2_2455, 0);
    V v_n_2457 = heff_field(v_x2_2455, 1);
    V v_ru_24x2_2455_24MkPair = heff_take_reuse_n(v_x2_2455, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2441, v_x_2456}), v_n_2457});
  }
  default: return heff_nomatch(v_x2_2455);
  }
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam9(V self, V *args) {
  V v_n_2459 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2459});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam10(V self, V *args) {
  V v_n_2462 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2462});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam11(V self, V *args) {
  V v_n_2465 = args[0];
  V v_g_2463 = heff_env(self)[0];
  V v_args_2464 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2466 = heff_tag_n(TAG_ECall, 2, (V[]){heff_strAppend(v_g_2463, ((V)&g_heff_2ecompile_2ecpr_2eoutRw_str2)), v_args_2464});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2466, v_n_2465});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam12(V self, V *args) {
  V v_n_2468 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2468});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam13(V self, V *args) {
  V v_n_2470 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2470});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam14(V self, V *args) {
  V v_n_2472 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2472});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam15(V self, V *args) {
  V v_n_2474 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2474});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam16(V self, V *args) {
  V v_n_2477 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2477});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam17(V self, V *args) {
  V v_n_2479 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2479});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam18(V self, V *args) {
  V v_n_2480 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2480});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam19(V self, V *args) {
  V v_n_2482 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2482});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam20(V self, V *args) {
  V v_n_2487 = args[0];
  V v_m_2486 = heff_env(self)[0];
  V v_xs_2483 = heff_env(self)[1];
  V v_a_2484 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2488 = heff_tr(heff_call(v_m_2486, 1, (V[]){v_n_2487}));
  switch (heff_tag_of(v_x2_2488)) {
  case TAG_MkPair: {
    V v_x_2489 = heff_field(v_x2_2488, 0);
    V v_n_2490 = heff_field(v_x2_2488, 1);
    V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2488_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2483, v_a_2484, v_x_2489}), v_n_2490});
  }
  default: return heff_nomatch(v_x2_2488);
  }
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam21(V self, V *args) {
  V v_n_2492 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2492});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam22(V self, V *args) {
  V v_n_2495 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2495});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_str1, 3, "tag");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_str2, 5, "field");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_str3, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_str4, 4, "$cpr");
V g_heff_2ecompile_2ecpr_2ewrapperOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ewrapperOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ewrapperOf_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2ewrapperOf(V v_lay_240, V v_d_241, V v_xs_242) {
top: ;
  V v_key_243 = heff_take_field(v_d_241, 0);
  V v_name_244 = heff_get_n(v_d_241, 1, 3);
  V v_m_245 = (g_prelude_2etraverse_24s247294553x1909820037(MK_INT(0LL), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_str0), MK_INT(1LL), v_xs_242));
  return heff_clo_n(g_heff_2ecompile_2ecpr_2ewrapperOf_lam0, 1, 4, (V[]){v_m_245, v_lay_240, v_key_243, v_name_244});
}
V g_heff_2ecompile_2ecpr_2ewrapperOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ewrapperOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecpr_2ewrapperOf_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_lay_240 = heff_env(self)[1];
  V v_key_243 = heff_env(self)[2];
  V v_name_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = heff_dup(heff_rfield(v_lay_240, 1));
    V v_t_2412;
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V v_t_2411 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
      v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_dup(heff_rfield(v_lay_240, 2))});
    } else {
      heff_drop(v_t_2410);
      v_t_2412 = heff_dup(heff_rfield(v_lay_240, 2));
    }
    V v_t_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2412; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
    V v_t_2414 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2413, MK_INT(1LL))));
    HeffT2 v_t_2415 = (g_prelude_2etraverse_24s1400036078x174253642_24cpr(heff_dup(v_lay_240), MK_INT(0LL), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_str1), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_str2), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_str3), MK_INT(1LL), v_t_2414, v_n_249));
    {
      V v_field_2416 = v_t_2415.f[0];
      V v_field_2417 = v_t_2415.f[1];
      V v_x_2418 = v_field_2416;
      V v_n_2419 = v_field_2417;
      V v_t_2420 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_x_248)));
      V v_t_2421 = heff_tag_n(TAG_ECall, 2, (V[]){heff_strAppend(heff_dup(v_key_243), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_str4)), v_t_2420});
      V v_t_2422 = (g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(heff_dup(v_lay_240), v_x_2418, v_x_2418, heff_dup(heff_rfield(v_lay_240, 5))));
      V v_t_2423 = heff_tag_n(TAG_MkArm, 3, (V[]){heff_get_n(v_lay_240, 0, 7), v_x_2418, v_t_2422});
      V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
      V v_body_2425 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_248, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2421, v_t_2424})});
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){v_key_243, v_name_244, v_body_2425}), v_n_2419});
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2edefWith_str0, 4, "$cpr");
V g_heff_2ecompile_2ecpr_2edefWith_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam3(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam4(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam5(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam6(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam7(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam8(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam9(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam10(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam11(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam12(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam13(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam14(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam15(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam16(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam17(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam18(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam19(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam20(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam21(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam22(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam23(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam24(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam25(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam26(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam27(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam28(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam29(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam30(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam31(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam32(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam33(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam34(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam35(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam36(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam37(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam38(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam39(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam40(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam41(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam42(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam43(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam44(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam45(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam46(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam47(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam48(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam49(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam50(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam51(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam52(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam53(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam54(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam55(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam56(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam57(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam58(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam59(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam60(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam61(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam62(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam63(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam64(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam65(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam66(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam67(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam68(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam69(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2edefWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2edefWith_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2edefWith(V v_k_240, V v_d_241, V v_m_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_EVar: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_245 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_246 = (g_heff_2ecompile_2eir_2enubI(v_t_245));
    V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam0, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_246; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_246); r_; });
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      V v_m_2413 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam1, 1, 2, (V[]){v_m_2413, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_2412);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam2, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_2423 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_2424 = (g_heff_2ecompile_2eir_2enubI(v_t_2423));
    V v_t_2430 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam3, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_2424; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2424); r_; });
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop(v_t_2430);
      V v_m_2431 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam4, 1, 2, (V[]){v_m_2431, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_2430);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam5, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_ELam: {
    V v_xs_2440 = heff_field(v_t_243, 0);
    V v_b_2441 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_m_242)) {
    case TAG_Nothing: {
      heff_drop(v_xs_2440);
      heff_drop(v_b_2441);
      V v_t_2442 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
      V v_t_2443 = (g_heff_2ecompile_2eir_2enubI(v_t_2442));
      V v_t_2449 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam6, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_2443; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2443); r_; });
      if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
        heff_drop(v_t_2449);
        V v_m_2450 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
        return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam7, 1, 2, (V[]){v_m_2450, v_d_241});
      } else {
        heff_drop(v_k_240);
        heff_drop(v_t_2449);
        return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam8, 1, 1, (V[]){v_d_241});
      }
    }
    case TAG_Just: {
      V v_lay_2459 = heff_field(v_m_242, 0);
      V v_m_2460 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, v_b_2441));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam9, 1, 4, (V[]){v_m_2460, heff_dup(v_lay_2459), v_d_241, v_xs_2440});
    }
    default: return heff_nomatch(v_m_242);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_2478 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_2479 = (g_heff_2ecompile_2eir_2enubI(v_t_2478));
    V v_t_2485 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam10, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_2479; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2479); r_; });
    if ((heff_dup(v_t_2485) == NTAG(TAG_True))) {
      heff_drop(v_t_2485);
      V v_m_2486 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam11, 1, 2, (V[]){v_m_2486, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_2485);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam12, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_ELet: {
    heff_take_n(v_t_243, 0ULL, 3);
    V v_t_2498 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_2499 = (g_heff_2ecompile_2eir_2enubI(v_t_2498));
    V v_t_24105 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam13, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_2499; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2499); r_; });
    if ((heff_dup(v_t_24105) == NTAG(TAG_True))) {
      heff_drop(v_t_24105);
      V v_m_24106 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam14, 1, 2, (V[]){v_m_24106, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24105);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam15, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_24117 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24118 = (g_heff_2ecompile_2eir_2enubI(v_t_24117));
    V v_t_24124 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam16, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24118; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24118); r_; });
    if ((heff_dup(v_t_24124) == NTAG(TAG_True))) {
      heff_drop(v_t_24124);
      V v_m_24125 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam17, 1, 2, (V[]){v_m_24125, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24124);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam18, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EProj: {
    heff_take_n(v_t_243, 0ULL, 4);
    V v_t_24138 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24139 = (g_heff_2ecompile_2eir_2enubI(v_t_24138));
    V v_t_24145 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam19, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24139; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24139); r_; });
    if ((heff_dup(v_t_24145) == NTAG(TAG_True))) {
      heff_drop(v_t_24145);
      V v_m_24146 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam20, 1, 2, (V[]){v_m_24146, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24145);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam21, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_ETag: {
    heff_take_n(v_t_243, 0ULL, 3);
    V v_t_24158 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24159 = (g_heff_2ecompile_2eir_2enubI(v_t_24158));
    V v_t_24165 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam22, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24159; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24159); r_; });
    if ((heff_dup(v_t_24165) == NTAG(TAG_True))) {
      heff_drop(v_t_24165);
      V v_m_24166 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam23, 1, 2, (V[]){v_m_24166, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24165);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam24, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_24177 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24178 = (g_heff_2ecompile_2eir_2enubI(v_t_24177));
    V v_t_24184 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam25, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24178; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24178); r_; });
    if ((heff_dup(v_t_24184) == NTAG(TAG_True))) {
      heff_drop(v_t_24184);
      V v_m_24185 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam26, 1, 2, (V[]){v_m_24185, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24184);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam27, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_24195 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24196 = (g_heff_2ecompile_2eir_2enubI(v_t_24195));
    V v_t_24202 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam28, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24196; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24196); r_; });
    if ((heff_dup(v_t_24202) == NTAG(TAG_True))) {
      heff_drop(v_t_24202);
      V v_m_24203 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam29, 1, 2, (V[]){v_m_24203, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24202);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam30, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_24214 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24215 = (g_heff_2ecompile_2eir_2enubI(v_t_24214));
    V v_t_24221 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam31, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24215; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24215); r_; });
    if ((heff_dup(v_t_24221) == NTAG(TAG_True))) {
      heff_drop(v_t_24221);
      V v_m_24222 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam32, 1, 2, (V[]){v_m_24222, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24221);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam33, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_ECall: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_24233 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24234 = (g_heff_2ecompile_2eir_2enubI(v_t_24233));
    V v_t_24240 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam34, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24234; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24234); r_; });
    if ((heff_dup(v_t_24240) == NTAG(TAG_True))) {
      heff_drop(v_t_24240);
      V v_m_24241 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam35, 1, 2, (V[]){v_m_24241, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24240);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam36, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_24251 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24252 = (g_heff_2ecompile_2eir_2enubI(v_t_24251));
    V v_t_24258 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam37, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24252; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24252); r_; });
    if ((heff_dup(v_t_24258) == NTAG(TAG_True))) {
      heff_drop(v_t_24258);
      V v_m_24259 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam38, 1, 2, (V[]){v_m_24259, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24258);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam39, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EFloat: {
    heff_take_na(v_t_243, 0ULL, 1);
    V v_t_24269 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24270 = (g_heff_2ecompile_2eir_2enubI(v_t_24269));
    V v_t_24276 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam40, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24270; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24270); r_; });
    if ((heff_dup(v_t_24276) == NTAG(TAG_True))) {
      heff_drop(v_t_24276);
      V v_m_24277 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam41, 1, 2, (V[]){v_m_24277, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24276);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam42, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EStr: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_24287 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24288 = (g_heff_2ecompile_2eir_2enubI(v_t_24287));
    V v_t_24294 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam43, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24288; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24288); r_; });
    if ((heff_dup(v_t_24294) == NTAG(TAG_True))) {
      heff_drop(v_t_24294);
      V v_m_24295 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam44, 1, 2, (V[]){v_m_24295, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24294);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam45, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_24305 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24306 = (g_heff_2ecompile_2eir_2enubI(v_t_24305));
    V v_t_24312 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam46, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24306; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24306); r_; });
    if ((heff_dup(v_t_24312) == NTAG(TAG_True))) {
      heff_drop(v_t_24312);
      V v_m_24313 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam47, 1, 2, (V[]){v_m_24313, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24312);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam48, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_24324 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24325 = (g_heff_2ecompile_2eir_2enubI(v_t_24324));
    V v_t_24331 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam49, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24325; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24325); r_; });
    if ((heff_dup(v_t_24331) == NTAG(TAG_True))) {
      heff_drop(v_t_24331);
      V v_m_24332 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam50, 1, 2, (V[]){v_m_24332, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24331);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam51, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_243, 0ULL, 1);
    V v_t_24342 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24343 = (g_heff_2ecompile_2eir_2enubI(v_t_24342));
    V v_t_24349 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam52, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24343; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24343); r_; });
    if ((heff_dup(v_t_24349) == NTAG(TAG_True))) {
      heff_drop(v_t_24349);
      V v_m_24350 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam53, 1, 2, (V[]){v_m_24350, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24349);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam54, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EAbandon: {
    V v_t_24359 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24360 = (g_heff_2ecompile_2eir_2enubI(v_t_24359));
    V v_t_24366 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam55, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24360; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24360); r_; });
    if ((heff_dup(v_t_24366) == NTAG(TAG_True))) {
      heff_drop(v_t_24366);
      V v_m_24367 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam56, 1, 2, (V[]){v_m_24367, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24366);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam57, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EBool: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_24377 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24378 = (g_heff_2ecompile_2eir_2enubI(v_t_24377));
    V v_t_24384 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam58, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24378; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24378); r_; });
    if ((heff_dup(v_t_24384) == NTAG(TAG_True))) {
      heff_drop(v_t_24384);
      V v_m_24385 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam59, 1, 2, (V[]){v_m_24385, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24384);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam60, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_ESet: {
    heff_take_n(v_t_243, 0ULL, 3);
    V v_t_24397 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24398 = (g_heff_2ecompile_2eir_2enubI(v_t_24397));
    V v_t_24404 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam61, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24398; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24398); r_; });
    if ((heff_dup(v_t_24404) == NTAG(TAG_True))) {
      heff_drop(v_t_24404);
      V v_m_24405 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam62, 1, 2, (V[]){v_m_24405, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24404);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam63, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EValues: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_24415 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24416 = (g_heff_2ecompile_2eir_2enubI(v_t_24415));
    V v_t_24422 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam64, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24416; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24416); r_; });
    if ((heff_dup(v_t_24422) == NTAG(TAG_True))) {
      heff_drop(v_t_24422);
      V v_m_24423 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam65, 1, 2, (V[]){v_m_24423, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24422);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam66, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_24434 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24435 = (g_heff_2ecompile_2eir_2enubI(v_t_24434));
    V v_t_24441 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam67, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24435; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24435); r_; });
    if ((heff_dup(v_t_24441) == NTAG(TAG_True))) {
      heff_drop(v_t_24441);
      V v_m_24442 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam68, 1, 2, (V[]){v_m_24442, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24441);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam69, 1, 1, (V[]){v_d_241});
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2edefWith(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecpr_2edefWith_lam0(V self, V *args) {
  V v_g_247 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_248 = ({ V a_0 = v_k_240; V a_1 = v_g_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_247); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_249 == ((int64_t)0ULL)) && ({ V v_x_2411 = heff_dup(v_field_2410); int c_ = 1; heff_drop(v_x_2411); c_; })));
    heff_drop(v_field_2410);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam1(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = ({ V rv_2 = v_x_2416; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam2(V self, V *args) {
  V v_n_2420 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, v_n_2420});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam3(V self, V *args) {
  V v_g_2425 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2426 = ({ V a_0 = v_k_240; V a_1 = v_g_2425; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_2425); r_; });
  {
    V v_field_2428 = v_t_2426.f[1];
    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2427 == ((int64_t)0ULL)) && ({ V v_x_2429 = heff_dup(v_field_2428); int c_ = 1; heff_drop(v_x_2429); c_; })));
    heff_drop(v_field_2428);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam4(V self, V *args) {
  V v_n_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_t_2436 = ({ V rv_2 = v_x_2434; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){v_t_2437, v_n_2435});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam5(V self, V *args) {
  V v_n_2438 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2439, v_n_2438});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam6(V self, V *args) {
  V v_g_2444 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2445 = ({ V a_0 = v_k_240; V a_1 = v_g_2444; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_2444); r_; });
  {
    V v_field_2447 = v_t_2445.f[1];
    int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2446 == ((int64_t)0ULL)) && ({ V v_x_2448 = heff_dup(v_field_2447); int c_ = 1; heff_drop(v_x_2448); c_; })));
    heff_drop(v_field_2447);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam7(V self, V *args) {
  V v_n_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_n_2451}));
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_n_2454 = heff_field(v_x2_2452, 1);
    V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
    V v_t_2455 = ({ V rv_2 = v_x_2453; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, (V[]){v_t_2456, v_n_2454});
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam8(V self, V *args) {
  V v_n_2457 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2458, v_n_2457});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam9(V self, V *args) {
  V v_n_2461 = args[0];
  V v_m_2460 = heff_env(self)[0];
  V v_lay_2459 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_xs_2440 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2462 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_n_2461}));
  switch (heff_tag_of(v_x2_2462)) {
  case TAG_MkPair: {
    V v_x_2463 = heff_field(v_x2_2462, 0);
    V v_n_2464 = heff_field(v_x2_2462, 1);
    V v_ru_24x2_2462_24MkPair = heff_take_reuse_n(v_x2_2462, 3ULL, 2);
    V v_m_2465 = (g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lay_2459), v_x_2463));
    V v_x2_2466 = heff_tr(heff_call(v_m_2465, 1, (V[]){v_n_2464}));
    switch (heff_tag_of(v_x2_2466)) {
    case TAG_MkPair: {
      V v_x_2467 = heff_field(v_x2_2466, 0);
      V v_n_2468 = heff_field(v_x2_2466, 1);
      V v_ru_24x2_2466_24MkPair = heff_take_reuse_n(v_x2_2466, 3ULL, 2);
      V v_m_2469 = (g_heff_2ecompile_2ecpr_2ewrapperOf(v_lay_2459, heff_dup(v_d_241), heff_dup(v_xs_2440)));
      V v_x2_2470 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_n_2468}));
      switch (heff_tag_of(v_x2_2470)) {
      case TAG_MkPair: {
        V v_x_2471 = heff_field(v_x2_2470, 0);
        V v_n_2472 = heff_field(v_x2_2470, 1);
        heff_take_n(v_x2_2470, 3ULL, 2);
        V v_t_2473 = heff_strAppend(heff_take_field(v_d_241, 0), ((V)&g_heff_2ecompile_2ecpr_2edefWith_str0));
        V v_t_2474 = ({ V rv_0 = v_t_2473; V rv_2 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2440, v_x_2467}); V rr_ = heff_rec_reuse_nf(v_d_241, 2ULL, 3, shape_key__name__body, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2475 = heff_tag_at_n(v_ru_24x2_2466_24MkPair, TAG_Cons, 2, (V[]){v_x_2471, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_2462_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2474, v_t_2475}), v_n_2472});
      }
      default: return heff_nomatch(v_x2_2470);
      }
    }
    default: return heff_nomatch(v_x2_2466);
    }
  }
  default: return heff_nomatch(v_x2_2462);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam10(V self, V *args) {
  V v_g_2480 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2481 = ({ V a_0 = v_k_240; V a_1 = v_g_2480; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_2480); r_; });
  {
    V v_field_2483 = v_t_2481.f[1];
    int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2482 == ((int64_t)0ULL)) && ({ V v_x_2484 = heff_dup(v_field_2483); int c_ = 1; heff_drop(v_x_2484); c_; })));
    heff_drop(v_field_2483);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam11(V self, V *args) {
  V v_n_2487 = args[0];
  V v_m_2486 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2488 = heff_tr(heff_call(v_m_2486, 1, (V[]){v_n_2487}));
  switch (heff_tag_of(v_x2_2488)) {
  case TAG_MkPair: {
    V v_x_2489 = heff_field(v_x2_2488, 0);
    V v_n_2490 = heff_field(v_x2_2488, 1);
    V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
    V v_t_2491 = ({ V rv_2 = v_x_2489; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2491, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2488_24MkPair, TAG_MkPair, 2, (V[]){v_t_2492, v_n_2490});
  }
  default: return heff_nomatch(v_x2_2488);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam12(V self, V *args) {
  V v_n_2493 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2494, v_n_2493});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam13(V self, V *args) {
  V v_g_24100 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24101 = ({ V a_0 = v_k_240; V a_1 = v_g_24100; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24100); r_; });
  {
    V v_field_24103 = v_t_24101.f[1];
    int64_t v_tag_24102 = ((int64_t)v_t_24101.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24102 == ((int64_t)0ULL)) && ({ V v_x_24104 = heff_dup(v_field_24103); int c_ = 1; heff_drop(v_x_24104); c_; })));
    heff_drop(v_field_24103);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam14(V self, V *args) {
  V v_n_24107 = args[0];
  V v_m_24106 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24108 = heff_tr(heff_call(v_m_24106, 1, (V[]){v_n_24107}));
  switch (heff_tag_of(v_x2_24108)) {
  case TAG_MkPair: {
    V v_x_24109 = heff_field(v_x2_24108, 0);
    V v_n_24110 = heff_field(v_x2_24108, 1);
    V v_ru_24x2_24108_24MkPair = heff_take_reuse_n(v_x2_24108, 3ULL, 2);
    V v_t_24111 = ({ V rv_2 = v_x_24109; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24112 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24111, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24108_24MkPair, TAG_MkPair, 2, (V[]){v_t_24112, v_n_24110});
  }
  default: return heff_nomatch(v_x2_24108);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam15(V self, V *args) {
  V v_n_24113 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24114 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24114, v_n_24113});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam16(V self, V *args) {
  V v_g_24119 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24120 = ({ V a_0 = v_k_240; V a_1 = v_g_24119; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24119); r_; });
  {
    V v_field_24122 = v_t_24120.f[1];
    int64_t v_tag_24121 = ((int64_t)v_t_24120.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24121 == ((int64_t)0ULL)) && ({ V v_x_24123 = heff_dup(v_field_24122); int c_ = 1; heff_drop(v_x_24123); c_; })));
    heff_drop(v_field_24122);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam17(V self, V *args) {
  V v_n_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_n_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_n_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    V v_t_24130 = ({ V rv_2 = v_x_24128; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24131 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24130, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, (V[]){v_t_24131, v_n_24129});
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam18(V self, V *args) {
  V v_n_24132 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24133 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24133, v_n_24132});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam19(V self, V *args) {
  V v_g_24140 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24141 = ({ V a_0 = v_k_240; V a_1 = v_g_24140; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24140); r_; });
  {
    V v_field_24143 = v_t_24141.f[1];
    int64_t v_tag_24142 = ((int64_t)v_t_24141.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24142 == ((int64_t)0ULL)) && ({ V v_x_24144 = heff_dup(v_field_24143); int c_ = 1; heff_drop(v_x_24144); c_; })));
    heff_drop(v_field_24143);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam20(V self, V *args) {
  V v_n_24147 = args[0];
  V v_m_24146 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24148 = heff_tr(heff_call(v_m_24146, 1, (V[]){v_n_24147}));
  switch (heff_tag_of(v_x2_24148)) {
  case TAG_MkPair: {
    V v_x_24149 = heff_field(v_x2_24148, 0);
    V v_n_24150 = heff_field(v_x2_24148, 1);
    V v_ru_24x2_24148_24MkPair = heff_take_reuse_n(v_x2_24148, 3ULL, 2);
    V v_t_24151 = ({ V rv_2 = v_x_24149; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24152 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24151, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24148_24MkPair, TAG_MkPair, 2, (V[]){v_t_24152, v_n_24150});
  }
  default: return heff_nomatch(v_x2_24148);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam21(V self, V *args) {
  V v_n_24153 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24154 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24154, v_n_24153});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam22(V self, V *args) {
  V v_g_24160 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24161 = ({ V a_0 = v_k_240; V a_1 = v_g_24160; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24160); r_; });
  {
    V v_field_24163 = v_t_24161.f[1];
    int64_t v_tag_24162 = ((int64_t)v_t_24161.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24162 == ((int64_t)0ULL)) && ({ V v_x_24164 = heff_dup(v_field_24163); int c_ = 1; heff_drop(v_x_24164); c_; })));
    heff_drop(v_field_24163);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam23(V self, V *args) {
  V v_n_24167 = args[0];
  V v_m_24166 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24168 = heff_tr(heff_call(v_m_24166, 1, (V[]){v_n_24167}));
  switch (heff_tag_of(v_x2_24168)) {
  case TAG_MkPair: {
    V v_x_24169 = heff_field(v_x2_24168, 0);
    V v_n_24170 = heff_field(v_x2_24168, 1);
    V v_ru_24x2_24168_24MkPair = heff_take_reuse_n(v_x2_24168, 3ULL, 2);
    V v_t_24171 = ({ V rv_2 = v_x_24169; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24172 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24171, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24168_24MkPair, TAG_MkPair, 2, (V[]){v_t_24172, v_n_24170});
  }
  default: return heff_nomatch(v_x2_24168);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam24(V self, V *args) {
  V v_n_24173 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24174 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24174, v_n_24173});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam25(V self, V *args) {
  V v_g_24179 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24180 = ({ V a_0 = v_k_240; V a_1 = v_g_24179; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24179); r_; });
  {
    V v_field_24182 = v_t_24180.f[1];
    int64_t v_tag_24181 = ((int64_t)v_t_24180.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24181 == ((int64_t)0ULL)) && ({ V v_x_24183 = heff_dup(v_field_24182); int c_ = 1; heff_drop(v_x_24183); c_; })));
    heff_drop(v_field_24182);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam26(V self, V *args) {
  V v_n_24186 = args[0];
  V v_m_24185 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24187 = heff_tr(heff_call(v_m_24185, 1, (V[]){v_n_24186}));
  switch (heff_tag_of(v_x2_24187)) {
  case TAG_MkPair: {
    V v_x_24188 = heff_field(v_x2_24187, 0);
    V v_n_24189 = heff_field(v_x2_24187, 1);
    V v_ru_24x2_24187_24MkPair = heff_take_reuse_n(v_x2_24187, 3ULL, 2);
    V v_t_24190 = ({ V rv_2 = v_x_24188; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24191 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24190, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24187_24MkPair, TAG_MkPair, 2, (V[]){v_t_24191, v_n_24189});
  }
  default: return heff_nomatch(v_x2_24187);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam27(V self, V *args) {
  V v_n_24192 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24193 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24193, v_n_24192});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam28(V self, V *args) {
  V v_g_24197 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24198 = ({ V a_0 = v_k_240; V a_1 = v_g_24197; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24197); r_; });
  {
    V v_field_24200 = v_t_24198.f[1];
    int64_t v_tag_24199 = ((int64_t)v_t_24198.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24199 == ((int64_t)0ULL)) && ({ V v_x_24201 = heff_dup(v_field_24200); int c_ = 1; heff_drop(v_x_24201); c_; })));
    heff_drop(v_field_24200);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam29(V self, V *args) {
  V v_n_24204 = args[0];
  V v_m_24203 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24205 = heff_tr(heff_call(v_m_24203, 1, (V[]){v_n_24204}));
  switch (heff_tag_of(v_x2_24205)) {
  case TAG_MkPair: {
    V v_x_24206 = heff_field(v_x2_24205, 0);
    V v_n_24207 = heff_field(v_x2_24205, 1);
    V v_ru_24x2_24205_24MkPair = heff_take_reuse_n(v_x2_24205, 3ULL, 2);
    V v_t_24208 = ({ V rv_2 = v_x_24206; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24209 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24208, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24205_24MkPair, TAG_MkPair, 2, (V[]){v_t_24209, v_n_24207});
  }
  default: return heff_nomatch(v_x2_24205);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam30(V self, V *args) {
  V v_n_24210 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24211 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24211, v_n_24210});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam31(V self, V *args) {
  V v_g_24216 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24217 = ({ V a_0 = v_k_240; V a_1 = v_g_24216; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24216); r_; });
  {
    V v_field_24219 = v_t_24217.f[1];
    int64_t v_tag_24218 = ((int64_t)v_t_24217.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24218 == ((int64_t)0ULL)) && ({ V v_x_24220 = heff_dup(v_field_24219); int c_ = 1; heff_drop(v_x_24220); c_; })));
    heff_drop(v_field_24219);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam32(V self, V *args) {
  V v_n_24223 = args[0];
  V v_m_24222 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24224 = heff_tr(heff_call(v_m_24222, 1, (V[]){v_n_24223}));
  switch (heff_tag_of(v_x2_24224)) {
  case TAG_MkPair: {
    V v_x_24225 = heff_field(v_x2_24224, 0);
    V v_n_24226 = heff_field(v_x2_24224, 1);
    V v_ru_24x2_24224_24MkPair = heff_take_reuse_n(v_x2_24224, 3ULL, 2);
    V v_t_24227 = ({ V rv_2 = v_x_24225; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24228 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24227, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24224_24MkPair, TAG_MkPair, 2, (V[]){v_t_24228, v_n_24226});
  }
  default: return heff_nomatch(v_x2_24224);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam33(V self, V *args) {
  V v_n_24229 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24230 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24230, v_n_24229});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam34(V self, V *args) {
  V v_g_24235 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24236 = ({ V a_0 = v_k_240; V a_1 = v_g_24235; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24235); r_; });
  {
    V v_field_24238 = v_t_24236.f[1];
    int64_t v_tag_24237 = ((int64_t)v_t_24236.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24237 == ((int64_t)0ULL)) && ({ V v_x_24239 = heff_dup(v_field_24238); int c_ = 1; heff_drop(v_x_24239); c_; })));
    heff_drop(v_field_24238);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam35(V self, V *args) {
  V v_n_24242 = args[0];
  V v_m_24241 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24243 = heff_tr(heff_call(v_m_24241, 1, (V[]){v_n_24242}));
  switch (heff_tag_of(v_x2_24243)) {
  case TAG_MkPair: {
    V v_x_24244 = heff_field(v_x2_24243, 0);
    V v_n_24245 = heff_field(v_x2_24243, 1);
    V v_ru_24x2_24243_24MkPair = heff_take_reuse_n(v_x2_24243, 3ULL, 2);
    V v_t_24246 = ({ V rv_2 = v_x_24244; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24246, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24243_24MkPair, TAG_MkPair, 2, (V[]){v_t_24247, v_n_24245});
  }
  default: return heff_nomatch(v_x2_24243);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam36(V self, V *args) {
  V v_n_24248 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24249 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24249, v_n_24248});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam37(V self, V *args) {
  V v_g_24253 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24254 = ({ V a_0 = v_k_240; V a_1 = v_g_24253; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24253); r_; });
  {
    V v_field_24256 = v_t_24254.f[1];
    int64_t v_tag_24255 = ((int64_t)v_t_24254.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24255 == ((int64_t)0ULL)) && ({ V v_x_24257 = heff_dup(v_field_24256); int c_ = 1; heff_drop(v_x_24257); c_; })));
    heff_drop(v_field_24256);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam38(V self, V *args) {
  V v_n_24260 = args[0];
  V v_m_24259 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24261 = heff_tr(heff_call(v_m_24259, 1, (V[]){v_n_24260}));
  switch (heff_tag_of(v_x2_24261)) {
  case TAG_MkPair: {
    V v_x_24262 = heff_field(v_x2_24261, 0);
    V v_n_24263 = heff_field(v_x2_24261, 1);
    V v_ru_24x2_24261_24MkPair = heff_take_reuse_n(v_x2_24261, 3ULL, 2);
    V v_t_24264 = ({ V rv_2 = v_x_24262; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24265 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24264, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24261_24MkPair, TAG_MkPair, 2, (V[]){v_t_24265, v_n_24263});
  }
  default: return heff_nomatch(v_x2_24261);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam39(V self, V *args) {
  V v_n_24266 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24267 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24267, v_n_24266});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam40(V self, V *args) {
  V v_g_24271 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24272 = ({ V a_0 = v_k_240; V a_1 = v_g_24271; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24271); r_; });
  {
    V v_field_24274 = v_t_24272.f[1];
    int64_t v_tag_24273 = ((int64_t)v_t_24272.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24273 == ((int64_t)0ULL)) && ({ V v_x_24275 = heff_dup(v_field_24274); int c_ = 1; heff_drop(v_x_24275); c_; })));
    heff_drop(v_field_24274);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam41(V self, V *args) {
  V v_n_24278 = args[0];
  V v_m_24277 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24279 = heff_tr(heff_call(v_m_24277, 1, (V[]){v_n_24278}));
  switch (heff_tag_of(v_x2_24279)) {
  case TAG_MkPair: {
    V v_x_24280 = heff_field(v_x2_24279, 0);
    V v_n_24281 = heff_field(v_x2_24279, 1);
    V v_ru_24x2_24279_24MkPair = heff_take_reuse_n(v_x2_24279, 3ULL, 2);
    V v_t_24282 = ({ V rv_2 = v_x_24280; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24283 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24282, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24279_24MkPair, TAG_MkPair, 2, (V[]){v_t_24283, v_n_24281});
  }
  default: return heff_nomatch(v_x2_24279);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam42(V self, V *args) {
  V v_n_24284 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24285 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24285, v_n_24284});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam43(V self, V *args) {
  V v_g_24289 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24290 = ({ V a_0 = v_k_240; V a_1 = v_g_24289; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24289); r_; });
  {
    V v_field_24292 = v_t_24290.f[1];
    int64_t v_tag_24291 = ((int64_t)v_t_24290.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24291 == ((int64_t)0ULL)) && ({ V v_x_24293 = heff_dup(v_field_24292); int c_ = 1; heff_drop(v_x_24293); c_; })));
    heff_drop(v_field_24292);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam44(V self, V *args) {
  V v_n_24296 = args[0];
  V v_m_24295 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24297 = heff_tr(heff_call(v_m_24295, 1, (V[]){v_n_24296}));
  switch (heff_tag_of(v_x2_24297)) {
  case TAG_MkPair: {
    V v_x_24298 = heff_field(v_x2_24297, 0);
    V v_n_24299 = heff_field(v_x2_24297, 1);
    V v_ru_24x2_24297_24MkPair = heff_take_reuse_n(v_x2_24297, 3ULL, 2);
    V v_t_24300 = ({ V rv_2 = v_x_24298; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24301 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24300, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24297_24MkPair, TAG_MkPair, 2, (V[]){v_t_24301, v_n_24299});
  }
  default: return heff_nomatch(v_x2_24297);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam45(V self, V *args) {
  V v_n_24302 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24303 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24303, v_n_24302});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam46(V self, V *args) {
  V v_g_24307 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24308 = ({ V a_0 = v_k_240; V a_1 = v_g_24307; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24307); r_; });
  {
    V v_field_24310 = v_t_24308.f[1];
    int64_t v_tag_24309 = ((int64_t)v_t_24308.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24309 == ((int64_t)0ULL)) && ({ V v_x_24311 = heff_dup(v_field_24310); int c_ = 1; heff_drop(v_x_24311); c_; })));
    heff_drop(v_field_24310);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam47(V self, V *args) {
  V v_n_24314 = args[0];
  V v_m_24313 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24315 = heff_tr(heff_call(v_m_24313, 1, (V[]){v_n_24314}));
  switch (heff_tag_of(v_x2_24315)) {
  case TAG_MkPair: {
    V v_x_24316 = heff_field(v_x2_24315, 0);
    V v_n_24317 = heff_field(v_x2_24315, 1);
    V v_ru_24x2_24315_24MkPair = heff_take_reuse_n(v_x2_24315, 3ULL, 2);
    V v_t_24318 = ({ V rv_2 = v_x_24316; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24319 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24318, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24315_24MkPair, TAG_MkPair, 2, (V[]){v_t_24319, v_n_24317});
  }
  default: return heff_nomatch(v_x2_24315);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam48(V self, V *args) {
  V v_n_24320 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24321 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24321, v_n_24320});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam49(V self, V *args) {
  V v_g_24326 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24327 = ({ V a_0 = v_k_240; V a_1 = v_g_24326; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24326); r_; });
  {
    V v_field_24329 = v_t_24327.f[1];
    int64_t v_tag_24328 = ((int64_t)v_t_24327.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24328 == ((int64_t)0ULL)) && ({ V v_x_24330 = heff_dup(v_field_24329); int c_ = 1; heff_drop(v_x_24330); c_; })));
    heff_drop(v_field_24329);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam50(V self, V *args) {
  V v_n_24333 = args[0];
  V v_m_24332 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24334 = heff_tr(heff_call(v_m_24332, 1, (V[]){v_n_24333}));
  switch (heff_tag_of(v_x2_24334)) {
  case TAG_MkPair: {
    V v_x_24335 = heff_field(v_x2_24334, 0);
    V v_n_24336 = heff_field(v_x2_24334, 1);
    V v_ru_24x2_24334_24MkPair = heff_take_reuse_n(v_x2_24334, 3ULL, 2);
    V v_t_24337 = ({ V rv_2 = v_x_24335; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24338 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24337, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24334_24MkPair, TAG_MkPair, 2, (V[]){v_t_24338, v_n_24336});
  }
  default: return heff_nomatch(v_x2_24334);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam51(V self, V *args) {
  V v_n_24339 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24340 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24340, v_n_24339});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam52(V self, V *args) {
  V v_g_24344 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24345 = ({ V a_0 = v_k_240; V a_1 = v_g_24344; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24344); r_; });
  {
    V v_field_24347 = v_t_24345.f[1];
    int64_t v_tag_24346 = ((int64_t)v_t_24345.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24346 == ((int64_t)0ULL)) && ({ V v_x_24348 = heff_dup(v_field_24347); int c_ = 1; heff_drop(v_x_24348); c_; })));
    heff_drop(v_field_24347);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam53(V self, V *args) {
  V v_n_24351 = args[0];
  V v_m_24350 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24352 = heff_tr(heff_call(v_m_24350, 1, (V[]){v_n_24351}));
  switch (heff_tag_of(v_x2_24352)) {
  case TAG_MkPair: {
    V v_x_24353 = heff_field(v_x2_24352, 0);
    V v_n_24354 = heff_field(v_x2_24352, 1);
    V v_ru_24x2_24352_24MkPair = heff_take_reuse_n(v_x2_24352, 3ULL, 2);
    V v_t_24355 = ({ V rv_2 = v_x_24353; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24356 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24355, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24352_24MkPair, TAG_MkPair, 2, (V[]){v_t_24356, v_n_24354});
  }
  default: return heff_nomatch(v_x2_24352);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam54(V self, V *args) {
  V v_n_24357 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24358 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24358, v_n_24357});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam55(V self, V *args) {
  V v_g_24361 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24362 = ({ V a_0 = v_k_240; V a_1 = v_g_24361; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24361); r_; });
  {
    V v_field_24364 = v_t_24362.f[1];
    int64_t v_tag_24363 = ((int64_t)v_t_24362.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24363 == ((int64_t)0ULL)) && ({ V v_x_24365 = heff_dup(v_field_24364); int c_ = 1; heff_drop(v_x_24365); c_; })));
    heff_drop(v_field_24364);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam56(V self, V *args) {
  V v_n_24368 = args[0];
  V v_m_24367 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24369 = heff_tr(heff_call(v_m_24367, 1, (V[]){v_n_24368}));
  switch (heff_tag_of(v_x2_24369)) {
  case TAG_MkPair: {
    V v_x_24370 = heff_field(v_x2_24369, 0);
    V v_n_24371 = heff_field(v_x2_24369, 1);
    V v_ru_24x2_24369_24MkPair = heff_take_reuse_n(v_x2_24369, 3ULL, 2);
    V v_t_24372 = ({ V rv_2 = v_x_24370; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24373 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24372, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24369_24MkPair, TAG_MkPair, 2, (V[]){v_t_24373, v_n_24371});
  }
  default: return heff_nomatch(v_x2_24369);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam57(V self, V *args) {
  V v_n_24374 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24375 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24375, v_n_24374});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam58(V self, V *args) {
  V v_g_24379 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24380 = ({ V a_0 = v_k_240; V a_1 = v_g_24379; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24379); r_; });
  {
    V v_field_24382 = v_t_24380.f[1];
    int64_t v_tag_24381 = ((int64_t)v_t_24380.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24381 == ((int64_t)0ULL)) && ({ V v_x_24383 = heff_dup(v_field_24382); int c_ = 1; heff_drop(v_x_24383); c_; })));
    heff_drop(v_field_24382);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam59(V self, V *args) {
  V v_n_24386 = args[0];
  V v_m_24385 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24387 = heff_tr(heff_call(v_m_24385, 1, (V[]){v_n_24386}));
  switch (heff_tag_of(v_x2_24387)) {
  case TAG_MkPair: {
    V v_x_24388 = heff_field(v_x2_24387, 0);
    V v_n_24389 = heff_field(v_x2_24387, 1);
    V v_ru_24x2_24387_24MkPair = heff_take_reuse_n(v_x2_24387, 3ULL, 2);
    V v_t_24390 = ({ V rv_2 = v_x_24388; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24391 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24390, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24387_24MkPair, TAG_MkPair, 2, (V[]){v_t_24391, v_n_24389});
  }
  default: return heff_nomatch(v_x2_24387);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam60(V self, V *args) {
  V v_n_24392 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24393 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24393, v_n_24392});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam61(V self, V *args) {
  V v_g_24399 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24400 = ({ V a_0 = v_k_240; V a_1 = v_g_24399; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24399); r_; });
  {
    V v_field_24402 = v_t_24400.f[1];
    int64_t v_tag_24401 = ((int64_t)v_t_24400.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24401 == ((int64_t)0ULL)) && ({ V v_x_24403 = heff_dup(v_field_24402); int c_ = 1; heff_drop(v_x_24403); c_; })));
    heff_drop(v_field_24402);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam62(V self, V *args) {
  V v_n_24406 = args[0];
  V v_m_24405 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24407 = heff_tr(heff_call(v_m_24405, 1, (V[]){v_n_24406}));
  switch (heff_tag_of(v_x2_24407)) {
  case TAG_MkPair: {
    V v_x_24408 = heff_field(v_x2_24407, 0);
    V v_n_24409 = heff_field(v_x2_24407, 1);
    V v_ru_24x2_24407_24MkPair = heff_take_reuse_n(v_x2_24407, 3ULL, 2);
    V v_t_24410 = ({ V rv_2 = v_x_24408; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24410, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24407_24MkPair, TAG_MkPair, 2, (V[]){v_t_24411, v_n_24409});
  }
  default: return heff_nomatch(v_x2_24407);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam63(V self, V *args) {
  V v_n_24412 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24413 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24413, v_n_24412});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam64(V self, V *args) {
  V v_g_24417 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24418 = ({ V a_0 = v_k_240; V a_1 = v_g_24417; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24417); r_; });
  {
    V v_field_24420 = v_t_24418.f[1];
    int64_t v_tag_24419 = ((int64_t)v_t_24418.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24419 == ((int64_t)0ULL)) && ({ V v_x_24421 = heff_dup(v_field_24420); int c_ = 1; heff_drop(v_x_24421); c_; })));
    heff_drop(v_field_24420);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam65(V self, V *args) {
  V v_n_24424 = args[0];
  V v_m_24423 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24425 = heff_tr(heff_call(v_m_24423, 1, (V[]){v_n_24424}));
  switch (heff_tag_of(v_x2_24425)) {
  case TAG_MkPair: {
    V v_x_24426 = heff_field(v_x2_24425, 0);
    V v_n_24427 = heff_field(v_x2_24425, 1);
    V v_ru_24x2_24425_24MkPair = heff_take_reuse_n(v_x2_24425, 3ULL, 2);
    V v_t_24428 = ({ V rv_2 = v_x_24426; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24428, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24425_24MkPair, TAG_MkPair, 2, (V[]){v_t_24429, v_n_24427});
  }
  default: return heff_nomatch(v_x2_24425);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam66(V self, V *args) {
  V v_n_24430 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24431 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24431, v_n_24430});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam67(V self, V *args) {
  V v_g_24436 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24437 = ({ V a_0 = v_k_240; V a_1 = v_g_24436; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24436); r_; });
  {
    V v_field_24439 = v_t_24437.f[1];
    int64_t v_tag_24438 = ((int64_t)v_t_24437.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24438 == ((int64_t)0ULL)) && ({ V v_x_24440 = heff_dup(v_field_24439); int c_ = 1; heff_drop(v_x_24440); c_; })));
    heff_drop(v_field_24439);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam68(V self, V *args) {
  V v_n_24443 = args[0];
  V v_m_24442 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24444 = heff_tr(heff_call(v_m_24442, 1, (V[]){v_n_24443}));
  switch (heff_tag_of(v_x2_24444)) {
  case TAG_MkPair: {
    V v_x_24445 = heff_field(v_x2_24444, 0);
    V v_n_24446 = heff_field(v_x2_24444, 1);
    V v_ru_24x2_24444_24MkPair = heff_take_reuse_n(v_x2_24444, 3ULL, 2);
    V v_t_24447 = ({ V rv_2 = v_x_24445; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24447, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24444_24MkPair, TAG_MkPair, 2, (V[]){v_t_24448, v_n_24446});
  }
  default: return heff_nomatch(v_x2_24444);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam69(V self, V *args) {
  V v_n_24449 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24450 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24450, v_n_24449});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecprWith_str0, 4, "$cpr");
V g_heff_2ecompile_2ecpr_2ecprWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ecprWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ecprWith_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2ecprWith(V v_supply_240, V v_defs_241, V v_k_242) {
top: ;
  V v_t_243 = (g_std_2emap_2esize(v_k_242));
  if (heff_intEq_c(v_t_243, MK_INT(0LL))) {
    heff_drop(v_k_242);
    return heff_rec_n(3, shape_defs__supply__tuples, (V[]){v_defs_241, v_supply_240, heff_dup(g_std_2emap_2eempty_get())});
  } else {
    V v_t_246 = (g_prelude_2etraverse_24s1673840189x4008143(heff_clo_n(g_heff_2ecompile_2ecpr_2ecprWith_lam0, 1, 1, (V[]){heff_dup(v_k_242)}), v_defs_241));
    V v_t_247 = heff_tr(heff_call(v_t_246, 1, (V[]){v_supply_240}));
    switch (heff_tag_of(v_t_247)) {
    case TAG_MkPair: {
      V v_dss_248 = heff_field(v_t_247, 0);
      V v_n_249 = heff_field(v_t_247, 1);
      heff_take_n(v_t_247, 3ULL, 2);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_dss_248));
      V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = ({ V a_0 = v_k_242; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_k_242); r_; });
      V v_ps_2413 = (g_list_2emap_24s273193875x235978955(((V)&g_heff_2ecompile_2ecpr_2ecprWith_str0), MK_INT(1LL), MK_INT(0LL), v_t_2412));
      V v_t_2414 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2413; V r_ = (g_list_2efoldl_24s571527232x333134686(a_0, a_1)); heff_drop(v_ps_2413); r_; });
      return heff_rec_n(3, shape_defs__supply__tuples, (V[]){v_t_2411, v_n_249, v_t_2414});
    }
    default: return heff_nomatch(v_t_247);
    }
  }
}
V g_heff_2ecompile_2ecpr_2ecprWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ecprWith(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecpr_2ecprWith_lam0(V self, V *args) {
  V v_d_244 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = (g_std_2emap_2elookup_24s1930949324x2078207031(v_k_242, heff_rfield(v_d_244, 0)));
  return ({ V a_0 = v_k_242; V a_1 = v_d_244; V a_2 = v_t_245; V r_ = (g_heff_2ecompile_2ecpr_2edefWith(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_str1, 0, "");
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2(V v_tok_240, V v_lay_241, V v_vs_242, V v_c_243) {
top: ;
  V v_places_244 = heff_take_field(v_c_243, 3);
  V v_tys_245 = heff_take_field(v_c_243, 2);
  V v_tag_246 = heff_get_n(v_c_243, 0, 4);
  V v_record_247 = heff_take_field(v_lay_241, 3);
  V v_numbered_248 = heff_take_field(v_lay_241, 1);
  V v_labels_249 = heff_get_n(v_lay_241, 4, 7);
  if ((heff_dup(v_record_247) == NTAG(TAG_True))) {
    heff_drop(v_tag_246);
    heff_drop(v_record_247);
    V v_t_2420 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam0, 2, 2, (V[]){v_numbered_248, heff_dup(v_vs_242)}), v_labels_249, v_places_244));
    return heff_tag_at_n(v_tok_240, TAG_ERecord, 2, (V[]){v_t_2420, v_tys_245});
  } else {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_record_247);
    heff_drop(v_labels_249);
    V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam1, 1, 2, (V[]){v_numbered_248, heff_dup(v_vs_242)}), v_places_244));
    return heff_tag_n(TAG_ETag, 3, (V[]){v_tag_246, v_t_2430, v_tys_245});
  }
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam0(V self, V *args) {
  V v_l_2410 = args[0];
  V v_i_2411 = args[1];
  V v_numbered_248 = heff_env(self)[0];
  V v_vs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412;
  if ((heff_dup(v_numbered_248) == NTAG(TAG_True))) {
    heff_drop(v_numbered_248);
    v_t_2412 = heff_intAdd(v_i_2411, MK_INT(1LL));
  } else {
    heff_drop(v_numbered_248);
    v_t_2412 = v_i_2411;
  }
  HeffT3 v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = v_vs_242; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_242); r_; });
  V v_t_2419;
  {
    V v_field_2415 = v_t_2413.f[1];
    V v_field_2416 = v_t_2413.f[2];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_x_2417 = v_field_2415;
      V v_x12_2418 = v_field_2416;
      heff_drop(v_x12_2418);
      v_t_2419 = v_x_2417;
    } else {
      heff_drop(v_field_2415);
      heff_drop(v_field_2416);
      v_t_2419 = ((V)&g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_str0);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2410, heff_tag_n(TAG_EVar, 1, (V[]){v_t_2419})});
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam1(V self, V *args) {
  V v_i_2421 = args[0];
  V v_numbered_248 = heff_env(self)[0];
  V v_vs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422;
  if ((heff_dup(v_numbered_248) == NTAG(TAG_True))) {
    heff_drop(v_numbered_248);
    v_t_2422 = heff_intAdd(v_i_2421, MK_INT(1LL));
  } else {
    heff_drop(v_numbered_248);
    v_t_2422 = v_i_2421;
  }
  HeffT3 v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = v_vs_242; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_242); r_; });
  V v_t_2429;
  {
    V v_field_2425 = v_t_2423.f[1];
    V v_field_2426 = v_t_2423.f[2];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    if ((v_tag_2424 == ((int64_t)0ULL))) {
      V v_x_2427 = v_field_2425;
      V v_x12_2428 = v_field_2426;
      heff_drop(v_x12_2428);
      v_t_2429 = v_x_2427;
    } else {
      heff_drop(v_field_2425);
      heff_drop(v_field_2426);
      v_t_2429 = ((V)&g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_str1);
    }
  }
  return heff_tag_n(TAG_EVar, 1, (V[]){v_t_2429});
}
V g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2_entry, 6, 0};

V g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2(V v_tok_240, V v_g_241, V v_args_242, V v_arms_243, V v_x4_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nothing: {
    V v_t_246 = heff_tag_at_n(v_tok_240, TAG_EMatch, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_241, v_args_242}), v_arms_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_z_245});
  }
  case TAG_Just: {
    V v_lay_247 = heff_field(v_x4_244, 0);
    if (!(heff_dup(heff_rfield(v_lay_247, 3)) == NTAG(TAG_True))) {
      V v_t_2413 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2_lam0, 1, 1, (V[]){heff_dup(v_arms_243)}), heff_rfield(v_lay_247, 5)));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_t_2413);
        V v_t_2417 = (g_heff_2ecompile_2ecpr_2ecalledApart(heff_dup(v_lay_247), v_g_241, v_args_242, heff_clo_n(g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2_lam1, 1, 2, (V[]){v_arms_243, heff_dup(v_lay_247)})));
        return heff_tail(v_t_2417, 1, (V[]){v_z_245});
      } else {
        heff_drop(v_t_2413);
        V v_t_2418 = heff_tag_at_n(v_tok_240, TAG_EMatch, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_241, v_args_242}), v_arms_243});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_z_245});
      }
    } else {
      V v_t_2419 = heff_tag_at_n(v_tok_240, TAG_EMatch, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_241, v_args_242}), v_arms_243});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, v_z_245});
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_arms_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_c_248, 0, 4); V a_1 = v_arms_243; HeffT2 r_ = (g_heff_2ecompile_2ecpr_2earmOf_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) && ({ V v_x11_2412 = heff_dup(v_field_2411); int c_ = 1; heff_drop(v_x11_2412); c_; })));
    heff_drop(v_field_2411);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2_lam2(V self, V *args) {
  V v_c_2415 = args[0];
  V v_arms_243 = heff_env(self)[0];
  V v_lay_247 = heff_env(self)[1];
  V v_vs_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = (g_heff_2ecompile_2ecpr_2earmOf(heff_rfield(v_c_2415, 0), v_arms_243));
  return ({ V a_0 = v_lay_247; V a_1 = v_vs_2414; V a_2 = v_c_2415; V a_3 = v_t_2416; V r_ = (g_heff_2ecompile_2ecpr_2earmBodyAs(a_0, a_1, a_2, a_3)); heff_drop(v_vs_2414); r_; });
}
V g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2_lam1(V self, V *args) {
  V v_vs_2414 = args[0];
  V v_arms_243 = heff_env(self)[0];
  V v_lay_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_vs_2414; V a_1 = heff_clo_n(g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2_lam2, 1, 3, (V[]){v_arms_243, heff_dup(v_lay_247), heff_dup(v_vs_2414)}); V a_2 = heff_get_n(v_lay_247, 5, 7); V r_ = (g_heff_2ecompile_2ecpr_2echosen(a_0, a_1, a_2)); heff_drop(v_vs_2414); r_; });
}
Clo g_heff_2ecompile_2ecpr_2ematchRw_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ematchRw_24tok2_entry, 5, 0};

V g_heff_2ecompile_2ecpr_2ematchRw_24tok2(V v_tok_240, V v_k_241, V v_s_242, V v_arms_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_s_242)) {
  case TAG_EVar: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EGlobal: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_ELam: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EApp: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_ELet: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_ERecord: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EProj: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_ETag: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EMatch: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EPrim: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EPrimCall: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_ECall: {
    V v_g_2428 = heff_field(v_s_242, 0);
    V v_args_2429 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24ECall = heff_take_reuse_n(v_s_242, 3ULL, 2);
    heff_drop_cell(v_tok_240, 2);
    V v_t_2430 = (g_std_2emap_2elookup_24s1930949324x2078207031(v_k_241, v_g_2428));
    return ({ V a_0 = v_ru_24s_242_24ECall; V a_1 = v_g_2428; V a_2 = v_args_2429; V a_3 = v_arms_243; V a_4 = v_t_2430; V a_5 = v_z_244; V r_ = (g_heff_2ecompile_2ecpr_2ematchCallIn_24tok2(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2430); r_; });
  }
  case TAG_EInt: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EFloat: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EStr: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EBytes: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EFixed: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EFloat32: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EAbandon: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EBool: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_ESet: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EValues: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  case TAG_EFix: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_arms_243}), v_z_244});
  }
  default: return heff_nomatch(v_s_242);
  }
}
V g_heff_2ecompile_2ecpr_2ematchRw_24tok2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2ematchRw_24tok2(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecpr_2esiteLetIn_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esiteLetIn_24tok2_entry, 5, 0};

V g_heff_2ecompile_2ecpr_2esiteLetIn_24tok2(V v_tok_240, V v_acc_241, V v_x_242, V v_b_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nothing: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_b_243);
    return v_acc_241;
  }
  case TAG_Just: {
    V v_lay_245 = heff_field(v_x4_244, 0);
    V v_t_246 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
    V v_x_247 = (g_heff_2ecompile_2ecpr_2eapartW(heff_dup(v_lay_245), v_x_242, MK_INT(0LL), v_t_246));
    V v_t_248 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_247, 1));
    heff_drop(v_x_247);
    if (((heff_dup(v_t_248) == NTAG(TAG_True)) && ({ V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2411 = (g_heff_2ecompile_2ecpr_2eapartW(heff_dup(v_lay_245), v_x_242, MK_INT(0LL), heff_dup(v_t_249))); int c_ = ({ V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2412 = (g_heff_2ecompile_2eir_2ecountW(v_x_242, MK_INT(0LL), heff_dup(v_t_2410))); int c_ = heff_intEq_c_lent(v_t_2411, v_t_2412, 0); heff_drop(v_t_2412); c_; }); heff_drop(v_t_2410); c_; }); heff_drop(v_t_2411); c_; }); heff_drop(v_t_249); c_; }))) {
      heff_drop(v_b_243);
      heff_drop(v_t_248);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_lay_245, 6)), v_acc_241});
    } else {
      heff_drop(v_b_243);
      heff_drop(v_t_248);
      return v_acc_241;
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_heff_2ecompile_2ecpr_2esiteLetIn_24tok2_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ecompile_2ecpr_2esiteLetIn_24tok2(a[0], a[1], a2, a[3], a4); heff_drop(a2); heff_drop(a4); return r;
}
V g_heff_2ecompile_2ecpr_2esiteMatchIn_24tok2_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2esiteMatchIn_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esiteMatchIn_24tok2_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2esiteMatchIn_24tok2(V v_tok_240, V v_acc_241, V v_arms_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_arms_242);
    return v_acc_241;
  }
  case TAG_Just: {
    V v_lay_244 = heff_field(v_x3_243, 0);
    V v_record_245 = heff_dup(heff_rfield(v_lay_244, 3));
    V v_cons_246 = heff_dup(heff_rfield(v_lay_244, 5));
    V v_group_247 = heff_dup(heff_rfield(v_lay_244, 6));
    if (!(heff_dup(v_record_245) == NTAG(TAG_True))) {
      heff_drop(v_record_245);
      V v_t_2413 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2esiteMatchIn_24tok2_lam0, 1, 1, (V[]){v_arms_242}); V a_1 = v_cons_246; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_cons_246); r_; });
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_group_247, v_acc_241});
      } else {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_group_247);
        heff_drop(v_t_2413);
        return v_acc_241;
      }
    } else {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_arms_242);
      heff_drop(v_record_245);
      heff_drop(v_cons_246);
      heff_drop(v_group_247);
      return v_acc_241;
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2ecpr_2esiteMatchIn_24tok2_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2ecpr_2esiteMatchIn_24tok2(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2ecpr_2esiteMatchIn_24tok2_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_arms_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_c_248, 0, 4); V a_1 = v_arms_242; HeffT2 r_ = (g_heff_2ecompile_2ecpr_2earmOf_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) && ({ V v_x11_2412 = heff_dup(v_field_2411); int c_ = 1; heff_drop(v_x11_2412); c_; })));
    heff_drop(v_field_2411);
    return v_ret_24bool;
  }
}