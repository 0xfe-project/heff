// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_NoShape 40346
#define TAG_RepFix 59335
#define TAG_Tip 31527
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_body 9524841
#define LBL_cons 9554936
#define LBL_defs 9574869
#define LBL_group 299987609
#define LBL_index 301704428
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_labels 836724522
#define LBL_lets 9813631
#define LBL_name 9869138
#define LBL_numbered 1006183371
#define LBL_places 961367927
#define LBL_record 1012233084
#define LBL_supply 1056026650
#define LBL_tag 324116
#define LBL_tuple 312083426
#define LBL_tuples 1084651734
#define LBL_tys 324872
#define LBL_vals 10107449
static uint32_t shape_defs__supply__tuples[] = {LBL_defs, LBL_supply, LBL_tuples};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_kinds__cons[] = {LBL_kinds, LBL_cons};
static uint32_t shape_kinds__places[] = {LBL_kinds, LBL_places};
static uint32_t shape_lets__vals[] = {LBL_lets, LBL_vals};
static uint32_t shape_tag__index__tys__places[] = {LBL_tag, LBL_index, LBL_tys, LBL_places};
static uint32_t shape_tuple__numbered__kinds__record__labels__cons__group[] = {LBL_tuple, LBL_numbered, LBL_kinds, LBL_record, LBL_labels, LBL_cons, LBL_group};
V g_heff_2ecompile_2ecpr_2eapartW(V, V, V, V);
V g_heff_2ecompile_2ecpr_2eapartW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eapartW_clo;
V g_heff_2ecompile_2ecpr_2earmBodyAs(V, V, V, V);
V g_heff_2ecompile_2ecpr_2earmBodyAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2earmBodyAs_clo;
V g_heff_2ecompile_2ecpr_2earmOf(V, V);
V g_heff_2ecompile_2ecpr_2earmOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2earmOf_clo;
HeffT2 g_heff_2ecompile_2ecpr_2earmOf_24cpr(V, V);
V g_heff_2ecompile_2ecpr_2eboundOne(V, V);
V g_heff_2ecompile_2ecpr_2eboundOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eboundOne_clo;
V g_heff_2ecompile_2ecpr_2ebuiltOut(V, V, V);
V g_heff_2ecompile_2ecpr_2ebuiltOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ebuiltOut_clo;
V g_heff_2ecompile_2ecpr_2ecandOne(V, V);
V g_heff_2ecompile_2ecpr_2ecandOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ecandOne_clo;
V g_heff_2ecompile_2ecpr_2echosen(V, V, V);
V g_heff_2ecompile_2ecpr_2echosen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2echosen_clo;
V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(V, V, V, V);
V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_clo;
V g_heff_2ecompile_2ecpr_2ecprWith(V, V, V);
V g_heff_2ecompile_2ecpr_2ecprWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ecprWith_clo;
V g_heff_2ecompile_2ecpr_2edefWith(V, V, V);
V g_heff_2ecompile_2ecpr_2edefWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2edefWith_clo;
V g_heff_2ecompile_2ecpr_2edropCalling(V);
V g_heff_2ecompile_2ecpr_2edropCalling_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2edropCalling_clo;
HeffT2 g_heff_2ecompile_2ecpr_2efieldAt_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2ecpr_2efitting_24cpr(V);
V g_heff_2ecompile_2ecpr_2ekeptGo(V, V);
V g_heff_2ecompile_2ecpr_2ekeptGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ekeptGo_clo;
V g_heff_2ecompile_2ecpr_2elayTag(V, V);
V g_heff_2ecompile_2ecpr_2elayTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2elayTag_clo;
V g_heff_2ecompile_2ecpr_2elayoutsAt(V, V, V);
V g_heff_2ecompile_2ecpr_2elayoutsAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2elayoutsAt_clo;
V g_heff_2ecompile_2ecpr_2ematchCallIn(V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2ematchCallIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ematchCallIn_clo;
V g_heff_2ecompile_2ecpr_2emergeTy(V, V);
V g_heff_2ecompile_2ecpr_2emergeTy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2emergeTy_clo;
V g_heff_2ecompile_2ecpr_2eoutRw(V, V);
V g_heff_2ecompile_2ecpr_2eoutRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eoutRw_clo;
V g_heff_2ecompile_2ecpr_2eoutsW(V, V);
V g_heff_2ecompile_2ecpr_2eoutsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eoutsW_clo;
V g_heff_2ecompile_2ecpr_2eplacedAt(V, V, V);
V g_heff_2ecompile_2ecpr_2eplacedAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eplacedAt_clo;
V g_heff_2ecompile_2ecpr_2erw(V, V);
V g_heff_2ecompile_2ecpr_2erw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2erw_clo;
V g_heff_2ecompile_2ecpr_2esameLabels(V, V);
V g_heff_2ecompile_2ecpr_2esameLabels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esameLabels_clo;
V g_heff_2ecompile_2ecpr_2eshapesOf(V, V);
V g_heff_2ecompile_2ecpr_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eshapesOf_clo;
V g_heff_2ecompile_2ecpr_2esiteLet(V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2esiteLet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esiteLet_clo;
V g_heff_2ecompile_2ecpr_2esiteMatchIn(V, V, V);
V g_heff_2ecompile_2ecpr_2esiteMatchIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esiteMatchIn_clo;
V g_heff_2ecompile_2ecpr_2esited(V, V);
V g_heff_2ecompile_2ecpr_2esited_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esited_clo;
V g_heff_2ecompile_2ecpr_2esitesW(V, V, V);
V g_heff_2ecompile_2ecpr_2esitesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esitesW_clo;
HeffT2 g_heff_2ecompile_2ecpr_2etagLayout_24cpr(V, V, V);
V g_heff_2ecompile_2ecpr_2etakenApart(V, V, V);
V g_heff_2ecompile_2ecpr_2etakenApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2etakenApart_clo;
V g_heff_2ecompile_2ecpr_2etupleVars(V);
V g_heff_2ecompile_2ecpr_2etupleVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2etupleVars_clo;
V g_heff_2ecompile_2ecpr_2ewrapperOf(V, V, V);
V g_heff_2ecompile_2ecpr_2ewrapperOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ewrapperOf_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2erepr_2erootFrom(V, V, V);
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2erootFrom_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1630057461x1822494873(V);
V g_list_2eany_24s1630057461x1822494873_entry(V self, V *a);
extern Clo g_list_2eany_24s1630057461x1822494873_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
HeffT2 g_list_2efind_24s1220402251x718717745_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f155552269x628597815(V, V, V);
V g_list_2efoldl_24f155552269x628597815_entry(V self, V *a);
extern Clo g_list_2efoldl_24f155552269x628597815_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1766906699x9526323(V, V);
V g_list_2efoldl_24s1766906699x9526323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1766906699x9526323_clo;
V g_list_2efoldl_24s465028312x319285028(V, V);
V g_list_2efoldl_24s465028312x319285028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s465028312x319285028_clo;
V g_list_2efoldl_24s477184376x1963488659(V, V);
V g_list_2efoldl_24s477184376x1963488659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s477184376x1963488659_clo;
V g_list_2efoldl_24s651278233x871164524(V, V);
V g_list_2efoldl_24s651278233x871164524_entry(V self, V *a);
extern Clo g_list_2efoldl_24s651278233x871164524_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s2090270526x1588636862(V);
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_clo;
V g_list_2emap_24s273193875x235978955(V, V, V, V);
V g_list_2emap_24s273193875x235978955_entry(V self, V *a);
extern Clo g_list_2emap_24s273193875x235978955_clo;
V g_list_2emap_24s45270243x110012769(V);
V g_list_2emap_24s45270243x110012769_entry(V self, V *a);
extern Clo g_list_2emap_24s45270243x110012769_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1673840189x4008143(V, V);
V g_prelude_2etraverse_24s1673840189x4008143_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1673840189x4008143_clo;
V g_prelude_2etraverse_24s247294553x1909820037(V, V, V, V);
V g_prelude_2etraverse_24s247294553x1909820037_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s247294553x1909820037_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411(V, V);
V g_std_2emap_2elookup_24s1963842891x1660122411_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1963842891x1660122411_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2ecpr_2esameLabels_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esameLabels_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2esameLabels(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_a_244, v_b_246, 0)) {
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecpr_2esameLabels_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2esameLabels(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecpr_2ecandOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ecandOne_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2ecandOne(V v_m_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_b_246 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24ELam = heff_take_reuse_n(v_t_242, 2ULL, 2);
    V v_t_247 = heff_tag_at_n(v_ru_24t_242_24ELam, TAG_Cons, 2, (V[]){v_b_246, NTAG(TAG_Nil)});
    V v_os_248 = (g_heff_2ecompile_2ecpr_2eoutsW(NTAG(TAG_Nil), v_t_247));
    V v_t_249 = (g_list_2eany_24s1630057461x1822494873(v_os_248));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop_rec(v_d_241, 3);
      heff_drop(v_os_248);
      heff_drop(v_t_249);
      return v_m_240;
    } else {
      heff_drop(v_t_249);
      return (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_240, heff_get_n(v_d_241, 0, 3), v_os_248));
    }
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 4);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2ecpr_2ecandOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ecandOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecpr_2ekeptGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ekeptGo_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2ekeptGo(V v_m_240, V v_m2_241) {
top: ;
  V v_t_242 = (g_std_2emap_2esize(v_m2_241));
  V v_t_243 = (g_std_2emap_2esize(v_m_240));
  if (heff_intEq_c(v_t_242, v_t_243)) {
    heff_drop(v_m2_241);
    return v_m_240;
  } else {
    heff_drop(v_m_240);
    V v_t_245 = (g_heff_2ecompile_2ecpr_2edropCalling(v_m2_241));
    V t_0 = v_m2_241;
    V t_1 = v_t_245;
    v_m_240 = t_0;
    v_m2_241 = t_1;
    goto top;
  }
}
V g_heff_2ecompile_2ecpr_2ekeptGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ekeptGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str11, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str12, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str13, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str14, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str15, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str16, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str17, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str18, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str19, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str20, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str21, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str22, 1, "_");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str23, 1, "\?");
Clo g_heff_2ecompile_2ecpr_2emergeTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2emergeTy_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2emergeTy(V v_a_240, V v_b_241) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_a_240)) {
  case TAG_FtFloat: {
    v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str0);
    break;
  }
  case TAG_FtFixed: {
    V v_w_242 = heff_dup(heff_field(v_a_240, 0));
    switch (heff_tag_of(v_w_242)) {
    case TAG_I8: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str1);
      break;
    }
    case TAG_I16: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str2);
      break;
    }
    case TAG_I32: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str3);
      break;
    }
    case TAG_I64: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str4);
      break;
    }
    case TAG_U8: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str5);
      break;
    }
    case TAG_U16: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str6);
      break;
    }
    case TAG_U32: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str7);
      break;
    }
    case TAG_U64: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str8);
      break;
    }
    case TAG_F32: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str9);
      break;
    }
    default: heff_nomatch(v_w_242);
    }
    break;
  }
  case TAG_FtOther: {
    v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str10);
    break;
  }
  case TAG_FtAny: {
    v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str11);
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  V v_t_245;
  switch (heff_tag_of(v_b_241)) {
  case TAG_FtFloat: {
    v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str12);
    break;
  }
  case TAG_FtFixed: {
    V v_w_244 = heff_field(v_b_241, 0);
    switch (heff_tag_of(v_w_244)) {
    case TAG_I8: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str13);
      break;
    }
    case TAG_I16: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str14);
      break;
    }
    case TAG_I32: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str15);
      break;
    }
    case TAG_I64: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str16);
      break;
    }
    case TAG_U8: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str17);
      break;
    }
    case TAG_U16: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str18);
      break;
    }
    case TAG_U32: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str19);
      break;
    }
    case TAG_U64: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str20);
      break;
    }
    case TAG_F32: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str21);
      break;
    }
    default: heff_nomatch(v_w_244);
    }
    break;
  }
  case TAG_FtOther: {
    v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str22);
    break;
  }
  case TAG_FtAny: {
    v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str23);
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  if (heff_strEq_c(v_t_243, v_t_245)) {
    return v_a_240;
  } else {
    heff_drop(v_a_240);
    return NTAG(TAG_FtOther);
  }
}
V g_heff_2ecompile_2ecpr_2emergeTy_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2emergeTy(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2eshapesOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eshapesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eshapesOf_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eshapesOf(V v_parent_240, V v_m_241) {
top: ;
  V v_t_242 = (g_std_2emap_2etoListOnto(v_m_241, NTAG(TAG_Nil)));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2eshapesOf_lam0, 2, 1, (V[]){heff_dup(v_parent_240)}); V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2ecompile_2ecpr_2eshapesOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2eshapesOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2eshapesOf_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_p_244 = args[1];
  V v_parent_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_247;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_p_244, 0));
    v_x_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_248 = (g_std_2emap_2elookup_24s1963842891x1660122411(v_parent_240, v_x_247));
  V v_root_249 = ({ V a_0 = v_parent_240; V a_1 = v_x_247; V a_2 = v_t_248; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_240); r_; });
  HeffT2 v_t_2410 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_acc_243, v_root_249));
  V v_t_2415;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2412;
      v_t_2415 = v_x_2414;
    } else {
      heff_drop(v_field_2412);
      v_t_2415 = NTAG(TAG_NoShape);
    }
  }
  V v_t_2418;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_p_244, 1);
    heff_take_n(v_p_244, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_2419 = ({ V a_0 = v_t_2415; V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s1766906699x9526323(a_0, a_1)); heff_drop(v_t_2418); r_; });
  return (g_std_2emap_2einsert_24s1305793909x1049798133(v_acc_243, v_root_249, v_t_2419));
}
Clo g_heff_2ecompile_2ecpr_2eplacedAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eplacedAt_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2eplacedAt(V v_p_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_k_241, NTAG(TAG_Nil)});
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_240, 0)), v_t_243));
    V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_p_240, 0)));
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_prelude_2e_2b_2b(heff_get_n(v_p_240, 1, 2), v_t_246));
    return heff_rec_n(2, shape_kinds__places, (V[]){v_t_244, v_t_247});
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_x3_242, 0);
    heff_drop(v_k_241);
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_i_248), NTAG(TAG_Nil)});
    V v_t_2410 = (g_prelude_2e_2b_2b(heff_take_field(v_p_240, 1), v_t_249));
    return ({ V rv_1 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_p_240, 1ULL, 2, shape_kinds__places, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2eplacedAt_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2eplacedAt(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecpr_2elayTag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2elayTag_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2elayTag(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_ts_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_rec_n(2, shape_kinds__places, (V[]){heff_take_field(v_acc_240, 0), NTAG(TAG_Nil)});
    V v_p_245 = (g_list_2efoldl_24s465028312x319285028(v_t_244, v_ts_243));
    V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_acc_240, 1)));
    V v_t_247 = heff_rec_n(4, shape_tag__index__tys__places, (V[]){v_t_242, v_t_246, v_ts_243, heff_take_field(v_p_245, 1)});
    V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_240, 1, 2), v_t_248));
    return heff_rec_n(2, shape_kinds__cons, (V[]){heff_get_n(v_p_245, 0, 2), v_t_249});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecpr_2elayTag_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2elayTag(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str2, 1, "#");

HeffT2 g_heff_2ecompile_2ecpr_2etagLayout_24cpr(V v_root_240, V v_numbered_241, V v_l_242) {
top: ;
  V v_t_244;
  if ((heff_dup(v_numbered_241) == NTAG(TAG_True))) {
    V v_t_243 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
    v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_dup(heff_rfield(v_l_242, 0))});
  } else {
    v_t_244 = heff_dup(heff_rfield(v_l_242, 0));
  }
  V v_x2_245 = (g_list_2emap_24s2090270526x1588636862(v_t_244));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str1); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_249 = heff_rec_n(7, shape_tuple__numbered__kinds__record__labels__cons__group, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str2), v_t_248), v_numbered_241, heff_take_field(v_l_242, 0), NTAG(TAG_False), NTAG(TAG_Nil), heff_get_n(v_l_242, 1, 2), v_root_240});
  return (g_heff_2ecompile_2ecpr_2efitting_24cpr(v_t_249));
}
V g_heff_2ecompile_2ecpr_2elayoutsAt_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2elayoutsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2elayoutsAt_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2elayoutsAt(V v_parent_240, V v_ls_241, V v_m_242) {
top: ;
  V v_t_243 = (g_std_2emap_2etoListOnto(v_m_242, NTAG(TAG_Nil)));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2elayoutsAt_lam0, 2, 2, (V[]){heff_dup(v_parent_240), heff_dup(v_ls_241)}); V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_t_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
}
V g_heff_2ecompile_2ecpr_2elayoutsAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2elayoutsAt(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecpr_2elayoutsAt_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_p_245 = args[1];
  V v_parent_240 = heff_env(self)[0];
  V v_ls_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_dup(heff_field(v_p_245, 0));
    v_x_248 = v_x_246;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_249 = (g_std_2emap_2elookup_24s1963842891x1660122411(v_parent_240, v_x_248));
  V v_t_2410 = ({ V a_0 = v_parent_240; V a_1 = v_x_248; V a_2 = v_t_249; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_240); r_; });
  HeffT2 v_t_2411 = ({ V a_0 = v_ls_241; V a_1 = v_t_2410; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_ls_241); heff_drop(v_t_2410); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_lay_2415 = v_field_2413;
      V v_t_2418;
      switch (heff_tag_of(v_p_245)) {
      case TAG_MkPair: {
        V v_x_2416 = heff_field(v_p_245, 0);
        heff_take_n(v_p_245, 1ULL, 2);
        v_t_2418 = v_x_2416;
        break;
      }
      default: heff_nomatch(v_p_245);
      }
      return (g_std_2emap_2einsert_24s1305793909x1049798133(v_acc_244, v_t_2418, v_lay_2415));
    } else {
      heff_drop(v_p_245);
      heff_drop(v_field_2413);
      return v_acc_244;
    }
  }
}
Clo g_heff_2ecompile_2ecpr_2earmOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2earmOf_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2earmOf(V v_t_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2ecpr_2earmOf_24cpr(v_t_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2ecpr_2earmOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2earmOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2ecpr_2etakenApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2etakenApart_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2etakenApart(V v_lay_240, V v_x_241, V v_b_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
  V v_x_244 = (g_heff_2ecompile_2ecpr_2eapartW(heff_dup(v_lay_240), v_x_241, MK_INT(0LL), v_t_243));
  V v_ret_24bool = heff_bool((heff_intLt_c_lent(MK_INT(0LL), v_x_244, 1) && ({ V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_247 = (g_heff_2ecompile_2ecpr_2eapartW(heff_dup(v_lay_240), v_x_241, MK_INT(0LL), heff_dup(v_t_246))); int c_ = ({ V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)}); int c_ = ({ V v_t_249 = (g_heff_2ecompile_2eir_2ecountW(v_x_241, MK_INT(0LL), heff_dup(v_t_248))); int c_ = heff_intEq_c_lent(v_t_247, v_t_249, 0); heff_drop(v_t_249); c_; }); heff_drop(v_t_248); c_; }); heff_drop(v_t_247); c_; }); heff_drop(v_t_246); c_; })));
  heff_drop(v_lay_240);
  heff_drop(v_b_242);
  heff_drop(v_x_244);
  return v_ret_24bool;
}
V g_heff_2ecompile_2ecpr_2etakenApart_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2etakenApart(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2esiteMatchIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2esiteMatchIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esiteMatchIn_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2esiteMatchIn(V v_acc_240, V v_arms_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_arms_241);
    return v_acc_240;
  }
  case TAG_Just: {
    V v_lay_243 = heff_field(v_x3_242, 0);
    V v_t_244 = heff_dup(heff_rfield(v_lay_243, 3));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_arms_241);
      heff_drop(v_t_244);
      return v_acc_240;
    } else {
      heff_drop(v_t_244);
      V v_t_2411 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2ecpr_2esiteMatchIn_lam0, 1, 1, (V[]){v_arms_241}), heff_rfield(v_lay_243, 5)));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_lay_243, 6)), v_acc_240});
      } else {
        heff_drop(v_t_2411);
        return v_acc_240;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2esiteMatchIn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2esiteMatchIn(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecpr_2esiteMatchIn_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_arms_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_c_245, 0, 4); V a_1 = v_arms_241; HeffT2 r_ = (g_heff_2ecompile_2ecpr_2earmOf_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_247 == ((int64_t)0ULL)) && ({ V v_x11_2410 = heff_dup(v_field_248); int c_ = 1; heff_drop(v_x11_2410); c_; })));
    heff_drop(v_field_248);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2ecpr_2esitesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esitesW_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2esitesW(V v_k_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_249 = heff_field(v_x31_243, 0);
      V v_as_2410 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI(v_as_2410, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_249, v_t_2411});
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_x_2412 = heff_field(v_x31_243, 0);
      V v_a_2413 = heff_field(v_x31_243, 1);
      V v_b_2414 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_t_2415 = ({ V a_0 = v_k_240; V a_1 = v_acc_241; V a_2 = v_x_2412; V a_3 = heff_dup(v_a_2413); V a_4 = heff_dup(v_b_2414); V r_ = (g_heff_2ecompile_2ecpr_2esiteLet(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2412); r_; });
      V v_t_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2414, v_rest_244})});
      V t_0 = v_k_240;
      V t_1 = v_t_2415;
      V t_2 = v_t_2416;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2417 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2419 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2417, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2419;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2420 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2420, v_rest_244});
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2425 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2427 = (g_heff_2ecompile_2eir_2eappendI(v_as_2425, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2427;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2428 = heff_field(v_x31_243, 0);
      V v_arms_2429 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2465;
      switch (heff_tag_of(v_s_2428)) {
      case TAG_EVar: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_EGlobal: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_ELam: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_EApp: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_ELet: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_ERecord: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_EProj: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_ETag: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_EMatch: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_EPrim: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_ECall: {
        V v_g_2453 = heff_dup(heff_field(v_s_2428, 0));
        V v_t_2455 = ({ V a_0 = v_k_240; V a_1 = v_g_2453; V r_ = (g_std_2emap_2elookup_24s1963842891x1660122411(a_0, a_1)); heff_drop(v_g_2453); r_; });
        v_t_2465 = ({ V a_0 = v_acc_241; V a_1 = heff_dup(v_arms_2429); V a_2 = v_t_2455; V r_ = (g_heff_2ecompile_2ecpr_2esiteMatchIn(a_0, a_1, a_2)); heff_drop(v_t_2455); r_; });
        break;
      }
      case TAG_EInt: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_EFloat: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_EStr: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_EBytes: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_EFixed: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_EFloat32: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_EAbandon: {
        v_t_2465 = v_acc_241;
        break;
      }
      case TAG_EFix: {
        v_t_2465 = v_acc_241;
        break;
      }
      default: heff_nomatch(v_s_2428);
      }
      V v_t_2466 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2429, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_t_2465;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2428, v_t_2466});
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2469 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2470 = (g_heff_2ecompile_2eir_2eappendI(v_as_2469, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2470;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2472 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2473 = (g_heff_2ecompile_2eir_2eappendI(v_as_2472, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_2473;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_rest_244;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2esitesW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2esitesW(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecpr_2esited_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2esited_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esited_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2esited(V v_defs_240, V v_k_241) {
top: ;
  V v_t_242 = (g_list_2emap_24s45270243x110012769(v_defs_240));
  V v_t_243 = (g_heff_2ecompile_2ecpr_2esitesW(v_k_241, NTAG(TAG_Nil), v_t_242));
  V v_groups_244 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s477184376x1963488659(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_std_2emap_2etoListOnto(v_k_241, NTAG(TAG_Nil)));
  V v_ps_2415 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2ecpr_2esited_lam0, 1, 1, (V[]){v_groups_244}), v_t_245));
  return ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2415; V r_ = (g_list_2efoldl_24s651278233x871164524(a_0, a_1)); heff_drop(v_ps_2415); r_; });
}
V g_heff_2ecompile_2ecpr_2esited_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2esited(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2esited_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_groups_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249;
  switch (heff_tag_of(v_p_246)) {
  case TAG_MkPair: {
    V v_y_248 = heff_field(v_p_246, 1);
    heff_take_n(v_p_246, 2ULL, 2);
    v_t_249 = v_y_248;
    break;
  }
  default: heff_nomatch(v_p_246);
  }
  HeffT2 v_t_2410 = ({ V a_0 = v_groups_244; V b_1 = heff_get_n(v_t_249, 6, 7); HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, b_1)); heff_drop(v_groups_244); heff_drop(b_1); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2411 == ((int64_t)0ULL)) && ({ V v_x_2414 = heff_dup(v_field_2412); int c_ = 1; heff_drop(v_x_2414); c_; })));
    heff_drop(v_field_2412);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2earmBodyAs_str0, 0, "");
V g_heff_2ecompile_2ecpr_2earmBodyAs_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2earmBodyAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2earmBodyAs_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2earmBodyAs(V v_lay_240, V v_vs_241, V v_c_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop_rec(v_c_242, 4);
    return NTAG(TAG_EAbandon);
  }
  case TAG_Just: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkArm: {
      V v_ws_246 = heff_field(v_x41_244, 1);
      V v_b_247 = heff_field(v_x41_244, 2);
      heff_take_n(v_x41_244, 6ULL, 3);
      V v_t_248 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_ws_246, heff_get_n(v_c_242, 3, 4)));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2earmBodyAs_lam0, 2, 2, (V[]){v_lay_240, heff_dup(v_vs_241)}); V a_1 = v_b_247; V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecpr_2earmBodyAs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2earmBodyAs(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2earmBodyAs_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_lay_240 = heff_env(self)[0];
  V v_vs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_dup(heff_field(v_x_2410, 0));
    v_t_2413 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_i_2416;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_y_2415 = heff_field(v_x_2410, 1);
    heff_take_n(v_x_2410, 2ULL, 2);
    v_i_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2417 = heff_get_n(v_lay_240, 1, 7);
  V v_t_2418;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_t_2417);
    v_t_2418 = heff_intAdd(v_i_2416, MK_INT(1LL));
  } else {
    heff_drop(v_t_2417);
    v_t_2418 = v_i_2416;
  }
  HeffT3 v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = v_vs_241; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_241); r_; });
  V v_t_2426;
  {
    V v_field_2421 = v_t_2419.f[1];
    V v_field_2422 = v_t_2419.f[2];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_x_2424 = v_field_2421;
      V v_x12_2425 = v_field_2422;
      heff_drop(v_x12_2425);
      v_t_2426 = v_x_2424;
    } else {
      heff_drop(v_field_2421);
      heff_drop(v_field_2422);
      v_t_2426 = ((V)&g_heff_2ecompile_2ecpr_2earmBodyAs_str0);
    }
  }
  return heff_tag_n(TAG_ELet, 3, (V[]){v_t_2413, heff_tag_n(TAG_EVar, 1, (V[]){v_t_2426}), v_acc_249});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_str1, 4, "True");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_str2, 5, "False");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_str3, 7, "int64Eq");
Clo g_heff_2ecompile_2ecpr_2echosen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2echosen_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2echosen(V v_vs_240, V v_way_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_way_241);
    return NTAG(TAG_EAbandon);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_x32_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x32_244)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_tail(v_way_241, 1, (V[]){v_c_243});
    }
    case TAG_Cons: {
      V v_yes_247 = heff_tr(heff_call(heff_dup(v_way_241), 1, (V[]){heff_dup(v_c_243)}));
      V v_no_248 = heff_tr(g_heff_2ecompile_2ecpr_2echosen(v_vs_240, v_way_241, v_x32_244));
      V v_t_2411;
      switch (heff_tag_of(v_vs_240)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2ecompile_2ecpr_2echosen_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_vs_240, 0);
        v_t_2411 = heff_dup(v_x_249);
        break;
      }
      default: heff_nomatch(v_vs_240);
      }
      V v_t_2412 = heff_tag_n(TAG_EFixed, 2, (V[]){NTAG(TAG_I64), heff_get_n(v_c_243, 1, 4)});
      V v_t_2413 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2411}), v_t_2413});
      V v_t_2415 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_str1), NTAG(TAG_Nil), v_yes_247});
      V v_t_2416 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_str2), NTAG(TAG_Nil), v_no_248});
      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_str3), v_t_2414}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2417})});
    }
    default: return heff_nomatch(v_x32_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2echosen_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2echosen(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ematchCallIn_str0, 4, "$cpr");
V g_heff_2ecompile_2ecpr_2ematchCallIn_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2ematchCallIn_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ematchCallIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ematchCallIn_entry, 5, 0};

V g_heff_2ecompile_2ecpr_2ematchCallIn(V v_g_240, V v_as_241, V v_arms_242, V v_x4_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_245 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_240, v_as_241}), v_arms_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_z_244});
  }
  case TAG_Just: {
    V v_lay_246 = heff_field(v_x4_243, 0);
    V v_t_247 = heff_dup(heff_rfield(v_lay_246, 3));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_t_248 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_240, v_as_241}), v_arms_242});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_z_244});
    } else {
      heff_drop(v_t_247);
      V v_t_2415 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2ecpr_2ematchCallIn_lam0, 1, 1, (V[]){heff_dup(v_arms_242)}), heff_rfield(v_lay_246, 5)));
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        V v_m_2416 = heff_tr(g_heff_2ecompile_2ecpr_2etupleVars(heff_dup(v_lay_246)));
        V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_z_244}));
        switch (heff_tag_of(v_x2_2417)) {
        case TAG_MkPair: {
          V v_x_2418 = heff_field(v_x2_2417, 0);
          V v_n_2419 = heff_field(v_x2_2417, 1);
          V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
          V v_t_2420 = heff_tag_n(TAG_ECall, 2, (V[]){heff_strAppend(v_g_240, ((V)&g_heff_2ecompile_2ecpr_2ematchCallIn_str0)), v_as_241});
          V v_t_2423 = heff_tr(g_heff_2ecompile_2ecpr_2echosen(v_x_2418, heff_clo_n(g_heff_2ecompile_2ecpr_2ematchCallIn_lam1, 1, 3, (V[]){v_arms_242, heff_dup(v_lay_246), heff_dup(v_x_2418)}), heff_dup(heff_rfield(v_lay_246, 5))));
          V v_t_2424 = heff_tag_n(TAG_MkArm, 3, (V[]){heff_dup(heff_rfield(v_lay_246, 0)), v_x_2418, v_t_2423});
          V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
          V v_x_2426 = heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2420, v_t_2425});
          return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_x_2426, v_n_2419});
        }
        default: return heff_nomatch(v_x2_2417);
        }
      } else {
        heff_drop(v_t_2415);
        V v_t_2427 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_240, v_as_241}), v_arms_242});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2427, v_z_244});
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecpr_2ematchCallIn_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2ecpr_2ematchCallIn(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2ecpr_2ematchCallIn_lam0(V self, V *args) {
  V v_c_249 = args[0];
  V v_arms_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2410 = ({ V b_0 = heff_get_n(v_c_249, 0, 4); V a_1 = v_arms_242; HeffT2 r_ = (g_heff_2ecompile_2ecpr_2earmOf_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2411 == ((int64_t)0ULL)) && ({ V v_x11_2414 = heff_dup(v_field_2412); int c_ = 1; heff_drop(v_x11_2414); c_; })));
    heff_drop(v_field_2412);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2ematchCallIn_lam1(V self, V *args) {
  V v_c_2421 = args[0];
  V v_arms_242 = heff_env(self)[0];
  V v_lay_246 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2422 = (g_heff_2ecompile_2ecpr_2earmOf(heff_rfield(v_c_2421, 0), v_arms_242));
  return ({ V a_0 = v_lay_246; V a_1 = v_x_2418; V a_2 = v_c_2421; V a_3 = v_t_2422; V r_ = (g_heff_2ecompile_2ecpr_2earmBodyAs(a_0, a_1, a_2, a_3)); heff_drop(v_x_2418); r_; });
}

HeffT2 g_heff_2ecompile_2ecpr_2efieldAt_24cpr(V v_i_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x2_241, 0);
    V v_ps_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_i_240);
      heff_drop(v_p_243);
      heff_drop(v_ps_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_e_245 = heff_field(v_x3_242, 0);
      V v_es_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      if (heff_intEq_c_lent(v_p_243, v_i_240, 1)) {
        heff_drop(v_i_240);
        heff_drop(v_ps_244);
        heff_drop(v_es_246);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_245}});
      } else {
        heff_drop(v_e_245);
        V t_0 = v_i_240;
        V t_1 = v_ps_244;
        V t_2 = v_es_246;
        v_i_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2eboundOne_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecpr_2eboundOne_str1, 1, "f");
V g_heff_2ecompile_2ecpr_2eboundOne_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eboundOne_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eboundOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eboundOne_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eboundOne(V v_b_240, V v_e_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2eir_2eisValue(v_e_241));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    V v_t_244 = (g_prelude_2e_2b_2b(heff_take_field(v_b_240, 1), v_t_243));
    V v_x_245 = ({ V rv_1 = v_t_244; V rr_ = heff_rec_reuse_nf(v_b_240, 1ULL, 2, shape_lets__vals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eboundOne_lam0, 1, 1, (V[]){v_x_245});
  } else {
    heff_drop(v_t_242);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eboundOne_lam1, 1, 2, (V[]){v_e_241, v_b_240});
  }
}
V g_heff_2ecompile_2ecpr_2eboundOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eboundOne(a[0], a[1]);
}
V g_heff_2ecompile_2ecpr_2eboundOne_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_245, v_n_246});
}
V g_heff_2ecompile_2ecpr_2eboundOne_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_b_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2ecpr_2eboundOne_str0), heff_intShow(heff_dup(v_n_247)));
  V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2ecpr_2eboundOne_str1), v_t_248);
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_t_249), v_e_241}), NTAG(TAG_Nil)});
  V v_t_2411 = (g_prelude_2e_2b_2b(heff_take_field(v_b_240, 0), v_t_2410));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_249}), NTAG(TAG_Nil)});
  V v_t_2413 = (g_prelude_2e_2b_2b(heff_get_n(v_b_240, 1, 2), v_t_2412));
  V v_x_2414 = heff_rec_n(2, shape_lets__vals, (V[]){v_t_2411, v_t_2413});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2414, heff_intAdd(v_n_247, MK_INT(1LL))});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2eoutRw_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2eoutRw_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2eoutRw_str2, 4, "$cpr");
V g_heff_2ecompile_2ecpr_2eoutRw_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam3(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam4(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam5(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam7(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam6(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam8(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam9(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam10(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam11(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam12(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam13(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam14(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam15(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam16(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam17(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam18(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam19(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eoutRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eoutRw_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eoutRw(V v_lay_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam0, 1, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam1, 1, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam2, 1, 1, (V[]){v_e_241});
  }
  case TAG_EApp: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam3, 1, 1, (V[]){v_e_241});
  }
  case TAG_ELet: {
    V v_x_2412 = heff_field(v_e_241, 0);
    V v_a_2413 = heff_field(v_e_241, 1);
    V v_b_2414 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2415 = (g_heff_2ecompile_2ecpr_2eoutRw(v_lay_240, v_b_2414));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam4, 1, 3, (V[]){v_m_2415, v_x_2412, v_a_2413});
  }
  case TAG_ERecord: {
    V v_fs_2420 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 2);
    HeffT2 v_t_2422 = ({ V b_0 = ((V)&g_heff_2ecompile_2ecpr_2eoutRw_str0); V a_1 = heff_dup(heff_rfield(v_lay_240, 5)); HeffT2 r_ = (g_list_2efind_24s1220402251x718717745_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2427;
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        V v_x_2426 = v_field_2424;
        v_t_2427 = v_x_2426;
      } else {
        heff_drop(v_field_2424);
        v_t_2427 = heff_rec_n(4, shape_tag__index__tys__places, (V[]){((V)&g_heff_2ecompile_2ecpr_2eoutRw_str1), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
    }
    V v_t_2428 = (g_list_2emap_24s1173914895x100384474(v_fs_2420));
    return ({ V a_0 = v_lay_240; V a_1 = v_t_2427; V a_2 = v_t_2428; V r_ = (g_heff_2ecompile_2ecpr_2ebuiltOut(a_0, a_1, a_2)); heff_drop(v_t_2428); r_; });
  }
  case TAG_EProj: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam5, 1, 1, (V[]){v_e_241});
  }
  case TAG_ETag: {
    V v_t_2434 = heff_field(v_e_241, 0);
    V v_as_2435 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 3);
    HeffT2 v_t_2437 = (g_list_2efind_24s1220402251x718717745_24cpr(v_t_2434, heff_dup(heff_rfield(v_lay_240, 5))));
    V v_t_2442;
    {
      V v_field_2439 = v_t_2437.f[1];
      int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
      if ((v_tag_2438 == ((int64_t)0ULL))) {
        heff_drop(v_t_2434);
        V v_x_2441 = v_field_2439;
        v_t_2442 = v_x_2441;
      } else {
        heff_drop(v_field_2439);
        v_t_2442 = heff_rec_n(4, shape_tag__index__tys__places, (V[]){v_t_2434, MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
    }
    return ({ V a_0 = v_lay_240; V a_1 = v_t_2442; V a_2 = v_as_2435; V r_ = (g_heff_2ecompile_2ecpr_2ebuiltOut(a_0, a_1, a_2)); heff_drop(v_as_2435); r_; });
  }
  case TAG_EMatch: {
    V v_s_2443 = heff_field(v_e_241, 0);
    V v_arms_2444 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_go_2445 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eoutRw_clo), 1, (V[]){v_lay_240}));
    V v_m_2455 = (g_prelude_2etraverse_24s1673840189x4008143(heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam6, 1, 1, (V[]){v_go_2445}), v_arms_2444));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam8, 1, 2, (V[]){v_m_2455, v_s_2443});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam9, 1, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam10, 1, 1, (V[]){v_e_241});
  }
  case TAG_ECall: {
    V v_g_2465 = heff_field(v_e_241, 0);
    V v_as_2466 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam11, 1, 2, (V[]){v_g_2465, v_as_2466});
  }
  case TAG_EInt: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam12, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam13, 1, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam14, 1, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam15, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam16, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam17, 1, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam18, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam19, 1, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2ecpr_2eoutRw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eoutRw(a[0], a[1]);
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_243});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_245});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_248});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam3(V self, V *args) {
  V v_n_2411 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2411});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam4(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_a_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2412, v_a_2413, v_x_2418}), v_n_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam5(V self, V *args) {
  V v_n_2433 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2433});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam7(V self, V *args) {
  V v_n_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  V v_t_2447 = heff_env(self)[1];
  V v_ws_2448 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_n_2451}));
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_n_2454 = heff_field(v_x2_2452, 1);
    V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2447, v_ws_2448, v_x_2453}), v_n_2454});
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam6(V self, V *args) {
  V v_x2_2446 = args[0];
  V v_go_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2446)) {
  case TAG_MkArm: {
    V v_t_2447 = heff_field(v_x2_2446, 0);
    V v_ws_2448 = heff_field(v_x2_2446, 1);
    V v_b_2449 = heff_field(v_x2_2446, 2);
    heff_take_n(v_x2_2446, 7ULL, 3);
    V v_m_2450 = heff_tr(heff_call(v_go_2445, 1, (V[]){v_b_2449}));
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam7, 1, 3, (V[]){v_m_2450, v_t_2447, v_ws_2448});
  }
  default: return heff_nomatch(v_x2_2446);
  }
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam8(V self, V *args) {
  V v_n_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_s_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2457 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_n_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_n_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2443, v_x_2458}), v_n_2459});
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam9(V self, V *args) {
  V v_n_2461 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2461});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam10(V self, V *args) {
  V v_n_2464 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2464});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam11(V self, V *args) {
  V v_n_2467 = args[0];
  V v_g_2465 = heff_env(self)[0];
  V v_as_2466 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2468 = heff_tag_n(TAG_ECall, 2, (V[]){heff_strAppend(v_g_2465, ((V)&g_heff_2ecompile_2ecpr_2eoutRw_str2)), v_as_2466});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2468, v_n_2467});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam12(V self, V *args) {
  V v_n_2470 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2470});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam13(V self, V *args) {
  V v_n_2472 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2472});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam14(V self, V *args) {
  V v_n_2474 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2474});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam15(V self, V *args) {
  V v_n_2476 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2476});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam16(V self, V *args) {
  V v_n_2479 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2479});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam17(V self, V *args) {
  V v_n_2481 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2481});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam18(V self, V *args) {
  V v_n_2482 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2482});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam19(V self, V *args) {
  V v_n_2485 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2485});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_str1, 4, "$cpr");
V g_heff_2ecompile_2ecpr_2ewrapperOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ewrapperOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ewrapperOf_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2ewrapperOf(V v_lay_240, V v_d_241, V v_xs_242) {
top: ;
  V v_m_243 = (g_prelude_2etraverse_24s247294553x1909820037(MK_INT(0LL), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_str0), MK_INT(1LL), v_xs_242));
  return heff_clo_n(g_heff_2ecompile_2ecpr_2ewrapperOf_lam0, 1, 3, (V[]){v_m_243, v_lay_240, v_d_241});
}
V g_heff_2ecompile_2ecpr_2ewrapperOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ewrapperOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecpr_2ewrapperOf_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_lay_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_n_244}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_n_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_m_248 = heff_tr(g_heff_2ecompile_2ecpr_2etupleVars(heff_dup(v_lay_240)));
    V v_x2_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_247}));
    switch (heff_tag_of(v_x2_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_n_2411 = heff_field(v_x2_249, 1);
      V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
      V v_t_2412 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_str1));
      V v_t_2413 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_x_246)));
      V v_t_2414 = (g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(heff_dup(v_lay_240), v_x_2410, v_x_2410, heff_dup(heff_rfield(v_lay_240, 5))));
      V v_t_2415 = heff_tag_n(TAG_MkArm, 3, (V[]){heff_get_n(v_lay_240, 0, 7), v_x_2410, v_t_2414});
      V v_t_2416 = heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
      V v_t_2417 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_t_2412, v_t_2413}), v_t_2416});
      V v_body_2418 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_246, v_t_2417});
      V v_t_2419 = ({ V rv_2 = v_body_2418; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_n_2411});
    }
    default: return heff_nomatch(v_x2_249);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2edefWith_str0, 4, "$cpr");
V g_heff_2ecompile_2ecpr_2edefWith_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam3(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam4(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam5(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam6(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam7(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam8(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam9(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam10(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam11(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam12(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam13(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam14(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam15(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam16(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam17(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam18(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam19(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam20(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam21(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam22(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam23(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam24(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam25(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam26(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam27(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam28(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam29(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam30(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam31(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam32(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam33(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam34(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam35(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam36(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam37(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam38(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam39(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam40(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam41(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam42(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam43(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam44(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam45(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam46(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam47(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam48(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam49(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam50(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam51(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam52(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam53(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam54(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam55(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam56(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam57(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam58(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam59(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam60(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2edefWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2edefWith_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2edefWith(V v_k_240, V v_d_241, V v_m_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_EVar: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_245 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_246 = (g_heff_2ecompile_2eir_2enubI(v_t_245));
    V v_t_2413 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam0, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_246; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_246); r_; });
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      V v_m_2414 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam1, 1, 2, (V[]){v_m_2414, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_2413);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam2, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_2424 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_2425 = (g_heff_2ecompile_2eir_2enubI(v_t_2424));
    V v_t_2432 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam3, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_2425; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2425); r_; });
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop(v_t_2432);
      V v_m_2433 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam4, 1, 2, (V[]){v_m_2433, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_2432);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam5, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_ELam: {
    V v_xs_2442 = heff_field(v_t_243, 0);
    V v_b_2443 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_m_242)) {
    case TAG_Nothing: {
      heff_drop(v_xs_2442);
      heff_drop(v_b_2443);
      V v_t_2444 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
      V v_t_2445 = (g_heff_2ecompile_2eir_2enubI(v_t_2444));
      V v_t_2452 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam6, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_2445; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2445); r_; });
      if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
        heff_drop(v_t_2452);
        V v_m_2453 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
        return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam7, 1, 2, (V[]){v_m_2453, v_d_241});
      } else {
        heff_drop(v_k_240);
        heff_drop(v_t_2452);
        return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam8, 1, 1, (V[]){v_d_241});
      }
    }
    case TAG_Just: {
      V v_lay_2462 = heff_field(v_m_242, 0);
      V v_m_2463 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, v_b_2443));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam9, 1, 4, (V[]){v_m_2463, heff_dup(v_lay_2462), v_d_241, v_xs_2442});
    }
    default: return heff_nomatch(v_m_242);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_2481 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_2482 = (g_heff_2ecompile_2eir_2enubI(v_t_2481));
    V v_t_2489 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam10, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_2482; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2482); r_; });
    if ((heff_dup(v_t_2489) == NTAG(TAG_True))) {
      heff_drop(v_t_2489);
      V v_m_2490 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam11, 1, 2, (V[]){v_m_2490, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_2489);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam12, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_ELet: {
    heff_take_n(v_t_243, 0ULL, 3);
    V v_t_24102 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24103 = (g_heff_2ecompile_2eir_2enubI(v_t_24102));
    V v_t_24110 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam13, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24103; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24103); r_; });
    if ((heff_dup(v_t_24110) == NTAG(TAG_True))) {
      heff_drop(v_t_24110);
      V v_m_24111 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam14, 1, 2, (V[]){v_m_24111, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24110);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam15, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_24122 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24123 = (g_heff_2ecompile_2eir_2enubI(v_t_24122));
    V v_t_24130 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam16, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24123; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24123); r_; });
    if ((heff_dup(v_t_24130) == NTAG(TAG_True))) {
      heff_drop(v_t_24130);
      V v_m_24131 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam17, 1, 2, (V[]){v_m_24131, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24130);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam18, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EProj: {
    heff_take_n(v_t_243, 0ULL, 4);
    V v_t_24144 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24145 = (g_heff_2ecompile_2eir_2enubI(v_t_24144));
    V v_t_24152 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam19, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24145; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24145); r_; });
    if ((heff_dup(v_t_24152) == NTAG(TAG_True))) {
      heff_drop(v_t_24152);
      V v_m_24153 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam20, 1, 2, (V[]){v_m_24153, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24152);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam21, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_ETag: {
    heff_take_n(v_t_243, 0ULL, 3);
    V v_t_24165 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24166 = (g_heff_2ecompile_2eir_2enubI(v_t_24165));
    V v_t_24173 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam22, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24166; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24166); r_; });
    if ((heff_dup(v_t_24173) == NTAG(TAG_True))) {
      heff_drop(v_t_24173);
      V v_m_24174 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam23, 1, 2, (V[]){v_m_24174, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24173);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam24, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_24185 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24186 = (g_heff_2ecompile_2eir_2enubI(v_t_24185));
    V v_t_24193 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam25, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24186; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24186); r_; });
    if ((heff_dup(v_t_24193) == NTAG(TAG_True))) {
      heff_drop(v_t_24193);
      V v_m_24194 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam26, 1, 2, (V[]){v_m_24194, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24193);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam27, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_24204 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24205 = (g_heff_2ecompile_2eir_2enubI(v_t_24204));
    V v_t_24212 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam28, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24205; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24205); r_; });
    if ((heff_dup(v_t_24212) == NTAG(TAG_True))) {
      heff_drop(v_t_24212);
      V v_m_24213 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam29, 1, 2, (V[]){v_m_24213, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24212);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam30, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_24224 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24225 = (g_heff_2ecompile_2eir_2enubI(v_t_24224));
    V v_t_24232 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam31, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24225; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24225); r_; });
    if ((heff_dup(v_t_24232) == NTAG(TAG_True))) {
      heff_drop(v_t_24232);
      V v_m_24233 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam32, 1, 2, (V[]){v_m_24233, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24232);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam33, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_ECall: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_24244 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24245 = (g_heff_2ecompile_2eir_2enubI(v_t_24244));
    V v_t_24252 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam34, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24245; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24245); r_; });
    if ((heff_dup(v_t_24252) == NTAG(TAG_True))) {
      heff_drop(v_t_24252);
      V v_m_24253 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam35, 1, 2, (V[]){v_m_24253, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24252);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam36, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_24263 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24264 = (g_heff_2ecompile_2eir_2enubI(v_t_24263));
    V v_t_24271 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam37, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24264; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24264); r_; });
    if ((heff_dup(v_t_24271) == NTAG(TAG_True))) {
      heff_drop(v_t_24271);
      V v_m_24272 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam38, 1, 2, (V[]){v_m_24272, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24271);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam39, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EFloat: {
    heff_take_na(v_t_243, 0ULL, 1);
    V v_t_24282 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24283 = (g_heff_2ecompile_2eir_2enubI(v_t_24282));
    V v_t_24290 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam40, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24283; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24283); r_; });
    if ((heff_dup(v_t_24290) == NTAG(TAG_True))) {
      heff_drop(v_t_24290);
      V v_m_24291 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam41, 1, 2, (V[]){v_m_24291, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24290);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam42, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EStr: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_24301 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24302 = (g_heff_2ecompile_2eir_2enubI(v_t_24301));
    V v_t_24309 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam43, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24302; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24302); r_; });
    if ((heff_dup(v_t_24309) == NTAG(TAG_True))) {
      heff_drop(v_t_24309);
      V v_m_24310 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam44, 1, 2, (V[]){v_m_24310, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24309);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam45, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_t_24320 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24321 = (g_heff_2ecompile_2eir_2enubI(v_t_24320));
    V v_t_24328 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam46, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24321; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24321); r_; });
    if ((heff_dup(v_t_24328) == NTAG(TAG_True))) {
      heff_drop(v_t_24328);
      V v_m_24329 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam47, 1, 2, (V[]){v_m_24329, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24328);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam48, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_24340 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24341 = (g_heff_2ecompile_2eir_2enubI(v_t_24340));
    V v_t_24348 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam49, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24341; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24341); r_; });
    if ((heff_dup(v_t_24348) == NTAG(TAG_True))) {
      heff_drop(v_t_24348);
      V v_m_24349 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam50, 1, 2, (V[]){v_m_24349, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24348);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam51, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_243, 0ULL, 1);
    V v_t_24359 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24360 = (g_heff_2ecompile_2eir_2enubI(v_t_24359));
    V v_t_24367 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam52, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24360; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24360); r_; });
    if ((heff_dup(v_t_24367) == NTAG(TAG_True))) {
      heff_drop(v_t_24367);
      V v_m_24368 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam53, 1, 2, (V[]){v_m_24368, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24367);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam54, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EAbandon: {
    V v_t_24377 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24378 = (g_heff_2ecompile_2eir_2enubI(v_t_24377));
    V v_t_24385 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam55, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24378; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24378); r_; });
    if ((heff_dup(v_t_24385) == NTAG(TAG_True))) {
      heff_drop(v_t_24385);
      V v_m_24386 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam56, 1, 2, (V[]){v_m_24386, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24385);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam57, 1, 1, (V[]){v_d_241});
    }
  }
  case TAG_EFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_24397 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_24398 = (g_heff_2ecompile_2eir_2enubI(v_t_24397));
    V v_t_24405 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam58, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_24398; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24398); r_; });
    if ((heff_dup(v_t_24405) == NTAG(TAG_True))) {
      heff_drop(v_t_24405);
      V v_m_24406 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam59, 1, 2, (V[]){v_m_24406, v_d_241});
    } else {
      heff_drop(v_k_240);
      heff_drop(v_t_24405);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam60, 1, 1, (V[]){v_d_241});
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2edefWith(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecpr_2edefWith_lam0(V self, V *args) {
  V v_g_247 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_248 = ({ V a_0 = v_k_240; V a_1 = v_g_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_247); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_249 == ((int64_t)0ULL)) && ({ V v_x_2412 = heff_dup(v_field_2410); int c_ = 1; heff_drop(v_x_2412); c_; })));
    heff_drop(v_field_2410);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam1(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_n_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_t_2419 = ({ V rv_2 = v_x_2417; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2420, v_n_2418});
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam2(V self, V *args) {
  V v_n_2421 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_n_2421});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam3(V self, V *args) {
  V v_g_2426 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2427 = ({ V a_0 = v_k_240; V a_1 = v_g_2426; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_2426); r_; });
  {
    V v_field_2429 = v_t_2427.f[1];
    int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2428 == ((int64_t)0ULL)) && ({ V v_x_2431 = heff_dup(v_field_2429); int c_ = 1; heff_drop(v_x_2431); c_; })));
    heff_drop(v_field_2429);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam4(V self, V *args) {
  V v_n_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_n_2434}));
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_n_2437 = heff_field(v_x2_2435, 1);
    V v_ru_24x2_2435_24MkPair = heff_take_reuse_n(v_x2_2435, 3ULL, 2);
    V v_t_2438 = ({ V rv_2 = v_x_2436; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2435_24MkPair, TAG_MkPair, 2, (V[]){v_t_2439, v_n_2437});
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam5(V self, V *args) {
  V v_n_2440 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2441, v_n_2440});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam6(V self, V *args) {
  V v_g_2446 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2447 = ({ V a_0 = v_k_240; V a_1 = v_g_2446; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_2446); r_; });
  {
    V v_field_2449 = v_t_2447.f[1];
    int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2448 == ((int64_t)0ULL)) && ({ V v_x_2451 = heff_dup(v_field_2449); int c_ = 1; heff_drop(v_x_2451); c_; })));
    heff_drop(v_field_2449);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam7(V self, V *args) {
  V v_n_2454 = args[0];
  V v_m_2453 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2455 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_n_2454}));
  switch (heff_tag_of(v_x2_2455)) {
  case TAG_MkPair: {
    V v_x_2456 = heff_field(v_x2_2455, 0);
    V v_n_2457 = heff_field(v_x2_2455, 1);
    V v_ru_24x2_2455_24MkPair = heff_take_reuse_n(v_x2_2455, 3ULL, 2);
    V v_t_2458 = ({ V rv_2 = v_x_2456; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2455_24MkPair, TAG_MkPair, 2, (V[]){v_t_2459, v_n_2457});
  }
  default: return heff_nomatch(v_x2_2455);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam8(V self, V *args) {
  V v_n_2460 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2461, v_n_2460});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam9(V self, V *args) {
  V v_n_2464 = args[0];
  V v_m_2463 = heff_env(self)[0];
  V v_lay_2462 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_xs_2442 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2465 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_n_2464}));
  switch (heff_tag_of(v_x2_2465)) {
  case TAG_MkPair: {
    V v_x_2466 = heff_field(v_x2_2465, 0);
    V v_n_2467 = heff_field(v_x2_2465, 1);
    V v_ru_24x2_2465_24MkPair = heff_take_reuse_n(v_x2_2465, 3ULL, 2);
    V v_m_2468 = (g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lay_2462), v_x_2466));
    V v_x2_2469 = heff_tr(heff_call(v_m_2468, 1, (V[]){v_n_2467}));
    switch (heff_tag_of(v_x2_2469)) {
    case TAG_MkPair: {
      V v_x_2470 = heff_field(v_x2_2469, 0);
      V v_n_2471 = heff_field(v_x2_2469, 1);
      V v_ru_24x2_2469_24MkPair = heff_take_reuse_n(v_x2_2469, 3ULL, 2);
      V v_m_2472 = (g_heff_2ecompile_2ecpr_2ewrapperOf(v_lay_2462, heff_dup(v_d_241), heff_dup(v_xs_2442)));
      V v_x2_2473 = heff_tr(heff_call(v_m_2472, 1, (V[]){v_n_2471}));
      switch (heff_tag_of(v_x2_2473)) {
      case TAG_MkPair: {
        V v_x_2474 = heff_field(v_x2_2473, 0);
        V v_n_2475 = heff_field(v_x2_2473, 1);
        heff_take_n(v_x2_2473, 3ULL, 2);
        V v_t_2476 = heff_strAppend(heff_take_field(v_d_241, 0), ((V)&g_heff_2ecompile_2ecpr_2edefWith_str0));
        V v_t_2477 = ({ V rv_0 = v_t_2476; V rv_2 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2442, v_x_2470}); V rr_ = heff_rec_reuse_nf(v_d_241, 2ULL, 3, shape_key__name__body, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2478 = heff_tag_at_n(v_ru_24x2_2469_24MkPair, TAG_Cons, 2, (V[]){v_x_2474, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_2465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, v_t_2478}), v_n_2475});
      }
      default: return heff_nomatch(v_x2_2473);
      }
    }
    default: return heff_nomatch(v_x2_2469);
    }
  }
  default: return heff_nomatch(v_x2_2465);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam10(V self, V *args) {
  V v_g_2483 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2484 = ({ V a_0 = v_k_240; V a_1 = v_g_2483; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_2483); r_; });
  {
    V v_field_2486 = v_t_2484.f[1];
    int64_t v_tag_2485 = ((int64_t)v_t_2484.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2485 == ((int64_t)0ULL)) && ({ V v_x_2488 = heff_dup(v_field_2486); int c_ = 1; heff_drop(v_x_2488); c_; })));
    heff_drop(v_field_2486);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam11(V self, V *args) {
  V v_n_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2492 = heff_tr(heff_call(v_m_2490, 1, (V[]){v_n_2491}));
  switch (heff_tag_of(v_x2_2492)) {
  case TAG_MkPair: {
    V v_x_2493 = heff_field(v_x2_2492, 0);
    V v_n_2494 = heff_field(v_x2_2492, 1);
    V v_ru_24x2_2492_24MkPair = heff_take_reuse_n(v_x2_2492, 3ULL, 2);
    V v_t_2495 = ({ V rv_2 = v_x_2493; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2496 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2495, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2492_24MkPair, TAG_MkPair, 2, (V[]){v_t_2496, v_n_2494});
  }
  default: return heff_nomatch(v_x2_2492);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam12(V self, V *args) {
  V v_n_2497 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2498, v_n_2497});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam13(V self, V *args) {
  V v_g_24104 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24105 = ({ V a_0 = v_k_240; V a_1 = v_g_24104; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24104); r_; });
  {
    V v_field_24107 = v_t_24105.f[1];
    int64_t v_tag_24106 = ((int64_t)v_t_24105.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24106 == ((int64_t)0ULL)) && ({ V v_x_24109 = heff_dup(v_field_24107); int c_ = 1; heff_drop(v_x_24109); c_; })));
    heff_drop(v_field_24107);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam14(V self, V *args) {
  V v_n_24112 = args[0];
  V v_m_24111 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24113 = heff_tr(heff_call(v_m_24111, 1, (V[]){v_n_24112}));
  switch (heff_tag_of(v_x2_24113)) {
  case TAG_MkPair: {
    V v_x_24114 = heff_field(v_x2_24113, 0);
    V v_n_24115 = heff_field(v_x2_24113, 1);
    V v_ru_24x2_24113_24MkPair = heff_take_reuse_n(v_x2_24113, 3ULL, 2);
    V v_t_24116 = ({ V rv_2 = v_x_24114; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24117 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24116, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24113_24MkPair, TAG_MkPair, 2, (V[]){v_t_24117, v_n_24115});
  }
  default: return heff_nomatch(v_x2_24113);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam15(V self, V *args) {
  V v_n_24118 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24119, v_n_24118});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam16(V self, V *args) {
  V v_g_24124 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24125 = ({ V a_0 = v_k_240; V a_1 = v_g_24124; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24124); r_; });
  {
    V v_field_24127 = v_t_24125.f[1];
    int64_t v_tag_24126 = ((int64_t)v_t_24125.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24126 == ((int64_t)0ULL)) && ({ V v_x_24129 = heff_dup(v_field_24127); int c_ = 1; heff_drop(v_x_24129); c_; })));
    heff_drop(v_field_24127);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam17(V self, V *args) {
  V v_n_24132 = args[0];
  V v_m_24131 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24133 = heff_tr(heff_call(v_m_24131, 1, (V[]){v_n_24132}));
  switch (heff_tag_of(v_x2_24133)) {
  case TAG_MkPair: {
    V v_x_24134 = heff_field(v_x2_24133, 0);
    V v_n_24135 = heff_field(v_x2_24133, 1);
    V v_ru_24x2_24133_24MkPair = heff_take_reuse_n(v_x2_24133, 3ULL, 2);
    V v_t_24136 = ({ V rv_2 = v_x_24134; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24137 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24136, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24133_24MkPair, TAG_MkPair, 2, (V[]){v_t_24137, v_n_24135});
  }
  default: return heff_nomatch(v_x2_24133);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam18(V self, V *args) {
  V v_n_24138 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24139 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24139, v_n_24138});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam19(V self, V *args) {
  V v_g_24146 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24147 = ({ V a_0 = v_k_240; V a_1 = v_g_24146; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24146); r_; });
  {
    V v_field_24149 = v_t_24147.f[1];
    int64_t v_tag_24148 = ((int64_t)v_t_24147.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24148 == ((int64_t)0ULL)) && ({ V v_x_24151 = heff_dup(v_field_24149); int c_ = 1; heff_drop(v_x_24151); c_; })));
    heff_drop(v_field_24149);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam20(V self, V *args) {
  V v_n_24154 = args[0];
  V v_m_24153 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24155 = heff_tr(heff_call(v_m_24153, 1, (V[]){v_n_24154}));
  switch (heff_tag_of(v_x2_24155)) {
  case TAG_MkPair: {
    V v_x_24156 = heff_field(v_x2_24155, 0);
    V v_n_24157 = heff_field(v_x2_24155, 1);
    V v_ru_24x2_24155_24MkPair = heff_take_reuse_n(v_x2_24155, 3ULL, 2);
    V v_t_24158 = ({ V rv_2 = v_x_24156; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24159 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24158, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24155_24MkPair, TAG_MkPair, 2, (V[]){v_t_24159, v_n_24157});
  }
  default: return heff_nomatch(v_x2_24155);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam21(V self, V *args) {
  V v_n_24160 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24161 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24161, v_n_24160});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam22(V self, V *args) {
  V v_g_24167 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24168 = ({ V a_0 = v_k_240; V a_1 = v_g_24167; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24167); r_; });
  {
    V v_field_24170 = v_t_24168.f[1];
    int64_t v_tag_24169 = ((int64_t)v_t_24168.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24169 == ((int64_t)0ULL)) && ({ V v_x_24172 = heff_dup(v_field_24170); int c_ = 1; heff_drop(v_x_24172); c_; })));
    heff_drop(v_field_24170);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam23(V self, V *args) {
  V v_n_24175 = args[0];
  V v_m_24174 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24176 = heff_tr(heff_call(v_m_24174, 1, (V[]){v_n_24175}));
  switch (heff_tag_of(v_x2_24176)) {
  case TAG_MkPair: {
    V v_x_24177 = heff_field(v_x2_24176, 0);
    V v_n_24178 = heff_field(v_x2_24176, 1);
    V v_ru_24x2_24176_24MkPair = heff_take_reuse_n(v_x2_24176, 3ULL, 2);
    V v_t_24179 = ({ V rv_2 = v_x_24177; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24180 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24179, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24176_24MkPair, TAG_MkPair, 2, (V[]){v_t_24180, v_n_24178});
  }
  default: return heff_nomatch(v_x2_24176);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam24(V self, V *args) {
  V v_n_24181 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24182 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24182, v_n_24181});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam25(V self, V *args) {
  V v_g_24187 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24188 = ({ V a_0 = v_k_240; V a_1 = v_g_24187; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24187); r_; });
  {
    V v_field_24190 = v_t_24188.f[1];
    int64_t v_tag_24189 = ((int64_t)v_t_24188.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24189 == ((int64_t)0ULL)) && ({ V v_x_24192 = heff_dup(v_field_24190); int c_ = 1; heff_drop(v_x_24192); c_; })));
    heff_drop(v_field_24190);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam26(V self, V *args) {
  V v_n_24195 = args[0];
  V v_m_24194 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24196 = heff_tr(heff_call(v_m_24194, 1, (V[]){v_n_24195}));
  switch (heff_tag_of(v_x2_24196)) {
  case TAG_MkPair: {
    V v_x_24197 = heff_field(v_x2_24196, 0);
    V v_n_24198 = heff_field(v_x2_24196, 1);
    V v_ru_24x2_24196_24MkPair = heff_take_reuse_n(v_x2_24196, 3ULL, 2);
    V v_t_24199 = ({ V rv_2 = v_x_24197; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24200 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24199, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24196_24MkPair, TAG_MkPair, 2, (V[]){v_t_24200, v_n_24198});
  }
  default: return heff_nomatch(v_x2_24196);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam27(V self, V *args) {
  V v_n_24201 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24202 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24202, v_n_24201});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam28(V self, V *args) {
  V v_g_24206 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24207 = ({ V a_0 = v_k_240; V a_1 = v_g_24206; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24206); r_; });
  {
    V v_field_24209 = v_t_24207.f[1];
    int64_t v_tag_24208 = ((int64_t)v_t_24207.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24208 == ((int64_t)0ULL)) && ({ V v_x_24211 = heff_dup(v_field_24209); int c_ = 1; heff_drop(v_x_24211); c_; })));
    heff_drop(v_field_24209);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam29(V self, V *args) {
  V v_n_24214 = args[0];
  V v_m_24213 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24215 = heff_tr(heff_call(v_m_24213, 1, (V[]){v_n_24214}));
  switch (heff_tag_of(v_x2_24215)) {
  case TAG_MkPair: {
    V v_x_24216 = heff_field(v_x2_24215, 0);
    V v_n_24217 = heff_field(v_x2_24215, 1);
    V v_ru_24x2_24215_24MkPair = heff_take_reuse_n(v_x2_24215, 3ULL, 2);
    V v_t_24218 = ({ V rv_2 = v_x_24216; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24219 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24218, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24215_24MkPair, TAG_MkPair, 2, (V[]){v_t_24219, v_n_24217});
  }
  default: return heff_nomatch(v_x2_24215);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam30(V self, V *args) {
  V v_n_24220 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24221 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24221, v_n_24220});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam31(V self, V *args) {
  V v_g_24226 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24227 = ({ V a_0 = v_k_240; V a_1 = v_g_24226; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24226); r_; });
  {
    V v_field_24229 = v_t_24227.f[1];
    int64_t v_tag_24228 = ((int64_t)v_t_24227.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24228 == ((int64_t)0ULL)) && ({ V v_x_24231 = heff_dup(v_field_24229); int c_ = 1; heff_drop(v_x_24231); c_; })));
    heff_drop(v_field_24229);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam32(V self, V *args) {
  V v_n_24234 = args[0];
  V v_m_24233 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24235 = heff_tr(heff_call(v_m_24233, 1, (V[]){v_n_24234}));
  switch (heff_tag_of(v_x2_24235)) {
  case TAG_MkPair: {
    V v_x_24236 = heff_field(v_x2_24235, 0);
    V v_n_24237 = heff_field(v_x2_24235, 1);
    V v_ru_24x2_24235_24MkPair = heff_take_reuse_n(v_x2_24235, 3ULL, 2);
    V v_t_24238 = ({ V rv_2 = v_x_24236; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24239 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24238, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24235_24MkPair, TAG_MkPair, 2, (V[]){v_t_24239, v_n_24237});
  }
  default: return heff_nomatch(v_x2_24235);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam33(V self, V *args) {
  V v_n_24240 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24241 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24241, v_n_24240});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam34(V self, V *args) {
  V v_g_24246 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24247 = ({ V a_0 = v_k_240; V a_1 = v_g_24246; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24246); r_; });
  {
    V v_field_24249 = v_t_24247.f[1];
    int64_t v_tag_24248 = ((int64_t)v_t_24247.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24248 == ((int64_t)0ULL)) && ({ V v_x_24251 = heff_dup(v_field_24249); int c_ = 1; heff_drop(v_x_24251); c_; })));
    heff_drop(v_field_24249);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam35(V self, V *args) {
  V v_n_24254 = args[0];
  V v_m_24253 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24255 = heff_tr(heff_call(v_m_24253, 1, (V[]){v_n_24254}));
  switch (heff_tag_of(v_x2_24255)) {
  case TAG_MkPair: {
    V v_x_24256 = heff_field(v_x2_24255, 0);
    V v_n_24257 = heff_field(v_x2_24255, 1);
    V v_ru_24x2_24255_24MkPair = heff_take_reuse_n(v_x2_24255, 3ULL, 2);
    V v_t_24258 = ({ V rv_2 = v_x_24256; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24259 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24258, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24255_24MkPair, TAG_MkPair, 2, (V[]){v_t_24259, v_n_24257});
  }
  default: return heff_nomatch(v_x2_24255);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam36(V self, V *args) {
  V v_n_24260 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24261 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24261, v_n_24260});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam37(V self, V *args) {
  V v_g_24265 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24266 = ({ V a_0 = v_k_240; V a_1 = v_g_24265; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24265); r_; });
  {
    V v_field_24268 = v_t_24266.f[1];
    int64_t v_tag_24267 = ((int64_t)v_t_24266.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24267 == ((int64_t)0ULL)) && ({ V v_x_24270 = heff_dup(v_field_24268); int c_ = 1; heff_drop(v_x_24270); c_; })));
    heff_drop(v_field_24268);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam38(V self, V *args) {
  V v_n_24273 = args[0];
  V v_m_24272 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24274 = heff_tr(heff_call(v_m_24272, 1, (V[]){v_n_24273}));
  switch (heff_tag_of(v_x2_24274)) {
  case TAG_MkPair: {
    V v_x_24275 = heff_field(v_x2_24274, 0);
    V v_n_24276 = heff_field(v_x2_24274, 1);
    V v_ru_24x2_24274_24MkPair = heff_take_reuse_n(v_x2_24274, 3ULL, 2);
    V v_t_24277 = ({ V rv_2 = v_x_24275; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24278 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24277, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24274_24MkPair, TAG_MkPair, 2, (V[]){v_t_24278, v_n_24276});
  }
  default: return heff_nomatch(v_x2_24274);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam39(V self, V *args) {
  V v_n_24279 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24280 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24280, v_n_24279});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam40(V self, V *args) {
  V v_g_24284 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24285 = ({ V a_0 = v_k_240; V a_1 = v_g_24284; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24284); r_; });
  {
    V v_field_24287 = v_t_24285.f[1];
    int64_t v_tag_24286 = ((int64_t)v_t_24285.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24286 == ((int64_t)0ULL)) && ({ V v_x_24289 = heff_dup(v_field_24287); int c_ = 1; heff_drop(v_x_24289); c_; })));
    heff_drop(v_field_24287);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam41(V self, V *args) {
  V v_n_24292 = args[0];
  V v_m_24291 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24293 = heff_tr(heff_call(v_m_24291, 1, (V[]){v_n_24292}));
  switch (heff_tag_of(v_x2_24293)) {
  case TAG_MkPair: {
    V v_x_24294 = heff_field(v_x2_24293, 0);
    V v_n_24295 = heff_field(v_x2_24293, 1);
    V v_ru_24x2_24293_24MkPair = heff_take_reuse_n(v_x2_24293, 3ULL, 2);
    V v_t_24296 = ({ V rv_2 = v_x_24294; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24297 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24296, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24293_24MkPair, TAG_MkPair, 2, (V[]){v_t_24297, v_n_24295});
  }
  default: return heff_nomatch(v_x2_24293);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam42(V self, V *args) {
  V v_n_24298 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24299 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24299, v_n_24298});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam43(V self, V *args) {
  V v_g_24303 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24304 = ({ V a_0 = v_k_240; V a_1 = v_g_24303; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24303); r_; });
  {
    V v_field_24306 = v_t_24304.f[1];
    int64_t v_tag_24305 = ((int64_t)v_t_24304.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24305 == ((int64_t)0ULL)) && ({ V v_x_24308 = heff_dup(v_field_24306); int c_ = 1; heff_drop(v_x_24308); c_; })));
    heff_drop(v_field_24306);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam44(V self, V *args) {
  V v_n_24311 = args[0];
  V v_m_24310 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24312 = heff_tr(heff_call(v_m_24310, 1, (V[]){v_n_24311}));
  switch (heff_tag_of(v_x2_24312)) {
  case TAG_MkPair: {
    V v_x_24313 = heff_field(v_x2_24312, 0);
    V v_n_24314 = heff_field(v_x2_24312, 1);
    V v_ru_24x2_24312_24MkPair = heff_take_reuse_n(v_x2_24312, 3ULL, 2);
    V v_t_24315 = ({ V rv_2 = v_x_24313; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24316 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24315, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24312_24MkPair, TAG_MkPair, 2, (V[]){v_t_24316, v_n_24314});
  }
  default: return heff_nomatch(v_x2_24312);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam45(V self, V *args) {
  V v_n_24317 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24318 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24318, v_n_24317});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam46(V self, V *args) {
  V v_g_24322 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24323 = ({ V a_0 = v_k_240; V a_1 = v_g_24322; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24322); r_; });
  {
    V v_field_24325 = v_t_24323.f[1];
    int64_t v_tag_24324 = ((int64_t)v_t_24323.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24324 == ((int64_t)0ULL)) && ({ V v_x_24327 = heff_dup(v_field_24325); int c_ = 1; heff_drop(v_x_24327); c_; })));
    heff_drop(v_field_24325);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam47(V self, V *args) {
  V v_n_24330 = args[0];
  V v_m_24329 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24331 = heff_tr(heff_call(v_m_24329, 1, (V[]){v_n_24330}));
  switch (heff_tag_of(v_x2_24331)) {
  case TAG_MkPair: {
    V v_x_24332 = heff_field(v_x2_24331, 0);
    V v_n_24333 = heff_field(v_x2_24331, 1);
    V v_ru_24x2_24331_24MkPair = heff_take_reuse_n(v_x2_24331, 3ULL, 2);
    V v_t_24334 = ({ V rv_2 = v_x_24332; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24335 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24334, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24331_24MkPair, TAG_MkPair, 2, (V[]){v_t_24335, v_n_24333});
  }
  default: return heff_nomatch(v_x2_24331);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam48(V self, V *args) {
  V v_n_24336 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24337 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24337, v_n_24336});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam49(V self, V *args) {
  V v_g_24342 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24343 = ({ V a_0 = v_k_240; V a_1 = v_g_24342; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24342); r_; });
  {
    V v_field_24345 = v_t_24343.f[1];
    int64_t v_tag_24344 = ((int64_t)v_t_24343.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24344 == ((int64_t)0ULL)) && ({ V v_x_24347 = heff_dup(v_field_24345); int c_ = 1; heff_drop(v_x_24347); c_; })));
    heff_drop(v_field_24345);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam50(V self, V *args) {
  V v_n_24350 = args[0];
  V v_m_24349 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24351 = heff_tr(heff_call(v_m_24349, 1, (V[]){v_n_24350}));
  switch (heff_tag_of(v_x2_24351)) {
  case TAG_MkPair: {
    V v_x_24352 = heff_field(v_x2_24351, 0);
    V v_n_24353 = heff_field(v_x2_24351, 1);
    V v_ru_24x2_24351_24MkPair = heff_take_reuse_n(v_x2_24351, 3ULL, 2);
    V v_t_24354 = ({ V rv_2 = v_x_24352; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24355 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24354, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24351_24MkPair, TAG_MkPair, 2, (V[]){v_t_24355, v_n_24353});
  }
  default: return heff_nomatch(v_x2_24351);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam51(V self, V *args) {
  V v_n_24356 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24357 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24357, v_n_24356});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam52(V self, V *args) {
  V v_g_24361 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24362 = ({ V a_0 = v_k_240; V a_1 = v_g_24361; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24361); r_; });
  {
    V v_field_24364 = v_t_24362.f[1];
    int64_t v_tag_24363 = ((int64_t)v_t_24362.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24363 == ((int64_t)0ULL)) && ({ V v_x_24366 = heff_dup(v_field_24364); int c_ = 1; heff_drop(v_x_24366); c_; })));
    heff_drop(v_field_24364);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam53(V self, V *args) {
  V v_n_24369 = args[0];
  V v_m_24368 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24370 = heff_tr(heff_call(v_m_24368, 1, (V[]){v_n_24369}));
  switch (heff_tag_of(v_x2_24370)) {
  case TAG_MkPair: {
    V v_x_24371 = heff_field(v_x2_24370, 0);
    V v_n_24372 = heff_field(v_x2_24370, 1);
    V v_ru_24x2_24370_24MkPair = heff_take_reuse_n(v_x2_24370, 3ULL, 2);
    V v_t_24373 = ({ V rv_2 = v_x_24371; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24374 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24373, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24370_24MkPair, TAG_MkPair, 2, (V[]){v_t_24374, v_n_24372});
  }
  default: return heff_nomatch(v_x2_24370);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam54(V self, V *args) {
  V v_n_24375 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24376 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24376, v_n_24375});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam55(V self, V *args) {
  V v_g_24379 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24380 = ({ V a_0 = v_k_240; V a_1 = v_g_24379; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24379); r_; });
  {
    V v_field_24382 = v_t_24380.f[1];
    int64_t v_tag_24381 = ((int64_t)v_t_24380.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24381 == ((int64_t)0ULL)) && ({ V v_x_24384 = heff_dup(v_field_24382); int c_ = 1; heff_drop(v_x_24384); c_; })));
    heff_drop(v_field_24382);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam56(V self, V *args) {
  V v_n_24387 = args[0];
  V v_m_24386 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24388 = heff_tr(heff_call(v_m_24386, 1, (V[]){v_n_24387}));
  switch (heff_tag_of(v_x2_24388)) {
  case TAG_MkPair: {
    V v_x_24389 = heff_field(v_x2_24388, 0);
    V v_n_24390 = heff_field(v_x2_24388, 1);
    V v_ru_24x2_24388_24MkPair = heff_take_reuse_n(v_x2_24388, 3ULL, 2);
    V v_t_24391 = ({ V rv_2 = v_x_24389; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24392 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24391, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24388_24MkPair, TAG_MkPair, 2, (V[]){v_t_24392, v_n_24390});
  }
  default: return heff_nomatch(v_x2_24388);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam57(V self, V *args) {
  V v_n_24393 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24394 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24394, v_n_24393});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam58(V self, V *args) {
  V v_g_24399 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24400 = ({ V a_0 = v_k_240; V a_1 = v_g_24399; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_24399); r_; });
  {
    V v_field_24402 = v_t_24400.f[1];
    int64_t v_tag_24401 = ((int64_t)v_t_24400.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24401 == ((int64_t)0ULL)) && ({ V v_x_24404 = heff_dup(v_field_24402); int c_ = 1; heff_drop(v_x_24404); c_; })));
    heff_drop(v_field_24402);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam59(V self, V *args) {
  V v_n_24407 = args[0];
  V v_m_24406 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24408 = heff_tr(heff_call(v_m_24406, 1, (V[]){v_n_24407}));
  switch (heff_tag_of(v_x2_24408)) {
  case TAG_MkPair: {
    V v_x_24409 = heff_field(v_x2_24408, 0);
    V v_n_24410 = heff_field(v_x2_24408, 1);
    V v_ru_24x2_24408_24MkPair = heff_take_reuse_n(v_x2_24408, 3ULL, 2);
    V v_t_24411 = ({ V rv_2 = v_x_24409; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_24412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24411, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24408_24MkPair, TAG_MkPair, 2, (V[]){v_t_24412, v_n_24410});
  }
  default: return heff_nomatch(v_x2_24408);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam60(V self, V *args) {
  V v_n_24413 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24414 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24414, v_n_24413});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecprWith_str0, 4, "$cpr");
V g_heff_2ecompile_2ecpr_2ecprWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ecprWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ecprWith_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2ecprWith(V v_supply_240, V v_defs_241, V v_k_242) {
top: ;
  V v_t_243 = (g_std_2emap_2esize(v_k_242));
  if (heff_intEq_c(v_t_243, MK_INT(0LL))) {
    heff_drop(v_k_242);
    return heff_rec_n(3, shape_defs__supply__tuples, (V[]){v_defs_241, v_supply_240, heff_dup(g_std_2emap_2eempty_get())});
  } else {
    V v_t_247 = (g_prelude_2etraverse_24s1673840189x4008143(heff_clo_n(g_heff_2ecompile_2ecpr_2ecprWith_lam0, 1, 1, (V[]){heff_dup(v_k_242)}), v_defs_241));
    V v_t_248 = heff_tr(heff_call(v_t_247, 1, (V[]){v_supply_240}));
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkPair: {
      V v_dss_249 = heff_field(v_t_248, 0);
      V v_n_2410 = heff_field(v_t_248, 1);
      heff_take_n(v_t_248, 3ULL, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_dss_249));
      V v_t_2412 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2411); r_; });
      V v_t_2413 = ({ V a_0 = v_k_242; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_k_242); r_; });
      V v_ps_2414 = (g_list_2emap_24s273193875x235978955(((V)&g_heff_2ecompile_2ecpr_2ecprWith_str0), MK_INT(1LL), MK_INT(0LL), v_t_2413));
      V v_t_2415 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2414; V r_ = (g_list_2efoldl_24s651278233x871164524(a_0, a_1)); heff_drop(v_ps_2414); r_; });
      return heff_rec_n(3, shape_defs__supply__tuples, (V[]){v_t_2412, v_n_2410, v_t_2415});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
}
V g_heff_2ecompile_2ecpr_2ecprWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ecprWith(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecpr_2ecprWith_lam0(V self, V *args) {
  V v_d_245 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_std_2emap_2elookup_24s1963842891x1660122411(v_k_242, heff_rfield(v_d_245, 0)));
  return ({ V a_0 = v_k_242; V a_1 = v_d_245; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2ecpr_2edefWith(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
}