// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_broken 566525696
#define LBL_entries 787768015
#define LBL_hidden 729654485
#define LBL_instances 1653559473
#define LBL_order 307364712
#define LBL_places 961367927
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eglobals_2eaddAmbiguous(V, V, V);
V g_heff_2eelab_2eglobals_2eaddAmbiguous_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddAmbiguous_clo;
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2eglobals_2eemptyGlobals_get(void);
V g_heff_2eelab_2eglobals_2eisBroken(V, V);
V g_heff_2eelab_2eglobals_2eisBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eisBroken_clo;
HeffT2 g_heff_2eelab_2eglobals_2elookupKey_24cpr(V, V);
V g_heff_2eelab_2eglobals_2eunderBrokenFrom(V, V, V);
V g_heff_2eelab_2eglobals_2eunderBrokenFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eunderBrokenFrom_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2emap_2edelete_24s1614046289x1611773644(V, V);
V g_std_2emap_2edelete_24s1614046289x1611773644_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s1614046289x1611773644_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);

static V g_heff_2eelab_2eglobals_2eemptyGlobals_val;
static HEFF_ONCE g_heff_2eelab_2eglobals_2eemptyGlobals_st;
static V g_heff_2eelab_2eglobals_2eemptyGlobals_init(void) {
  return heff_rec_n(8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2eglobals_2eemptyGlobals_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eglobals_2eemptyGlobals_st)) return g_heff_2eelab_2eglobals_2eemptyGlobals_val;
  return heff_global(&g_heff_2eelab_2eglobals_2eemptyGlobals_val, &g_heff_2eelab_2eglobals_2eemptyGlobals_st, g_heff_2eelab_2eglobals_2eemptyGlobals_init);
}
HEFF_LIT(g_heff_2eelab_2eglobals_2eunderBrokenFrom_str0, 1, ".");
Clo g_heff_2eelab_2eglobals_2eunderBrokenFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eunderBrokenFrom_entry, 3, 0};

V g_heff_2eelab_2eglobals_2eunderBrokenFrom(V v_g_240, V v_x_241, V v_i_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2eelab_2eglobals_2eunderBrokenFrom_str0), v_x_241, v_i_242, 5);
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop_rec(v_g_240, 8);
    heff_drop(v_j_243);
    return NTAG(TAG_False);
  } else {
    V v_t_244 = heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), heff_intAdd(heff_dup(v_j_243), MK_INT(1LL)));
    HeffT2 v_t_245 = ({ V a_0 = heff_rfield(v_g_240, 3); V a_1 = v_t_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_j_243);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_field_247);
        V t_0 = v_g_240;
        V t_1 = v_x_241;
        V t_2 = heff_intAdd(v_j_243, MK_INT(1LL));
        v_g_240 = t_0;
        v_x_241 = t_1;
        v_i_242 = t_2;
        goto top;
      }
    }
  }
}
V g_heff_2eelab_2eglobals_2eunderBrokenFrom_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eglobals_2eunderBrokenFrom(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eglobals_2eisBroken_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eisBroken_entry, 2, 0};

V g_heff_2eelab_2eglobals_2eisBroken(V v_g_240, V v_x_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_g_240, 2), v_x_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_k_245 = v_field_244;
      HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_g_240, 3, 8); V a_1 = v_k_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k_245); r_; });
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        V v_ret_24bool = heff_bool(((v_tag_247 == ((int64_t)0ULL)) && ({ V v_x_249 = heff_dup(v_field_248); int c_ = 1; heff_drop(v_x_249); c_; })));
        heff_drop(v_field_248);
        return v_ret_24bool;
      }
    } else {
      heff_drop(v_field_244);
      HeffT2 v_t_2410 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(heff_rfield(v_g_240, 3), v_x_241));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop_rec(v_g_240, 8);
          V v_x_2413 = v_field_2412;
          heff_drop(v_x_2413);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_field_2412);
          return (g_heff_2eelab_2eglobals_2eunderBrokenFrom(v_g_240, v_x_241, MK_INT(0LL)));
        }
      }
    }
  }
}
V g_heff_2eelab_2eglobals_2eisBroken_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eglobals_2eisBroken(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eglobals_2eaddEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eaddEntry_entry, 3, 0};

V g_heff_2eelab_2eglobals_2eaddEntry(V v_x_240, V v_e_241, V v_g_242) {
top: ;
  V v_entries_243 = heff_take_field(v_g_242, 1);
  V v_order_244 = heff_take_field(v_g_242, 0);
  V v_aliases_245 = heff_take_field(v_g_242, 2);
  V v_broken_246 = heff_take_field(v_g_242, 3);
  V v_ambiguous_247 = heff_take_field(v_g_242, 4);
  V v_places_248 = heff_take_field(v_g_242, 5);
  V v_hidden_249 = heff_take_field(v_g_242, 6);
  V v_instances_2410 = heff_get_n(v_g_242, 7, 8);
  HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_entries_243, v_x_240));
  V v_t_2416;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2413;
      heff_drop(v_x_2414);
      V v_t_2415 = (g_list_2ekeepIf_24s930188071x496633547(v_x_240, v_order_244));
      v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_240), v_t_2415});
    } else {
      heff_drop(v_field_2413);
      v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_240), v_order_244});
    }
  }
  V v_t_2417 = (g_std_2emap_2einsert_24s93785294x875597928(v_entries_243, v_x_240, v_e_241));
  return heff_rec_n(8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, (V[]){v_t_2416, v_t_2417, v_aliases_245, v_broken_246, v_ambiguous_247, v_places_248, v_hidden_249, v_instances_2410});
}
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eglobals_2eaddEntry(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eglobals_2eaddAmbiguous_lam0(V self, V *args);
Clo g_heff_2eelab_2eglobals_2eaddAmbiguous_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eaddAmbiguous_entry, 3, 0};

V g_heff_2eelab_2eglobals_2eaddAmbiguous(V v_x_240, V v_ks_241, V v_g_242) {
top: ;
  V v_order_243 = heff_take_field(v_g_242, 0);
  V v_entries_244 = heff_take_field(v_g_242, 1);
  V v_aliases_245 = heff_take_field(v_g_242, 2);
  V v_broken_246 = heff_take_field(v_g_242, 3);
  V v_ambiguous_247 = heff_take_field(v_g_242, 4);
  V v_places_248 = heff_take_field(v_g_242, 5);
  V v_hidden_249 = heff_take_field(v_g_242, 6);
  V v_instances_2410 = heff_get_n(v_g_242, 7, 8);
  V v_t_2411 = (g_std_2emap_2edelete_24s1614046289x1611773644(v_aliases_245, v_x_240));
  HeffT2 v_t_2412 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_ambiguous_247, v_x_240));
  V v_t_2419;
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_old_2415 = v_field_2414;
      v_t_2419 = (g_list_2ekeepIf(heff_clo_n(g_heff_2eelab_2eglobals_2eaddAmbiguous_lam0, 1, 1, (V[]){heff_dup(v_ks_241)}), v_old_2415));
    } else {
      heff_drop(v_field_2414);
      v_t_2419 = NTAG(TAG_Nil);
    }
  }
  V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2419, v_ks_241));
  V v_t_2421 = (g_std_2emap_2einsert_24s93785294x875597928(v_ambiguous_247, v_x_240, v_t_2420));
  return heff_rec_n(8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, (V[]){v_order_243, v_entries_244, v_t_2411, v_broken_246, v_t_2421, v_places_248, v_hidden_249, v_instances_2410});
}
V g_heff_2eelab_2eglobals_2eaddAmbiguous_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eglobals_2eaddAmbiguous(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eglobals_2eaddAmbiguous_lam0(V self, V *args) {
  V v_k_2416 = args[0];
  V v_ks_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_k_2416}));
  V v_x1_2418 = ({ V a_0 = v_t_2417; V a_1 = v_ks_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_ks_241); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2418) == NTAG(TAG_True)));
  heff_drop(v_x1_2418);
  return v_ret_24bool;
}

HeffT2 g_heff_2eelab_2eglobals_2elookupKey_24cpr(V v_g_240, V v_x_241) {
top: ;
  V v_aliases_242 = heff_take_field(v_g_240, 2);
  V v_entries_243 = heff_take_field(v_g_240, 1);
  V v_hidden_244 = heff_get_n(v_g_240, 6, 8);
  HeffT2 v_t_245 = ({ V a_0 = v_aliases_242; V a_1 = v_x_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_aliases_242); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_x_241);
      heff_drop(v_hidden_244);
      V v_k_248 = v_field_247;
      HeffT2 v_t_249 = ({ V a_0 = v_entries_243; V a_1 = v_k_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_entries_243); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_e_2412 = v_field_2411;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_k_248, v_e_2412})}});
        } else {
          heff_drop(v_k_248);
          heff_drop(v_field_2411);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_field_247);
      HeffT2 v_t_2413 = ({ V a_0 = v_hidden_244; V a_1 = v_x_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_hidden_244); r_; });
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          heff_drop(v_x_241);
          heff_drop(v_entries_243);
          V v_x_2416 = v_field_2415;
          heff_drop(v_x_2416);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        } else {
          heff_drop(v_field_2415);
          HeffT2 v_t_2417 = ({ V a_0 = v_entries_243; V a_1 = v_x_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_entries_243); r_; });
          {
            V v_field_2419 = v_t_2417.f[1];
            int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
            if ((v_tag_2418 == ((int64_t)0ULL))) {
              V v_e_2420 = v_field_2419;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_x_241, v_e_2420})}});
            } else {
              heff_drop(v_x_241);
              heff_drop(v_field_2419);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
      }
    }
  }
}
Clo g_heff_2eelab_2eglobals_2eaddOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eaddOwn_entry, 3, 0};

V g_heff_2eelab_2eglobals_2eaddOwn(V v_x_240, V v_k_241, V v_g_242) {
top: ;
  V v_ambiguous_243 = heff_take_field(v_g_242, 4);
  V v_order_244 = heff_take_field(v_g_242, 0);
  V v_entries_245 = heff_take_field(v_g_242, 1);
  V v_aliases_246 = heff_take_field(v_g_242, 2);
  V v_broken_247 = heff_take_field(v_g_242, 3);
  V v_places_248 = heff_take_field(v_g_242, 5);
  V v_hidden_249 = heff_take_field(v_g_242, 6);
  V v_instances_2410 = heff_get_n(v_g_242, 7, 8);
  V v_t_2411 = (g_std_2emap_2edelete_24s1614046289x1611773644(v_ambiguous_243, v_x_240));
  V v_t_2412 = (g_std_2emap_2einsert_24s93785294x875597928(v_aliases_246, v_x_240, v_k_241));
  return heff_rec_n(8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, (V[]){v_order_244, v_entries_245, v_t_2412, v_broken_247, v_t_2411, v_places_248, v_hidden_249, v_instances_2410});
}
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eglobals_2eaddOwn(a[0], a[1], a[2]);
}