// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_broken 566525696
#define LBL_entries 787768015
#define LBL_instances 1653559473
#define LBL_order 307364712
#define LBL_places 961367927
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_instances};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eglobals_2eaddAmbiguous(V, V, V);
V g_heff_2eelab_2eglobals_2eaddAmbiguous_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddAmbiguous_clo;
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2eglobals_2eemptyGlobals_get(void);
V g_heff_2eelab_2eglobals_2eisBroken(V, V);
V g_heff_2eelab_2eglobals_2eisBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eisBroken_clo;
V g_heff_2eelab_2eglobals_2elookupKey(V, V);
V g_heff_2eelab_2eglobals_2elookupKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2elookupKey_clo;
V g_heff_2eelab_2eglobals_2eunderBrokenFrom(V, V, V);
V g_heff_2eelab_2eglobals_2eunderBrokenFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eunderBrokenFrom_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s727803713x1346936525(V, V);
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_clo;
V g_map_2edelete_24s805420727x38051515(V, V);
V g_map_2edelete_24s805420727x38051515_entry(V self, V *a);
extern Clo g_map_2edelete_24s805420727x38051515_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;

static V g_heff_2eelab_2eglobals_2eemptyGlobals_val;
static HEFF_ONCE g_heff_2eelab_2eglobals_2eemptyGlobals_st;
static V g_heff_2eelab_2eglobals_2eemptyGlobals_init(void) {
  return heff_rec_n(7, shape_order__entries__aliases__broken__ambiguous__places__instances, (V[]){NTAG(TAG_Nil), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2eglobals_2eemptyGlobals_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eglobals_2eemptyGlobals_st)) return g_heff_2eelab_2eglobals_2eemptyGlobals_val;
  return heff_global(&g_heff_2eelab_2eglobals_2eemptyGlobals_val, &g_heff_2eelab_2eglobals_2eemptyGlobals_st, g_heff_2eelab_2eglobals_2eemptyGlobals_init);
}
HEFF_LIT(g_heff_2eelab_2eglobals_2eunderBrokenFrom_str0, 1, ".");
Clo g_heff_2eelab_2eglobals_2eunderBrokenFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eunderBrokenFrom_entry, 3, 0};

V g_heff_2eelab_2eglobals_2eunderBrokenFrom(V v_g_240, V v_x_241, V v_i_242) {
top: ;
  V v_t_243 = (g_prelude_2eindexFrom(((V)&g_heff_2eelab_2eglobals_2eunderBrokenFrom_str0), heff_dup(v_x_241), v_i_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_g_240, 7);
    heff_drop(v_x_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_j_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = heff_strSlice(heff_dup(v_x_241), MK_INT(0LL), heff_intAdd(heff_dup(v_j_244), MK_INT(1LL)));
    V v_x3_246 = (g_map_2elookup_24s659669741x1036301430(v_t_245, heff_rfield(v_g_240, 3)));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      V t_0 = v_g_240;
      V t_1 = v_x_241;
      V t_2 = heff_intAdd(v_j_244, MK_INT(1LL));
      v_g_240 = t_0;
      v_x_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      heff_drop_rec(v_g_240, 7);
      heff_drop(v_x_241);
      heff_drop(v_j_244);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_246);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2eglobals_2eunderBrokenFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eglobals_2eunderBrokenFrom(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eglobals_2eisBroken_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eisBroken_entry, 2, 0};

V g_heff_2eelab_2eglobals_2eisBroken(V v_g_240, V v_x_241) {
top: ;
  V v_t_242 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_241), heff_rfield(v_g_240, 2)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_x3_243 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_241), heff_rfield(v_g_240, 3)));
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nothing: {
      return (g_heff_2eelab_2eglobals_2eunderBrokenFrom(v_g_240, v_x_241, MK_INT(0LL)));
    }
    case TAG_Just: {
      heff_take_n(v_x3_243, 0ULL, 1);
      heff_drop_rec(v_g_240, 7);
      heff_drop(v_x_241);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  case TAG_Just: {
    V v_k_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    heff_drop(v_x_241);
    V v_x3_246 = ({ V a_0 = v_k_245; V b_1 = heff_get_n(v_g_240, 3, 7); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_246);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2eglobals_2eisBroken_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eglobals_2eisBroken(a[0], a[1]);
}
Clo g_heff_2eelab_2eglobals_2eaddEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eaddEntry_entry, 3, 0};

V g_heff_2eelab_2eglobals_2eaddEntry(V v_x_240, V v_e_241, V v_g_242) {
top: ;
  V v_x3_243 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_240), heff_rfield(v_g_242, 1)));
  V v_t_246;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_240), heff_dup(heff_rfield(v_g_242, 0))});
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_243, 0ULL, 1);
    V v_t_245 = (g_list_2efilter_24s727803713x1346936525(heff_dup(v_x_240), heff_dup(heff_rfield(v_g_242, 0))));
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_240), v_t_245});
    break;
  }
  default: heff_nomatch(v_x3_243);
  }
  V v_t_247 = (g_map_2einsert_24s1341440536x470972936(v_x_240, v_e_241, heff_take_field(v_g_242, 1)));
  return ({ V rv_0 = v_t_246; V rv_1 = v_t_247; V rr_ = heff_rec_reuse_nf(v_g_242, 124ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances, 16368u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eglobals_2eaddEntry(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eglobals_2eaddAmbiguous_lam0(V self, V *args);
Clo g_heff_2eelab_2eglobals_2eaddAmbiguous_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eaddAmbiguous_entry, 3, 0};

V g_heff_2eelab_2eglobals_2eaddAmbiguous(V v_x_240, V v_ks_241, V v_g_242) {
top: ;
  V v_t_243 = (g_map_2edelete_24s805420727x38051515(heff_dup(v_x_240), heff_rfield(v_g_242, 2)));
  V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_240), heff_rfield(v_g_242, 4)));
  V v_t_249;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_old_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_t_249 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2eglobals_2eaddAmbiguous_lam0, 1, 1, (V[]){heff_dup(v_ks_241)}), v_old_245));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_2410 = (g_prelude_2e_2b_2b(v_t_249, v_ks_241));
  V v_t_2411 = (g_map_2einsert_24s1341440536x470972936(v_x_240, v_t_2410, heff_take_field(v_g_242, 4)));
  return ({ V rv_2 = v_t_243; V rv_4 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_g_242, 107ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances, 15567u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2eglobals_2eaddAmbiguous_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eglobals_2eaddAmbiguous(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eglobals_2eaddAmbiguous_lam0(V self, V *args) {
  V v_k_246 = args[0];
  V v_ks_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_k_246}));
  V v_x1_248 = ({ V a_0 = v_t_247; V a_1 = v_ks_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_ks_241); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_248) == NTAG(TAG_True)));
  heff_drop(v_x1_248);
  return v_ret_24bool;
}
Clo g_heff_2eelab_2eglobals_2elookupKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2elookupKey_entry, 2, 0};

V g_heff_2eelab_2eglobals_2elookupKey(V v_g_240, V v_x_241) {
top: ;
  V v_t_242 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_241), heff_rfield(v_g_240, 2)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = ({ V a_0 = heff_dup(v_x_241); V b_1 = heff_get_n(v_g_240, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop(v_x_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_e_244 = heff_field(v_t_243, 0);
      V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
      return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_241, v_e_244})});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_Just: {
    V v_k_245 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    heff_drop(v_x_241);
    V v_t_246 = ({ V a_0 = heff_dup(v_k_245); V b_1 = heff_get_n(v_g_240, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop(v_k_245);
      heff_drop_cell(v_ru_24t_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_e_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24t_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_245, v_e_247})});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2eglobals_2elookupKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eglobals_2elookupKey(a[0], a[1]);
}
Clo g_heff_2eelab_2eglobals_2eaddOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eaddOwn_entry, 3, 0};

V g_heff_2eelab_2eglobals_2eaddOwn(V v_x_240, V v_k_241, V v_g_242) {
top: ;
  V v_t_243 = (g_map_2edelete_24s805420727x38051515(heff_dup(v_x_240), heff_rfield(v_g_242, 4)));
  V v_g_244 = ({ V rv_4 = v_t_243; V rr_ = heff_rec_reuse_nf(v_g_242, 111ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances, 15615u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_t_245 = (g_map_2einsert_24s1341440536x470972936(v_x_240, v_k_241, heff_take_field(v_g_244, 2)));
  return ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_nf(v_g_244, 123ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances, 16335u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eglobals_2eaddOwn(a[0], a[1], a[2]);
}