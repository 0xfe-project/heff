// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IntWord 51777
#define TAG_Left 13886
#define TAG_MkFieldPat 14710
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_RuneWord 42901
#define TAG_SError 24172
#define TAG_SizeDefault 11444
#define TAG_StringWord 15530
#define TAG_TypeWord 10401
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_items 301884378
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_unit 10090059
#define LBL_waiting 1348170899
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_items__waiting__diags[] = {LBL_items, LBL_waiting, LBL_diags};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_ty__size__unit__little__signed[] = {LBL_ty, LBL_size, LBL_unit, LBL_little, LBL_signed};
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2esyntax_2ecst_2efirstP(V);
V g_heff_2esyntax_2ecst_2efirstP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstP_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eapplyPatOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyPatOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyPatOp_clo;
V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo;
V g_heff_2esyntax_2esurface_2edeclL(V, V, V);
V g_heff_2esyntax_2esurface_2edeclL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclL_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclL_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387_24cpr(V, V);
V g_heff_2esyntax_2esurface_2edigitsVal(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2edigitsVal_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edigitsVal_clo;
V g_heff_2esyntax_2esurface_2edocNext(V, V, V);
V g_heff_2esyntax_2esurface_2edocNext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edocNext_clo;
V g_heff_2esyntax_2esurface_2eemptySpec_get(void);
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efieldPatL(V, V);
V g_heff_2esyntax_2esurface_2efieldPatL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldPatL_clo;
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2eidentOf(V);
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eidentOf_clo;
V g_heff_2esyntax_2esurface_2eintegerChecks(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerChecks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerChecks_clo;
V g_heff_2esyntax_2esurface_2eintegerFits(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerFits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerFits_clo;
V g_heff_2esyntax_2esurface_2eknotOf(V, V);
V g_heff_2esyntax_2esurface_2eknotOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eknotOf_clo;
V g_heff_2esyntax_2esurface_2elistP(V, V);
V g_heff_2esyntax_2esurface_2elistP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elistP_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2epiImplicits(V);
V g_heff_2esyntax_2esurface_2epiImplicits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_clo;
V g_heff_2esyntax_2esurface_2epiImplicits_24dps(V, V);
V g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_24dps_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_clo;
HeffT2 g_heff_2esyntax_2esurface_2esharedField_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2etuplePRev(V, V);
V g_heff_2esyntax_2esurface_2etuplePRev_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etuplePRev_clo;
V g_heff_2esyntax_2esurface_2ewordKw(V);
V g_heff_2esyntax_2esurface_2ewordKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewordKw_clo;
HeffT2 g_list_2efind_24s1236173780x2048419812_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
Clo g_heff_2esyntax_2esurface_2edigitsVal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edigitsVal_entry, 5, 0};

V g_heff_2esyntax_2esurface_2edigitsVal(V v_base_240, V v_s_241, V v_box_24i_242, V v_box_24stop_243, V v_n_244) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  int64_t v_stop_243 = heff_unbox_word(v_box_24stop_243);
top: ;
  if ((v_stop_243 <= v_i_242)) {
    heff_drop(v_base_240);
    return v_n_244;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_241, heff_box_word(v_i_242), 2)) == ((int64_t)95ULL))) {
      V t_0 = v_base_240;
      V t_1 = v_s_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      int64_t t_3 = v_stop_243;
      V t_4 = v_n_244;
      v_base_240 = t_0;
      v_s_241 = t_1;
      v_i_242 = t_2;
      v_stop_243 = t_3;
      v_n_244 = t_4;
      goto top;
    } else {
      V v_c_247 = heff_strByteAt_lent(v_s_241, heff_box_word(v_i_242), 2);
      int64_t v_t_2410;
      if ((((int64_t)97ULL) <= heff_peek_word(v_c_247))) {
        v_t_2410 = (heff_unbox_word(v_c_247) - ((int64_t)87ULL));
      } else {
        if ((((int64_t)65ULL) <= heff_peek_word(v_c_247))) {
          v_t_2410 = (heff_unbox_word(v_c_247) - ((int64_t)55ULL));
        } else {
          v_t_2410 = (heff_unbox_word(v_c_247) - ((int64_t)48ULL));
        }
      }
      V v_t_2411 = heff_intAdd(heff_intMul(v_n_244, heff_dup(v_base_240)), heff_box_word(v_t_2410));
      V t_0 = v_base_240;
      V t_1 = v_s_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      int64_t t_3 = v_stop_243;
      V t_4 = v_t_2411;
      v_base_240 = t_0;
      v_s_241 = t_1;
      v_i_242 = t_2;
      v_stop_243 = t_3;
      v_n_244 = t_4;
      goto top;
    }
  }
}
V g_heff_2esyntax_2esurface_2edigitsVal_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2edigitsVal(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2esurface_2epiImplicits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epiImplicits_entry, 1, 0};

V g_heff_2esyntax_2esurface_2epiImplicits(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EProject: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EPi: {
      V v_x111_2417 = heff_field(v_x11_241, 0);
      V v_rest_2418 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      switch (heff_tag_of(v_x111_2417)) {
      case TAG_PiNamed: {
        heff_take_n(v_x111_2417, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        V t_0 = v_rest_2418;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_PiImplicit: {
        V v_x_2422 = heff_field(v_x111_2417, 0);
        heff_take_n(v_x111_2417, 1ULL, 5);
        V v_cell_2427 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2422, heff_hole()});
        V v_u_2428 = (g_heff_2esyntax_2esurface_2epiImplicits_24dps(v_rest_2418, heff_dup(v_cell_2427)));
        heff_drop(v_u_2428);
        return v_cell_2427;
      }
      case TAG_PiInstance: {
        V v_x_2429 = heff_field(v_x111_2417, 0);
        heff_take_n(v_x111_2417, 1ULL, 4);
        V v_cell_2433 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2429, heff_hole()});
        V v_u_2434 = (g_heff_2esyntax_2esurface_2epiImplicits_24dps(v_rest_2418, heff_dup(v_cell_2433)));
        heff_drop(v_u_2434);
        return v_cell_2433;
      }
      case TAG_PiAnon: {
        heff_take_n(v_x111_2417, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        V t_0 = v_rest_2418;
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_x111_2417);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESig: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESum: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EDo: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EAssign: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWhile: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFor: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EIfThen: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EBreak: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EContinue: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EReturn: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ENest: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELazy: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETuple: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETry: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWith: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epiImplicits_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epiImplicits(a[0]);
}
Clo g_heff_2esyntax_2esurface_2eidentOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eidentOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eidentOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      V v_x_243 = heff_field(v_x11_241, 0);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_243)});
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      V v_x_245 = heff_field(v_x11_241, 0);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_245)});
    }
    case TAG_EInt: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EString: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EBinary: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ERune: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EProject: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ENamed: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EPi: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EAnn: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ESpec: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ESig: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ESum: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EStruct: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EDo: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELocal: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EAssign: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EWhile: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EFor: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EBreak: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EContinue: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EReturn: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ENest: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELazy: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ETuple: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ETry: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EWith: {
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eidentOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edocNext_str0, 1, "\012");
Clo g_heff_2esyntax_2esurface_2edocNext_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edocNext_entry, 3, 0};

V g_heff_2esyntax_2esurface_2edocNext(V v_src_240, V v_p_241, V v_d_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_p_241, 1));
  V v_t_2418;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_p_241, 1));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nil: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_d_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      V v_t_2411;
      switch (heff_tag_of(v_d_247)) {
      case TAG_At: {
        V v_s_2410 = heff_field(v_d_247, 1);
        heff_take_n(v_d_247, 2ULL, 2);
        v_t_2411 = v_s_2410;
        break;
      }
      default: heff_nomatch(v_d_247);
      }
      V v_j_2412 = heff_strFind(((V)&g_heff_2esyntax_2esurface_2edocNext_str0), heff_dup(v_src_240), heff_get_n(v_t_2411, 1, 2));
      V v_t_2414;
      if (heff_intLt_c_lent(v_j_2412, MK_INT(0LL), 2)) {
        heff_drop(v_j_2412);
        v_t_2414 = heff_strLength_lent(v_src_240, 0);
      } else {
        v_t_2414 = v_j_2412;
      }
      V v_t_2417;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2416 = heff_dup(heff_field(v_d_242, 1));
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      v_t_2418 = (g_heff_2esyntax_2esurface_2ecommentLinesFrom(v_src_240, heff_intAdd(v_t_2414, MK_INT(1LL)), heff_get_n(v_t_2417, 0, 2)));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, heff_take_field(v_p_241, 1)});
    return ({ V rv_1 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_p_241, 5ULL, 3, shape_items__waiting__diags, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  } else {
    heff_drop(v_t_2418);
    V v_items_2420 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_dup(heff_rfield(v_p_241, 0)), heff_dup(heff_rfield(v_p_241, 1))));
    V v_diags_2421 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_dup(heff_rfield(v_p_241, 2)), heff_dup(heff_rfield(v_p_241, 1))));
    heff_drop(v_diags_2421);
    V v_items_2422 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_241, 0), heff_dup(heff_rfield(v_p_241, 1))));
    heff_drop(v_items_2422);
    V v_diags_2423 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_241, 2), heff_get_n(v_p_241, 1, 3)));
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, NTAG(TAG_Nil)});
    return heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_2420, v_t_2424, v_diags_2423});
  }
}
V g_heff_2esyntax_2esurface_2edocNext_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2edocNext(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str0, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str1, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str2, 6, "String");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str3, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str4, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str5, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str6, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str7, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str8, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str9, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str10, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str11, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str12, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str13, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str14, 7, "Float32");
Clo g_heff_2esyntax_2esurface_2ewordKw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewordKw_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ewordKw(V v_x_240) {
top: ;
  if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurface_2ewordKw_str0), 2)) {
    return NTAG(TAG_IntWord);
  } else {
    if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurface_2ewordKw_str1), 2)) {
      return NTAG(TAG_FloatWord);
    } else {
      if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurface_2ewordKw_str2), 2)) {
        return NTAG(TAG_StringWord);
      } else {
        if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurface_2ewordKw_str3), 2)) {
          return NTAG(TAG_RuneWord);
        } else {
          if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurface_2ewordKw_str4), 2)) {
            return NTAG(TAG_ArrayWord);
          } else {
            if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurface_2ewordKw_str5), 2)) {
              return NTAG(TAG_AbandonWord);
            } else {
              HeffT2 v_t_247 = (g_list_2efind_24s1236173780x2048419812_24cpr(((V)&g_heff_2esyntax_2esurface_2ewordKw_str6), ((V)&g_heff_2esyntax_2esurface_2ewordKw_str7), ((V)&g_heff_2esyntax_2esurface_2ewordKw_str8), ((V)&g_heff_2esyntax_2esurface_2ewordKw_str9), ((V)&g_heff_2esyntax_2esurface_2ewordKw_str10), ((V)&g_heff_2esyntax_2esurface_2ewordKw_str11), ((V)&g_heff_2esyntax_2esurface_2ewordKw_str12), ((V)&g_heff_2esyntax_2esurface_2ewordKw_str13), ((V)&g_heff_2esyntax_2esurface_2ewordKw_str14), v_x_240, heff_dup(g_heff_2eelab_2efixed_2eallFixed_get())));
              {
                V v_field_249 = v_t_247.f[1];
                int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
                if ((v_tag_248 == ((int64_t)0ULL))) {
                  V v_w_2411 = v_field_249;
                  return heff_tag_n(TAG_FixedWord, 1, (V[]){v_w_2411});
                } else {
                  heff_drop(v_field_249);
                  return NTAG(TAG_TypeWord);
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2ewordKw_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2ewordKw(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etuplePRev_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2esurface_2etuplePRev_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2esurface_2etuplePRev_str2, 6, "MkPair");
Clo g_heff_2esyntax_2esurface_2etuplePRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etuplePRev_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etuplePRev(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2etuplePRev_str0), heff_dup(v_sp_240), NTAG(TAG_Nil)});
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etuplePRev_str1)}), heff_dup(v_sp_240)});
    V v_x1_244 = ({ V a_0 = v_t_243; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_247;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_At: {
      V v_s_246 = heff_field(v_x1_244, 1);
      heff_take_n(v_x1_244, 2ULL, 2);
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    V v_t_248 = ({ V rv_1 = heff_get_n(v_t_247, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_t_248});
  }
  case TAG_Cons: {
    V v_p_249 = heff_field(v_x2_241, 0);
    V v_x22_2410 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_2410)) {
    case TAG_Nil: {
      heff_drop_rec(v_sp_240, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_p_249;
    }
    case TAG_Cons: {
      V v_a_2411 = heff_field(v_x22_2410, 0);
      V v_more_2412 = heff_field(v_x22_2410, 1);
      V v_ru_24x22_2410_24Cons = heff_take_reuse_n(v_x22_2410, 3ULL, 2);
      V v_t_2415;
      switch (heff_tag_of(v_a_2411)) {
      case TAG_At: {
        V v_s_2414 = heff_dup(heff_field(v_a_2411, 1));
        v_t_2415 = v_s_2414;
        break;
      }
      default: heff_nomatch(v_a_2411);
      }
      V v_t_2416 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2415, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2417 = (g_heff_2esyntax_2esurface_2etuplePRev(v_t_2416, heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2411, v_more_2412})));
      V v_t_2418 = heff_tag_at_n(v_ru_24x22_2410_24Cons, TAG_Cons, 2, (V[]){v_p_249, NTAG(TAG_Nil)});
      V v_t_2419 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2etuplePRev_str2), heff_dup(v_sp_240), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2418})});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
    }
    default: return heff_nomatch(v_x22_2410);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2etuplePRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etuplePRev(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2elistP_str0, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurface_2elistP_str1, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurface_2elistP_str2, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2esurface_2elistP_str3, 4, "Cons");
V g_heff_2esyntax_2esurface_2elistP_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2elistP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elistP_entry, 2, 0};

V g_heff_2esyntax_2esurface_2elistP(V v_sp_240, V v_xs_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2elistP_str0), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2elistP_str1)}), heff_dup(v_sp_240)});
  V v_x1_244 = ({ V a_0 = v_t_243; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_At: {
    V v_s_246 = heff_field(v_x1_244, 1);
    heff_take_n(v_x1_244, 2ULL, 2);
    v_t_247 = v_s_246;
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_t_248 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_247, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  return (g_heff_2esyntax_2esurface_2efoldr(heff_clo_n(g_heff_2esyntax_2esurface_2elistP_lam0, 2, 1, (V[]){v_sp_240}), heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_t_248}), v_xs_241));
}
V g_heff_2esyntax_2esurface_2elistP_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2elistP(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2elistP_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_rest_2410 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_rest_2410), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2elistP_str2), heff_dup(v_sp_240), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_249), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2elistP_str3)}), heff_dup(v_sp_240)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_2410, NTAG(TAG_Nil)});
  V v_x1_2415 = ({ V a_0 = v_t_2413; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_t_2414}); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2418;
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_At: {
    V v_s_2417 = heff_field(v_x1_2415, 1);
    heff_take_n(v_x1_2415, 2ULL, 2);
    v_t_2418 = v_s_2417;
    break;
  }
  default: heff_nomatch(v_x1_2415);
  }
  V v_t_2419 = ({ V rv_1 = heff_get_n(v_t_2418, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  return heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_t_2419});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esharedField_24cpr_str0, 24, "a field is `name : Type`");
HEFF_LIT(g_heff_2esyntax_2esurface_2esharedField_24cpr_str1, 24, "a field is `name : Type`");

HeffT2 g_heff_2esyntax_2esurface_2esharedField_24cpr(V v_x_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_240, 3), heff_get_n(v_x_240, 4, 9)});
    V v_t_244 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esharedField_24cpr_str0), v_t_243, NTAG(TAG_Nothing)});
    V v_f_245 = heff_tag_n(TAG_Left, 1, (V[]){v_t_244});
    return ((HeffT2){{v_f_245, v_p_242}});
  }
  case TAG_Cons: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_At: {
      V v_x211_248 = heff_field(v_x21_246, 0);
      V v_sp_249 = heff_field(v_x21_246, 1);
      heff_take_n(v_x21_246, 3ULL, 2);
      switch (heff_tag_of(v_x211_248)) {
      case TAG_DeclareField: {
        V v_t_2412 = heff_field(v_x211_248, 2);
        V v_d_2413 = heff_field(v_x211_248, 3);
        V v_ru_24x211_248_24DeclareField = heff_take_reuse_n(v_x211_248, 12ULL, 4);
        V v_t_2414 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_240, 3)), heff_take_field(v_x_240, 4)});
        V v_t_2415 = heff_tag_at_n(v_ru_24x211_248_24DeclareField, TAG_DeclareField, 4, (V[]){heff_dup(heff_rfield(v_x_240, 1)), v_t_2414, v_t_2412, v_d_2413});
        V v_t_2416 = ({ V rv_0 = heff_get_n(v_x_240, 3, 9); V rr_ = heff_rec_reuse_nf(v_sp_249, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_f_2417 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_At, 2, (V[]){v_t_2415, v_t_2416})});
        return ((HeffT2){{v_f_2417, v_p_242}});
      }
      case TAG_BadFieldDecl: {
        V v_ru_24x211_248_24BadFieldDecl = heff_take_reuse_n(v_x211_248, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_rec(v_sp_249, 2);
        V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_240, 3), heff_get_n(v_x_240, 4, 9)});
        V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esharedField_24cpr_str1), v_t_2419, NTAG(TAG_Nothing)});
        V v_f_2421 = heff_tag_at_n(v_ru_24x211_248_24BadFieldDecl, TAG_Left, 1, (V[]){v_t_2420});
        return ((HeffT2){{v_f_2421, v_p_242}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x211_248)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

static V g_heff_2esyntax_2esurface_2eemptySpec_val;
static HEFF_ONCE g_heff_2esyntax_2esurface_2eemptySpec_st;
static V g_heff_2esyntax_2esurface_2eemptySpec_init(void) {
  return heff_rec_n(5, shape_ty__size__unit__little__signed, (V[]){NTAG(TAG_Nothing), NTAG(TAG_SizeDefault), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
}
V g_heff_2esyntax_2esurface_2eemptySpec_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurface_2eemptySpec_st)) return g_heff_2esyntax_2esurface_2eemptySpec_val;
  return heff_global(&g_heff_2esyntax_2esurface_2eemptySpec_val, &g_heff_2esyntax_2esurface_2eemptySpec_st, g_heff_2esyntax_2esurface_2eemptySpec_init);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerChecks_str0, 45, "an integer's segment is of 1 to 64 bits, not ");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintegerChecks_str1, 45, "an integer's segment is of 1 to 64 bits, not ");
V g_heff_2esyntax_2esurface_2eintegerChecks_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eintegerChecks_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerChecks_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2eintegerChecks_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eintegerChecks_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eintegerChecks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintegerChecks_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eintegerChecks(V v_inPat_240, V v_sp_241, V v_v_242, V v_s_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    heff_drop(v_s_243);
    return ((V)&g_heff_2esyntax_2esurface_2eintegerChecks_lam0_clo);
  }
  case TAG_Just: {
    V v_n_247 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    if (heff_intLt_c_lent(v_n_247, MK_INT(1LL), 2)) {
      heff_drop(v_v_242);
      heff_drop(v_s_243);
      return heff_clo_n(g_heff_2esyntax_2esurface_2eintegerChecks_lam1, 1, 2, (V[]){v_n_247, v_sp_241});
    } else {
      if (heff_intLt_c_lent(MK_INT(64LL), v_n_247, 1)) {
        heff_drop(v_v_242);
        heff_drop(v_s_243);
        return heff_clo_n(g_heff_2esyntax_2esurface_2eintegerChecks_lam2, 1, 2, (V[]){v_n_247, v_sp_241});
      } else {
        HEFF_LAST return g_heff_2esyntax_2esurface_2eintegerFits(v_inPat_240, v_sp_241, v_v_242, v_s_243, v_n_247);
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esyntax_2esurface_2eintegerChecks_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eintegerChecks(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eintegerChecks_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_st_245});
}
V g_heff_2esyntax_2esurface_2eintegerChecks_lam1(V self, V *args) {
  V v_st_249 = args[0];
  V v_n_247 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerChecks_str0), heff_intShow(v_n_247));
  V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2410, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2411}), v_st_249});
}
V g_heff_2esyntax_2esurface_2eintegerChecks_lam2(V self, V *args) {
  V v_st_2413 = args[0];
  V v_n_247 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eintegerChecks_str1), heff_intShow(v_n_247));
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2414, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2415}), v_st_2413});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str1, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str3, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str7, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str9, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str11, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str13, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldPatL_str15, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2efieldPatL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldPatL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldPatL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldPatL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldPatL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldPatL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldPatL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldPatL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldPatL_lam8(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efieldPatL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efieldPatL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efieldPatL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    heff_drop_rec(v_r_240, 3);
    V v_t_244 = (g_heff_2esyntax_2ecst_2efirstP(v_x2_241));
    V v_t_245 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstP(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_246 = heff_strAppend(heff_get_n(v_t_245, 1, 9), ((V)&g_heff_2esyntax_2esurface_2efieldPatL_str0));
    V v_msg_247 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efieldPatL_str1), v_t_246);
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldPatL_lam0, 1, 2, (V[]){v_t_244, v_msg_247});
  }
  case TAG_PAtom: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2412 = (g_heff_2esyntax_2ecst_2efirstP(v_x2_241));
    V v_t_2413 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstP(a_0)); heff_drop_tag(v_x2_241, 1); r_; });
    V v_t_2414 = heff_strAppend(heff_get_n(v_t_2413, 1, 9), ((V)&g_heff_2esyntax_2esurface_2efieldPatL_str2));
    V v_msg_2415 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efieldPatL_str3), v_t_2414);
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldPatL_lam1, 1, 2, (V[]){v_t_2412, v_msg_2415});
  }
  case TAG_PParen: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2422 = (g_heff_2esyntax_2ecst_2efirstP(v_x2_241));
    V v_t_2423 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstP(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_2424 = heff_strAppend(heff_get_n(v_t_2423, 1, 9), ((V)&g_heff_2esyntax_2esurface_2efieldPatL_str4));
    V v_msg_2425 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efieldPatL_str5), v_t_2424);
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldPatL_lam2, 1, 2, (V[]){v_t_2422, v_msg_2425});
  }
  case TAG_PList: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2433 = (g_heff_2esyntax_2ecst_2efirstP(v_x2_241));
    V v_t_2434 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstP(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_2435 = heff_strAppend(heff_get_n(v_t_2434, 1, 9), ((V)&g_heff_2esyntax_2esurface_2efieldPatL_str6));
    V v_msg_2436 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efieldPatL_str7), v_t_2435);
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldPatL_lam3, 1, 2, (V[]){v_t_2433, v_msg_2436});
  }
  case TAG_POp: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2443 = (g_heff_2esyntax_2ecst_2efirstP(v_x2_241));
    V v_t_2444 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstP(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_2445 = heff_strAppend(heff_get_n(v_t_2444, 1, 9), ((V)&g_heff_2esyntax_2esurface_2efieldPatL_str8));
    V v_msg_2446 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efieldPatL_str9), v_t_2445);
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldPatL_lam4, 1, 2, (V[]){v_t_2443, v_msg_2446});
  }
  case TAG_PRec: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2454 = (g_heff_2esyntax_2ecst_2efirstP(v_x2_241));
    V v_t_2455 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstP(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_2456 = heff_strAppend(heff_get_n(v_t_2455, 1, 9), ((V)&g_heff_2esyntax_2esurface_2efieldPatL_str10));
    V v_msg_2457 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efieldPatL_str11), v_t_2456);
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldPatL_lam5, 1, 2, (V[]){v_t_2454, v_msg_2457});
  }
  case TAG_PField: {
    V v_x_2461 = heff_field(v_x2_241, 0);
    V v_p_2463 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    V v_m_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){v_p_2463}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldPatL_lam6, 1, 2, (V[]){v_m_2464, v_x_2461});
  }
  case TAG_PAs: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2475 = (g_heff_2esyntax_2ecst_2efirstP(v_x2_241));
    V v_t_2476 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstP(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_2477 = heff_strAppend(heff_get_n(v_t_2476, 1, 9), ((V)&g_heff_2esyntax_2esurface_2efieldPatL_str12));
    V v_msg_2478 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efieldPatL_str13), v_t_2477);
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldPatL_lam7, 1, 2, (V[]){v_t_2475, v_msg_2478});
  }
  case TAG_PSeg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2485 = (g_heff_2esyntax_2ecst_2efirstP(v_x2_241));
    V v_t_2486 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstP(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_2487 = heff_strAppend(heff_get_n(v_t_2486, 1, 9), ((V)&g_heff_2esyntax_2esurface_2efieldPatL_str14));
    V v_msg_2488 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efieldPatL_str15), v_t_2487);
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldPatL_lam8, 1, 2, (V[]){v_t_2485, v_msg_2488});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2efieldPatL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efieldPatL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2efieldPatL_lam0(V self, V *args) {
  V v_st_248 = args[0];
  V v_t_244 = heff_env(self)[0];
  V v_msg_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_244, 3), heff_get_n(v_t_244, 4, 9)});
  V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_247, v_t_249, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2410}), v_st_248});
}
V g_heff_2esyntax_2esurface_2efieldPatL_lam1(V self, V *args) {
  V v_st_2416 = args[0];
  V v_t_2412 = heff_env(self)[0];
  V v_msg_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2412, 3), heff_get_n(v_t_2412, 4, 9)});
  V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2415, v_t_2417, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2418}), v_st_2416});
}
V g_heff_2esyntax_2esurface_2efieldPatL_lam2(V self, V *args) {
  V v_st_2426 = args[0];
  V v_t_2422 = heff_env(self)[0];
  V v_msg_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2422, 3), heff_get_n(v_t_2422, 4, 9)});
  V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2425, v_t_2427, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2428}), v_st_2426});
}
V g_heff_2esyntax_2esurface_2efieldPatL_lam3(V self, V *args) {
  V v_st_2437 = args[0];
  V v_t_2433 = heff_env(self)[0];
  V v_msg_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2438 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2433, 3), heff_get_n(v_t_2433, 4, 9)});
  V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2436, v_t_2438, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2439}), v_st_2437});
}
V g_heff_2esyntax_2esurface_2efieldPatL_lam4(V self, V *args) {
  V v_st_2447 = args[0];
  V v_t_2443 = heff_env(self)[0];
  V v_msg_2446 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2448 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2443, 3), heff_get_n(v_t_2443, 4, 9)});
  V v_t_2449 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2446, v_t_2448, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2449}), v_st_2447});
}
V g_heff_2esyntax_2esurface_2efieldPatL_lam5(V self, V *args) {
  V v_st_2458 = args[0];
  V v_t_2454 = heff_env(self)[0];
  V v_msg_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2454, 3), heff_get_n(v_t_2454, 4, 9)});
  V v_t_2460 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2457, v_t_2459, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2460}), v_st_2458});
}
V g_heff_2esyntax_2esurface_2efieldPatL_lam6(V self, V *args) {
  V v_st_2465 = args[0];
  V v_m_2464 = heff_env(self)[0];
  V v_x_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2466 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_st_2465}));
  switch (heff_tag_of(v_x1_2466)) {
  case TAG_MkPair: {
    V v_x11_2467 = heff_field(v_x1_2466, 0);
    V v_st_2468 = heff_field(v_x1_2466, 1);
    V v_ru_24x1_2466_24MkPair = heff_take_reuse_n(v_x1_2466, 3ULL, 2);
    switch (heff_tag_of(v_x11_2467)) {
    case TAG_Left: {
      V v_e_2469 = heff_field(v_x11_2467, 0);
      heff_take_n(v_x11_2467, 1ULL, 1);
      heff_drop_rec(v_x_2461, 9);
      return heff_tag_at_n(v_ru_24x1_2466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2469}), v_st_2468});
    }
    case TAG_Right: {
      V v_x_2470 = heff_field(v_x11_2467, 0);
      heff_take_n(v_x11_2467, 1ULL, 1);
      V v_t_2471 = heff_tag_n(TAG_MkFieldPat, 2, (V[]){heff_get_n(v_x_2461, 1, 9), v_x_2470});
      return heff_tag_at_n(v_ru_24x1_2466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2471}), v_st_2468});
    }
    default: return heff_nomatch(v_x11_2467);
    }
  }
  default: return heff_nomatch(v_x1_2466);
  }
}
V g_heff_2esyntax_2esurface_2efieldPatL_lam7(V self, V *args) {
  V v_st_2479 = args[0];
  V v_t_2475 = heff_env(self)[0];
  V v_msg_2478 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2480 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2475, 3), heff_get_n(v_t_2475, 4, 9)});
  V v_t_2481 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2478, v_t_2480, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2481}), v_st_2479});
}
V g_heff_2esyntax_2esurface_2efieldPatL_lam8(V self, V *args) {
  V v_st_2489 = args[0];
  V v_t_2485 = heff_env(self)[0];
  V v_msg_2488 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2490 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2485, 3), heff_get_n(v_t_2485, 4, 9)});
  V v_t_2491 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2488, v_t_2490, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2491}), v_st_2489});
}
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(V v_fix_240, V v_lenient_241, V v_st_242, V v_r_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_st_242, 0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_lam0, 1, 2, (V[]){v_r_243, v_st_242});
  }
  case TAG_Cons: {
    V v_before_249 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    V v_m_2411 = (g_heff_2esyntax_2esurface_2efirstS(heff_dup(v_fix_240), v_lenient_241, v_before_249, heff_dup(heff_rfield(v_r_243, 0))));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_lam1, 1, 5, (V[]){v_m_2411, v_st_242, v_fix_240, heff_dup(v_lenient_241), v_r_243});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_246, v_t_247})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_245});
}
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_fix_240 = heff_env(self)[2];
  V v_lenient_241 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_st_242, 2);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop_rec(v_r_243, 2);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_2413_24MkPair, 2);
        heff_drop(v_x_2417);
        heff_drop_cell(v_ru_24x11_2414_24Right, 1);
        V v_t_2418 = heff_dup(heff_rfield(v_st_242, 0));
        V v_t_2427;
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nil: {
          v_t_2427 = v_st_242;
          break;
        }
        case TAG_Cons: {
          V v_o_2419 = heff_field(v_t_2418, 0);
          V v_os_2420 = heff_field(v_t_2418, 1);
          heff_take_n(v_t_2418, 3ULL, 2);
          V v_t_2421 = heff_dup(heff_rfield(v_st_242, 1));
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Nil: {
            heff_drop(v_o_2419);
            heff_drop(v_os_2420);
            v_t_2427 = v_st_242;
            break;
          }
          case TAG_Cons: {
            V v_r_2422 = heff_field(v_t_2421, 0);
            V v_it2_2423 = heff_field(v_t_2421, 1);
            heff_take_n(v_t_2421, 3ULL, 2);
            switch (heff_tag_of(v_it2_2423)) {
            case TAG_Nil: {
              heff_drop(v_o_2419);
              heff_drop(v_os_2420);
              heff_drop(v_r_2422);
              v_t_2427 = v_st_242;
              break;
            }
            case TAG_Cons: {
              V v_l_2424 = heff_field(v_it2_2423, 0);
              V v_rest_2425 = heff_field(v_it2_2423, 1);
              heff_take_n(v_it2_2423, 3ULL, 2);
              heff_drop_rec(v_st_242, 2);
              V v_t_2426 = (g_heff_2esyntax_2esurface_2eapplyPatOp(v_o_2419, v_l_2424, v_r_2422));
              v_t_2427 = heff_rec_n(2, shape_ops__out, (V[]){v_os_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_rest_2425})});
              break;
            }
            default: heff_nomatch(v_it2_2423);
            }
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        V v_t_2428 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_t_2427; V a_3 = v_r_243; V r_ = (g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
        V f_ = v_t_2428;
        args[0] = v_st_2415;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_fix_240);
        heff_drop(v_lenient_241);
        heff_drop(v_x_2417);
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
        V v_t_2431 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_2429, v_t_2430})});
        return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, v_st_2415});
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_heff_2esyntax_2esurface_2eknotOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eknotOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eknotOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eknotOf(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_k_240);
    return heff_dup(g_std_2emap_2eempty_get());
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DImport: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DFixity: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DSig: {
      V v_names_247 = heff_field(v_x21_242, 0);
      V v_t_2411 = (g_heff_2esyntax_2esurface_2eknotOf(heff_dup(v_k_240), v_rest_243));
      return (g_list_2efoldl(heff_clo_n(g_heff_2esyntax_2esurface_2eknotOf_lam0, 2, 1, (V[]){v_k_240}), v_t_2411, v_names_247));
    }
    case TAG_DInstance: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DEqn: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DData: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DType: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DTheory: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DMutual: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DPrimitive: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DTest: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DWatch: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eknotOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eknotOf(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eknotOf_lam0(V self, V *args) {
  V v_m_2412 = args[0];
  V v_n_2413 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_n_2413));
  return (g_std_2emap_2einsert_24s93785294x875597928(v_m_2412, heff_get_n(v_t_2414, 0, 2), v_k_240));
}
Clo g_heff_2esyntax_2esurface_2edeclL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edeclL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2edeclL(V v_r_240, V v_d_241, V v_z_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2edeclL_24cpr(v_r_240, v_d_241, v_z_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2esurface_2edeclL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edeclL(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nothing: {
    V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
    return ((HeffT2){{v_t_242, v_p_241}});
  }
  case TAG_Just: {
    V v_x21_243 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24Just = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_d_245 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 2ULL, 2);
      V v_x1_246 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_d_245, v_p_241));
      switch (heff_tag_of(v_x1_246)) {
      case TAG_MkPair: {
        V v_x11_247 = heff_field(v_x1_246, 0);
        V v_st_248 = heff_field(v_x1_246, 1);
        heff_take_n(v_x1_246, 3ULL, 2);
        switch (heff_tag_of(v_x11_247)) {
        case TAG_Left: {
          V v_e_249 = heff_field(v_x11_247, 0);
          V v_ru_24x11_247_24Left = heff_take_reuse_n(v_x11_247, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24Just, 1);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_247_24Left, TAG_Left, 1, (V[]){v_e_249}), v_st_248}});
        }
        case TAG_Right: {
          V v_x_2410 = heff_field(v_x11_247, 0);
          V v_ru_24x11_247_24Right = heff_take_reuse_n(v_x11_247, 1ULL, 1);
          V v_t_2411 = heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Just, TAG_Just, 1, (V[]){v_x_2410})});
          return ((HeffT2){{v_t_2411, v_st_248}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_247)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}