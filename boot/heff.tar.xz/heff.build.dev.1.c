// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_MkWith 3751
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Sleep 25229
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_TryWait 64330
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_body 9524841
#define LBL_build 295453320
#define LBL_builds 569118448
#define LBL_code 9554612
#define LBL_command 1182252425
#define LBL_dev 308879
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_group 299987609
#define LBL_headers 1027165638
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_stamp 311115741
#define LBL_status 1054660381
#define LBL_target 1066236092
#define LBL_timeout 1065429926
#define LBL_wanted 1152016858
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_builds__wanted__port__proxy__pages[] = {LBL_builds, LBL_wanted, LBL_port, LBL_proxy, LBL_pages};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_dev__apps__stamp[] = {LBL_dev, LBL_apps, LBL_stamp};
static uint32_t shape_name__ended[] = {LBL_name, LBL_ended};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_get(void);
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2edev_2eanswer(V, V, V, V);
V g_heff_2ebuild_2edev_2eanswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eanswer_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235(V, V);
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_clo;
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516(V, V, V);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_clo;
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363(V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_clo;
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(V, V, V);
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_clo;
V g_heff_2ebuild_2edev_2efileAnswer(V, V);
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efileAnswer_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444_clo;
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_clo;
V g_heff_2ebuild_2edev_2eindexAnswer(V);
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eindexAnswer_clo;
V g_heff_2ebuild_2edev_2emadePage(V);
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2emadePage_clo;
V g_heff_2ebuild_2edev_2eownPath(V);
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eownPath_clo;
V g_heff_2ebuild_2edev_2epageAnswer(V, V, V);
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epageAnswer_clo;
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140(V, V, V, V);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_clo;
V g_heff_2ebuild_2edev_2erelayed(V, V);
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erelayed_clo;
V g_heff_2ebuild_2edev_2ereloadScript_get(void);
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537(V, V, V, V);
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634(V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_clo;
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(V);
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_clo;
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(V);
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_clo;
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(V);
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_clo;
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(V, V);
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s105899861x584770213(V);
V g_list_2eany_24s105899861x584770213_entry(V self, V *a);
extern Clo g_list_2eany_24s105899861x584770213_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s2044822566x1809079154(V, V, V, V, V, V);
V g_list_2ekeepIf_24s2044822566x1809079154_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2044822566x1809079154_clo;
V g_list_2emap_24f1297529223x1960372761(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1297529223x1960372761_entry(V self, V *a);
extern Clo g_list_2emap_24f1297529223x1960372761_clo;
V g_list_2emap_24s2104774589x596860835(V);
V g_list_2emap_24s2104774589x596860835_entry(V self, V *a);
extern Clo g_list_2emap_24s2104774589x596860835_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2efilesystem_2eisDirectory_24s742424059x1763865794(V);
V g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eisDirectory_24s742424059x1763865794_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s2044712421x1082792288(V, V, V);
V g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str0, 9, "</script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str1, 10, "  }, 500);");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str2, 5, "})();");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str3, 98, "      .then(function (t) { if (seen === null) seen = t; else if (t !== seen) location.reload(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str4, 29, "      .catch(function () {});");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str5, 48, "    fetch(\"/.heff/built\", { cache: \"no-store\" })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str6, 46, "      .then(function (r) { return r.text(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str7, 18, "  var seen = null;");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str8, 27, "  setInterval(function () {");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str10, 8, "<script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str11, 14, "(function () {");

static V g_heff_2ebuild_2edev_2ereloadScript_val;
static HEFF_ONCE g_heff_2ebuild_2edev_2ereloadScript_st;
static V g_heff_2ebuild_2edev_2ereloadScript_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str9); V a_1 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str10); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str11), v_t_244}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2edev_2ereloadScript_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2edev_2ereloadScript_st)) return g_heff_2ebuild_2edev_2ereloadScript_val;
  return heff_global(&g_heff_2ebuild_2edev_2ereloadScript_val, &g_heff_2ebuild_2edev_2ereloadScript_st, g_heff_2ebuild_2edev_2ereloadScript_init);
}
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str2, 3, "no ");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str4, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str5, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str6, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2efileAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efileAnswer_entry, 2, 0};

V g_heff_2ebuild_2edev_2efileAnswer(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str0), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str1)}), NTAG(TAG_Nil)});
    V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2efileAnswer_str2), heff_strAppend(v_p_240, ((V)&g_heff_2ebuild_2edev_2efileAnswer_str3)));
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_242, heff_bytesFromString(v_t_243)});
  }
  case TAG_Just: {
    V v_text_244 = heff_field(v_x2_241, 0);
    V v_kind_245 = ({ V a_0 = v_p_240; V r_ = (g_heff_2ebuild_2edev_2etypeOf(a_0)); heff_drop(v_p_240); r_; });
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str4), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str5)}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str6), v_kind_245}), v_t_246});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_247, heff_bytesFromString(heff_dup(v_text_244))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2efileAnswer(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str1, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str2, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str3, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str4, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str5, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str6, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str7, 8, "no page ");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str9, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str10, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str11, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str12, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str13, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2epageAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epageAnswer_entry, 3, 0};

V g_heff_2ebuild_2edev_2epageAnswer(V v_name_240, V v_built_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    if ((heff_dup(v_built_241) == NTAG(TAG_True))) {
      V v_kind_243 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str0); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
      V v_html_244 = (g_heff_2ebuild_2edev_2emadePage(v_name_240));
      V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str1), v_html_244, MK_INT(0LL), 5);
      V v_text_248;
      if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
        heff_drop(v_j_245);
        v_text_248 = heff_strAppend(v_html_244, heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
      } else {
        V v_t_247 = heff_strSlice(heff_dup(v_html_244), heff_dup(v_j_245), heff_strLength_lent(v_html_244, 0));
        v_text_248 = heff_strAppend(heff_strSlice(v_html_244, MK_INT(0LL), v_j_245), heff_strAppend(heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), v_t_247));
      }
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str2), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str3)}), NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str4), v_kind_243}), v_t_249});
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2410, heff_bytesFromString(v_text_248)});
    } else {
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str5), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str6)}), NTAG(TAG_Nil)});
      V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str7), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2edev_2epageAnswer_str8)));
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2411, heff_bytesFromString(v_t_2412)});
    }
  }
  case TAG_Just: {
    V v_html_2413 = heff_field(v_x3_242, 0);
    heff_drop(v_name_240);
    V v_kind_2414 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str9); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
    V v_j_2415 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str10), v_html_2413, MK_INT(0LL), 5);
    V v_text_2418;
    if (heff_intLt_c_lent(v_j_2415, MK_INT(0LL), 2)) {
      heff_drop(v_j_2415);
      v_text_2418 = heff_strAppend(heff_dup(v_html_2413), heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
    } else {
      V v_t_2417 = heff_strSlice(heff_dup(v_html_2413), heff_dup(v_j_2415), heff_strLength_lent(v_html_2413, 0));
      v_text_2418 = heff_strAppend(heff_strSlice_lent(v_html_2413, MK_INT(0LL), v_j_2415, 6), heff_strAppend(heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), v_t_2417));
    }
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str11), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str12)}), NTAG(TAG_Nil)});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str13), v_kind_2414}), v_t_2419});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2420, heff_bytesFromString(v_text_2418)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2edev_2epageAnswer(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str1, 4, "<ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str2, 23, "<title>heff dev</title>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str3, 18, "<h1>the pages</h1>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str4, 14, "<li><a href=\"/");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str5, 3, "/\">");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str6, 9, "</a></li>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str7, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str8, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str9, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str10, 5, "</ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str11, 15, "<!doctype html>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str14, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str15, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str16, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2eindexAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eindexAnswer_entry, 1, 0};

V g_heff_2ebuild_2edev_2eindexAnswer(V v_found_240) {
top: ;
  V v_kind_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str0); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str1), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str3), v_t_242})});
  V v_t_245;
  switch (heff_tag_of(v_found_240)) {
  case TAG_Nothing: {
    v_t_245 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_found_240, 0);
    v_t_245 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_found_240);
  }
  V v_t_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str4); V b_1 = MK_INT(0LL); V a_2 = MK_INT(3LL); V a_3 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str5); V b_4 = MK_INT(0LL); V a_5 = MK_INT(3LL); V a_6 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str6); V b_7 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str7); V b_8 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str8); V b_9 = MK_INT(0LL); V b_10 = MK_INT(1LL); V b_11 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str9); V a_12 = v_t_245; V r_ = (g_list_2emap_24f1297529223x1960372761(a_0, b_1, a_2, a_3, b_4, a_5, a_6, b_7, b_8, b_9, b_10, b_11, a_12)); heff_drop(b_1); heff_drop(b_4); heff_drop(b_7); heff_drop(b_8); heff_drop(b_9); heff_drop(b_10); heff_drop(b_11); r_; });
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), NTAG(TAG_Nil)});
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str10), v_t_247})));
  V v_xs_249 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str11), v_t_243}), v_t_248));
  V v_text_2412;
  switch (heff_tag_of(v_xs_249)) {
  case TAG_Nil: {
    v_text_2412 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_xs_249, 0);
    V v_xs_2411 = heff_field(v_xs_249, 1);
    heff_take_n(v_xs_249, 3ULL, 2);
    v_text_2412 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str13); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_xs_249);
  }
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str14), ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str15)}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str16), v_kind_241}), v_t_2413});
  return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2414, heff_bytesFromString(v_text_2412)});
}
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eindexAnswer(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str2, 2, ") ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str3, 7, "curl: (");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str6, 23, "heff dev: nothing from ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str7, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str8, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str9, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str10, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str11, 10, "keep-alive");
Clo g_heff_2ebuild_2edev_2erelayed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erelayed_entry, 2, 0};

V g_heff_2ebuild_2edev_2erelayed(V v_to_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Left: {
    V v_err_242 = heff_field(v_x2_241, 0);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erelayed_str0), ((V)&g_heff_2ebuild_2edev_2erelayed_str1)}), NTAG(TAG_Nil)});
    V v_t_244 = heff_intShow(heff_dup(heff_rfield(v_err_242, 0)));
    V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str2), heff_dup(heff_rfield(v_err_242, 1)));
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str3), heff_strAppend(v_t_244, v_t_245));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str4), heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2edev_2erelayed_str5)));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str6), heff_strAppend(v_to_240, v_t_247));
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(502LL), v_t_243, heff_bytesFromString(v_t_248)});
  }
  case TAG_Right: {
    V v_res_249 = heff_field(v_x2_241, 0);
    heff_drop(v_to_240);
    V v_t_2410 = (g_list_2ekeepIf_24s2044822566x1809079154(((V)&g_heff_2ebuild_2edev_2erelayed_str7), ((V)&g_heff_2ebuild_2edev_2erelayed_str8), ((V)&g_heff_2ebuild_2edev_2erelayed_str9), ((V)&g_heff_2ebuild_2edev_2erelayed_str10), ((V)&g_heff_2ebuild_2edev_2erelayed_str11), heff_dup(heff_rfield(v_res_249, 1))));
    return heff_rec_n(3, shape_status__headers__body, (V[]){heff_dup(heff_rfield(v_res_249, 0)), v_t_2410, heff_dup(heff_rfield(v_res_249, 2))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2erelayed(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str1, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str2, 1, ".");
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam2, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_entry, 2, 0};

V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235(V v_prog_240, V v_st_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_243 = (g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(v_t_242));
  return heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam0, 2, 3, (V[]){v_c_243, v_prog_240, heff_dup(v_st_241)});
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam2(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2421);
  V v_t_2423;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2418, 1)))) {
    heff_drop_rec(v_x_2418, 2);
    v_t_2423 = NTAG(TAG_Nil);
  } else {
    v_t_2423 = heff_get_n(v_x_2418, 0, 2);
  }
  V f_ = v_k_245;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2419 = heff_tag_n(TAG_End, 2, (V[]){v_x_2412, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2419}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2420, v_hd_244, heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam5, 1, 2, (V[]){v_x_2418, v_k_245})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = (g_heff_2ebuild_2ecommands_2ebuildTarget(v_st_241, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str2)));
  V v_t_2414 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2416;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  V v_c_2417 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_241; V a_2 = v_t_2413; V a_3 = heff_dup(v_x_2412); V a_4 = v_t_2414; V a_5 = v_t_2416; V r_ = (g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_241); r_; });
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam4, 1, 4, (V[]){v_x_2412, v_prog_240, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_247 = heff_dup(heff_field(v_x_246, 0));
    v_t_248 = v_x_247;
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  V v_total_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_248; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_t_2411 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str1), v_total_249, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam2_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2411, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam3, 1, 5, (V[]){v_st_241, v_x_246, v_prog_240, v_hd_244, v_k_245})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam1, 1, 4, (V[]){v_prog_240, v_hd_244, v_st_241, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_str0, 52, "heff dev: not built; built again at the next change\012");
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_entry, 3, 0};

V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(V v_r_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Write, 2, (V[]){heff_dup(heff_rfield(v_r_240, 1)), NTAG(TAG_MkUnit)});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  HEFF_LAST return g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam0, 1, 3, (V[]){v_r_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_str0), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2410);
  V v_t_2411 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_r_240, 2, 3), NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam1, 1, 2, (V[]){v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_str0, 8, "building");
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_str1, 5, "build");
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam1, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam3, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_entry, 4, 0};

V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140(V v_prog_240, V v_st_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam0, 1, 4, (V[]){v_prog_240, v_hd_242, heff_dup(v_st_241), v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam1(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam3(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam7(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2420);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam8(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2422);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam9(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2423);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam10(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2424);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_dup(heff_rfield(v_x_2411, 0));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Exited: {
    V v_n_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    if (heff_intEq_c(v_n_2416, MK_INT(0LL))) {
      heff_drop_rec(v_x_2411, 3);
      V v_c_2418 = ({ V a_0 = v_prog_240; V a_1 = v_st_241; V r_ = (g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235(a_0, a_1)); heff_drop(v_st_241); r_; });
      V f_ = v_c_2418;
      heff_room[0] = v_hd_242;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam6, 1, 1, (V[]){v_k_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_prog_240);
      heff_drop(v_st_241);
      return (g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(v_x_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam7, 1, 1, (V[]){v_k_243})));
    }
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(v_x_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam8, 1, 1, (V[]){v_k_243})));
  }
  case TAG_TimedOut: {
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(v_x_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam9, 1, 1, (V[]){v_k_243})));
  }
  case TAG_NotRun: {
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(v_x_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam10, 1, 1, (V[]){v_k_243})));
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412 = heff_tag_n(TAG_End, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2412}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2413, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam5, 1, 5, (V[]){v_x_2411, v_prog_240, v_st_241, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_str1), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_247), v_x_244, v_t_248, ((V)&g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam3_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2410, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam4, 1, 5, (V[]){v_x_247, v_prog_240, v_hd_242, v_st_241, v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam1_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_246, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam2, 1, 5, (V[]){v_prog_240, v_x_244, v_hd_242, v_st_241, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_str1, 1, "\012");
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_entry, 6, 0};

V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634(V v_prog_240, V v_clock_241, V v_st_242, V v_d_243, V v_stamp_244, V v_running_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_Sleep, 2, (V[]){MK_INT(250LL), NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tr(heff_call(heff_dup(v_clock_241), 1, (V[]){v_t_246}));
  return heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam0, 2, 7, (V[]){v_t_247, v_running_245, heff_dup(v_st_242), heff_dup(v_stamp_244), v_prog_240, v_clock_241, v_d_243});
}
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634(a[0], a[1], a2, a[3], a4, a[5]); heff_drop(a2); heff_drop(a4); return r;
}
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_d_243 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_hd_248 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nothing: {
    V v_t_2420 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_st_242; V a_3 = v_d_243; V a_4 = v_x_2416; V a_5 = v_x_2411; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_242); heff_drop(v_x_2416); r_; });
    V f_ = v_t_2420;
    heff_room[0] = v_hd_248;
    heff_room[1] = v_k_249;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_argv_2421 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_clock_241);
    heff_drop(v_st_242);
    heff_drop(v_x_2411);
    heff_drop(v_hd_248);
    V v_t_2422 = heff_intAdd(heff_take_field(v_d_243, 0), MK_INT(1LL));
    V v_t_2423 = ({ V rv_0 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_d_243, 30ULL, 5, shape_builds__wanted__port__proxy__pages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_k_249;
    args[0] = heff_rec_n(3, shape_dev__apps__stamp, (V[]){v_t_2423, v_argv_2421, v_x_2416});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_stamp_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_st_242 = heff_env(self)[3];
  V v_d_243 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_hd_248 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2416;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nil: {
    v_x_2416 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x_2413, 0);
    V v_xs_2415 = heff_field(v_x_2413, 1);
    heff_take_n(v_x_2413, 3ULL, 2);
    v_x_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_str1); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  if (heff_strEq_c_lent(v_x_2416, v_stamp_244, 0)) {
    heff_drop(v_x_2416);
    V v_t_2418 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_st_242; V a_3 = v_d_243; V a_4 = v_stamp_244; V a_5 = v_x_2411; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_242); heff_drop(v_stamp_244); r_; });
    V f_ = v_t_2418;
    heff_room[0] = v_hd_248;
    heff_room[1] = v_k_249;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_stamp_244);
    return ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_242; V a_2 = heff_dup(v_hd_248); V a_3 = heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam4, 1, 8, (V[]){v_prog_240, v_clock_241, heff_dup(v_st_242), v_d_243, v_x_2416, v_x_2411, v_hd_248, v_k_249}); V r_ = (g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140(a_0, a_1, a_2, a_3)); heff_drop(v_st_242); r_; });
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_stamp_244 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_clock_241 = heff_env(self)[4];
  V v_d_243 = heff_env(self)[5];
  V v_k_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2412 = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(v_st_242, NTAG(TAG_Nil), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam3, 1, 8, (V[]){v_stamp_244, v_prog_240, v_clock_241, v_st_242, v_d_243, v_x_2411, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_running_245 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_stamp_244 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_d_243 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2410);
  return (g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(NTAG(TAG_Nil), v_running_245, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam2, 1, 7, (V[]){v_st_242, v_hd_248, v_stamp_244, v_prog_240, v_clock_241, v_d_243, v_k_249})));
}
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_t_247 = heff_env(self)[0];
  V v_running_245 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_stamp_244 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_d_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s615738393x1686646143(v_t_247, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam1, 1, 8, (V[]){v_running_245, v_hd_248, v_st_242, v_stamp_244, v_prog_240, v_clock_241, v_d_243, v_k_249})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str1, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str3, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str4, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str5, 1, "c");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str6, 14, "nothing to run");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str8, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str9, 11, "); running ");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str10, 17, "heff dev: built (");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str11, 1, "\012");
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_entry, 3, 0};

V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516(V v_st_240, V v_d_241, V v_apps_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str0)));
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str1)));
  V v_t_245 = (g_std_2epath_2ejoin(v_t_243, v_t_244));
  V v_s_246 = ({ V a_0 = v_st_240; V a_1 = v_t_245; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_246; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(a_0)); heff_drop(v_t_247); r_; });
  return heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam0, 2, 4, (V[]){v_c_248, heff_dup(v_st_240), v_d_241, v_apps_242});
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam3(V self, V *args) {
  V v_a_2426 = args[0];
  V v_wanted_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_a_2426, 1)), 0, 3);
  if (heff_strEq_c(v_t_2427, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str5))) {
    switch (heff_tag_of(v_wanted_2425)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_2426, 2);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_t_2431 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_a_2426, 0, 2)}));
      return ({ V a_0 = v_t_2431; V a_1 = v_wanted_2425; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_wanted_2425, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2425);
    }
  } else {
    heff_drop_rec(v_a_2426, 2);
    heff_drop(v_wanted_2425);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_apps_242 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2423);
  V v_t_2424 = heff_intShow(heff_take_field(v_d_241, 0));
  V v_wanted_2425 = heff_get_n(v_d_241, 1, 5);
  V v_argv_2432 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam3, 1, 1, (V[]){v_wanted_2425}), v_apps_242));
  V v_t_2438;
  switch (heff_tag_of(v_argv_2432)) {
  case TAG_Nil: {
    v_t_2438 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str6);
    break;
  }
  case TAG_Cons: {
    V v_x2_2435 = (g_list_2emap_24s2104774589x596860835(v_argv_2432));
    switch (heff_tag_of(v_x2_2435)) {
    case TAG_Nil: {
      v_t_2438 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2436 = heff_field(v_x2_2435, 0);
      V v_xs_2437 = heff_field(v_x2_2435, 1);
      heff_take_n(v_x2_2435, 3ULL, 2);
      v_t_2438 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str8); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2435);
    }
    break;
  }
  default: heff_nomatch(v_argv_2432);
  }
  V v_t_2439 = heff_strAppend(v_t_2424, heff_strAppend(((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str9), v_t_2438));
  V v_str_2440 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str10), v_t_2439);
  V v_t_2441 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2440, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str11)), NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_apps_242 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2411);
  V v_t_2412 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str2)));
  V v_t_2413 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str3)));
  V v_t_2414 = (g_std_2epath_2ejoin(v_t_2412, v_t_2413));
  V v_a_2415 = ({ V a_0 = v_st_240; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_std_2epath_2eparse(v_st_240, v_a_2415));
  V v_t_2417 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str4)));
  V v_t_2418 = (g_std_2epath_2ejoin(v_t_2416, v_t_2417));
  V v_s_2419 = ({ V a_0 = v_st_240; V a_1 = v_t_2418; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2418); r_; });
  V v_t_2420 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2419; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2421 = heff_intShow(heff_dup(heff_rfield(v_d_241, 0)));
  V v_c_2422 = ({ V a_0 = v_t_2420; V a_1 = v_t_2421; V r_ = (g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(a_0, a_1)); heff_drop(v_t_2420); r_; });
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam2, 1, 4, (V[]){v_d_241, v_apps_242, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_apps_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam1, 1, 5, (V[]){v_st_240, v_d_241, v_hd_249, v_apps_242, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str2, 4, ".exe");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str3, 21, "heff dev: cannot run ");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str4, 1, "\012");
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam1, 1, 0};
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam12(V self, V *args);
Clo g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_entry, 8, 0};

V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273(V v_prog_240, V v_clock_241, V v_ex_242, V v_st_243, V v_d_244, V v_stamp_245, V v_running_246, V v_x5_247) {
top: ;
  switch (heff_tag_of(v_x5_247)) {
  case TAG_Nil: {
    heff_drop(v_ex_242);
    return (g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634(v_prog_240, v_clock_241, v_st_243, v_d_244, v_stamp_245, v_running_246));
  }
  case TAG_Cons: {
    V v_a_248 = heff_field(v_x5_247, 0);
    V v_rest_249 = heff_field(v_x5_247, 1);
    heff_take_n(v_x5_247, 3ULL, 2);
    V v_t_2410 = (g_std_2epath_2eparse(v_st_243, ((V)&g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str0)));
    V v_t_2411 = (g_std_2epath_2eparse(v_st_243, ((V)&g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str1)));
    V v_t_2412 = (g_std_2epath_2ejoin(v_t_2410, v_t_2411));
    V v_a_2413 = ({ V a_0 = v_st_243; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2412); r_; });
    V v_n_2414 = heff_dup(heff_rfield(v_a_248, 0));
    V v_t_2415 = (g_std_2epath_2eparse(v_st_243, v_a_2413));
    V v_t_2416;
    switch (heff_tag_of(v_st_243)) {
    case TAG_Posix: {
      v_t_2416 = v_n_2414;
      break;
    }
    case TAG_Windows: {
      v_t_2416 = heff_strAppend(v_n_2414, ((V)&g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str2));
      break;
    }
    default: heff_nomatch(v_st_243);
    }
    V v_t_2417 = (g_std_2epath_2eparse(v_st_243, v_t_2416));
    V v_t_2418 = (g_std_2epath_2ejoin(v_t_2415, v_t_2417));
    V v_program_2419 = ({ V a_0 = v_st_243; V a_1 = v_t_2418; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_t_2420 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_program_2419, NTAG(TAG_Nil), heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_c_2446 = (g_std_2eprocess_2ewithProcess_24s2044712421x1082792288(heff_dup(v_ex_242), v_t_2420, heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam0, 1, 9, (V[]){heff_dup(v_a_248), heff_dup(v_running_246), heff_dup(v_prog_240), heff_dup(v_clock_241), heff_dup(v_ex_242), heff_dup(v_st_243), heff_dup(v_d_244), heff_dup(v_stamp_245), heff_dup(v_rest_249)})));
    V v_t_2467 = heff_tr(heff_call(heff_dup(v_ex_242), 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam6, 2, 1, (V[]){v_c_2446}), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam8, 3, 9, (V[]){v_a_248, v_prog_240, v_clock_241, v_ex_242, heff_dup(v_st_243), v_d_244, heff_dup(v_stamp_245), v_running_246, v_rest_249})})}));
    return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam12, 2, 1, (V[]){v_t_2467});
  }
  default: return heff_nomatch(v_x5_247);
  }
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a5 = a[5]; V r = g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273(a[0], a[1], a[2], a3, a[4], a5, a[6], a[7]); heff_drop(a3); heff_drop(a5); return r;
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam1(V self, V *args) {
  V v_r_2424 = args[0];
  return v_r_2424;
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam5(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_2444 = args[1];
  V v_k_2445 = args[2];
  V v_x_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2443);
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_2441 = args[1];
  V v_k_2442 = args[2];
  V v_x_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2440);
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam5, 3, 1, (V[]){v_x_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam3(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2438;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam4, 3, 1, (V[]){v_x_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam2(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_c_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2436;
  args[0] = v_hd_2437;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam3, 1, 1, (V[]){v_k_2438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam0(V self, V *args) {
  V v_p_2421 = args[0];
  V v_a_248 = heff_env(self)[0];
  V v_running_246 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_ex_242 = heff_env(self)[4];
  V v_st_243 = heff_env(self)[5];
  V v_d_244 = heff_env(self)[6];
  V v_stamp_245 = heff_env(self)[7];
  V v_rest_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2423;
  switch (heff_tag_of(v_p_2421)) {
  case TAG_MkWith: {
    V v_x_2422 = heff_field(v_p_2421, 0);
    heff_take_n(v_p_2421, 1ULL, 1);
    v_t_2423 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_p_2421);
  }
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_TryWait, 2, (V[]){v_t_2423, ((V)&g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam1_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2431}));
  V v_t_2433 = heff_rec_n(2, shape_name__ended, (V[]){heff_get_n(v_a_248, 0, 2), v_t_2432});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
  V v_t_2435 = (g_prelude_2e_2b_2b(v_running_246, v_t_2434));
  V v_c_2436 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = v_t_2435; V a_7 = v_rest_249; V r_ = (g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam2, 2, 1, (V[]){v_c_2436});
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_hd_2447 = heff_env(self)[0];
  V v_k_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2449;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2447;
  heff_room[2] = v_k_2448;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam6(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2446;
  args[0] = heff_dup(v_hd_2447);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam7, 1, 2, (V[]){v_hd_2447, v_k_2448});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam11(V self, V *args) {
  V v_x_2464 = args[0];
  V v_hd_2465 = args[1];
  V v_k_2466 = args[2];
  V v_x_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2464);
  heff_drop(v_hd_2465);
  V f_ = v_k_2466;
  args[0] = v_x_2463;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam10(V self, V *args) {
  V v_x_2463 = args[0];
  V v_k_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2452;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam11, 3, 1, (V[]){v_x_2463});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam9(V self, V *args) {
  V v_x_2461 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_st_243 = heff_env(self)[3];
  V v_d_244 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_running_246 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  V v_hd_2451 = heff_env(self)[8];
  V v_k_2452 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2461);
  V v_c_2462 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = v_running_246; V a_7 = v_rest_249; V r_ = (g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  V f_ = v_c_2462;
  heff_room[0] = v_hd_2451;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam10, 1, 1, (V[]){v_k_2452});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam8(V self, V *args) {
  V v_err_2450 = args[0];
  V v_hd_2451 = args[1];
  V v_k_2452 = args[2];
  V v_a_248 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_d_244 = heff_env(self)[5];
  V v_stamp_245 = heff_env(self)[6];
  V v_running_246 = heff_env(self)[7];
  V v_rest_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_err_2450);
  V v_t_2453 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str3), heff_get_n(v_a_248, 0, 2));
  V v_t_2454 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2453, ((V)&g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str4)), NTAG(TAG_MkUnit)});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2460}), heff_dup(v_hd_2451), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam9, 1, 10, (V[]){v_prog_240, v_clock_241, v_ex_242, v_st_243, v_d_244, v_stamp_245, v_running_246, v_rest_249, v_hd_2451, v_k_2452})));
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam13(V self, V *args) {
  V v_x_2470 = args[0];
  V v_hd_2468 = heff_env(self)[0];
  V v_k_2469 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2470;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2468;
  heff_room[2] = v_k_2469;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam12(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  V v_t_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_co_2eop_24s615738393x1686646143(v_t_2467, heff_dup(v_hd_2468), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam13, 1, 2, (V[]){v_hd_2468, v_k_2469})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_str0, 9, "dev-pages");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_str1, 33, "heff dev: cannot serve the pages\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_str2, 1, "c");
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam14(V self, V *args);
Clo g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_entry, 7, 0};

V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(V v_prog_240, V v_clock_241, V v_ex_242, V v_st_243, V v_d_244, V v_stamp_245, V v_apps_246) {
top: ;
  V v_t_247 = (g_list_2eany_24s105899861x584770213(v_apps_246));
  V v_t_249 = heff_bool(((heff_dup(v_t_247) == NTAG(TAG_True)) && ({ V v_t_248 = heff_dup(heff_rfield(v_d_244, 4)); int c_ = !(heff_dup(v_t_248) == NTAG(TAG_True)); heff_drop(v_t_248); c_; })));
  heff_drop(v_t_247);
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam0, 2, 7, (V[]){v_d_244, v_ex_242, v_prog_240, v_clock_241, heff_dup(v_st_243), heff_dup(v_stamp_245), v_apps_246});
  } else {
    heff_drop(v_t_249);
    V v_c_2453 = (g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516(v_st_243, heff_dup(v_d_244), heff_dup(v_apps_246)));
    return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam14, 2, 8, (V[]){v_c_2453, v_d_244, v_apps_246, v_prog_240, v_clock_241, v_ex_242, heff_dup(v_st_243), heff_dup(v_stamp_245)});
  }
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a5 = a[5]; V r = g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(a[0], a[1], a[2], a3, a[4], a5, a[6]); heff_drop(a3); heff_drop(a5); return r;
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_2428 = args[1];
  V v_k_2429 = args[2];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2427);
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_2425 = args[1];
  V v_k_2426 = args[2];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2424);
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam6, 3, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2422;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam5, 3, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam4, 1, 1, (V[]){v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam2(V self, V *args) {
  V v_pg_2418 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_pg_2418);
  V v_t_2419 = ({ V rv_4 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_d_244, 15ULL, 5, shape_builds__wanted__port__proxy__pages, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_c_2420 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_t_2419; V a_5 = v_stamp_245; V a_6 = v_apps_246; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam3, 2, 1, (V[]){v_c_2420});
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam8(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_2431 = heff_env(self)[0];
  V v_k_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2433;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2431;
  heff_room[2] = v_k_2432;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam7(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2430;
  args[0] = heff_dup(v_hd_2431);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam8, 1, 2, (V[]){v_hd_2431, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam12(V self, V *args) {
  V v_x_2448 = args[0];
  V v_hd_2449 = args[1];
  V v_k_2450 = args[2];
  V v_x_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2448);
  heff_drop(v_hd_2449);
  V f_ = v_k_2450;
  args[0] = v_x_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam11(V self, V *args) {
  V v_x_2447 = args[0];
  V v_k_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2436;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam12, 3, 1, (V[]){v_x_2447});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam10(V self, V *args) {
  V v_x_2444 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  V v_hd_2435 = heff_env(self)[7];
  V v_k_2436 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2444);
  V v_t_2445 = ({ V rv_4 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_d_244, 15ULL, 5, shape_builds__wanted__port__proxy__pages, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_c_2446 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_t_2445; V a_5 = v_stamp_245; V a_6 = v_apps_246; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  V f_ = v_c_2446;
  heff_room[0] = v_hd_2435;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam11, 1, 1, (V[]){v_k_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam9(V self, V *args) {
  V v_err_2434 = args[0];
  V v_hd_2435 = args[1];
  V v_k_2436 = args[2];
  V v_d_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_err_2434);
  V v_t_2437 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_str1), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), heff_dup(v_hd_2435), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam10, 1, 9, (V[]){v_d_244, v_prog_240, v_clock_241, v_ex_242, v_st_243, v_stamp_245, v_apps_246, v_hd_2435, v_k_2436})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam13(V self, V *args) {
  V v_x_2452 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2452;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2410;
  heff_room[2] = v_k_2411;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_ex_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  V v_hd_2410 = heff_env(self)[7];
  V v_k_2411 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2413 = heff_dup(heff_rfield(v_d_244, 3));
  V v_t_2415;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2414, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_d_244, 2)), v_t_2415});
  V v_t_2417 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2412, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_str0), v_t_2416}), heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_c_2430 = (g_std_2eprocess_2ewithProcess_24s2044712421x1082792288(heff_dup(v_ex_242), v_t_2417, heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam2, 1, 7, (V[]){heff_dup(v_d_244), heff_dup(v_prog_240), heff_dup(v_clock_241), heff_dup(v_ex_242), heff_dup(v_st_243), heff_dup(v_stamp_245), heff_dup(v_apps_246)})));
  V v_t_2451 = heff_tr(heff_call(heff_dup(v_ex_242), 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam7, 2, 1, (V[]){v_c_2430}), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam9, 3, 7, (V[]){v_d_244, v_prog_240, v_clock_241, v_ex_242, v_st_243, v_stamp_245, v_apps_246})})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2451, heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam13, 1, 2, (V[]){v_hd_2410, v_k_2411})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_d_244 = heff_env(self)[0];
  V v_ex_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam1, 1, 9, (V[]){v_d_244, v_ex_242, v_prog_240, v_clock_241, v_st_243, v_stamp_245, v_apps_246, v_hd_2410, v_k_2411})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam16(V self, V *args) {
  V v_a_2458 = args[0];
  V v_wanted_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2459 = heff_get_n(heff_dup(heff_rfield(v_a_2458, 1)), 0, 3);
  if (heff_strEq_c(v_t_2459, ((V)&g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_str2))) {
    switch (heff_tag_of(v_wanted_2457)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_2458, 2);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_t_2463 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_a_2458, 0, 2)}));
      return ({ V a_0 = v_t_2463; V a_1 = v_wanted_2457; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_wanted_2457, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2457);
    }
  } else {
    heff_drop_rec(v_a_2458, 2);
    heff_drop(v_wanted_2457);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam17(V self, V *args) {
  V v_x_2466 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_st_243 = heff_env(self)[3];
  V v_hd_2454 = heff_env(self)[4];
  V v_k_2455 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2467 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = heff_take_field(v_x_2466, 0); V b_5 = heff_take_field(v_x_2466, 2); V a_6 = heff_get_n(v_x_2466, 1, 3); V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(a_0, a_1, a_2, a_3, a_4, b_5, a_6)); heff_drop(v_st_243); heff_drop(b_5); r_; });
  V f_ = v_t_2467;
  heff_room[0] = v_hd_2454;
  heff_room[1] = v_k_2455;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam15(V self, V *args) {
  V v_x_2456 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_apps_246 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_ex_242 = heff_env(self)[4];
  V v_st_243 = heff_env(self)[5];
  V v_stamp_245 = heff_env(self)[6];
  V v_hd_2454 = heff_env(self)[7];
  V v_k_2455 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2456);
  V v_wanted_2457 = heff_dup(heff_rfield(v_d_244, 1));
  V v_t_2464 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam16, 1, 1, (V[]){v_wanted_2457}), v_apps_246));
  V v_c_2465 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = heff_dup(v_clock_241); V a_2 = heff_dup(v_ex_242); V a_3 = v_st_243; V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = NTAG(TAG_Nil); V a_7 = v_t_2464; V r_ = (g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_stamp_245); r_; });
  V f_ = v_c_2465;
  heff_room[0] = heff_dup(v_hd_2454);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam17, 1, 6, (V[]){v_prog_240, v_clock_241, v_ex_242, v_st_243, v_hd_2454, v_k_2455});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam14(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  V v_c_2453 = heff_env(self)[0];
  V v_d_244 = heff_env(self)[1];
  V v_apps_246 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_clock_241 = heff_env(self)[4];
  V v_ex_242 = heff_env(self)[5];
  V v_st_243 = heff_env(self)[6];
  V v_stamp_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2453;
  args[0] = heff_dup(v_hd_2454);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam15, 1, 9, (V[]){v_d_244, v_apps_246, v_prog_240, v_clock_241, v_ex_242, v_st_243, v_stamp_245, v_hd_2454, v_k_2455});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str2, 59, "heff dev: no package.hf here: run it at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str5, 4, "8000");
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam2, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_entry, 6, 0};

V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363(V v_prog_240, V v_clock_241, V v_ex_242, V v_wanted_243, V v_port_244, V v_proxy_245) {
top: ;
  V v_t_246 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_246); r_; });
  return heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam0, 2, 7, (V[]){v_c_247, heff_dup(v_port_244), v_wanted_243, v_proxy_245, v_prog_240, v_clock_241, v_ex_242});
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  return v_s_2411;
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  V v_t_2430 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_hd_248, v_k_249));
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam7(V self, V *args) {
  V v_x_2448 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_st_2421 = heff_env(self)[3];
  V v_hd_248 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2449 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_2421; V a_4 = heff_take_field(v_x_2448, 0); V b_5 = heff_take_field(v_x_2448, 2); V a_6 = heff_get_n(v_x_2448, 1, 3); V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(a_0, a_1, a_2, a_3, a_4, b_5, a_6)); heff_drop(v_st_2421); heff_drop(b_5); r_; });
  V f_ = v_t_2449;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam6(V self, V *args) {
  V v_x_2446 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_st_2421 = heff_env(self)[2];
  V v_d_2445 = heff_env(self)[3];
  V v_x_2442 = heff_env(self)[4];
  V v_hd_248 = heff_env(self)[5];
  V v_ex_242 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2446)) {
  case TAG_Nothing: {
    V v_c_2447 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = heff_dup(v_clock_241); V a_2 = v_st_2421; V a_3 = v_d_2445; V a_4 = v_x_2442; V a_5 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2442); r_; });
    V f_ = v_c_2447;
    heff_room[0] = heff_dup(v_hd_248);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam7, 1, 6, (V[]){v_prog_240, v_clock_241, v_ex_242, v_st_2421, v_hd_248, v_k_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_apps_2450 = heff_field(v_x_2446, 0);
    heff_take_n(v_x_2446, 1ULL, 1);
    V v_t_2451 = ({ V rv_0 = MK_INT(1LL); V rr_ = heff_rec_reuse_nf(v_d_2445, 30ULL, 5, shape_builds__wanted__port__proxy__pages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2452 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_2421; V a_4 = v_t_2451; V a_5 = v_x_2442; V a_6 = v_apps_2450; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_2421); heff_drop(v_x_2442); r_; });
    V f_ = v_t_2452;
    heff_room[0] = v_hd_248;
    heff_room[1] = v_k_249;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2446);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam5(V self, V *args) {
  V v_x_2439 = args[0];
  V v_port_244 = heff_env(self)[0];
  V v_wanted_243 = heff_env(self)[1];
  V v_proxy_245 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_st_2421 = heff_env(self)[4];
  V v_hd_248 = heff_env(self)[5];
  V v_clock_241 = heff_env(self)[6];
  V v_ex_242 = heff_env(self)[7];
  V v_k_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x_2442;
  switch (heff_tag_of(v_x_2439)) {
  case TAG_Nil: {
    v_x_2442 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2440 = heff_field(v_x_2439, 0);
    V v_xs_2441 = heff_field(v_x_2439, 1);
    heff_take_n(v_x_2439, 3ULL, 2);
    v_x_2442 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str4); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
    break;
  }
  default: heff_nomatch(v_x_2439);
  }
  V v_t_2444;
  switch (heff_tag_of(v_port_244)) {
  case TAG_Nothing: {
    v_t_2444 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str5);
    break;
  }
  case TAG_Just: {
    V v_x_2443 = heff_field(v_port_244, 0);
    heff_take_n(v_port_244, 1ULL, 1);
    v_t_2444 = v_x_2443;
    break;
  }
  default: heff_nomatch(v_port_244);
  }
  V v_d_2445 = heff_rec_n(5, shape_builds__wanted__port__proxy__pages, (V[]){MK_INT(0LL), v_wanted_243, v_t_2444, v_proxy_245, NTAG(TAG_False)});
  return ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_2421; V a_2 = heff_dup(v_hd_248); V a_3 = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam6, 1, 8, (V[]){v_prog_240, v_clock_241, heff_dup(v_st_2421), v_d_2445, v_x_2442, v_hd_248, v_ex_242, v_k_249}); V r_ = (g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140(a_0, a_1, a_2, a_3)); heff_drop(v_st_2421); r_; });
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_port_244 = heff_env(self)[3];
  V v_wanted_243 = heff_env(self)[4];
  V v_proxy_245 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_clock_241 = heff_env(self)[7];
  V v_ex_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_st_2421;
  if (heff_strEq_c(v_x_2419, ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str1))) {
    v_st_2421 = NTAG(TAG_Windows);
  } else {
    v_st_2421 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_drop(v_port_244);
    heff_drop(v_wanted_243);
    heff_drop(v_proxy_245);
    heff_drop(v_prog_240);
    heff_drop(v_clock_241);
    heff_drop(v_ex_242);
    heff_drop(v_st_2421);
    V v_t_2422 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str2), NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam4, 1, 2, (V[]){v_hd_248, v_k_249})));
  }
  case TAG_Just: {
    heff_take_n(v_x_2410, 0ULL, 1);
    V v_c_2438 = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(v_st_2421, NTAG(TAG_Nil), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
    V f_ = v_c_2438;
    heff_room[0] = heff_dup(v_hd_248);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam5, 1, 9, (V[]){v_port_244, v_wanted_243, v_proxy_245, v_prog_240, v_st_2421, v_hd_248, v_clock_241, v_ex_242, v_k_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  V v_port_244 = heff_env(self)[2];
  V v_wanted_243 = heff_env(self)[3];
  V v_proxy_245 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_clock_241 = heff_env(self)[6];
  V v_ex_242 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s615738393x1686646143(v_t_2418, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam3, 1, 9, (V[]){v_x_2410, v_hd_248, v_k_249, v_port_244, v_wanted_243, v_proxy_245, v_prog_240, v_clock_241, v_ex_242})));
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_port_244 = heff_env(self)[1];
  V v_wanted_243 = heff_env(self)[2];
  V v_proxy_245 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_ex_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam1, 1, 8, (V[]){v_hd_248, v_k_249, v_port_244, v_wanted_243, v_proxy_245, v_prog_240, v_clock_241, v_ex_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str0, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str3, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str6, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str8, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str9, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str10, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str11, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str12, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str13, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str14, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str15, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str16, 1, "/");
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam3, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam4(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam4, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_entry, 4, 0};

V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537(V v_web_240, V v_st_241, V v_x2_242, V v_req_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nothing: {
    heff_drop(v_web_240);
    V v_target_244 = heff_get_n(v_req_243, 1, 6);
    V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str0), v_target_244, MK_INT(0LL), 5);
    V v_path_247;
    if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
      heff_drop(v_j_245);
      v_path_247 = v_target_244;
    } else {
      v_path_247 = heff_strSlice(v_target_244, MK_INT(0LL), v_j_245);
    }
    V v_s_248 = heff_strSlice(heff_dup(v_path_247), MK_INT(1LL), heff_strLength(v_path_247));
    V v_t_249 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str1); V a_1 = v_s_248; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str2), v_s_248, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_248); r_; });
    HEFF_LAST return g_heff_2ebuild_2edev_2eanswer(heff_dup(g_co_2e_3c_2b_3e_24s1957723276x2068325901_get()), ((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam0_clo), v_st_241, v_t_249);
  }
  case TAG_Just: {
    V v_to_2417 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    V v_target_2418 = heff_dup(heff_rfield(v_req_243, 1));
    V v_j_2419 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str3), v_target_2418, MK_INT(0LL), 5);
    V v_path_2421;
    if (heff_intLt_c_lent(v_j_2419, MK_INT(0LL), 2)) {
      heff_drop(v_j_2419);
      v_path_2421 = v_target_2418;
    } else {
      v_path_2421 = heff_strSlice(v_target_2418, MK_INT(0LL), v_j_2419);
    }
    V v_s_2422 = heff_strSlice(heff_dup(v_path_2421), MK_INT(1LL), heff_strLength(v_path_2421));
    V v_x1_2423 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str4); V a_1 = v_s_2422; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str5), v_s_2422, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2422); r_; });
    V v_t_2424 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str6)));
    V v_t_2427;
    switch (heff_tag_of(v_x1_2423)) {
    case TAG_Nil: {
      v_t_2427 = ((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_x1_2423, 0);
      heff_take_n(v_x1_2423, 1ULL, 2);
      v_t_2427 = v_x_2425;
      break;
    }
    default: heff_nomatch(v_x1_2423);
    }
    V v_t_2428 = (g_std_2epath_2eparse(v_st_241, v_t_2427));
    V v_t_2429 = (g_std_2epath_2ejoin(v_t_2424, v_t_2428));
    V v_s_2430 = ({ V a_0 = v_st_241; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2429); r_; });
    V v_t_2431 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2430; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2432 = ({ V a_0 = v_t_2431; V r_ = (g_std_2efilesystem_2eisDirectory_24s742424059x1763865794(a_0)); heff_drop(v_t_2431); r_; });
    return heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam1, 2, 5, (V[]){v_c_2432, v_req_243, heff_dup(v_st_241), v_web_240, v_to_2417});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam0(V self, V *args) {
  V v_a_2410 = args[0];
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2416});
}
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam3(V self, V *args) {
  V v_a_2442 = args[0];
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2448});
}
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam4(V self, V *args) {
  V v_a_2463 = args[0];
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2469});
}
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam2(V self, V *args) {
  V v_x_2435 = args[0];
  V v_req_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_hd_2433 = heff_env(self)[2];
  V v_k_2434 = heff_env(self)[3];
  V v_web_240 = heff_env(self)[4];
  V v_to_2417 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2435) == NTAG(TAG_True))) {
    heff_drop(v_x_2435);
    heff_drop(v_web_240);
    heff_drop(v_to_2417);
    V v_target_2436 = heff_get_n(v_req_243, 1, 6);
    V v_j_2437 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str8), v_target_2436, MK_INT(0LL), 5);
    V v_path_2439;
    if (heff_intLt_c_lent(v_j_2437, MK_INT(0LL), 2)) {
      heff_drop(v_j_2437);
      v_path_2439 = v_target_2436;
    } else {
      v_path_2439 = heff_strSlice(v_target_2436, MK_INT(0LL), v_j_2437);
    }
    V v_s_2440 = heff_strSlice(heff_dup(v_path_2439), MK_INT(1LL), heff_strLength(v_path_2439));
    V v_t_2441 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str9); V a_1 = v_s_2440; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str10), v_s_2440, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2440); r_; });
    V v_t_2449 = ({ V a_0 = heff_dup(g_co_2e_3c_2b_3e_24s1957723276x2068325901_get()); V a_1 = ((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam3_clo); V a_2 = v_st_241; V a_3 = v_t_2441; V r_ = (g_heff_2ebuild_2edev_2eanswer(a_0, a_1, a_2, a_3)); heff_drop(v_st_241); r_; });
    V f_ = v_t_2449;
    heff_room[0] = v_hd_2433;
    heff_room[1] = v_k_2434;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2435);
    V v_target_2450 = heff_dup(heff_rfield(v_req_243, 1));
    V v_j_2451 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str11), v_target_2450, MK_INT(0LL), 5);
    V v_path_2453;
    if (heff_intLt_c_lent(v_j_2451, MK_INT(0LL), 2)) {
      heff_drop(v_j_2451);
      v_path_2453 = v_target_2450;
    } else {
      v_path_2453 = heff_strSlice(v_target_2450, MK_INT(0LL), v_j_2451);
    }
    V v_s_2454 = heff_strSlice(heff_dup(v_path_2453), MK_INT(1LL), heff_strLength(v_path_2453));
    V v_t_2455 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str12); V a_1 = v_s_2454; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str13), v_s_2454, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2454); r_; });
    V v_t_2456 = ({ V a_0 = v_t_2455; V r_ = (g_heff_2ebuild_2edev_2eownPath(a_0)); heff_drop(v_t_2455); r_; });
    if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
      heff_drop(v_web_240);
      heff_drop(v_to_2417);
      heff_drop(v_t_2456);
      V v_target_2457 = heff_get_n(v_req_243, 1, 6);
      V v_j_2458 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str14), v_target_2457, MK_INT(0LL), 5);
      V v_path_2460;
      if (heff_intLt_c_lent(v_j_2458, MK_INT(0LL), 2)) {
        heff_drop(v_j_2458);
        v_path_2460 = v_target_2457;
      } else {
        v_path_2460 = heff_strSlice(v_target_2457, MK_INT(0LL), v_j_2458);
      }
      V v_s_2461 = heff_strSlice(heff_dup(v_path_2460), MK_INT(1LL), heff_strLength(v_path_2460));
      V v_t_2462 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str15); V a_1 = v_s_2461; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_str16), v_s_2461, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2461); r_; });
      V v_t_2470 = ({ V a_0 = heff_dup(g_co_2e_3c_2b_3e_24s1957723276x2068325901_get()); V a_1 = ((V)&g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam4_clo); V a_2 = v_st_241; V a_3 = v_t_2462; V r_ = (g_heff_2ebuild_2edev_2eanswer(a_0, a_1, a_2, a_3)); heff_drop(v_st_241); r_; });
      V f_ = v_t_2470;
      heff_room[0] = v_hd_2433;
      heff_room[1] = v_k_2434;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_st_241);
      heff_drop(v_t_2456);
      return (g_heff_2ebuild_2edev_2eforwarded_24s999642276x849785444(v_web_240, v_to_2417, v_req_243, v_hd_2433, v_k_2434));
    }
  }
}
V g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam1(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_c_2432 = heff_env(self)[0];
  V v_req_243 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_web_240 = heff_env(self)[3];
  V v_to_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2432;
  args[0] = heff_dup(v_hd_2433);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s603474979x1470581537_lam2, 1, 6, (V[]){v_req_243, v_st_241, v_hd_2433, v_k_2434, v_web_240, v_to_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}