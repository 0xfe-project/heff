// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Directory 35277
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_Listen 55096
#define TAG_NotRun 12703
#define TAG_Other 45236
#define TAG_PathStatus 29154
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Regular 40886
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_body 9524841
#define LBL_builds 569118448
#define LBL_code 9554612
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_headers 1027165638
#define LBL_kind 9787483
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_pages 307784670
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_running 1782641667
#define LBL_status 1054660381
#define LBL_target 1066236092
#define LBL_wanted 1152016858
static uint32_t shape_running__pages__builds__wanted__port__proxy[] = {LBL_running, LBL_pages, LBL_builds, LBL_wanted, LBL_port, LBL_proxy};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
V g_co_2eop_24s162716155x1210144019(V, V, V);
V g_co_2eop_24s162716155x1210144019_entry(V self, V *a);
extern Clo g_co_2eop_24s162716155x1210144019_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_green_2escheduledWith_24s323844761x1686441296(V, V, V, V);
V g_green_2escheduledWith_24s323844761x1686441296_entry(V self, V *a);
extern Clo g_green_2escheduledWith_24s323844761x1686441296_clo;
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388(V, V);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_clo;
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473(V, V, V, V, V);
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_clo;
V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655(V, V, V);
V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_clo;
V g_heff_2ebuild_2edev_2efileAnswer(V, V);
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efileAnswer_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_clo;
V g_heff_2ebuild_2edev_2eindexAnswer(V);
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eindexAnswer_clo;
V g_heff_2ebuild_2edev_2emadePage(V);
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2emadePage_clo;
V g_heff_2ebuild_2edev_2eownPath(V);
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eownPath_clo;
V g_heff_2ebuild_2edev_2epageAnswer(V, V, V);
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epageAnswer_clo;
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_clo;
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452(V, V, V, V, V);
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_clo;
V g_heff_2ebuild_2edev_2erelayed(V, V);
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erelayed_clo;
V g_heff_2ebuild_2edev_2ereloadScript_get(void);
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802(V, V, V, V);
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_clo;
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_clo;
V g_list_2eall_24s1579400704x1789597964(V);
V g_list_2eall_24s1579400704x1789597964_entry(V self, V *a);
extern Clo g_list_2eall_24s1579400704x1789597964_clo;
V g_list_2efilter_24s514881809x1990693194(V, V, V, V, V, V);
V g_list_2efilter_24s514881809x1990693194_entry(V self, V *a);
extern Clo g_list_2efilter_24s514881809x1990693194_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2emap_24f336527456x1519848451(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f336527456x1519848451_entry(V self, V *a);
extern Clo g_list_2emap_24f336527456x1519848451_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1684451694x373462712(V, V, V);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1684451694x373462712_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s1684451694x373462712_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);
V g_std_2ereactor_2eoutside_24s626113845x1580845692(V);
V g_std_2ereactor_2eoutside_24s626113845x1580845692_entry(V self, V *a);
extern Clo g_std_2ereactor_2eoutside_24s626113845x1580845692_clo;
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str0, 9, "</script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str1, 10, "  }, 500);");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str2, 5, "})();");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str3, 98, "      .then(function (t) { if (seen === null) seen = t; else if (t !== seen) location.reload(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str4, 29, "      .catch(function () {});");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str5, 48, "    fetch(\"/.heff/built\", { cache: \"no-store\" })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str6, 46, "      .then(function (r) { return r.text(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str7, 18, "  var seen = null;");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str8, 27, "  setInterval(function () {");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str10, 8, "<script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str11, 14, "(function () {");

static V g_heff_2ebuild_2edev_2ereloadScript_val;
static HEFF_ONCE g_heff_2ebuild_2edev_2ereloadScript_st;
static V g_heff_2ebuild_2edev_2ereloadScript_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str9); V a_1 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str10); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str11), v_t_244}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2edev_2ereloadScript_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2edev_2ereloadScript_st)) return g_heff_2ebuild_2edev_2ereloadScript_val;
  return heff_global(&g_heff_2ebuild_2edev_2ereloadScript_val, &g_heff_2ebuild_2edev_2ereloadScript_st, g_heff_2ebuild_2edev_2ereloadScript_init);
}
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str2, 3, "no ");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str4, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str5, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str6, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2efileAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efileAnswer_entry, 2, 0};

V g_heff_2ebuild_2edev_2efileAnswer(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str0), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str1)}), NTAG(TAG_Nil)});
    V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2efileAnswer_str2), heff_strAppend(v_p_240, ((V)&g_heff_2ebuild_2edev_2efileAnswer_str3)));
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_242, heff_bytesFromString(v_t_243)});
  }
  case TAG_Just: {
    V v_text_244 = heff_field(v_x2_241, 0);
    V v_kind_245 = ({ V a_0 = v_p_240; V r_ = (g_heff_2ebuild_2edev_2etypeOf(a_0)); heff_drop(v_p_240); r_; });
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str4), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str5)}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str6), v_kind_245}), v_t_246});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_247, heff_bytesFromString(heff_dup(v_text_244))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2efileAnswer(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str1, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str2, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str3, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str4, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str5, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str6, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str7, 8, "no page ");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str9, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str10, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str11, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str12, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str13, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2epageAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epageAnswer_entry, 3, 0};

V g_heff_2ebuild_2edev_2epageAnswer(V v_name_240, V v_built_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    if ((heff_dup(v_built_241) == NTAG(TAG_True))) {
      V v_kind_243 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str0); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
      V v_html_244 = (g_heff_2ebuild_2edev_2emadePage(v_name_240));
      V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str1), v_html_244, MK_INT(0LL), 5);
      V v_text_248;
      if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
        heff_drop(v_j_245);
        v_text_248 = heff_strAppend(v_html_244, heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
      } else {
        V v_t_247 = heff_strSlice(heff_dup(v_html_244), heff_dup(v_j_245), heff_strLength_lent(v_html_244, 0));
        v_text_248 = heff_strAppend(heff_strSlice(v_html_244, MK_INT(0LL), v_j_245), heff_strAppend(heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), v_t_247));
      }
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str2), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str3)}), NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str4), v_kind_243}), v_t_249});
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2410, heff_bytesFromString(v_text_248)});
    } else {
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str5), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str6)}), NTAG(TAG_Nil)});
      V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str7), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2edev_2epageAnswer_str8)));
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2411, heff_bytesFromString(v_t_2412)});
    }
  }
  case TAG_Just: {
    V v_html_2413 = heff_field(v_x3_242, 0);
    heff_drop(v_name_240);
    V v_kind_2414 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str9); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
    V v_j_2415 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str10), v_html_2413, MK_INT(0LL), 5);
    V v_text_2418;
    if (heff_intLt_c_lent(v_j_2415, MK_INT(0LL), 2)) {
      heff_drop(v_j_2415);
      v_text_2418 = heff_strAppend(heff_dup(v_html_2413), heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
    } else {
      V v_t_2417 = heff_strSlice(heff_dup(v_html_2413), heff_dup(v_j_2415), heff_strLength_lent(v_html_2413, 0));
      v_text_2418 = heff_strAppend(heff_strSlice_lent(v_html_2413, MK_INT(0LL), v_j_2415, 6), heff_strAppend(heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), v_t_2417));
    }
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str11), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str12)}), NTAG(TAG_Nil)});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str13), v_kind_2414}), v_t_2419});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2420, heff_bytesFromString(v_text_2418)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2edev_2epageAnswer(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str1, 4, "<ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str2, 23, "<title>heff dev</title>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str3, 18, "<h1>the pages</h1>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str4, 14, "<li><a href=\"/");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str5, 3, "/\">");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str6, 9, "</a></li>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str7, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str8, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str9, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str10, 5, "</ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str11, 15, "<!doctype html>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str14, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str15, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str16, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2eindexAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eindexAnswer_entry, 1, 0};

V g_heff_2ebuild_2edev_2eindexAnswer(V v_found_240) {
top: ;
  V v_kind_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str0); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str1), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str3), v_t_242})});
  V v_t_245;
  switch (heff_tag_of(v_found_240)) {
  case TAG_Nothing: {
    v_t_245 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_found_240, 0);
    v_t_245 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_found_240);
  }
  V v_t_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str4); V b_1 = MK_INT(0LL); V a_2 = MK_INT(3LL); V a_3 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str5); V b_4 = MK_INT(0LL); V a_5 = MK_INT(3LL); V a_6 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str6); V b_7 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str7); V b_8 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str8); V b_9 = MK_INT(0LL); V b_10 = MK_INT(1LL); V b_11 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str9); V a_12 = v_t_245; V r_ = (g_list_2emap_24f336527456x1519848451(a_0, b_1, a_2, a_3, b_4, a_5, a_6, b_7, b_8, b_9, b_10, b_11, a_12)); heff_drop(b_1); heff_drop(b_4); heff_drop(b_7); heff_drop(b_8); heff_drop(b_9); heff_drop(b_10); heff_drop(b_11); r_; });
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), NTAG(TAG_Nil)});
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str10), v_t_247})));
  V v_xs_249 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str11), v_t_243}), v_t_248));
  V v_text_2412;
  switch (heff_tag_of(v_xs_249)) {
  case TAG_Nil: {
    v_text_2412 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_xs_249, 0);
    V v_xs_2411 = heff_field(v_xs_249, 1);
    heff_take_n(v_xs_249, 3ULL, 2);
    v_text_2412 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str13); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_xs_249);
  }
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str14), ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str15)}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str16), v_kind_241}), v_t_2413});
  return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2414, heff_bytesFromString(v_text_2412)});
}
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eindexAnswer(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str2, 2, ") ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str3, 7, "curl: (");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str6, 23, "heff dev: nothing from ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str7, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str8, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str9, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str10, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str11, 10, "keep-alive");
Clo g_heff_2ebuild_2edev_2erelayed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erelayed_entry, 2, 0};

V g_heff_2ebuild_2edev_2erelayed(V v_to_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Left: {
    V v_err_242 = heff_field(v_x2_241, 0);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erelayed_str0), ((V)&g_heff_2ebuild_2edev_2erelayed_str1)}), NTAG(TAG_Nil)});
    V v_t_244 = heff_intShow(heff_dup(heff_rfield(v_err_242, 0)));
    V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str2), heff_dup(heff_rfield(v_err_242, 1)));
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str3), heff_strAppend(v_t_244, v_t_245));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str4), heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2edev_2erelayed_str5)));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str6), heff_strAppend(v_to_240, v_t_247));
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(502LL), v_t_243, heff_bytesFromString(v_t_248)});
  }
  case TAG_Right: {
    V v_res_249 = heff_field(v_x2_241, 0);
    heff_drop(v_to_240);
    V v_t_2410 = (g_list_2efilter_24s514881809x1990693194(((V)&g_heff_2ebuild_2edev_2erelayed_str7), ((V)&g_heff_2ebuild_2edev_2erelayed_str8), ((V)&g_heff_2ebuild_2edev_2erelayed_str9), ((V)&g_heff_2ebuild_2edev_2erelayed_str10), ((V)&g_heff_2ebuild_2edev_2erelayed_str11), heff_dup(heff_rfield(v_res_249, 1))));
    return heff_rec_n(3, shape_status__headers__body, (V[]){heff_dup(heff_rfield(v_res_249, 0)), v_t_2410, heff_dup(heff_rfield(v_res_249, 2))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2erelayed(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_str0, 52, "heff dev: not built; built again at the next change\012");
V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_entry, 3, 0};

V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655(V v_r_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Write, 2, (V[]){heff_dup(heff_rfield(v_r_240, 1)), NTAG(TAG_MkUnit)});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  HEFF_LAST return g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_248}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_lam0, 1, 3, (V[]){v_r_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_str0), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_249);
  V v_t_2410 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_r_240, 2, 3), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_lam1, 1, 2, (V[]){v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_str0, 8, "building");
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_str1, 5, "build");
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam0, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam2, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam4(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam4, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_entry, 5, 0};

V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452(V v_prog_240, V v_st_241, V v_d_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s94900133x232571340(v_t_2411, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam1, 1, 5, (V[]){v_prog_240, v_hd_243, heff_dup(v_st_241), v_d_242, v_k_244})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam4(V self, V *args) {
  V v_r_2417 = args[0];
  return v_r_2417;
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam7(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V f_ = v_k_244;
  args[0] = v_d_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_dup(heff_rfield(v_x_2419, 0));
  V v_t_2426;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Exited: {
    V v_n_2424 = heff_field(v_t_2423, 0);
    heff_take_n(v_t_2423, 1ULL, 1);
    v_t_2426 = heff_intEq(v_n_2424, MK_INT(0LL));
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2423, 0ULL, 1);
    v_t_2426 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2426 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2426 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2419, 3);
    heff_drop(v_t_2426);
    return ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_d_242; V a_3 = v_hd_243; V a_4 = v_k_244; V r_ = (g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_241); r_; });
  } else {
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    heff_drop(v_t_2426);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655(v_x_2419, v_hd_243, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam7, 1, 2, (V[]){v_k_244, v_d_242})));
  }
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2420}));
  return (g_co_2eop_24s94900133x232571340(v_t_2421, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam6, 1, 6, (V[]){v_x_2419, v_prog_240, v_st_241, v_d_242, v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_str1), NTAG(TAG_Nil)});
  V v_t_2418 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2415), v_x_2412, v_t_2416, ((V)&g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam4_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2418, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam5, 1, 6, (V[]){v_x_2415, v_prog_240, v_hd_243, v_st_241, v_d_242, v_k_244})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam2_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2414, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam3, 1, 6, (V[]){v_prog_240, v_x_2412, v_hd_243, v_st_241, v_d_242, v_k_244})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str2, 59, "heff dev: no package.hf here: run it at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str5, 4, "8000");
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam0, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam2, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_entry, 7, 0};

V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739(V v_prog_240, V v_clock_241, V v_wanted_242, V v_port_243, V v_proxy_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str0), ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam1, 1, 7, (V[]){v_hd_245, v_k_246, heff_dup(v_port_243), v_wanted_242, v_proxy_244, v_prog_240, v_clock_241})));
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam0(V self, V *args) {
  V v_t_247 = args[0];
  return v_t_247;
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  return v_s_2414;
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_hd_245, v_k_246));
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_st_2423 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_x_2441 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_prog_240; V a_1 = v_st_2423; V a_2 = v_clock_241; V a_3 = v_st_2423; V a_4 = heff_dup(g_heff_2ebuild_2ewatch_2eproject_get()); V a_5 = v_x_2441; V a_6 = v_x_2445; V a_7 = v_hd_245; V a_8 = v_k_246; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_st_2423); heff_drop(v_x_2441); heff_drop(v_k_246); r_; });
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_port_243 = heff_env(self)[0];
  V v_wanted_242 = heff_env(self)[1];
  V v_proxy_244 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_st_2423 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_clock_241 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2441;
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Nil: {
    v_x_2441 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2439 = heff_field(v_x_2438, 0);
    V v_xs_2440 = heff_field(v_x_2438, 1);
    heff_take_n(v_x_2438, 3ULL, 2);
    v_x_2441 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str4); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
    break;
  }
  default: heff_nomatch(v_x_2438);
  }
  V v_t_2443;
  switch (heff_tag_of(v_port_243)) {
  case TAG_Nothing: {
    v_t_2443 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str5);
    break;
  }
  case TAG_Just: {
    V v_x_2442 = heff_field(v_port_243, 0);
    heff_take_n(v_port_243, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_port_243);
  }
  V v_t_2444 = heff_rec_n(6, shape_running__pages__builds__wanted__port__proxy, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nothing), MK_INT(0LL), v_wanted_242, v_t_2443, v_proxy_244});
  return ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_2423; V a_2 = v_t_2444; V a_3 = heff_dup(v_hd_245); V a_4 = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam6, 1, 6, (V[]){v_prog_240, heff_dup(v_st_2423), v_clock_241, v_x_2441, v_hd_245, v_k_246}); V r_ = (g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_2423); r_; });
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_port_243 = heff_env(self)[3];
  V v_wanted_242 = heff_env(self)[4];
  V v_proxy_244 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_clock_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_st_2423;
  if (heff_strEq_c(v_x_2421, ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str1))) {
    v_st_2423 = NTAG(TAG_Windows);
  } else {
    v_st_2423 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    heff_drop(v_port_243);
    heff_drop(v_wanted_242);
    heff_drop(v_proxy_244);
    heff_drop(v_prog_240);
    heff_drop(v_clock_241);
    heff_drop(v_st_2423);
    V v_t_2424 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str2), NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam4, 1, 2, (V[]){v_hd_245, v_k_246})));
  }
  case TAG_Just: {
    heff_take_n(v_x_2413, 0ULL, 1);
    return ({ V a_0 = v_st_2423; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(g_heff_2ebuild_2ewatch_2eproject_get()); V a_3 = heff_dup(v_hd_245); V a_4 = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam5, 1, 8, (V[]){v_port_243, v_wanted_242, v_proxy_244, v_prog_240, heff_dup(v_st_2423), v_hd_245, v_clock_241, v_k_246}); V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_2423); r_; });
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  V v_port_243 = heff_env(self)[2];
  V v_wanted_242 = heff_env(self)[3];
  V v_proxy_244 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_clock_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s94900133x232571340(v_t_2420, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam3, 1, 8, (V[]){v_x_2413, v_hd_245, v_k_246, v_port_243, v_wanted_242, v_proxy_244, v_prog_240, v_clock_241})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str2, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str3, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str6, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str8, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str9, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str10, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str11, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str12, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str13, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str14, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str15, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str16, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str17, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str18, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str19, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str21, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str22, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str23, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str24, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str25, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str26, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str27, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str28, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str29, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str31, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str32, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str33, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str34, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str35, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str36, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str37, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str38, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str39, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str40, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str41, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str42, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str43, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str44, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str45, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str46, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str47, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str48, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str49, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str50, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str51, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str52, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str53, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str54, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str55, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str56, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str57, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str58, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str59, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str60, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str61, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str62, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str63, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str64, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str65, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str66, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str67, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str68, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str69, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str70, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str71, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str72, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str73, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str74, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str75, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str76, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str77, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str78, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str79, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str80, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str81, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str82, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str83, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str84, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str85, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str86, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str87, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str88, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str89, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str90, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str91, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str92, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str93, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str94, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str95, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str96, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str97, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str98, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str99, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str100, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str101, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str102, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str103, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str104, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str105, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str106, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str107, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str108, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str109, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str110, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str111, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str112, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str113, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str114, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str115, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str116, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str117, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str118, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str119, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str120, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str121, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str122, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str123, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str124, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str125, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str126, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str127, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str128, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str129, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str130, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str131, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str132, 1, "/");
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam0, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam3, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam5(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam5, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam7(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam7, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam11(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam11, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam14(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam14, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam16(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam16, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam18(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam18, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam20(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam20, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam21(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam19(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam22(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam24(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam24, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam25(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam23(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam26(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam26, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam28(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam28, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam29(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam27(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam30(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam32(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam32, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam33(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam31(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam35(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam35, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam36(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam34(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam38(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam38, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam40(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam40, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam41(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam39(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam37(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam42(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam42, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam44(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam44_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam44, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam45(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam43(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam46(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam48(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam48_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam48, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam49(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam47(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam50(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam50_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam50, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam52(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam52_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam52, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam53(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam51(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam54(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam56(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam56_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam56, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam57(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam55(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam58(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam60(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam60_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam60, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam62(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam62_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam62, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam63(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam61(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam59(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam64(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam64_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam64, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam66(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam66_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam66, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam67(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam65(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam68(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam70(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam70_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam70, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam71(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam69(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam72(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam72_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam72, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam74(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam74_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam74, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam75(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam73(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam76(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam78(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam78_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam78, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam79(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam77(V self, V *args);
Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_entry, 2, 0};

V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    V v_x22_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str3), 2)) {
      switch (heff_tag_of(v_x22_247)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam1, 2, 1, (V[]){v_x21_246});
      }
      case TAG_Cons: {
        V v_x221_2414 = heff_dup(heff_field(v_x22_247, 0));
        V v_x222_2415 = heff_dup(heff_field(v_x22_247, 1));
        if (heff_strEq_c_lent(v_x221_2414, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str8), 2)) {
          heff_drop(v_x221_2414);
          switch (heff_tag_of(v_x222_2415)) {
          case TAG_Nil: {
            heff_drop(v_x21_246);
            heff_drop_tag(v_x22_247, 2);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            V v_t_2417 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str9), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str10)));
            V v_path_2418 = (g_std_2epath_2ejoin(v_st_240, v_t_2417, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str11)));
            return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam2, 2, 1, (V[]){v_path_2418});
          }
          case TAG_Cons: {
            heff_take_n(v_x222_2415, 0ULL, 2);
            V v_x1_2437 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            V v_t_2438 = heff_bool(!(heff_dup(v_x1_2437) == NTAG(TAG_True)));
            heff_drop(v_x1_2437);
            if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
              heff_drop(v_x21_246);
              heff_drop_tag(v_x22_247, 2);
              heff_drop(v_t_2438);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam5_clo);
            } else {
              heff_drop(v_t_2438);
              V v_t_2445;
              switch (heff_tag_of(v_x22_247)) {
              case TAG_Nil: {
                v_t_2445 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str20);
                break;
              }
              case TAG_Cons: {
                V v_x_2443 = heff_dup(heff_field(v_x22_247, 0));
                V v_xs_2444 = heff_dup(heff_field(v_x22_247, 1));
                v_t_2445 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str21); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
                break;
              }
              default: heff_nomatch(v_x22_247);
              }
              if (heff_strEq_c(v_t_2445, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str22)))) {
                heff_drop_tag(v_x22_247, 2);
                V v_t_2447 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str23), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str24)));
                V v_path_2448 = (g_std_2epath_2ejoin(v_st_240, v_t_2447, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str25))));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam6, 2, 2, (V[]){v_path_2448, v_x21_246});
              } else {
                V v_t_2460 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str27), v_x21_246));
                V v_path_2463 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam9, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_2460, v_x22_247));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam10, 2, 2, (V[]){v_path_2463, v_x22_247});
              }
            }
          }
          default: return heff_nomatch(v_x222_2415);
          }
        } else {
          if (heff_strEq_c(v_x221_2414, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str30))) {
            switch (heff_tag_of(v_x222_2415)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_247, 2);
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              V v_t_2479 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str31), heff_dup(v_x21_246)));
              V v_path_2480 = (g_std_2epath_2ejoin(v_st_240, v_t_2479, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str32)));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam13, 2, 3, (V[]){v_path_2480, heff_dup(v_st_240), v_x21_246});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_2415, 0ULL, 2);
              V v_x1_24109 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              V v_t_24110 = heff_bool(!(heff_dup(v_x1_24109) == NTAG(TAG_True)));
              heff_drop(v_x1_24109);
              if ((heff_dup(v_t_24110) == NTAG(TAG_True))) {
                heff_drop(v_x21_246);
                heff_drop_tag(v_x22_247, 2);
                heff_drop(v_t_24110);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam18_clo);
              } else {
                heff_drop(v_t_24110);
                V v_t_24117;
                switch (heff_tag_of(v_x22_247)) {
                case TAG_Nil: {
                  v_t_24117 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str39);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24115 = heff_dup(heff_field(v_x22_247, 0));
                  V v_xs_24116 = heff_dup(heff_field(v_x22_247, 1));
                  v_t_24117 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str40); V a_1 = v_x_24115; V a_2 = v_xs_24116; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24116); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_247);
                }
                if (heff_strEq_c(v_t_24117, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str41)))) {
                  heff_drop_tag(v_x22_247, 2);
                  V v_t_24119 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str42), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str43)));
                  V v_path_24120 = (g_std_2epath_2ejoin(v_st_240, v_t_24119, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str44))));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam19, 2, 2, (V[]){v_path_24120, v_x21_246});
                } else {
                  V v_t_24132 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str46), v_x21_246));
                  V v_path_24135 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam22, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24132, v_x22_247));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam23, 2, 2, (V[]){v_path_24135, v_x22_247});
                }
              }
            }
            default: return heff_nomatch(v_x222_2415);
            }
          } else {
            heff_drop(v_x222_2415);
            V v_x1_24150 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            V v_t_24151 = heff_bool(!(heff_dup(v_x1_24150) == NTAG(TAG_True)));
            heff_drop(v_x1_24150);
            if ((heff_dup(v_t_24151) == NTAG(TAG_True))) {
              heff_drop(v_x21_246);
              heff_drop_tag(v_x22_247, 2);
              heff_drop(v_t_24151);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam26_clo);
            } else {
              heff_drop(v_t_24151);
              V v_t_24158;
              switch (heff_tag_of(v_x22_247)) {
              case TAG_Nil: {
                v_t_24158 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str52);
                break;
              }
              case TAG_Cons: {
                V v_x_24156 = heff_dup(heff_field(v_x22_247, 0));
                V v_xs_24157 = heff_dup(heff_field(v_x22_247, 1));
                v_t_24158 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str53); V a_1 = v_x_24156; V a_2 = v_xs_24157; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24157); r_; });
                break;
              }
              default: heff_nomatch(v_x22_247);
              }
              if (heff_strEq_c(v_t_24158, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str54)))) {
                heff_drop_tag(v_x22_247, 2);
                V v_t_24160 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str55), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str56)));
                V v_path_24161 = (g_std_2epath_2ejoin(v_st_240, v_t_24160, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str57))));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam27, 2, 2, (V[]){v_path_24161, v_x21_246});
              } else {
                V v_t_24173 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str59), v_x21_246));
                V v_path_24176 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam30, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24173, v_x22_247));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam31, 2, 2, (V[]){v_path_24176, v_x22_247});
              }
            }
          }
        }
      }
      default: return heff_nomatch(v_x22_247);
      }
    } else {
      if (heff_strEq_c_lent(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str62), 2)) {
        switch (heff_tag_of(v_x22_247)) {
        case TAG_Nil: {
          heff_drop(v_x21_246);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          V v_path_24192 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str63), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str64)));
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam34, 2, 1, (V[]){v_path_24192});
        }
        case TAG_Cons: {
          V v_x221_24204 = heff_dup(heff_field(v_x22_247, 0));
          V v_x222_24205 = heff_dup(heff_field(v_x22_247, 1));
          if (heff_strEq_c(v_x221_24204, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str65))) {
            switch (heff_tag_of(v_x222_24205)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_247, 2);
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              V v_t_24207 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str66), heff_dup(v_x21_246)));
              V v_path_24208 = (g_std_2epath_2ejoin(v_st_240, v_t_24207, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str67)));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam37, 2, 3, (V[]){v_path_24208, heff_dup(v_st_240), v_x21_246});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24205, 0ULL, 2);
              V v_x1_24237 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              V v_t_24238 = heff_bool(!(heff_dup(v_x1_24237) == NTAG(TAG_True)));
              heff_drop(v_x1_24237);
              if ((heff_dup(v_t_24238) == NTAG(TAG_True))) {
                heff_drop(v_x21_246);
                heff_drop_tag(v_x22_247, 2);
                heff_drop(v_t_24238);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam42_clo);
              } else {
                heff_drop(v_t_24238);
                V v_t_24245;
                switch (heff_tag_of(v_x22_247)) {
                case TAG_Nil: {
                  v_t_24245 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str74);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24243 = heff_dup(heff_field(v_x22_247, 0));
                  V v_xs_24244 = heff_dup(heff_field(v_x22_247, 1));
                  v_t_24245 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str75); V a_1 = v_x_24243; V a_2 = v_xs_24244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24244); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_247);
                }
                if (heff_strEq_c(v_t_24245, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str76)))) {
                  heff_drop_tag(v_x22_247, 2);
                  V v_t_24247 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str77), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str78)));
                  V v_path_24248 = (g_std_2epath_2ejoin(v_st_240, v_t_24247, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str79))));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam43, 2, 2, (V[]){v_path_24248, v_x21_246});
                } else {
                  V v_t_24260 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str81), v_x21_246));
                  V v_path_24263 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam46, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24260, v_x22_247));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam47, 2, 2, (V[]){v_path_24263, v_x22_247});
                }
              }
            }
            default: return heff_nomatch(v_x222_24205);
            }
          } else {
            heff_drop(v_x222_24205);
            V v_x1_24278 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            V v_t_24279 = heff_bool(!(heff_dup(v_x1_24278) == NTAG(TAG_True)));
            heff_drop(v_x1_24278);
            if ((heff_dup(v_t_24279) == NTAG(TAG_True))) {
              heff_drop(v_x21_246);
              heff_drop_tag(v_x22_247, 2);
              heff_drop(v_t_24279);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam50_clo);
            } else {
              heff_drop(v_t_24279);
              V v_t_24286;
              switch (heff_tag_of(v_x22_247)) {
              case TAG_Nil: {
                v_t_24286 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str87);
                break;
              }
              case TAG_Cons: {
                V v_x_24284 = heff_dup(heff_field(v_x22_247, 0));
                V v_xs_24285 = heff_dup(heff_field(v_x22_247, 1));
                v_t_24286 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str88); V a_1 = v_x_24284; V a_2 = v_xs_24285; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24285); r_; });
                break;
              }
              default: heff_nomatch(v_x22_247);
              }
              if (heff_strEq_c(v_t_24286, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str89)))) {
                heff_drop_tag(v_x22_247, 2);
                V v_t_24288 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str90), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str91)));
                V v_path_24289 = (g_std_2epath_2ejoin(v_st_240, v_t_24288, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str92))));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam51, 2, 2, (V[]){v_path_24289, v_x21_246});
              } else {
                V v_t_24301 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str94), v_x21_246));
                V v_path_24304 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam54, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24301, v_x22_247));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam55, 2, 2, (V[]){v_path_24304, v_x22_247});
              }
            }
          }
        }
        default: return heff_nomatch(v_x22_247);
        }
      } else {
        switch (heff_tag_of(v_x22_247)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam58, 2, 1, (V[]){v_x21_246});
        }
        case TAG_Cons: {
          V v_x221_24324 = heff_dup(heff_field(v_x22_247, 0));
          V v_x222_24325 = heff_dup(heff_field(v_x22_247, 1));
          if (heff_strEq_c(v_x221_24324, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str101))) {
            switch (heff_tag_of(v_x222_24325)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_247, 2);
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              V v_t_24327 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str102), heff_dup(v_x21_246)));
              V v_path_24328 = (g_std_2epath_2ejoin(v_st_240, v_t_24327, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str103)));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam59, 2, 3, (V[]){v_path_24328, heff_dup(v_st_240), v_x21_246});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24325, 0ULL, 2);
              V v_x1_24357 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              V v_t_24358 = heff_bool(!(heff_dup(v_x1_24357) == NTAG(TAG_True)));
              heff_drop(v_x1_24357);
              if ((heff_dup(v_t_24358) == NTAG(TAG_True))) {
                heff_drop(v_x21_246);
                heff_drop_tag(v_x22_247, 2);
                heff_drop(v_t_24358);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam64_clo);
              } else {
                heff_drop(v_t_24358);
                V v_t_24365;
                switch (heff_tag_of(v_x22_247)) {
                case TAG_Nil: {
                  v_t_24365 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str110);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24363 = heff_dup(heff_field(v_x22_247, 0));
                  V v_xs_24364 = heff_dup(heff_field(v_x22_247, 1));
                  v_t_24365 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str111); V a_1 = v_x_24363; V a_2 = v_xs_24364; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24364); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_247);
                }
                if (heff_strEq_c(v_t_24365, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str112)))) {
                  heff_drop_tag(v_x22_247, 2);
                  V v_t_24367 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str113), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str114)));
                  V v_path_24368 = (g_std_2epath_2ejoin(v_st_240, v_t_24367, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str115))));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam65, 2, 2, (V[]){v_path_24368, v_x21_246});
                } else {
                  V v_t_24380 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str117), v_x21_246));
                  V v_path_24383 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam68, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24380, v_x22_247));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam69, 2, 2, (V[]){v_path_24383, v_x22_247});
                }
              }
            }
            default: return heff_nomatch(v_x222_24325);
            }
          } else {
            heff_drop(v_x222_24325);
            V v_x1_24398 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            V v_t_24399 = heff_bool(!(heff_dup(v_x1_24398) == NTAG(TAG_True)));
            heff_drop(v_x1_24398);
            if ((heff_dup(v_t_24399) == NTAG(TAG_True))) {
              heff_drop(v_x21_246);
              heff_drop_tag(v_x22_247, 2);
              heff_drop(v_t_24399);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam72_clo);
            } else {
              heff_drop(v_t_24399);
              V v_t_24406;
              switch (heff_tag_of(v_x22_247)) {
              case TAG_Nil: {
                v_t_24406 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str123);
                break;
              }
              case TAG_Cons: {
                V v_x_24404 = heff_dup(heff_field(v_x22_247, 0));
                V v_xs_24405 = heff_dup(heff_field(v_x22_247, 1));
                v_t_24406 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str124); V a_1 = v_x_24404; V a_2 = v_xs_24405; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24405); r_; });
                break;
              }
              default: heff_nomatch(v_x22_247);
              }
              if (heff_strEq_c(v_t_24406, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str125)))) {
                heff_drop_tag(v_x22_247, 2);
                V v_t_24408 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str126), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str127)));
                V v_path_24409 = (g_std_2epath_2ejoin(v_st_240, v_t_24408, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str128))));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam73, 2, 2, (V[]){v_path_24409, v_x21_246});
              } else {
                V v_t_24421 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str130), v_x21_246));
                V v_path_24424 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam76, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24421, v_x22_247));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam77, 2, 2, (V[]){v_path_24424, v_x22_247});
              }
            }
          }
        }
        default: return heff_nomatch(v_x22_247);
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str0), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str1)}), NTAG(TAG_Nil)});
  V v_t_245 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_244, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str2))});
  V f_ = v_k_243;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_x21_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_249);
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str4), heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str5)));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str6), v_t_2411}), NTAG(TAG_Nil)});
  V v_t_2413 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_2412, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str7))});
  V f_ = v_k_2410;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam3(V self, V *args) {
  V v_t_2421 = args[0];
  return v_t_2421;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_kind_2429 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str12); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str13), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str14)}), NTAG(TAG_Nil)});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str15), v_kind_2429}), v_t_2430});
  V v_t_2433;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_Nothing: {
    v_t_2433 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str16);
    break;
  }
  case TAG_Just: {
    V v_x_2432 = heff_field(v_x_2428, 0);
    heff_take_n(v_x_2428, 1ULL, 1);
    v_t_2433 = v_x_2432;
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  V v_t_2434 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2431, heff_bytesFromString(v_t_2433)});
  V f_ = v_k_2420;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_path_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2418, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam3_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s162716155x1210144019(v_t_2427, v_hd_2419, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam4, 1, 1, (V[]){v_k_2420})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam5(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  heff_drop(v_hd_2439);
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str17), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str18)}), NTAG(TAG_Nil)});
  V v_t_2442 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2441, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str19))});
  V f_ = v_k_2440;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam7(V self, V *args) {
  V v_t_2451 = args[0];
  return v_t_2451;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam8(V self, V *args) {
  V v_x_2458 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_2450 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2459 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str26)); V a_1 = v_x_2458; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2458); r_; });
  V f_ = v_k_2450;
  args[0] = v_x_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam6(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  V v_path_2448 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2448, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam7_clo)})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  return (g_co_2eop_24s162716155x1210144019(v_t_2457, v_hd_2449, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam8, 1, 2, (V[]){v_x21_246, v_k_2450})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam9(V self, V *args) {
  V v_p_2461 = args[0];
  V v_x_2462 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_2461; V a_2 = v_x_2462; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam11(V self, V *args) {
  V v_t_2466 = args[0];
  return v_t_2466;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam12(V self, V *args) {
  V v_x_2473 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_2465 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2476;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_2476 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str28);
    break;
  }
  case TAG_Cons: {
    V v_x_2474 = heff_field(v_x22_247, 0);
    V v_xs_2475 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_2476 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str29); V a_1 = v_x_2474; V a_2 = v_xs_2475; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2475); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_2477 = ({ V a_0 = v_t_2476; V a_1 = v_x_2473; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2473); r_; });
  V f_ = v_k_2465;
  args[0] = v_x_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam10(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  V v_path_2463 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2463, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam11_clo)})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})});
  return (g_co_2eop_24s162716155x1210144019(v_t_2472, v_hd_2464, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam12, 1, 2, (V[]){v_x22_247, v_k_2465})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam14(V self, V *args) {
  V v_t_2483 = args[0];
  return v_t_2483;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam16(V self, V *args) {
  V v_r_2493 = args[0];
  return v_r_2493;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam17(V self, V *args) {
  V v_x_24100 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_x_2490 = heff_env(self)[1];
  V v_k_2482 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24100)) {
  case TAG_Left: {
    heff_take_n(v_x_24100, 0ULL, 1);
    V v_x_24102 = ({ V a_0 = v_x21_246; V b_1 = NTAG(TAG_False); V a_2 = v_x_2490; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_x_2490); r_; });
    V f_ = v_k_2482;
    args[0] = v_x_24102;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_24103 = heff_field(v_x_24100, 0);
    heff_take_n(v_x_24100, 1ULL, 1);
    V v_t_24104 = heff_get_n(v_s_24103, 0, 4);
    V v_t_24105;
    switch (heff_tag_of(v_t_24104)) {
    case TAG_Regular: {
      v_t_24105 = NTAG(TAG_True);
      break;
    }
    case TAG_Directory: {
      v_t_24105 = NTAG(TAG_False);
      break;
    }
    case TAG_Link: {
      v_t_24105 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_24105 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_24104);
    }
    V v_x_24106 = ({ V a_0 = v_x21_246; V a_1 = v_t_24105; V a_2 = v_x_2490; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_t_24105); heff_drop(v_x_2490); r_; });
    V f_ = v_k_2482;
    args[0] = v_x_24106;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_24100);
  }
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam15(V self, V *args) {
  V v_x_2490 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  V v_hd_2481 = heff_env(self)[2];
  V v_k_2482 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2491 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str33), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str34)));
  V v_path_2492 = ({ V a_0 = v_st_240; V a_1 = v_t_2491; V a_2 = heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str35)); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V v_t_2494 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_path_2492, NTAG(TAG_True), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam16_clo)});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  return (g_co_2eop_24s162716155x1210144019(heff_tag_n(TAG_InR, 1, (V[]){v_t_2499}), v_hd_2481, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam17, 1, 3, (V[]){v_x21_246, v_x_2490, v_k_2482})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam13(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k_2482 = args[1];
  V v_path_2480 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x21_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2480, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam14_clo)})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})});
  return (g_co_2eop_24s162716155x1210144019(v_t_2489, heff_dup(v_hd_2481), heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam15, 1, 4, (V[]){v_st_240, v_x21_246, v_hd_2481, v_k_2482})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam18(V self, V *args) {
  V v_hd_24111 = args[0];
  V v_k_24112 = args[1];
  heff_drop(v_hd_24111);
  V v_t_24113 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str36), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str37)}), NTAG(TAG_Nil)});
  V v_t_24114 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24113, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str38))});
  V f_ = v_k_24112;
  args[0] = v_t_24114;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam20(V self, V *args) {
  V v_t_24123 = args[0];
  return v_t_24123;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam21(V self, V *args) {
  V v_x_24130 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24122 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24131 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str45)); V a_1 = v_x_24130; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24130); r_; });
  V f_ = v_k_24122;
  args[0] = v_x_24131;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam19(V self, V *args) {
  V v_hd_24121 = args[0];
  V v_k_24122 = args[1];
  V v_path_24120 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24124 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24120, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam20_clo)})});
  V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24124})});
  V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
  V v_t_24127 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24126})});
  V v_t_24128 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24127})});
  V v_t_24129 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24128})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24129, v_hd_24121, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam21, 1, 2, (V[]){v_x21_246, v_k_24122})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam22(V self, V *args) {
  V v_p_24133 = args[0];
  V v_x_24134 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24133; V a_2 = v_x_24134; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam24(V self, V *args) {
  V v_t_24138 = args[0];
  return v_t_24138;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam25(V self, V *args) {
  V v_x_24145 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24137 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24148;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24148 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str47);
    break;
  }
  case TAG_Cons: {
    V v_x_24146 = heff_field(v_x22_247, 0);
    V v_xs_24147 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24148 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str48); V a_1 = v_x_24146; V a_2 = v_xs_24147; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24147); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24149 = ({ V a_0 = v_t_24148; V a_1 = v_x_24145; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24145); r_; });
  V f_ = v_k_24137;
  args[0] = v_x_24149;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam23(V self, V *args) {
  V v_hd_24136 = args[0];
  V v_k_24137 = args[1];
  V v_path_24135 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24139 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24135, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam24_clo)})});
  V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
  V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
  V v_t_24142 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24141})});
  V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
  V v_t_24144 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24143})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24144, v_hd_24136, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam25, 1, 2, (V[]){v_x22_247, v_k_24137})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam26(V self, V *args) {
  V v_hd_24152 = args[0];
  V v_k_24153 = args[1];
  heff_drop(v_hd_24152);
  V v_t_24154 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str49), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str50)}), NTAG(TAG_Nil)});
  V v_t_24155 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24154, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str51))});
  V f_ = v_k_24153;
  args[0] = v_t_24155;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam28(V self, V *args) {
  V v_t_24164 = args[0];
  return v_t_24164;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam29(V self, V *args) {
  V v_x_24171 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24163 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24172 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str58)); V a_1 = v_x_24171; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24171); r_; });
  V f_ = v_k_24163;
  args[0] = v_x_24172;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam27(V self, V *args) {
  V v_hd_24162 = args[0];
  V v_k_24163 = args[1];
  V v_path_24161 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24165 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24161, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam28_clo)})});
  V v_t_24166 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24165})});
  V v_t_24167 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24166})});
  V v_t_24168 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24167})});
  V v_t_24169 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24168})});
  V v_t_24170 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24169})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24170, v_hd_24162, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam29, 1, 2, (V[]){v_x21_246, v_k_24163})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam30(V self, V *args) {
  V v_p_24174 = args[0];
  V v_x_24175 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24174; V a_2 = v_x_24175; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam32(V self, V *args) {
  V v_t_24179 = args[0];
  return v_t_24179;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam33(V self, V *args) {
  V v_x_24186 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24178 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24189;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24189 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str60);
    break;
  }
  case TAG_Cons: {
    V v_x_24187 = heff_field(v_x22_247, 0);
    V v_xs_24188 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24189 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str61); V a_1 = v_x_24187; V a_2 = v_xs_24188; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24188); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24190 = ({ V a_0 = v_t_24189; V a_1 = v_x_24186; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24186); r_; });
  V f_ = v_k_24178;
  args[0] = v_x_24190;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam31(V self, V *args) {
  V v_hd_24177 = args[0];
  V v_k_24178 = args[1];
  V v_path_24176 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24180 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24176, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam32_clo)})});
  V v_t_24181 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24180})});
  V v_t_24182 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24181})});
  V v_t_24183 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24182})});
  V v_t_24184 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24183})});
  V v_t_24185 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24184})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24185, v_hd_24177, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam33, 1, 2, (V[]){v_x22_247, v_k_24178})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam35(V self, V *args) {
  V v_ns_24195 = args[0];
  return v_ns_24195;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam36(V self, V *args) {
  V v_x_24202 = args[0];
  V v_k_24194 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_24203 = ({ V a_0 = v_x_24202; V r_ = (g_heff_2ebuild_2edev_2eindexAnswer(a_0)); heff_drop(v_x_24202); r_; });
  V f_ = v_k_24194;
  args[0] = v_x_24203;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam34(V self, V *args) {
  V v_hd_24193 = args[0];
  V v_k_24194 = args[1];
  V v_path_24192 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24196 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_path_24192, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam35_clo)})});
  V v_t_24197 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24196})});
  V v_t_24198 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24197})});
  V v_t_24199 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24198})});
  V v_t_24200 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24199})});
  V v_t_24201 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24200})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24201, v_hd_24193, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam36, 1, 1, (V[]){v_k_24194})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam38(V self, V *args) {
  V v_t_24211 = args[0];
  return v_t_24211;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam40(V self, V *args) {
  V v_r_24221 = args[0];
  return v_r_24221;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam41(V self, V *args) {
  V v_x_24228 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_x_24218 = heff_env(self)[1];
  V v_k_24210 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24228)) {
  case TAG_Left: {
    heff_take_n(v_x_24228, 0ULL, 1);
    V v_x_24230 = ({ V a_0 = v_x21_246; V b_1 = NTAG(TAG_False); V a_2 = v_x_24218; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_x_24218); r_; });
    V f_ = v_k_24210;
    args[0] = v_x_24230;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_24231 = heff_field(v_x_24228, 0);
    heff_take_n(v_x_24228, 1ULL, 1);
    V v_t_24232 = heff_get_n(v_s_24231, 0, 4);
    V v_t_24233;
    switch (heff_tag_of(v_t_24232)) {
    case TAG_Regular: {
      v_t_24233 = NTAG(TAG_True);
      break;
    }
    case TAG_Directory: {
      v_t_24233 = NTAG(TAG_False);
      break;
    }
    case TAG_Link: {
      v_t_24233 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_24233 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_24232);
    }
    V v_x_24234 = ({ V a_0 = v_x21_246; V a_1 = v_t_24233; V a_2 = v_x_24218; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_t_24233); heff_drop(v_x_24218); r_; });
    V f_ = v_k_24210;
    args[0] = v_x_24234;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_24228);
  }
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam39(V self, V *args) {
  V v_x_24218 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  V v_hd_24209 = heff_env(self)[2];
  V v_k_24210 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24219 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str68), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str69)));
  V v_path_24220 = ({ V a_0 = v_st_240; V a_1 = v_t_24219; V a_2 = heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str70)); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V v_t_24222 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_path_24220, NTAG(TAG_True), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam40_clo)});
  V v_t_24223 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24222})});
  V v_t_24224 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24223})});
  V v_t_24225 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24224})});
  V v_t_24226 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24225})});
  V v_t_24227 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24226})});
  return (g_co_2eop_24s162716155x1210144019(heff_tag_n(TAG_InR, 1, (V[]){v_t_24227}), v_hd_24209, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam41, 1, 3, (V[]){v_x21_246, v_x_24218, v_k_24210})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam37(V self, V *args) {
  V v_hd_24209 = args[0];
  V v_k_24210 = args[1];
  V v_path_24208 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x21_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24212 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24208, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam38_clo)})});
  V v_t_24213 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24212})});
  V v_t_24214 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24213})});
  V v_t_24215 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24214})});
  V v_t_24216 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24215})});
  V v_t_24217 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24216})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24217, heff_dup(v_hd_24209), heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam39, 1, 4, (V[]){v_st_240, v_x21_246, v_hd_24209, v_k_24210})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam42(V self, V *args) {
  V v_hd_24239 = args[0];
  V v_k_24240 = args[1];
  heff_drop(v_hd_24239);
  V v_t_24241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str71), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str72)}), NTAG(TAG_Nil)});
  V v_t_24242 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24241, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str73))});
  V f_ = v_k_24240;
  args[0] = v_t_24242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam44(V self, V *args) {
  V v_t_24251 = args[0];
  return v_t_24251;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam45(V self, V *args) {
  V v_x_24258 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24250 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24259 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str80)); V a_1 = v_x_24258; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24258); r_; });
  V f_ = v_k_24250;
  args[0] = v_x_24259;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam43(V self, V *args) {
  V v_hd_24249 = args[0];
  V v_k_24250 = args[1];
  V v_path_24248 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24252 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24248, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam44_clo)})});
  V v_t_24253 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24252})});
  V v_t_24254 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24253})});
  V v_t_24255 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24254})});
  V v_t_24256 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24255})});
  V v_t_24257 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24256})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24257, v_hd_24249, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam45, 1, 2, (V[]){v_x21_246, v_k_24250})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam46(V self, V *args) {
  V v_p_24261 = args[0];
  V v_x_24262 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24261; V a_2 = v_x_24262; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam48(V self, V *args) {
  V v_t_24266 = args[0];
  return v_t_24266;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam49(V self, V *args) {
  V v_x_24273 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24265 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24276;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24276 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str82);
    break;
  }
  case TAG_Cons: {
    V v_x_24274 = heff_field(v_x22_247, 0);
    V v_xs_24275 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24276 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str83); V a_1 = v_x_24274; V a_2 = v_xs_24275; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24275); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24277 = ({ V a_0 = v_t_24276; V a_1 = v_x_24273; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24273); r_; });
  V f_ = v_k_24265;
  args[0] = v_x_24277;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam47(V self, V *args) {
  V v_hd_24264 = args[0];
  V v_k_24265 = args[1];
  V v_path_24263 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24267 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24263, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam48_clo)})});
  V v_t_24268 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24267})});
  V v_t_24269 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24268})});
  V v_t_24270 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24269})});
  V v_t_24271 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24270})});
  V v_t_24272 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24271})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24272, v_hd_24264, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam49, 1, 2, (V[]){v_x22_247, v_k_24265})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam50(V self, V *args) {
  V v_hd_24280 = args[0];
  V v_k_24281 = args[1];
  heff_drop(v_hd_24280);
  V v_t_24282 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str84), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str85)}), NTAG(TAG_Nil)});
  V v_t_24283 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24282, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str86))});
  V f_ = v_k_24281;
  args[0] = v_t_24283;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam52(V self, V *args) {
  V v_t_24292 = args[0];
  return v_t_24292;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam53(V self, V *args) {
  V v_x_24299 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24291 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24300 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str93)); V a_1 = v_x_24299; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24299); r_; });
  V f_ = v_k_24291;
  args[0] = v_x_24300;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam51(V self, V *args) {
  V v_hd_24290 = args[0];
  V v_k_24291 = args[1];
  V v_path_24289 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24293 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24289, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam52_clo)})});
  V v_t_24294 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24293})});
  V v_t_24295 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24294})});
  V v_t_24296 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24295})});
  V v_t_24297 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24296})});
  V v_t_24298 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24297})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24298, v_hd_24290, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam53, 1, 2, (V[]){v_x21_246, v_k_24291})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam54(V self, V *args) {
  V v_p_24302 = args[0];
  V v_x_24303 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24302; V a_2 = v_x_24303; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam56(V self, V *args) {
  V v_t_24307 = args[0];
  return v_t_24307;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam57(V self, V *args) {
  V v_x_24314 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24306 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24317;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24317 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str95);
    break;
  }
  case TAG_Cons: {
    V v_x_24315 = heff_field(v_x22_247, 0);
    V v_xs_24316 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24317 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str96); V a_1 = v_x_24315; V a_2 = v_xs_24316; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24316); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24318 = ({ V a_0 = v_t_24317; V a_1 = v_x_24314; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24314); r_; });
  V f_ = v_k_24306;
  args[0] = v_x_24318;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam55(V self, V *args) {
  V v_hd_24305 = args[0];
  V v_k_24306 = args[1];
  V v_path_24304 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24308 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24304, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam56_clo)})});
  V v_t_24309 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24308})});
  V v_t_24310 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24309})});
  V v_t_24311 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24310})});
  V v_t_24312 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24311})});
  V v_t_24313 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24312})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24313, v_hd_24305, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam57, 1, 2, (V[]){v_x22_247, v_k_24306})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam58(V self, V *args) {
  V v_hd_24319 = args[0];
  V v_k_24320 = args[1];
  V v_x21_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24319);
  V v_t_24321 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str97), heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str98)));
  V v_t_24322 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str99), v_t_24321}), NTAG(TAG_Nil)});
  V v_t_24323 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_24322, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str100))});
  V f_ = v_k_24320;
  args[0] = v_t_24323;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam60(V self, V *args) {
  V v_t_24331 = args[0];
  return v_t_24331;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam62(V self, V *args) {
  V v_r_24341 = args[0];
  return v_r_24341;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam63(V self, V *args) {
  V v_x_24348 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_x_24338 = heff_env(self)[1];
  V v_k_24330 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24348)) {
  case TAG_Left: {
    heff_take_n(v_x_24348, 0ULL, 1);
    V v_x_24350 = ({ V a_0 = v_x21_246; V b_1 = NTAG(TAG_False); V a_2 = v_x_24338; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_x_24338); r_; });
    V f_ = v_k_24330;
    args[0] = v_x_24350;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_24351 = heff_field(v_x_24348, 0);
    heff_take_n(v_x_24348, 1ULL, 1);
    V v_t_24352 = heff_get_n(v_s_24351, 0, 4);
    V v_t_24353;
    switch (heff_tag_of(v_t_24352)) {
    case TAG_Regular: {
      v_t_24353 = NTAG(TAG_True);
      break;
    }
    case TAG_Directory: {
      v_t_24353 = NTAG(TAG_False);
      break;
    }
    case TAG_Link: {
      v_t_24353 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_24353 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_24352);
    }
    V v_x_24354 = ({ V a_0 = v_x21_246; V a_1 = v_t_24353; V a_2 = v_x_24338; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_t_24353); heff_drop(v_x_24338); r_; });
    V f_ = v_k_24330;
    args[0] = v_x_24354;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_24348);
  }
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam61(V self, V *args) {
  V v_x_24338 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  V v_hd_24329 = heff_env(self)[2];
  V v_k_24330 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24339 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str104), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str105)));
  V v_path_24340 = ({ V a_0 = v_st_240; V a_1 = v_t_24339; V a_2 = heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str106)); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V v_t_24342 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_path_24340, NTAG(TAG_True), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam62_clo)});
  V v_t_24343 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24342})});
  V v_t_24344 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24343})});
  V v_t_24345 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24344})});
  V v_t_24346 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24345})});
  V v_t_24347 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24346})});
  return (g_co_2eop_24s162716155x1210144019(heff_tag_n(TAG_InR, 1, (V[]){v_t_24347}), v_hd_24329, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam63, 1, 3, (V[]){v_x21_246, v_x_24338, v_k_24330})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam59(V self, V *args) {
  V v_hd_24329 = args[0];
  V v_k_24330 = args[1];
  V v_path_24328 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x21_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24332 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24328, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam60_clo)})});
  V v_t_24333 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24332})});
  V v_t_24334 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24333})});
  V v_t_24335 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24334})});
  V v_t_24336 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24335})});
  V v_t_24337 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24336})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24337, heff_dup(v_hd_24329), heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam61, 1, 4, (V[]){v_st_240, v_x21_246, v_hd_24329, v_k_24330})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam64(V self, V *args) {
  V v_hd_24359 = args[0];
  V v_k_24360 = args[1];
  heff_drop(v_hd_24359);
  V v_t_24361 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str107), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str108)}), NTAG(TAG_Nil)});
  V v_t_24362 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24361, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str109))});
  V f_ = v_k_24360;
  args[0] = v_t_24362;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam66(V self, V *args) {
  V v_t_24371 = args[0];
  return v_t_24371;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam67(V self, V *args) {
  V v_x_24378 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24370 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24379 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str116)); V a_1 = v_x_24378; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24378); r_; });
  V f_ = v_k_24370;
  args[0] = v_x_24379;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam65(V self, V *args) {
  V v_hd_24369 = args[0];
  V v_k_24370 = args[1];
  V v_path_24368 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24372 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24368, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam66_clo)})});
  V v_t_24373 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24372})});
  V v_t_24374 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24373})});
  V v_t_24375 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24374})});
  V v_t_24376 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24375})});
  V v_t_24377 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24376})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24377, v_hd_24369, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam67, 1, 2, (V[]){v_x21_246, v_k_24370})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam68(V self, V *args) {
  V v_p_24381 = args[0];
  V v_x_24382 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24381; V a_2 = v_x_24382; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam70(V self, V *args) {
  V v_t_24386 = args[0];
  return v_t_24386;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam71(V self, V *args) {
  V v_x_24393 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24385 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24396;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24396 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str118);
    break;
  }
  case TAG_Cons: {
    V v_x_24394 = heff_field(v_x22_247, 0);
    V v_xs_24395 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24396 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str119); V a_1 = v_x_24394; V a_2 = v_xs_24395; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24395); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24397 = ({ V a_0 = v_t_24396; V a_1 = v_x_24393; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24393); r_; });
  V f_ = v_k_24385;
  args[0] = v_x_24397;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam69(V self, V *args) {
  V v_hd_24384 = args[0];
  V v_k_24385 = args[1];
  V v_path_24383 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24387 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24383, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam70_clo)})});
  V v_t_24388 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24387})});
  V v_t_24389 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24388})});
  V v_t_24390 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24389})});
  V v_t_24391 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24390})});
  V v_t_24392 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24391})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24392, v_hd_24384, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam71, 1, 2, (V[]){v_x22_247, v_k_24385})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam72(V self, V *args) {
  V v_hd_24400 = args[0];
  V v_k_24401 = args[1];
  heff_drop(v_hd_24400);
  V v_t_24402 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str120), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str121)}), NTAG(TAG_Nil)});
  V v_t_24403 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24402, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str122))});
  V f_ = v_k_24401;
  args[0] = v_t_24403;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam74(V self, V *args) {
  V v_t_24412 = args[0];
  return v_t_24412;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam75(V self, V *args) {
  V v_x_24419 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24420 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str129)); V a_1 = v_x_24419; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24419); r_; });
  V f_ = v_k_24411;
  args[0] = v_x_24420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam73(V self, V *args) {
  V v_hd_24410 = args[0];
  V v_k_24411 = args[1];
  V v_path_24409 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24409, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam74_clo)})});
  V v_t_24414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24413})});
  V v_t_24415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24414})});
  V v_t_24416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24415})});
  V v_t_24417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24416})});
  V v_t_24418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24417})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24418, v_hd_24410, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam75, 1, 2, (V[]){v_x21_246, v_k_24411})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam76(V self, V *args) {
  V v_p_24422 = args[0];
  V v_x_24423 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24422; V a_2 = v_x_24423; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam78(V self, V *args) {
  V v_t_24427 = args[0];
  return v_t_24427;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam79(V self, V *args) {
  V v_x_24434 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24437;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24437 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str131);
    break;
  }
  case TAG_Cons: {
    V v_x_24435 = heff_field(v_x22_247, 0);
    V v_xs_24436 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24437 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str132); V a_1 = v_x_24435; V a_2 = v_xs_24436; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24436); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24438 = ({ V a_0 = v_t_24437; V a_1 = v_x_24434; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24434); r_; });
  V f_ = v_k_24426;
  args[0] = v_x_24438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam77(V self, V *args) {
  V v_hd_24425 = args[0];
  V v_k_24426 = args[1];
  V v_path_24424 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24424, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam78_clo)})});
  V v_t_24429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24428})});
  V v_t_24430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24429})});
  V v_t_24431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24430})});
  V v_t_24432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24431})});
  V v_t_24433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24432})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24433, v_hd_24425, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam79, 1, 2, (V[]){v_x22_247, v_k_24426})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str0, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str3, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str7, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str8, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str9, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str10, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str11, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str12, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str13, 1, "/");
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam2, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_entry, 4, 0};

V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802(V v_web_240, V v_st_241, V v_x2_242, V v_req_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nothing: {
    heff_drop(v_web_240);
    V v_target_244 = heff_get_n(v_req_243, 1, 6);
    V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str0), v_target_244, MK_INT(0LL), 5);
    V v_path_247;
    if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
      heff_drop(v_j_245);
      v_path_247 = v_target_244;
    } else {
      v_path_247 = heff_strSlice(v_target_244, MK_INT(0LL), v_j_245);
    }
    V v_s_248 = heff_strSlice(heff_dup(v_path_247), MK_INT(1LL), heff_strLength(v_path_247));
    V v_t_249 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str1); V a_1 = v_s_248; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str2), v_s_248, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_248); r_; });
    return (g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388(v_st_241, v_t_249));
  }
  case TAG_Just: {
    V v_to_2410 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    V v_target_2411 = heff_dup(heff_rfield(v_req_243, 1));
    V v_j_2412 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str3), v_target_2411, MK_INT(0LL), 5);
    V v_path_2414;
    if (heff_intLt_c_lent(v_j_2412, MK_INT(0LL), 2)) {
      heff_drop(v_j_2412);
      v_path_2414 = v_target_2411;
    } else {
      v_path_2414 = heff_strSlice(v_target_2411, MK_INT(0LL), v_j_2412);
    }
    V v_s_2415 = heff_strSlice(heff_dup(v_path_2414), MK_INT(1LL), heff_strLength(v_path_2414));
    V v_x1_2416 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str4); V a_1 = v_s_2415; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str5), v_s_2415, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2415); r_; });
    V v_t_2419;
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x1_2416, 0);
      heff_take_n(v_x1_2416, 1ULL, 2);
      v_t_2419 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x1_2416);
    }
    V v_path_2420 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str7), v_t_2419));
    return heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam0, 2, 5, (V[]){v_req_243, heff_dup(v_st_241), v_web_240, v_to_2410, v_path_2420});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2eserved_24s761133100x856838802(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_req_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_hd_2421 = heff_env(self)[2];
  V v_k_2422 = heff_env(self)[3];
  V v_web_240 = heff_env(self)[4];
  V v_to_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2430;
  if ((heff_dup(v_x_2423) == NTAG(TAG_True))) {
    heff_drop(v_x_2423);
    v_t_2430 = NTAG(TAG_True);
  } else {
    heff_drop(v_x_2423);
    V v_target_2424 = heff_dup(heff_rfield(v_req_243, 1));
    V v_j_2425 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str8), v_target_2424, MK_INT(0LL), 5);
    V v_path_2427;
    if (heff_intLt_c_lent(v_j_2425, MK_INT(0LL), 2)) {
      heff_drop(v_j_2425);
      v_path_2427 = v_target_2424;
    } else {
      v_path_2427 = heff_strSlice(v_target_2424, MK_INT(0LL), v_j_2425);
    }
    V v_s_2428 = heff_strSlice(heff_dup(v_path_2427), MK_INT(1LL), heff_strLength(v_path_2427));
    V v_t_2429 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str9); V a_1 = v_s_2428; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str10), v_s_2428, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2428); r_; });
    v_t_2430 = ({ V a_0 = v_t_2429; V r_ = (g_heff_2ebuild_2edev_2eownPath(a_0)); heff_drop(v_t_2429); r_; });
  }
  if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
    heff_drop(v_web_240);
    heff_drop(v_to_2410);
    heff_drop(v_t_2430);
    V v_target_2431 = heff_get_n(v_req_243, 1, 6);
    V v_j_2432 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str11), v_target_2431, MK_INT(0LL), 5);
    V v_path_2434;
    if (heff_intLt_c_lent(v_j_2432, MK_INT(0LL), 2)) {
      heff_drop(v_j_2432);
      v_path_2434 = v_target_2431;
    } else {
      v_path_2434 = heff_strSlice(v_target_2431, MK_INT(0LL), v_j_2432);
    }
    V v_s_2435 = heff_strSlice(heff_dup(v_path_2434), MK_INT(1LL), heff_strLength(v_path_2434));
    V v_t_2436 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str12); V a_1 = v_s_2435; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str13), v_s_2435, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2435); r_; });
    V v_t_2437 = ({ V a_0 = v_st_241; V a_1 = v_t_2436; V r_ = (g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388(a_0, a_1)); heff_drop(v_st_241); r_; });
    V f_ = v_t_2437;
    heff_room[0] = v_hd_2421;
    heff_room[1] = v_k_2422;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_st_241);
    heff_drop(v_t_2430);
    return (g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604(v_web_240, v_to_2410, v_req_243, v_hd_2421, v_k_2422));
  }
}
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam2(V self, V *args) {
  V v_r_2439 = args[0];
  return v_r_2439;
}
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam3(V self, V *args) {
  V v_x_2446 = args[0];
  V v_k_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2446)) {
  case TAG_Left: {
    heff_take_n(v_x_2446, 0ULL, 1);
    V f_ = v_k_2438;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_2448 = heff_field(v_x_2446, 0);
    heff_take_n(v_x_2446, 1ULL, 1);
    V v_t_2449 = heff_get_n(v_s_2448, 0, 4);
    V v_t_2450;
    switch (heff_tag_of(v_t_2449)) {
    case TAG_Regular: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    case TAG_Directory: {
      v_t_2450 = NTAG(TAG_True);
      break;
    }
    case TAG_Link: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2449);
    }
    V f_ = v_k_2438;
    args[0] = v_t_2450;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2446);
  }
}
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam0(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_req_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_web_240 = heff_env(self)[2];
  V v_to_2410 = heff_env(self)[3];
  V v_path_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_k_2438 = heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam1, 1, 6, (V[]){v_req_243, v_st_241, heff_dup(v_hd_2421), v_k_2422, v_web_240, v_to_2410});
  V v_t_2440 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_path_2420, NTAG(TAG_True), ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam2_clo)});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  return (g_co_2eop_24s162716155x1210144019(heff_tag_n(TAG_InR, 1, (V[]){v_t_2445}), v_hd_2421, heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam3, 1, 1, (V[]){v_k_2438})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str0, 9, "127.0.0.1");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str3, 41, "heff dev: cannot serve the pages at port ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str6, 19, ", the rest sent to ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str7, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str8, 40, "heff dev: the pages at http://127.0.0.1:");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str10, 5, "win32");
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam0, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam2, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_entry, 7, 0};

V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450(V v_nt_240, V v_rx_241, V v_web_242, V v_port_243, V v_proxy_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s94900133x232571340(v_t_2413, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam1, 1, 7, (V[]){v_port_243, v_nt_240, v_hd_245, v_k_246, v_proxy_244, v_web_242, v_rx_241})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam2(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_hd_245, v_k_246));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam6(V self, V *args) {
  V v_p_2456 = args[0];
  V v_web_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2457 = heff_tr(heff_call(v_web_242, 1, (V[]){v_p_2456}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2457});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam7(V self, V *args) {
  V v_p_2459 = args[0];
  V v_nt_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2460 = heff_tr(heff_call(v_nt_240, 1, (V[]){v_p_2459}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2460});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam8(V self, V *args) {
  V v_x_2463 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2463);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam5(V self, V *args) {
  V v_x_2453 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_web_242 = heff_env(self)[1];
  V v_proxy_244 = heff_env(self)[2];
  V v_nt_240 = heff_env(self)[3];
  V v_listener_2442 = heff_env(self)[4];
  V v_rx_241 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2453);
  V v_t_2455;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str10))) {
    v_t_2455 = NTAG(TAG_Windows);
  } else {
    v_t_2455 = NTAG(TAG_Posix);
  }
  V v_t_2458 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_clo), 3, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam6, 1, 1, (V[]){v_web_242}), v_t_2455, v_proxy_244}));
  V v_c_2461 = (g_std_2ehttp_2eserver_2eserveConcurrently_24s1684451694x373462712(heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam7, 1, 1, (V[]){v_nt_240}), v_listener_2442, v_t_2458));
  V v_t_2462 = (g_std_2ereactor_2eoutside_24s626113845x1580845692(v_rx_241));
  return (g_green_2escheduledWith_24s323844761x1686441296(v_t_2462, v_c_2461, v_hd_245, heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam8, 1, 1, (V[]){v_k_246})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_port_243 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_proxy_244 = heff_env(self)[3];
  V v_x_2414 = heff_env(self)[4];
  V v_web_242 = heff_env(self)[5];
  V v_nt_240 = heff_env(self)[6];
  V v_rx_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    V v_err_2424 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Left = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    heff_drop(v_proxy_244);
    heff_drop(v_x_2414);
    heff_drop(v_web_242);
    heff_drop(v_nt_240);
    heff_drop(v_rx_241);
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str1), heff_take_field(v_err_2424, 2));
    V v_t_2426 = heff_strAppend(heff_get_n(v_err_2424, 1, 3), v_t_2425);
    V v_t_2427 = heff_strAppend(v_port_243, heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str2), v_t_2426));
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str3), v_t_2427), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str4));
    V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_at_n(v_ru_24x_2423_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam4, 1, 2, (V[]){v_hd_245, v_k_246})));
  }
  case TAG_Right: {
    V v_listener_2442 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Right = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    V v_t_2444;
    switch (heff_tag_of(v_proxy_244)) {
    case TAG_Nothing: {
      v_t_2444 = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str5);
      break;
    }
    case TAG_Just: {
      V v_x_2443 = heff_dup(heff_field(v_proxy_244, 0));
      v_t_2444 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str6), v_x_2443);
      break;
    }
    default: heff_nomatch(v_proxy_244);
    }
    V v_t_2445 = heff_strAppend(v_port_243, heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str7), v_t_2444));
    V v_t_2446 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str8), v_t_2445), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str9));
    V v_t_2447 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2446, NTAG(TAG_MkUnit)});
    V v_t_2448 = heff_tag_at_n(v_ru_24x_2423_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam5, 1, 8, (V[]){v_x_2414, v_web_242, v_proxy_244, v_nt_240, v_listener_2442, v_rx_241, v_hd_245, v_k_246})));
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_port_243 = heff_env(self)[0];
  V v_nt_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_proxy_244 = heff_env(self)[4];
  V v_web_242 = heff_env(self)[5];
  V v_rx_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  HeffT2 v_t_2415 = (g_prelude_2eparseInt_24cpr(v_port_243));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    V v_t_2420;
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2417;
      v_t_2420 = v_x_2419;
    } else {
      heff_drop(v_field_2417);
      v_t_2420 = MK_INT(8000LL);
    }
    V v_t_2422 = heff_tr(heff_call(heff_dup(v_nt_240), 1, (V[]){heff_tag_n(TAG_Listen, 4, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str0), v_t_2420, MK_INT(64LL), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam2_clo)})}));
    return (g_co_2eop_24s94900133x232571340(v_t_2422, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam3, 1, 8, (V[]){v_port_243, v_hd_245, v_k_246, v_proxy_244, v_x_2414, v_web_242, v_nt_240, v_rx_241})));
  }
}