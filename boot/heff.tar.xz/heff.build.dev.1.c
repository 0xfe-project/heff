// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_MkWith 3751
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Sleep 25229
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_TryWait 64330
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_build 295453320
#define LBL_builds 569118448
#define LBL_code 9554612
#define LBL_command 1182252425
#define LBL_dev 308879
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_group 299987609
#define LBL_headers 1027165638
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_malg 9839318
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_stamp 311115741
#define LBL_status 1054660381
#define LBL_timeout 1065429926
#define LBL_wanted 1152016858
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_builds__wanted__port__proxy__pages[] = {LBL_builds, LBL_wanted, LBL_port, LBL_proxy, LBL_pages};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_dev__apps__stamp[] = {LBL_dev, LBL_apps, LBL_stamp};
static uint32_t shape_name__ended[] = {LBL_name, LBL_ended};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235(V, V);
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_clo;
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516(V, V, V);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_clo;
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363(V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_clo;
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(V, V, V);
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_clo;
V g_heff_2ebuild_2edev_2efileAnswer(V, V);
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efileAnswer_clo;
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_clo;
V g_heff_2ebuild_2edev_2eindexAnswer(V);
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eindexAnswer_clo;
V g_heff_2ebuild_2edev_2emadePage(V);
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2emadePage_clo;
V g_heff_2ebuild_2edev_2epageAnswer(V, V, V);
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epageAnswer_clo;
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140(V, V, V, V);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_clo;
V g_heff_2ebuild_2edev_2erelayed(V, V);
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erelayed_clo;
V g_heff_2ebuild_2edev_2ereloadScript_get(void);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634(V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s105899861x584770213(V);
V g_list_2eany_24s105899861x584770213_entry(V self, V *a);
extern Clo g_list_2eany_24s105899861x584770213_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1992606061x1037009925(V, V, V, V, V, V);
V g_list_2ekeepIf_24s1992606061x1037009925_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1992606061x1037009925_clo;
V g_list_2emap_24f288061900x1645061111(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f288061900x1645061111_entry(V self, V *a);
extern Clo g_list_2emap_24f288061900x1645061111_clo;
V g_list_2emap_24s2104774589x596860835(V);
V g_list_2emap_24s2104774589x596860835_entry(V self, V *a);
extern Clo g_list_2emap_24s2104774589x596860835_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(V);
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_clo;
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(V);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(V, V);
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s2044712421x1082792288(V, V, V);
V g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str0, 9, "</script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str1, 10, "  }, 500);");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str2, 5, "})();");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str3, 98, "      .then(function (t) { if (seen === null) seen = t; else if (t !== seen) location.reload(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str4, 29, "      .catch(function () {});");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str5, 48, "    fetch(\"/.heff/built\", { cache: \"no-store\" })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str6, 46, "      .then(function (r) { return r.text(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str7, 18, "  var seen = null;");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str8, 27, "  setInterval(function () {");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str10, 8, "<script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str11, 14, "(function () {");

static V g_heff_2ebuild_2edev_2ereloadScript_val;
static HEFF_ONCE g_heff_2ebuild_2edev_2ereloadScript_st;
static V g_heff_2ebuild_2edev_2ereloadScript_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str9); V a_1 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str10); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str11), v_t_244}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2edev_2ereloadScript_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2edev_2ereloadScript_st)) return g_heff_2ebuild_2edev_2ereloadScript_val;
  return heff_global(&g_heff_2ebuild_2edev_2ereloadScript_val, &g_heff_2ebuild_2edev_2ereloadScript_st, g_heff_2ebuild_2edev_2ereloadScript_init);
}
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str2, 3, "no ");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str4, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str5, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str6, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2efileAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efileAnswer_entry, 2, 0};

V g_heff_2ebuild_2edev_2efileAnswer(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str0), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str1)}), NTAG(TAG_Nil)});
    V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2efileAnswer_str2), heff_strAppend(v_p_240, ((V)&g_heff_2ebuild_2edev_2efileAnswer_str3)));
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_242, heff_bytesFromString(v_t_243)});
  }
  case TAG_Just: {
    V v_text_244 = heff_field(v_x2_241, 0);
    V v_kind_245 = ({ V a_0 = v_p_240; V r_ = (g_heff_2ebuild_2edev_2etypeOf(a_0)); heff_drop(v_p_240); r_; });
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str4), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str5)}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str6), v_kind_245}), v_t_246});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_247, heff_bytesFromString(heff_dup(v_text_244))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2efileAnswer(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str1, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str2, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str3, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str4, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str5, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str6, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str7, 8, "no page ");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str9, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str10, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str11, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str12, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str13, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2epageAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epageAnswer_entry, 3, 0};

V g_heff_2ebuild_2edev_2epageAnswer(V v_name_240, V v_built_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    if ((heff_dup(v_built_241) == NTAG(TAG_True))) {
      V v_kind_243 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str0); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
      V v_html_244 = (g_heff_2ebuild_2edev_2emadePage(v_name_240));
      V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str1), v_html_244, MK_INT(0LL), 5);
      V v_text_247;
      if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
        heff_drop(v_j_245);
        v_text_247 = heff_strAppend(v_html_244, heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
      } else {
        V v_t_246 = heff_strSlice(heff_dup(v_html_244), heff_dup(v_j_245), heff_strLength_lent(v_html_244, 0));
        v_text_247 = heff_strAppend(heff_strSlice(v_html_244, MK_INT(0LL), v_j_245), heff_strAppend(heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), v_t_246));
      }
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str2), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str3)}), NTAG(TAG_Nil)});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str4), v_kind_243}), v_t_248});
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_249, heff_bytesFromString(v_text_247)});
    } else {
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str5), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str6)}), NTAG(TAG_Nil)});
      V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str7), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2edev_2epageAnswer_str8)));
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2410, heff_bytesFromString(v_t_2411)});
    }
  }
  case TAG_Just: {
    V v_html_2412 = heff_field(v_x3_242, 0);
    heff_drop(v_name_240);
    V v_kind_2413 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str9); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
    V v_j_2414 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str10), v_html_2412, MK_INT(0LL), 5);
    V v_text_2416;
    if (heff_intLt_c_lent(v_j_2414, MK_INT(0LL), 2)) {
      heff_drop(v_j_2414);
      v_text_2416 = heff_strAppend(heff_dup(v_html_2412), heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
    } else {
      V v_t_2415 = heff_strSlice(heff_dup(v_html_2412), heff_dup(v_j_2414), heff_strLength_lent(v_html_2412, 0));
      v_text_2416 = heff_strAppend(heff_strSlice_lent(v_html_2412, MK_INT(0LL), v_j_2414, 6), heff_strAppend(heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), v_t_2415));
    }
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str11), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str12)}), NTAG(TAG_Nil)});
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str13), v_kind_2413}), v_t_2417});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2418, heff_bytesFromString(v_text_2416)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2edev_2epageAnswer(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str1, 4, "<ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str2, 23, "<title>heff dev</title>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str3, 18, "<h1>the pages</h1>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str4, 14, "<li><a href=\"/");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str5, 3, "/\">");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str6, 9, "</a></li>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str7, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str8, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str9, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str10, 5, "</ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str11, 15, "<!doctype html>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str14, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str15, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str16, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2eindexAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eindexAnswer_entry, 1, 0};

V g_heff_2ebuild_2edev_2eindexAnswer(V v_found_240) {
top: ;
  V v_kind_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str0); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str1), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str3), v_t_242})});
  V v_t_245;
  switch (heff_tag_of(v_found_240)) {
  case TAG_Nothing: {
    v_t_245 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_found_240, 0);
    v_t_245 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_found_240);
  }
  V v_t_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str4); V b_1 = MK_INT(0LL); V a_2 = MK_INT(3LL); V a_3 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str5); V b_4 = MK_INT(0LL); V a_5 = MK_INT(3LL); V a_6 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str6); V b_7 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str7); V b_8 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str8); V b_9 = MK_INT(0LL); V b_10 = MK_INT(1LL); V b_11 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str9); V a_12 = v_t_245; V r_ = (g_list_2emap_24f288061900x1645061111(a_0, b_1, a_2, a_3, b_4, a_5, a_6, b_7, b_8, b_9, b_10, b_11, a_12)); heff_drop(b_1); heff_drop(b_4); heff_drop(b_7); heff_drop(b_8); heff_drop(b_9); heff_drop(b_10); heff_drop(b_11); r_; });
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), NTAG(TAG_Nil)});
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str10), v_t_247})));
  V v_xs_249 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str11), v_t_243}), v_t_248));
  V v_text_2412;
  switch (heff_tag_of(v_xs_249)) {
  case TAG_Nil: {
    v_text_2412 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_xs_249, 0);
    V v_xs_2411 = heff_field(v_xs_249, 1);
    heff_take_n(v_xs_249, 3ULL, 2);
    v_text_2412 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str13); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_xs_249);
  }
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str14), ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str15)}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str16), v_kind_241}), v_t_2413});
  return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2414, heff_bytesFromString(v_text_2412)});
}
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eindexAnswer(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str2, 2, ") ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str3, 7, "curl: (");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str6, 23, "heff dev: nothing from ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str7, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str8, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str9, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str10, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str11, 10, "keep-alive");
Clo g_heff_2ebuild_2edev_2erelayed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erelayed_entry, 2, 0};

V g_heff_2ebuild_2edev_2erelayed(V v_to_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Left: {
    V v_err_242 = heff_field(v_x2_241, 0);
    V v_code_243 = heff_dup(heff_rfield(v_err_242, 0));
    V v_message_244 = heff_dup(heff_rfield(v_err_242, 1));
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erelayed_str0), ((V)&g_heff_2ebuild_2edev_2erelayed_str1)}), NTAG(TAG_Nil)});
    V v_t_246 = heff_strAppend(heff_intShow(v_code_243), heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str2), v_message_244));
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str3), v_t_246), ((V)&g_heff_2ebuild_2edev_2erelayed_str4));
    V v_t_248 = heff_strAppend(v_to_240, heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str5), v_t_247));
    V v_t_249 = heff_bytesFromString(heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str6), v_t_248));
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(502LL), v_t_245, v_t_249});
  }
  case TAG_Right: {
    V v_res_2410 = heff_field(v_x2_241, 0);
    heff_drop(v_to_240);
    V v_status_2411 = heff_dup(heff_rfield(v_res_2410, 0));
    V v_headers_2412 = heff_dup(heff_rfield(v_res_2410, 1));
    V v_body_2413 = heff_dup(heff_rfield(v_res_2410, 2));
    V v_t_2414 = (g_list_2ekeepIf_24s1992606061x1037009925(((V)&g_heff_2ebuild_2edev_2erelayed_str7), ((V)&g_heff_2ebuild_2edev_2erelayed_str8), ((V)&g_heff_2ebuild_2edev_2erelayed_str9), ((V)&g_heff_2ebuild_2edev_2erelayed_str10), ((V)&g_heff_2ebuild_2edev_2erelayed_str11), v_headers_2412));
    return heff_rec_n(3, shape_status__headers__body, (V[]){v_status_2411, v_t_2414, v_body_2413});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2erelayed(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str1, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str3, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str4, 1, ".");
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam4(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam4, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam8(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam8, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam2(V self, V *args);
Clo g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_entry, 2, 0};

V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235(V v_prog_240, V v_st_241) {
top: ;
  V v_path_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_243 = (g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(v_path_242));
  V v_c_248 = heff_tr(heff_call(v_c_243, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam2, 2, 3, (V[]){v_c_248, v_prog_240, heff_dup(v_st_241)});
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_x_245 = (g_list_2emap_24s219049803x1458391381(v_x_244));
  return heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam1, 2, 1, (V[]){v_x_245});
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam4(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_bad_2421 = heff_env(self)[0];
  V v_apps_2422 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2425);
  V v_t_2426;
  if (heff_intLt_c(MK_INT(0LL), v_bad_2421)) {
    heff_drop(v_apps_2422);
    v_t_2426 = NTAG(TAG_Nil);
  } else {
    v_t_2426 = v_apps_2422;
  }
  V f_ = v_k_2410;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_bad_2421 = heff_take_field(v_x_2420, 1);
  V v_apps_2422 = heff_get_n(v_x_2420, 0, 2);
  V v_t_2423 = heff_tag_n(TAG_End, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2423}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2424, v_hd_249, heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam7, 1, 3, (V[]){v_bad_2421, v_apps_2422, v_k_2410})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2417 = (g_heff_2ebuild_2ecommands_2ebuildTarget(v_st_241, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str2)));
  V v_t_2418 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2419 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_241; V a_2 = v_t_2417; V a_3 = heff_dup(v_x_2416); V a_4 = v_t_2418; V a_5 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_241); r_; });
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam6, 1, 4, (V[]){v_x_2416, v_prog_240, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam8(V self, V *args) {
  V v_t_2429 = args[0];
  return v_t_2429;
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam11(V self, V *args) {
  V v_x_2440 = args[0];
  V v_bad_2436 = heff_env(self)[0];
  V v_apps_2437 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2440);
  V v_t_2441;
  if (heff_intLt_c(MK_INT(0LL), v_bad_2436)) {
    heff_drop(v_apps_2437);
    v_t_2441 = NTAG(TAG_Nil);
  } else {
    v_t_2441 = v_apps_2437;
  }
  V f_ = v_k_2410;
  args[0] = v_t_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam10(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2431 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_bad_2436 = heff_take_field(v_x_2435, 1);
  V v_apps_2437 = heff_get_n(v_x_2435, 0, 2);
  V v_t_2438 = heff_tag_n(TAG_End, 2, (V[]){v_x_2431, NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2438}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2439, v_hd_249, heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam11, 1, 3, (V[]){v_bad_2436, v_apps_2437, v_k_2410})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam9(V self, V *args) {
  V v_x_2431 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_y_2427 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432 = (g_heff_2ebuild_2ecommands_2ebuildTarget(v_st_241, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str4)));
  V v_t_2433 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2434 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_241; V a_2 = v_t_2432; V a_3 = heff_dup(v_x_2431); V a_4 = v_t_2433; V a_5 = v_y_2427; V r_ = (g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_241); r_; });
  V f_ = v_c_2434;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam10, 1, 4, (V[]){v_x_2431, v_prog_240, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    V v_ru_24x_2411_24Left = heff_take_reuse_n(v_x_2411, 0ULL, 1);
    V v_total_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = NTAG(TAG_Nil); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2415 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str1), v_total_2413, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam4_clo)})}));
    return (g_co_2eop_24s615738393x1686646143_24tok1(v_ru_24x_2411_24Left, v_t_2415, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam5, 1, 4, (V[]){v_st_241, v_prog_240, v_hd_249, v_k_2410})));
  }
  case TAG_Right: {
    V v_y_2427 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Right = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_total_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_y_2427));
    V v_t_2430 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_str3), v_total_2428, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam8_clo)})}));
    return (g_co_2eop_24s615738393x1686646143_24tok1(v_ru_24x_2411_24Right, v_t_2430, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam9, 1, 5, (V[]){v_st_241, v_prog_240, v_y_2427, v_hd_249, v_k_2410})));
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam2(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235_lam3, 1, 4, (V[]){v_prog_240, v_hd_249, v_st_241, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_str0, 52, "heff dev: not built; built again at the next change\012");
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_entry, 3, 0};

V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(V v_r_240, V v_hd_241, V v_k_242) {
top: ;
  V v_out_243 = heff_take_field(v_r_240, 1);
  V v_err_244 = heff_get_n(v_r_240, 2, 3);
  V v_t_245 = heff_tag_n(TAG_Write, 2, (V[]){v_out_243, NTAG(TAG_MkUnit)});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam0, 1, 3, (V[]){v_err_244, v_hd_241, v_k_242})});
}
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_str0), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_err_244 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2413);
  V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_err_244, NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2421;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam1, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_str0, 8, "building");
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_str1, 5, "build");
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam1, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam3, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_entry, 4, 0};

V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140(V v_prog_240, V v_st_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam0, 1, 4, (V[]){v_prog_240, v_hd_242, heff_dup(v_st_241), v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam1(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam3(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2419);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam8(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2421);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam9(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2422);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam10(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2423);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_dup(heff_rfield(v_x_2411, 0));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Exited: {
    V v_n_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    if (heff_intEq_c(v_n_2416, MK_INT(0LL))) {
      heff_drop_rec(v_x_2411, 3);
      V v_c_2417 = ({ V a_0 = v_prog_240; V a_1 = v_st_241; V r_ = (g_heff_2ebuild_2edev_2eappsNow_24s423357443x1536698235(a_0, a_1)); heff_drop(v_st_241); r_; });
      V f_ = v_c_2417;
      heff_room[0] = v_hd_242;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam6, 1, 1, (V[]){v_k_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_prog_240);
      heff_drop(v_st_241);
      return (g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(v_x_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam7, 1, 1, (V[]){v_k_243})));
    }
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(v_x_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam8, 1, 1, (V[]){v_k_243})));
  }
  case TAG_TimedOut: {
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(v_x_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam9, 1, 1, (V[]){v_k_243})));
  }
  case TAG_NotRun: {
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(v_x_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam10, 1, 1, (V[]){v_k_243})));
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412 = heff_tag_n(TAG_End, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2412}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2413, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam5, 1, 5, (V[]){v_x_2411, v_prog_240, v_st_241, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_str1), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_247), v_x_244, v_t_248, ((V)&g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam3_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2410, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam4, 1, 5, (V[]){v_x_247, v_prog_240, v_hd_242, v_st_241, v_k_243})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam1_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_246, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140_lam2, 1, 5, (V[]){v_prog_240, v_x_244, v_hd_242, v_st_241, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_str1, 1, "\012");
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_entry, 6, 0};

V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634(V v_prog_240, V v_clock_241, V v_st_242, V v_d_243, V v_stamp_244, V v_running_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_Sleep, 2, (V[]){MK_INT(250LL), NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tr(heff_call(heff_dup(v_clock_241), 1, (V[]){v_t_246}));
  return heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam0, 2, 7, (V[]){v_t_247, v_running_245, heff_dup(v_st_242), heff_dup(v_stamp_244), v_prog_240, v_clock_241, v_d_243});
}
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634(a[0], a[1], a2, a[3], a4, a[5]); heff_drop(a2); heff_drop(a4); return r;
}
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_d_243 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_hd_248 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    V v_t_2419 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_st_242; V a_3 = v_d_243; V a_4 = v_x_2416; V a_5 = v_x_2411; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_242); heff_drop(v_x_2416); r_; });
    V f_ = v_t_2419;
    heff_room[0] = v_hd_248;
    heff_room[1] = v_k_249;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_argv_2420 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_clock_241);
    heff_drop(v_st_242);
    heff_drop(v_x_2411);
    heff_drop(v_hd_248);
    V v_t_2421 = heff_intAdd(heff_take_field(v_d_243, 0), MK_INT(1LL));
    V v_t_2422 = ({ V rv_0 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_d_243, 30ULL, 5, shape_builds__wanted__port__proxy__pages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_k_249;
    args[0] = heff_rec_n(3, shape_dev__apps__stamp, (V[]){v_t_2422, v_argv_2420, v_x_2416});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_stamp_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_st_242 = heff_env(self)[3];
  V v_d_243 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_hd_248 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2416;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nil: {
    v_x_2416 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x_2413, 0);
    V v_xs_2415 = heff_field(v_x_2413, 1);
    heff_take_n(v_x_2413, 3ULL, 2);
    v_x_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_str1); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  if (heff_strEq_c_lent(v_x_2416, v_stamp_244, 0)) {
    heff_drop(v_x_2416);
    V v_t_2417 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_st_242; V a_3 = v_d_243; V a_4 = v_stamp_244; V a_5 = v_x_2411; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_242); heff_drop(v_stamp_244); r_; });
    V f_ = v_t_2417;
    heff_room[0] = v_hd_248;
    heff_room[1] = v_k_249;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_stamp_244);
    return ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_242; V a_2 = heff_dup(v_hd_248); V a_3 = heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam4, 1, 8, (V[]){v_prog_240, v_clock_241, heff_dup(v_st_242), v_d_243, v_x_2416, v_x_2411, v_hd_248, v_k_249}); V r_ = (g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140(a_0, a_1, a_2, a_3)); heff_drop(v_st_242); r_; });
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_stamp_244 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_clock_241 = heff_env(self)[4];
  V v_d_243 = heff_env(self)[5];
  V v_k_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2412 = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(v_st_242, NTAG(TAG_Nil), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam3, 1, 8, (V[]){v_stamp_244, v_prog_240, v_clock_241, v_st_242, v_d_243, v_x_2411, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_running_245 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_stamp_244 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_d_243 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2410);
  return (g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(NTAG(TAG_Nil), v_running_245, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam2, 1, 7, (V[]){v_st_242, v_hd_248, v_stamp_244, v_prog_240, v_clock_241, v_d_243, v_k_249})));
}
V g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_t_247 = heff_env(self)[0];
  V v_running_245 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_stamp_244 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_d_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s615738393x1686646143(v_t_247, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634_lam1, 1, 8, (V[]){v_running_245, v_hd_248, v_st_242, v_stamp_244, v_prog_240, v_clock_241, v_d_243, v_k_249})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str1, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str3, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str4, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str5, 1, "c");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str6, 14, "nothing to run");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str8, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str9, 11, "); running ");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str10, 17, "heff dev: built (");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str11, 1, "\012");
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam0, 3, 0};
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam3, 3, 0};
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_entry, 3, 0};

V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516(V v_st_240, V v_d_241, V v_apps_242) {
top: ;
  V v_builds_243 = heff_take_field(v_d_241, 0);
  V v_wanted_244 = heff_get_n(v_d_241, 1, 5);
  V v_t_245 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str0)));
  V v_t_246 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str1)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_s_248 = ({ V a_0 = v_st_240; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_path_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_248; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2410 = ({ V a_0 = v_path_249; V r_ = (g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(a_0)); heff_drop(v_path_249); r_; });
  V v_c_2414 = heff_tr(heff_call(v_c_2410, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam1, 2, 5, (V[]){v_c_2414, heff_dup(v_st_240), v_builds_243, v_wanted_244, v_apps_242});
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_2412 = args[1];
  V v_k_2413 = args[2];
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_2429 = args[1];
  V v_k_2430 = args[2];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam5(V self, V *args) {
  V v_a_2434 = args[0];
  V v_wanted_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_build_2435 = heff_take_field(v_a_2434, 1);
  V v_name_2436 = heff_get_n(v_a_2434, 0, 2);
  if (heff_strEq_c(heff_get_n(v_build_2435, 0, 3), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str5))) {
    switch (heff_tag_of(v_wanted_2433)) {
    case TAG_Nil: {
      heff_drop(v_name_2436);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_t_2439 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_name_2436}));
      return ({ V a_0 = v_t_2439; V a_1 = v_wanted_2433; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_wanted_2433, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2433);
    }
  } else {
    heff_drop(v_wanted_2433);
    heff_drop(v_name_2436);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  V v_apps_242 = heff_env(self)[1];
  V v_builds_243 = heff_env(self)[2];
  V v_hd_2415 = heff_env(self)[3];
  V v_k_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2432);
  V v_wanted_2433 = v_wanted_244;
  V v_argv_2440 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam5, 1, 1, (V[]){v_wanted_2433}), v_apps_242));
  V v_t_2446;
  switch (heff_tag_of(v_argv_2440)) {
  case TAG_Nil: {
    v_t_2446 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str6);
    break;
  }
  case TAG_Cons: {
    V v_x2_2443 = (g_list_2emap_24s2104774589x596860835(v_argv_2440));
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_Nil: {
      v_t_2446 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2444 = heff_field(v_x2_2443, 0);
      V v_xs_2445 = heff_field(v_x2_2443, 1);
      heff_take_n(v_x2_2443, 3ULL, 2);
      v_t_2446 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str8); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2443);
    }
    break;
  }
  default: heff_nomatch(v_argv_2440);
  }
  V v_t_2447 = heff_strAppend(heff_intShow(v_builds_243), heff_strAppend(((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str9), v_t_2446));
  V v_str_2448 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str10), v_t_2447);
  V v_t_2449 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2448, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str11)), NTAG(TAG_MkUnit)});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tr(heff_call(heff_take_field(v_hd_2415, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})}));
  V f_ = heff_get_n(v_hd_2415, 1, 3);
  heff_room[0] = v_t_2456;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_builds_243 = heff_env(self)[1];
  V v_hd_2415 = heff_env(self)[2];
  V v_wanted_244 = heff_env(self)[3];
  V v_apps_242 = heff_env(self)[4];
  V v_k_2416 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2417);
  V v_t_2418 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str2)));
  V v_t_2419 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str3)));
  V v_t_2420 = (g_std_2epath_2ejoin(v_t_2418, v_t_2419));
  V v_a_2421 = ({ V a_0 = v_st_240; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2420); r_; });
  V v_t_2422 = (g_std_2epath_2eparse(v_st_240, v_a_2421));
  V v_t_2423 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str4)));
  V v_t_2424 = (g_std_2epath_2ejoin(v_t_2422, v_t_2423));
  V v_s_2425 = ({ V a_0 = v_st_240; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2424); r_; });
  V v_path_2426 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2425; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2427 = ({ V a_0 = v_path_2426; V a_1 = heff_intShow(heff_dup(v_builds_243)); V r_ = (g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a_0, a_1)); heff_drop(v_path_2426); r_; });
  V v_c_2431 = heff_tr(heff_call(v_c_2427, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam3_clo)}));
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam4, 1, 5, (V[]){v_wanted_244, v_apps_242, v_builds_243, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_builds_243 = heff_env(self)[2];
  V v_wanted_244 = heff_env(self)[3];
  V v_apps_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam2, 1, 6, (V[]){v_st_240, v_builds_243, v_hd_2415, v_wanted_244, v_apps_242, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str2, 4, ".exe");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str3, 21, "heff dev: cannot run ");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str4, 1, "\012");
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam1, 1, 0};
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam12(V self, V *args);
Clo g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_entry, 8, 0};

V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273(V v_prog_240, V v_clock_241, V v_ex_242, V v_st_243, V v_d_244, V v_stamp_245, V v_running_246, V v_x5_247) {
top: ;
  switch (heff_tag_of(v_x5_247)) {
  case TAG_Nil: {
    heff_drop(v_ex_242);
    return (g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634(v_prog_240, v_clock_241, v_st_243, v_d_244, v_stamp_245, v_running_246));
  }
  case TAG_Cons: {
    V v_a_248 = heff_field(v_x5_247, 0);
    V v_rest_249 = heff_field(v_x5_247, 1);
    heff_take_n(v_x5_247, 3ULL, 2);
    V v_t_2410 = (g_std_2epath_2eparse(v_st_243, ((V)&g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str0)));
    V v_t_2411 = (g_std_2epath_2eparse(v_st_243, ((V)&g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str1)));
    V v_t_2412 = (g_std_2epath_2ejoin(v_t_2410, v_t_2411));
    V v_a_2413 = ({ V a_0 = v_st_243; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2412); r_; });
    V v_n_2414 = heff_dup(heff_rfield(v_a_248, 0));
    V v_t_2415 = (g_std_2epath_2eparse(v_st_243, v_a_2413));
    V v_t_2416;
    switch (heff_tag_of(v_st_243)) {
    case TAG_Posix: {
      v_t_2416 = v_n_2414;
      break;
    }
    case TAG_Windows: {
      v_t_2416 = heff_strAppend(v_n_2414, ((V)&g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str2));
      break;
    }
    default: heff_nomatch(v_st_243);
    }
    V v_t_2417 = (g_std_2epath_2eparse(v_st_243, v_t_2416));
    V v_t_2418 = (g_std_2epath_2ejoin(v_t_2415, v_t_2417));
    V v_program_2419 = ({ V a_0 = v_st_243; V a_1 = v_t_2418; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_t_2420 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_program_2419, NTAG(TAG_Nil), heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_c_2446 = (g_std_2eprocess_2ewithProcess_24s2044712421x1082792288(heff_dup(v_ex_242), v_t_2420, heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam0, 1, 9, (V[]){heff_dup(v_a_248), heff_dup(v_running_246), heff_dup(v_prog_240), heff_dup(v_clock_241), heff_dup(v_ex_242), heff_dup(v_st_243), heff_dup(v_d_244), heff_dup(v_stamp_245), heff_dup(v_rest_249)})));
    V v_t_2468 = heff_tr(heff_call(heff_dup(v_ex_242), 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam6, 2, 1, (V[]){v_c_2446}), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam8, 3, 9, (V[]){v_a_248, v_prog_240, v_clock_241, v_ex_242, heff_dup(v_st_243), v_d_244, heff_dup(v_stamp_245), v_running_246, v_rest_249})})}));
    return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam12, 2, 1, (V[]){v_t_2468});
  }
  default: return heff_nomatch(v_x5_247);
  }
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a5 = a[5]; V r = g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273(a[0], a[1], a[2], a3, a[4], a5, a[6], a[7]); heff_drop(a3); heff_drop(a5); return r;
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam1(V self, V *args) {
  V v_r_2424 = args[0];
  return v_r_2424;
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam5(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_2444 = args[1];
  V v_k_2445 = args[2];
  V v_x_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2443);
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_2441 = args[1];
  V v_k_2442 = args[2];
  V v_x_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2440);
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam5, 3, 1, (V[]){v_x_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam3(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2438;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam4, 3, 1, (V[]){v_x_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam2(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_c_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2436;
  args[0] = v_hd_2437;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam3, 1, 1, (V[]){v_k_2438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam0(V self, V *args) {
  V v_p_2421 = args[0];
  V v_a_248 = heff_env(self)[0];
  V v_running_246 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_ex_242 = heff_env(self)[4];
  V v_st_243 = heff_env(self)[5];
  V v_d_244 = heff_env(self)[6];
  V v_stamp_245 = heff_env(self)[7];
  V v_rest_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2423;
  switch (heff_tag_of(v_p_2421)) {
  case TAG_MkWith: {
    V v_x_2422 = heff_field(v_p_2421, 0);
    heff_take_n(v_p_2421, 1ULL, 1);
    v_t_2423 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_p_2421);
  }
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_TryWait, 2, (V[]){v_t_2423, ((V)&g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam1_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2431}));
  V v_t_2433 = heff_rec_n(2, shape_name__ended, (V[]){heff_get_n(v_a_248, 0, 2), v_t_2432});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
  V v_t_2435 = (g_prelude_2e_2b_2b(v_running_246, v_t_2434));
  V v_c_2436 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = v_t_2435; V a_7 = v_rest_249; V r_ = (g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam2, 2, 1, (V[]){v_c_2436});
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_hd_2447 = heff_env(self)[0];
  V v_k_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2449;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2447;
  heff_room[2] = v_k_2448;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam6(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2446;
  args[0] = heff_dup(v_hd_2447);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam7, 1, 2, (V[]){v_hd_2447, v_k_2448});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam11(V self, V *args) {
  V v_x_2465 = args[0];
  V v_hd_2466 = args[1];
  V v_k_2467 = args[2];
  V v_x_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2465);
  heff_drop(v_hd_2466);
  V f_ = v_k_2467;
  args[0] = v_x_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam10(V self, V *args) {
  V v_x_2464 = args[0];
  V v_k_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2452;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam11, 3, 1, (V[]){v_x_2464});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam9(V self, V *args) {
  V v_x_2462 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_st_243 = heff_env(self)[3];
  V v_d_244 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_running_246 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  V v_hd_2451 = heff_env(self)[8];
  V v_k_2452 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2462);
  V v_c_2463 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = v_running_246; V a_7 = v_rest_249; V r_ = (g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  V f_ = v_c_2463;
  heff_room[0] = v_hd_2451;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam10, 1, 1, (V[]){v_k_2452});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam8(V self, V *args) {
  V v_err_2450 = args[0];
  V v_hd_2451 = args[1];
  V v_k_2452 = args[2];
  V v_a_248 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_d_244 = heff_env(self)[5];
  V v_stamp_245 = heff_env(self)[6];
  V v_running_246 = heff_env(self)[7];
  V v_rest_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_err_2450);
  V v_t_2453 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str3), heff_get_n(v_a_248, 0, 2));
  V v_t_2454 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2453, ((V)&g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_str4)), NTAG(TAG_MkUnit)});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2451, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2460})}));
  V f_ = heff_dup(heff_rfield(v_hd_2451, 1));
  args[0] = v_t_2461;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam9, 1, 10, (V[]){v_prog_240, v_clock_241, v_ex_242, v_st_243, v_d_244, v_stamp_245, v_running_246, v_rest_249, v_hd_2451, v_k_2452});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam13(V self, V *args) {
  V v_x_2471 = args[0];
  V v_hd_2469 = heff_env(self)[0];
  V v_k_2470 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2471;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2469;
  heff_room[2] = v_k_2470;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam12(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k_2470 = args[1];
  V v_t_2468 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_co_2eop_24s615738393x1686646143(v_t_2468, heff_dup(v_hd_2469), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273_lam13, 1, 2, (V[]){v_hd_2469, v_k_2470})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_str0, 9, "dev-pages");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_str1, 33, "heff dev: cannot serve the pages\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_str2, 1, "c");
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam14(V self, V *args);
Clo g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_entry, 7, 0};

V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(V v_prog_240, V v_clock_241, V v_ex_242, V v_st_243, V v_d_244, V v_stamp_245, V v_apps_246) {
top: ;
  V v_t_247 = (g_list_2eany_24s105899861x584770213(v_apps_246));
  if (((heff_dup(v_t_247) == NTAG(TAG_True)) && !(heff_dup(heff_rfield(v_d_244, 4)) == NTAG(TAG_True)))) {
    heff_drop(v_t_247);
    return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam0, 2, 7, (V[]){v_d_244, v_ex_242, v_prog_240, v_clock_241, heff_dup(v_st_243), heff_dup(v_stamp_245), v_apps_246});
  } else {
    heff_drop(v_t_247);
    V v_c_2452 = (g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516(v_st_243, heff_dup(v_d_244), heff_dup(v_apps_246)));
    return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam14, 2, 8, (V[]){v_c_2452, v_d_244, v_apps_246, v_prog_240, v_clock_241, v_ex_242, heff_dup(v_st_243), heff_dup(v_stamp_245)});
  }
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a5 = a[5]; V r = g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(a[0], a[1], a[2], a3, a[4], a5, a[6]); heff_drop(a3); heff_drop(a5); return r;
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2426 = args[1];
  V v_k_2427 = args[2];
  V v_x_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2425);
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2423 = args[1];
  V v_k_2424 = args[2];
  V v_x_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2422);
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam6, 3, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2420;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam5, 3, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam4, 1, 1, (V[]){v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam2(V self, V *args) {
  V v_pg_2416 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_pg_2416);
  V v_t_2417 = ({ V rv_4 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_d_244, 15ULL, 5, shape_builds__wanted__port__proxy__pages, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_c_2418 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_t_2417; V a_5 = v_stamp_245; V a_6 = v_apps_246; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam3, 2, 1, (V[]){v_c_2418});
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam8(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_2429 = heff_env(self)[0];
  V v_k_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2431;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2429;
  heff_room[2] = v_k_2430;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam7(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2428;
  args[0] = heff_dup(v_hd_2429);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam8, 1, 2, (V[]){v_hd_2429, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam12(V self, V *args) {
  V v_x_2447 = args[0];
  V v_hd_2448 = args[1];
  V v_k_2449 = args[2];
  V v_x_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2447);
  heff_drop(v_hd_2448);
  V f_ = v_k_2449;
  args[0] = v_x_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam11(V self, V *args) {
  V v_x_2446 = args[0];
  V v_k_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2434;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam12, 3, 1, (V[]){v_x_2446});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam10(V self, V *args) {
  V v_x_2443 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  V v_hd_2433 = heff_env(self)[7];
  V v_k_2434 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2443);
  V v_t_2444 = ({ V rv_4 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_d_244, 15ULL, 5, shape_builds__wanted__port__proxy__pages, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_c_2445 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_t_2444; V a_5 = v_stamp_245; V a_6 = v_apps_246; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  V f_ = v_c_2445;
  heff_room[0] = v_hd_2433;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam11, 1, 1, (V[]){v_k_2434});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam9(V self, V *args) {
  V v_err_2432 = args[0];
  V v_hd_2433 = args[1];
  V v_k_2434 = args[2];
  V v_d_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_err_2432);
  V v_t_2435 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_str1), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2433, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})}));
  V f_ = heff_dup(heff_rfield(v_hd_2433, 1));
  args[0] = v_t_2442;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam10, 1, 9, (V[]){v_d_244, v_prog_240, v_clock_241, v_ex_242, v_st_243, v_stamp_245, v_apps_246, v_hd_2433, v_k_2434});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam13(V self, V *args) {
  V v_x_2451 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2451;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_248;
  heff_room[2] = v_k_249;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_ex_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  V v_hd_248 = heff_env(self)[7];
  V v_k_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2411 = heff_dup(heff_rfield(v_d_244, 3));
  V v_t_2413;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    v_t_2413 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 1);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_d_244, 2)), v_t_2413});
  V v_t_2415 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2410, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_str0), v_t_2414}), heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_c_2428 = (g_std_2eprocess_2ewithProcess_24s2044712421x1082792288(heff_dup(v_ex_242), v_t_2415, heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam2, 1, 7, (V[]){heff_dup(v_d_244), heff_dup(v_prog_240), heff_dup(v_clock_241), heff_dup(v_ex_242), heff_dup(v_st_243), heff_dup(v_stamp_245), heff_dup(v_apps_246)})));
  V v_t_2450 = heff_tr(heff_call(heff_dup(v_ex_242), 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam7, 2, 1, (V[]){v_c_2428}), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam9, 3, 7, (V[]){v_d_244, v_prog_240, v_clock_241, v_ex_242, v_st_243, v_stamp_245, v_apps_246})})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2450, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam13, 1, 2, (V[]){v_hd_248, v_k_249})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_d_244 = heff_env(self)[0];
  V v_ex_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam1, 1, 9, (V[]){v_d_244, v_ex_242, v_prog_240, v_clock_241, v_st_243, v_stamp_245, v_apps_246, v_hd_248, v_k_249})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam16(V self, V *args) {
  V v_a_2457 = args[0];
  V v_wanted_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_build_2458 = heff_take_field(v_a_2457, 1);
  V v_name_2459 = heff_get_n(v_a_2457, 0, 2);
  if (heff_strEq_c(heff_get_n(v_build_2458, 0, 3), ((V)&g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_str2))) {
    switch (heff_tag_of(v_wanted_2456)) {
    case TAG_Nil: {
      heff_drop(v_name_2459);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_t_2462 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_name_2459}));
      return ({ V a_0 = v_t_2462; V a_1 = v_wanted_2456; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_wanted_2456, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2456);
    }
  } else {
    heff_drop(v_wanted_2456);
    heff_drop(v_name_2459);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam17(V self, V *args) {
  V v_x_2465 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_st_243 = heff_env(self)[3];
  V v_hd_2453 = heff_env(self)[4];
  V v_k_2454 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_dev_2466 = heff_take_field(v_x_2465, 0);
  V v_stamp_2467 = heff_take_field(v_x_2465, 2);
  V v_apps_2468 = heff_get_n(v_x_2465, 1, 3);
  V v_t_2469 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_dev_2466; V a_5 = v_stamp_2467; V a_6 = v_apps_2468; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_243); heff_drop(v_stamp_2467); r_; });
  V f_ = v_t_2469;
  heff_room[0] = v_hd_2453;
  heff_room[1] = v_k_2454;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam15(V self, V *args) {
  V v_x_2455 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_apps_246 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_ex_242 = heff_env(self)[4];
  V v_st_243 = heff_env(self)[5];
  V v_stamp_245 = heff_env(self)[6];
  V v_hd_2453 = heff_env(self)[7];
  V v_k_2454 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2455);
  V v_wanted_2456 = heff_dup(heff_rfield(v_d_244, 1));
  V v_t_2463 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam16, 1, 1, (V[]){v_wanted_2456}), v_apps_246));
  V v_c_2464 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = heff_dup(v_clock_241); V a_2 = heff_dup(v_ex_242); V a_3 = v_st_243; V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = NTAG(TAG_Nil); V a_7 = v_t_2463; V r_ = (g_heff_2ebuild_2edev_2eheld_24s346027070x1793118273(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_stamp_245); r_; });
  V f_ = v_c_2464;
  heff_room[0] = heff_dup(v_hd_2453);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam17, 1, 6, (V[]){v_prog_240, v_clock_241, v_ex_242, v_st_243, v_hd_2453, v_k_2454});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam14(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k_2454 = args[1];
  V v_c_2452 = heff_env(self)[0];
  V v_d_244 = heff_env(self)[1];
  V v_apps_246 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_clock_241 = heff_env(self)[4];
  V v_ex_242 = heff_env(self)[5];
  V v_st_243 = heff_env(self)[6];
  V v_stamp_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2452;
  args[0] = heff_dup(v_hd_2453);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244_lam15, 1, 9, (V[]){v_d_244, v_apps_246, v_prog_240, v_clock_241, v_ex_242, v_st_243, v_stamp_245, v_hd_2453, v_k_2454});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str2, 59, "heff dev: no package.hf here: run it at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str5, 4, "8000");
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam0, 3, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam3, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_entry, 6, 0};

V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363(V v_prog_240, V v_clock_241, V v_ex_242, V v_wanted_243, V v_port_244, V v_proxy_245) {
top: ;
  V v_path_246 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_247 = ({ V a_0 = v_path_246; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_246); r_; });
  V v_c_2411 = heff_tr(heff_call(v_c_247, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam1, 2, 7, (V[]){v_c_2411, heff_dup(v_port_244), v_wanted_243, v_proxy_245, v_prog_240, v_clock_241, v_ex_242});
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_249 = args[1];
  V v_k_2410 = args[2];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam3(V self, V *args) {
  V v_s_2415 = args[0];
  return v_s_2415;
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_hd_2412, v_k_2413));
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam8(V self, V *args) {
  V v_x_2454 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_st_2425 = heff_env(self)[3];
  V v_hd_2412 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_dev_2455 = heff_take_field(v_x_2454, 0);
  V v_stamp_2456 = heff_take_field(v_x_2454, 2);
  V v_apps_2457 = heff_get_n(v_x_2454, 1, 3);
  V v_t_2458 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_2425; V a_4 = v_dev_2455; V a_5 = v_stamp_2456; V a_6 = v_apps_2457; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_2425); heff_drop(v_stamp_2456); r_; });
  V f_ = v_t_2458;
  heff_room[0] = v_hd_2412;
  heff_room[1] = v_k_2413;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam7(V self, V *args) {
  V v_x_2452 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_st_2425 = heff_env(self)[2];
  V v_d_2451 = heff_env(self)[3];
  V v_x_2448 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_ex_242 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2452)) {
  case TAG_Nothing: {
    V v_c_2453 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = heff_dup(v_clock_241); V a_2 = v_st_2425; V a_3 = v_d_2451; V a_4 = v_x_2448; V a_5 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2edev_2ewatched_24s354779282x304972634(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2448); r_; });
    V f_ = v_c_2453;
    heff_room[0] = heff_dup(v_hd_2412);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam8, 1, 6, (V[]){v_prog_240, v_clock_241, v_ex_242, v_st_2425, v_hd_2412, v_k_2413});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_apps_2459 = heff_field(v_x_2452, 0);
    heff_take_n(v_x_2452, 1ULL, 1);
    V v_t_2460 = ({ V rv_0 = MK_INT(1LL); V rr_ = heff_rec_reuse_nf(v_d_2451, 30ULL, 5, shape_builds__wanted__port__proxy__pages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2461 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_2425; V a_4 = v_t_2460; V a_5 = v_x_2448; V a_6 = v_apps_2459; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1145260848x984331244(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_2425); heff_drop(v_x_2448); r_; });
    V f_ = v_t_2461;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2452);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_port_244 = heff_env(self)[0];
  V v_wanted_243 = heff_env(self)[1];
  V v_proxy_245 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_st_2425 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_clock_241 = heff_env(self)[6];
  V v_ex_242 = heff_env(self)[7];
  V v_k_2413 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x_2448;
  switch (heff_tag_of(v_x_2445)) {
  case TAG_Nil: {
    v_x_2448 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2446 = heff_field(v_x_2445, 0);
    V v_xs_2447 = heff_field(v_x_2445, 1);
    heff_take_n(v_x_2445, 3ULL, 2);
    v_x_2448 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str4); V a_1 = v_x_2446; V a_2 = v_xs_2447; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2447); r_; });
    break;
  }
  default: heff_nomatch(v_x_2445);
  }
  V v_t_2450;
  switch (heff_tag_of(v_port_244)) {
  case TAG_Nothing: {
    v_t_2450 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str5);
    break;
  }
  case TAG_Just: {
    V v_x_2449 = heff_field(v_port_244, 0);
    heff_take_n(v_port_244, 1ULL, 1);
    v_t_2450 = v_x_2449;
    break;
  }
  default: heff_nomatch(v_port_244);
  }
  V v_d_2451 = heff_rec_n(5, shape_builds__wanted__port__proxy__pages, (V[]){MK_INT(0LL), v_wanted_243, v_t_2450, v_proxy_245, NTAG(TAG_False)});
  return ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_2425; V a_2 = heff_dup(v_hd_2412); V a_3 = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam7, 1, 8, (V[]){v_prog_240, v_clock_241, heff_dup(v_st_2425), v_d_2451, v_x_2448, v_hd_2412, v_ex_242, v_k_2413}); V r_ = (g_heff_2ebuild_2edev_2erebuilt_24s41941369x1244703140(a_0, a_1, a_2, a_3)); heff_drop(v_st_2425); r_; });
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  V v_port_244 = heff_env(self)[3];
  V v_wanted_243 = heff_env(self)[4];
  V v_proxy_245 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_clock_241 = heff_env(self)[7];
  V v_ex_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_st_2425;
  if (heff_strEq_c(v_x_2424, ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str1))) {
    v_st_2425 = NTAG(TAG_Windows);
  } else {
    v_st_2425 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 0ULL, 1);
    heff_drop(v_port_244);
    heff_drop(v_wanted_243);
    heff_drop(v_proxy_245);
    heff_drop(v_prog_240);
    heff_drop(v_clock_241);
    heff_drop(v_ex_242);
    heff_drop(v_st_2425);
    V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_str2), NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag_at_n(v_ru_24x_2414_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})}));
    V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
    heff_room[0] = v_t_2434;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam5, 1, 2, (V[]){v_hd_2412, v_k_2413});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2414, 0ULL, 1);
    V v_c_2444 = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(v_st_2425, NTAG(TAG_Nil), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
    V f_ = v_c_2444;
    heff_room[0] = heff_dup(v_hd_2412);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam6, 1, 9, (V[]){v_port_244, v_wanted_243, v_proxy_245, v_prog_240, v_st_2425, v_hd_2412, v_clock_241, v_ex_242, v_k_2413});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  V v_port_244 = heff_env(self)[2];
  V v_wanted_243 = heff_env(self)[3];
  V v_proxy_245 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_clock_241 = heff_env(self)[6];
  V v_ex_242 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam3_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){v_t_2422}));
  V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
  heff_room[0] = v_t_2423;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam4, 1, 9, (V[]){v_x_2414, v_hd_2412, v_k_2413, v_port_244, v_wanted_243, v_proxy_245, v_prog_240, v_clock_241, v_ex_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_port_244 = heff_env(self)[1];
  V v_wanted_243 = heff_env(self)[2];
  V v_proxy_245 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_clock_241 = heff_env(self)[5];
  V v_ex_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1343929477x1508085363_lam2, 1, 8, (V[]){v_hd_2412, v_k_2413, v_port_244, v_wanted_243, v_proxy_245, v_prog_240, v_clock_241, v_ex_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}