// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Exit 20279
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_MkWith 3751
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_TryWait 64330
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_body 9524841
#define LBL_builds 569118448
#define LBL_command 1182252425
#define LBL_dev 308879
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_group 299987609
#define LBL_headers 1027165638
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_stamp 311115741
#define LBL_status 1054660381
#define LBL_timeout 1065429926
#define LBL_wanted 1152016858
static uint32_t shape_builds__wanted__port__proxy__pages[] = {LBL_builds, LBL_wanted, LBL_port, LBL_proxy, LBL_pages};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_name__ended[] = {LBL_name, LBL_ended};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038(V, V, V, V, V);
V g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546(V, V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_clo;
V g_heff_2ebuild_2edev_2efileAnswer(V, V);
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efileAnswer_clo;
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784(V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_clo;
V g_heff_2ebuild_2edev_2epageAnswer(V, V, V);
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epageAnswer_clo;
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374(V, V, V, V);
V g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374_clo;
V g_heff_2ebuild_2edev_2ereloadScript_get(void);
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644(V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s1454779957x1076453187(V, V, V);
V g_std_2eprocess_2ewithProcess_24s1454779957x1076453187_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1454779957x1076453187_clo;
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str0, 9, "</script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str1, 10, "  }, 500);");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str2, 5, "})();");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str3, 98, "      .then(function (t) { if (seen === null) seen = t; else if (t !== seen) location.reload(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str4, 29, "      .catch(function () {});");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str5, 48, "    fetch(\"/.heff/built\", { cache: \"no-store\" })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str6, 46, "      .then(function (r) { return r.text(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str7, 18, "  var seen = null;");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str8, 27, "  setInterval(function () {");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str10, 8, "<script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str11, 14, "(function () {");

static V g_heff_2ebuild_2edev_2ereloadScript_val;
static HEFF_ONCE g_heff_2ebuild_2edev_2ereloadScript_st;
static V g_heff_2ebuild_2edev_2ereloadScript_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str9); V a_1 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str10); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str11), v_t_244}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2edev_2ereloadScript_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2edev_2ereloadScript_st)) return g_heff_2ebuild_2edev_2ereloadScript_val;
  return heff_global(&g_heff_2ebuild_2edev_2ereloadScript_val, &g_heff_2ebuild_2edev_2ereloadScript_st, g_heff_2ebuild_2edev_2ereloadScript_init);
}
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str2, 3, "no ");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str4, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str5, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str6, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2efileAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efileAnswer_entry, 2, 0};

V g_heff_2ebuild_2edev_2efileAnswer(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str0), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str1)}), NTAG(TAG_Nil)});
    V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2efileAnswer_str2), v_p_240), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str3));
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_242, heff_bytesFromString(v_t_243)});
  }
  case TAG_Just: {
    V v_text_244 = heff_field(v_x2_241, 0);
    V v_kind_245 = ({ V a_0 = v_p_240; V r_ = (g_heff_2ebuild_2edev_2etypeOf(a_0)); heff_drop(v_p_240); r_; });
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str4), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str5)}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str6), v_kind_245}), v_t_246});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_247, heff_bytesFromString(heff_dup(v_text_244))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2efileAnswer(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str1, 35, "<head><meta charset=\"utf-8\"><title>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str2, 15, "</title></head>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str3, 9, "<div id=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str4, 8, "\"></div>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str5, 33, "<!doctype html>\012<html lang=\"en\">\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str7, 6, "<body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str10, 13, "<script src=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str11, 14, ".js\"></script>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str12, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str13, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str15, 7, "</html>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str16, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str17, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str18, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str19, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str20, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str21, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str22, 8, "no page ");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str23, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str24, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str25, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str26, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str27, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str28, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2epageAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epageAnswer_entry, 3, 0};

V g_heff_2ebuild_2edev_2epageAnswer(V v_name_240, V v_built_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    if ((heff_dup(v_built_241) == NTAG(TAG_True))) {
      V v_kind_243 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str0); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
      V v_name_244 = v_name_240;
      V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str1), heff_dup(v_name_244)), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str2));
      V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str3), heff_dup(v_name_244)), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str4));
      V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str5), v_t_245), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str6));
      V v_t_248 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2edev_2epageAnswer_str7)), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str8));
      V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, v_t_246), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str9));
      V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str10), v_name_244), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str11));
      V v_t_2411 = heff_strAppend(heff_strAppend(v_t_249, v_t_2410), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str12));
      V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2edev_2epageAnswer_str13)), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str14));
      V v_html_2413 = heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2edev_2epageAnswer_str15));
      V v_j_2414 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str16), v_html_2413, MK_INT(0LL), 5);
      V v_text_2417;
      if (heff_intLt_c_lent(v_j_2414, MK_INT(0LL), 2)) {
        heff_drop(v_j_2414);
        v_text_2417 = heff_strAppend(v_html_2413, heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
      } else {
        V v_t_2415 = heff_strAppend(heff_strSlice_lent(v_html_2413, MK_INT(0LL), v_j_2414, 2), heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
        V v_t_2416 = heff_strSlice(heff_dup(v_html_2413), v_j_2414, heff_strLength(v_html_2413));
        v_text_2417 = heff_strAppend(v_t_2415, v_t_2416);
      }
      V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str17), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str18)}), NTAG(TAG_Nil)});
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str19), v_kind_243}), v_t_2418});
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2419, heff_bytesFromString(v_text_2417)});
    } else {
      V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str20), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str21)}), NTAG(TAG_Nil)});
      V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str22), v_name_240), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str23));
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2420, heff_bytesFromString(v_t_2421)});
    }
  }
  case TAG_Just: {
    V v_html_2422 = heff_field(v_x3_242, 0);
    heff_drop(v_name_240);
    V v_kind_2423 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str24); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
    V v_j_2424 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str25), v_html_2422, MK_INT(0LL), 5);
    V v_text_2427;
    if (heff_intLt_c_lent(v_j_2424, MK_INT(0LL), 2)) {
      heff_drop(v_j_2424);
      v_text_2427 = heff_strAppend(heff_dup(v_html_2422), heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
    } else {
      V v_t_2425 = heff_strAppend(heff_strSlice_lent(v_html_2422, MK_INT(0LL), v_j_2424, 2), heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
      V v_t_2426 = heff_strSlice(heff_dup(v_html_2422), v_j_2424, heff_strLength_lent(v_html_2422, 0));
      v_text_2427 = heff_strAppend(v_t_2425, v_t_2426);
    }
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str26), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str27)}), NTAG(TAG_Nil)});
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str28), v_kind_2423}), v_t_2428});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2429, heff_bytesFromString(v_text_2427)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2edev_2epageAnswer(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_str2, 4, ".exe");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_str5, 21, "heff dev: cannot run ");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_str6, 1, "\012");
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam1, 1, 0};
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam6(V self, V *args);
Clo g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_entry, 6, 0};

V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784(V v_e_240, V v_st_241, V v_d_242, V v_stamp_243, V v_running_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nil: {
    return heff_tail(((V)&g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315_clo), 5, (V[]){v_e_240, v_st_241, v_d_242, v_stamp_243, v_running_244});
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x5_245, 0);
    V v_rest_247 = heff_field(v_x5_245, 1);
    heff_take_n(v_x5_245, 3ULL, 2);
    V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_str0)));
    V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_str1)));
    V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
    V v_a_2411 = ({ V a_0 = v_st_241; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
    V v_n_2412 = heff_dup(heff_rfield(v_a_246, 0));
    V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_a_2411));
    V v_t_2414;
    switch (heff_tag_of(v_st_241)) {
    case TAG_Posix: {
      v_t_2414 = v_n_2412;
      break;
    }
    case TAG_Windows: {
      v_t_2414 = heff_strAppend(v_n_2412, ((V)&g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_str2));
      break;
    }
    default: heff_nomatch(v_st_241);
    }
    V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_t_2414));
    V v_t_2416 = (g_std_2epath_2ejoin(v_t_2413, v_t_2415));
    V v_program_2417 = ({ V a_0 = v_st_241; V a_1 = v_t_2416; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_program_2417, NTAG(TAG_Nil), heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_c_2444 = (g_std_2eprocess_2ewithProcess_24s1454779957x1076453187(heff_dup(v_e_240), v_t_2418, heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam0, 1, 7, (V[]){heff_dup(v_e_240), v_a_246, heff_dup(v_running_244), heff_dup(v_st_241), heff_dup(v_d_242), heff_dup(v_stamp_243), heff_dup(v_rest_247)})));
    return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam6, 2, 7, (V[]){v_c_2444, v_e_240, v_st_241, v_d_242, v_stamp_243, v_running_244, v_rest_247});
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam1(V self, V *args) {
  V v_r_2422 = args[0];
  return v_r_2422;
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam5(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_2442 = args[1];
  V v_k_2443 = args[2];
  V v_x_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2441);
  heff_drop(v_hd_2442);
  V f_ = v_k_2443;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam4(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_2439 = args[1];
  V v_k_2440 = args[2];
  V v_x_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2438);
  heff_drop(v_hd_2439);
  V f_ = v_k_2440;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam5, 3, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam3(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2436;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam4, 3, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam2(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam3, 1, 1, (V[]){v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam0(V self, V *args) {
  V v_p_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  V v_running_244 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_stamp_243 = heff_env(self)[5];
  V v_rest_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2421;
  switch (heff_tag_of(v_p_2419)) {
  case TAG_MkWith: {
    V v_x_2420 = heff_field(v_p_2419, 0);
    heff_take_n(v_p_2419, 1ULL, 1);
    v_t_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_p_2419);
  }
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_TryWait, 2, (V[]){v_t_2421, ((V)&g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam1_clo)})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_e_240), v_t_2429}));
  V v_t_2431 = heff_rec_n(2, shape_name__ended, (V[]){heff_get_n(v_a_246, 0, 2), v_t_2430});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
  V v_t_2433 = (g_prelude_2e_2b_2b(v_running_244, v_t_2432));
  V v_c_2434 = heff_tr(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784(v_e_240, v_st_241, v_d_242, v_stamp_243, v_t_2433, v_rest_247));
  return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam2, 2, 1, (V[]){v_c_2434});
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_hd_2447 = heff_env(self)[0];
  V v_k_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2449;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2447;
  heff_room[2] = v_k_2448;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam7(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2444;
  args[0] = heff_dup(v_hd_2447);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam8, 1, 2, (V[]){v_hd_2447, v_k_2448});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam12(V self, V *args) {
  V v_x_2469 = args[0];
  V v_hd_2470 = args[1];
  V v_k_2471 = args[2];
  V v_x_2468 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2469);
  heff_drop(v_hd_2470);
  V f_ = v_k_2471;
  args[0] = v_x_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam11(V self, V *args) {
  V v_x_2468 = args[0];
  V v_k_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2452;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam12, 3, 1, (V[]){v_x_2468});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam10(V self, V *args) {
  V v_x_2466 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_stamp_243 = heff_env(self)[3];
  V v_running_244 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  V v_hd_2451 = heff_env(self)[6];
  V v_k_2452 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2466);
  V v_c_2467 = heff_tr(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784(v_e_240, v_st_241, v_d_242, v_stamp_243, v_running_244, v_rest_247));
  V f_ = v_c_2467;
  heff_room[0] = v_hd_2451;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam11, 1, 1, (V[]){v_k_2452});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam9(V self, V *args) {
  V v_err_2450 = args[0];
  V v_hd_2451 = args[1];
  V v_k_2452 = args[2];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_stamp_243 = heff_env(self)[3];
  V v_running_244 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_path_2453 = heff_take_field(v_err_2450, 3);
  V v_name_2454 = heff_take_field(v_err_2450, 1);
  V v_message_2455 = heff_get_n(v_err_2450, 2, 4);
  V v_t_2456 = heff_strAppend(heff_strAppend(v_path_2453, ((V)&g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_str3)), v_name_2454);
  V v_t_2457 = heff_strAppend(heff_strAppend(v_t_2456, ((V)&g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_str4)), v_message_2455);
  V v_t_2458 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_str5), v_t_2457), ((V)&g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_str6));
  V v_t_2459 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2458, NTAG(TAG_MkUnit)});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2465}), heff_dup(v_hd_2451), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam10, 1, 8, (V[]){v_e_240, v_st_241, v_d_242, v_stamp_243, v_running_244, v_rest_247, v_hd_2451, v_k_2452})));
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam13(V self, V *args) {
  V v_x_2473 = args[0];
  V v_hd_2445 = heff_env(self)[0];
  V v_k_2446 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2473;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2445;
  heff_room[2] = v_k_2446;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam6(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_c_2444 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_stamp_243 = heff_env(self)[4];
  V v_running_244 = heff_env(self)[5];
  V v_rest_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam7, 2, 1, (V[]){v_c_2444}), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam9, 3, 6, (V[]){heff_dup(v_e_240), v_st_241, v_d_242, v_stamp_243, v_running_244, v_rest_247})})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2472}), heff_dup(v_hd_2445), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1507218150x201324784_lam13, 1, 2, (V[]){v_hd_2445, v_k_2446})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_str2, 59, "heff dev: no package.hf here: run it at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_str5, 4, "8000");
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam0, 3, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam3, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_entry, 4, 0};

V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546(V v_e_240, V v_wanted_241, V v_port_242, V v_proxy_243) {
top: ;
  V v_path_244 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_str0)));
  V v_c_245 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_244; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_244); r_; });
  V v_t_246 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2410 = heff_tr(heff_call(v_c_245, 2, (V[]){v_t_246, ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam1, 2, 5, (V[]){v_c_2410, v_e_240, heff_dup(v_port_242), v_wanted_241, v_proxy_243});
}
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_248 = args[1];
  V v_k_249 = args[2];
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam3(V self, V *args) {
  V v_s_2414 = args[0];
  return v_s_2414;
}
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2432);
  V v_t_2433 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_hd_2411, v_k_2412));
}
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam8(V self, V *args) {
  V v_x_2450 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_2423 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_dev_2451 = heff_take_field(v_x_2450, 0);
  V v_stamp_2452 = heff_take_field(v_x_2450, 2);
  V v_apps_2453 = heff_get_n(v_x_2450, 1, 3);
  V v_t_2454 = (g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038(v_e_240, v_st_2423, v_dev_2451, v_stamp_2452, v_apps_2453));
  V f_ = v_t_2454;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_2423 = heff_env(self)[1];
  V v_d_2448 = heff_env(self)[2];
  V v_x_2445 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Nothing: {
    return ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_st_2423); V a_2 = v_d_2448; V a_3 = v_x_2445; V a_4 = NTAG(TAG_Nil); V a_5 = heff_dup(v_hd_2411); V a_6 = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam8, 1, 4, (V[]){v_e_240, v_st_2423, v_hd_2411, v_k_2412}); V r_ = (g_heff_2ebuild_2edev_2ewatched_24s1171079935x1661540315(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2445); r_; });
  }
  case TAG_Just: {
    V v_apps_2455 = heff_field(v_x_2449, 0);
    heff_take_n(v_x_2449, 1ULL, 1);
    V v_t_2456 = ({ V rv_0 = MK_INT(1LL); V rr_ = heff_rec_reuse_nf(v_d_2448, 30ULL, 5, shape_builds__wanted__port__proxy__pages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2457 = (g_heff_2ebuild_2edev_2ecycle_24s1752734360x358915038(v_e_240, v_st_2423, v_t_2456, v_x_2445, v_apps_2455));
    V f_ = v_t_2457;
    heff_room[0] = v_hd_2411;
    heff_room[1] = v_k_2412;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2449);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam6(V self, V *args) {
  V v_x_2442 = args[0];
  V v_port_242 = heff_env(self)[0];
  V v_wanted_241 = heff_env(self)[1];
  V v_proxy_243 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_st_2423 = heff_env(self)[4];
  V v_hd_2411 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x_2445;
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Nil: {
    v_x_2445 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2443 = heff_field(v_x_2442, 0);
    V v_xs_2444 = heff_field(v_x_2442, 1);
    heff_take_n(v_x_2442, 3ULL, 2);
    v_x_2445 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_str4); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
    break;
  }
  default: heff_nomatch(v_x_2442);
  }
  V v_t_2447;
  switch (heff_tag_of(v_port_242)) {
  case TAG_Nothing: {
    v_t_2447 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_str5);
    break;
  }
  case TAG_Just: {
    V v_x_2446 = heff_field(v_port_242, 0);
    heff_take_n(v_port_242, 1ULL, 1);
    v_t_2447 = v_x_2446;
    break;
  }
  default: heff_nomatch(v_port_242);
  }
  V v_d_2448 = heff_rec_n(5, shape_builds__wanted__port__proxy__pages, (V[]){MK_INT(0LL), v_wanted_241, v_t_2447, v_proxy_243, NTAG(TAG_False)});
  return (g_heff_2ebuild_2edev_2erebuilt_24s1623446834x1195748374(heff_dup(v_e_240), heff_dup(v_st_2423), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam7, 1, 6, (V[]){v_e_240, v_st_2423, v_d_2448, v_x_2445, v_hd_2411, v_k_2412})));
}
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  V v_port_242 = heff_env(self)[4];
  V v_wanted_241 = heff_env(self)[5];
  V v_proxy_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2423;
  if (heff_strEq_c(v_x_2422, ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_str1))) {
    v_st_2423 = NTAG(TAG_Windows);
  } else {
    v_st_2423 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 0ULL, 1);
    heff_drop(v_port_242);
    heff_drop(v_wanted_241);
    heff_drop(v_proxy_243);
    heff_drop(v_st_2423);
    V v_t_2425 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_str2), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_at_n(v_ru_24x_2413_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam5, 1, 3, (V[]){v_e_240, v_hd_2411, v_k_2412})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2413, 0ULL, 1);
    V v_c_2441 = (g_heff_2ebuild_2ewatch_2estamps_24s684575078x514449644(heff_dup(v_e_240), heff_dup(v_st_2423), NTAG(TAG_Nil), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
    V f_ = v_c_2441;
    heff_room[0] = heff_dup(v_hd_2411);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam6, 1, 7, (V[]){v_port_242, v_wanted_241, v_proxy_243, v_e_240, v_st_2423, v_hd_2411, v_k_2412});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  V v_port_242 = heff_env(self)[3];
  V v_wanted_241 = heff_env(self)[4];
  V v_proxy_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam3_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2421, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam4, 1, 7, (V[]){v_x_2413, v_e_240, v_hd_2411, v_k_2412, v_port_242, v_wanted_241, v_proxy_243})));
}
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_port_242 = heff_env(self)[2];
  V v_wanted_241 = heff_env(self)[3];
  V v_proxy_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_lam2, 1, 6, (V[]){v_e_240, v_hd_2411, v_k_2412, v_port_242, v_wanted_241, v_proxy_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}