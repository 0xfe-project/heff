// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_Main 39920
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_body 9524841
#define LBL_build 295453320
#define LBL_builds 569118448
#define LBL_chans 295981947
#define LBL_code 9554612
#define LBL_command 1182252425
#define LBL_dev 308879
#define LBL_dir 308999
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_follow 678183644
#define LBL_group 299987609
#define LBL_headers 1027165638
#define LBL_host 9704047
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_message 1186782793
#define LBL_method 869586956
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_pending 1696753626
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_ready 309745085
#define LBL_stamp 311115741
#define LBL_status 1054660381
#define LBL_target 1066236092
#define LBL_timeout 1065429926
#define LBL_turns 312085424
#define LBL_url 325609
#define LBL_waiting 1348170899
#define LBL_wanted 1152016858
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_builds__wanted__port__proxy__pages[] = {LBL_builds, LBL_wanted, LBL_port, LBL_proxy, LBL_pages};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_host__port[] = {LBL_host, LBL_port};
static uint32_t shape_ready__chans__waiting__next__pending__turns[] = {LBL_ready, LBL_chans, LBL_waiting, LBL_next, LBL_pending, LBL_turns};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
static uint32_t shape_url__method__headers__body__timeout__follow[] = {LBL_url, LBL_method, LBL_headers, LBL_body, LBL_timeout, LBL_follow};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s310418905x1614124229(V, V, V);
V g_co_2eop_24s310418905x1614124229_entry(V self, V *a);
extern Clo g_co_2eop_24s310418905x1614124229_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_green_2eemptyQ_get(void);
V g_green_2ego_24s850908287x1133196696(V, V, V, V);
V g_green_2ego_24s850908287x1133196696_entry(V self, V *a);
extern Clo g_green_2ego_24s850908287x1133196696_clo;
V g_green_2eview_24s192594942x2076863488(V);
V g_green_2eview_24s192594942x2076863488_entry(V self, V *a);
extern Clo g_green_2eview_24s192594942x2076863488_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957(V, V);
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_clo;
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196(V, V, V);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_clo;
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_clo;
V g_heff_2ebuild_2edev_2efileAnswer(V, V);
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efileAnswer_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_clo;
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_clo;
V g_heff_2ebuild_2edev_2eindexAnswer(V);
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eindexAnswer_clo;
V g_heff_2ebuild_2edev_2emadePage(V);
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2emadePage_clo;
V g_heff_2ebuild_2edev_2epageAnswer(V, V, V);
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epageAnswer_clo;
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_clo;
V g_heff_2ebuild_2edev_2erelayed(V, V);
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erelayed_clo;
V g_heff_2ebuild_2edev_2ereloadScript_get(void);
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958(V, V, V, V);
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s105899861x584770213(V);
V g_list_2eany_24s105899861x584770213_entry(V self, V *a);
extern Clo g_list_2eany_24s105899861x584770213_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s2044822566x1809079154(V, V, V, V, V, V);
V g_list_2ekeepIf_24s2044822566x1809079154_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2044822566x1809079154_clo;
V g_list_2emap_24f1297529223x1960372761(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1297529223x1960372761_entry(V self, V *a);
extern Clo g_list_2emap_24f1297529223x1960372761_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s729664635x1487989391(V, V, V);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s729664635x1487989391_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s729664635x1487989391_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2enet_2ewithListener_24s1242722304x1501661027(V, V, V, V, V);
V g_std_2enet_2ewithListener_24s1242722304x1501661027_entry(V self, V *a);
extern Clo g_std_2enet_2ewithListener_24s1242722304x1501661027_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s1854160028x1916200928(V, V, V);
V g_std_2eprocess_2ewithProcess_24s1854160028x1916200928_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1854160028x1916200928_clo;
V g_std_2eprogress_2eroot_get(void);
V g_std_2ereactor_2eoutside_24s283078862x396680432(V);
V g_std_2ereactor_2eoutside_24s283078862x396680432_entry(V self, V *a);
extern Clo g_std_2ereactor_2eoutside_24s283078862x396680432_clo;
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str0, 9, "</script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str1, 10, "  }, 500);");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str2, 5, "})();");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str3, 98, "      .then(function (t) { if (seen === null) seen = t; else if (t !== seen) location.reload(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str4, 29, "      .catch(function () {});");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str5, 48, "    fetch(\"/.heff/built\", { cache: \"no-store\" })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str6, 46, "      .then(function (r) { return r.text(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str7, 18, "  var seen = null;");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str8, 27, "  setInterval(function () {");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str10, 8, "<script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str11, 14, "(function () {");

static V g_heff_2ebuild_2edev_2ereloadScript_val;
static HEFF_ONCE g_heff_2ebuild_2edev_2ereloadScript_st;
static V g_heff_2ebuild_2edev_2ereloadScript_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str9); V a_1 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str10); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str11), v_t_244}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2edev_2ereloadScript_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2edev_2ereloadScript_st)) return g_heff_2ebuild_2edev_2ereloadScript_val;
  return heff_global(&g_heff_2ebuild_2edev_2ereloadScript_val, &g_heff_2ebuild_2edev_2ereloadScript_st, g_heff_2ebuild_2edev_2ereloadScript_init);
}
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str2, 3, "no ");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str4, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str5, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str6, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2efileAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efileAnswer_entry, 2, 0};

V g_heff_2ebuild_2edev_2efileAnswer(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str0), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str1)}), NTAG(TAG_Nil)});
    V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2efileAnswer_str2), heff_strAppend(v_p_240, ((V)&g_heff_2ebuild_2edev_2efileAnswer_str3)));
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_242, heff_bytesFromString(v_t_243)});
  }
  case TAG_Just: {
    V v_text_244 = heff_field(v_x2_241, 0);
    V v_kind_245 = ({ V a_0 = v_p_240; V r_ = (g_heff_2ebuild_2edev_2etypeOf(a_0)); heff_drop(v_p_240); r_; });
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str4), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str5)}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str6), v_kind_245}), v_t_246});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_247, heff_bytesFromString(heff_dup(v_text_244))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2efileAnswer(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str1, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str2, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str3, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str4, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str5, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str6, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str7, 8, "no page ");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str9, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str10, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str11, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str12, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str13, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2epageAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epageAnswer_entry, 3, 0};

V g_heff_2ebuild_2edev_2epageAnswer(V v_name_240, V v_built_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    if ((heff_dup(v_built_241) == NTAG(TAG_True))) {
      V v_kind_243 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str0); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
      V v_html_244 = (g_heff_2ebuild_2edev_2emadePage(v_name_240));
      V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str1), v_html_244, MK_INT(0LL), 5);
      V v_text_248;
      if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
        heff_drop(v_j_245);
        v_text_248 = heff_strAppend(v_html_244, heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
      } else {
        V v_t_247 = heff_strSlice(heff_dup(v_html_244), heff_dup(v_j_245), heff_strLength_lent(v_html_244, 0));
        v_text_248 = heff_strAppend(heff_strSlice(v_html_244, MK_INT(0LL), v_j_245), heff_strAppend(heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), v_t_247));
      }
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str2), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str3)}), NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str4), v_kind_243}), v_t_249});
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2410, heff_bytesFromString(v_text_248)});
    } else {
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str5), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str6)}), NTAG(TAG_Nil)});
      V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str7), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2edev_2epageAnswer_str8)));
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2411, heff_bytesFromString(v_t_2412)});
    }
  }
  case TAG_Just: {
    V v_html_2413 = heff_field(v_x3_242, 0);
    heff_drop(v_name_240);
    V v_kind_2414 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str9); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
    V v_j_2415 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str10), v_html_2413, MK_INT(0LL), 5);
    V v_text_2418;
    if (heff_intLt_c_lent(v_j_2415, MK_INT(0LL), 2)) {
      heff_drop(v_j_2415);
      v_text_2418 = heff_strAppend(heff_dup(v_html_2413), heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
    } else {
      V v_t_2417 = heff_strSlice(heff_dup(v_html_2413), heff_dup(v_j_2415), heff_strLength_lent(v_html_2413, 0));
      v_text_2418 = heff_strAppend(heff_strSlice_lent(v_html_2413, MK_INT(0LL), v_j_2415, 6), heff_strAppend(heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), v_t_2417));
    }
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str11), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str12)}), NTAG(TAG_Nil)});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str13), v_kind_2414}), v_t_2419});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2420, heff_bytesFromString(v_text_2418)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2edev_2epageAnswer(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str1, 4, "<ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str2, 23, "<title>heff dev</title>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str3, 18, "<h1>the pages</h1>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str4, 14, "<li><a href=\"/");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str5, 3, "/\">");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str6, 9, "</a></li>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str7, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str8, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str9, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str10, 5, "</ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str11, 15, "<!doctype html>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str14, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str15, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str16, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2eindexAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eindexAnswer_entry, 1, 0};

V g_heff_2ebuild_2edev_2eindexAnswer(V v_found_240) {
top: ;
  V v_kind_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str0); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str1), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str3), v_t_242})});
  V v_t_245;
  switch (heff_tag_of(v_found_240)) {
  case TAG_Nothing: {
    v_t_245 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_found_240, 0);
    v_t_245 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_found_240);
  }
  V v_t_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str4); V b_1 = MK_INT(0LL); V a_2 = MK_INT(3LL); V a_3 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str5); V b_4 = MK_INT(0LL); V a_5 = MK_INT(3LL); V a_6 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str6); V b_7 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str7); V b_8 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str8); V b_9 = MK_INT(0LL); V b_10 = MK_INT(1LL); V b_11 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str9); V a_12 = v_t_245; V r_ = (g_list_2emap_24f1297529223x1960372761(a_0, b_1, a_2, a_3, b_4, a_5, a_6, b_7, b_8, b_9, b_10, b_11, a_12)); heff_drop(b_1); heff_drop(b_4); heff_drop(b_7); heff_drop(b_8); heff_drop(b_9); heff_drop(b_10); heff_drop(b_11); r_; });
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), NTAG(TAG_Nil)});
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str10), v_t_247})));
  V v_xs_249 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str11), v_t_243}), v_t_248));
  V v_text_2412;
  switch (heff_tag_of(v_xs_249)) {
  case TAG_Nil: {
    v_text_2412 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_xs_249, 0);
    V v_xs_2411 = heff_field(v_xs_249, 1);
    heff_take_n(v_xs_249, 3ULL, 2);
    v_text_2412 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str13); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_xs_249);
  }
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str14), ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str15)}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str16), v_kind_241}), v_t_2413});
  return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2414, heff_bytesFromString(v_text_2412)});
}
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eindexAnswer(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str2, 2, ") ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str3, 7, "curl: (");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str6, 23, "heff dev: nothing from ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str7, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str8, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str9, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str10, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str11, 10, "keep-alive");
Clo g_heff_2ebuild_2edev_2erelayed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erelayed_entry, 2, 0};

V g_heff_2ebuild_2edev_2erelayed(V v_to_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Left: {
    V v_err_242 = heff_field(v_x2_241, 0);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erelayed_str0), ((V)&g_heff_2ebuild_2edev_2erelayed_str1)}), NTAG(TAG_Nil)});
    V v_t_244 = heff_intShow(heff_dup(heff_rfield(v_err_242, 0)));
    V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str2), heff_dup(heff_rfield(v_err_242, 1)));
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str3), heff_strAppend(v_t_244, v_t_245));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str4), heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2edev_2erelayed_str5)));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str6), heff_strAppend(v_to_240, v_t_247));
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(502LL), v_t_243, heff_bytesFromString(v_t_248)});
  }
  case TAG_Right: {
    V v_res_249 = heff_field(v_x2_241, 0);
    heff_drop(v_to_240);
    V v_t_2410 = (g_list_2ekeepIf_24s2044822566x1809079154(((V)&g_heff_2ebuild_2edev_2erelayed_str7), ((V)&g_heff_2ebuild_2edev_2erelayed_str8), ((V)&g_heff_2ebuild_2edev_2erelayed_str9), ((V)&g_heff_2ebuild_2edev_2erelayed_str10), ((V)&g_heff_2ebuild_2edev_2erelayed_str11), heff_dup(heff_rfield(v_res_249, 1))));
    return heff_rec_n(3, shape_status__headers__body, (V[]){heff_dup(heff_rfield(v_res_249, 0)), v_t_2410, heff_dup(heff_rfield(v_res_249, 2))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2erelayed(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str1, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str2, 1, ".");
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam3, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_entry, 2, 0};

V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957(V v_prog_240, V v_st_241) {
top: ;
  V v_path_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_242; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_242); r_; });
  V v_a_245 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_243, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam1, 2, 3, (V[]){v_a_245, v_prog_240, heff_dup(v_st_241)});
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam0(V self, V *args) {
  V v_ns_244 = args[0];
  return v_ns_244;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam3(V self, V *args) {
  V v_t_2418 = args[0];
  return v_t_2418;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2426 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  V v_t_2431;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2426, 1)))) {
    heff_drop_rec(v_x_2426, 2);
    v_t_2431 = NTAG(TAG_Nil);
  } else {
    v_t_2431 = heff_get_n(v_x_2426, 0, 2);
  }
  V f_ = v_k_247;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2427 = heff_tag_n(TAG_End, 2, (V[]){v_x_2420, NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2427}));
  return (g_co_2eop_24s495635622x733177935(v_t_2428, v_hd_246, heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam6, 1, 2, (V[]){v_x_2426, v_k_247})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2421 = (g_heff_2ebuild_2ecommands_2ebuildTarget(v_st_241, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str2)));
  V v_t_2422 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2424;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    v_t_2424 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2423 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    v_t_2424 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_c_2425 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_241; V a_2 = v_t_2421; V a_3 = heff_dup(v_x_2420); V a_4 = v_t_2422; V a_5 = v_t_2424; V r_ = (g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_241); r_; });
  V f_ = v_c_2425;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam5, 1, 4, (V[]){v_x_2420, v_prog_240, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_dup(heff_field(v_x_2414, 0));
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_total_2417 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2416; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
  V v_t_2419 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str1), v_total_2417, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam3_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2419, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam4, 1, 5, (V[]){v_st_241, v_x_2414, v_prog_240, v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_245})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s495635622x733177935(v_t_2413, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam2, 1, 4, (V[]){v_prog_240, v_hd_246, v_st_241, v_k_247})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_str0, 9, "dev-pages");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_str1, 33, "heff dev: cannot serve the pages\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_str2, 1, "c");
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam14(V self, V *args);
Clo g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_entry, 7, 0};

V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(V v_prog_240, V v_clock_241, V v_ex_242, V v_st_243, V v_d_244, V v_stamp_245, V v_apps_246) {
top: ;
  V v_t_247 = (g_list_2eany_24s105899861x584770213(v_apps_246));
  V v_t_249 = heff_bool(((heff_dup(v_t_247) == NTAG(TAG_True)) && ({ V v_t_248 = heff_dup(heff_rfield(v_d_244, 4)); int c_ = !(heff_dup(v_t_248) == NTAG(TAG_True)); heff_drop(v_t_248); c_; })));
  heff_drop(v_t_247);
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam0, 2, 7, (V[]){v_d_244, v_ex_242, v_prog_240, v_clock_241, heff_dup(v_st_243), heff_dup(v_stamp_245), v_apps_246});
  } else {
    heff_drop(v_t_249);
    V v_c_2453 = (g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196(v_st_243, heff_dup(v_d_244), heff_dup(v_apps_246)));
    return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam14, 2, 8, (V[]){v_c_2453, v_d_244, v_apps_246, v_prog_240, v_clock_241, v_ex_242, heff_dup(v_st_243), heff_dup(v_stamp_245)});
  }
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a5 = a[5]; V r = g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(a[0], a[1], a[2], a3, a[4], a5, a[6]); heff_drop(a3); heff_drop(a5); return r;
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_2428 = args[1];
  V v_k_2429 = args[2];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2427);
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_2425 = args[1];
  V v_k_2426 = args[2];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2424);
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam6, 3, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2422;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam5, 3, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam4, 1, 1, (V[]){v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam2(V self, V *args) {
  V v_pg_2418 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_pg_2418);
  V v_t_2419 = ({ V rv_4 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_d_244, 15ULL, 5, shape_builds__wanted__port__proxy__pages, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_c_2420 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_t_2419; V a_5 = v_stamp_245; V a_6 = v_apps_246; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam3, 2, 1, (V[]){v_c_2420});
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam8(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_2431 = heff_env(self)[0];
  V v_k_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2433;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2431;
  heff_room[2] = v_k_2432;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam7(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2430;
  args[0] = heff_dup(v_hd_2431);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam8, 1, 2, (V[]){v_hd_2431, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam12(V self, V *args) {
  V v_x_2448 = args[0];
  V v_hd_2449 = args[1];
  V v_k_2450 = args[2];
  V v_x_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2448);
  heff_drop(v_hd_2449);
  V f_ = v_k_2450;
  args[0] = v_x_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam11(V self, V *args) {
  V v_x_2447 = args[0];
  V v_k_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2436;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam12, 3, 1, (V[]){v_x_2447});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam10(V self, V *args) {
  V v_x_2444 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  V v_hd_2435 = heff_env(self)[7];
  V v_k_2436 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2444);
  V v_t_2445 = ({ V rv_4 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_d_244, 15ULL, 5, shape_builds__wanted__port__proxy__pages, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_c_2446 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_t_2445; V a_5 = v_stamp_245; V a_6 = v_apps_246; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  V f_ = v_c_2446;
  heff_room[0] = v_hd_2435;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam11, 1, 1, (V[]){v_k_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam9(V self, V *args) {
  V v_err_2434 = args[0];
  V v_hd_2435 = args[1];
  V v_k_2436 = args[2];
  V v_d_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_err_2434);
  V v_t_2437 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_str1), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), heff_dup(v_hd_2435), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam10, 1, 9, (V[]){v_d_244, v_prog_240, v_clock_241, v_ex_242, v_st_243, v_stamp_245, v_apps_246, v_hd_2435, v_k_2436})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam13(V self, V *args) {
  V v_x_2452 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2452;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2410;
  heff_room[2] = v_k_2411;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_ex_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  V v_hd_2410 = heff_env(self)[7];
  V v_k_2411 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2413 = heff_dup(heff_rfield(v_d_244, 3));
  V v_t_2415;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2414, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_d_244, 2)), v_t_2415});
  V v_t_2417 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2412, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_str0), v_t_2416}), heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_c_2430 = (g_std_2eprocess_2ewithProcess_24s1854160028x1916200928(heff_dup(v_ex_242), v_t_2417, heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam2, 1, 7, (V[]){heff_dup(v_d_244), heff_dup(v_prog_240), heff_dup(v_clock_241), heff_dup(v_ex_242), heff_dup(v_st_243), heff_dup(v_stamp_245), heff_dup(v_apps_246)})));
  V v_t_2451 = heff_tr(heff_call(heff_dup(v_ex_242), 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam7, 2, 1, (V[]){v_c_2430}), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam9, 3, 7, (V[]){v_d_244, v_prog_240, v_clock_241, v_ex_242, v_st_243, v_stamp_245, v_apps_246})})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2451, heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam13, 1, 2, (V[]){v_hd_2410, v_k_2411})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_d_244 = heff_env(self)[0];
  V v_ex_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581(heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam1, 1, 9, (V[]){v_d_244, v_ex_242, v_prog_240, v_clock_241, v_st_243, v_stamp_245, v_apps_246, v_hd_2410, v_k_2411})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam16(V self, V *args) {
  V v_a_2458 = args[0];
  V v_wanted_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2459 = heff_get_n(heff_dup(heff_rfield(v_a_2458, 1)), 0, 3);
  if (heff_strEq_c(v_t_2459, ((V)&g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_str2))) {
    switch (heff_tag_of(v_wanted_2457)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_2458, 2);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_t_2463 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_a_2458, 0, 2)}));
      return ({ V a_0 = v_t_2463; V a_1 = v_wanted_2457; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_wanted_2457, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2457);
    }
  } else {
    heff_drop_rec(v_a_2458, 2);
    heff_drop(v_wanted_2457);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam17(V self, V *args) {
  V v_x_2466 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_st_243 = heff_env(self)[3];
  V v_hd_2454 = heff_env(self)[4];
  V v_k_2455 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2467 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = heff_take_field(v_x_2466, 0); V b_5 = heff_take_field(v_x_2466, 2); V a_6 = heff_get_n(v_x_2466, 1, 3); V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(a_0, a_1, a_2, a_3, a_4, b_5, a_6)); heff_drop(v_st_243); heff_drop(b_5); r_; });
  V f_ = v_t_2467;
  heff_room[0] = v_hd_2454;
  heff_room[1] = v_k_2455;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam15(V self, V *args) {
  V v_x_2456 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_apps_246 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_ex_242 = heff_env(self)[4];
  V v_st_243 = heff_env(self)[5];
  V v_stamp_245 = heff_env(self)[6];
  V v_hd_2454 = heff_env(self)[7];
  V v_k_2455 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2456);
  V v_wanted_2457 = heff_dup(heff_rfield(v_d_244, 1));
  V v_t_2464 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam16, 1, 1, (V[]){v_wanted_2457}), v_apps_246));
  V v_c_2465 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = heff_dup(v_clock_241); V a_2 = heff_dup(v_ex_242); V a_3 = v_st_243; V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = NTAG(TAG_Nil); V a_7 = v_t_2464; V r_ = (g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_stamp_245); r_; });
  V f_ = v_c_2465;
  heff_room[0] = heff_dup(v_hd_2454);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam17, 1, 6, (V[]){v_prog_240, v_clock_241, v_ex_242, v_st_243, v_hd_2454, v_k_2455});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam14(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  V v_c_2453 = heff_env(self)[0];
  V v_d_244 = heff_env(self)[1];
  V v_apps_246 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_clock_241 = heff_env(self)[4];
  V v_ex_242 = heff_env(self)[5];
  V v_st_243 = heff_env(self)[6];
  V v_stamp_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2453;
  args[0] = heff_dup(v_hd_2454);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam15, 1, 9, (V[]){v_d_244, v_apps_246, v_prog_240, v_clock_241, v_ex_242, v_st_243, v_stamp_245, v_hd_2454, v_k_2455});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str0, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str1, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str2, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str3, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str4, 10, "keep-alive");
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_entry, 5, 0};

V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210(V v_web_240, V v_to_241, V v_req_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_strAppend(heff_dup(v_to_241), heff_take_field(v_req_242, 1));
  V v_t_246 = (g_list_2ekeepIf_24s2044822566x1809079154(((V)&g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str0), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str1), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str2), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str3), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str4), heff_take_field(v_req_242, 3)));
  V v_rq_247 = heff_rec_n(6, shape_url__method__headers__body__timeout__follow, (V[]){v_t_245, heff_take_field(v_req_242, 0), v_t_246, heff_get_n(v_req_242, 4, 6), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_249 = heff_tr(heff_call(v_web_240, 1, (V[]){heff_tag_n(TAG_Send, 2, (V[]){v_rq_247, ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam0_clo)})}));
  return (g_co_2eop_24s310418905x1614124229(v_t_249, v_z_243, heff_clo_n(g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam1, 1, 2, (V[]){v_to_241, v_z_244})));
}
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam0(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_to_241 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = ({ V a_0 = v_to_241; V a_1 = v_x_2410; V r_ = (g_heff_2ebuild_2edev_2erelayed(a_0, a_1)); heff_drop(v_x_2410); r_; });
  V f_ = v_z_244;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str0, 9, "127.0.0.1");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str2, 19, ", the rest sent to ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str3, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str4, 40, "heff dev: the pages at http://127.0.0.1:");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str6, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str7, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str9, 41, "heff dev: cannot serve the pages at port ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str10, 1, "\012");
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam0, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam9(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam9, 3, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam8(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam8, 3, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam14(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_entry, 8, 0};

V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740(V v_nt_240, V v_rx_241, V v_web_242, V v_nx_243, V v_port_244, V v_proxy_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s495635622x733177935(v_t_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam1, 1, 8, (V[]){v_port_244, v_nt_240, v_nx_243, v_proxy_245, v_rx_241, v_web_242, v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam5(V self, V *args) {
  V v_p_2442 = args[0];
  V v_web_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443 = heff_tr(heff_call(v_web_242, 1, (V[]){v_p_2442}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2443});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam6(V self, V *args) {
  V v_p_2445 = args[0];
  V v_nt_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_tr(heff_call(v_nt_240, 1, (V[]){v_p_2445}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2446});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_hd_2455 = args[1];
  V v_k_2456 = args[2];
  heff_drop(v_x_2454);
  heff_drop(v_hd_2455);
  V f_ = v_k_2456;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam8(V self, V *args) {
  V v_x_2451 = args[0];
  V v_hd_2452 = args[1];
  V v_k_2453 = args[2];
  heff_drop(v_x_2451);
  heff_drop(v_hd_2452);
  V f_ = v_k_2453;
  args[0] = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam9_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam7(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2450);
  V f_ = v_k_2425;
  args[0] = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam8_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam4(V self, V *args) {
  V v_x_2439 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_web_242 = heff_env(self)[1];
  V v_proxy_245 = heff_env(self)[2];
  V v_nt_240 = heff_env(self)[3];
  V v_listener_2423 = heff_env(self)[4];
  V v_t_2438 = heff_env(self)[5];
  V v_hd_2424 = heff_env(self)[6];
  V v_k_2425 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2441;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str6))) {
    v_t_2441 = NTAG(TAG_Windows);
  } else {
    v_t_2441 = NTAG(TAG_Posix);
  }
  V v_t_2444 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_clo), 3, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam5, 1, 1, (V[]){v_web_242}), v_t_2441, v_proxy_245}));
  V v_t_2447 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam6, 1, 1, (V[]){v_nt_240}); V a_1 = v_listener_2423; V a_2 = v_t_2444; V r_ = heff_tr(g_std_2ehttp_2eserver_2eserveConcurrently_24s729664635x1487989391(a_0, a_1, a_2)); heff_drop(v_listener_2423); r_; });
  V v_t_2448 = (g_green_2eview_24s192594942x2076863488(heff_tag_n(TAG_Main, 1, (V[]){v_t_2447})));
  V v_t_2449 = (g_green_2ego_24s850908287x1133196696(v_t_2438, v_x_2439, heff_rec_n(6, shape_ready__chans__waiting__next__pending__turns, (V[]){heff_dup(g_green_2eemptyQ_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}), v_t_2448));
  V f_ = v_t_2449;
  heff_room[0] = v_hd_2424;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam7, 1, 1, (V[]){v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam3(V self, V *args) {
  V v_x_2437 = args[0];
  V v_rx_241 = heff_env(self)[0];
  V v_hd_2424 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_web_242 = heff_env(self)[3];
  V v_proxy_245 = heff_env(self)[4];
  V v_nt_240 = heff_env(self)[5];
  V v_listener_2423 = heff_env(self)[6];
  V v_k_2425 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2437);
  V v_t_2438 = (g_std_2ereactor_2eoutside_24s283078862x396680432(v_rx_241));
  V f_ = heff_dup(heff_rfield(v_t_2438, 0));
  heff_room[0] = heff_dup(v_hd_2424);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam4, 1, 8, (V[]){v_x_2416, v_web_242, v_proxy_245, v_nt_240, v_listener_2423, v_t_2438, v_hd_2424, v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam2(V self, V *args) {
  V v_listener_2423 = args[0];
  V v_hd_2424 = args[1];
  V v_k_2425 = args[2];
  V v_proxy_245 = heff_env(self)[0];
  V v_port_244 = heff_env(self)[1];
  V v_rx_241 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_web_242 = heff_env(self)[4];
  V v_nt_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2427;
  switch (heff_tag_of(v_proxy_245)) {
  case TAG_Nothing: {
    v_t_2427 = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2426 = heff_dup(heff_field(v_proxy_245, 0));
    v_t_2427 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str2), v_x_2426);
    break;
  }
  default: heff_nomatch(v_proxy_245);
  }
  V v_t_2428 = heff_strAppend(v_port_244, heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str3), v_t_2427));
  V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str4), v_t_2428), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str5));
  V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2429, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_hd_2424), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam3, 1, 8, (V[]){v_rx_241, v_hd_2424, v_x_2416, v_web_242, v_proxy_245, v_nt_240, v_listener_2423, v_k_2425})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam11(V self, V *args) {
  V v_x_2460 = args[0];
  V v_hd_2458 = heff_env(self)[0];
  V v_k_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2460;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2458;
  heff_room[2] = v_k_2459;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam10(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_c_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2457;
  args[0] = heff_dup(v_hd_2458);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam11, 1, 2, (V[]){v_hd_2458, v_k_2459});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam15(V self, V *args) {
  V v_x_2484 = args[0];
  V v_hd_2485 = args[1];
  V v_k_2486 = args[2];
  V v_x_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2484);
  heff_drop(v_hd_2485);
  V f_ = v_k_2486;
  args[0] = v_x_2483;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam14(V self, V *args) {
  V v_x_2483 = args[0];
  V v_k_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2463;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam15, 3, 1, (V[]){v_x_2483});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam13(V self, V *args) {
  V v_x_2475 = args[0];
  V v_hd_2462 = heff_env(self)[0];
  V v_k_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2475);
  V v_t_2476 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2482}), v_hd_2462, heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam14, 1, 1, (V[]){v_k_2463})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam12(V self, V *args) {
  V v_err_2461 = args[0];
  V v_hd_2462 = args[1];
  V v_k_2463 = args[2];
  V v_port_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2464 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str7), heff_take_field(v_err_2461, 2));
  V v_t_2465 = heff_strAppend(heff_get_n(v_err_2461, 1, 3), v_t_2464);
  V v_t_2466 = heff_strAppend(v_port_244, heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str8), v_t_2465));
  V v_t_2467 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str9), v_t_2466), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str10));
  V v_t_2468 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2467, NTAG(TAG_MkUnit)});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2474}), heff_dup(v_hd_2462), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam13, 1, 2, (V[]){v_hd_2462, v_k_2463})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam16(V self, V *args) {
  V v_x_2488 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2488;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_246;
  heff_room[2] = v_k_247;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_port_244 = heff_env(self)[0];
  V v_nt_240 = heff_env(self)[1];
  V v_nx_243 = heff_env(self)[2];
  V v_proxy_245 = heff_env(self)[3];
  V v_rx_241 = heff_env(self)[4];
  V v_web_242 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  HeffT2 v_t_2417 = (g_prelude_2eparseInt_24cpr(v_port_244));
  V v_t_2422;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_x_2421 = v_field_2419;
      v_t_2422 = v_x_2421;
    } else {
      heff_drop(v_field_2419);
      v_t_2422 = MK_INT(8000LL);
    }
  }
  V v_c_2457 = (g_std_2enet_2ewithListener_24s1242722304x1501661027(heff_dup(v_nt_240), heff_dup(v_nx_243), heff_rec_n(2, shape_host__port, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str0), v_t_2422}), MK_INT(64LL), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam2, 3, 6, (V[]){v_proxy_245, heff_dup(v_port_244), v_rx_241, v_x_2416, v_web_242, v_nt_240})));
  V v_t_2487 = heff_tr(heff_call(v_nx_243, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam10, 2, 1, (V[]){v_c_2457}), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam12, 3, 1, (V[]){v_port_244})})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2487, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam16, 1, 2, (V[]){v_hd_246, v_k_247})));
}