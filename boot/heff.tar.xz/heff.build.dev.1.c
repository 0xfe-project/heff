// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_End 17255
#define TAG_Exited 20560
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_MkWith 3751
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Send 26077
#define TAG_Signalled 34337
#define TAG_Sleep 25229
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_TimedOut 6056
#define TAG_TryWait 64330
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_backend 2032133329
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_build 295453320
#define LBL_builds 569118448
#define LBL_code 9554612
#define LBL_command 1182252425
#define LBL_dev 308879
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_follow 678183644
#define LBL_group 299987609
#define LBL_headers 1027165638
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_malg 9839318
#define LBL_message 1186782793
#define LBL_method 869586956
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_ret 322331
#define LBL_stamp 311115741
#define LBL_status 1054660381
#define LBL_target 1066236092
#define LBL_timeout 1065429926
#define LBL_url 325609
#define LBL_wanted 1152016858
static uint32_t shape_builds__wanted__port__proxy__pages[] = {LBL_builds, LBL_wanted, LBL_port, LBL_proxy, LBL_pages};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_dev__apps__stamp[] = {LBL_dev, LBL_apps, LBL_stamp};
static uint32_t shape_name__ended[] = {LBL_name, LBL_ended};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
static uint32_t shape_url__method__headers__body__timeout__follow[] = {LBL_url, LBL_method, LBL_headers, LBL_body, LBL_timeout, LBL_follow};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1876960293x1282655859(V, V, V);
V g_co_2eop_24s1876960293x1282655859_entry(V self, V *a);
extern Clo g_co_2eop_24s1876960293x1282655859_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825(V);
V g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825_clo;
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516(V, V, V);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_clo;
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854(V, V, V, V);
V g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320(V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_clo;
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(V, V, V);
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_clo;
V g_heff_2ebuild_2edev_2efileAnswer(V, V);
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efileAnswer_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320(V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_clo;
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_clo;
V g_heff_2ebuild_2edev_2epageAnswer(V, V, V);
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epageAnswer_clo;
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307(V, V, V);
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_clo;
V g_heff_2ebuild_2edev_2ereloadScript_get(void);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181(V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s483972445x1090422631(V, V, V, V, V, V);
V g_list_2ekeepIf_24s483972445x1090422631_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s483972445x1090422631_clo;
V g_list_2emap_24s2104774589x596860835(V);
V g_list_2emap_24s2104774589x596860835_entry(V self, V *a);
extern Clo g_list_2emap_24s2104774589x596860835_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s1730600117x1705054924(V, V);
V g_std_2eprocess_2ewithProcess_24s1730600117x1705054924_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1730600117x1705054924_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str0, 9, "</script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str1, 10, "  }, 500);");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str2, 5, "})();");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str3, 98, "      .then(function (t) { if (seen === null) seen = t; else if (t !== seen) location.reload(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str4, 29, "      .catch(function () {});");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str5, 48, "    fetch(\"/.heff/built\", { cache: \"no-store\" })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str6, 46, "      .then(function (r) { return r.text(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str7, 18, "  var seen = null;");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str8, 27, "  setInterval(function () {");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str10, 8, "<script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str11, 14, "(function () {");

static V g_heff_2ebuild_2edev_2ereloadScript_val;
static HEFF_ONCE g_heff_2ebuild_2edev_2ereloadScript_st;
static V g_heff_2ebuild_2edev_2ereloadScript_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str9); V a_1 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str10); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str11), v_t_244}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2edev_2ereloadScript_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2edev_2ereloadScript_st)) return g_heff_2ebuild_2edev_2ereloadScript_val;
  return heff_global(&g_heff_2ebuild_2edev_2ereloadScript_val, &g_heff_2ebuild_2edev_2ereloadScript_st, g_heff_2ebuild_2edev_2ereloadScript_init);
}
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str2, 3, "no ");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str4, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str5, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str6, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2efileAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efileAnswer_entry, 2, 0};

V g_heff_2ebuild_2edev_2efileAnswer(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str0), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str1)}), NTAG(TAG_Nil)});
    V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2efileAnswer_str2), v_p_240), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str3));
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_242, heff_bytesFromString(v_t_243)});
  }
  case TAG_Just: {
    V v_text_244 = heff_field(v_x2_241, 0);
    V v_kind_245 = ({ V a_0 = v_p_240; V r_ = (g_heff_2ebuild_2edev_2etypeOf(a_0)); heff_drop(v_p_240); r_; });
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str4), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str5)}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str6), v_kind_245}), v_t_246});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_247, heff_bytesFromString(heff_dup(v_text_244))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2efileAnswer(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str1, 35, "<head><meta charset=\"utf-8\"><title>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str2, 15, "</title></head>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str3, 9, "<div id=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str4, 8, "\"></div>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str5, 33, "<!doctype html>\012<html lang=\"en\">\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str7, 6, "<body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str10, 13, "<script src=\"");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str11, 14, ".js\"></script>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str12, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str13, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str15, 7, "</html>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str16, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str17, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str18, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str19, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str20, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str21, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str22, 8, "no page ");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str23, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str24, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str25, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str26, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str27, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str28, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2epageAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epageAnswer_entry, 3, 0};

V g_heff_2ebuild_2edev_2epageAnswer(V v_name_240, V v_built_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    if ((heff_dup(v_built_241) == NTAG(TAG_True))) {
      V v_kind_243 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str0); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
      V v_name_244 = v_name_240;
      V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str1), heff_dup(v_name_244)), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str2));
      V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str3), heff_dup(v_name_244)), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str4));
      V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str5), v_t_245), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str6));
      V v_t_248 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2edev_2epageAnswer_str7)), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str8));
      V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, v_t_246), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str9));
      V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str10), v_name_244), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str11));
      V v_t_2411 = heff_strAppend(heff_strAppend(v_t_249, v_t_2410), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str12));
      V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2edev_2epageAnswer_str13)), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str14));
      V v_html_2413 = heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2edev_2epageAnswer_str15));
      V v_j_2414 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str16), v_html_2413, MK_INT(0LL), 5);
      V v_text_2417;
      if (heff_intLt_c_lent(v_j_2414, MK_INT(0LL), 2)) {
        heff_drop(v_j_2414);
        v_text_2417 = heff_strAppend(v_html_2413, heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
      } else {
        V v_t_2415 = heff_strAppend(heff_strSlice_lent(v_html_2413, MK_INT(0LL), v_j_2414, 2), heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
        V v_t_2416 = heff_strSlice(heff_dup(v_html_2413), v_j_2414, heff_strLength(v_html_2413));
        v_text_2417 = heff_strAppend(v_t_2415, v_t_2416);
      }
      V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str17), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str18)}), NTAG(TAG_Nil)});
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str19), v_kind_243}), v_t_2418});
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2419, heff_bytesFromString(v_text_2417)});
    } else {
      V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str20), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str21)}), NTAG(TAG_Nil)});
      V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str22), v_name_240), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str23));
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2420, heff_bytesFromString(v_t_2421)});
    }
  }
  case TAG_Just: {
    V v_html_2422 = heff_field(v_x3_242, 0);
    heff_drop(v_name_240);
    V v_kind_2423 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str24); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
    V v_j_2424 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str25), v_html_2422, MK_INT(0LL), 5);
    V v_text_2427;
    if (heff_intLt_c_lent(v_j_2424, MK_INT(0LL), 2)) {
      heff_drop(v_j_2424);
      v_text_2427 = heff_strAppend(heff_dup(v_html_2422), heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
    } else {
      V v_t_2425 = heff_strAppend(heff_strSlice_lent(v_html_2422, MK_INT(0LL), v_j_2424, 2), heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
      V v_t_2426 = heff_strSlice(heff_dup(v_html_2422), v_j_2424, heff_strLength_lent(v_html_2422, 0));
      v_text_2427 = heff_strAppend(v_t_2425, v_t_2426);
    }
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str26), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str27)}), NTAG(TAG_Nil)});
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str28), v_kind_2423}), v_t_2428});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2429, heff_bytesFromString(v_text_2427)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2edev_2epageAnswer(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_str0, 52, "heff dev: not built; built again at the next change\012");
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_entry, 3, 0};

V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(V v_r_240, V v_p_241, V v_p_242) {
top: ;
  V v_out_243 = heff_take_field(v_r_240, 1);
  V v_err_244 = heff_get_n(v_r_240, 2, 3);
  V v_t_245 = heff_tag_n(TAG_Write, 2, (V[]){v_out_243, NTAG(TAG_MkUnit)});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})}));
  return heff_tail(heff_dup(heff_rfield(v_p_241, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam0, 1, 3, (V[]){v_err_244, v_p_241, v_p_242})});
}
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_lit_2423 = ((V)&g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_str0);
  V v_hd_2424 = v_p_241;
  V v_bind_2425 = heff_take_field(v_hd_2424, 1);
  V v_malg_2426 = heff_get_n(v_hd_2424, 2, 3);
  V v_k2_2427 = v_p_242;
  V v_t_2428 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_lit_2423, NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tr(heff_call(v_malg_2426, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})}));
  V f_ = v_bind_2425;
  heff_room[0] = v_t_2435;
  heff_room[1] = v_k2_2427;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_err_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2413);
  V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_err_244, NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})}));
  V f_ = heff_dup(heff_rfield(v_p_241, 1));
  heff_room[0] = v_t_2421;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504_lam1, 1, 2, (V[]){v_p_241, v_p_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_str0, 8, "building");
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_str1, 5, "build");
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam1, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam3, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_entry, 3, 0};

V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307(V v_st_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam0, 1, 3, (V[]){v_hd_241, v_st_240, v_k_242})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam1(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam3(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam7(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2423);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam8(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2425);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam9(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2426);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam10(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2427);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_dup(heff_rfield(v_x_2414, 0));
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Exited: {
    V v_n_2420 = heff_field(v_t_2419, 0);
    heff_take_n(v_t_2419, 1ULL, 1);
    if (heff_intEq_c(v_n_2420, MK_INT(0LL))) {
      heff_drop_rec(v_x_2414, 3);
      V v_c_2421 = (g_heff_2ebuild_2edev_2eappsNow_24s1647829377x841028825(v_st_240));
      V f_ = v_c_2421;
      heff_room[0] = v_hd_241;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam6, 1, 1, (V[]){v_k_242});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_st_240);
      return (g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(v_x_2414, v_hd_241, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam7, 1, 1, (V[]){v_k_242})));
    }
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2419, 0ULL, 1);
    heff_drop(v_st_240);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(v_x_2414, v_hd_241, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam8, 1, 1, (V[]){v_k_242})));
  }
  case TAG_TimedOut: {
    heff_drop(v_st_240);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(v_x_2414, v_hd_241, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam9, 1, 1, (V[]){v_k_242})));
  }
  case TAG_NotRun: {
    heff_drop(v_st_240);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s851027092x1187193504(v_x_2414, v_hd_241, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam10, 1, 1, (V[]){v_k_242})));
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_End, 2, (V[]){v_x_248, NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2417;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam5, 1, 4, (V[]){v_x_2414, v_st_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_str1), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_248), v_x_243, v_t_249, ((V)&g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam3_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam4, 1, 4, (V[]){v_x_248, v_hd_241, v_st_240, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam1_clo)})});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_246}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307_lam2, 1, 4, (V[]){v_x_243, v_hd_241, v_st_240, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_str1, 1, "\012");
V g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_entry, 6, 0};

V g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181(V v_st_240, V v_d_241, V v_stamp_242, V v_running_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_Sleep, 2, (V[]){MK_INT(250LL), NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_lam0, 1, 6, (V[]){v_running_243, v_hd_244, v_st_240, heff_dup(v_stamp_242), v_d_241, v_k_245})});
}
V g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    return ({ V a_0 = v_st_240; V a_1 = v_d_241; V a_2 = v_x_2417; V a_3 = v_x_2412; V a_4 = v_hd_244; V a_5 = v_k_245; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2417); r_; });
  }
  case TAG_Just: {
    V v_argv_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_drop(v_st_240);
    heff_drop(v_x_2412);
    heff_drop_rec(v_hd_244, 3);
    V v_t_2420 = heff_intAdd(heff_take_field(v_d_241, 0), MK_INT(1LL));
    V v_t_2421 = ({ V rv_0 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_d_241, 30ULL, 5, shape_builds__wanted__port__proxy__pages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_k_245;
    args[0] = heff_rec_n(3, shape_dev__apps__stamp, (V[]){v_t_2421, v_argv_2419, v_x_2417});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_stamp_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2417;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nil: {
    v_x_2417 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x_2414, 0);
    V v_xs_2416 = heff_field(v_x_2414, 1);
    heff_take_n(v_x_2414, 3ULL, 2);
    v_x_2417 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_str1); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  if (heff_strEq_c_lent(v_x_2417, v_stamp_242, 0)) {
    heff_drop(v_x_2417);
    return ({ V a_0 = v_st_240; V a_1 = v_d_241; V a_2 = v_stamp_242; V a_3 = v_x_2412; V a_4 = v_hd_244; V a_5 = v_k_245; V r_ = (g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_stamp_242); r_; });
  } else {
    heff_drop(v_stamp_242);
    return (g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307(heff_dup(v_st_240), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_lam3, 1, 6, (V[]){v_st_240, v_d_241, v_x_2417, v_x_2412, v_hd_244, v_k_245})));
  }
}
V g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_stamp_242 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2413 = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(heff_dup(v_st_240), NTAG(TAG_Nil), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_lam2, 1, 6, (V[]){v_stamp_242, v_st_240, v_d_241, v_x_2412, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_running_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_stamp_242 = heff_env(self)[3];
  V v_d_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2411);
  return (g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(NTAG(TAG_Nil), v_running_243, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_lam1, 1, 5, (V[]){v_st_240, v_hd_244, v_stamp_242, v_d_241, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str1, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str3, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str4, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str5, 17, "heff dev: built (");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str6, 1, "c");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str7, 14, "nothing to run");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str9, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str10, 11, "); running ");
HEFF_LIT(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str11, 1, "\012");
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam0, 1, 0};
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam1, 1, 0};
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam5(V self, V *args); static Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam5, 1, 0};
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam6(V self, V *args); static Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam6, 1, 0};
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam3(V self, V *args);
Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_entry, 3, 0};

V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516(V v_st_240, V v_d_241, V v_apps_242) {
top: ;
  V v_builds_243 = heff_take_field(v_d_241, 0);
  V v_wanted_244 = heff_get_n(v_d_241, 1, 5);
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str0)));
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str1)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_s_248 = ({ V a_0 = v_st_240; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_248));
  V v_t_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_249; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_249); r_; });
  V v_a_2412 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam0_clo)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_c_2425 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam1_clo)));
  return heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam3, 2, 5, (V[]){v_c_2425, v_st_240, v_builds_243, v_wanted_244, v_apps_242});
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam0(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam2(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_x_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_err_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    V v_t_2421 = heff_tag_at_n(v_ru_24x_2419_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2420})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2421));
  }
  case TAG_Right: {
    V v_x_2422 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam2, 2, 1, (V[]){v_x_2422});
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam5(V self, V *args) {
  V v_r_2439 = args[0];
  return v_r_2439;
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam7(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_x_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2451);
  V f_ = v_k_2452;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2450});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  switch (heff_tag_of(v_x_2447)) {
  case TAG_Left: {
    V v_err_2448 = heff_field(v_x_2447, 0);
    V v_ru_24x_2447_24Left = heff_take_reuse_n(v_x_2447, 1ULL, 1);
    V v_t_2449 = heff_tag_at_n(v_ru_24x_2447_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2448})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2449));
  }
  case TAG_Right: {
    V v_x_2450 = heff_field(v_x_2447, 0);
    heff_take_n(v_x_2447, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam7, 2, 1, (V[]){v_x_2450});
  }
  default: return heff_nomatch(v_x_2447);
  }
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam9(V self, V *args) {
  V v_a_2457 = args[0];
  V v_wanted_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_build_2458 = heff_take_field(v_a_2457, 1);
  V v_name_2459 = heff_get_n(v_a_2457, 0, 2);
  if (heff_strEq_c(heff_get_n(v_build_2458, 0, 3), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str6))) {
    switch (heff_tag_of(v_wanted_2456)) {
    case TAG_Nil: {
      heff_drop(v_name_2459);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_t_2462 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_name_2459}));
      return ({ V a_0 = v_t_2462; V a_1 = v_wanted_2456; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_wanted_2456, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2456);
    }
  } else {
    heff_drop(v_wanted_2456);
    heff_drop(v_name_2459);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam8(V self, V *args) {
  V v_x_2454 = args[0];
  V v_builds_243 = heff_env(self)[0];
  V v_wanted_244 = heff_env(self)[1];
  V v_apps_242 = heff_env(self)[2];
  V v_hd_2426 = heff_env(self)[3];
  V v_k_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2454);
  V v_t_2455 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str5), heff_intShow(v_builds_243));
  V v_wanted_2456 = v_wanted_244;
  V v_argv_2463 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam9, 1, 1, (V[]){v_wanted_2456}), v_apps_242));
  V v_t_2469;
  switch (heff_tag_of(v_argv_2463)) {
  case TAG_Nil: {
    v_t_2469 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str7);
    break;
  }
  case TAG_Cons: {
    V v_x2_2466 = (g_list_2emap_24s2104774589x596860835(v_argv_2463));
    switch (heff_tag_of(v_x2_2466)) {
    case TAG_Nil: {
      v_t_2469 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2467 = heff_field(v_x2_2466, 0);
      V v_xs_2468 = heff_field(v_x2_2466, 1);
      heff_take_n(v_x2_2466, 3ULL, 2);
      v_t_2469 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str9); V a_1 = v_x_2467; V a_2 = v_xs_2468; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2468); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2466);
    }
    break;
  }
  default: heff_nomatch(v_argv_2463);
  }
  V v_str_2470 = heff_strAppend(heff_strAppend(v_t_2455, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str10)), v_t_2469);
  V v_t_2471 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2470, ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str11)), NTAG(TAG_MkUnit)});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tr(heff_call(heff_take_field(v_hd_2426, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})}));
  V f_ = heff_get_n(v_hd_2426, 1, 3);
  heff_room[0] = v_t_2478;
  heff_room[1] = v_k_2427;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_builds_243 = heff_env(self)[1];
  V v_hd_2426 = heff_env(self)[2];
  V v_wanted_244 = heff_env(self)[3];
  V v_apps_242 = heff_env(self)[4];
  V v_k_2427 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2428);
  V v_t_2429 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str2)));
  V v_t_2430 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str3)));
  V v_t_2431 = (g_std_2epath_2ejoin(v_t_2429, v_t_2430));
  V v_a_2432 = ({ V a_0 = v_st_240; V a_1 = v_t_2431; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2431); r_; });
  V v_t_2433 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_a_2432));
  V v_t_2434 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_str4)));
  V v_t_2435 = (g_std_2epath_2ejoin(v_t_2433, v_t_2434));
  V v_s_2436 = ({ V a_0 = v_st_240; V a_1 = v_t_2435; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2435); r_; });
  V v_path_2437 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2436));
  V v_t_2438 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2437; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2437); r_; });
  V v_a_2440 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2438, heff_intShow(heff_dup(v_builds_243)), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam5_clo)});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_c_2453 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam6_clo)));
  V f_ = v_c_2453;
  heff_room[0] = heff_dup(v_hd_2426);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam8, 1, 5, (V[]){v_builds_243, v_wanted_244, v_apps_242, v_hd_2426, v_k_2427});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam3(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_builds_243 = heff_env(self)[2];
  V v_wanted_244 = heff_env(self)[3];
  V v_apps_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2425;
  args[0] = heff_dup(v_hd_2426);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ebuiltSaid_24s490464206x1457535516_lam4, 1, 6, (V[]){v_st_240, v_builds_243, v_hd_2426, v_wanted_244, v_apps_242, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_str2, 4, ".exe");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_str3, 21, "heff dev: cannot run ");
HEFF_LIT(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_str4, 1, "\012");
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam1, 1, 0};
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam6(V self, V *args);
Clo g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_entry, 5, 0};

V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917(V v_st_240, V v_d_241, V v_stamp_242, V v_running_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    return heff_tail(((V)&g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181_clo), 4, (V[]){v_st_240, v_d_241, v_stamp_242, v_running_243});
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    heff_take_n(v_x5_244, 3ULL, 2);
    V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_str0)));
    V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_str1)));
    V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
    V v_a_2410 = ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_n_2411 = heff_dup(heff_rfield(v_a_245, 0));
    V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_a_2410));
    V v_t_2413;
    switch (heff_tag_of(v_st_240)) {
    case TAG_Posix: {
      v_t_2413 = v_n_2411;
      break;
    }
    case TAG_Windows: {
      v_t_2413 = heff_strAppend(v_n_2411, ((V)&g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_str2));
      break;
    }
    default: heff_nomatch(v_st_240);
    }
    V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_t_2413));
    V v_t_2415 = (g_std_2epath_2ejoin(v_t_2412, v_t_2414));
    V v_program_2416 = ({ V a_0 = v_st_240; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_program_2416, NTAG(TAG_Nil), heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_c_2443 = (g_std_2eprocess_2ewithProcess_24s1730600117x1705054924(v_t_2417, heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam0, 1, 6, (V[]){heff_dup(v_a_245), heff_dup(v_running_243), heff_dup(v_st_240), heff_dup(v_d_241), heff_dup(v_stamp_242), heff_dup(v_rest_246)})));
    return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam6, 2, 7, (V[]){v_c_2443, v_a_245, v_st_240, v_d_241, v_stamp_242, v_running_243, v_rest_246});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam1(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam5(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_2441 = args[1];
  V v_k_2442 = args[2];
  V v_x_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2440);
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam4(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_2438 = args[1];
  V v_k_2439 = args[2];
  V v_x_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2437);
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam5, 3, 1, (V[]){v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2435;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam4, 3, 1, (V[]){v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam2(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2433;
  args[0] = v_hd_2434;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam3, 1, 1, (V[]){v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam0(V self, V *args) {
  V v_p_2418 = args[0];
  V v_a_245 = heff_env(self)[0];
  V v_running_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_stamp_242 = heff_env(self)[4];
  V v_rest_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420;
  switch (heff_tag_of(v_p_2418)) {
  case TAG_MkWith: {
    V v_x_2419 = heff_field(v_p_2418, 0);
    heff_take_n(v_p_2418, 1ULL, 1);
    v_t_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_p_2418);
  }
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_TryWait, 2, (V[]){v_t_2420, ((V)&g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam1_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2428}));
  V v_t_2430 = heff_rec_n(2, shape_name__ended, (V[]){heff_get_n(v_a_245, 0, 2), v_t_2429});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
  V v_t_2432 = (g_prelude_2e_2b_2b(v_running_243, v_t_2431));
  V v_c_2433 = heff_tr(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917(v_st_240, v_d_241, v_stamp_242, v_t_2432, v_rest_246));
  return heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam2, 2, 1, (V[]){v_c_2433});
}
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam7(V self, V *args) {
  V v_x_2447 = args[0];
  V v_hd_2444 = heff_env(self)[0];
  V v_k_2446 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2447;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2444;
  heff_room[2] = v_k_2446;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam11(V self, V *args) {
  V v_x_2463 = args[0];
  V v_hd_2464 = args[1];
  V v_k_2465 = args[2];
  V v_x_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2463);
  heff_drop(v_hd_2464);
  V f_ = v_k_2465;
  args[0] = v_x_2462;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam10(V self, V *args) {
  V v_x_2462 = args[0];
  V v_k_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2450;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam11, 3, 1, (V[]){v_x_2462});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam9(V self, V *args) {
  V v_x_2460 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_stamp_242 = heff_env(self)[2];
  V v_running_243 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_hd_2444 = heff_env(self)[5];
  V v_k_2450 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2460);
  V v_c_2461 = heff_tr(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917(v_st_240, v_d_241, v_stamp_242, v_running_243, v_rest_246));
  V f_ = v_c_2461;
  heff_room[0] = v_hd_2444;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam10, 1, 1, (V[]){v_k_2450});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam8(V self, V *args) {
  V v_s_2449 = args[0];
  V v_hd_2444 = heff_env(self)[0];
  V v_a_245 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_stamp_242 = heff_env(self)[4];
  V v_running_243 = heff_env(self)[5];
  V v_rest_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_s_2449);
  V v_k_2450 = heff_dup(heff_rfield(v_hd_2444, 0));
  V v_t_2451 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_str3), heff_get_n(v_a_245, 0, 2));
  V v_t_2452 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2451, ((V)&g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_str4)), NTAG(TAG_MkUnit)});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2444, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})}));
  V f_ = heff_dup(heff_rfield(v_hd_2444, 1));
  heff_room[0] = v_t_2459;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam9, 1, 7, (V[]){v_st_240, v_d_241, v_stamp_242, v_running_243, v_rest_246, v_hd_2444, v_k_2450});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam12(V self, V *args) {
  V v_x_2468 = args[0];
  V v_hd_2444 = heff_env(self)[0];
  V v_k_2445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2468;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2444;
  heff_room[2] = v_k_2445;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam6(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_c_2443 = heff_env(self)[0];
  V v_a_245 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_stamp_242 = heff_env(self)[4];
  V v_running_243 = heff_env(self)[5];
  V v_rest_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_k_2446 = heff_dup(heff_rfield(v_hd_2444, 0));
  V v_t_2448 = heff_tr(heff_call(v_c_2443, 2, (V[]){heff_dup(v_hd_2444), heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam7, 1, 2, (V[]){heff_dup(v_hd_2444), v_k_2446})}));
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2448, heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam8, 1, 7, (V[]){heff_dup(v_hd_2444), v_a_245, v_st_240, v_d_241, v_stamp_242, v_running_243, v_rest_246})})});
  V v_t_2467 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2444, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})}));
  V f_ = heff_dup(heff_rfield(v_hd_2444, 1));
  args[0] = v_t_2467;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2eheld_24s1961331960x1335279917_lam12, 1, 2, (V[]){v_hd_2444, v_k_2445});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_str2, 59, "heff dev: no package.hf here: run it at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_str5, 4, "8000");
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam0, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam1, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam5(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam5, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam3(V self, V *args);
Clo g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_entry, 3, 0};

V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320(V v_wanted_240, V v_port_241, V v_proxy_242) {
top: ;
  V v_path_243 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_str0)));
  V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_243; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_243); r_; });
  V v_a_246 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam0_clo)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  V v_c_2419 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam1_clo)));
  return heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam3, 2, 4, (V[]){v_c_2419, heff_dup(v_port_241), v_wanted_240, v_proxy_242});
}
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam0(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2413_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2414})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2415));
  }
  case TAG_Right: {
    V v_x_2416 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam2, 2, 1, (V[]){v_x_2416});
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam5(V self, V *args) {
  V v_s_2423 = args[0];
  return v_s_2423;
}
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_2420 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2443);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2420, v_k_2421));
}
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam10(V self, V *args) {
  V v_x_2454 = args[0];
  V v_st_2433 = heff_env(self)[0];
  V v_hd_2420 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_dev_2455 = heff_take_field(v_x_2454, 0);
  V v_stamp_2456 = heff_take_field(v_x_2454, 2);
  V v_apps_2457 = heff_get_n(v_x_2454, 1, 3);
  V v_t_2458 = (g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854(v_st_2433, v_dev_2455, v_stamp_2456, v_apps_2457));
  V f_ = v_t_2458;
  heff_room[0] = v_hd_2420;
  heff_room[1] = v_k_2421;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam9(V self, V *args) {
  V v_x_2453 = args[0];
  V v_st_2433 = heff_env(self)[0];
  V v_d_2452 = heff_env(self)[1];
  V v_x_2449 = heff_env(self)[2];
  V v_hd_2420 = heff_env(self)[3];
  V v_k_2421 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2453)) {
  case TAG_Nothing: {
    return ({ V a_0 = heff_dup(v_st_2433); V a_1 = v_d_2452; V a_2 = v_x_2449; V a_3 = NTAG(TAG_Nil); V a_4 = heff_dup(v_hd_2420); V a_5 = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam10, 1, 3, (V[]){v_st_2433, v_hd_2420, v_k_2421}); V r_ = (g_heff_2ebuild_2edev_2ewatched_24s1895916180x1428178181(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2449); r_; });
  }
  case TAG_Just: {
    V v_apps_2459 = heff_field(v_x_2453, 0);
    heff_take_n(v_x_2453, 1ULL, 1);
    V v_t_2460 = ({ V rv_0 = MK_INT(1LL); V rr_ = heff_rec_reuse_nf(v_d_2452, 30ULL, 5, shape_builds__wanted__port__proxy__pages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2461 = (g_heff_2ebuild_2edev_2ecycle_24s1817825656x841006854(v_st_2433, v_t_2460, v_x_2449, v_apps_2459));
    V f_ = v_t_2461;
    heff_room[0] = v_hd_2420;
    heff_room[1] = v_k_2421;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2453);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam8(V self, V *args) {
  V v_x_2446 = args[0];
  V v_port_241 = heff_env(self)[0];
  V v_wanted_240 = heff_env(self)[1];
  V v_proxy_242 = heff_env(self)[2];
  V v_st_2433 = heff_env(self)[3];
  V v_hd_2420 = heff_env(self)[4];
  V v_k_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2449;
  switch (heff_tag_of(v_x_2446)) {
  case TAG_Nil: {
    v_x_2449 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2447 = heff_field(v_x_2446, 0);
    V v_xs_2448 = heff_field(v_x_2446, 1);
    heff_take_n(v_x_2446, 3ULL, 2);
    v_x_2449 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_str4); V a_1 = v_x_2447; V a_2 = v_xs_2448; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2448); r_; });
    break;
  }
  default: heff_nomatch(v_x_2446);
  }
  V v_t_2451;
  switch (heff_tag_of(v_port_241)) {
  case TAG_Nothing: {
    v_t_2451 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_str5);
    break;
  }
  case TAG_Just: {
    V v_x_2450 = heff_field(v_port_241, 0);
    heff_take_n(v_port_241, 1ULL, 1);
    v_t_2451 = v_x_2450;
    break;
  }
  default: heff_nomatch(v_port_241);
  }
  V v_d_2452 = heff_rec_n(5, shape_builds__wanted__port__proxy__pages, (V[]){MK_INT(0LL), v_wanted_240, v_t_2451, v_proxy_242, NTAG(TAG_False)});
  return (g_heff_2ebuild_2edev_2erebuilt_24s706041310x397715307(heff_dup(v_st_2433), heff_dup(v_hd_2420), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam9, 1, 5, (V[]){v_st_2433, v_d_2452, v_x_2449, v_hd_2420, v_k_2421})));
}
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_2422 = heff_env(self)[0];
  V v_hd_2420 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  V v_port_241 = heff_env(self)[3];
  V v_wanted_240 = heff_env(self)[4];
  V v_proxy_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2433;
  if (heff_strEq_c(v_x_2432, ((V)&g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_str1))) {
    v_st_2433 = NTAG(TAG_Windows);
  } else {
    v_st_2433 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    V v_ru_24x_2422_24Left = heff_take_reuse_n(v_x_2422, 0ULL, 1);
    heff_drop(v_port_241);
    heff_drop(v_wanted_240);
    heff_drop(v_proxy_242);
    heff_drop(v_st_2433);
    V v_t_2435 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_str2), NTAG(TAG_MkUnit)});
    V v_t_2436 = heff_tag_at_n(v_ru_24x_2422_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2420, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})}));
    V f_ = heff_dup(heff_rfield(v_hd_2420, 1));
    heff_room[0] = v_t_2442;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam7, 1, 2, (V[]){v_hd_2420, v_k_2421});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2422, 0ULL, 1);
    V v_c_2445 = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(heff_dup(v_st_2433), NTAG(TAG_Nil), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
    V f_ = v_c_2445;
    heff_room[0] = heff_dup(v_hd_2420);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam8, 1, 6, (V[]){v_port_241, v_wanted_240, v_proxy_242, v_st_2433, v_hd_2420, v_k_2421});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2420 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  V v_port_241 = heff_env(self)[2];
  V v_wanted_240 = heff_env(self)[3];
  V v_proxy_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam5_clo)})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2420, 2)), 1, (V[]){v_t_2430}));
  V f_ = heff_dup(heff_rfield(v_hd_2420, 1));
  heff_room[0] = v_t_2431;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam6, 1, 6, (V[]){v_x_2422, v_hd_2420, v_k_2421, v_port_241, v_wanted_240, v_proxy_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_port_241 = heff_env(self)[1];
  V v_wanted_240 = heff_env(self)[2];
  V v_proxy_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s929022286x1088366320_lam4, 1, 5, (V[]){v_hd_2420, v_k_2421, v_port_241, v_wanted_240, v_proxy_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str0, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str1, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str2, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str3, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str4, 10, "keep-alive");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str5, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str6, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str7, 23, "heff dev: nothing from ");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str9, 7, "curl: (");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str10, 2, ") ");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str12, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str13, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str14, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str15, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str16, 10, "keep-alive");
V g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_entry, 4, 0};

V g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320(V v_to_240, V v_req_241, V v_z_242, V v_z_243) {
top: ;
  V v_target_244 = heff_take_field(v_req_241, 1);
  V v_method_245 = heff_take_field(v_req_241, 0);
  V v_headers_246 = heff_take_field(v_req_241, 3);
  V v_body_247 = heff_get_n(v_req_241, 4, 6);
  V v_t_248 = (g_list_2ekeepIf_24s483972445x1090422631(((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str0), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str1), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str2), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str3), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str4), v_headers_246));
  V v_rq_249 = heff_rec_n(6, shape_url__method__headers__body__timeout__follow, (V[]){heff_strAppend(heff_dup(v_to_240), v_target_244), v_method_245, v_t_248, v_body_247, MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Send, 2, (V[]){v_rq_249, ((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_lam0_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s1876960293x1282655859(v_t_2413, v_z_242, heff_clo_n(g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_lam1, 1, 2, (V[]){v_to_240, v_z_243})));
}
V g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_to_240 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_to_2415 = v_to_240;
  V v_x2_2416 = v_x_2414;
  V v_x_2427;
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Left: {
    V v_err_2417 = heff_field(v_x2_2416, 0);
    heff_take_n(v_x2_2416, 1ULL, 1);
    V v_code_2418 = heff_take_field(v_err_2417, 0);
    V v_message_2419 = heff_get_n(v_err_2417, 1, 2);
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str5), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str6)}), NTAG(TAG_Nil)});
    V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str7), v_to_2415), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str8));
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str9), heff_intShow(v_code_2418));
    V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str10)), v_message_2419);
    V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2421, v_t_2423), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str11));
    v_x_2427 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(502LL), v_t_2420, heff_bytesFromString(v_t_2424)});
    break;
  }
  case TAG_Right: {
    V v_res_2425 = heff_field(v_x2_2416, 0);
    heff_take_n(v_x2_2416, 1ULL, 1);
    heff_drop(v_to_2415);
    V v_t_2426 = (g_list_2ekeepIf_24s483972445x1090422631(((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str12), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str13), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str14), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str15), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s552191176x1583126320_str16), heff_take_field(v_res_2425, 1)));
    v_x_2427 = ({ V rv_1 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_res_2425, 5ULL, 3, shape_status__headers__body, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    break;
  }
  default: heff_nomatch(v_x2_2416);
  }
  V f_ = v_z_243;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}