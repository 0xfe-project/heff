// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Directory 35277
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_Main 39920
#define TAG_Other 45236
#define TAG_PathStatus 29154
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Regular 40886
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_body 9524841
#define LBL_build 295453320
#define LBL_builds 569118448
#define LBL_chans 295981947
#define LBL_code 9554612
#define LBL_command 1182252425
#define LBL_dev 308879
#define LBL_dir 308999
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_follow 678183644
#define LBL_group 299987609
#define LBL_headers 1027165638
#define LBL_host 9704047
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_kind 9787483
#define LBL_message 1186782793
#define LBL_method 869586956
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_opt 319789
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_pending 1696753626
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_ready 309745085
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_shipTo 1043811586
#define LBL_stamp 311115741
#define LBL_status 1054660381
#define LBL_target 1066236092
#define LBL_timeout 1065429926
#define LBL_turns 312085424
#define LBL_url 325609
#define LBL_waiting 1348170899
#define LBL_wanted 1152016858
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_builds__wanted__port__proxy__pages[] = {LBL_builds, LBL_wanted, LBL_port, LBL_proxy, LBL_pages};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_host__port[] = {LBL_host, LBL_port};
static uint32_t shape_ready__chans__waiting__next__pending__turns[] = {LBL_ready, LBL_chans, LBL_waiting, LBL_next, LBL_pending, LBL_turns};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
static uint32_t shape_url__method__headers__body__timeout__follow[] = {LBL_url, LBL_method, LBL_headers, LBL_body, LBL_timeout, LBL_follow};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s310418905x1614124229(V, V, V);
V g_co_2eop_24s310418905x1614124229_entry(V self, V *a);
extern Clo g_co_2eop_24s310418905x1614124229_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_green_2eemptyQ_get(void);
V g_green_2ego_24s850908287x1133196696(V, V, V, V);
V g_green_2ego_24s850908287x1133196696_entry(V self, V *a);
extern Clo g_green_2ego_24s850908287x1133196696_clo;
V g_green_2eview_24s192594942x2076863488(V);
V g_green_2eview_24s192594942x2076863488_entry(V self, V *a);
extern Clo g_green_2eview_24s192594942x2076863488_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_clo;
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547(V, V);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_clo;
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957(V, V, V, V);
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_clo;
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196(V, V, V);
V g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196_clo;
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_clo;
V g_heff_2ebuild_2edev_2efileAnswer(V, V);
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efileAnswer_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_clo;
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040_clo;
V g_heff_2ebuild_2edev_2eindexAnswer(V);
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eindexAnswer_clo;
V g_heff_2ebuild_2edev_2emadePage(V);
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2emadePage_clo;
V g_heff_2ebuild_2edev_2epageAnswer(V, V, V);
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epageAnswer_clo;
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_clo;
V g_heff_2ebuild_2edev_2erelayed(V, V);
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erelayed_clo;
V g_heff_2ebuild_2edev_2ereloadScript_get(void);
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958(V, V, V, V);
V g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_list_2eall_24s1579400704x1789597964(V);
V g_list_2eall_24s1579400704x1789597964_entry(V self, V *a);
extern Clo g_list_2eall_24s1579400704x1789597964_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s105899861x584770213(V);
V g_list_2eany_24s105899861x584770213_entry(V self, V *a);
extern Clo g_list_2eany_24s105899861x584770213_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s514881809x1990693194(V, V, V, V, V, V);
V g_list_2efilter_24s514881809x1990693194_entry(V self, V *a);
extern Clo g_list_2efilter_24s514881809x1990693194_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24f336527456x1519848451(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f336527456x1519848451_entry(V self, V *a);
extern Clo g_list_2emap_24f336527456x1519848451_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s729664635x1487989391(V, V, V);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s729664635x1487989391_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s729664635x1487989391_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2enet_2ewithListener_24s1242722304x1501661027(V, V, V, V, V);
V g_std_2enet_2ewithListener_24s1242722304x1501661027_entry(V self, V *a);
extern Clo g_std_2enet_2ewithListener_24s1242722304x1501661027_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprocess_2ewithProcess_24s1854160028x1916200928(V, V, V, V, V);
V g_std_2eprocess_2ewithProcess_24s1854160028x1916200928_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1854160028x1916200928_clo;
V g_std_2eprogress_2eroot_get(void);
V g_std_2ereactor_2eoutside_24s283078862x396680432(V);
V g_std_2ereactor_2eoutside_24s283078862x396680432_entry(V self, V *a);
extern Clo g_std_2ereactor_2eoutside_24s283078862x396680432_clo;
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str0, 9, "</script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str1, 10, "  }, 500);");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str2, 5, "})();");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str3, 98, "      .then(function (t) { if (seen === null) seen = t; else if (t !== seen) location.reload(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str4, 29, "      .catch(function () {});");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str5, 48, "    fetch(\"/.heff/built\", { cache: \"no-store\" })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str6, 46, "      .then(function (r) { return r.text(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str7, 18, "  var seen = null;");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str8, 27, "  setInterval(function () {");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str10, 8, "<script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str11, 14, "(function () {");

static V g_heff_2ebuild_2edev_2ereloadScript_val;
static HEFF_ONCE g_heff_2ebuild_2edev_2ereloadScript_st;
static V g_heff_2ebuild_2edev_2ereloadScript_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str9); V a_1 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str10); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str11), v_t_244}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2edev_2ereloadScript_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2edev_2ereloadScript_st)) return g_heff_2ebuild_2edev_2ereloadScript_val;
  return heff_global(&g_heff_2ebuild_2edev_2ereloadScript_val, &g_heff_2ebuild_2edev_2ereloadScript_st, g_heff_2ebuild_2edev_2ereloadScript_init);
}
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str2, 3, "no ");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str4, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str5, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str6, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2efileAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efileAnswer_entry, 2, 0};

V g_heff_2ebuild_2edev_2efileAnswer(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str0), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str1)}), NTAG(TAG_Nil)});
    V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2efileAnswer_str2), heff_strAppend(v_p_240, ((V)&g_heff_2ebuild_2edev_2efileAnswer_str3)));
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_242, heff_bytesFromString(v_t_243)});
  }
  case TAG_Just: {
    V v_text_244 = heff_field(v_x2_241, 0);
    V v_kind_245 = ({ V a_0 = v_p_240; V r_ = (g_heff_2ebuild_2edev_2etypeOf(a_0)); heff_drop(v_p_240); r_; });
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str4), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str5)}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str6), v_kind_245}), v_t_246});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_247, heff_bytesFromString(heff_dup(v_text_244))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2efileAnswer(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str1, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str2, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str3, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str4, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str5, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str6, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str7, 8, "no page ");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str9, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str10, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str11, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str12, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str13, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2epageAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epageAnswer_entry, 3, 0};

V g_heff_2ebuild_2edev_2epageAnswer(V v_name_240, V v_built_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    if ((heff_dup(v_built_241) == NTAG(TAG_True))) {
      V v_kind_243 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str0); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
      V v_html_244 = (g_heff_2ebuild_2edev_2emadePage(v_name_240));
      V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str1), v_html_244, MK_INT(0LL), 5);
      V v_text_248;
      if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
        heff_drop(v_j_245);
        v_text_248 = heff_strAppend(v_html_244, heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
      } else {
        V v_t_247 = heff_strSlice(heff_dup(v_html_244), heff_dup(v_j_245), heff_strLength_lent(v_html_244, 0));
        v_text_248 = heff_strAppend(heff_strSlice(v_html_244, MK_INT(0LL), v_j_245), heff_strAppend(heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), v_t_247));
      }
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str2), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str3)}), NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str4), v_kind_243}), v_t_249});
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2410, heff_bytesFromString(v_text_248)});
    } else {
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str5), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str6)}), NTAG(TAG_Nil)});
      V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str7), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2edev_2epageAnswer_str8)));
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2411, heff_bytesFromString(v_t_2412)});
    }
  }
  case TAG_Just: {
    V v_html_2413 = heff_field(v_x3_242, 0);
    heff_drop(v_name_240);
    V v_kind_2414 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str9); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
    V v_j_2415 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str10), v_html_2413, MK_INT(0LL), 5);
    V v_text_2418;
    if (heff_intLt_c_lent(v_j_2415, MK_INT(0LL), 2)) {
      heff_drop(v_j_2415);
      v_text_2418 = heff_strAppend(heff_dup(v_html_2413), heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
    } else {
      V v_t_2417 = heff_strSlice(heff_dup(v_html_2413), heff_dup(v_j_2415), heff_strLength_lent(v_html_2413, 0));
      v_text_2418 = heff_strAppend(heff_strSlice_lent(v_html_2413, MK_INT(0LL), v_j_2415, 6), heff_strAppend(heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), v_t_2417));
    }
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str11), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str12)}), NTAG(TAG_Nil)});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str13), v_kind_2414}), v_t_2419});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2420, heff_bytesFromString(v_text_2418)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2edev_2epageAnswer(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str1, 4, "<ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str2, 23, "<title>heff dev</title>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str3, 18, "<h1>the pages</h1>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str4, 14, "<li><a href=\"/");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str5, 3, "/\">");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str6, 9, "</a></li>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str7, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str8, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str9, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str10, 5, "</ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str11, 15, "<!doctype html>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str14, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str15, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str16, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2eindexAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eindexAnswer_entry, 1, 0};

V g_heff_2ebuild_2edev_2eindexAnswer(V v_found_240) {
top: ;
  V v_kind_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str0); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str1), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str3), v_t_242})});
  V v_t_245;
  switch (heff_tag_of(v_found_240)) {
  case TAG_Nothing: {
    v_t_245 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_found_240, 0);
    v_t_245 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_found_240);
  }
  V v_t_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str4); V b_1 = MK_INT(0LL); V a_2 = MK_INT(3LL); V a_3 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str5); V b_4 = MK_INT(0LL); V a_5 = MK_INT(3LL); V a_6 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str6); V b_7 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str7); V b_8 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str8); V b_9 = MK_INT(0LL); V b_10 = MK_INT(1LL); V b_11 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str9); V a_12 = v_t_245; V r_ = (g_list_2emap_24f336527456x1519848451(a_0, b_1, a_2, a_3, b_4, a_5, a_6, b_7, b_8, b_9, b_10, b_11, a_12)); heff_drop(b_1); heff_drop(b_4); heff_drop(b_7); heff_drop(b_8); heff_drop(b_9); heff_drop(b_10); heff_drop(b_11); r_; });
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), NTAG(TAG_Nil)});
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str10), v_t_247})));
  V v_xs_249 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str11), v_t_243}), v_t_248));
  V v_text_2412;
  switch (heff_tag_of(v_xs_249)) {
  case TAG_Nil: {
    v_text_2412 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_xs_249, 0);
    V v_xs_2411 = heff_field(v_xs_249, 1);
    heff_take_n(v_xs_249, 3ULL, 2);
    v_text_2412 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str13); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_xs_249);
  }
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str14), ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str15)}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str16), v_kind_241}), v_t_2413});
  return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2414, heff_bytesFromString(v_text_2412)});
}
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eindexAnswer(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str2, 2, ") ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str3, 7, "curl: (");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str6, 23, "heff dev: nothing from ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str7, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str8, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str9, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str10, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str11, 10, "keep-alive");
Clo g_heff_2ebuild_2edev_2erelayed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erelayed_entry, 2, 0};

V g_heff_2ebuild_2edev_2erelayed(V v_to_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Left: {
    V v_err_242 = heff_field(v_x2_241, 0);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erelayed_str0), ((V)&g_heff_2ebuild_2edev_2erelayed_str1)}), NTAG(TAG_Nil)});
    V v_t_244 = heff_intShow(heff_dup(heff_rfield(v_err_242, 0)));
    V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str2), heff_dup(heff_rfield(v_err_242, 1)));
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str3), heff_strAppend(v_t_244, v_t_245));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str4), heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2edev_2erelayed_str5)));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str6), heff_strAppend(v_to_240, v_t_247));
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(502LL), v_t_243, heff_bytesFromString(v_t_248)});
  }
  case TAG_Right: {
    V v_res_249 = heff_field(v_x2_241, 0);
    heff_drop(v_to_240);
    V v_t_2410 = (g_list_2efilter_24s514881809x1990693194(((V)&g_heff_2ebuild_2edev_2erelayed_str7), ((V)&g_heff_2ebuild_2edev_2erelayed_str8), ((V)&g_heff_2ebuild_2edev_2erelayed_str9), ((V)&g_heff_2ebuild_2edev_2erelayed_str10), ((V)&g_heff_2ebuild_2edev_2erelayed_str11), heff_dup(heff_rfield(v_res_249, 1))));
    return heff_rec_n(3, shape_status__headers__body, (V[]){heff_dup(heff_rfield(v_res_249, 0)), v_t_2410, heff_dup(heff_rfield(v_res_249, 2))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2erelayed(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str1, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str3, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str6, 5, "wrote");
HEFF_LIT(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str7, 3, "-O1");
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam2, 1, 0};
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_entry, 4, 0};

V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957(V v_prog_240, V v_st_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str0), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam1, 1, 4, (V[]){v_prog_240, v_hd_242, heff_dup(v_st_241), v_k_243})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam0(V self, V *args) {
  V v_ns_244 = args[0];
  return v_ns_244;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam2(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2428);
  V v_t_2430;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2425, 1)))) {
    heff_drop_rec(v_x_2425, 2);
    v_t_2430 = NTAG(TAG_Nil);
  } else {
    v_t_2430 = heff_get_n(v_x_2425, 0, 2);
  }
  V f_ = v_k_243;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2426 = heff_tag_n(TAG_End, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2426}));
  return (g_co_2eop_24s495635622x733177935(v_t_2427, v_hd_242, heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam5, 1, 2, (V[]){v_x_2425, v_k_243})));
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2418 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str2), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str3)));
  V v_t_2419 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str4), v_t_2418));
  V v_t_2420 = heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str5), v_t_2419, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str6), NTAG(TAG_True), NTAG(TAG_Nothing), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str7)});
  V v_t_2421 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2423;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    v_t_2423 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2422 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    v_t_2423 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_c_2424 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_241; V a_2 = v_t_2420; V a_3 = heff_dup(v_x_2417); V a_4 = v_t_2421; V a_5 = v_t_2423; V r_ = (g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_241); r_; });
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam4, 1, 4, (V[]){v_x_2417, v_prog_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    v_t_2413 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2412 = heff_dup(heff_field(v_x_2411, 0));
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_total_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2413; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
  V v_t_2416 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_str1), v_total_2414, ((V)&g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam2_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2416, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edev_2eappsNow_24s1962204922x1319080957_lam3, 1, 5, (V[]){v_st_241, v_x_2411, v_prog_240, v_hd_242, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_str0, 9, "dev-pages");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_str2, 33, "heff dev: cannot serve the pages\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_str3, 1, "c");
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam1(V self, V *args); static Clo g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam1, 1, 0};
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam14(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam0(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam18(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam15(V self, V *args);
Clo g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_entry, 7, 0};

V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(V v_prog_240, V v_clock_241, V v_ex_242, V v_st_243, V v_d_244, V v_stamp_245, V v_apps_246) {
top: ;
  V v_t_247 = (g_list_2eany_24s105899861x584770213(v_apps_246));
  V v_t_249 = heff_bool(((heff_dup(v_t_247) == NTAG(TAG_True)) && ({ V v_t_248 = heff_dup(heff_rfield(v_d_244, 4)); int c_ = !(heff_dup(v_t_248) == NTAG(TAG_True)); heff_drop(v_t_248); c_; })));
  heff_drop(v_t_247);
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam0, 2, 7, (V[]){v_ex_242, v_d_244, v_prog_240, v_clock_241, heff_dup(v_st_243), heff_dup(v_stamp_245), v_apps_246});
  } else {
    heff_drop(v_t_249);
    V v_c_2460 = (g_heff_2ebuild_2edev_2ebuiltSaid_24s2064775980x2109549196(v_st_243, heff_dup(v_d_244), heff_dup(v_apps_246)));
    return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam15, 2, 8, (V[]){v_c_2460, v_d_244, v_apps_246, v_prog_240, v_clock_241, v_ex_242, heff_dup(v_st_243), heff_dup(v_stamp_245)});
  }
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a5 = a[5]; V r = g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(a[0], a[1], a[2], a3, a[4], a5, a[6]); heff_drop(a3); heff_drop(a5); return r;
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  return v_s_2412;
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam8(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_2438 = args[1];
  V v_k_2439 = args[2];
  V v_x_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2437);
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_2435 = args[1];
  V v_k_2436 = args[2];
  V v_x_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2434);
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam8, 3, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2432;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam7, 3, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam5(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2430;
  args[0] = v_hd_2431;
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam6, 1, 1, (V[]){v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam4(V self, V *args) {
  V v_pg_2428 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_pg_2428);
  V v_t_2429 = ({ V rv_4 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_d_244, 15ULL, 5, shape_builds__wanted__port__proxy__pages, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_c_2430 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_t_2429; V a_5 = v_stamp_245; V a_6 = v_apps_246; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  return heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam5, 2, 1, (V[]){v_c_2430});
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam9(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_2421 = heff_env(self)[0];
  V v_k_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2440;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2421;
  heff_room[2] = v_k_2422;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_d_244 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_clock_241 = heff_env(self)[4];
  V v_st_243 = heff_env(self)[5];
  V v_stamp_245 = heff_env(self)[6];
  V v_apps_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2423 = heff_dup(heff_rfield(v_d_244, 3));
  V v_t_2425;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Nothing: {
    v_t_2425 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2424 = heff_field(v_t_2423, 0);
    heff_take_n(v_t_2423, 1ULL, 1);
    v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2424, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_d_244, 2)), v_t_2425});
  V v_t_2427 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2420, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_str0), v_t_2426}), ((V)&g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_str1), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  return (g_std_2eprocess_2ewithProcess_24s1854160028x1916200928(heff_dup(v_ex_242), v_t_2427, heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam4, 1, 7, (V[]){v_d_244, v_prog_240, v_clock_241, v_ex_242, v_st_243, v_stamp_245, v_apps_246}), heff_dup(v_hd_2421), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam9, 1, 2, (V[]){v_hd_2421, v_k_2422})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam13(V self, V *args) {
  V v_x_2455 = args[0];
  V v_hd_2456 = args[1];
  V v_k_2457 = args[2];
  V v_x_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2455);
  heff_drop(v_hd_2456);
  V f_ = v_k_2457;
  args[0] = v_x_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam12(V self, V *args) {
  V v_x_2454 = args[0];
  V v_k_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2443;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam13, 3, 1, (V[]){v_x_2454});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam11(V self, V *args) {
  V v_x_2451 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  V v_hd_2442 = heff_env(self)[7];
  V v_k_2443 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2451);
  V v_t_2452 = ({ V rv_4 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_d_244, 15ULL, 5, shape_builds__wanted__port__proxy__pages, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_c_2453 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = v_t_2452; V a_5 = v_stamp_245; V a_6 = v_apps_246; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_243); heff_drop(v_stamp_245); r_; });
  V f_ = v_c_2453;
  heff_room[0] = v_hd_2442;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam12, 1, 1, (V[]){v_k_2443});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam10(V self, V *args) {
  V v_err_2441 = args[0];
  V v_hd_2442 = args[1];
  V v_k_2443 = args[2];
  V v_d_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_err_2441);
  V v_t_2444 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_str2), NTAG(TAG_MkUnit)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), heff_dup(v_hd_2442), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam11, 1, 9, (V[]){v_d_244, v_prog_240, v_clock_241, v_ex_242, v_st_243, v_stamp_245, v_apps_246, v_hd_2442, v_k_2443})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam14(V self, V *args) {
  V v_x_2459 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2459;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2410;
  heff_room[2] = v_k_2411;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_ex_242 = heff_env(self)[0];
  V v_d_244 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  V v_hd_2410 = heff_env(self)[7];
  V v_k_2411 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2458 = heff_tr(heff_call(heff_dup(v_ex_242), 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam3, 2, 8, (V[]){heff_dup(v_d_244), v_x_2420, heff_dup(v_ex_242), heff_dup(v_prog_240), heff_dup(v_clock_241), heff_dup(v_st_243), heff_dup(v_stamp_245), heff_dup(v_apps_246)}), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam10, 3, 7, (V[]){v_d_244, v_prog_240, v_clock_241, v_ex_242, v_st_243, v_stamp_245, v_apps_246})})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2458, heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam14, 1, 2, (V[]){v_hd_2410, v_k_2411})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_ex_242 = heff_env(self)[0];
  V v_d_244 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_st_243 = heff_env(self)[4];
  V v_stamp_245 = heff_env(self)[5];
  V v_apps_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam1_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s495635622x733177935(v_t_2419, heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam2, 1, 9, (V[]){v_ex_242, v_d_244, v_prog_240, v_clock_241, v_st_243, v_stamp_245, v_apps_246, v_hd_2410, v_k_2411})));
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam17(V self, V *args) {
  V v_a_2465 = args[0];
  V v_wanted_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = heff_get_n(heff_dup(heff_rfield(v_a_2465, 1)), 0, 3);
  if (heff_strEq_c(v_t_2466, ((V)&g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_str3))) {
    switch (heff_tag_of(v_wanted_2464)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_2465, 2);
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_t_2470 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_a_2465, 0, 2)}));
      return ({ V a_0 = v_t_2470; V a_1 = v_wanted_2464; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_wanted_2464, 2); r_; });
    }
    default: return heff_nomatch(v_wanted_2464);
    }
  } else {
    heff_drop_rec(v_a_2465, 2);
    heff_drop(v_wanted_2464);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam18(V self, V *args) {
  V v_x_2473 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_clock_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_st_243 = heff_env(self)[3];
  V v_hd_2461 = heff_env(self)[4];
  V v_k_2462 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2474 = ({ V a_0 = v_prog_240; V a_1 = v_clock_241; V a_2 = v_ex_242; V a_3 = v_st_243; V a_4 = heff_take_field(v_x_2473, 0); V b_5 = heff_take_field(v_x_2473, 2); V a_6 = heff_get_n(v_x_2473, 1, 3); V r_ = (g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776(a_0, a_1, a_2, a_3, a_4, b_5, a_6)); heff_drop(v_st_243); heff_drop(b_5); r_; });
  V f_ = v_t_2474;
  heff_room[0] = v_hd_2461;
  heff_room[1] = v_k_2462;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam16(V self, V *args) {
  V v_x_2463 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_apps_246 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_clock_241 = heff_env(self)[3];
  V v_ex_242 = heff_env(self)[4];
  V v_st_243 = heff_env(self)[5];
  V v_stamp_245 = heff_env(self)[6];
  V v_hd_2461 = heff_env(self)[7];
  V v_k_2462 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2463);
  V v_wanted_2464 = heff_dup(heff_rfield(v_d_244, 1));
  V v_t_2471 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam17, 1, 1, (V[]){v_wanted_2464}), v_apps_246));
  V v_c_2472 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = heff_dup(v_clock_241); V a_2 = heff_dup(v_ex_242); V a_3 = v_st_243; V a_4 = v_d_244; V a_5 = v_stamp_245; V a_6 = NTAG(TAG_Nil); V a_7 = v_t_2471; V r_ = (g_heff_2ebuild_2edev_2eheld_24s1354292429x1677933040(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_stamp_245); r_; });
  V f_ = v_c_2472;
  heff_room[0] = heff_dup(v_hd_2461);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam18, 1, 6, (V[]){v_prog_240, v_clock_241, v_ex_242, v_st_243, v_hd_2461, v_k_2462});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam15(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_c_2460 = heff_env(self)[0];
  V v_d_244 = heff_env(self)[1];
  V v_apps_246 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_clock_241 = heff_env(self)[4];
  V v_ex_242 = heff_env(self)[5];
  V v_st_243 = heff_env(self)[6];
  V v_stamp_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2460;
  args[0] = heff_dup(v_hd_2461);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2ecycle_24s1497844419x1692708776_lam16, 1, 9, (V[]){v_d_244, v_apps_246, v_prog_240, v_clock_241, v_ex_242, v_st_243, v_stamp_245, v_hd_2461, v_k_2462});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str2, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str3, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str6, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str8, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str9, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str10, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str11, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str12, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str13, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str14, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str15, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str16, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str18, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str19, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str20, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str21, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str22, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str23, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str24, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str25, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str26, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str27, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str28, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str29, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str31, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str32, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str33, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str34, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str35, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str36, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str37, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str38, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str39, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str40, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str41, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str42, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str43, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str44, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str45, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str46, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str47, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str48, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str49, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str50, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str51, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str52, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str53, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str54, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str55, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str56, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str57, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str58, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str59, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str60, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str61, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str62, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str63, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str64, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str65, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str66, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str67, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str68, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str69, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str70, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str71, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str72, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str73, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str74, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str75, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str76, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str77, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str78, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str79, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str80, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str81, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str82, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str83, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str84, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str85, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str86, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str87, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str88, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str89, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str90, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str91, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str92, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str93, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str94, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str95, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str96, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str97, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str98, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str99, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str100, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str101, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str102, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str103, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str104, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str105, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str106, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str107, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str108, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str109, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str110, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str111, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str112, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str113, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str114, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str115, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str116, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str117, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str118, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str119, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str120, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str121, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str122, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str123, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str124, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str125, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str126, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str127, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str128, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str129, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str130, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str131, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str132, 13, "no such file\012");
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam0, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam3, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam6(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam6, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam10(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam10, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam12(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam12, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam14(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam14, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam16(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam16, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam19(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam19, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam20(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam18(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam21(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam23(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam23, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam24(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam22(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam25(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam25, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam27(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam27, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam28(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam26(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam29(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam31(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam31, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam32(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam30(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam33(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam33_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam33, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam35(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam35, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam36(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam34(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam38(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam38, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam40(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam40, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam41(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam39(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam37(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam43(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam43, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam44(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam42(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam45(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam47(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam47, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam48(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam46(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam49(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam49_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam49, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam51(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam51, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam52(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam50(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam53(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam55(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam55_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam55, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam56(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam54(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam57(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam57, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam58(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam60(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam60_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam60, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam62(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam62_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam62, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam63(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam61(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam59(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam65(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam65_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam65, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam66(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam64(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam67(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam69(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam69_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam69, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam70(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam68(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam71(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam71_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam71, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam73(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam73_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam73, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam74(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam72(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam75(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam77(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam77_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam77, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam78(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam76(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam79(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam79_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam79, 2, 0};
Clo g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_entry, 2, 0};

V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    V v_x22_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str3), 2)) {
      switch (heff_tag_of(v_x22_247)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam1, 2, 1, (V[]){v_x21_246});
      }
      case TAG_Cons: {
        V v_x221_2414 = heff_dup(heff_field(v_x22_247, 0));
        V v_x222_2415 = heff_dup(heff_field(v_x22_247, 1));
        if (heff_strEq_c_lent(v_x221_2414, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str8), 2)) {
          heff_drop(v_x221_2414);
          switch (heff_tag_of(v_x222_2415)) {
          case TAG_Nil: {
            heff_drop(v_x21_246);
            heff_drop_tag(v_x22_247, 2);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            V v_t_2417 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str9), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str10)));
            V v_path_2418 = (g_std_2epath_2ejoin(v_st_240, v_t_2417, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str11)));
            return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam2, 2, 1, (V[]){v_path_2418});
          }
          case TAG_Cons: {
            heff_take_n(v_x222_2415, 0ULL, 2);
            V v_x1_2438 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_2438) == NTAG(TAG_True))) {
              heff_drop(v_x1_2438);
              V v_t_2441;
              switch (heff_tag_of(v_x22_247)) {
              case TAG_Nil: {
                v_t_2441 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str17);
                break;
              }
              case TAG_Cons: {
                V v_x_2439 = heff_dup(heff_field(v_x22_247, 0));
                V v_xs_2440 = heff_dup(heff_field(v_x22_247, 1));
                v_t_2441 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str18); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
                break;
              }
              default: heff_nomatch(v_x22_247);
              }
              if (heff_strEq_c(v_t_2441, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str19)))) {
                heff_drop_tag(v_x22_247, 2);
                V v_t_2443 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str20), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str21)));
                V v_path_2444 = (g_std_2epath_2ejoin(v_st_240, v_t_2443, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str22))));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam5, 2, 2, (V[]){v_path_2444, v_x21_246});
              } else {
                V v_t_2457 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str24), v_x21_246));
                V v_path_2460 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam8, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_2457, v_x22_247));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam9, 2, 2, (V[]){v_path_2460, v_x22_247});
              }
            } else {
              heff_drop(v_x21_246);
              heff_drop_tag(v_x22_247, 2);
              heff_drop(v_x1_2438);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam12_clo);
            }
          }
          default: return heff_nomatch(v_x222_2415);
          }
        } else {
          if (heff_strEq_c(v_x221_2414, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str30))) {
            switch (heff_tag_of(v_x222_2415)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_247, 2);
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              V v_t_2481 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str31), heff_dup(v_x21_246)));
              V v_path_2482 = (g_std_2epath_2ejoin(v_st_240, v_t_2481, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str32)));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam13, 2, 3, (V[]){v_path_2482, heff_dup(v_st_240), v_x21_246});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_2415, 0ULL, 2);
              V v_x1_24113 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if ((heff_dup(v_x1_24113) == NTAG(TAG_True))) {
                heff_drop(v_x1_24113);
                V v_t_24116;
                switch (heff_tag_of(v_x22_247)) {
                case TAG_Nil: {
                  v_t_24116 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str36);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24114 = heff_dup(heff_field(v_x22_247, 0));
                  V v_xs_24115 = heff_dup(heff_field(v_x22_247, 1));
                  v_t_24116 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str37); V a_1 = v_x_24114; V a_2 = v_xs_24115; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24115); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_247);
                }
                if (heff_strEq_c(v_t_24116, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str38)))) {
                  heff_drop_tag(v_x22_247, 2);
                  V v_t_24118 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str39), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str40)));
                  V v_path_24119 = (g_std_2epath_2ejoin(v_st_240, v_t_24118, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str41))));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam18, 2, 2, (V[]){v_path_24119, v_x21_246});
                } else {
                  V v_t_24132 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str43), v_x21_246));
                  V v_path_24135 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam21, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24132, v_x22_247));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam22, 2, 2, (V[]){v_path_24135, v_x22_247});
                }
              } else {
                heff_drop(v_x21_246);
                heff_drop_tag(v_x22_247, 2);
                heff_drop(v_x1_24113);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam25_clo);
              }
            }
            default: return heff_nomatch(v_x222_2415);
            }
          } else {
            heff_drop(v_x222_2415);
            V v_x1_24155 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_24155) == NTAG(TAG_True))) {
              heff_drop(v_x1_24155);
              V v_t_24158;
              switch (heff_tag_of(v_x22_247)) {
              case TAG_Nil: {
                v_t_24158 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str49);
                break;
              }
              case TAG_Cons: {
                V v_x_24156 = heff_dup(heff_field(v_x22_247, 0));
                V v_xs_24157 = heff_dup(heff_field(v_x22_247, 1));
                v_t_24158 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str50); V a_1 = v_x_24156; V a_2 = v_xs_24157; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24157); r_; });
                break;
              }
              default: heff_nomatch(v_x22_247);
              }
              if (heff_strEq_c(v_t_24158, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str51)))) {
                heff_drop_tag(v_x22_247, 2);
                V v_t_24160 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str52), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str53)));
                V v_path_24161 = (g_std_2epath_2ejoin(v_st_240, v_t_24160, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str54))));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam26, 2, 2, (V[]){v_path_24161, v_x21_246});
              } else {
                V v_t_24174 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str56), v_x21_246));
                V v_path_24177 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam29, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24174, v_x22_247));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam30, 2, 2, (V[]){v_path_24177, v_x22_247});
              }
            } else {
              heff_drop(v_x21_246);
              heff_drop_tag(v_x22_247, 2);
              heff_drop(v_x1_24155);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam33_clo);
            }
          }
        }
      }
      default: return heff_nomatch(v_x22_247);
      }
    } else {
      if (heff_strEq_c_lent(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str62), 2)) {
        switch (heff_tag_of(v_x22_247)) {
        case TAG_Nil: {
          heff_drop(v_x21_246);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          V v_path_24198 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str63), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str64)));
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam34, 2, 1, (V[]){v_path_24198});
        }
        case TAG_Cons: {
          V v_x221_24211 = heff_dup(heff_field(v_x22_247, 0));
          V v_x222_24212 = heff_dup(heff_field(v_x22_247, 1));
          if (heff_strEq_c(v_x221_24211, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str65))) {
            switch (heff_tag_of(v_x222_24212)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_247, 2);
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              V v_t_24214 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str66), heff_dup(v_x21_246)));
              V v_path_24215 = (g_std_2epath_2ejoin(v_st_240, v_t_24214, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str67)));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam37, 2, 3, (V[]){v_path_24215, heff_dup(v_st_240), v_x21_246});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24212, 0ULL, 2);
              V v_x1_24246 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if ((heff_dup(v_x1_24246) == NTAG(TAG_True))) {
                heff_drop(v_x1_24246);
                V v_t_24249;
                switch (heff_tag_of(v_x22_247)) {
                case TAG_Nil: {
                  v_t_24249 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str71);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24247 = heff_dup(heff_field(v_x22_247, 0));
                  V v_xs_24248 = heff_dup(heff_field(v_x22_247, 1));
                  v_t_24249 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str72); V a_1 = v_x_24247; V a_2 = v_xs_24248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24248); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_247);
                }
                if (heff_strEq_c(v_t_24249, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str73)))) {
                  heff_drop_tag(v_x22_247, 2);
                  V v_t_24251 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str74), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str75)));
                  V v_path_24252 = (g_std_2epath_2ejoin(v_st_240, v_t_24251, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str76))));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam42, 2, 2, (V[]){v_path_24252, v_x21_246});
                } else {
                  V v_t_24265 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str78), v_x21_246));
                  V v_path_24268 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam45, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24265, v_x22_247));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam46, 2, 2, (V[]){v_path_24268, v_x22_247});
                }
              } else {
                heff_drop(v_x21_246);
                heff_drop_tag(v_x22_247, 2);
                heff_drop(v_x1_24246);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam49_clo);
              }
            }
            default: return heff_nomatch(v_x222_24212);
            }
          } else {
            heff_drop(v_x222_24212);
            V v_x1_24288 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_24288) == NTAG(TAG_True))) {
              heff_drop(v_x1_24288);
              V v_t_24291;
              switch (heff_tag_of(v_x22_247)) {
              case TAG_Nil: {
                v_t_24291 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str84);
                break;
              }
              case TAG_Cons: {
                V v_x_24289 = heff_dup(heff_field(v_x22_247, 0));
                V v_xs_24290 = heff_dup(heff_field(v_x22_247, 1));
                v_t_24291 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str85); V a_1 = v_x_24289; V a_2 = v_xs_24290; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24290); r_; });
                break;
              }
              default: heff_nomatch(v_x22_247);
              }
              if (heff_strEq_c(v_t_24291, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str86)))) {
                heff_drop_tag(v_x22_247, 2);
                V v_t_24293 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str87), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str88)));
                V v_path_24294 = (g_std_2epath_2ejoin(v_st_240, v_t_24293, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str89))));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam50, 2, 2, (V[]){v_path_24294, v_x21_246});
              } else {
                V v_t_24307 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str91), v_x21_246));
                V v_path_24310 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam53, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24307, v_x22_247));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam54, 2, 2, (V[]){v_path_24310, v_x22_247});
              }
            } else {
              heff_drop(v_x21_246);
              heff_drop_tag(v_x22_247, 2);
              heff_drop(v_x1_24288);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam57_clo);
            }
          }
        }
        default: return heff_nomatch(v_x22_247);
        }
      } else {
        switch (heff_tag_of(v_x22_247)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam58, 2, 1, (V[]){v_x21_246});
        }
        case TAG_Cons: {
          V v_x221_24335 = heff_dup(heff_field(v_x22_247, 0));
          V v_x222_24336 = heff_dup(heff_field(v_x22_247, 1));
          if (heff_strEq_c(v_x221_24335, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str101))) {
            switch (heff_tag_of(v_x222_24336)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_247, 2);
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              V v_t_24338 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str102), heff_dup(v_x21_246)));
              V v_path_24339 = (g_std_2epath_2ejoin(v_st_240, v_t_24338, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str103)));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam59, 2, 3, (V[]){v_path_24339, heff_dup(v_st_240), v_x21_246});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24336, 0ULL, 2);
              V v_x1_24370 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if ((heff_dup(v_x1_24370) == NTAG(TAG_True))) {
                heff_drop(v_x1_24370);
                V v_t_24373;
                switch (heff_tag_of(v_x22_247)) {
                case TAG_Nil: {
                  v_t_24373 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str107);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24371 = heff_dup(heff_field(v_x22_247, 0));
                  V v_xs_24372 = heff_dup(heff_field(v_x22_247, 1));
                  v_t_24373 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str108); V a_1 = v_x_24371; V a_2 = v_xs_24372; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24372); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_247);
                }
                if (heff_strEq_c(v_t_24373, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str109)))) {
                  heff_drop_tag(v_x22_247, 2);
                  V v_t_24375 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str110), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str111)));
                  V v_path_24376 = (g_std_2epath_2ejoin(v_st_240, v_t_24375, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str112))));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam64, 2, 2, (V[]){v_path_24376, v_x21_246});
                } else {
                  V v_t_24389 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str114), v_x21_246));
                  V v_path_24392 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam67, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24389, v_x22_247));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam68, 2, 2, (V[]){v_path_24392, v_x22_247});
                }
              } else {
                heff_drop(v_x21_246);
                heff_drop_tag(v_x22_247, 2);
                heff_drop(v_x1_24370);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam71_clo);
              }
            }
            default: return heff_nomatch(v_x222_24336);
            }
          } else {
            heff_drop(v_x222_24336);
            V v_x1_24412 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_24412) == NTAG(TAG_True))) {
              heff_drop(v_x1_24412);
              V v_t_24415;
              switch (heff_tag_of(v_x22_247)) {
              case TAG_Nil: {
                v_t_24415 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str120);
                break;
              }
              case TAG_Cons: {
                V v_x_24413 = heff_dup(heff_field(v_x22_247, 0));
                V v_xs_24414 = heff_dup(heff_field(v_x22_247, 1));
                v_t_24415 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str121); V a_1 = v_x_24413; V a_2 = v_xs_24414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24414); r_; });
                break;
              }
              default: heff_nomatch(v_x22_247);
              }
              if (heff_strEq_c(v_t_24415, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str122)))) {
                heff_drop_tag(v_x22_247, 2);
                V v_t_24417 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str123), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str124)));
                V v_path_24418 = (g_std_2epath_2ejoin(v_st_240, v_t_24417, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str125))));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam72, 2, 2, (V[]){v_path_24418, v_x21_246});
              } else {
                V v_t_24431 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str127), v_x21_246));
                V v_path_24434 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam75, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24431, v_x22_247));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam76, 2, 2, (V[]){v_path_24434, v_x22_247});
              }
            } else {
              heff_drop(v_x21_246);
              heff_drop_tag(v_x22_247, 2);
              heff_drop(v_x1_24412);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam79_clo);
            }
          }
        }
        default: return heff_nomatch(v_x22_247);
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str0), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str1)}), NTAG(TAG_Nil)});
  V v_t_245 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_244, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str2))});
  V f_ = v_k_243;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_x21_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_249);
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str4), heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str5)));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str6), v_t_2411}), NTAG(TAG_Nil)});
  V v_t_2413 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_2412, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str7))});
  V f_ = v_k_2410;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam3(V self, V *args) {
  V v_t_2421 = args[0];
  return v_t_2421;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_kind_2430 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str12); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str13), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str14)}), NTAG(TAG_Nil)});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str15), v_kind_2430}), v_t_2431});
  V v_t_2434;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Nothing: {
    v_t_2434 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str16);
    break;
  }
  case TAG_Just: {
    V v_x_2433 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 1);
    v_t_2434 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  V v_t_2435 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2432, heff_bytesFromString(v_t_2434)});
  V f_ = v_k_2420;
  args[0] = v_t_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_path_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2418, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam3_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s310418905x1614124229(v_t_2428, v_hd_2419, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam4, 1, 1, (V[]){v_k_2420})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam6(V self, V *args) {
  V v_t_2447 = args[0];
  return v_t_2447;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam7(V self, V *args) {
  V v_x_2455 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_2446 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2456 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str23)); V a_1 = v_x_2455; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2455); r_; });
  V f_ = v_k_2446;
  args[0] = v_x_2456;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam5(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_path_2444 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2444, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam6_clo)})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  return (g_co_2eop_24s310418905x1614124229(v_t_2454, v_hd_2445, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam7, 1, 2, (V[]){v_x21_246, v_k_2446})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam8(V self, V *args) {
  V v_p_2458 = args[0];
  V v_x_2459 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_2458; V a_2 = v_x_2459; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam10(V self, V *args) {
  V v_t_2463 = args[0];
  return v_t_2463;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam11(V self, V *args) {
  V v_x_2471 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_2462 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2474;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_2474 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str25);
    break;
  }
  case TAG_Cons: {
    V v_x_2472 = heff_field(v_x22_247, 0);
    V v_xs_2473 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_2474 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str26); V a_1 = v_x_2472; V a_2 = v_xs_2473; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2473); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_2475 = ({ V a_0 = v_t_2474; V a_1 = v_x_2471; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2471); r_; });
  V f_ = v_k_2462;
  args[0] = v_x_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam9(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_path_2460 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2460, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam10_clo)})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
  return (g_co_2eop_24s310418905x1614124229(v_t_2470, v_hd_2461, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam11, 1, 2, (V[]){v_x22_247, v_k_2462})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam12(V self, V *args) {
  V v_hd_2476 = args[0];
  V v_k_2477 = args[1];
  heff_drop(v_hd_2476);
  V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str27), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str28)}), NTAG(TAG_Nil)});
  V v_t_2479 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2478, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str29))});
  V f_ = v_k_2477;
  args[0] = v_t_2479;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam14(V self, V *args) {
  V v_t_2485 = args[0];
  return v_t_2485;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam16(V self, V *args) {
  V v_r_2496 = args[0];
  return v_r_2496;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam17(V self, V *args) {
  V v_x_24104 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_x_2493 = heff_env(self)[1];
  V v_k_2484 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24104)) {
  case TAG_Left: {
    heff_take_n(v_x_24104, 0ULL, 1);
    V v_x_24106 = ({ V a_0 = v_x21_246; V b_1 = NTAG(TAG_False); V a_2 = v_x_2493; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_x_2493); r_; });
    V f_ = v_k_2484;
    args[0] = v_x_24106;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_24107 = heff_field(v_x_24104, 0);
    heff_take_n(v_x_24104, 1ULL, 1);
    V v_t_24108 = heff_get_n(v_s_24107, 0, 4);
    V v_t_24109;
    switch (heff_tag_of(v_t_24108)) {
    case TAG_Regular: {
      v_t_24109 = NTAG(TAG_True);
      break;
    }
    case TAG_Directory: {
      v_t_24109 = NTAG(TAG_False);
      break;
    }
    case TAG_Link: {
      v_t_24109 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_24109 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_24108);
    }
    V v_x_24110 = ({ V a_0 = v_x21_246; V a_1 = v_t_24109; V a_2 = v_x_2493; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_t_24109); heff_drop(v_x_2493); r_; });
    V f_ = v_k_2484;
    args[0] = v_x_24110;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_24104);
  }
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam15(V self, V *args) {
  V v_x_2493 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  V v_hd_2483 = heff_env(self)[2];
  V v_k_2484 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2494 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str33), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str34)));
  V v_path_2495 = ({ V a_0 = v_st_240; V a_1 = v_t_2494; V a_2 = heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str35)); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V v_t_2497 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_path_2495, NTAG(TAG_True), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam16_clo)});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
  V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24102})});
  return (g_co_2eop_24s310418905x1614124229(heff_tag_n(TAG_InR, 1, (V[]){v_t_24103}), v_hd_2483, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam17, 1, 3, (V[]){v_x21_246, v_x_2493, v_k_2484})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam13(V self, V *args) {
  V v_hd_2483 = args[0];
  V v_k_2484 = args[1];
  V v_path_2482 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x21_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2482, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam14_clo)})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})});
  return (g_co_2eop_24s310418905x1614124229(v_t_2492, heff_dup(v_hd_2483), heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam15, 1, 4, (V[]){v_st_240, v_x21_246, v_hd_2483, v_k_2484})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam19(V self, V *args) {
  V v_t_24122 = args[0];
  return v_t_24122;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam20(V self, V *args) {
  V v_x_24130 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24121 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24131 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str42)); V a_1 = v_x_24130; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24130); r_; });
  V f_ = v_k_24121;
  args[0] = v_x_24131;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam18(V self, V *args) {
  V v_hd_24120 = args[0];
  V v_k_24121 = args[1];
  V v_path_24119 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24123 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24119, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam19_clo)})});
  V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
  V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24124})});
  V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
  V v_t_24127 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24126})});
  V v_t_24128 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24127})});
  V v_t_24129 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24128})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24129, v_hd_24120, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam20, 1, 2, (V[]){v_x21_246, v_k_24121})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam21(V self, V *args) {
  V v_p_24133 = args[0];
  V v_x_24134 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24133; V a_2 = v_x_24134; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam23(V self, V *args) {
  V v_t_24138 = args[0];
  return v_t_24138;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam24(V self, V *args) {
  V v_x_24146 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24137 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24149;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24149 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str44);
    break;
  }
  case TAG_Cons: {
    V v_x_24147 = heff_field(v_x22_247, 0);
    V v_xs_24148 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24149 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str45); V a_1 = v_x_24147; V a_2 = v_xs_24148; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24148); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24150 = ({ V a_0 = v_t_24149; V a_1 = v_x_24146; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24146); r_; });
  V f_ = v_k_24137;
  args[0] = v_x_24150;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam22(V self, V *args) {
  V v_hd_24136 = args[0];
  V v_k_24137 = args[1];
  V v_path_24135 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24139 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24135, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam23_clo)})});
  V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
  V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
  V v_t_24142 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24141})});
  V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
  V v_t_24144 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24143})});
  V v_t_24145 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24144})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24145, v_hd_24136, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam24, 1, 2, (V[]){v_x22_247, v_k_24137})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam25(V self, V *args) {
  V v_hd_24151 = args[0];
  V v_k_24152 = args[1];
  heff_drop(v_hd_24151);
  V v_t_24153 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str46), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str47)}), NTAG(TAG_Nil)});
  V v_t_24154 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24153, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str48))});
  V f_ = v_k_24152;
  args[0] = v_t_24154;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam27(V self, V *args) {
  V v_t_24164 = args[0];
  return v_t_24164;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam28(V self, V *args) {
  V v_x_24172 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24163 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24173 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str55)); V a_1 = v_x_24172; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24172); r_; });
  V f_ = v_k_24163;
  args[0] = v_x_24173;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam26(V self, V *args) {
  V v_hd_24162 = args[0];
  V v_k_24163 = args[1];
  V v_path_24161 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24165 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24161, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam27_clo)})});
  V v_t_24166 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24165})});
  V v_t_24167 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24166})});
  V v_t_24168 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24167})});
  V v_t_24169 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24168})});
  V v_t_24170 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24169})});
  V v_t_24171 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24170})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24171, v_hd_24162, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam28, 1, 2, (V[]){v_x21_246, v_k_24163})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam29(V self, V *args) {
  V v_p_24175 = args[0];
  V v_x_24176 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24175; V a_2 = v_x_24176; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam31(V self, V *args) {
  V v_t_24180 = args[0];
  return v_t_24180;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam32(V self, V *args) {
  V v_x_24188 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24179 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24191;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24191 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str57);
    break;
  }
  case TAG_Cons: {
    V v_x_24189 = heff_field(v_x22_247, 0);
    V v_xs_24190 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24191 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str58); V a_1 = v_x_24189; V a_2 = v_xs_24190; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24190); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24192 = ({ V a_0 = v_t_24191; V a_1 = v_x_24188; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24188); r_; });
  V f_ = v_k_24179;
  args[0] = v_x_24192;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam30(V self, V *args) {
  V v_hd_24178 = args[0];
  V v_k_24179 = args[1];
  V v_path_24177 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24181 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24177, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam31_clo)})});
  V v_t_24182 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24181})});
  V v_t_24183 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24182})});
  V v_t_24184 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24183})});
  V v_t_24185 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24184})});
  V v_t_24186 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24185})});
  V v_t_24187 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24186})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24187, v_hd_24178, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam32, 1, 2, (V[]){v_x22_247, v_k_24179})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam33(V self, V *args) {
  V v_hd_24193 = args[0];
  V v_k_24194 = args[1];
  heff_drop(v_hd_24193);
  V v_t_24195 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str59), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str60)}), NTAG(TAG_Nil)});
  V v_t_24196 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24195, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str61))});
  V f_ = v_k_24194;
  args[0] = v_t_24196;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam35(V self, V *args) {
  V v_ns_24201 = args[0];
  return v_ns_24201;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam36(V self, V *args) {
  V v_x_24209 = args[0];
  V v_k_24200 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_24210 = ({ V a_0 = v_x_24209; V r_ = (g_heff_2ebuild_2edev_2eindexAnswer(a_0)); heff_drop(v_x_24209); r_; });
  V f_ = v_k_24200;
  args[0] = v_x_24210;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam34(V self, V *args) {
  V v_hd_24199 = args[0];
  V v_k_24200 = args[1];
  V v_path_24198 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24202 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_path_24198, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam35_clo)})});
  V v_t_24203 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24202})});
  V v_t_24204 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24203})});
  V v_t_24205 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24204})});
  V v_t_24206 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24205})});
  V v_t_24207 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24206})});
  V v_t_24208 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24207})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24208, v_hd_24199, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam36, 1, 1, (V[]){v_k_24200})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam38(V self, V *args) {
  V v_t_24218 = args[0];
  return v_t_24218;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam40(V self, V *args) {
  V v_r_24229 = args[0];
  return v_r_24229;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam41(V self, V *args) {
  V v_x_24237 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_x_24226 = heff_env(self)[1];
  V v_k_24217 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24237)) {
  case TAG_Left: {
    heff_take_n(v_x_24237, 0ULL, 1);
    V v_x_24239 = ({ V a_0 = v_x21_246; V b_1 = NTAG(TAG_False); V a_2 = v_x_24226; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_x_24226); r_; });
    V f_ = v_k_24217;
    args[0] = v_x_24239;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_24240 = heff_field(v_x_24237, 0);
    heff_take_n(v_x_24237, 1ULL, 1);
    V v_t_24241 = heff_get_n(v_s_24240, 0, 4);
    V v_t_24242;
    switch (heff_tag_of(v_t_24241)) {
    case TAG_Regular: {
      v_t_24242 = NTAG(TAG_True);
      break;
    }
    case TAG_Directory: {
      v_t_24242 = NTAG(TAG_False);
      break;
    }
    case TAG_Link: {
      v_t_24242 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_24242 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_24241);
    }
    V v_x_24243 = ({ V a_0 = v_x21_246; V a_1 = v_t_24242; V a_2 = v_x_24226; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_t_24242); heff_drop(v_x_24226); r_; });
    V f_ = v_k_24217;
    args[0] = v_x_24243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_24237);
  }
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam39(V self, V *args) {
  V v_x_24226 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  V v_hd_24216 = heff_env(self)[2];
  V v_k_24217 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24227 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str68), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str69)));
  V v_path_24228 = ({ V a_0 = v_st_240; V a_1 = v_t_24227; V a_2 = heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str70)); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V v_t_24230 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_path_24228, NTAG(TAG_True), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam40_clo)});
  V v_t_24231 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24230})});
  V v_t_24232 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24231})});
  V v_t_24233 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24232})});
  V v_t_24234 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24233})});
  V v_t_24235 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24234})});
  V v_t_24236 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24235})});
  return (g_co_2eop_24s310418905x1614124229(heff_tag_n(TAG_InR, 1, (V[]){v_t_24236}), v_hd_24216, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam41, 1, 3, (V[]){v_x21_246, v_x_24226, v_k_24217})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam37(V self, V *args) {
  V v_hd_24216 = args[0];
  V v_k_24217 = args[1];
  V v_path_24215 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x21_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24219 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24215, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam38_clo)})});
  V v_t_24220 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24219})});
  V v_t_24221 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24220})});
  V v_t_24222 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24221})});
  V v_t_24223 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24222})});
  V v_t_24224 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24223})});
  V v_t_24225 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24224})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24225, heff_dup(v_hd_24216), heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam39, 1, 4, (V[]){v_st_240, v_x21_246, v_hd_24216, v_k_24217})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam43(V self, V *args) {
  V v_t_24255 = args[0];
  return v_t_24255;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam44(V self, V *args) {
  V v_x_24263 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24254 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24264 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str77)); V a_1 = v_x_24263; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24263); r_; });
  V f_ = v_k_24254;
  args[0] = v_x_24264;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam42(V self, V *args) {
  V v_hd_24253 = args[0];
  V v_k_24254 = args[1];
  V v_path_24252 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24256 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24252, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam43_clo)})});
  V v_t_24257 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24256})});
  V v_t_24258 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24257})});
  V v_t_24259 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24258})});
  V v_t_24260 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24259})});
  V v_t_24261 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24260})});
  V v_t_24262 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24261})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24262, v_hd_24253, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam44, 1, 2, (V[]){v_x21_246, v_k_24254})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam45(V self, V *args) {
  V v_p_24266 = args[0];
  V v_x_24267 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24266; V a_2 = v_x_24267; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam47(V self, V *args) {
  V v_t_24271 = args[0];
  return v_t_24271;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam48(V self, V *args) {
  V v_x_24279 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24270 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24282;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24282 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str79);
    break;
  }
  case TAG_Cons: {
    V v_x_24280 = heff_field(v_x22_247, 0);
    V v_xs_24281 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24282 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str80); V a_1 = v_x_24280; V a_2 = v_xs_24281; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24281); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24283 = ({ V a_0 = v_t_24282; V a_1 = v_x_24279; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24279); r_; });
  V f_ = v_k_24270;
  args[0] = v_x_24283;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam46(V self, V *args) {
  V v_hd_24269 = args[0];
  V v_k_24270 = args[1];
  V v_path_24268 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24272 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24268, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam47_clo)})});
  V v_t_24273 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24272})});
  V v_t_24274 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24273})});
  V v_t_24275 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24274})});
  V v_t_24276 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24275})});
  V v_t_24277 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24276})});
  V v_t_24278 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24277})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24278, v_hd_24269, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam48, 1, 2, (V[]){v_x22_247, v_k_24270})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam49(V self, V *args) {
  V v_hd_24284 = args[0];
  V v_k_24285 = args[1];
  heff_drop(v_hd_24284);
  V v_t_24286 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str81), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str82)}), NTAG(TAG_Nil)});
  V v_t_24287 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24286, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str83))});
  V f_ = v_k_24285;
  args[0] = v_t_24287;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam51(V self, V *args) {
  V v_t_24297 = args[0];
  return v_t_24297;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam52(V self, V *args) {
  V v_x_24305 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24296 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24306 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str90)); V a_1 = v_x_24305; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24305); r_; });
  V f_ = v_k_24296;
  args[0] = v_x_24306;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam50(V self, V *args) {
  V v_hd_24295 = args[0];
  V v_k_24296 = args[1];
  V v_path_24294 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24298 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24294, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam51_clo)})});
  V v_t_24299 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24298})});
  V v_t_24300 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24299})});
  V v_t_24301 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24300})});
  V v_t_24302 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24301})});
  V v_t_24303 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24302})});
  V v_t_24304 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24303})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24304, v_hd_24295, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam52, 1, 2, (V[]){v_x21_246, v_k_24296})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam53(V self, V *args) {
  V v_p_24308 = args[0];
  V v_x_24309 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24308; V a_2 = v_x_24309; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam55(V self, V *args) {
  V v_t_24313 = args[0];
  return v_t_24313;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam56(V self, V *args) {
  V v_x_24321 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24312 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24324;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24324 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str92);
    break;
  }
  case TAG_Cons: {
    V v_x_24322 = heff_field(v_x22_247, 0);
    V v_xs_24323 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24324 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str93); V a_1 = v_x_24322; V a_2 = v_xs_24323; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24323); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24325 = ({ V a_0 = v_t_24324; V a_1 = v_x_24321; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24321); r_; });
  V f_ = v_k_24312;
  args[0] = v_x_24325;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam54(V self, V *args) {
  V v_hd_24311 = args[0];
  V v_k_24312 = args[1];
  V v_path_24310 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24314 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24310, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam55_clo)})});
  V v_t_24315 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24314})});
  V v_t_24316 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24315})});
  V v_t_24317 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24316})});
  V v_t_24318 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24317})});
  V v_t_24319 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24318})});
  V v_t_24320 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24319})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24320, v_hd_24311, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam56, 1, 2, (V[]){v_x22_247, v_k_24312})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam57(V self, V *args) {
  V v_hd_24326 = args[0];
  V v_k_24327 = args[1];
  heff_drop(v_hd_24326);
  V v_t_24328 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str94), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str95)}), NTAG(TAG_Nil)});
  V v_t_24329 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24328, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str96))});
  V f_ = v_k_24327;
  args[0] = v_t_24329;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam58(V self, V *args) {
  V v_hd_24330 = args[0];
  V v_k_24331 = args[1];
  V v_x21_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24330);
  V v_t_24332 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str97), heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str98)));
  V v_t_24333 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str99), v_t_24332}), NTAG(TAG_Nil)});
  V v_t_24334 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_24333, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str100))});
  V f_ = v_k_24331;
  args[0] = v_t_24334;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam60(V self, V *args) {
  V v_t_24342 = args[0];
  return v_t_24342;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam62(V self, V *args) {
  V v_r_24353 = args[0];
  return v_r_24353;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam63(V self, V *args) {
  V v_x_24361 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_x_24350 = heff_env(self)[1];
  V v_k_24341 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24361)) {
  case TAG_Left: {
    heff_take_n(v_x_24361, 0ULL, 1);
    V v_x_24363 = ({ V a_0 = v_x21_246; V b_1 = NTAG(TAG_False); V a_2 = v_x_24350; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_x_24350); r_; });
    V f_ = v_k_24341;
    args[0] = v_x_24363;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_24364 = heff_field(v_x_24361, 0);
    heff_take_n(v_x_24361, 1ULL, 1);
    V v_t_24365 = heff_get_n(v_s_24364, 0, 4);
    V v_t_24366;
    switch (heff_tag_of(v_t_24365)) {
    case TAG_Regular: {
      v_t_24366 = NTAG(TAG_True);
      break;
    }
    case TAG_Directory: {
      v_t_24366 = NTAG(TAG_False);
      break;
    }
    case TAG_Link: {
      v_t_24366 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_24366 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_24365);
    }
    V v_x_24367 = ({ V a_0 = v_x21_246; V a_1 = v_t_24366; V a_2 = v_x_24350; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_t_24366); heff_drop(v_x_24350); r_; });
    V f_ = v_k_24341;
    args[0] = v_x_24367;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_24361);
  }
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam61(V self, V *args) {
  V v_x_24350 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  V v_hd_24340 = heff_env(self)[2];
  V v_k_24341 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24351 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str104), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str105)));
  V v_path_24352 = ({ V a_0 = v_st_240; V a_1 = v_t_24351; V a_2 = heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str106)); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V v_t_24354 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_path_24352, NTAG(TAG_True), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam62_clo)});
  V v_t_24355 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24354})});
  V v_t_24356 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24355})});
  V v_t_24357 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24356})});
  V v_t_24358 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24357})});
  V v_t_24359 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24358})});
  V v_t_24360 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24359})});
  return (g_co_2eop_24s310418905x1614124229(heff_tag_n(TAG_InR, 1, (V[]){v_t_24360}), v_hd_24340, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam63, 1, 3, (V[]){v_x21_246, v_x_24350, v_k_24341})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam59(V self, V *args) {
  V v_hd_24340 = args[0];
  V v_k_24341 = args[1];
  V v_path_24339 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x21_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24343 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24339, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam60_clo)})});
  V v_t_24344 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24343})});
  V v_t_24345 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24344})});
  V v_t_24346 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24345})});
  V v_t_24347 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24346})});
  V v_t_24348 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24347})});
  V v_t_24349 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24348})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24349, heff_dup(v_hd_24340), heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam61, 1, 4, (V[]){v_st_240, v_x21_246, v_hd_24340, v_k_24341})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam65(V self, V *args) {
  V v_t_24379 = args[0];
  return v_t_24379;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam66(V self, V *args) {
  V v_x_24387 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24378 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24388 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str113)); V a_1 = v_x_24387; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24387); r_; });
  V f_ = v_k_24378;
  args[0] = v_x_24388;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam64(V self, V *args) {
  V v_hd_24377 = args[0];
  V v_k_24378 = args[1];
  V v_path_24376 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24380 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24376, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam65_clo)})});
  V v_t_24381 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24380})});
  V v_t_24382 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24381})});
  V v_t_24383 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24382})});
  V v_t_24384 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24383})});
  V v_t_24385 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24384})});
  V v_t_24386 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24385})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24386, v_hd_24377, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam66, 1, 2, (V[]){v_x21_246, v_k_24378})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam67(V self, V *args) {
  V v_p_24390 = args[0];
  V v_x_24391 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24390; V a_2 = v_x_24391; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam69(V self, V *args) {
  V v_t_24395 = args[0];
  return v_t_24395;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam70(V self, V *args) {
  V v_x_24403 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24394 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24406;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24406 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str115);
    break;
  }
  case TAG_Cons: {
    V v_x_24404 = heff_field(v_x22_247, 0);
    V v_xs_24405 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24406 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str116); V a_1 = v_x_24404; V a_2 = v_xs_24405; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24405); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24407 = ({ V a_0 = v_t_24406; V a_1 = v_x_24403; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24403); r_; });
  V f_ = v_k_24394;
  args[0] = v_x_24407;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam68(V self, V *args) {
  V v_hd_24393 = args[0];
  V v_k_24394 = args[1];
  V v_path_24392 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24396 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24392, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam69_clo)})});
  V v_t_24397 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24396})});
  V v_t_24398 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24397})});
  V v_t_24399 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24398})});
  V v_t_24400 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24399})});
  V v_t_24401 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24400})});
  V v_t_24402 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24401})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24402, v_hd_24393, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam70, 1, 2, (V[]){v_x22_247, v_k_24394})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam71(V self, V *args) {
  V v_hd_24408 = args[0];
  V v_k_24409 = args[1];
  heff_drop(v_hd_24408);
  V v_t_24410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str117), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str118)}), NTAG(TAG_Nil)});
  V v_t_24411 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24410, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str119))});
  V f_ = v_k_24409;
  args[0] = v_t_24411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam73(V self, V *args) {
  V v_t_24421 = args[0];
  return v_t_24421;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam74(V self, V *args) {
  V v_x_24429 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24430 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str126)); V a_1 = v_x_24429; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24429); r_; });
  V f_ = v_k_24420;
  args[0] = v_x_24430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam72(V self, V *args) {
  V v_hd_24419 = args[0];
  V v_k_24420 = args[1];
  V v_path_24418 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24418, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam73_clo)})});
  V v_t_24423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24422})});
  V v_t_24424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24423})});
  V v_t_24425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24424})});
  V v_t_24426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24425})});
  V v_t_24427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24426})});
  V v_t_24428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24427})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24428, v_hd_24419, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam74, 1, 2, (V[]){v_x21_246, v_k_24420})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam75(V self, V *args) {
  V v_p_24432 = args[0];
  V v_x_24433 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24432; V a_2 = v_x_24433; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam77(V self, V *args) {
  V v_t_24437 = args[0];
  return v_t_24437;
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam78(V self, V *args) {
  V v_x_24445 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24448;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24448 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str128);
    break;
  }
  case TAG_Cons: {
    V v_x_24446 = heff_field(v_x22_247, 0);
    V v_xs_24447 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24448 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str129); V a_1 = v_x_24446; V a_2 = v_xs_24447; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24447); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24449 = ({ V a_0 = v_t_24448; V a_1 = v_x_24445; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24445); r_; });
  V f_ = v_k_24436;
  args[0] = v_x_24449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam76(V self, V *args) {
  V v_hd_24435 = args[0];
  V v_k_24436 = args[1];
  V v_path_24434 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24434, ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam77_clo)})});
  V v_t_24439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24438})});
  V v_t_24440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24439})});
  V v_t_24441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24440})});
  V v_t_24442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24441})});
  V v_t_24443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24442})});
  V v_t_24444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24443})});
  return (g_co_2eop_24s310418905x1614124229(v_t_24444, v_hd_24435, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam78, 1, 2, (V[]){v_x22_247, v_k_24436})));
}
V g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_lam79(V self, V *args) {
  V v_hd_24450 = args[0];
  V v_k_24451 = args[1];
  heff_drop(v_hd_24450);
  V v_t_24452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str130), ((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str131)}), NTAG(TAG_Nil)});
  V v_t_24453 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24452, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s423198816x2049413547_str132))});
  V f_ = v_k_24451;
  args[0] = v_t_24453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str0, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str1, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str2, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str3, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str4, 10, "keep-alive");
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam0, 1, 0};
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_entry, 5, 0};

V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210(V v_web_240, V v_to_241, V v_req_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = heff_strAppend(heff_dup(v_to_241), heff_take_field(v_req_242, 1));
  V v_t_246 = (g_list_2efilter_24s514881809x1990693194(((V)&g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str0), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str1), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str2), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str3), ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_str4), heff_take_field(v_req_242, 3)));
  V v_rq_247 = heff_rec_n(6, shape_url__method__headers__body__timeout__follow, (V[]){v_t_245, heff_take_field(v_req_242, 0), v_t_246, heff_get_n(v_req_242, 4, 6), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_249 = heff_tr(heff_call(v_web_240, 1, (V[]){heff_tag_n(TAG_Send, 2, (V[]){v_rq_247, ((V)&g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam0_clo)})}));
  return (g_co_2eop_24s310418905x1614124229(v_t_249, v_z_243, heff_clo_n(g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam1, 1, 2, (V[]){v_to_241, v_z_244})));
}
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam0(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2edev_2eforwarded_24s1591549241x1872088210_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_to_241 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = ({ V a_0 = v_to_241; V a_1 = v_x_2410; V r_ = (g_heff_2ebuild_2edev_2erelayed(a_0, a_1)); heff_drop(v_x_2410); r_; });
  V f_ = v_z_244;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str0, 9, "127.0.0.1");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str2, 19, ", the rest sent to ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str3, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str4, 40, "heff dev: the pages at http://127.0.0.1:");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str6, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str7, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str9, 41, "heff dev: cannot serve the pages at port ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str10, 1, "\012");
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam0, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam9(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam9, 3, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam8(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam8, 3, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam14(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam12(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam16(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_entry, 8, 0};

V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740(V v_nt_240, V v_rx_241, V v_web_242, V v_nx_243, V v_port_244, V v_proxy_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s495635622x733177935(v_t_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam1, 1, 8, (V[]){v_port_244, v_nt_240, v_nx_243, v_proxy_245, v_rx_241, v_web_242, v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam5(V self, V *args) {
  V v_p_2442 = args[0];
  V v_web_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443 = heff_tr(heff_call(v_web_242, 1, (V[]){v_p_2442}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2443});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam6(V self, V *args) {
  V v_p_2445 = args[0];
  V v_nt_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_tr(heff_call(v_nt_240, 1, (V[]){v_p_2445}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2446});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_hd_2455 = args[1];
  V v_k_2456 = args[2];
  heff_drop(v_x_2454);
  heff_drop(v_hd_2455);
  V f_ = v_k_2456;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam8(V self, V *args) {
  V v_x_2451 = args[0];
  V v_hd_2452 = args[1];
  V v_k_2453 = args[2];
  heff_drop(v_x_2451);
  heff_drop(v_hd_2452);
  V f_ = v_k_2453;
  args[0] = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam9_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam7(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2450);
  V f_ = v_k_2425;
  args[0] = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam8_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam4(V self, V *args) {
  V v_x_2439 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_web_242 = heff_env(self)[1];
  V v_proxy_245 = heff_env(self)[2];
  V v_nt_240 = heff_env(self)[3];
  V v_listener_2423 = heff_env(self)[4];
  V v_t_2438 = heff_env(self)[5];
  V v_hd_2424 = heff_env(self)[6];
  V v_k_2425 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2441;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str6))) {
    v_t_2441 = NTAG(TAG_Windows);
  } else {
    v_t_2441 = NTAG(TAG_Posix);
  }
  V v_t_2444 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edev_2eserved_24s415977329x1817796958_clo), 3, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam5, 1, 1, (V[]){v_web_242}), v_t_2441, v_proxy_245}));
  V v_t_2447 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam6, 1, 1, (V[]){v_nt_240}); V a_1 = v_listener_2423; V a_2 = v_t_2444; V r_ = heff_tr(g_std_2ehttp_2eserver_2eserveConcurrently_24s729664635x1487989391(a_0, a_1, a_2)); heff_drop(v_listener_2423); r_; });
  V v_t_2448 = (g_green_2eview_24s192594942x2076863488(heff_tag_n(TAG_Main, 1, (V[]){v_t_2447})));
  V v_t_2449 = (g_green_2ego_24s850908287x1133196696(v_t_2438, v_x_2439, heff_rec_n(6, shape_ready__chans__waiting__next__pending__turns, (V[]){heff_dup(g_green_2eemptyQ_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}), v_t_2448));
  V f_ = v_t_2449;
  heff_room[0] = v_hd_2424;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam7, 1, 1, (V[]){v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam3(V self, V *args) {
  V v_x_2437 = args[0];
  V v_rx_241 = heff_env(self)[0];
  V v_hd_2424 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_web_242 = heff_env(self)[3];
  V v_proxy_245 = heff_env(self)[4];
  V v_nt_240 = heff_env(self)[5];
  V v_listener_2423 = heff_env(self)[6];
  V v_k_2425 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2437);
  V v_t_2438 = (g_std_2ereactor_2eoutside_24s283078862x396680432(v_rx_241));
  V f_ = heff_dup(heff_rfield(v_t_2438, 0));
  heff_room[0] = heff_dup(v_hd_2424);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam4, 1, 8, (V[]){v_x_2416, v_web_242, v_proxy_245, v_nt_240, v_listener_2423, v_t_2438, v_hd_2424, v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam2(V self, V *args) {
  V v_listener_2423 = args[0];
  V v_hd_2424 = args[1];
  V v_k_2425 = args[2];
  V v_proxy_245 = heff_env(self)[0];
  V v_port_244 = heff_env(self)[1];
  V v_rx_241 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_web_242 = heff_env(self)[4];
  V v_nt_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2427;
  switch (heff_tag_of(v_proxy_245)) {
  case TAG_Nothing: {
    v_t_2427 = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2426 = heff_dup(heff_field(v_proxy_245, 0));
    v_t_2427 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str2), v_x_2426);
    break;
  }
  default: heff_nomatch(v_proxy_245);
  }
  V v_t_2428 = heff_strAppend(v_port_244, heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str3), v_t_2427));
  V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str4), v_t_2428), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str5));
  V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2429, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_hd_2424), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam3, 1, 8, (V[]){v_rx_241, v_hd_2424, v_x_2416, v_web_242, v_proxy_245, v_nt_240, v_listener_2423, v_k_2425})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam11(V self, V *args) {
  V v_x_2460 = args[0];
  V v_hd_2458 = heff_env(self)[0];
  V v_k_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2460;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_2458;
  heff_room[2] = v_k_2459;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam10(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_c_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2457;
  args[0] = heff_dup(v_hd_2458);
  args[1] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam11, 1, 2, (V[]){v_hd_2458, v_k_2459});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam15(V self, V *args) {
  V v_x_2484 = args[0];
  V v_hd_2485 = args[1];
  V v_k_2486 = args[2];
  V v_x_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2484);
  heff_drop(v_hd_2485);
  V f_ = v_k_2486;
  args[0] = v_x_2483;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam14(V self, V *args) {
  V v_x_2483 = args[0];
  V v_k_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2463;
  args[0] = heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam15, 3, 1, (V[]){v_x_2483});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam13(V self, V *args) {
  V v_x_2475 = args[0];
  V v_hd_2462 = heff_env(self)[0];
  V v_k_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2475);
  V v_t_2476 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2482}), v_hd_2462, heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam14, 1, 1, (V[]){v_k_2463})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam12(V self, V *args) {
  V v_err_2461 = args[0];
  V v_hd_2462 = args[1];
  V v_k_2463 = args[2];
  V v_port_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2464 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str7), heff_take_field(v_err_2461, 2));
  V v_t_2465 = heff_strAppend(heff_get_n(v_err_2461, 1, 3), v_t_2464);
  V v_t_2466 = heff_strAppend(v_port_244, heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str8), v_t_2465));
  V v_t_2467 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str9), v_t_2466), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str10));
  V v_t_2468 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2467, NTAG(TAG_MkUnit)});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2474}), heff_dup(v_hd_2462), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam13, 1, 2, (V[]){v_hd_2462, v_k_2463})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam16(V self, V *args) {
  V v_x_2488 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2488;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_246;
  heff_room[2] = v_k_247;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_port_244 = heff_env(self)[0];
  V v_nt_240 = heff_env(self)[1];
  V v_nx_243 = heff_env(self)[2];
  V v_proxy_245 = heff_env(self)[3];
  V v_rx_241 = heff_env(self)[4];
  V v_web_242 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  HeffT2 v_t_2417 = (g_prelude_2eparseInt_24cpr(v_port_244));
  V v_t_2422;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_x_2421 = v_field_2419;
      v_t_2422 = v_x_2421;
    } else {
      heff_drop(v_field_2419);
      v_t_2422 = MK_INT(8000LL);
    }
  }
  V v_c_2457 = (g_std_2enet_2ewithListener_24s1242722304x1501661027(heff_dup(v_nt_240), heff_dup(v_nx_243), heff_rec_n(2, shape_host__port, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_str0), v_t_2422}), MK_INT(64LL), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam2, 3, 6, (V[]){v_proxy_245, heff_dup(v_port_244), v_rx_241, v_x_2416, v_web_242, v_nt_240})));
  V v_t_2487 = heff_tr(heff_call(v_nx_243, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam10, 2, 1, (V[]){v_c_2457}), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam12, 3, 1, (V[]){v_port_244})})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2487, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s1263933285x1982712740_lam16, 1, 2, (V[]){v_hd_246, v_k_247})));
}