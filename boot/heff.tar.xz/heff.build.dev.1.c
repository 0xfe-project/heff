// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Directory 35277
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_Listen 55096
#define TAG_NotRun 12703
#define TAG_Other 45236
#define TAG_PathStatus 29154
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Regular 40886
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_body 9524841
#define LBL_builds 569118448
#define LBL_code 9554612
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_headers 1027165638
#define LBL_kind 9787483
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_pages 307784670
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_running 1782641667
#define LBL_status 1054660381
#define LBL_target 1066236092
#define LBL_wanted 1152016858
static uint32_t shape_running__pages__builds__wanted__port__proxy[] = {LBL_running, LBL_pages, LBL_builds, LBL_wanted, LBL_port, LBL_proxy};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
V g_co_2eop_24s162716155x1210144019(V, V, V);
V g_co_2eop_24s162716155x1210144019_entry(V self, V *a);
extern Clo g_co_2eop_24s162716155x1210144019_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_green_2escheduledWith_24s323844761x1686441296(V, V, V, V);
V g_green_2escheduledWith_24s323844761x1686441296_entry(V self, V *a);
extern Clo g_green_2escheduledWith_24s323844761x1686441296_clo;
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388(V, V);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_clo;
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473(V, V, V, V, V);
V g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_clo;
V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655(V, V, V);
V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_clo;
V g_heff_2ebuild_2edev_2efileAnswer(V, V);
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2efileAnswer_clo;
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604(V, V, V, V, V);
V g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604_clo;
V g_heff_2ebuild_2edev_2eindexAnswer(V);
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eindexAnswer_clo;
V g_heff_2ebuild_2edev_2emadePage(V);
V g_heff_2ebuild_2edev_2emadePage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2emadePage_clo;
V g_heff_2ebuild_2edev_2eownPath(V);
V g_heff_2ebuild_2edev_2eownPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eownPath_clo;
V g_heff_2ebuild_2edev_2epageAnswer(V, V, V);
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epageAnswer_clo;
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_clo;
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452(V, V, V, V, V);
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_clo;
V g_heff_2ebuild_2edev_2erelayed(V, V);
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2erelayed_clo;
V g_heff_2ebuild_2edev_2ereloadScript_get(void);
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802(V, V, V, V);
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_clo;
V g_heff_2ebuild_2edev_2etypeOf(V);
V g_heff_2ebuild_2edev_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2etypeOf_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239_clo;
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716_clo;
V g_list_2eall_24s1579400704x1789597964(V);
V g_list_2eall_24s1579400704x1789597964_entry(V self, V *a);
extern Clo g_list_2eall_24s1579400704x1789597964_clo;
V g_list_2efilter_24s514881809x1990693194(V, V, V, V, V, V);
V g_list_2efilter_24s514881809x1990693194_entry(V self, V *a);
extern Clo g_list_2efilter_24s514881809x1990693194_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2emap_24f336527456x1519848451(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f336527456x1519848451_entry(V self, V *a);
extern Clo g_list_2emap_24f336527456x1519848451_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1684451694x373462712(V, V, V);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1684451694x373462712_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s1684451694x373462712_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);
V g_std_2ereactor_2eoutside_24s626113845x1580845692(V);
V g_std_2ereactor_2eoutside_24s626113845x1580845692_entry(V self, V *a);
extern Clo g_std_2ereactor_2eoutside_24s626113845x1580845692_clo;
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str0, 9, "</script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str1, 10, "  }, 500);");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str2, 5, "})();");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str3, 98, "      .then(function (t) { if (seen === null) seen = t; else if (t !== seen) location.reload(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str4, 29, "      .catch(function () {});");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str5, 48, "    fetch(\"/.heff/built\", { cache: \"no-store\" })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str6, 46, "      .then(function (r) { return r.text(); })");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str7, 18, "  var seen = null;");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str8, 27, "  setInterval(function () {");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str10, 8, "<script>");
HEFF_LIT(g_heff_2ebuild_2edev_2ereloadScript_str11, 14, "(function () {");

static V g_heff_2ebuild_2edev_2ereloadScript_val;
static HEFF_ONCE g_heff_2ebuild_2edev_2ereloadScript_st;
static V g_heff_2ebuild_2edev_2ereloadScript_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str9); V a_1 = ((V)&g_heff_2ebuild_2edev_2ereloadScript_str10); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2ereloadScript_str11), v_t_244}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2edev_2ereloadScript_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2edev_2ereloadScript_st)) return g_heff_2ebuild_2edev_2ereloadScript_val;
  return heff_global(&g_heff_2ebuild_2edev_2ereloadScript_val, &g_heff_2ebuild_2edev_2ereloadScript_st, g_heff_2ebuild_2edev_2ereloadScript_init);
}
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str2, 3, "no ");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str4, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str5, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2efileAnswer_str6, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2efileAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efileAnswer_entry, 2, 0};

V g_heff_2ebuild_2edev_2efileAnswer(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str0), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str1)}), NTAG(TAG_Nil)});
    V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2efileAnswer_str2), heff_strAppend(v_p_240, ((V)&g_heff_2ebuild_2edev_2efileAnswer_str3)));
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_242, heff_bytesFromString(v_t_243)});
  }
  case TAG_Just: {
    V v_text_244 = heff_field(v_x2_241, 0);
    V v_kind_245 = ({ V a_0 = v_p_240; V r_ = (g_heff_2ebuild_2edev_2etypeOf(a_0)); heff_drop(v_p_240); r_; });
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str4), ((V)&g_heff_2ebuild_2edev_2efileAnswer_str5)}), NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efileAnswer_str6), v_kind_245}), v_t_246});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_247, heff_bytesFromString(heff_dup(v_text_244))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2efileAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2efileAnswer(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str1, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str2, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str3, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str4, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str5, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str6, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str7, 8, "no page ");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str9, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str10, 7, "</body>");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str11, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str12, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2epageAnswer_str13, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2epageAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epageAnswer_entry, 3, 0};

V g_heff_2ebuild_2edev_2epageAnswer(V v_name_240, V v_built_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    if ((heff_dup(v_built_241) == NTAG(TAG_True))) {
      V v_kind_243 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str0); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
      V v_html_244 = (g_heff_2ebuild_2edev_2emadePage(v_name_240));
      V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str1), v_html_244, MK_INT(0LL), 5);
      V v_text_248;
      if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
        heff_drop(v_j_245);
        v_text_248 = heff_strAppend(v_html_244, heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
      } else {
        V v_t_247 = heff_strSlice(heff_dup(v_html_244), heff_dup(v_j_245), heff_strLength_lent(v_html_244, 0));
        v_text_248 = heff_strAppend(heff_strSlice(v_html_244, MK_INT(0LL), v_j_245), heff_strAppend(heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), v_t_247));
      }
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str2), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str3)}), NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str4), v_kind_243}), v_t_249});
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2410, heff_bytesFromString(v_text_248)});
    } else {
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str5), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str6)}), NTAG(TAG_Nil)});
      V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epageAnswer_str7), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2edev_2epageAnswer_str8)));
      return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2411, heff_bytesFromString(v_t_2412)});
    }
  }
  case TAG_Just: {
    V v_html_2413 = heff_field(v_x3_242, 0);
    heff_drop(v_name_240);
    V v_kind_2414 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2epageAnswer_str9); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
    V v_j_2415 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2epageAnswer_str10), v_html_2413, MK_INT(0LL), 5);
    V v_text_2418;
    if (heff_intLt_c_lent(v_j_2415, MK_INT(0LL), 2)) {
      heff_drop(v_j_2415);
      v_text_2418 = heff_strAppend(heff_dup(v_html_2413), heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()));
    } else {
      V v_t_2417 = heff_strSlice(heff_dup(v_html_2413), heff_dup(v_j_2415), heff_strLength_lent(v_html_2413, 0));
      v_text_2418 = heff_strAppend(heff_strSlice_lent(v_html_2413, MK_INT(0LL), v_j_2415, 6), heff_strAppend(heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), v_t_2417));
    }
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str11), ((V)&g_heff_2ebuild_2edev_2epageAnswer_str12)}), NTAG(TAG_Nil)});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2epageAnswer_str13), v_kind_2414}), v_t_2419});
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2420, heff_bytesFromString(v_text_2418)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edev_2epageAnswer_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2edev_2epageAnswer(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str0, 5, ".html");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str1, 4, "<ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str2, 23, "<title>heff dev</title>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str3, 18, "<h1>the pages</h1>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str4, 14, "<li><a href=\"/");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str5, 3, "/\">");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str6, 9, "</a></li>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str7, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str8, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str9, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str10, 5, "</ul>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str11, 15, "<!doctype html>");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str14, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str15, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eindexAnswer_str16, 12, "Content-Type");
Clo g_heff_2ebuild_2edev_2eindexAnswer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eindexAnswer_entry, 1, 0};

V g_heff_2ebuild_2edev_2eindexAnswer(V v_found_240) {
top: ;
  V v_kind_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str0); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str1), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str3), v_t_242})});
  V v_t_245;
  switch (heff_tag_of(v_found_240)) {
  case TAG_Nothing: {
    v_t_245 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_found_240, 0);
    v_t_245 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_found_240);
  }
  V v_t_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str4); V b_1 = MK_INT(0LL); V a_2 = MK_INT(3LL); V a_3 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str5); V b_4 = MK_INT(0LL); V a_5 = MK_INT(3LL); V a_6 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str6); V b_7 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str7); V b_8 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str8); V b_9 = MK_INT(0LL); V b_10 = MK_INT(1LL); V b_11 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str9); V a_12 = v_t_245; V r_ = (g_list_2emap_24f336527456x1519848451(a_0, b_1, a_2, a_3, b_4, a_5, a_6, b_7, b_8, b_9, b_10, b_11, a_12)); heff_drop(b_1); heff_drop(b_4); heff_drop(b_7); heff_drop(b_8); heff_drop(b_9); heff_drop(b_10); heff_drop(b_11); r_; });
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2edev_2ereloadScript_get()), NTAG(TAG_Nil)});
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str10), v_t_247})));
  V v_xs_249 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str11), v_t_243}), v_t_248));
  V v_text_2412;
  switch (heff_tag_of(v_xs_249)) {
  case TAG_Nil: {
    v_text_2412 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_xs_249, 0);
    V v_xs_2411 = heff_field(v_xs_249, 1);
    heff_take_n(v_xs_249, 3ULL, 2);
    v_text_2412 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str13); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_xs_249);
  }
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str14), ((V)&g_heff_2ebuild_2edev_2eindexAnswer_str15)}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eindexAnswer_str16), v_kind_241}), v_t_2413});
  return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2414, heff_bytesFromString(v_text_2412)});
}
V g_heff_2ebuild_2edev_2eindexAnswer_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eindexAnswer(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str2, 2, ") ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str3, 7, "curl: (");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str6, 23, "heff dev: nothing from ");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str7, 4, "host");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str8, 14, "content-length");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str9, 10, "connection");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str10, 17, "transfer-encoding");
HEFF_LIT(g_heff_2ebuild_2edev_2erelayed_str11, 10, "keep-alive");
Clo g_heff_2ebuild_2edev_2erelayed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erelayed_entry, 2, 0};

V g_heff_2ebuild_2edev_2erelayed(V v_to_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Left: {
    V v_err_242 = heff_field(v_x2_241, 0);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erelayed_str0), ((V)&g_heff_2ebuild_2edev_2erelayed_str1)}), NTAG(TAG_Nil)});
    V v_t_244 = heff_intShow(heff_dup(heff_rfield(v_err_242, 0)));
    V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str2), heff_dup(heff_rfield(v_err_242, 1)));
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str3), heff_strAppend(v_t_244, v_t_245));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str4), heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2edev_2erelayed_str5)));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2erelayed_str6), heff_strAppend(v_to_240, v_t_247));
    return heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(502LL), v_t_243, heff_bytesFromString(v_t_248)});
  }
  case TAG_Right: {
    V v_res_249 = heff_field(v_x2_241, 0);
    heff_drop(v_to_240);
    V v_t_2410 = (g_list_2efilter_24s514881809x1990693194(((V)&g_heff_2ebuild_2edev_2erelayed_str7), ((V)&g_heff_2ebuild_2edev_2erelayed_str8), ((V)&g_heff_2ebuild_2edev_2erelayed_str9), ((V)&g_heff_2ebuild_2edev_2erelayed_str10), ((V)&g_heff_2ebuild_2edev_2erelayed_str11), heff_dup(heff_rfield(v_res_249, 1))));
    return heff_rec_n(3, shape_status__headers__body, (V[]){heff_dup(heff_rfield(v_res_249, 0)), v_t_2410, heff_dup(heff_rfield(v_res_249, 2))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2erelayed_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2erelayed(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_str0, 52, "heff dev: not built; built again at the next change\012");
V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_entry, 3, 0};

V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655(V v_r_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Write, 2, (V[]){heff_dup(heff_rfield(v_r_240, 1)), NTAG(TAG_MkUnit)});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  HEFF_LAST return g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_248}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_lam0, 1, 3, (V[]){v_r_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_str0), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_249);
  V v_t_2410 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_r_240, 2, 3), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655_lam1, 1, 2, (V[]){v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_str0, 8, "building");
HEFF_LIT(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_str1, 5, "build");
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam0, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam2, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam4(V self, V *args); static Clo g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam4, 1, 0};
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam10(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_entry, 5, 0};

V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452(V v_prog_240, V v_st_241, V v_d_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s94900133x232571340(v_t_2411, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam1, 1, 5, (V[]){v_prog_240, v_hd_243, heff_dup(v_st_241), v_d_242, v_k_244})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam4(V self, V *args) {
  V v_r_2417 = args[0];
  return v_r_2417;
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V f_ = v_k_244;
  args[0] = v_d_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam8(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2428);
  V f_ = v_k_244;
  args[0] = v_d_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam9(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  V f_ = v_k_244;
  args[0] = v_d_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam10(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2430);
  V f_ = v_k_244;
  args[0] = v_d_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_dup(heff_rfield(v_x_2419, 0));
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Exited: {
    V v_n_2424 = heff_field(v_t_2423, 0);
    heff_take_n(v_t_2423, 1ULL, 1);
    if (heff_intEq_c(v_n_2424, MK_INT(0LL))) {
      heff_drop_rec(v_x_2419, 3);
      return ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_d_242; V a_3 = v_hd_243; V a_4 = v_k_244; V r_ = (g_heff_2ebuild_2edev_2ebuiltWell_24s216994588x723270473(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_241); r_; });
    } else {
      heff_drop(v_prog_240);
      heff_drop(v_st_241);
      return (g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655(v_x_2419, v_hd_243, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam7, 1, 2, (V[]){v_k_244, v_d_242})));
    }
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2423, 0ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655(v_x_2419, v_hd_243, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam8, 1, 2, (V[]){v_k_244, v_d_242})));
  }
  case TAG_TimedOut: {
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655(v_x_2419, v_hd_243, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam9, 1, 2, (V[]){v_k_244, v_d_242})));
  }
  case TAG_NotRun: {
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    return (g_heff_2ebuild_2edev_2efailedSaid_24s45802596x1385924655(v_x_2419, v_hd_243, heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam10, 1, 2, (V[]){v_k_244, v_d_242})));
  }
  default: return heff_nomatch(v_t_2423);
  }
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2420}));
  return (g_co_2eop_24s94900133x232571340(v_t_2421, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam6, 1, 6, (V[]){v_x_2419, v_prog_240, v_st_241, v_d_242, v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_str1), NTAG(TAG_Nil)});
  V v_t_2418 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2415), v_x_2412, v_t_2416, ((V)&g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam4_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2418, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam5, 1, 6, (V[]){v_x_2415, v_prog_240, v_hd_243, v_st_241, v_d_242, v_k_244})));
}
V g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam2_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2414, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452_lam3, 1, 6, (V[]){v_prog_240, v_x_2412, v_hd_243, v_st_241, v_d_242, v_k_244})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str2, 59, "heff dev: no package.hf here: run it at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str5, 4, "8000");
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam0, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam2, 1, 0};
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_entry, 7, 0};

V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739(V v_prog_240, V v_clock_241, V v_wanted_242, V v_port_243, V v_proxy_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str0), ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam1, 1, 7, (V[]){v_hd_245, v_k_246, heff_dup(v_port_243), v_wanted_242, v_proxy_244, v_prog_240, v_clock_241})));
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam0(V self, V *args) {
  V v_t_247 = args[0];
  return v_t_247;
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  return v_s_2414;
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_hd_245, v_k_246));
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_st_2423 = heff_env(self)[1];
  V v_clock_241 = heff_env(self)[2];
  V v_x_2441 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_prog_240; V a_1 = v_st_2423; V a_2 = v_clock_241; V a_3 = v_st_2423; V a_4 = heff_dup(g_heff_2ebuild_2ewatch_2eproject_get()); V a_5 = v_x_2441; V a_6 = v_x_2445; V a_7 = v_hd_245; V a_8 = v_k_246; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s968785352x1272559716(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_st_2423); heff_drop(v_x_2441); heff_drop(v_k_246); r_; });
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_port_243 = heff_env(self)[0];
  V v_wanted_242 = heff_env(self)[1];
  V v_proxy_244 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_st_2423 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_clock_241 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2441;
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Nil: {
    v_x_2441 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2439 = heff_field(v_x_2438, 0);
    V v_xs_2440 = heff_field(v_x_2438, 1);
    heff_take_n(v_x_2438, 3ULL, 2);
    v_x_2441 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str4); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
    break;
  }
  default: heff_nomatch(v_x_2438);
  }
  V v_t_2443;
  switch (heff_tag_of(v_port_243)) {
  case TAG_Nothing: {
    v_t_2443 = ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str5);
    break;
  }
  case TAG_Just: {
    V v_x_2442 = heff_field(v_port_243, 0);
    heff_take_n(v_port_243, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_port_243);
  }
  V v_t_2444 = heff_rec_n(6, shape_running__pages__builds__wanted__port__proxy, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nothing), MK_INT(0LL), v_wanted_242, v_t_2443, v_proxy_244});
  return ({ V a_0 = heff_dup(v_prog_240); V a_1 = v_st_2423; V a_2 = v_t_2444; V a_3 = heff_dup(v_hd_245); V a_4 = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam6, 1, 6, (V[]){v_prog_240, heff_dup(v_st_2423), v_clock_241, v_x_2441, v_hd_245, v_k_246}); V r_ = (g_heff_2ebuild_2edev_2erebuilt_24s145247501x1179781452(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_2423); r_; });
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_port_243 = heff_env(self)[3];
  V v_wanted_242 = heff_env(self)[4];
  V v_proxy_244 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_clock_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_st_2423;
  if (heff_strEq_c(v_x_2421, ((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str1))) {
    v_st_2423 = NTAG(TAG_Windows);
  } else {
    v_st_2423 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    heff_drop(v_port_243);
    heff_drop(v_wanted_242);
    heff_drop(v_proxy_244);
    heff_drop(v_prog_240);
    heff_drop(v_clock_241);
    heff_drop(v_st_2423);
    V v_t_2424 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_str2), NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam4, 1, 2, (V[]){v_hd_245, v_k_246})));
  }
  case TAG_Just: {
    heff_take_n(v_x_2413, 0ULL, 1);
    return ({ V a_0 = v_st_2423; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(g_heff_2ebuild_2ewatch_2eproject_get()); V a_3 = heff_dup(v_hd_245); V a_4 = heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam5, 1, 8, (V[]){v_port_243, v_wanted_242, v_proxy_244, v_prog_240, heff_dup(v_st_2423), v_hd_245, v_clock_241, v_k_246}); V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s1334128865x2038964239(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_2423); r_; });
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  V v_port_243 = heff_env(self)[2];
  V v_wanted_242 = heff_env(self)[3];
  V v_proxy_244 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_clock_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s94900133x232571340(v_t_2420, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2edevCmd_24s1613211604x171602739_lam3, 1, 8, (V[]){v_x_2413, v_hd_245, v_k_246, v_port_243, v_wanted_242, v_proxy_244, v_prog_240, v_clock_241})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str0, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str1, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str2, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str3, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str6, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str8, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str9, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str10, 3, "dev");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str11, 5, "built");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str12, 4, ".txt");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str13, 13, "Cache-Control");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str14, 8, "no-store");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str15, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str16, 1, "0");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str18, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str19, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str20, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str21, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str22, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str23, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str24, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str25, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str26, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str27, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str28, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str29, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str31, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str32, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str33, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str34, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str35, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str36, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str37, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str38, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str39, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str40, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str41, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str42, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str43, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str44, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str45, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str46, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str47, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str48, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str49, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str50, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str51, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str52, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str53, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str54, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str55, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str56, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str57, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str58, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str59, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str60, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str61, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str62, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str63, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str64, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str65, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str66, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str67, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str68, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str69, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str70, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str71, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str72, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str73, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str74, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str75, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str76, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str77, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str78, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str79, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str80, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str81, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str82, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str83, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str84, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str85, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str86, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str87, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str88, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str89, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str90, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str91, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str92, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str93, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str94, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str95, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str96, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str97, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str98, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str99, 8, "Location");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str100, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str101, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str102, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str103, 10, "index.html");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str104, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str105, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str106, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str107, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str108, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str109, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str110, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str111, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str112, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str113, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str114, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str115, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str116, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str117, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str118, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str119, 13, "no such file\012");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str120, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str121, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str122, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str123, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str124, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str125, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str126, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str127, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str128, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str129, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str130, 12, "Content-Type");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str131, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str132, 13, "no such file\012");
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam0, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam3(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam3, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam2(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam6(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam6, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam10(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam10, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam11(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam9(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam12(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam12, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam14(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam14, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam16(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam16, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam17(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam15(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam13(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam19(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam19, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam20(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam18(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam21(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam23(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam23, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam24(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam22(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam25(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam25, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam27(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam27, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam28(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam26(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam29(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam31(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam31, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam32(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam30(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam33(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam33_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam33, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam35(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam35, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam36(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam34(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam38(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam38, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam40(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam40, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam41(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam39(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam37(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam43(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam43, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam44(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam42(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam45(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam47(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam47, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam48(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam46(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam49(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam49_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam49, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam51(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam51, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam52(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam50(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam53(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam55(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam55_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam55, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam56(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam54(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam57(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam57, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam58(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam60(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam60_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam60, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam62(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam62_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam62, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam63(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam61(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam59(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam65(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam65_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam65, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam66(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam64(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam67(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam69(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam69_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam69, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam70(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam68(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam71(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam71_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam71, 2, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam73(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam73_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam73, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam74(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam72(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam75(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam77(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam77_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam77, 1, 0};
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam78(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam76(V self, V *args);
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam79(V self, V *args); static Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam79_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam79, 2, 0};
Clo g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_entry, 2, 0};

V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    V v_x22_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str3), 2)) {
      switch (heff_tag_of(v_x22_247)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam1, 2, 1, (V[]){v_x21_246});
      }
      case TAG_Cons: {
        V v_x221_2414 = heff_dup(heff_field(v_x22_247, 0));
        V v_x222_2415 = heff_dup(heff_field(v_x22_247, 1));
        if (heff_strEq_c_lent(v_x221_2414, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str8), 2)) {
          heff_drop(v_x221_2414);
          switch (heff_tag_of(v_x222_2415)) {
          case TAG_Nil: {
            heff_drop(v_x21_246);
            heff_drop_tag(v_x22_247, 2);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            V v_t_2417 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str9), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str10)));
            V v_path_2418 = (g_std_2epath_2ejoin(v_st_240, v_t_2417, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str11)));
            return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam2, 2, 1, (V[]){v_path_2418});
          }
          case TAG_Cons: {
            heff_take_n(v_x222_2415, 0ULL, 2);
            V v_x1_2437 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_2437) == NTAG(TAG_True))) {
              heff_drop(v_x1_2437);
              V v_t_2440;
              switch (heff_tag_of(v_x22_247)) {
              case TAG_Nil: {
                v_t_2440 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str17);
                break;
              }
              case TAG_Cons: {
                V v_x_2438 = heff_dup(heff_field(v_x22_247, 0));
                V v_xs_2439 = heff_dup(heff_field(v_x22_247, 1));
                v_t_2440 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str18); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
                break;
              }
              default: heff_nomatch(v_x22_247);
              }
              if (heff_strEq_c(v_t_2440, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str19)))) {
                heff_drop_tag(v_x22_247, 2);
                V v_t_2442 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str20), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str21)));
                V v_path_2443 = (g_std_2epath_2ejoin(v_st_240, v_t_2442, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str22))));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam5, 2, 2, (V[]){v_path_2443, v_x21_246});
              } else {
                V v_t_2455 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str24), v_x21_246));
                V v_path_2458 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam8, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_2455, v_x22_247));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam9, 2, 2, (V[]){v_path_2458, v_x22_247});
              }
            } else {
              heff_drop(v_x21_246);
              heff_drop_tag(v_x22_247, 2);
              heff_drop(v_x1_2437);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam12_clo);
            }
          }
          default: return heff_nomatch(v_x222_2415);
          }
        } else {
          if (heff_strEq_c(v_x221_2414, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str30))) {
            switch (heff_tag_of(v_x222_2415)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_247, 2);
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              V v_t_2478 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str31), heff_dup(v_x21_246)));
              V v_path_2479 = (g_std_2epath_2ejoin(v_st_240, v_t_2478, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str32)));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam13, 2, 3, (V[]){v_path_2479, heff_dup(v_st_240), v_x21_246});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_2415, 0ULL, 2);
              V v_x1_24108 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if ((heff_dup(v_x1_24108) == NTAG(TAG_True))) {
                heff_drop(v_x1_24108);
                V v_t_24111;
                switch (heff_tag_of(v_x22_247)) {
                case TAG_Nil: {
                  v_t_24111 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str36);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24109 = heff_dup(heff_field(v_x22_247, 0));
                  V v_xs_24110 = heff_dup(heff_field(v_x22_247, 1));
                  v_t_24111 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str37); V a_1 = v_x_24109; V a_2 = v_xs_24110; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24110); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_247);
                }
                if (heff_strEq_c(v_t_24111, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str38)))) {
                  heff_drop_tag(v_x22_247, 2);
                  V v_t_24113 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str39), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str40)));
                  V v_path_24114 = (g_std_2epath_2ejoin(v_st_240, v_t_24113, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str41))));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam18, 2, 2, (V[]){v_path_24114, v_x21_246});
                } else {
                  V v_t_24126 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str43), v_x21_246));
                  V v_path_24129 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam21, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24126, v_x22_247));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam22, 2, 2, (V[]){v_path_24129, v_x22_247});
                }
              } else {
                heff_drop(v_x21_246);
                heff_drop_tag(v_x22_247, 2);
                heff_drop(v_x1_24108);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam25_clo);
              }
            }
            default: return heff_nomatch(v_x222_2415);
            }
          } else {
            heff_drop(v_x222_2415);
            V v_x1_24148 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_24148) == NTAG(TAG_True))) {
              heff_drop(v_x1_24148);
              V v_t_24151;
              switch (heff_tag_of(v_x22_247)) {
              case TAG_Nil: {
                v_t_24151 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str49);
                break;
              }
              case TAG_Cons: {
                V v_x_24149 = heff_dup(heff_field(v_x22_247, 0));
                V v_xs_24150 = heff_dup(heff_field(v_x22_247, 1));
                v_t_24151 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str50); V a_1 = v_x_24149; V a_2 = v_xs_24150; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24150); r_; });
                break;
              }
              default: heff_nomatch(v_x22_247);
              }
              if (heff_strEq_c(v_t_24151, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str51)))) {
                heff_drop_tag(v_x22_247, 2);
                V v_t_24153 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str52), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str53)));
                V v_path_24154 = (g_std_2epath_2ejoin(v_st_240, v_t_24153, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str54))));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam26, 2, 2, (V[]){v_path_24154, v_x21_246});
              } else {
                V v_t_24166 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str56), v_x21_246));
                V v_path_24169 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam29, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24166, v_x22_247));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam30, 2, 2, (V[]){v_path_24169, v_x22_247});
              }
            } else {
              heff_drop(v_x21_246);
              heff_drop_tag(v_x22_247, 2);
              heff_drop(v_x1_24148);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam33_clo);
            }
          }
        }
      }
      default: return heff_nomatch(v_x22_247);
      }
    } else {
      if (heff_strEq_c_lent(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str62), 2)) {
        switch (heff_tag_of(v_x22_247)) {
        case TAG_Nil: {
          heff_drop(v_x21_246);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          V v_path_24189 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str63), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str64)));
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam34, 2, 1, (V[]){v_path_24189});
        }
        case TAG_Cons: {
          V v_x221_24201 = heff_dup(heff_field(v_x22_247, 0));
          V v_x222_24202 = heff_dup(heff_field(v_x22_247, 1));
          if (heff_strEq_c(v_x221_24201, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str65))) {
            switch (heff_tag_of(v_x222_24202)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_247, 2);
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              V v_t_24204 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str66), heff_dup(v_x21_246)));
              V v_path_24205 = (g_std_2epath_2ejoin(v_st_240, v_t_24204, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str67)));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam37, 2, 3, (V[]){v_path_24205, heff_dup(v_st_240), v_x21_246});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24202, 0ULL, 2);
              V v_x1_24234 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if ((heff_dup(v_x1_24234) == NTAG(TAG_True))) {
                heff_drop(v_x1_24234);
                V v_t_24237;
                switch (heff_tag_of(v_x22_247)) {
                case TAG_Nil: {
                  v_t_24237 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str71);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24235 = heff_dup(heff_field(v_x22_247, 0));
                  V v_xs_24236 = heff_dup(heff_field(v_x22_247, 1));
                  v_t_24237 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str72); V a_1 = v_x_24235; V a_2 = v_xs_24236; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24236); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_247);
                }
                if (heff_strEq_c(v_t_24237, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str73)))) {
                  heff_drop_tag(v_x22_247, 2);
                  V v_t_24239 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str74), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str75)));
                  V v_path_24240 = (g_std_2epath_2ejoin(v_st_240, v_t_24239, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str76))));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam42, 2, 2, (V[]){v_path_24240, v_x21_246});
                } else {
                  V v_t_24252 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str78), v_x21_246));
                  V v_path_24255 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam45, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24252, v_x22_247));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam46, 2, 2, (V[]){v_path_24255, v_x22_247});
                }
              } else {
                heff_drop(v_x21_246);
                heff_drop_tag(v_x22_247, 2);
                heff_drop(v_x1_24234);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam49_clo);
              }
            }
            default: return heff_nomatch(v_x222_24202);
            }
          } else {
            heff_drop(v_x222_24202);
            V v_x1_24274 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_24274) == NTAG(TAG_True))) {
              heff_drop(v_x1_24274);
              V v_t_24277;
              switch (heff_tag_of(v_x22_247)) {
              case TAG_Nil: {
                v_t_24277 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str84);
                break;
              }
              case TAG_Cons: {
                V v_x_24275 = heff_dup(heff_field(v_x22_247, 0));
                V v_xs_24276 = heff_dup(heff_field(v_x22_247, 1));
                v_t_24277 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str85); V a_1 = v_x_24275; V a_2 = v_xs_24276; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24276); r_; });
                break;
              }
              default: heff_nomatch(v_x22_247);
              }
              if (heff_strEq_c(v_t_24277, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str86)))) {
                heff_drop_tag(v_x22_247, 2);
                V v_t_24279 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str87), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str88)));
                V v_path_24280 = (g_std_2epath_2ejoin(v_st_240, v_t_24279, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str89))));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam50, 2, 2, (V[]){v_path_24280, v_x21_246});
              } else {
                V v_t_24292 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str91), v_x21_246));
                V v_path_24295 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam53, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24292, v_x22_247));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam54, 2, 2, (V[]){v_path_24295, v_x22_247});
              }
            } else {
              heff_drop(v_x21_246);
              heff_drop_tag(v_x22_247, 2);
              heff_drop(v_x1_24274);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam57_clo);
            }
          }
        }
        default: return heff_nomatch(v_x22_247);
        }
      } else {
        switch (heff_tag_of(v_x22_247)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam58, 2, 1, (V[]){v_x21_246});
        }
        case TAG_Cons: {
          V v_x221_24319 = heff_dup(heff_field(v_x22_247, 0));
          V v_x222_24320 = heff_dup(heff_field(v_x22_247, 1));
          if (heff_strEq_c(v_x221_24319, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str101))) {
            switch (heff_tag_of(v_x222_24320)) {
            case TAG_Nil: {
              heff_drop_tag(v_x22_247, 2);
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              V v_t_24322 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str102), heff_dup(v_x21_246)));
              V v_path_24323 = (g_std_2epath_2ejoin(v_st_240, v_t_24322, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str103)));
              return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam59, 2, 3, (V[]){v_path_24323, heff_dup(v_st_240), v_x21_246});
            }
            case TAG_Cons: {
              heff_take_n(v_x222_24320, 0ULL, 2);
              V v_x1_24352 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
              if ((heff_dup(v_x1_24352) == NTAG(TAG_True))) {
                heff_drop(v_x1_24352);
                V v_t_24355;
                switch (heff_tag_of(v_x22_247)) {
                case TAG_Nil: {
                  v_t_24355 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str107);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24353 = heff_dup(heff_field(v_x22_247, 0));
                  V v_xs_24354 = heff_dup(heff_field(v_x22_247, 1));
                  v_t_24355 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str108); V a_1 = v_x_24353; V a_2 = v_xs_24354; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24354); r_; });
                  break;
                }
                default: heff_nomatch(v_x22_247);
                }
                if (heff_strEq_c(v_t_24355, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str109)))) {
                  heff_drop_tag(v_x22_247, 2);
                  V v_t_24357 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str110), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str111)));
                  V v_path_24358 = (g_std_2epath_2ejoin(v_st_240, v_t_24357, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str112))));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam64, 2, 2, (V[]){v_path_24358, v_x21_246});
                } else {
                  V v_t_24370 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str114), v_x21_246));
                  V v_path_24373 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam67, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24370, v_x22_247));
                  return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam68, 2, 2, (V[]){v_path_24373, v_x22_247});
                }
              } else {
                heff_drop(v_x21_246);
                heff_drop_tag(v_x22_247, 2);
                heff_drop(v_x1_24352);
                return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam71_clo);
              }
            }
            default: return heff_nomatch(v_x222_24320);
            }
          } else {
            heff_drop(v_x222_24320);
            V v_x1_24392 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x21_246), heff_dup(v_x22_247)}); V r_ = (g_list_2eall_24s1579400704x1789597964(b_0)); heff_drop(b_0); r_; });
            if ((heff_dup(v_x1_24392) == NTAG(TAG_True))) {
              heff_drop(v_x1_24392);
              V v_t_24395;
              switch (heff_tag_of(v_x22_247)) {
              case TAG_Nil: {
                v_t_24395 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str120);
                break;
              }
              case TAG_Cons: {
                V v_x_24393 = heff_dup(heff_field(v_x22_247, 0));
                V v_xs_24394 = heff_dup(heff_field(v_x22_247, 1));
                v_t_24395 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str121); V a_1 = v_x_24393; V a_2 = v_xs_24394; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24394); r_; });
                break;
              }
              default: heff_nomatch(v_x22_247);
              }
              if (heff_strEq_c(v_t_24395, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str122)))) {
                heff_drop_tag(v_x22_247, 2);
                V v_t_24397 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str123), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str124)));
                V v_path_24398 = (g_std_2epath_2ejoin(v_st_240, v_t_24397, heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str125))));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam72, 2, 2, (V[]){v_path_24398, v_x21_246});
              } else {
                V v_t_24410 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str127), v_x21_246));
                V v_path_24413 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam75, 2, 1, (V[]){heff_dup(v_st_240)}), v_t_24410, v_x22_247));
                return heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam76, 2, 2, (V[]){v_path_24413, v_x22_247});
              }
            } else {
              heff_drop(v_x21_246);
              heff_drop_tag(v_x22_247, 2);
              heff_drop(v_x1_24392);
              return ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam79_clo);
            }
          }
        }
        default: return heff_nomatch(v_x22_247);
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str0), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str1)}), NTAG(TAG_Nil)});
  V v_t_245 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_244, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str2))});
  V f_ = v_k_243;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_x21_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_249);
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str4), heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str5)));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str6), v_t_2411}), NTAG(TAG_Nil)});
  V v_t_2413 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_2412, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str7))});
  V f_ = v_k_2410;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam3(V self, V *args) {
  V v_t_2421 = args[0];
  return v_t_2421;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_kind_2429 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str12); V r_ = (g_heff_2ebuild_2edev_2etypeOf(b_0)); heff_drop(b_0); r_; });
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str13), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str14)}), NTAG(TAG_Nil)});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str15), v_kind_2429}), v_t_2430});
  V v_t_2433;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_Nothing: {
    v_t_2433 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str16);
    break;
  }
  case TAG_Just: {
    V v_x_2432 = heff_field(v_x_2428, 0);
    heff_take_n(v_x_2428, 1ULL, 1);
    v_t_2433 = v_x_2432;
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  V v_t_2434 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(200LL), v_t_2431, heff_bytesFromString(v_t_2433)});
  V f_ = v_k_2420;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_path_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2418, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam3_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s162716155x1210144019(v_t_2427, v_hd_2419, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam4, 1, 1, (V[]){v_k_2420})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam6(V self, V *args) {
  V v_t_2446 = args[0];
  return v_t_2446;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam7(V self, V *args) {
  V v_x_2453 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_2445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2454 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str23)); V a_1 = v_x_2453; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2453); r_; });
  V f_ = v_k_2445;
  args[0] = v_x_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam5(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_path_2443 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2443, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam6_clo)})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  return (g_co_2eop_24s162716155x1210144019(v_t_2452, v_hd_2444, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam7, 1, 2, (V[]){v_x21_246, v_k_2445})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam8(V self, V *args) {
  V v_p_2456 = args[0];
  V v_x_2457 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_2456; V a_2 = v_x_2457; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam10(V self, V *args) {
  V v_t_2461 = args[0];
  return v_t_2461;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam11(V self, V *args) {
  V v_x_2468 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2471;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_2471 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str25);
    break;
  }
  case TAG_Cons: {
    V v_x_2469 = heff_field(v_x22_247, 0);
    V v_xs_2470 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_2471 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str26); V a_1 = v_x_2469; V a_2 = v_xs_2470; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2470); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_2472 = ({ V a_0 = v_t_2471; V a_1 = v_x_2468; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_2468); r_; });
  V f_ = v_k_2460;
  args[0] = v_x_2472;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam9(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k_2460 = args[1];
  V v_path_2458 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2458, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam10_clo)})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
  return (g_co_2eop_24s162716155x1210144019(v_t_2467, v_hd_2459, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam11, 1, 2, (V[]){v_x22_247, v_k_2460})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam12(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k_2474 = args[1];
  heff_drop(v_hd_2473);
  V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str27), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str28)}), NTAG(TAG_Nil)});
  V v_t_2476 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_2475, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str29))});
  V f_ = v_k_2474;
  args[0] = v_t_2476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam14(V self, V *args) {
  V v_t_2482 = args[0];
  return v_t_2482;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam16(V self, V *args) {
  V v_r_2492 = args[0];
  return v_r_2492;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam17(V self, V *args) {
  V v_x_2499 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_x_2489 = heff_env(self)[1];
  V v_k_2481 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2499)) {
  case TAG_Left: {
    heff_take_n(v_x_2499, 0ULL, 1);
    V v_x_24101 = ({ V a_0 = v_x21_246; V b_1 = NTAG(TAG_False); V a_2 = v_x_2489; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_x_2489); r_; });
    V f_ = v_k_2481;
    args[0] = v_x_24101;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_24102 = heff_field(v_x_2499, 0);
    heff_take_n(v_x_2499, 1ULL, 1);
    V v_t_24103 = heff_get_n(v_s_24102, 0, 4);
    V v_t_24104;
    switch (heff_tag_of(v_t_24103)) {
    case TAG_Regular: {
      v_t_24104 = NTAG(TAG_True);
      break;
    }
    case TAG_Directory: {
      v_t_24104 = NTAG(TAG_False);
      break;
    }
    case TAG_Link: {
      v_t_24104 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_24104 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_24103);
    }
    V v_x_24105 = ({ V a_0 = v_x21_246; V a_1 = v_t_24104; V a_2 = v_x_2489; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_t_24104); heff_drop(v_x_2489); r_; });
    V f_ = v_k_2481;
    args[0] = v_x_24105;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2499);
  }
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam15(V self, V *args) {
  V v_x_2489 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  V v_hd_2480 = heff_env(self)[2];
  V v_k_2481 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2490 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str33), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str34)));
  V v_path_2491 = ({ V a_0 = v_st_240; V a_1 = v_t_2490; V a_2 = heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str35)); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V v_t_2493 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_path_2491, NTAG(TAG_True), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam16_clo)});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  return (g_co_2eop_24s162716155x1210144019(heff_tag_n(TAG_InR, 1, (V[]){v_t_2498}), v_hd_2480, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam17, 1, 3, (V[]){v_x21_246, v_x_2489, v_k_2481})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam13(V self, V *args) {
  V v_hd_2480 = args[0];
  V v_k_2481 = args[1];
  V v_path_2479 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x21_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2479, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam14_clo)})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2487})});
  return (g_co_2eop_24s162716155x1210144019(v_t_2488, heff_dup(v_hd_2480), heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam15, 1, 4, (V[]){v_st_240, v_x21_246, v_hd_2480, v_k_2481})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam19(V self, V *args) {
  V v_t_24117 = args[0];
  return v_t_24117;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam20(V self, V *args) {
  V v_x_24124 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24116 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24125 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str42)); V a_1 = v_x_24124; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24124); r_; });
  V f_ = v_k_24116;
  args[0] = v_x_24125;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam18(V self, V *args) {
  V v_hd_24115 = args[0];
  V v_k_24116 = args[1];
  V v_path_24114 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24118 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24114, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam19_clo)})});
  V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
  V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
  V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
  V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
  V v_t_24123 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24122})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24123, v_hd_24115, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam20, 1, 2, (V[]){v_x21_246, v_k_24116})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam21(V self, V *args) {
  V v_p_24127 = args[0];
  V v_x_24128 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24127; V a_2 = v_x_24128; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam23(V self, V *args) {
  V v_t_24132 = args[0];
  return v_t_24132;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam24(V self, V *args) {
  V v_x_24139 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24131 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24142;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24142 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str44);
    break;
  }
  case TAG_Cons: {
    V v_x_24140 = heff_field(v_x22_247, 0);
    V v_xs_24141 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24142 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str45); V a_1 = v_x_24140; V a_2 = v_xs_24141; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24141); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24143 = ({ V a_0 = v_t_24142; V a_1 = v_x_24139; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24139); r_; });
  V f_ = v_k_24131;
  args[0] = v_x_24143;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam22(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k_24131 = args[1];
  V v_path_24129 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24133 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24129, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam23_clo)})});
  V v_t_24134 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24133})});
  V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
  V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
  V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
  V v_t_24138 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24137})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24138, v_hd_24130, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam24, 1, 2, (V[]){v_x22_247, v_k_24131})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam25(V self, V *args) {
  V v_hd_24144 = args[0];
  V v_k_24145 = args[1];
  heff_drop(v_hd_24144);
  V v_t_24146 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str46), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str47)}), NTAG(TAG_Nil)});
  V v_t_24147 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24146, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str48))});
  V f_ = v_k_24145;
  args[0] = v_t_24147;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam27(V self, V *args) {
  V v_t_24157 = args[0];
  return v_t_24157;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam28(V self, V *args) {
  V v_x_24164 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24156 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24165 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str55)); V a_1 = v_x_24164; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24164); r_; });
  V f_ = v_k_24156;
  args[0] = v_x_24165;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam26(V self, V *args) {
  V v_hd_24155 = args[0];
  V v_k_24156 = args[1];
  V v_path_24154 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24158 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24154, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam27_clo)})});
  V v_t_24159 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24158})});
  V v_t_24160 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24159})});
  V v_t_24161 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24160})});
  V v_t_24162 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24161})});
  V v_t_24163 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24162})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24163, v_hd_24155, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam28, 1, 2, (V[]){v_x21_246, v_k_24156})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam29(V self, V *args) {
  V v_p_24167 = args[0];
  V v_x_24168 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24167; V a_2 = v_x_24168; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam31(V self, V *args) {
  V v_t_24172 = args[0];
  return v_t_24172;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam32(V self, V *args) {
  V v_x_24179 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24171 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24182;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24182 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str57);
    break;
  }
  case TAG_Cons: {
    V v_x_24180 = heff_field(v_x22_247, 0);
    V v_xs_24181 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24182 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str58); V a_1 = v_x_24180; V a_2 = v_xs_24181; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24181); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24183 = ({ V a_0 = v_t_24182; V a_1 = v_x_24179; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24179); r_; });
  V f_ = v_k_24171;
  args[0] = v_x_24183;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam30(V self, V *args) {
  V v_hd_24170 = args[0];
  V v_k_24171 = args[1];
  V v_path_24169 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24173 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24169, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam31_clo)})});
  V v_t_24174 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24173})});
  V v_t_24175 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24174})});
  V v_t_24176 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24175})});
  V v_t_24177 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24176})});
  V v_t_24178 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24177})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24178, v_hd_24170, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam32, 1, 2, (V[]){v_x22_247, v_k_24171})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam33(V self, V *args) {
  V v_hd_24184 = args[0];
  V v_k_24185 = args[1];
  heff_drop(v_hd_24184);
  V v_t_24186 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str59), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str60)}), NTAG(TAG_Nil)});
  V v_t_24187 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24186, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str61))});
  V f_ = v_k_24185;
  args[0] = v_t_24187;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam35(V self, V *args) {
  V v_ns_24192 = args[0];
  return v_ns_24192;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam36(V self, V *args) {
  V v_x_24199 = args[0];
  V v_k_24191 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_24200 = ({ V a_0 = v_x_24199; V r_ = (g_heff_2ebuild_2edev_2eindexAnswer(a_0)); heff_drop(v_x_24199); r_; });
  V f_ = v_k_24191;
  args[0] = v_x_24200;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam34(V self, V *args) {
  V v_hd_24190 = args[0];
  V v_k_24191 = args[1];
  V v_path_24189 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24193 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_path_24189, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam35_clo)})});
  V v_t_24194 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24193})});
  V v_t_24195 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24194})});
  V v_t_24196 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24195})});
  V v_t_24197 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24196})});
  V v_t_24198 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24197})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24198, v_hd_24190, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam36, 1, 1, (V[]){v_k_24191})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam38(V self, V *args) {
  V v_t_24208 = args[0];
  return v_t_24208;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam40(V self, V *args) {
  V v_r_24218 = args[0];
  return v_r_24218;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam41(V self, V *args) {
  V v_x_24225 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_x_24215 = heff_env(self)[1];
  V v_k_24207 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24225)) {
  case TAG_Left: {
    heff_take_n(v_x_24225, 0ULL, 1);
    V v_x_24227 = ({ V a_0 = v_x21_246; V b_1 = NTAG(TAG_False); V a_2 = v_x_24215; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_x_24215); r_; });
    V f_ = v_k_24207;
    args[0] = v_x_24227;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_24228 = heff_field(v_x_24225, 0);
    heff_take_n(v_x_24225, 1ULL, 1);
    V v_t_24229 = heff_get_n(v_s_24228, 0, 4);
    V v_t_24230;
    switch (heff_tag_of(v_t_24229)) {
    case TAG_Regular: {
      v_t_24230 = NTAG(TAG_True);
      break;
    }
    case TAG_Directory: {
      v_t_24230 = NTAG(TAG_False);
      break;
    }
    case TAG_Link: {
      v_t_24230 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_24230 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_24229);
    }
    V v_x_24231 = ({ V a_0 = v_x21_246; V a_1 = v_t_24230; V a_2 = v_x_24215; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_t_24230); heff_drop(v_x_24215); r_; });
    V f_ = v_k_24207;
    args[0] = v_x_24231;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_24225);
  }
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam39(V self, V *args) {
  V v_x_24215 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  V v_hd_24206 = heff_env(self)[2];
  V v_k_24207 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24216 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str68), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str69)));
  V v_path_24217 = ({ V a_0 = v_st_240; V a_1 = v_t_24216; V a_2 = heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str70)); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V v_t_24219 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_path_24217, NTAG(TAG_True), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam40_clo)});
  V v_t_24220 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24219})});
  V v_t_24221 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24220})});
  V v_t_24222 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24221})});
  V v_t_24223 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24222})});
  V v_t_24224 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24223})});
  return (g_co_2eop_24s162716155x1210144019(heff_tag_n(TAG_InR, 1, (V[]){v_t_24224}), v_hd_24206, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam41, 1, 3, (V[]){v_x21_246, v_x_24215, v_k_24207})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam37(V self, V *args) {
  V v_hd_24206 = args[0];
  V v_k_24207 = args[1];
  V v_path_24205 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x21_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24209 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24205, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam38_clo)})});
  V v_t_24210 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24209})});
  V v_t_24211 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24210})});
  V v_t_24212 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24211})});
  V v_t_24213 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24212})});
  V v_t_24214 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24213})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24214, heff_dup(v_hd_24206), heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam39, 1, 4, (V[]){v_st_240, v_x21_246, v_hd_24206, v_k_24207})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam43(V self, V *args) {
  V v_t_24243 = args[0];
  return v_t_24243;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam44(V self, V *args) {
  V v_x_24250 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24251 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str77)); V a_1 = v_x_24250; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24250); r_; });
  V f_ = v_k_24242;
  args[0] = v_x_24251;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam42(V self, V *args) {
  V v_hd_24241 = args[0];
  V v_k_24242 = args[1];
  V v_path_24240 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam43_clo)})});
  V v_t_24245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24244})});
  V v_t_24246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24245})});
  V v_t_24247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24246})});
  V v_t_24248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24247})});
  V v_t_24249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24248})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24249, v_hd_24241, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam44, 1, 2, (V[]){v_x21_246, v_k_24242})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam45(V self, V *args) {
  V v_p_24253 = args[0];
  V v_x_24254 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24253; V a_2 = v_x_24254; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam47(V self, V *args) {
  V v_t_24258 = args[0];
  return v_t_24258;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam48(V self, V *args) {
  V v_x_24265 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24257 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24268;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24268 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str79);
    break;
  }
  case TAG_Cons: {
    V v_x_24266 = heff_field(v_x22_247, 0);
    V v_xs_24267 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24268 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str80); V a_1 = v_x_24266; V a_2 = v_xs_24267; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24267); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24269 = ({ V a_0 = v_t_24268; V a_1 = v_x_24265; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24265); r_; });
  V f_ = v_k_24257;
  args[0] = v_x_24269;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam46(V self, V *args) {
  V v_hd_24256 = args[0];
  V v_k_24257 = args[1];
  V v_path_24255 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24259 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24255, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam47_clo)})});
  V v_t_24260 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24259})});
  V v_t_24261 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24260})});
  V v_t_24262 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24261})});
  V v_t_24263 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24262})});
  V v_t_24264 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24263})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24264, v_hd_24256, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam48, 1, 2, (V[]){v_x22_247, v_k_24257})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam49(V self, V *args) {
  V v_hd_24270 = args[0];
  V v_k_24271 = args[1];
  heff_drop(v_hd_24270);
  V v_t_24272 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str81), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str82)}), NTAG(TAG_Nil)});
  V v_t_24273 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24272, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str83))});
  V f_ = v_k_24271;
  args[0] = v_t_24273;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam51(V self, V *args) {
  V v_t_24283 = args[0];
  return v_t_24283;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam52(V self, V *args) {
  V v_x_24290 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24282 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24291 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str90)); V a_1 = v_x_24290; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24290); r_; });
  V f_ = v_k_24282;
  args[0] = v_x_24291;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam50(V self, V *args) {
  V v_hd_24281 = args[0];
  V v_k_24282 = args[1];
  V v_path_24280 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24284 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24280, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam51_clo)})});
  V v_t_24285 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24284})});
  V v_t_24286 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24285})});
  V v_t_24287 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24286})});
  V v_t_24288 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24287})});
  V v_t_24289 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24288})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24289, v_hd_24281, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam52, 1, 2, (V[]){v_x21_246, v_k_24282})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam53(V self, V *args) {
  V v_p_24293 = args[0];
  V v_x_24294 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24293; V a_2 = v_x_24294; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam55(V self, V *args) {
  V v_t_24298 = args[0];
  return v_t_24298;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam56(V self, V *args) {
  V v_x_24305 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24297 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24308;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24308 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str92);
    break;
  }
  case TAG_Cons: {
    V v_x_24306 = heff_field(v_x22_247, 0);
    V v_xs_24307 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24308 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str93); V a_1 = v_x_24306; V a_2 = v_xs_24307; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24307); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24309 = ({ V a_0 = v_t_24308; V a_1 = v_x_24305; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24305); r_; });
  V f_ = v_k_24297;
  args[0] = v_x_24309;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam54(V self, V *args) {
  V v_hd_24296 = args[0];
  V v_k_24297 = args[1];
  V v_path_24295 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24299 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24295, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam55_clo)})});
  V v_t_24300 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24299})});
  V v_t_24301 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24300})});
  V v_t_24302 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24301})});
  V v_t_24303 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24302})});
  V v_t_24304 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24303})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24304, v_hd_24296, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam56, 1, 2, (V[]){v_x22_247, v_k_24297})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam57(V self, V *args) {
  V v_hd_24310 = args[0];
  V v_k_24311 = args[1];
  heff_drop(v_hd_24310);
  V v_t_24312 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str94), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str95)}), NTAG(TAG_Nil)});
  V v_t_24313 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24312, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str96))});
  V f_ = v_k_24311;
  args[0] = v_t_24313;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam58(V self, V *args) {
  V v_hd_24314 = args[0];
  V v_k_24315 = args[1];
  V v_x21_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24314);
  V v_t_24316 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str97), heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str98)));
  V v_t_24317 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str99), v_t_24316}), NTAG(TAG_Nil)});
  V v_t_24318 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(301LL), v_t_24317, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str100))});
  V f_ = v_k_24315;
  args[0] = v_t_24318;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam60(V self, V *args) {
  V v_t_24326 = args[0];
  return v_t_24326;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam62(V self, V *args) {
  V v_r_24336 = args[0];
  return v_r_24336;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam63(V self, V *args) {
  V v_x_24343 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_x_24333 = heff_env(self)[1];
  V v_k_24325 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24343)) {
  case TAG_Left: {
    heff_take_n(v_x_24343, 0ULL, 1);
    V v_x_24345 = ({ V a_0 = v_x21_246; V b_1 = NTAG(TAG_False); V a_2 = v_x_24333; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_x_24333); r_; });
    V f_ = v_k_24325;
    args[0] = v_x_24345;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_24346 = heff_field(v_x_24343, 0);
    heff_take_n(v_x_24343, 1ULL, 1);
    V v_t_24347 = heff_get_n(v_s_24346, 0, 4);
    V v_t_24348;
    switch (heff_tag_of(v_t_24347)) {
    case TAG_Regular: {
      v_t_24348 = NTAG(TAG_True);
      break;
    }
    case TAG_Directory: {
      v_t_24348 = NTAG(TAG_False);
      break;
    }
    case TAG_Link: {
      v_t_24348 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_24348 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_24347);
    }
    V v_x_24349 = ({ V a_0 = v_x21_246; V a_1 = v_t_24348; V a_2 = v_x_24333; V r_ = (g_heff_2ebuild_2edev_2epageAnswer(a_0, a_1, a_2)); heff_drop(v_t_24348); heff_drop(v_x_24333); r_; });
    V f_ = v_k_24325;
    args[0] = v_x_24349;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_24343);
  }
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam61(V self, V *args) {
  V v_x_24333 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  V v_hd_24324 = heff_env(self)[2];
  V v_k_24325 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24334 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str104), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str105)));
  V v_path_24335 = ({ V a_0 = v_st_240; V a_1 = v_t_24334; V a_2 = heff_strAppend(heff_dup(v_x21_246), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str106)); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V v_t_24337 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_path_24335, NTAG(TAG_True), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam62_clo)});
  V v_t_24338 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24337})});
  V v_t_24339 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24338})});
  V v_t_24340 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24339})});
  V v_t_24341 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24340})});
  V v_t_24342 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24341})});
  return (g_co_2eop_24s162716155x1210144019(heff_tag_n(TAG_InR, 1, (V[]){v_t_24342}), v_hd_24324, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam63, 1, 3, (V[]){v_x21_246, v_x_24333, v_k_24325})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam59(V self, V *args) {
  V v_hd_24324 = args[0];
  V v_k_24325 = args[1];
  V v_path_24323 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x21_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24327 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24323, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam60_clo)})});
  V v_t_24328 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24327})});
  V v_t_24329 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24328})});
  V v_t_24330 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24329})});
  V v_t_24331 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24330})});
  V v_t_24332 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24331})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24332, heff_dup(v_hd_24324), heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam61, 1, 4, (V[]){v_st_240, v_x21_246, v_hd_24324, v_k_24325})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam65(V self, V *args) {
  V v_t_24361 = args[0];
  return v_t_24361;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam66(V self, V *args) {
  V v_x_24368 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24360 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24369 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str113)); V a_1 = v_x_24368; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24368); r_; });
  V f_ = v_k_24360;
  args[0] = v_x_24369;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam64(V self, V *args) {
  V v_hd_24359 = args[0];
  V v_k_24360 = args[1];
  V v_path_24358 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24362 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24358, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam65_clo)})});
  V v_t_24363 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24362})});
  V v_t_24364 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24363})});
  V v_t_24365 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24364})});
  V v_t_24366 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24365})});
  V v_t_24367 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24366})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24367, v_hd_24359, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam66, 1, 2, (V[]){v_x21_246, v_k_24360})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam67(V self, V *args) {
  V v_p_24371 = args[0];
  V v_x_24372 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24371; V a_2 = v_x_24372; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam69(V self, V *args) {
  V v_t_24376 = args[0];
  return v_t_24376;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam70(V self, V *args) {
  V v_x_24383 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24375 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24386;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24386 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str115);
    break;
  }
  case TAG_Cons: {
    V v_x_24384 = heff_field(v_x22_247, 0);
    V v_xs_24385 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24386 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str116); V a_1 = v_x_24384; V a_2 = v_xs_24385; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24385); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24387 = ({ V a_0 = v_t_24386; V a_1 = v_x_24383; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24383); r_; });
  V f_ = v_k_24375;
  args[0] = v_x_24387;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam68(V self, V *args) {
  V v_hd_24374 = args[0];
  V v_k_24375 = args[1];
  V v_path_24373 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24377 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24373, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam69_clo)})});
  V v_t_24378 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24377})});
  V v_t_24379 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24378})});
  V v_t_24380 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24379})});
  V v_t_24381 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24380})});
  V v_t_24382 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24381})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24382, v_hd_24374, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam70, 1, 2, (V[]){v_x22_247, v_k_24375})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam71(V self, V *args) {
  V v_hd_24388 = args[0];
  V v_k_24389 = args[1];
  heff_drop(v_hd_24388);
  V v_t_24390 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str117), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str118)}), NTAG(TAG_Nil)});
  V v_t_24391 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24390, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str119))});
  V f_ = v_k_24389;
  args[0] = v_t_24391;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam73(V self, V *args) {
  V v_t_24401 = args[0];
  return v_t_24401;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam74(V self, V *args) {
  V v_x_24408 = args[0];
  V v_x21_246 = heff_env(self)[0];
  V v_k_24400 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24409 = ({ V a_0 = heff_strAppend(v_x21_246, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str126)); V a_1 = v_x_24408; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24408); r_; });
  V f_ = v_k_24400;
  args[0] = v_x_24409;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam72(V self, V *args) {
  V v_hd_24399 = args[0];
  V v_k_24400 = args[1];
  V v_path_24398 = heff_env(self)[0];
  V v_x21_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24402 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24398, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam73_clo)})});
  V v_t_24403 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24402})});
  V v_t_24404 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24403})});
  V v_t_24405 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24404})});
  V v_t_24406 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24405})});
  V v_t_24407 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24406})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24407, v_hd_24399, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam74, 1, 2, (V[]){v_x21_246, v_k_24400})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam75(V self, V *args) {
  V v_p_24411 = args[0];
  V v_x_24412 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_st_240; V a_1 = v_p_24411; V a_2 = v_x_24412; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam77(V self, V *args) {
  V v_t_24416 = args[0];
  return v_t_24416;
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam78(V self, V *args) {
  V v_x_24423 = args[0];
  V v_x22_247 = heff_env(self)[0];
  V v_k_24415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24426;
  switch (heff_tag_of(v_x22_247)) {
  case TAG_Nil: {
    v_t_24426 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str128);
    break;
  }
  case TAG_Cons: {
    V v_x_24424 = heff_field(v_x22_247, 0);
    V v_xs_24425 = heff_field(v_x22_247, 1);
    heff_take_n(v_x22_247, 3ULL, 2);
    v_t_24426 = ({ V a_0 = ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str129); V a_1 = v_x_24424; V a_2 = v_xs_24425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24425); r_; });
    break;
  }
  default: heff_nomatch(v_x22_247);
  }
  V v_x_24427 = ({ V a_0 = v_t_24426; V a_1 = v_x_24423; V r_ = (g_heff_2ebuild_2edev_2efileAnswer(a_0, a_1)); heff_drop(v_x_24423); r_; });
  V f_ = v_k_24415;
  args[0] = v_x_24427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam76(V self, V *args) {
  V v_hd_24414 = args[0];
  V v_k_24415 = args[1];
  V v_path_24413 = heff_env(self)[0];
  V v_x22_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_24413, ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam77_clo)})});
  V v_t_24418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24417})});
  V v_t_24419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24418})});
  V v_t_24420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24419})});
  V v_t_24421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24420})});
  V v_t_24422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24421})});
  return (g_co_2eop_24s162716155x1210144019(v_t_24422, v_hd_24414, heff_clo_n(g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam78, 1, 2, (V[]){v_x22_247, v_k_24415})));
}
V g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_lam79(V self, V *args) {
  V v_hd_24428 = args[0];
  V v_k_24429 = args[1];
  heff_drop(v_hd_24428);
  V v_t_24430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str130), ((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str131)}), NTAG(TAG_Nil)});
  V v_t_24431 = heff_rec_n(3, shape_status__headers__body, (V[]){MK_INT(404LL), v_t_24430, heff_bytesFromString(((V)&g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388_str132))});
  V f_ = v_k_24429;
  args[0] = v_t_24431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str0, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str3, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str7, 3, "app");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str8, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str9, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str10, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str11, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str12, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str13, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str14, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str15, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str16, 1, "/");
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam1(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam2, 1, 0};
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam0(V self, V *args);
Clo g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_entry, 4, 0};

V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802(V v_web_240, V v_st_241, V v_x2_242, V v_req_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nothing: {
    heff_drop(v_web_240);
    V v_target_244 = heff_get_n(v_req_243, 1, 6);
    V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str0), v_target_244, MK_INT(0LL), 5);
    V v_path_247;
    if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
      heff_drop(v_j_245);
      v_path_247 = v_target_244;
    } else {
      v_path_247 = heff_strSlice(v_target_244, MK_INT(0LL), v_j_245);
    }
    V v_s_248 = heff_strSlice(heff_dup(v_path_247), MK_INT(1LL), heff_strLength(v_path_247));
    V v_t_249 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str1); V a_1 = v_s_248; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str2), v_s_248, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_248); r_; });
    return (g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388(v_st_241, v_t_249));
  }
  case TAG_Just: {
    V v_to_2410 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    V v_target_2411 = heff_dup(heff_rfield(v_req_243, 1));
    V v_j_2412 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str3), v_target_2411, MK_INT(0LL), 5);
    V v_path_2414;
    if (heff_intLt_c_lent(v_j_2412, MK_INT(0LL), 2)) {
      heff_drop(v_j_2412);
      v_path_2414 = v_target_2411;
    } else {
      v_path_2414 = heff_strSlice(v_target_2411, MK_INT(0LL), v_j_2412);
    }
    V v_s_2415 = heff_strSlice(heff_dup(v_path_2414), MK_INT(1LL), heff_strLength(v_path_2414));
    V v_x1_2416 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str4); V a_1 = v_s_2415; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str5), v_s_2415, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2415); r_; });
    V v_t_2419;
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x1_2416, 0);
      heff_take_n(v_x1_2416, 1ULL, 2);
      v_t_2419 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x1_2416);
    }
    V v_path_2420 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str7), v_t_2419));
    return heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam0, 2, 5, (V[]){v_req_243, heff_dup(v_st_241), v_web_240, v_to_2410, v_path_2420});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edev_2eserved_24s761133100x856838802(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_req_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_hd_2421 = heff_env(self)[2];
  V v_k_2422 = heff_env(self)[3];
  V v_web_240 = heff_env(self)[4];
  V v_to_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2423) == NTAG(TAG_True))) {
    heff_drop(v_x_2423);
    heff_drop(v_web_240);
    heff_drop(v_to_2410);
    V v_target_2424 = heff_get_n(v_req_243, 1, 6);
    V v_j_2425 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str8), v_target_2424, MK_INT(0LL), 5);
    V v_path_2427;
    if (heff_intLt_c_lent(v_j_2425, MK_INT(0LL), 2)) {
      heff_drop(v_j_2425);
      v_path_2427 = v_target_2424;
    } else {
      v_path_2427 = heff_strSlice(v_target_2424, MK_INT(0LL), v_j_2425);
    }
    V v_s_2428 = heff_strSlice(heff_dup(v_path_2427), MK_INT(1LL), heff_strLength(v_path_2427));
    V v_t_2429 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str9); V a_1 = v_s_2428; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str10), v_s_2428, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2428); r_; });
    V v_t_2430 = ({ V a_0 = v_st_241; V a_1 = v_t_2429; V r_ = (g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388(a_0, a_1)); heff_drop(v_st_241); r_; });
    V f_ = v_t_2430;
    heff_room[0] = v_hd_2421;
    heff_room[1] = v_k_2422;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2423);
    V v_target_2431 = heff_dup(heff_rfield(v_req_243, 1));
    V v_j_2432 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str11), v_target_2431, MK_INT(0LL), 5);
    V v_path_2434;
    if (heff_intLt_c_lent(v_j_2432, MK_INT(0LL), 2)) {
      heff_drop(v_j_2432);
      v_path_2434 = v_target_2431;
    } else {
      v_path_2434 = heff_strSlice(v_target_2431, MK_INT(0LL), v_j_2432);
    }
    V v_s_2435 = heff_strSlice(heff_dup(v_path_2434), MK_INT(1LL), heff_strLength(v_path_2434));
    V v_t_2436 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str12); V a_1 = v_s_2435; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str13), v_s_2435, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2435); r_; });
    V v_t_2437 = ({ V a_0 = v_t_2436; V r_ = (g_heff_2ebuild_2edev_2eownPath(a_0)); heff_drop(v_t_2436); r_; });
    if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
      heff_drop(v_web_240);
      heff_drop(v_to_2410);
      heff_drop(v_t_2437);
      V v_target_2438 = heff_get_n(v_req_243, 1, 6);
      V v_j_2439 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str14), v_target_2438, MK_INT(0LL), 5);
      V v_path_2441;
      if (heff_intLt_c_lent(v_j_2439, MK_INT(0LL), 2)) {
        heff_drop(v_j_2439);
        v_path_2441 = v_target_2438;
      } else {
        v_path_2441 = heff_strSlice(v_target_2438, MK_INT(0LL), v_j_2439);
      }
      V v_s_2442 = heff_strSlice(heff_dup(v_path_2441), MK_INT(1LL), heff_strLength(v_path_2441));
      V v_t_2443 = ({ V b_0 = ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str15); V a_1 = v_s_2442; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_str16), v_s_2442, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2442); r_; });
      V v_t_2444 = ({ V a_0 = v_st_241; V a_1 = v_t_2443; V r_ = (g_heff_2ebuild_2edev_2eanswer_24s515607397x923396388(a_0, a_1)); heff_drop(v_st_241); r_; });
      V f_ = v_t_2444;
      heff_room[0] = v_hd_2421;
      heff_room[1] = v_k_2422;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_st_241);
      heff_drop(v_t_2437);
      return (g_heff_2ebuild_2edev_2eforwarded_24s1432881785x777273604(v_web_240, v_to_2410, v_req_243, v_hd_2421, v_k_2422));
    }
  }
}
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam2(V self, V *args) {
  V v_r_2446 = args[0];
  return v_r_2446;
}
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam3(V self, V *args) {
  V v_x_2453 = args[0];
  V v_k_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2453)) {
  case TAG_Left: {
    heff_take_n(v_x_2453, 0ULL, 1);
    V f_ = v_k_2445;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_s_2455 = heff_field(v_x_2453, 0);
    heff_take_n(v_x_2453, 1ULL, 1);
    V v_t_2456 = heff_get_n(v_s_2455, 0, 4);
    V v_t_2457;
    switch (heff_tag_of(v_t_2456)) {
    case TAG_Regular: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_Directory: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_Link: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2456);
    }
    V f_ = v_k_2445;
    args[0] = v_t_2457;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2453);
  }
}
V g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam0(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_req_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_web_240 = heff_env(self)[2];
  V v_to_2410 = heff_env(self)[3];
  V v_path_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_k_2445 = heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam1, 1, 6, (V[]){v_req_243, v_st_241, heff_dup(v_hd_2421), v_k_2422, v_web_240, v_to_2410});
  V v_t_2447 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_path_2420, NTAG(TAG_True), ((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam2_clo)});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  return (g_co_2eop_24s162716155x1210144019(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), v_hd_2421, heff_clo_n(g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_lam3, 1, 1, (V[]){v_k_2445})));
}
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str0, 9, "127.0.0.1");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str3, 41, "heff dev: cannot serve the pages at port ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str6, 19, ", the rest sent to ");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str7, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str8, 40, "heff dev: the pages at http://127.0.0.1:");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str10, 5, "win32");
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam0(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam0, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam2(V self, V *args); static Clo g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam2, 1, 0};
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam4(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam6(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam7(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam8(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam5(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam3(V self, V *args);
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam1(V self, V *args);
Clo g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_entry, 7, 0};

V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450(V v_nt_240, V v_rx_241, V v_web_242, V v_port_243, V v_proxy_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s94900133x232571340(v_t_2413, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam1, 1, 7, (V[]){v_port_243, v_nt_240, v_hd_245, v_k_246, v_proxy_244, v_web_242, v_rx_241})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam2(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_hd_245, v_k_246));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam6(V self, V *args) {
  V v_p_2456 = args[0];
  V v_web_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2457 = heff_tr(heff_call(v_web_242, 1, (V[]){v_p_2456}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2457});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam7(V self, V *args) {
  V v_p_2459 = args[0];
  V v_nt_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2460 = heff_tr(heff_call(v_nt_240, 1, (V[]){v_p_2459}));
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2460});
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam8(V self, V *args) {
  V v_x_2463 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2463);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam5(V self, V *args) {
  V v_x_2453 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_web_242 = heff_env(self)[1];
  V v_proxy_244 = heff_env(self)[2];
  V v_nt_240 = heff_env(self)[3];
  V v_listener_2442 = heff_env(self)[4];
  V v_rx_241 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2453);
  V v_t_2455;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str10))) {
    v_t_2455 = NTAG(TAG_Windows);
  } else {
    v_t_2455 = NTAG(TAG_Posix);
  }
  V v_t_2458 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edev_2eserved_24s761133100x856838802_clo), 3, (V[]){heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam6, 1, 1, (V[]){v_web_242}), v_t_2455, v_proxy_244}));
  V v_c_2461 = (g_std_2ehttp_2eserver_2eserveConcurrently_24s1684451694x373462712(heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam7, 1, 1, (V[]){v_nt_240}), v_listener_2442, v_t_2458));
  V v_t_2462 = (g_std_2ereactor_2eoutside_24s626113845x1580845692(v_rx_241));
  return (g_green_2escheduledWith_24s323844761x1686441296(v_t_2462, v_c_2461, v_hd_245, heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam8, 1, 1, (V[]){v_k_246})));
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_port_243 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_proxy_244 = heff_env(self)[3];
  V v_x_2414 = heff_env(self)[4];
  V v_web_242 = heff_env(self)[5];
  V v_nt_240 = heff_env(self)[6];
  V v_rx_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    V v_err_2424 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Left = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    heff_drop(v_proxy_244);
    heff_drop(v_x_2414);
    heff_drop(v_web_242);
    heff_drop(v_nt_240);
    heff_drop(v_rx_241);
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str1), heff_take_field(v_err_2424, 2));
    V v_t_2426 = heff_strAppend(heff_get_n(v_err_2424, 1, 3), v_t_2425);
    V v_t_2427 = heff_strAppend(v_port_243, heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str2), v_t_2426));
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str3), v_t_2427), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str4));
    V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_at_n(v_ru_24x_2423_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam4, 1, 2, (V[]){v_hd_245, v_k_246})));
  }
  case TAG_Right: {
    V v_listener_2442 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Right = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    V v_t_2444;
    switch (heff_tag_of(v_proxy_244)) {
    case TAG_Nothing: {
      v_t_2444 = ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str5);
      break;
    }
    case TAG_Just: {
      V v_x_2443 = heff_dup(heff_field(v_proxy_244, 0));
      v_t_2444 = heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str6), v_x_2443);
      break;
    }
    default: heff_nomatch(v_proxy_244);
    }
    V v_t_2445 = heff_strAppend(v_port_243, heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str7), v_t_2444));
    V v_t_2446 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str8), v_t_2445), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str9));
    V v_t_2447 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2446, NTAG(TAG_MkUnit)});
    V v_t_2448 = heff_tag_at_n(v_ru_24x_2423_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam5, 1, 8, (V[]){v_x_2414, v_web_242, v_proxy_244, v_nt_240, v_listener_2442, v_rx_241, v_hd_245, v_k_246})));
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_port_243 = heff_env(self)[0];
  V v_nt_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_proxy_244 = heff_env(self)[4];
  V v_web_242 = heff_env(self)[5];
  V v_rx_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  HeffT2 v_t_2415 = (g_prelude_2eparseInt_24cpr(v_port_243));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    V v_t_2420;
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2417;
      v_t_2420 = v_x_2419;
    } else {
      heff_drop(v_field_2417);
      v_t_2420 = MK_INT(8000LL);
    }
    V v_t_2422 = heff_tr(heff_call(heff_dup(v_nt_240), 1, (V[]){heff_tag_n(TAG_Listen, 4, (V[]){((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_str0), v_t_2420, MK_INT(64LL), ((V)&g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam2_clo)})}));
    return (g_co_2eop_24s94900133x232571340(v_t_2422, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edev_2epagesCmd_24s878987673x2135611450_lam3, 1, 8, (V[]){v_port_243, v_hd_245, v_k_246, v_proxy_244, v_x_2414, v_web_242, v_nt_240, v_rx_241})));
  }
}