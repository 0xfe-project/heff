// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_Copy 17796
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MkDir 57961
#define TAG_Move 53768
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_ReadOnly 17623
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_Start 63542
#define TAG_UseColor 15915
#define TAG_Windows 49101
#define TAG_WorkingDir 28879
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_absolute 325777132
#define LBL_apps 9496377
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_bind 9519364
#define LBL_build 295453320
#define LBL_by 9918
#define LBL_cwd 308458
#define LBL_defs 9574869
#define LBL_diags 296935042
#define LBL_diff 9578700
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_drive 297211300
#define LBL_effect 641056956
#define LBL_end 310101
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expected 956903529
#define LBL_expr 9623228
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_file 9638467
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_got 312070
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_key 315609
#define LBL_labels 836724522
#define LBL_lib 316671
#define LBL_malg 9839318
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_opt 319789
#define LBL_out 319944
#define LBL_outPath 1272254166
#define LBL_own 320000
#define LBL_owner 307523277
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_prefix 967031229
#define LBL_property 1899481104
#define LBL_renames 1324191545
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_run 322821
#define LBL_runs 10007567
#define LBL_said 10017968
#define LBL_seed 10021688
#define LBL_seen 10021698
#define LBL_segments 1801007612
#define LBL_shipTo 1043811586
#define LBL_ships 310766033
#define LBL_shrinks 154032591
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_src 323678
#define LBL_status 1054660381
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_value 313331083
#define LBL_version 583465758
#define LBL_watch 314261737
#define LBL_watches 1357821955
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_by__path__version[] = {LBL_by, LBL_path, LBL_version};
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_lib__mod__cwd__style[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_module__path__source__renames__implicit[] = {LBL_module, LBL_path, LBL_source, LBL_renames, LBL_implicit};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_name__build[] = {LBL_name, LBL_build};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_owner__watch[] = {LBL_owner, LBL_watch};
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
static uint32_t shape_total__failed__ok__tests__testsFailed[] = {LBL_total, LBL_failed, LBL_ok, LBL_tests, LBL_testsFailed};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eappFile_clo;
V g_heff_2ecommands_2eappRead_24s850601752x1675975415(V, V, V, V, V);
V g_heff_2ecommands_2eappRead_24s850601752x1675975415_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eappRead_24s850601752x1675975415_clo;
V g_heff_2ecommands_2eappShips_24s1825547416x1770957888(V, V, V, V, V, V);
V g_heff_2ecommands_2eappShips_24s1825547416x1770957888_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eappShips_24s1825547416x1770957888_clo;
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635(V, V, V, V, V);
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eappsIn_24s1939917301x724821635_clo;
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526(V, V, V, V, V, V, V, V);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_clo;
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273(V, V);
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_clo;
V g_heff_2ecommands_2ebuildEach_24s385407377x1706379496(V, V, V, V, V);
V g_heff_2ecommands_2ebuildEach_24s385407377x1706379496_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ebuildEach_24s385407377x1706379496_clo;
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042(V, V, V, V, V, V);
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_clo;
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035(V, V, V, V, V);
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_clo;
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661(V, V, V);
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_clo;
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318(V, V, V, V, V);
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_clo;
V g_heff_2ecommands_2ebuildTarget(V, V);
V g_heff_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ebuildTarget_clo;
V g_heff_2ecommands_2ebuildText_get(void);
V g_heff_2ecommands_2ecCmd_24s724601688x1192044019(V, V, V);
V g_heff_2ecommands_2ecCmd_24s724601688x1192044019_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecCmd_24s724601688x1192044019_clo;
V g_heff_2ecommands_2ecThen_24s903897371x1471440451(V, V, V, V);
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecThen_24s903897371x1471440451_clo;
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015(V);
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_entry(V self, V *a);
extern Clo g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_clo;
V g_heff_2ecommands_2echeckLast_24s411163256x943511502(V, V, V, V);
V g_heff_2ecommands_2echeckLast_24s411163256x943511502_entry(V self, V *a);
extern Clo g_heff_2ecommands_2echeckLast_24s411163256x943511502_clo;
V g_heff_2ecommands_2echeckModule_24s137050040x160185575(V, V, V);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_entry(V self, V *a);
extern Clo g_heff_2ecommands_2echeckModule_24s137050040x160185575_clo;
V g_heff_2ecommands_2echeckModules_24s831911915x2085898913(V, V, V);
V g_heff_2ecommands_2echeckModules_24s831911915x2085898913_entry(V self, V *a);
extern Clo g_heff_2ecommands_2echeckModules_24s831911915x2085898913_clo;
V g_heff_2ecommands_2ecompileDiags_24s921303827x759049455(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecommands_2ecompileDiags_24s921303827x759049455_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileDiags_24s921303827x759049455_clo;
V g_heff_2ecommands_2ecompileFound_24s787082998x1432739843(V, V, V, V, V, V, V);
V g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_clo;
V g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181(V, V, V, V, V, V, V);
V g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_clo;
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856(V, V);
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_clo;
V g_heff_2ecommands_2ecompileJsDiags_24s1851946979x681440696(V, V, V, V, V, V);
V g_heff_2ecommands_2ecompileJsDiags_24s1851946979x681440696_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileJsDiags_24s1851946979x681440696_clo;
V g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292(V, V, V, V, V);
V g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_clo;
V g_heff_2ecommands_2ecompileLast_24s1363458628x687987283(V, V, V, V, V, V, V);
V g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_clo;
V g_heff_2ecommands_2ecompileLastC_24s448887477x866119762(V, V, V, V, V, V);
V g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_clo;
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221(V, V, V, V, V);
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_clo;
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572(V);
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_clo;
V g_heff_2ecommands_2edefaultSeed_get(void);
V g_heff_2ecommands_2ediagCount_24s1773858402x841115473(V);
V g_heff_2ecommands_2ediagCount_24s1773858402x841115473_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ediagCount_24s1773858402x841115473_clo;
V g_heff_2ecommands_2eelemStrM(V, V);
V g_heff_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eelemStrM_clo;
V g_heff_2ecommands_2eemitErrs_24s852800528x545365095(V, V, V);
V g_heff_2ecommands_2eemitErrs_24s852800528x545365095_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eemitErrs_24s852800528x545365095_clo;
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915(V);
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_clo;
V g_heff_2ecommands_2eevalDiags_24s622182990x1910901847(V, V, V, V);
V g_heff_2ecommands_2eevalDiags_24s622182990x1910901847_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eevalDiags_24s622182990x1910901847_clo;
V g_heff_2ecommands_2eexisting_24s150974492x1363885069(V, V, V, V);
V g_heff_2ecommands_2eexisting_24s150974492x1363885069_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eexisting_24s150974492x1363885069_clo;
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381(V);
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_clo;
V g_heff_2ecommands_2efailLine(V, V, V);
V g_heff_2ecommands_2efailLine_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efailLine_clo;
V g_heff_2ecommands_2efailLines(V, V);
V g_heff_2ecommands_2efailLines_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efailLines_clo;
V g_heff_2ecommands_2efetched_24s1467657534x990122053(V, V, V);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efetched_24s1467657534x990122053_clo;
V g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881(V, V, V, V, V, V);
V g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_clo;
V g_heff_2ecommands_2efmtAll_24s486731757x642131866(V, V, V, V, V);
V g_heff_2ecommands_2efmtAll_24s486731757x642131866_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efmtAll_24s486731757x642131866_clo;
V g_heff_2ecommands_2efmtOne_24s852482434x948630519(V, V, V, V);
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efmtOne_24s852482434x948630519_clo;
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246(V, V, V, V);
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_entry(V self, V *a);
extern Clo g_heff_2ecommands_2efmtSrc_24s136663724x956277246_clo;
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_get(void);
V g_heff_2ecommands_2egetCmd_24s10896657x118494199(V, V, V);
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_entry(V self, V *a);
extern Clo g_heff_2ecommands_2egetCmd_24s10896657x118494199_clo;
V g_heff_2ecommands_2egetFails_24s970500795x1113151702(V, V, V);
V g_heff_2ecommands_2egetFails_24s970500795x1113151702_entry(V self, V *a);
extern Clo g_heff_2ecommands_2egetFails_24s970500795x1113151702_clo;
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469(V, V, V, V, V);
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_entry(V self, V *a);
extern Clo g_heff_2ecommands_2egetRequire_24s714371532x1125504469_clo;
V g_heff_2ecommands_2egitOk_24s1652772014x1583161201(V, V, V, V);
V g_heff_2ecommands_2egitOk_24s1652772014x1583161201_entry(V self, V *a);
extern Clo g_heff_2ecommands_2egitOk_24s1652772014x1583161201_clo;
V g_heff_2ecommands_2eheffErrors(V, V);
V g_heff_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eheffErrors_clo;
V g_heff_2ecommands_2eheffHome_24s914773566x189787564(V, V);
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eheffHome_24s914773566x189787564_clo;
V g_heff_2ecommands_2eheffVersions(V, V, V, V, V);
V g_heff_2ecommands_2eheffVersions_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eheffVersions_clo;
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798(V, V);
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_clo;
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488(V, V);
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo;
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128(V, V, V);
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_entry(V self, V *a);
extern Clo g_heff_2ecommands_2einitCmd_24s1172576284x845887128_clo;
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314(V, V, V);
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_entry(V self, V *a);
extern Clo g_heff_2ecommands_2einstallCmd_24s141488678x313111314_clo;
V g_heff_2ecommands_2eisThere_24s1074617931x1177790477(V, V, V);
V g_heff_2ecommands_2eisThere_24s1074617931x1177790477_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eisThere_24s1074617931x1177790477_clo;
V g_heff_2ecommands_2elibDir_24s652053211x1514718967(V, V);
V g_heff_2ecommands_2elibDir_24s652053211x1514718967_entry(V self, V *a);
extern Clo g_heff_2ecommands_2elibDir_24s652053211x1514718967_clo;
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942(V, V);
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_entry(V self, V *a);
extern Clo g_heff_2ecommands_2emodDir_24s1812307012x1810766942_clo;
V g_heff_2ecommands_2emoduleText(V);
V g_heff_2ecommands_2emoduleText_entry(V self, V *a);
extern Clo g_heff_2ecommands_2emoduleText_clo;
V g_heff_2ecommands_2enewestTag_24s456807686x23137961(V, V, V);
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_entry(V self, V *a);
extern Clo g_heff_2ecommands_2enewestTag_24s456807686x23137961_clo;
V g_heff_2ecommands_2enodeDone_24s1556319424x570941549(V, V, V, V);
V g_heff_2ecommands_2enodeDone_24s1556319424x570941549_entry(V self, V *a);
extern Clo g_heff_2ecommands_2enodeDone_24s1556319424x570941549_clo;
V g_heff_2ecommands_2enotInProject_24s862706981x126166655(V, V, V);
V g_heff_2ecommands_2enotInProject_24s862706981x126166655_entry(V self, V *a);
extern Clo g_heff_2ecommands_2enotInProject_24s862706981x126166655_clo;
V g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297(V, V, V, V);
V g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_entry(V self, V *a);
extern Clo g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_clo;
V g_heff_2ecommands_2enubStrGo(V, V);
V g_heff_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ecommands_2enubStrGo_clo;
V g_heff_2ecommands_2eonPathHint_24s240252977x1122862838(V, V, V, V);
V g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_clo;
V g_heff_2ecommands_2eoutcomeLine(V);
V g_heff_2ecommands_2eoutcomeLine_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eoutcomeLine_clo;
V g_heff_2ecommands_2eownPackage_24s2030161483x1635646466(V, V);
V g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_clo;
V g_heff_2ecommands_2eownRoot(V, V);
V g_heff_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eownRoot_clo;
V g_heff_2ecommands_2eownVersion_24s1137751716x1393321329(V, V);
V g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo;
V g_heff_2ecommands_2epartsDir(V, V, V);
V g_heff_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epartsDir_clo;
V g_heff_2ecommands_2epathOfModule(V, V);
V g_heff_2ecommands_2epathOfModule_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epathOfModule_clo;
V g_heff_2ecommands_2eprintAll_24s1507602401x266242271(V, V);
V g_heff_2ecommands_2eprintAll_24s1507602401x266242271_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprintAll_24s1507602401x266242271_clo;
V g_heff_2ecommands_2eprintDefs_24s214761775x657534145(V, V);
V g_heff_2ecommands_2eprintDefs_24s214761775x657534145_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprintDefs_24s214761775x657534145_clo;
V g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(V, V, V, V, V);
V g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_clo;
V g_heff_2ecommands_2eprintEvals_24s200975221x1971863026(V, V, V);
V g_heff_2ecommands_2eprintEvals_24s200975221x1971863026_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprintEvals_24s200975221x1971863026_clo;
V g_heff_2ecommands_2eprintFails_24s917669454x1451729436(V, V, V);
V g_heff_2ecommands_2eprintFails_24s917669454x1451729436_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprintFails_24s917669454x1451729436_clo;
V g_heff_2ecommands_2eprintLines_24s1854861431x875412566(V, V, V);
V g_heff_2ecommands_2eprintLines_24s1854861431x875412566_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprintLines_24s1854861431x875412566_clo;
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504(V, V);
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_clo;
V g_heff_2ecommands_2eprogramText(V);
V g_heff_2ecommands_2eprogramText_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprogramText_clo;
V g_heff_2ecommands_2eprojectFiles(V, V);
V g_heff_2ecommands_2eprojectFiles_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprojectFiles_clo;
V g_heff_2ecommands_2eprojectName(V, V, V);
V g_heff_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprojectName_clo;
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604(V);
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_clo;
V g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421(V, V, V, V, V);
V g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_clo;
V g_heff_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ecommands_2epublishChecked_24s261068515x607614241(V, V, V);
V g_heff_2ecommands_2epublishChecked_24s261068515x607614241_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epublishChecked_24s261068515x607614241_clo;
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439(V);
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_clo;
V g_heff_2ecommands_2epublishFails_24s1138740946x688035206(V, V, V);
V g_heff_2ecommands_2epublishFails_24s1138740946x688035206_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epublishFails_24s1138740946x688035206_clo;
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200(V, V, V, V, V);
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_clo;
V g_heff_2ecommands_2epublishTag_24s146522991x1682623660(V, V, V, V);
V g_heff_2ecommands_2epublishTag_24s146522991x1682623660_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epublishTag_24s146522991x1682623660_clo;
V g_heff_2ecommands_2epublishTested_24s632403930x348860581(V, V, V);
V g_heff_2ecommands_2epublishTested_24s632403930x348860581_entry(V self, V *a);
extern Clo g_heff_2ecommands_2epublishTested_24s632403930x348860581_clo;
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672(V, V, V);
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_clo;
V g_heff_2ecommands_2ereadAll_24s31913908x765275890(V, V, V, V);
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ereadAll_24s31913908x765275890_clo;
V g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288(V, V);
V g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_clo;
V g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493(V, V);
V g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_clo;
V g_heff_2ecommands_2ereadProviders_24s1822069164x530433648(V, V);
V g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_clo;
V g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080(V, V);
V g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_clo;
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612(V, V);
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_clo;
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654(V, V, V, V, V);
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_clo;
V g_heff_2ecommands_2erequiring(V, V, V, V);
V g_heff_2ecommands_2erequiring_entry(V self, V *a);
extern Clo g_heff_2ecommands_2erequiring_clo;
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376(V, V);
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_entry(V self, V *a);
extern Clo g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_clo;
V g_heff_2ecommands_2erunDir(V);
V g_heff_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ecommands_2erunDir_clo;
V g_heff_2ecommands_2erunPath(V, V);
V g_heff_2ecommands_2erunPath_entry(V self, V *a);
extern Clo g_heff_2ecommands_2erunPath_clo;
V g_heff_2ecommands_2eselfcheck_24s1104448856x189651634(V, V, V);
V g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_clo;
V g_heff_2ecommands_2eshipAll_24s1787275079x301132786(V, V, V, V, V, V);
V g_heff_2ecommands_2eshipAll_24s1787275079x301132786_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eshipAll_24s1787275079x301132786_clo;
V g_heff_2ecommands_2eshipFails_24s1573494380x931648657(V, V, V);
V g_heff_2ecommands_2eshipFails_24s1573494380x931648657_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eshipFails_24s1573494380x931648657_clo;
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526(V, V, V, V);
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eshipIn_24s1932155328x737088526_clo;
V g_heff_2ecommands_2eshipIn_24s921163756x271563113(V, V, V, V, V);
V g_heff_2ecommands_2eshipIn_24s921163756x271563113_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eshipIn_24s921163756x271563113_clo;
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548(V, V, V, V, V, V, V, V);
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_clo;
V g_heff_2ecommands_2eshipOne_24s392735153x883961245(V, V, V, V, V, V, V, V);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eshipOne_24s392735153x883961245_clo;
V g_heff_2ecommands_2estatistic(V);
V g_heff_2ecommands_2estatistic_entry(V self, V *a);
extern Clo g_heff_2ecommands_2estatistic_clo;
V g_heff_2ecommands_2esumsOf_24s591159322x49660413(V, V, V);
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_entry(V self, V *a);
extern Clo g_heff_2ecommands_2esumsOf_24s591159322x49660413_clo;
V g_heff_2ecommands_2etestAll_24s1250025441x1950168553(V, V);
V g_heff_2ecommands_2etestAll_24s1250025441x1950168553_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestAll_24s1250025441x1950168553_clo;
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428(V, V, V, V, V, V);
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestCmd_24s594351318x1837481428_clo;
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632(V);
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestFiles_24s195001740x1715824632_clo;
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249(V, V);
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_clo;
V g_heff_2ecommands_2etestOneC_24s478685886x44287029(V, V, V, V);
V g_heff_2ecommands_2etestOneC_24s478685886x44287029_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestOneC_24s478685886x44287029_clo;
V g_heff_2ecommands_2etestOneF_24s48196897x863364522(V, V);
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestOneF_24s48196897x863364522_clo;
V g_heff_2ecommands_2etestReport_24s576678775x1979662005(V, V, V, V, V, V);
V g_heff_2ecommands_2etestReport_24s576678775x1979662005_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestReport_24s576678775x1979662005_clo;
V g_heff_2ecommands_2etestText(V);
V g_heff_2ecommands_2etestText_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestText_clo;
V g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838(V, V);
V g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_clo;
V g_heff_2ecommands_2etestsSaid(V);
V g_heff_2ecommands_2etestsSaid_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etestsSaid_clo;
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198(V, V);
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_entry(V self, V *a);
extern Clo g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_clo;
V g_heff_2ecommands_2eversionCmd_24s622085897x237111290(V, V);
V g_heff_2ecommands_2eversionCmd_24s622085897x237111290_entry(V self, V *a);
extern Clo g_heff_2ecommands_2eversionCmd_24s622085897x237111290_clo;
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198(V, V, V, V);
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_clo;
V g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448(V, V, V, V, V);
V g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_clo;
V g_heff_2ecommands_2ewriteOut_24s522201506x283476832(V, V, V, V, V);
V g_heff_2ecommands_2ewriteOut_24s522201506x283476832_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ewriteOut_24s522201506x283476832_clo;
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955(V, V, V, V, V);
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ewriteParts_24s814767795x657824955_clo;
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080(V, V, V, V);
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_clo;
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141(V, V, V, V, V);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_entry(V self, V *a);
extern Clo g_heff_2ecommands_2ezigCc_24s1182148294x862333141_clo;
V g_heff_2edriver_2ecandLeaves(V);
V g_heff_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2edriver_2ecandLeaves_clo;
V g_heff_2edriver_2ecandidatesOf(V);
V g_heff_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2edriver_2ecandidatesOf_clo;
V g_heff_2edriver_2ecatMaybesD(V);
V g_heff_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2edriver_2ecatMaybesD_clo;
V g_heff_2edriver_2edumpLines(V, V);
V g_heff_2edriver_2edumpLines_entry(V self, V *a);
extern Clo g_heff_2edriver_2edumpLines_clo;
V g_heff_2edriver_2eevaluate(V);
V g_heff_2edriver_2eevaluate_entry(V self, V *a);
extern Clo g_heff_2edriver_2eevaluate_clo;
V g_heff_2edriver_2efindRunnable(V, V, V);
V g_heff_2edriver_2efindRunnable_entry(V self, V *a);
extern Clo g_heff_2edriver_2efindRunnable_clo;
V g_heff_2edriver_2efixitiesGo(V, V);
V g_heff_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2edriver_2efixitiesGo_clo;
V g_heff_2edriver_2einterface(V);
V g_heff_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2edriver_2einterface_clo;
V g_heff_2edriver_2elastChecked(V);
V g_heff_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2edriver_2elastChecked_clo;
V g_heff_2edriver_2enubStrD(V);
V g_heff_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2edriver_2enubStrD_clo;
V g_heff_2edriver_2eownerOf(V, V);
V g_heff_2edriver_2eownerOf_entry(V self, V *a);
extern Clo g_heff_2edriver_2eownerOf_clo;
V g_heff_2edriver_2erunTests(V, V);
V g_heff_2edriver_2erunTests_entry(V self, V *a);
extern Clo g_heff_2edriver_2erunTests_clo;
V g_heff_2edriver_2ewatchesGo(V, V, V);
V g_heff_2edriver_2ewatchesGo_entry(V self, V *a);
extern Clo g_heff_2edriver_2ewatchesGo_clo;
V g_heff_2eeffect_2edropLastD(V);
V g_heff_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eeffect_2edropLastD_clo;
V g_heff_2eeffect_2elastOr(V, V);
V g_heff_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eeffect_2elastOr_clo;
V g_heff_2eeffect_2eleaves(V);
V g_heff_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eeffect_2eleaves_clo;
V g_heff_2eemit_2ecatMaybesL(V);
V g_heff_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2eemit_2ecatMaybesL_clo;
V g_heff_2eemit_2ecompileJs(V, V);
V g_heff_2eemit_2ecompileJs_entry(V self, V *a);
extern Clo g_heff_2eemit_2ecompileJs_clo;
V g_heff_2eemit_2ecompileLowered(V, V, V, V, V);
V g_heff_2eemit_2ecompileLowered_entry(V self, V *a);
extern Clo g_heff_2eemit_2ecompileLowered_clo;
V g_heff_2eemit_2enubGo(V, V);
V g_heff_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2eemit_2enubGo_clo;
V g_heff_2eemit_2eprovsForGo(V, V);
V g_heff_2eemit_2eprovsForGo_entry(V self, V *a);
extern Clo g_heff_2eemit_2eprovsForGo_clo;
V g_heff_2eemitc_2ecatMaybesC(V);
V g_heff_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eemitc_2ecatMaybesC_clo;
V g_heff_2eemitc_2echeckOut(V, V, V);
V g_heff_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2eemitc_2echeckOut_clo;
V g_heff_2eemitc_2eoutputOf(V, V, V, V);
V g_heff_2eemitc_2eoutputOf_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eoutputOf_clo;
V g_heff_2eemitc_2eprogramParts(V, V, V, V);
V g_heff_2eemitc_2eprogramParts_entry(V self, V *a);
extern Clo g_heff_2eemitc_2eprogramParts_clo;
V g_heff_2eemitc_2erunEnd(V, V);
V g_heff_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2eemitc_2erunEnd_clo;
V g_heff_2eerase_2eeraseProgram(V);
V g_heff_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2eerase_2eeraseProgram_clo;
V g_heff_2efmt_2elayout_2eformatUncheckedIn(V, V);
V g_heff_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a);
extern Clo g_heff_2efmt_2elayout_2eformatUncheckedIn_clo;
V g_heff_2eformat_2echeck(V, V);
V g_heff_2eformat_2echeck_entry(V self, V *a);
extern Clo g_heff_2eformat_2echeck_clo;
V g_heff_2eformat_2eformat(V);
V g_heff_2eformat_2eformat_entry(V self, V *a);
extern Clo g_heff_2eformat_2eformat_clo;
V g_heff_2eimport_2eimplicitModules_get(void);
V g_heff_2eload_2ecachedDir(V, V, V);
V g_heff_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2eload_2ecachedDir_clo;
V g_heff_2eload_2efromCwd(V, V);
V g_heff_2eload_2efromCwd_entry(V self, V *a);
extern Clo g_heff_2eload_2efromCwd_clo;
V g_heff_2eload_2eisRoot_24s954538899x21349900(V, V);
V g_heff_2eload_2eisRoot_24s954538899x21349900_entry(V self, V *a);
extern Clo g_heff_2eload_2eisRoot_24s954538899x21349900_clo;
V g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(V, V);
V g_heff_2eload_2eloadProgramWith_24s1589620423x205198563_entry(V self, V *a);
extern Clo g_heff_2eload_2eloadProgramWith_24s1589620423x205198563_clo;
V g_heff_2eload_2emoduleOf(V, V);
V g_heff_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2eload_2emoduleOf_clo;
V g_heff_2eload_2eownDir_24s36575787x1607510651(V, V, V, V);
V g_heff_2eload_2eownDir_24s36575787x1607510651_entry(V self, V *a);
extern Clo g_heff_2eload_2eownDir_24s36575787x1607510651_clo;
V g_heff_2eload_2epathsFor_24s382934904x1572524859(V, V);
V g_heff_2eload_2epathsFor_24s382934904x1572524859_entry(V self, V *a);
extern Clo g_heff_2eload_2epathsFor_24s382934904x1572524859_clo;
V g_heff_2eload_2eproblemMsg(V, V, V);
V g_heff_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2eload_2eproblemMsg_clo;
V g_heff_2eload_2ereadPkgAt_24s1743338588x1287501617(V, V, V);
V g_heff_2eload_2ereadPkgAt_24s1743338588x1287501617_entry(V self, V *a);
extern Clo g_heff_2eload_2ereadPkgAt_24s1743338588x1287501617_clo;
V g_heff_2eload_2ereadSumAt_24s957792674x1765222920(V);
V g_heff_2eload_2ereadSumAt_24s957792674x1765222920_entry(V self, V *a);
extern Clo g_heff_2eload_2ereadSumAt_24s957792674x1765222920_clo;
V g_heff_2eload_2eunder(V, V, V);
V g_heff_2eload_2eunder_entry(V self, V *a);
extern Clo g_heff_2eload_2eunder_clo;
V g_heff_2eload_2eversionsGo_24s1827927732x1970474346(V, V, V, V, V);
V g_heff_2eload_2eversionsGo_24s1827927732x1970474346_entry(V self, V *a);
extern Clo g_heff_2eload_2eversionsGo_24s1827927732x1970474346_clo;
V g_heff_2elower_2eanfLowered(V, V);
V g_heff_2elower_2eanfLowered_entry(V self, V *a);
extern Clo g_heff_2elower_2eanfLowered_clo;
V g_heff_2elower_2elowerProgram(V, V);
V g_heff_2elower_2elowerProgram_entry(V self, V *a);
extern Clo g_heff_2elower_2elowerProgram_clo;
V g_heff_2elower_2elowerProgramAnf(V, V);
V g_heff_2elower_2elowerProgramAnf_entry(V self, V *a);
extern Clo g_heff_2elower_2elowerProgramAnf_clo;
V g_heff_2eproject_2ecompatible(V, V);
V g_heff_2eproject_2ecompatible_entry(V self, V *a);
extern Clo g_heff_2eproject_2ecompatible_clo;
V g_heff_2eproject_2eisName(V);
V g_heff_2eproject_2eisName_entry(V self, V *a);
extern Clo g_heff_2eproject_2eisName_clo;
V g_heff_2eproject_2eisNumber(V);
V g_heff_2eproject_2eisNumber_entry(V self, V *a);
extern Clo g_heff_2eproject_2eisNumber_clo;
V g_heff_2eproject_2emajorMismatch(V, V);
V g_heff_2eproject_2emajorMismatch_entry(V self, V *a);
extern Clo g_heff_2eproject_2emajorMismatch_clo;
V g_heff_2eproject_2enewerGo(V, V);
V g_heff_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2eproject_2enewerGo_clo;
V g_heff_2eproject_2ereadBuild(V);
V g_heff_2eproject_2ereadBuild_entry(V self, V *a);
extern Clo g_heff_2eproject_2ereadBuild_clo;
V g_heff_2eproject_2ereadPackage(V);
V g_heff_2eproject_2ereadPackage_entry(V self, V *a);
extern Clo g_heff_2eproject_2ereadPackage_clo;
V g_heff_2eproject_2erepoOf(V);
V g_heff_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2eproject_2erepoOf_clo;
V g_heff_2eproject_2eversion(V);
V g_heff_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2eproject_2eversion_clo;
V g_heff_2eproject_2ewithPackage(V, V);
V g_heff_2eproject_2ewithPackage_entry(V self, V *a);
extern Clo g_heff_2eproject_2ewithPackage_clo;
V g_heff_2equery_2eexplain(V);
V g_heff_2equery_2eexplain_entry(V self, V *a);
extern Clo g_heff_2equery_2eexplain_clo;
V g_heff_2equery_2etypeAt(V, V);
V g_heff_2equery_2etypeAt_entry(V self, V *a);
extern Clo g_heff_2equery_2etypeAt_clo;
V g_heff_2erender_2efileDiag(V, V, V, V);
V g_heff_2erender_2efileDiag_entry(V self, V *a);
extern Clo g_heff_2erender_2efileDiag_clo;
V g_heff_2ereport_2emismatch(V, V, V);
V g_heff_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2ereport_2emismatch_clo;
V g_heff_2esession_2ecachedProgram_24s595918180x507103762(V);
V g_heff_2esession_2ecachedProgram_24s595918180x507103762_entry(V self, V *a);
extern Clo g_heff_2esession_2ecachedProgram_24s595918180x507103762_clo;
V g_prelude_2eany(V, V);
V g_prelude_2eany_entry(V self, V *a);
extern Clo g_prelude_2eany_clo;
V g_prelude_2eany_24s827288872x1370860167(V);
V g_prelude_2eany_24s827288872x1370860167_entry(V self, V *a);
extern Clo g_prelude_2eany_24s827288872x1370860167_clo;
V g_prelude_2econcatList(V, V);
V g_prelude_2econcatList_entry(V self, V *a);
extern Clo g_prelude_2econcatList_clo;
V g_prelude_2edrop(V, V);
V g_prelude_2edrop_entry(V self, V *a);
extern Clo g_prelude_2edrop_clo;
V g_prelude_2efilter(V, V);
V g_prelude_2efilter_entry(V self, V *a);
extern Clo g_prelude_2efilter_clo;
V g_prelude_2efilter_24s1514461241x1644469075(V);
V g_prelude_2efilter_24s1514461241x1644469075_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s1514461241x1644469075_clo;
V g_prelude_2efilter_24s1642131147x1885675035(V, V, V, V);
V g_prelude_2efilter_24s1642131147x1885675035_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s1642131147x1885675035_clo;
V g_prelude_2efilter_24s1700824619x1565819740(V);
V g_prelude_2efilter_24s1700824619x1565819740_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s1700824619x1565819740_clo;
V g_prelude_2efilter_24s419026844x1025599777(V, V, V);
V g_prelude_2efilter_24s419026844x1025599777_entry(V self, V *a);
extern Clo g_prelude_2efilter_24s419026844x1025599777_clo;
V g_prelude_2efoldl(V, V, V);
V g_prelude_2efoldl_entry(V self, V *a);
extern Clo g_prelude_2efoldl_clo;
V g_prelude_2efoldl_24s1053087238x1725706605(V, V);
V g_prelude_2efoldl_24s1053087238x1725706605_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1053087238x1725706605_clo;
V g_prelude_2efoldl_24s1064255209x1797926961(V, V);
V g_prelude_2efoldl_24s1064255209x1797926961_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1064255209x1797926961_clo;
V g_prelude_2efoldl_24s1226147011x367015740(V, V, V);
V g_prelude_2efoldl_24s1226147011x367015740_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1226147011x367015740_clo;
V g_prelude_2efoldl_24s1546929672x1472202881(V, V);
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1546929672x1472202881_clo;
V g_prelude_2efoldl_24s1838030138x788027388(V, V);
V g_prelude_2efoldl_24s1838030138x788027388_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1838030138x788027388_clo;
V g_prelude_2efoldl_24s1939305664x1902528268(V, V, V);
V g_prelude_2efoldl_24s1939305664x1902528268_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1939305664x1902528268_clo;
V g_prelude_2efoldl_24s656731303x133259214(V, V, V, V);
V g_prelude_2efoldl_24s656731303x133259214_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s656731303x133259214_clo;
V g_prelude_2efoldl_24s701395232x704703097(V, V);
V g_prelude_2efoldl_24s701395232x704703097_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s701395232x704703097_clo;
V g_prelude_2efoldl_24s809825463x1159518974(V, V, V, V, V);
V g_prelude_2efoldl_24s809825463x1159518974_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s809825463x1159518974_clo;
V g_prelude_2efoldl_24s847320519x792667925(V, V);
V g_prelude_2efoldl_24s847320519x792667925_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s847320519x792667925_clo;
V g_prelude_2emap(V, V);
V g_prelude_2emap_entry(V self, V *a);
extern Clo g_prelude_2emap_clo;
V g_prelude_2emap_24s1213322018x576418267(V);
V g_prelude_2emap_24s1213322018x576418267_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1213322018x576418267_clo;
V g_prelude_2emap_24s1248084495x1713083677(V, V, V, V, V, V);
V g_prelude_2emap_24s1248084495x1713083677_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1248084495x1713083677_clo;
V g_prelude_2emap_24s1448703749x94773476(V);
V g_prelude_2emap_24s1448703749x94773476_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1448703749x94773476_clo;
V g_prelude_2emap_24s1537567598x716246174(V, V, V);
V g_prelude_2emap_24s1537567598x716246174_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1537567598x716246174_clo;
V g_prelude_2emap_24s1559710030x546042594(V, V);
V g_prelude_2emap_24s1559710030x546042594_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1559710030x546042594_clo;
V g_prelude_2emap_24s173337351x1152519035(V, V, V, V);
V g_prelude_2emap_24s173337351x1152519035_entry(V self, V *a);
extern Clo g_prelude_2emap_24s173337351x1152519035_clo;
V g_prelude_2emap_24s1843312214x961377872(V);
V g_prelude_2emap_24s1843312214x961377872_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1843312214x961377872_clo;
V g_prelude_2emap_24s1865958870x1922568484(V);
V g_prelude_2emap_24s1865958870x1922568484_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1865958870x1922568484_clo;
V g_prelude_2emap_24s2025198057x415178258(V);
V g_prelude_2emap_24s2025198057x415178258_entry(V self, V *a);
extern Clo g_prelude_2emap_24s2025198057x415178258_clo;
V g_prelude_2emap_24s546221959x1645923250(V);
V g_prelude_2emap_24s546221959x1645923250_entry(V self, V *a);
extern Clo g_prelude_2emap_24s546221959x1645923250_clo;
V g_prelude_2emap_24s554277126x598800825(V);
V g_prelude_2emap_24s554277126x598800825_entry(V self, V *a);
extern Clo g_prelude_2emap_24s554277126x598800825_clo;
V g_prelude_2emap_24s656438675x1758438999(V, V, V, V, V);
V g_prelude_2emap_24s656438675x1758438999_entry(V self, V *a);
extern Clo g_prelude_2emap_24s656438675x1758438999_clo;
V g_prelude_2emap_24s752906154x1709852375(V, V, V);
V g_prelude_2emap_24s752906154x1709852375_entry(V self, V *a);
extern Clo g_prelude_2emap_24s752906154x1709852375_clo;
V g_prelude_2emap_24s772488398x992379409(V);
V g_prelude_2emap_24s772488398x992379409_entry(V self, V *a);
extern Clo g_prelude_2emap_24s772488398x992379409_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esortBy_24s1510757765x2064206644(V);
V g_prelude_2esortBy_24s1510757765x2064206644_entry(V self, V *a);
extern Clo g_prelude_2esortBy_24s1510757765x2064206644_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ecollapse(V, V);
V g_std_2epath_2ecollapse_entry(V self, V *a);
extern Clo g_std_2epath_2ecollapse_clo;
V g_std_2epath_2eisUnder(V, V, V);
V g_std_2epath_2eisUnder_entry(V self, V *a);
extern Clo g_std_2epath_2eisUnder_clo;
V g_std_2epath_2ejoin_2eonto_240(V, V);
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_2eonto_240_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eownRoot_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eownRoot_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {111, 117, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eownRoot_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2eownRoot_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
Clo g_heff_2ecommands_2eownRoot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eownRoot_entry, 2, 0};

V g_heff_2ecommands_2eownRoot(V v_st_240, V v_self_241) {
top: ;
  V v_p_242 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_self_241)));
  V v_t_243 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_p_242), LBL_segments)));
  V v_xs_244 = (g_prelude_2edrop(MK_INT(1LL), v_t_243));
  V v_t_245 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_244));
  V v_t_246 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_242), LBL_drive), heff_get(v_p_242, LBL_absolute), v_t_245});
  V v_s_247 = (g_std_2epath_2erender(v_st_240, v_t_246));
  V v_t_248 = (g_std_2epath_2eparse(v_st_240, v_s_247));
  V v_xs_249 = heff_get(v_t_248, LBL_segments);
  V v_x1_2410 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_249));
  V v_x2_2413;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nil: {
    v_x2_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 2);
    v_x2_2413 = heff_tag(TAG_Just, 1, (V[]){v_x_2411});
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  V v_t_2415;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nothing: {
    v_t_2415 = ((V)&g_heff_2ecommands_2eownRoot_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    heff_take_n(v_x2_2413, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  V v_t_2416 = heff_strEq(v_t_2415, ((V)&g_heff_2ecommands_2eownRoot_str1));
  V v_t_2437;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    V v_p_2417 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_self_241)));
    V v_t_2418 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2417), LBL_segments)));
    V v_xs_2419 = (g_prelude_2edrop(MK_INT(1LL), v_t_2418));
    V v_t_2420 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2419));
    V v_t_2421 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2417), LBL_drive), heff_get(v_p_2417, LBL_absolute), v_t_2420});
    V v_s_2422 = (g_std_2epath_2erender(v_st_240, v_t_2421));
    V v_p_2423 = (g_std_2epath_2eparse(v_st_240, v_s_2422));
    V v_t_2424 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2423), LBL_segments)));
    V v_xs_2425 = (g_prelude_2edrop(MK_INT(1LL), v_t_2424));
    V v_t_2426 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2425));
    V v_t_2427 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2423), LBL_drive), heff_get(v_p_2423, LBL_absolute), v_t_2426});
    V v_s_2428 = (g_std_2epath_2erender(v_st_240, v_t_2427));
    V v_t_2429 = (g_std_2epath_2eparse(v_st_240, v_s_2428));
    V v_xs_2430 = heff_get(v_t_2429, LBL_segments);
    V v_x1_2431 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2430));
    V v_x2_2434;
    switch (heff_tag_of(v_x1_2431)) {
    case TAG_Nil: {
      v_x2_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2432 = heff_field(v_x1_2431, 0);
      heff_take_n(v_x1_2431, 1ULL, 2);
      v_x2_2434 = heff_tag(TAG_Just, 1, (V[]){v_x_2432});
      break;
    }
    default: heff_nomatch(v_x1_2431);
    }
    V v_t_2436;
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_Nothing: {
      v_t_2436 = ((V)&g_heff_2ecommands_2eownRoot_str2);
      break;
    }
    case TAG_Just: {
      V v_x_2435 = heff_field(v_x2_2434, 0);
      heff_take_n(v_x2_2434, 1ULL, 1);
      v_t_2436 = v_x_2435;
      break;
    }
    default: heff_nomatch(v_x2_2434);
    }
    v_t_2437 = heff_strEq(v_t_2436, ((V)&g_heff_2ecommands_2eownRoot_str3));
    break;
  }
  case TAG_False: {
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  switch (heff_tag_of(v_t_2437)) {
  case TAG_True: {
    V v_p_2438 = (g_std_2epath_2eparse(v_st_240, v_self_241));
    V v_t_2439 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2438), LBL_segments)));
    V v_xs_2440 = (g_prelude_2edrop(MK_INT(1LL), v_t_2439));
    V v_t_2441 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2440));
    V v_t_2442 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2438), LBL_drive), heff_get(v_p_2438, LBL_absolute), v_t_2441});
    V v_s_2443 = (g_std_2epath_2erender(v_st_240, v_t_2442));
    V v_p_2444 = (g_std_2epath_2eparse(v_st_240, v_s_2443));
    V v_t_2445 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2444), LBL_segments)));
    V v_xs_2446 = (g_prelude_2edrop(MK_INT(1LL), v_t_2445));
    V v_t_2447 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2446));
    V v_t_2448 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2444), LBL_drive), heff_get(v_p_2444, LBL_absolute), v_t_2447});
    V v_s_2449 = (g_std_2epath_2erender(v_st_240, v_t_2448));
    V v_p_2450 = (g_std_2epath_2eparse(v_st_240, v_s_2449));
    V v_t_2451 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2450), LBL_segments)));
    V v_xs_2452 = (g_prelude_2edrop(MK_INT(1LL), v_t_2451));
    V v_t_2453 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2452));
    V v_t_2454 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2450), LBL_drive), heff_get(v_p_2450, LBL_absolute), v_t_2453});
    HEFF_LAST return g_std_2epath_2erender(v_st_240, v_t_2454);
  }
  case TAG_False: {
    V v_p_2455 = (g_std_2epath_2eparse(v_st_240, v_self_241));
    V v_t_2456 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2455), LBL_segments)));
    V v_xs_2457 = (g_prelude_2edrop(MK_INT(1LL), v_t_2456));
    V v_t_2458 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2457));
    V v_t_2459 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2455), LBL_drive), heff_get(v_p_2455, LBL_absolute), v_t_2458});
    V v_s_2460 = (g_std_2epath_2erender(v_st_240, v_t_2459));
    V v_p_2461 = (g_std_2epath_2eparse(v_st_240, v_s_2460));
    V v_t_2462 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2461), LBL_segments)));
    V v_xs_2463 = (g_prelude_2edrop(MK_INT(1LL), v_t_2462));
    V v_t_2464 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2463));
    V v_t_2465 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2461), LBL_drive), heff_get(v_p_2461, LBL_absolute), v_t_2464});
    HEFF_LAST return g_std_2epath_2erender(v_st_240, v_t_2465);
  }
  default: return heff_nomatch(v_t_2437);
  }
}
V g_heff_2ecommands_2eownRoot_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eownRoot(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2eheffVersions_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {48, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2eheffVersions_str1 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 40, 116, 104, 101, 32, 115, 97, 109, 101, 32, 48, 46, 120, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eheffVersions_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2eheffVersions_str3 = {{0x80000000u, K_STR, 0}, 13, 13, {32, 105, 115, 32, 102, 111, 114, 32, 104, 101, 102, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2ecommands_2eheffVersions_str4 = {{0x80000000u, K_STR, 0}, 19, 19, {44, 32, 97, 110, 100, 32, 116, 104, 105, 115, 32, 104, 101, 102, 102, 32, 105, 115, 32}};
Clo g_heff_2ecommands_2eheffVersions_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffVersions_entry, 5, 0};

V g_heff_2ecommands_2eheffVersions(V v_who_240, V v_wanted_241, V v_running_242, V v_x4_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_who_240);
    heff_drop(v_wanted_241);
    heff_drop(v_running_242);
    heff_drop(v_x5_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_w_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nothing: {
      heff_drop(v_who_240);
      heff_drop(v_wanted_241);
      heff_drop(v_running_242);
      heff_drop(v_w_245);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_r_246 = heff_field(v_x5_244, 0);
      heff_take_n(v_x5_244, 1ULL, 1);
      V v_t_247 = ({ V a_0 = v_w_245; V a_1 = v_r_246; V r_ = (g_heff_2eproject_2ecompatible(a_0, a_1)); heff_drop(v_w_245); heff_drop(v_r_246); r_; });
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_who_240);
        heff_drop(v_wanted_241);
        heff_drop(v_running_242);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V v_t_248 = heff_strEq(heff_strSlice(heff_dup(v_wanted_241), MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2ecommands_2eheffVersions_str0));
        V v_t_249;
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          v_t_249 = ((V)&g_heff_2ecommands_2eheffVersions_str1);
          break;
        }
        case TAG_False: {
          v_t_249 = ((V)&g_heff_2ecommands_2eheffVersions_str2);
          break;
        }
        default: heff_nomatch(v_t_248);
        }
        V v_t_2410 = heff_strAppend(v_who_240, heff_strAppend(((V)&g_heff_2ecommands_2eheffVersions_str3), heff_strAppend(v_wanted_241, heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecommands_2eheffVersions_str4), v_running_242)))));
        return heff_tag_at(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){v_t_2410});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecommands_2eheffVersions_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eheffVersions(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eheffErrors_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eheffErrors_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2ecommands_2eheffErrors_str2 = {{0x80000000u, K_STR, 0}, 23, 23, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 58, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2eheffErrors_str3 = {{0x80000000u, K_STR, 0}, 12, 12, {116, 104, 101, 32, 112, 97, 99, 107, 97, 103, 101, 32}};
V g_heff_2ecommands_2eheffErrors_lam0(V self, V *args);
Clo g_heff_2ecommands_2eheffErrors_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffErrors_entry, 2, 0};

V g_heff_2ecommands_2eheffErrors(V v_running_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_project_242 = heff_field(v_x2_241, 0);
    V v_deps_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strEq(heff_get(heff_dup(v_project_242), LBL_heff), ((V)&g_heff_2ecommands_2eheffErrors_str0));
    V v_xs_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_project_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      v_xs_245 = v_deps_243;
      break;
    }
    case TAG_False: {
      v_xs_245 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_project_242, v_deps_243});
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_t_246 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_245));
    return ({ V a_0 = heff_clo(g_heff_2ecommands_2eheffErrors_lam0, 2, 1, (V[]){heff_dup(v_running_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eheffErrors_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eheffErrors(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eheffErrors_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_running_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_strEq(heff_get(heff_dup(v_x_248), LBL_own), ((V)&g_heff_2ecommands_2eheffErrors_str1));
  V v_who_2410;
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    v_who_2410 = ((V)&g_heff_2ecommands_2eheffErrors_str2);
    break;
  }
  case TAG_False: {
    v_who_2410 = heff_strAppend(((V)&g_heff_2ecommands_2eheffErrors_str3), heff_get(heff_dup(v_x_248), LBL_path));
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_wanted_2411 = heff_get(v_x_248, LBL_heff);
  V v_t_2417;
  switch (heff_tag_of(v_running_240)) {
  case TAG_Nothing: {
    heff_drop(v_who_2410);
    heff_drop(v_wanted_2411);
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_running_2412 = heff_field(v_running_240, 0);
    heff_take_n(v_running_240, 1ULL, 1);
    V v_t_2413 = (g_heff_2eproject_2eversion(heff_dup(v_wanted_2411)));
    V v_t_2414 = (g_heff_2eproject_2eversion(heff_dup(v_running_2412)));
    V v_t_2415 = (g_heff_2ecommands_2eheffVersions(v_who_2410, v_wanted_2411, v_running_2412, v_t_2413, v_t_2414));
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_why_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){v_why_2416, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    break;
  }
  default: heff_nomatch(v_running_240);
  }
  return (g_prelude_2econcatList(v_t_2417, v_acc_247));
}
Clo g_heff_2ecommands_2eelemStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eelemStrM_entry, 2, 0};

V g_heff_2ecommands_2eelemStrM(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_strEq(heff_dup(v_x_240), heff_dup(v_y_242));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eelemStrM_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eelemStrM(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecommands_2enubStrGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enubStrGo_entry, 2, 0};

V g_heff_2ecommands_2enubStrGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecommands_2eelemStrM(heff_dup(v_x_242), v_seen_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), (g_heff_2ecommands_2enubStrGo(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_rest_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2enubStrGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2enubStrGo(a[0], a[1]);
}
Clo g_heff_2ecommands_2epathOfModule_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epathOfModule_entry, 2, 0};

V g_heff_2ecommands_2epathOfModule(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_m_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_strEq(heff_get(heff_dup(v_s_242), LBL_module), heff_dup(v_m_241));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_m_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_get(heff_dup(v_s_242), LBL_path)});
    }
    case TAG_False: {
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2epathOfModule_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2epathOfModule(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeaf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeaf_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeaf_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeaf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeaf_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeaf_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
Clo g_heff_2ecommands_2eprovidesLeaf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprovidesLeaf_entry, 2, 0};

V g_heff_2ecommands_2eprovidesLeaf(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeaf_str0), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x2_245 = (g_heff_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ecommands_2eprovidesLeaf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ecommands_2eprovidesLeaf_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_strEq(heff_get(heff_dup(v_p_242), LBL_module), v_t_248);
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V v_t_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeaf_str3), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeaf_str4), heff_get(heff_dup(v_p_242), LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2413 = (g_prelude_2emap_24s1213322018x576418267(v_t_2412));
      V v_t_2414 = (g_heff_2eemit_2ecatMaybesL(v_t_2413));
      V v_t_2415 = (g_prelude_2efilter_24s1642131147x1885675035(MK_INT(0LL), MK_INT(1LL), ((V)&g_heff_2ecommands_2eprovidesLeaf_str5), v_t_2414));
      V v_t_2416 = ({ V a_0 = v_t_2411; V a_1 = v_t_2415; V r_ = (g_heff_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2415); r_; });
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        heff_drop(v_k_241);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    case TAG_False: {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprovidesLeaf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprovidesLeaf(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2erunDir_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {46, 104, 101, 102, 102, 47, 114, 117, 110}};
Clo g_heff_2ecommands_2erunDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erunDir_entry, 1, 0};

V g_heff_2ecommands_2erunDir(V v_paths_240) {
top: ;
  V v_st_241 = heff_get(heff_dup(v_paths_240), LBL_style);
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_get(v_paths_240, LBL_root)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ecommands_2erunDir_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = ({ V a_0 = heff_get(heff_dup(v_p_244), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_244), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_246 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_244), LBL_drive), heff_get(v_p_244, LBL_absolute), v_t_245});
  return ({ V a_0 = v_st_241; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); r_; });
}
V g_heff_2ecommands_2erunDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2erunDir(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2erunPath_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2erunPath_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunPath_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 109, 106, 115}};
Clo g_heff_2ecommands_2erunPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erunPath_entry, 2, 0};

V g_heff_2ecommands_2erunPath(V v_paths_240, V v_file_241) {
top: ;
  V v_t_242 = (g_heff_2ecommands_2erunDir(heff_dup(v_paths_240)));
  V v_p_243 = ({ V b_0 = heff_get(heff_dup(v_paths_240), LBL_style); V a_1 = v_file_241; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_244 = ({ V a_0 = heff_get(heff_dup(v_p_243), LBL_absolute); V b_1 = heff_get(v_p_243, LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecommands_2erunPath_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ecommands_2erunPath_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  return (g_heff_2eload_2eunder(v_paths_240, v_t_242, heff_strAppend(v_t_247, ((V)&g_heff_2ecommands_2erunPath_str2))));
}
V g_heff_2ecommands_2erunPath_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2erunPath(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeafC_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeafC_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeafC_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeafC_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeafC_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2ecommands_2eprovidesLeafC_str5 = {{0x80000000u, K_STR, 0}, 23, 23, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 114, 111, 118, 105, 100, 101, 114, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2ecommands_2eprovidesLeafC_str6 = {{0x80000000u, K_STR, 0}, 23, 23, {115, 116, 97, 116, 105, 99, 32, 86, 32, 104, 101, 102, 102, 95, 112, 114, 111, 118, 105, 100, 101, 114, 95}};
Clo g_heff_2ecommands_2eprovidesLeafC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprovidesLeafC_entry, 2, 0};

V g_heff_2ecommands_2eprovidesLeafC(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeafC_str0), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x2_245 = (g_heff_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ecommands_2eprovidesLeafC_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ecommands_2eprovidesLeafC_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_strEq(heff_get(heff_dup(v_p_242), LBL_module), v_t_248);
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V v_t_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeafC_str3), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeafC_str4), heff_get(heff_dup(v_p_242), LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2413 = (g_prelude_2emap_24s1248084495x1713083677(MK_INT(0LL), ((V)&g_heff_2ecommands_2eprovidesLeafC_str5), ((V)&g_heff_2ecommands_2eprovidesLeafC_str6), MK_INT(23LL), MK_INT(23LL), v_t_2412));
      V v_t_2414 = (g_heff_2eemitc_2ecatMaybesC(v_t_2413));
      V v_t_2415 = ({ V a_0 = v_t_2411; V a_1 = v_t_2414; V r_ = (g_heff_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2414); r_; });
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop(v_k_241);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    case TAG_False: {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprovidesLeafC_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprovidesLeafC(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildTarget_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildTarget_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildTarget_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 114, 111, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildTarget_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {45, 79, 49}};
Clo g_heff_2ecommands_2ebuildTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildTarget_entry, 2, 0};

V g_heff_2ecommands_2ebuildTarget(V v_st_240, V v_root_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildTarget_str0)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildTarget_str1)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = ({ V a_0 = heff_get(heff_dup(v_p_244), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_244), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_246 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_244), LBL_drive), heff_get(v_p_244, LBL_absolute), v_t_245});
  V v_b_247 = (g_std_2epath_2erender(v_st_240, v_t_246));
  V v_t_248 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_root_241)));
  V v_t_249 = (g_std_2epath_2eparse(v_st_240, v_b_247));
  V v_p_2410 = (g_std_2epath_2ejoin_2eonto_240(v_t_248, v_t_249));
  V v_t_2411 = ({ V a_0 = heff_get(heff_dup(v_p_2410), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2410), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2412 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2410), LBL_drive), heff_get(v_p_2410, LBL_absolute), v_t_2411});
  V v_t_2413 = (g_std_2epath_2erender(v_st_240, v_t_2412));
  return heff_rec(6, shape_root__bin__said__pages__shipTo__opt, (V[]){v_root_241, v_t_2413, ((V)&g_heff_2ecommands_2ebuildTarget_str2), NTAG(TAG_True), NTAG(TAG_Nothing), ((V)&g_heff_2ecommands_2ebuildTarget_str3)});
}
V g_heff_2ecommands_2ebuildTarget_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ebuildTarget(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eappFile_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
Clo g_heff_2ecommands_2eappFile_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eappFile_entry, 4, 0};

V g_heff_2ecommands_2eappFile(V v_st_240, V v_t_241, V v_x_242, V v_f_243) {
top: ;
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2eappFile_str0)));
  V v_t_245 = (g_std_2epath_2eparse(v_st_240, v_x_242));
  V v_p_246 = (g_std_2epath_2ejoin_2eonto_240(v_t_244, v_t_245));
  V v_t_247 = ({ V a_0 = heff_get(heff_dup(v_p_246), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_246), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_248 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_246), LBL_drive), heff_get(v_p_246, LBL_absolute), v_t_247});
  V v_a_249 = (g_std_2epath_2erender(v_st_240, v_t_248));
  V v_t_2410 = (g_std_2epath_2eparse(v_st_240, v_a_249));
  V v_t_2411 = (g_std_2epath_2eparse(v_st_240, v_f_243));
  V v_p_2412 = (g_std_2epath_2ejoin_2eonto_240(v_t_2410, v_t_2411));
  V v_t_2413 = ({ V a_0 = heff_get(heff_dup(v_p_2412), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2412), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2414 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2412), LBL_drive), heff_get(v_p_2412, LBL_absolute), v_t_2413});
  V v_p_2415 = (g_std_2epath_2erender(v_st_240, v_t_2414));
  V v_t_2416 = (g_std_2epath_2eparse(v_st_240, heff_get(v_t_241, LBL_root)));
  V v_t_2417 = (g_std_2epath_2eparse(v_st_240, v_p_2415));
  V v_p_2418 = (g_std_2epath_2ejoin_2eonto_240(v_t_2416, v_t_2417));
  V v_t_2419 = ({ V a_0 = heff_get(heff_dup(v_p_2418), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2418), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2420 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2418), LBL_drive), heff_get(v_p_2418, LBL_absolute), v_t_2419});
  return (g_std_2epath_2erender(v_st_240, v_t_2420));
}
V g_heff_2ecommands_2eappFile_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eappFile(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2epartsDir_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2epartsDir_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
Clo g_heff_2ecommands_2epartsDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epartsDir_entry, 3, 0};

V g_heff_2ecommands_2epartsDir(V v_st_240, V v_t_241, V v_x_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2epartsDir_str0)));
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2epartsDir_str1)));
  V v_p_245 = (g_std_2epath_2ejoin_2eonto_240(v_t_243, v_t_244));
  V v_t_246 = ({ V a_0 = heff_get(heff_dup(v_p_245), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_245), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_245), LBL_drive), heff_get(v_p_245, LBL_absolute), v_t_246});
  V v_a_248 = (g_std_2epath_2erender(v_st_240, v_t_247));
  V v_t_249 = (g_std_2epath_2eparse(v_st_240, v_a_248));
  V v_t_2410 = (g_std_2epath_2eparse(v_st_240, v_x_242));
  V v_p_2411 = (g_std_2epath_2ejoin_2eonto_240(v_t_249, v_t_2410));
  V v_t_2412 = ({ V a_0 = heff_get(heff_dup(v_p_2411), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2411), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2413 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2411), LBL_drive), heff_get(v_p_2411, LBL_absolute), v_t_2412});
  V v_p_2414 = (g_std_2epath_2erender(v_st_240, v_t_2413));
  V v_t_2415 = (g_std_2epath_2eparse(v_st_240, heff_get(v_t_241, LBL_root)));
  V v_t_2416 = (g_std_2epath_2eparse(v_st_240, v_p_2414));
  V v_p_2417 = (g_std_2epath_2ejoin_2eonto_240(v_t_2415, v_t_2416));
  V v_t_2418 = ({ V a_0 = heff_get(heff_dup(v_p_2417), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2417), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2419 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2417), LBL_drive), heff_get(v_p_2417, LBL_absolute), v_t_2418});
  return (g_std_2epath_2erender(v_st_240, v_t_2419));
}
V g_heff_2ecommands_2epartsDir_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2epartsDir(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efailLine_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efailLine_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efailLine_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efailLine_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 65, 73, 76, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efailLine_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2efailLine_str5 = {{0x80000000u, K_STR, 0}, 12, 12, {10, 32, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2efailLine_str6 = {{0x80000000u, K_STR, 0}, 12, 12, {10, 32, 32, 98, 117, 116, 32, 103, 111, 116, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2efailLine_str7 = {{0x80000000u, K_STR, 0}, 12, 12, {10, 32, 32, 100, 105, 102, 102, 32, 32, 32, 32, 32}};
Clo g_heff_2ecommands_2efailLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efailLine_entry, 3, 0};

V g_heff_2ecommands_2efailLine(V v_f_240, V v_r_241, V v_m_242) {
top: ;
  V v_t_243 = heff_get(heff_dup(v_r_241), LBL_owner);
  V v_t_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_heff_2ecommands_2efailLine_str0);
    break;
  }
  case TAG_Just: {
    V v_n_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    v_t_245 = heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str1), heff_strAppend(v_n_244, ((V)&g_heff_2ecommands_2efailLine_str2)));
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_246 = heff_get(heff_get(v_r_241, LBL_watch), LBL_expr);
  return heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str3), heff_strAppend(v_f_240, heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str4), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str5), heff_strAppend(heff_get(heff_dup(v_m_242), LBL_expected), heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str6), heff_strAppend(heff_get(heff_dup(v_m_242), LBL_got), heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str7), heff_get(v_m_242, LBL_diff)))))))))));
}
V g_heff_2ecommands_2efailLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2efailLine(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2estatistic_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2estatistic_str1 = {{0x80000000u, K_STR, 0}, 12, 12, {32, 103, 105, 118, 101, 110, 32, 117, 112, 32, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2estatistic_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2estatistic_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {37}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2estatistic_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2estatistic_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2estatistic_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2estatistic_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2estatistic_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 114, 117, 110, 115}};
V g_heff_2ecommands_2estatistic_lam0(V self, V *args);
Clo g_heff_2ecommands_2estatistic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2estatistic_entry, 1, 0};

V g_heff_2ecommands_2estatistic(V v_o_240) {
top: ;
  V v_t_241 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_runs));
  V v_t_242 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_o_240), LBL_discarded));
  V v_t_244;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_discarded));
    v_t_244 = heff_strAppend(((V)&g_heff_2ecommands_2estatistic_str0), heff_strAppend(v_t_243, ((V)&g_heff_2ecommands_2estatistic_str1)));
    break;
  }
  case TAG_False: {
    v_t_244 = ((V)&g_heff_2ecommands_2estatistic_str2);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_x2_2416 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2estatistic_lam0, 1, 1, (V[]){heff_dup(v_o_240)}), heff_get(v_o_240, LBL_labels)));
  V v_t_2419;
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nil: {
    v_t_2419 = ((V)&g_heff_2ecommands_2estatistic_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_xs_2418 = heff_field(v_x2_2416, 1);
    heff_take_n(v_x2_2416, 3ULL, 2);
    v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecommands_2estatistic_str7); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2416);
  }
  return heff_strAppend(v_t_241, heff_strAppend(((V)&g_heff_2ecommands_2estatistic_str8), heff_strAppend(v_t_244, v_t_2419)));
}
V g_heff_2ecommands_2estatistic_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2estatistic(a[0]);
}
V g_heff_2ecommands_2estatistic_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_o_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_n_248;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_y_247 = heff_dup(heff_field(v_p_245, 1));
    v_n_248 = v_y_247;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_total_249 = heff_get(v_o_240, LBL_runs);
  V v_t_2410 = heff_intEq(heff_dup(v_total_249), MK_INT(0LL));
  V v_t_2411;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_n_248);
    heff_drop(v_total_249);
    v_t_2411 = MK_INT(0LL);
    break;
  }
  case TAG_False: {
    v_t_2411 = heff_intDiv(heff_intMul(v_n_248, MK_INT(100LL)), v_total_249);
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_t_2412 = heff_strAppend(heff_intShow(v_t_2411), ((V)&g_heff_2ecommands_2estatistic_str3));
  V v_t_2415;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_p_245, 0);
    heff_take_n(v_p_245, 1ULL, 2);
    v_t_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  return heff_strAppend(((V)&g_heff_2ecommands_2estatistic_str4), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ecommands_2estatistic_str5), v_t_2415)));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eoutcomeLine_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 111, 107, 32, 32, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eoutcomeLine_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eoutcomeLine_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eoutcomeLine_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eoutcomeLine_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2eoutcomeLine_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2eoutcomeLine_str6 = {{0x80000000u, K_STR, 0}, 12, 12, {32, 103, 105, 118, 101, 110, 32, 117, 112, 32, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eoutcomeLine_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eoutcomeLine_str8 = {{0x80000000u, K_STR, 0}, 10, 10, {110, 111, 116, 32, 115, 104, 114, 117, 110, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2eoutcomeLine_str9 = {{0x80000000u, K_STR, 0}, 11, 11, {115, 104, 114, 117, 110, 107, 32, 111, 110, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2eoutcomeLine_str10 = {{0x80000000u, K_STR, 0}, 7, 7, {115, 104, 114, 117, 110, 107, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2eoutcomeLine_str11 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 116, 105, 109, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2eoutcomeLine_str12 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 32, 40, 102, 97, 105, 108, 101, 100, 32, 97, 102, 116, 101, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eoutcomeLine_str13 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 114, 117, 110, 115, 32, 104, 101, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2eoutcomeLine_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {59, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2eoutcomeLine_str15 = {{0x80000000u, K_STR, 0}, 16, 16, {59, 32, 97, 103, 97, 105, 110, 58, 32, 45, 45, 115, 101, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eoutcomeLine_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2ecommands_2eoutcomeLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eoutcomeLine_entry, 1, 0};

V g_heff_2ecommands_2eoutcomeLine(V v_o_240) {
top: ;
  V v_t_241 = heff_get(heff_dup(v_o_240), LBL_ok);
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    v_t_242 = ((V)&g_heff_2ecommands_2eoutcomeLine_str0);
    break;
  }
  case TAG_False: {
    v_t_242 = ((V)&g_heff_2ecommands_2eoutcomeLine_str1);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_243 = heff_get(heff_dup(v_o_240), LBL_property);
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_244 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_244 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_2416;
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    v_t_2416 = ((V)&g_heff_2ecommands_2eoutcomeLine_str2);
    break;
  }
  case TAG_False: {
    V v_t_245 = heff_get(heff_dup(v_o_240), LBL_ok);
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = (g_heff_2ecommands_2estatistic(heff_dup(v_o_240)));
      v_t_2416 = heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str3), heff_strAppend(v_t_246, ((V)&g_heff_2ecommands_2eoutcomeLine_str4)));
      break;
    }
    case TAG_False: {
      V v_t_247 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_runs));
      V v_t_248 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_o_240), LBL_discarded));
      V v_t_2410;
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        V v_t_249 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_discarded));
        v_t_2410 = heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str5), heff_strAppend(v_t_249, ((V)&g_heff_2ecommands_2eoutcomeLine_str6)));
        break;
      }
      case TAG_False: {
        v_t_2410 = ((V)&g_heff_2ecommands_2eoutcomeLine_str7);
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V v_n_2411 = heff_get(heff_dup(v_o_240), LBL_shrinks);
      V v_t_2412 = heff_intEq(heff_dup(v_n_2411), MK_INT(0LL));
      V v_t_2414;
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_n_2411);
        v_t_2414 = ((V)&g_heff_2ecommands_2eoutcomeLine_str8);
        break;
      }
      case TAG_False: {
        V v_t_2413 = heff_intEq(heff_dup(v_n_2411), MK_INT(1LL));
        switch (heff_tag_of(v_t_2413)) {
        case TAG_True: {
          heff_drop(v_n_2411);
          v_t_2414 = ((V)&g_heff_2ecommands_2eoutcomeLine_str9);
          break;
        }
        case TAG_False: {
          v_t_2414 = heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str10), heff_strAppend(heff_intShow(v_n_2411), ((V)&g_heff_2ecommands_2eoutcomeLine_str11)));
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      V v_t_2415 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_seed));
      v_t_2416 = heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str12), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str13), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str14), heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str15), heff_strAppend(v_t_2415, ((V)&g_heff_2ecommands_2eoutcomeLine_str16)))))))));
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  return heff_strAppend(v_t_242, heff_strAppend(heff_get(v_o_240, LBL_name), v_t_2416));
}
V g_heff_2ecommands_2eoutcomeLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eoutcomeLine(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2efailLines_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 32, 32, 32, 32, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2efailLines_str1 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 32, 32, 32, 32, 32, 32, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2efailLines_str2 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 32, 32, 32, 32, 32, 32, 32, 98, 117, 116, 32, 103, 111, 116, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2efailLines_str3 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 32, 32, 32, 32, 32, 32, 32, 100, 105, 102, 102, 32, 32, 32, 32, 32}};
Clo g_heff_2ecommands_2efailLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efailLines_entry, 2, 0};

V g_heff_2ecommands_2efailLines(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_FailBecause: {
    V v_why_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2efailLines_str0), v_why_242), NTAG(TAG_Nil)});
  }
  case TAG_FailDiffer: {
    V v_expected_243 = heff_field(v_x2_241, 0);
    V v_got_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24FailDiffer = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_245 = (g_heff_2ereport_2emismatch(v_color_240, v_expected_243, v_got_244));
    V v_t_246 = heff_strAppend(((V)&g_heff_2ecommands_2efailLines_str1), heff_get(heff_dup(v_m_245), LBL_expected));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ecommands_2efailLines_str2), heff_get(heff_dup(v_m_245), LBL_got));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecommands_2efailLines_str3), heff_get(v_m_245, LBL_diff));
    V v_t_249 = heff_tag_at(v_ru_24x2_241_24FailDiffer, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_246, heff_tag(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2efailLines_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2efailLines(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestsSaid_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2etestsSaid_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {44, 32, 116, 101, 115, 116, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestsSaid_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
Clo g_heff_2ecommands_2etestsSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestsSaid_entry, 1, 0};

V g_heff_2ecommands_2etestsSaid(V v_os_240) {
top: ;
  switch (heff_tag_of(v_os_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecommands_2etestsSaid_str0);
  }
  case TAG_Cons: {
    V v_t_243 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_xs_244 = (g_prelude_2efilter_24s1700824619x1565819740(heff_dup(v_os_240)));
    V v_t_245 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_244; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    V v_t_246 = heff_intShow(heff_intSub(v_t_243, v_t_245));
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_os_240; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop_tag(v_os_240, 2); r_; });
    return heff_strAppend(((V)&g_heff_2ecommands_2etestsSaid_str1), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecommands_2etestsSaid_str2), heff_intShow(v_t_247))));
  }
  default: return heff_nomatch(v_os_240);
  }
}
V g_heff_2ecommands_2etestsSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestsSaid(a[0]);
}

static V g_heff_2ecommands_2edefaultSeed_val;
static int g_heff_2ecommands_2edefaultSeed_st;
static V g_heff_2ecommands_2edefaultSeed_init(void) {
  return MK_INT(2026LL);
}
V g_heff_2ecommands_2edefaultSeed_get(void) {
  if (g_heff_2ecommands_2edefaultSeed_st == 2) return g_heff_2ecommands_2edefaultSeed_val;
  if (g_heff_2ecommands_2edefaultSeed_st == 1) heff_fail("defined by itself");
  g_heff_2ecommands_2edefaultSeed_st = 1;
  g_heff_2ecommands_2edefaultSeed_val = heff_tr(g_heff_2ecommands_2edefaultSeed_init());
  g_heff_2ecommands_2edefaultSeed_st = 2;
  return g_heff_2ecommands_2edefaultSeed_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectName_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectName_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectName_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectName_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2ecommands_2eprojectName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprojectName_entry, 3, 0};

V g_heff_2ecommands_2eprojectName(V v_st_240, V v_dir_241, V v_x3_242) {
top: ;
  V v_t_243 = heff_strEq(heff_dup(v_dir_241), ((V)&g_heff_2ecommands_2eprojectName_str0));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      V v_t_244 = (g_std_2epath_2eparse(v_st_240, v_dir_241));
      V v_xs_245 = heff_get(v_t_244, LBL_segments);
      V v_x1_246 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_245));
      V v_x2_249;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nil: {
        v_x2_249 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 2);
        v_x2_249 = heff_tag(TAG_Just, 1, (V[]){v_x_247});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        return ((V)&g_heff_2ecommands_2eprojectName_str1);
      }
      case TAG_Just: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        heff_take_n(v_x2_249, 1ULL, 1);
        return v_x_2410;
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    case TAG_Just: {
      V v_pwd_2411 = heff_field(v_x3_242, 0);
      V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
      heff_drop(v_dir_241);
      V v_t_2412 = (g_std_2epath_2eparse(v_st_240, v_pwd_2411));
      V v_xs_2413 = heff_get(v_t_2412, LBL_segments);
      V v_x1_2414 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2413));
      V v_x2_2417;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        v_x2_2417 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 2);
        v_x2_2417 = heff_tag_at(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_x_2415});
        break;
      }
      default: heff_nomatch(v_x1_2414);
      }
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_Nothing: {
        return ((V)&g_heff_2ecommands_2eprojectName_str2);
      }
      case TAG_Just: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        heff_take_n(v_x2_2417, 1ULL, 1);
        return v_x_2418;
      }
      default: return heff_nomatch(v_x2_2417);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_False: {
    heff_drop(v_x3_242);
    V v_t_2419 = (g_std_2epath_2eparse(v_st_240, v_dir_241));
    V v_xs_2420 = heff_get(v_t_2419, LBL_segments);
    V v_x1_2421 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2420));
    V v_x2_2424;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_Nil: {
      v_x2_2424 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 2);
      v_x2_2424 = heff_tag(TAG_Just, 1, (V[]){v_x_2422});
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nothing: {
      return ((V)&g_heff_2ecommands_2eprojectName_str3);
    }
    case TAG_Just: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      heff_take_n(v_x2_2424, 1ULL, 1);
      return v_x_2425;
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecommands_2eprojectName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprojectName(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2emoduleText_str0 = {{0x80000000u, K_STR, 0}, 18, 18, {45, 45, 32, 96, 104, 101, 102, 102, 32, 116, 101, 115, 116, 32, 115, 114, 99, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2emoduleText_str1 = {{0x80000000u, K_STR, 0}, 14, 14, {47, 103, 114, 101, 101, 116, 105, 110, 103, 46, 104, 102, 96, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2emoduleText_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2emoduleText_str3 = {{0x80000000u, K_STR, 0}, 22, 22, {45, 45, 32, 62, 62, 62, 32, 103, 114, 101, 101, 116, 105, 110, 103, 32, 34, 104, 101, 102, 102, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2emoduleText_str4 = {{0x80000000u, K_STR, 0}, 17, 17, {45, 45, 32, 34, 72, 101, 108, 108, 111, 44, 32, 104, 101, 102, 102, 33, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[40]; } g_heff_2ecommands_2emoduleText_str5 = {{0x80000000u, K_STR, 0}, 40, 40, {103, 114, 101, 101, 116, 105, 110, 103, 32, 110, 97, 109, 101, 32, 61, 32, 34, 72, 101, 108, 108, 111, 44, 32, 34, 32, 43, 43, 32, 110, 97, 109, 101, 32, 43, 43, 32, 34, 33, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2emoduleText_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2emoduleText_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2emoduleText_str8 = {{0x80000000u, K_STR, 0}, 27, 27, {103, 114, 101, 101, 116, 105, 110, 103, 32, 58, 32, 83, 116, 114, 105, 110, 103, 32, 45, 62, 32, 83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2emoduleText_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2emoduleText_str10 = {{0x80000000u, K_STR, 0}, 14, 14, {105, 109, 112, 111, 114, 116, 32, 112, 114, 101, 108, 117, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2ecommands_2emoduleText_str11 = {{0x80000000u, K_STR, 0}, 57, 57, {45, 45, 32, 99, 104, 101, 99, 107, 115, 32, 116, 104, 101, 109, 32, 97, 108, 108, 44, 32, 97, 110, 100, 32, 116, 104, 105, 115, 32, 111, 110, 101, 39, 115, 32, 119, 97, 116, 99, 104, 101, 115, 32, 97, 114, 101, 32, 99, 104, 101, 99, 107, 101, 100, 32, 98, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2emoduleText_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[66]; } g_heff_2ecommands_2emoduleText_str13 = {{0x80000000u, K_STR, 0}, 66, 66, {45, 45, 32, 65, 32, 109, 111, 100, 117, 108, 101, 32, 111, 102, 32, 116, 104, 101, 32, 112, 97, 99, 107, 97, 103, 101, 44, 32, 97, 115, 32, 101, 118, 101, 114, 121, 32, 102, 105, 108, 101, 32, 111, 102, 32, 115, 114, 99, 47, 32, 105, 115, 58, 32, 96, 104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 96}};
Clo g_heff_2ecommands_2emoduleText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emoduleText_entry, 1, 0};

V g_heff_2ecommands_2emoduleText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ecommands_2emoduleText_str0), heff_strAppend(v_name_240, ((V)&g_heff_2ecommands_2emoduleText_str1)));
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str2), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str4), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str6), v_t_243})});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str8), v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str10), v_t_245})});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str11), heff_tag(TAG_Cons, 2, (V[]){v_t_241, v_t_246})});
  return ({ V a_0 = ((V)&g_heff_2ecommands_2emoduleText_str12); V a_1 = ((V)&g_heff_2ecommands_2emoduleText_str13); V a_2 = v_t_247; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop_tag(v_t_247, 2); r_; });
}
V g_heff_2ecommands_2emoduleText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2emoduleText(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2eprogramText_str0 = {{0x80000000u, K_STR, 0}, 15, 15, {45, 45, 32, 84, 104, 101, 32, 112, 114, 111, 103, 114, 97, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2ecommands_2eprogramText_str1 = {{0x80000000u, K_STR, 0}, 42, 42, {58, 32, 96, 104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 96, 32, 98, 117, 105, 108, 100, 115, 32, 105, 116, 32, 116, 111, 32, 46, 104, 101, 102, 102, 47, 98, 105, 110, 47, 44, 32, 97, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2eprogramText_str2 = {{0x80000000u, K_STR, 0}, 37, 37, {45, 45, 32, 119, 105, 116, 104, 111, 117, 116, 32, 97, 32, 98, 117, 105, 108, 100, 44, 32, 98, 121, 32, 96, 104, 101, 102, 102, 32, 114, 117, 110, 32, 97, 112, 112, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eprogramText_str3 = {{0x80000000u, K_STR, 0}, 10, 10, {47, 109, 97, 105, 110, 46, 104, 102, 96, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2eprogramText_str4 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 109, 112, 111, 114, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2eprogramText_str5 = {{0x80000000u, K_STR, 0}, 9, 9, {46, 103, 114, 101, 101, 116, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprogramText_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecommands_2eprogramText_str7 = {{0x80000000u, K_STR, 0}, 20, 20, {109, 97, 105, 110, 32, 58, 32, 67, 111, 32, 115, 116, 100, 105, 111, 32, 85, 110, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[33]; } g_heff_2ecommands_2eprogramText_str8 = {{0x80000000u, K_STR, 0}, 33, 33, {109, 97, 105, 110, 32, 61, 32, 112, 114, 111, 103, 114, 97, 109, 32, 40, 105, 111, 32, 58, 61, 32, 104, 101, 114, 101, 32, 115, 116, 100, 105, 111, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2ecommands_2eprogramText_str9 = {{0x80000000u, K_STR, 0}, 34, 34, {112, 114, 111, 103, 114, 97, 109, 32, 61, 32, 112, 114, 105, 110, 116, 32, 40, 103, 114, 101, 101, 116, 105, 110, 103, 32, 34, 119, 111, 114, 108, 100, 34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprogramText_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprogramText_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[50]; } g_heff_2ecommands_2eprogramText_str12 = {{0x80000000u, K_STR, 0}, 50, 50, {112, 114, 111, 103, 114, 97, 109, 32, 58, 32, 123, 123, 105, 111, 32, 58, 32, 115, 116, 100, 105, 111, 32, 60, 58, 32, 115, 116, 100, 105, 111, 125, 125, 32, 45, 62, 32, 67, 111, 32, 115, 116, 100, 105, 111, 32, 85, 110, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2eprogramText_str13 = {{0x80000000u, K_STR, 0}, 14, 14, {105, 109, 112, 111, 114, 116, 32, 112, 114, 101, 108, 117, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2eprogramText_str14 = {{0x80000000u, K_STR, 0}, 13, 13, {105, 109, 112, 111, 114, 116, 32, 115, 116, 100, 46, 105, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2eprogramText_str15 = {{0x80000000u, K_STR, 0}, 9, 9, {105, 109, 112, 111, 114, 116, 32, 99, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprogramText_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprogramText_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[71]; } g_heff_2ecommands_2eprogramText_str18 = {{0x80000000u, K_STR, 0}, 71, 71, {45, 45, 32, 98, 117, 105, 108, 100, 46, 104, 102, 32, 115, 97, 121, 115, 44, 32, 97, 110, 100, 32, 96, 104, 101, 102, 102, 32, 105, 110, 115, 116, 97, 108, 108, 96, 32, 105, 110, 116, 111, 32, 126, 47, 46, 104, 101, 102, 102, 47, 98, 105, 110, 47, 59, 32, 114, 117, 110, 32, 111, 110, 32, 78, 111, 100, 101, 46, 106, 115, 44}};
Clo g_heff_2ecommands_2eprogramText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprogramText_entry, 1, 0};

V g_heff_2ecommands_2eprogramText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ecommands_2eprogramText_str0), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ecommands_2eprogramText_str1)));
  V v_t_242 = heff_strAppend(((V)&g_heff_2ecommands_2eprogramText_str2), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ecommands_2eprogramText_str3)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ecommands_2eprogramText_str4), heff_strAppend(v_name_240, ((V)&g_heff_2ecommands_2eprogramText_str5)));
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str6), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str8), v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str10), v_t_245})});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str11), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str12), v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str13), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str14), v_t_247})});
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str15), heff_tag(TAG_Cons, 2, (V[]){v_t_243, v_t_248})});
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_242, heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str16), v_t_249})});
  return ({ V a_0 = ((V)&g_heff_2ecommands_2eprogramText_str17); V a_1 = v_t_241; V b_2 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str18), v_t_2410}); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ecommands_2eprogramText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eprogramText(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildText_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2ebuildText_str1 = {{0x80000000u, K_STR, 0}, 13, 13, {98, 117, 105, 108, 100, 32, 58, 32, 66, 117, 105, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2ebuildText_str2 = {{0x80000000u, K_STR, 0}, 37, 37, {98, 117, 105, 108, 100, 32, 61, 32, 123, 32, 98, 97, 99, 107, 101, 110, 100, 32, 61, 32, 67, 44, 32, 114, 117, 110, 32, 61, 32, 34, 109, 97, 105, 110, 34, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2ebuildText_str3 = {{0x80000000u, K_STR, 0}, 15, 15, {105, 109, 112, 111, 114, 116, 32, 109, 97, 110, 105, 102, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildText_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2ecommands_2ebuildText_str5 = {{0x80000000u, K_STR, 0}, 21, 21, {45, 45, 32, 104, 101, 102, 102, 32, 104, 111, 109, 101, 32, 119, 105, 116, 104, 32, 105, 116, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildText_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[71]; } g_heff_2ecommands_2ebuildText_str7 = {{0x80000000u, K_STR, 0}, 71, 71, {45, 45, 32, 78, 111, 100, 101, 46, 106, 115, 32, 112, 114, 111, 103, 114, 97, 109, 32, 111, 102, 32, 105, 116, 46, 32, 32, 65, 32, 102, 105, 101, 108, 100, 32, 96, 115, 104, 105, 112, 115, 32, 61, 32, 91, 46, 46, 46, 93, 96, 32, 119, 111, 117, 108, 100, 32, 110, 97, 109, 101, 32, 102, 105, 108, 101, 115, 32, 97, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[69]; } g_heff_2ecommands_2ebuildText_str8 = {{0x80000000u, K_STR, 0}, 69, 69, {45, 45, 32, 100, 105, 114, 101, 99, 116, 111, 114, 105, 101, 115, 32, 111, 102, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116, 32, 102, 111, 114, 32, 96, 104, 101, 102, 102, 32, 105, 110, 115, 116, 97, 108, 108, 96, 32, 116, 111, 32, 112, 117, 116, 32, 105, 110, 32, 116, 104, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildText_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[69]; } g_heff_2ecommands_2ebuildText_str10 = {{0x80000000u, K_STR, 0}, 69, 69, {45, 45, 32, 109, 97, 105, 110, 46, 104, 102, 39, 115, 32, 96, 109, 97, 105, 110, 96, 44, 32, 99, 111, 109, 112, 105, 108, 101, 100, 32, 116, 104, 114, 111, 117, 103, 104, 32, 67, 32, 40, 98, 121, 32, 96, 122, 105, 103, 32, 99, 99, 96, 41, 59, 32, 96, 78, 111, 100, 101, 96, 32, 109, 97, 107, 101, 115, 32, 97}};

static V g_heff_2ecommands_2ebuildText_val;
static int g_heff_2ecommands_2ebuildText_st;
static V g_heff_2ecommands_2ebuildText_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str2), v_t_240})});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str4), v_t_241})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str6), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ecommands_2ebuildText_str9); V a_1 = ((V)&g_heff_2ecommands_2ebuildText_str10); V a_2 = v_t_244; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ecommands_2ebuildText_get(void) {
  if (g_heff_2ecommands_2ebuildText_st == 2) return g_heff_2ecommands_2ebuildText_val;
  if (g_heff_2ecommands_2ebuildText_st == 1) heff_fail("defined by itself");
  g_heff_2ecommands_2ebuildText_st = 1;
  g_heff_2ecommands_2ebuildText_val = heff_tr(g_heff_2ecommands_2ebuildText_init());
  g_heff_2ecommands_2ebuildText_st = 2;
  return g_heff_2ecommands_2ebuildText_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2etestText_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 109, 112, 111, 114, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2etestText_str1 = {{0x80000000u, K_STR, 0}, 9, 9, {46, 103, 114, 101, 101, 116, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestText_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2etestText_str3 = {{0x80000000u, K_STR, 0}, 8, 8, {103, 114, 101, 101, 116, 115, 32, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[69]; } g_heff_2ecommands_2etestText_str4 = {{0x80000000u, K_STR, 0}, 69, 69, {32, 32, 117, 110, 105, 116, 32, 34, 103, 114, 101, 101, 116, 105, 110, 103, 34, 32, 40, 101, 113, 117, 97, 108, 32, 115, 104, 111, 119, 83, 116, 114, 105, 110, 103, 32, 40, 103, 114, 101, 101, 116, 105, 110, 103, 32, 34, 116, 101, 115, 116, 34, 41, 32, 34, 72, 101, 108, 108, 111, 44, 32, 116, 101, 115, 116, 33, 34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestText_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2etestText_str6 = {{0x80000000u, K_STR, 0}, 13, 13, {103, 114, 101, 101, 116, 115, 32, 58, 32, 84, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2etestText_str7 = {{0x80000000u, K_STR, 0}, 14, 14, {105, 109, 112, 111, 114, 116, 32, 112, 114, 101, 108, 117, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestText_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2etestText_str9 = {{0x80000000u, K_STR, 0}, 12, 12, {105, 109, 112, 111, 114, 116, 32, 99, 104, 101, 99, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestText_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[69]; } g_heff_2ecommands_2etestText_str11 = {{0x80000000u, K_STR, 0}, 69, 69, {45, 45, 32, 96, 104, 101, 102, 102, 32, 116, 101, 115, 116, 96, 32, 114, 117, 110, 115, 32, 116, 104, 101, 32, 116, 101, 115, 116, 115, 32, 111, 102, 32, 101, 118, 101, 114, 121, 32, 102, 105, 108, 101, 32, 111, 102, 32, 116, 101, 115, 116, 47, 58, 32, 116, 104, 101, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[52]; } g_heff_2ecommands_2etestText_str12 = {{0x80000000u, K_STR, 0}, 52, 52, {45, 45, 32, 111, 102, 32, 116, 121, 112, 101, 32, 96, 84, 101, 115, 116, 96, 32, 40, 108, 105, 98, 47, 99, 104, 101, 99, 107, 46, 104, 102, 41, 44, 32, 97, 102, 116, 101, 114, 32, 116, 104, 101, 32, 119, 97, 116, 99, 104, 101, 115, 46}};
Clo g_heff_2ecommands_2etestText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestText_entry, 1, 0};

V g_heff_2ecommands_2etestText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ecommands_2etestText_str0), heff_strAppend(v_name_240, ((V)&g_heff_2ecommands_2etestText_str1)));
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str2), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str4), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str6), v_t_243})});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){v_t_241, heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str7), v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str8), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str9), v_t_245})});
  return ({ V a_0 = ((V)&g_heff_2ecommands_2etestText_str10); V a_1 = ((V)&g_heff_2ecommands_2etestText_str11); V b_2 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str12), v_t_246}); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ecommands_2etestText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestText(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2eprojectFiles_str0 = {{0x80000000u, K_STR, 0}, 22, 22, {112, 97, 99, 107, 97, 103, 101, 32, 61, 32, 123, 32, 109, 111, 100, 117, 108, 101, 32, 61, 32, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2eprojectFiles_str1 = {{0x80000000u, K_STR, 0}, 11, 11, {34, 44, 32, 104, 101, 102, 102, 32, 61, 32, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eprojectFiles_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {34, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2eprojectFiles_str4 = {{0x80000000u, K_STR, 0}, 17, 17, {112, 97, 99, 107, 97, 103, 101, 32, 58, 32, 80, 97, 99, 107, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eprojectFiles_str5 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2eprojectFiles_str7 = {{0x80000000u, K_STR, 0}, 15, 15, {105, 109, 112, 111, 114, 116, 32, 109, 97, 110, 105, 102, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eprojectFiles_str10 = {{0x80000000u, K_STR, 0}, 10, 10, {46, 103, 105, 116, 105, 103, 110, 111, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2eprojectFiles_str12 = {{0x80000000u, K_STR, 0}, 6, 6, {46, 104, 101, 102, 102, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eprojectFiles_str13 = {{0x80000000u, K_STR, 0}, 4, 4, {115, 114, 99, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2eprojectFiles_str14 = {{0x80000000u, K_STR, 0}, 12, 12, {47, 103, 114, 101, 101, 116, 105, 110, 103, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eprojectFiles_str15 = {{0x80000000u, K_STR, 0}, 4, 4, {97, 112, 112, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eprojectFiles_str16 = {{0x80000000u, K_STR, 0}, 8, 8, {47, 109, 97, 105, 110, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eprojectFiles_str17 = {{0x80000000u, K_STR, 0}, 4, 4, {97, 112, 112, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2eprojectFiles_str18 = {{0x80000000u, K_STR, 0}, 9, 9, {47, 98, 117, 105, 108, 100, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2eprojectFiles_str19 = {{0x80000000u, K_STR, 0}, 16, 16, {116, 101, 115, 116, 47, 103, 114, 101, 101, 116, 105, 110, 103, 46, 104, 102}};
Clo g_heff_2ecommands_2eprojectFiles_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprojectFiles_entry, 2, 0};

V g_heff_2ecommands_2eprojectFiles(V v_name_240, V v_v_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str0), heff_strAppend(heff_dup(v_name_240), heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str1), heff_strAppend(v_v_241, ((V)&g_heff_2ecommands_2eprojectFiles_str2)))));
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str3), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str4), heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_243})});
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str5), ({ V a_0 = ((V)&g_heff_2ecommands_2eprojectFiles_str6); V a_1 = ((V)&g_heff_2ecommands_2eprojectFiles_str7); V b_2 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str8), v_t_244}); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; })});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str9), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str10), ({ V a_0 = ((V)&g_heff_2ecommands_2eprojectFiles_str11); V a_1 = ((V)&g_heff_2ecommands_2eprojectFiles_str12); V a_2 = v_t_246; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop_tag(v_t_246, 2); r_; })});
  V v_t_248 = heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str13), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ecommands_2eprojectFiles_str14)));
  V v_t_249 = heff_tag(TAG_MkPair, 2, (V[]){v_t_248, (g_heff_2ecommands_2emoduleText(heff_dup(v_name_240)))});
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str15), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ecommands_2eprojectFiles_str16)));
  V v_t_2411 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2410, (g_heff_2ecommands_2eprogramText(heff_dup(v_name_240)))});
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str17), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ecommands_2eprojectFiles_str18)));
  V v_t_2413 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str19), (g_heff_2ecommands_2etestText(v_name_240))});
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_2412, heff_dup(g_heff_2ecommands_2ebuildText_get())}), v_t_2414});
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, heff_tag(TAG_Cons, 2, (V[]){v_t_2411, v_t_2415})});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_245, heff_tag(TAG_Cons, 2, (V[]){v_t_247, v_t_2416})});
}
V g_heff_2ecommands_2eprojectFiles_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eprojectFiles(a[0], a[1]);
}
V g_heff_2ecommands_2erequiring_lam0(V self, V *args);
V g_heff_2ecommands_2erequiring_lam1(V self, V *args);
Clo g_heff_2ecommands_2erequiring_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erequiring_entry, 4, 0};

V g_heff_2ecommands_2erequiring(V v_pk_240, V v_name_241, V v_path_242, V v_v_243) {
top: ;
  V v_t_245 = ({ V a_0 = heff_clo(g_heff_2ecommands_2erequiring_lam0, 1, 1, (V[]){heff_dup(v_path_242)}); V b_1 = heff_get(heff_dup(v_pk_240), LBL_require); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_249;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_name_241);
    v_t_249 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2erequiring_lam1, 1, 2, (V[]){v_path_242, v_v_243}), heff_get(heff_dup(v_pk_240), LBL_require)));
    break;
  }
  case TAG_False: {
    V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(3, shape_name__path__version, (V[]){v_name_241, v_path_242, v_v_243}), NTAG(TAG_Nil)});
    v_t_249 = (g_prelude_2econcatList(heff_get(heff_dup(v_pk_240), LBL_require), v_t_248));
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_rec(4, shape_module__heff__require__replace, (V[]){heff_get(heff_dup(v_pk_240), LBL_module), heff_get(heff_dup(v_pk_240), LBL_heff), v_t_249, heff_get(v_pk_240, LBL_replace)});
}
V g_heff_2ecommands_2erequiring_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2erequiring(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2erequiring_lam0(V self, V *args) {
  V v_r_244 = args[0];
  V v_path_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_r_244, LBL_path), v_path_242);
}
V g_heff_2ecommands_2erequiring_lam1(V self, V *args) {
  V v_r_246 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_v_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_strEq(heff_get(heff_dup(v_r_246), LBL_path), heff_dup(v_path_242));
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    return heff_rec(3, shape_name__path__version, (V[]){heff_get(v_r_246, LBL_name), v_path_242, v_v_243});
  }
  case TAG_False: {
    heff_drop(v_path_242);
    heff_drop(v_v_243);
    return v_r_246;
  }
  default: return heff_nomatch(v_t_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2elibDir_24s652053211x1514718967_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {72, 69, 70, 70, 95, 76, 73, 66}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2elibDir_24s652053211x1514718967_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2elibDir_24s652053211x1514718967_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 105, 98}};
V g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam0(V self, V *args); static Clo g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam0, 1, 0};
V g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam2(V self, V *args); static Clo g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam2, 1, 0};
V g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam4(V self, V *args); static Clo g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam4, 1, 0};
V g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam5(V self, V *args);
V g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam3(V self, V *args);
V g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam1(V self, V *args);
Clo g_heff_2ecommands_2elibDir_24s652053211x1514718967_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2elibDir_24s652053211x1514718967_entry, 2, 0};

V g_heff_2ecommands_2elibDir_24s652053211x1514718967(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2elibDir_24s652053211x1514718967_str0), ((V)&g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_245})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2elibDir_24s652053211x1514718967_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2elibDir_24s652053211x1514718967(a[0], a[1]);
}
V g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam2(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam4(V self, V *args) {
  V v_s_2416 = args[0];
  return v_s_2416;
}
V g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2422 = (g_heff_2ecommands_2eownRoot(v_x_2415, v_x_2421));
  V v_t_2423 = (g_std_2epath_2eparse(v_x_2415, v_a_2422));
  V v_t_2424 = (g_std_2epath_2eparse(v_x_2415, ((V)&g_heff_2ecommands_2elibDir_24s652053211x1514718967_str2)));
  V v_p_2425 = (g_std_2epath_2ejoin_2eonto_240(v_t_2423, v_t_2424));
  V v_t_2426 = ({ V a_0 = heff_get(heff_dup(v_p_2425), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2425), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2427 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2425), LBL_drive), heff_get(v_p_2425, LBL_absolute), v_t_2426});
  V v_x_2428 = ({ V a_0 = v_x_2415; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2415); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_strEq(v_x_2413, ((V)&g_heff_2ecommands_2elibDir_24s652053211x1514718967_str1));
  V v_x_2415;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    v_x_2415 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2415 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam4_clo)})});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2419})}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2420, heff_clo(g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam5, 1, 2, (V[]){v_x_2415, v_k_241})});
}
V g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam2_clo)})});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})}));
    return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2elibDir_24s652053211x1514718967_lam3, 1, 2, (V[]){v_hd_240, v_k_241})});
  }
  case TAG_Just: {
    V v_lib_2429 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_lib_2429;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {72, 69, 70, 70, 95, 77, 79, 68, 67, 65, 67, 72, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {72, 79, 77, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {85, 83, 69, 82, 80, 82, 79, 70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str5 = {{0x80000000u, K_STR, 0}, 6, 6, {46, 99, 97, 99, 104, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {109, 111, 100}};
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam0(V self, V *args); static Clo g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam0, 1, 0};
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam2(V self, V *args); static Clo g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam2, 1, 0};
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam4(V self, V *args); static Clo g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam4, 1, 0};
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam6(V self, V *args); static Clo g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam6, 1, 0};
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam7(V self, V *args);
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam5(V self, V *args);
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam3(V self, V *args);
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam1(V self, V *args);
Clo g_heff_2ecommands_2emodDir_24s1812307012x1810766942_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emodDir_24s1812307012x1810766942_entry, 2, 0};

V g_heff_2ecommands_2emodDir_24s1812307012x1810766942(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str0), ((V)&g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_245})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2emodDir_24s1812307012x1810766942(a[0], a[1]);
}
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam2(V self, V *args) {
  V v_v_248 = args[0];
  return v_v_248;
}
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam4(V self, V *args) {
  V v_v_2414 = args[0];
  return v_v_2414;
}
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam6(V self, V *args) {
  V v_s_2420 = args[0];
  return v_s_2420;
}
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2426 = heff_strEq(v_x_2425, ((V)&g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str3));
  V v_x_2427;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_True: {
    v_x_2427 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2427 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  V v_x_2450;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_d_2429;
    switch (heff_tag_of(v_x_2419)) {
    case TAG_Nothing: {
      v_d_2429 = ((V)&g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str4);
      break;
    }
    case TAG_Just: {
      V v_x_2428 = heff_field(v_x_2419, 0);
      heff_take_n(v_x_2419, 1ULL, 1);
      v_d_2429 = v_x_2428;
      break;
    }
    default: heff_nomatch(v_x_2419);
    }
    V v_a_2431;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_Nothing: {
      v_a_2431 = v_d_2429;
      break;
    }
    case TAG_Just: {
      V v_x_2430 = heff_field(v_x_2413, 0);
      heff_take_n(v_x_2413, 1ULL, 1);
      heff_drop(v_d_2429);
      v_a_2431 = v_x_2430;
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_t_2432 = (g_std_2epath_2eparse(v_x_2427, v_a_2431));
    V v_t_2433 = (g_std_2epath_2eparse(v_x_2427, ((V)&g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str5)));
    V v_p_2434 = (g_std_2epath_2ejoin_2eonto_240(v_t_2432, v_t_2433));
    V v_t_2435 = ({ V a_0 = heff_get(heff_dup(v_p_2434), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2434), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2436 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2434), LBL_drive), heff_get(v_p_2434, LBL_absolute), v_t_2435});
    V v_a_2437 = (g_std_2epath_2erender(v_x_2427, v_t_2436));
    V v_t_2438 = (g_std_2epath_2eparse(v_x_2427, ((V)&g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str6)));
    V v_t_2439 = (g_std_2epath_2eparse(v_x_2427, ((V)&g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str7)));
    V v_p_2440 = (g_std_2epath_2ejoin_2eonto_240(v_t_2438, v_t_2439));
    V v_t_2441 = ({ V a_0 = heff_get(heff_dup(v_p_2440), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2440), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2442 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2440), LBL_drive), heff_get(v_p_2440, LBL_absolute), v_t_2441});
    V v_b_2443 = (g_std_2epath_2erender(v_x_2427, v_t_2442));
    V v_t_2444 = (g_std_2epath_2eparse(v_x_2427, v_a_2437));
    V v_t_2445 = (g_std_2epath_2eparse(v_x_2427, v_b_2443));
    V v_p_2446 = (g_std_2epath_2ejoin_2eonto_240(v_t_2444, v_t_2445));
    V v_t_2447 = ({ V a_0 = heff_get(heff_dup(v_p_2446), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2446), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2448 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2446), LBL_drive), heff_get(v_p_2446, LBL_absolute), v_t_2447});
    v_x_2450 = ({ V a_0 = v_x_2427; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2427); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2449 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    heff_drop(v_x_2419);
    heff_drop(v_x_2413);
    heff_drop(v_x_2427);
    v_x_2450 = v_d_2449;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V f_ = v_k_241;
  args[0] = v_x_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam6_clo)})});
  V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2423})}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2424, heff_clo(g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam7, 1, 4, (V[]){v_x_247, v_x_2419, v_x_2413, v_k_241})});
}
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str2), ((V)&g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam4_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2417})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2418, heff_clo(g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam5, 1, 4, (V[]){v_hd_240, v_x_247, v_x_2413, v_k_241})});
}
V g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2emodDir_24s1812307012x1810766942_str1), ((V)&g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam2_clo)})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2emodDir_24s1812307012x1810766942_lam3, 1, 3, (V[]){v_hd_240, v_x_247, v_k_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ehostNow_24s95879950x2015218488_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam2(V self, V *args); static Clo g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam2, 1, 0};
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam4(V self, V *args); static Clo g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam4, 1, 0};
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam5(V self, V *args);
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam3(V self, V *args);
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam1(V self, V *args);
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam0(V self, V *args);
Clo g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ehostNow_24s95879950x2015218488_entry, 2, 0};

V g_heff_2ecommands_2ehostNow_24s95879950x2015218488(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2elibDir_24s652053211x1514718967(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ehostNow_24s95879950x2015218488(a[0], a[1]);
}
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam2(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam4(V self, V *args) {
  V v_s_2410 = args[0];
  return v_s_2410;
}
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416 = heff_strEq(v_x_2415, ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_str0));
  V v_x_2417;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    v_x_2417 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2417 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V f_ = v_k_241;
  args[0] = heff_rec(4, shape_lib__mod__cwd__style, (V[]){v_x_242, v_x_243, v_x_249, v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam4_clo)})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2413})}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam5, 1, 4, (V[]){v_k_241, v_x_242, v_x_243, v_x_249})});
}
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WorkingDir, 1, (V[]){((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam2_clo)})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam3, 1, 4, (V[]){v_hd_240, v_k_241, v_x_242, v_x_243})});
}
V g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecommands_2emodDir_24s1812307012x1810766942(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ehostNow_24s95879950x2015218488_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_str1 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
V g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam0(V self, V *args); static Clo g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam0, 1, 0};
V g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam2(V self, V *args); static Clo g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam2, 1, 0};
V g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam3(V self, V *args);
V g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam1(V self, V *args);
Clo g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_entry, 2, 0};

V g_heff_2ecommands_2eownPackage_24s2030161483x1635646466(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_245})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eownPackage_24s2030161483x1635646466(a[0], a[1]);
}
V g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return v_s_242;
}
V g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  return v_s_2410;
}
V g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2416 = (g_heff_2ecommands_2eownRoot(v_x_249, v_x_2415));
  V v_t_2417 = (g_std_2epath_2eparse(v_x_249, v_a_2416));
  V v_t_2418 = (g_std_2epath_2eparse(v_x_249, ((V)&g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_str1)));
  V v_p_2419 = (g_std_2epath_2ejoin_2eonto_240(v_t_2417, v_t_2418));
  V v_t_2420 = ({ V a_0 = heff_get(heff_dup(v_p_2419), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2419), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2421 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2419), LBL_drive), heff_get(v_p_2419, LBL_absolute), v_t_2420});
  V v_x_2422 = ({ V a_0 = v_x_249; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_249); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_strEq(v_x_247, ((V)&g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_str0));
  V v_x_249;
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    v_x_249 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_249 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam2_clo)})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2413})}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecommands_2eownPackage_24s2030161483x1635646466_lam3, 1, 2, (V[]){v_x_249, v_k_241})});
}
V g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_lam1(V self, V *args); static Clo g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_lam1, 1, 0};
V g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_lam2(V self, V *args);
V g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_lam0(V self, V *args);
Clo g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_entry, 2, 0};

V g_heff_2ecommands_2eownVersion_24s1137751716x1393321329(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2eownPackage_24s2030161483x1635646466(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eownVersion_24s1137751716x1393321329(a[0], a[1]);
}
V g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_lam1(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2413;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_x_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_249 = heff_field(v_x_248, 0);
    V v_ru_24x_248_24Just = heff_take_reuse_n(v_x_248, 1ULL, 1);
    V v_t_2410 = (g_heff_2eproject_2ereadPackage(v_src_249));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Left: {
      heff_take_n(v_t_2410, 0ULL, 1);
      heff_drop_cell(v_ru_24x_248_24Just, 1);
      v_x_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2412 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      v_x_2413 = heff_tag_at(v_ru_24x_248_24Just, TAG_Just, 1, (V[]){heff_get(v_p_2412, LBL_heff)});
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V f_ = v_k_241;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_x_242, ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_lam1_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_lam2, 1, 1, (V[]){v_k_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_lam0(V self, V *args);
Clo g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_entry, 5, 0};

V g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(V v_m_240, V v_x2_241, V v_n_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_n_242});
  }
  case TAG_Cons: {
    V v_l_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_dup(v_m_240), heff_strAppend(((V)&g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_str0), v_l_245));
    V v_t_248 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_str1)), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2411}));
    return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_lam0, 1, 5, (V[]){v_m_240, v_rest_246, v_n_242, v_p_243, v_p_244})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2413);
  return (g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(v_m_240, v_rest_246, heff_intAdd(v_n_242, MK_INT(1LL)), v_p_243, v_p_244));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam0(V self, V *args); static Clo g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam0, 1, 0};
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam2(V self, V *args); static Clo g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam2, 2, 0};
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam3(V self, V *args);
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam4(V self, V *args);
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam5(V self, V *args);
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam1(V self, V *args);
Clo g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_entry, 3, 0};

V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ErrColor, 1, (V[]){((V)&g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam0_clo)})});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam1, 1, 4, (V[]){v_c_243, v_p_241, v_rest_244, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam0(V self, V *args) {
  V v_b_245 = args[0];
  return v_b_245;
}
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam3(V self, V *args) {
  V v_d_2416 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_x_249; V a_1 = heff_get(heff_dup(v_c_243), LBL_path); V a_2 = heff_get(v_c_243, LBL_source); V a_3 = v_d_2416; V r_ = (g_heff_2erender_2efileDiag(a_0, a_1, a_2, a_3)); heff_drop(v_x_249); r_; });
}
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam4(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_str_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tag(TAG_WriteErr, 2, (V[]){v_str_2420, NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2421), LBL_malg), 1, (V[]){v_t_2426}));
  V f_ = heff_get(v_hd_2421, LBL_bind);
  args[0] = v_t_2427;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2429);
  return (g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672(v_rest_244, v_p_241, v_p_242));
}
V g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_get(heff_dup(v_c_243), LBL_diags);
  V v_t_2413;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nil: {
    v_t_2413 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2410, 0ULL, 2);
    v_t_2413 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_c_2428;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_True: {
    heff_drop(v_x_249);
    heff_drop(v_c_243);
    v_c_2428 = ((V)&g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam2_clo);
    break;
  }
  case TAG_False: {
    V v_x2_2417 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam3, 1, 2, (V[]){v_x_249, heff_dup(v_c_243)}), heff_get(v_c_243, LBL_diags)));
    V v_str_2420;
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_Nil: {
      v_str_2420 = ((V)&g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_xs_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      v_str_2420 = ({ V a_0 = ((V)&g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_str1); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2417);
    }
    v_c_2428 = heff_clo(g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam4, 2, 1, (V[]){v_str_2420});
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_p_241), heff_clo(g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672_lam5, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242})});
}
V g_heff_2ecommands_2echeckLast_24s411163256x943511502_lam1(V self, V *args);
V g_heff_2ecommands_2echeckLast_24s411163256x943511502_lam2(V self, V *args);
V g_heff_2ecommands_2echeckLast_24s411163256x943511502_lam0(V self, V *args);
Clo g_heff_2ecommands_2echeckLast_24s411163256x943511502_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2echeckLast_24s411163256x943511502_entry, 4, 0};

V g_heff_2ecommands_2echeckLast_24s411163256x943511502(V v_badLoad_240, V v_cs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672(heff_dup(v_cs_241), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2echeckLast_24s411163256x943511502_lam0, 1, 4, (V[]){v_cs_241, v_hd_242, v_k_243, heff_dup(v_badLoad_240)})));
}
V g_heff_2ecommands_2echeckLast_24s411163256x943511502_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2echeckLast_24s411163256x943511502(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2echeckLast_24s411163256x943511502_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_str_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tag(TAG_Write, 2, (V[]){v_str_2412, NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2413, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2echeckLast_24s411163256x943511502_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_badLoad_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2421);
  switch (heff_tag_of(v_badLoad_240)) {
  case TAG_True: {
    heff_drop(v_cs_241);
    V v_t_2422 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2425}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2426, v_k_243});
  }
  case TAG_False: {
    V v_t_2427 = ({ V a_0 = v_cs_241; V r_ = (g_prelude_2eany_24s827288872x1370860167(a_0)); heff_drop(v_cs_241); r_; });
    switch (heff_tag_of(v_t_2427)) {
    case TAG_True: {
      V v_t_2428 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2429 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2428})});
      V v_t_2430 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2431}));
      return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2432, v_k_243});
    }
    case TAG_False: {
      heff_drop(v_hd_242);
      V f_ = v_k_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  default: return heff_nomatch(v_badLoad_240);
  }
}
V g_heff_2ecommands_2echeckLast_24s411163256x943511502_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_badLoad_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_244);
  V v_t_245 = (g_heff_2edriver_2elastChecked(v_cs_241));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_cs_241);
    heff_drop(v_badLoad_240);
    V v_t_246 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2410, v_k_243});
  }
  case TAG_Just: {
    V v_c_2411 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_str_2412 = (g_heff_2edriver_2einterface(v_c_2411));
    V v_c_2420 = heff_clo(g_heff_2ecommands_2echeckLast_24s411163256x943511502_lam1, 2, 1, (V[]){v_str_2412});
    return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2echeckLast_24s411163256x943511502_lam2, 1, 4, (V[]){v_badLoad_240, v_hd_242, v_k_243, v_cs_241})});
  }
  default: return heff_nomatch(v_t_245);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam3(V self, V *args);
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam2(V self, V *args);
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam1(V self, V *args);
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam0(V self, V *args);
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam7(V self, V *args);
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam6(V self, V *args);
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam5(V self, V *args);
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam4(V self, V *args);
Clo g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_entry, 1, 0};

V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015(V v_file_240) {
top: ;
  V v_c_241 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  V v_c_2411 = heff_clo(g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam0, 2, 2, (V[]){v_c_241, v_file_240});
  return heff_clo(g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam4, 2, 1, (V[]){v_c_2411});
}
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2echeckCmd_24s1187483311x70246015(a[0]);
}
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = ({ V a_0 = v_x_248; V a_1 = heff_get(heff_dup(v_x_246), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_248); r_; });
  V v_x_2410 = (g_prelude_2efoldl_24s1838030138x788027388(v_x_246, v_t_249));
  V f_ = v_k_243;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_247 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_247, 2, (V[]){v_hd_242, heff_clo(g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam3, 1, 2, (V[]){v_x_246, v_k_243})});
}
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(v_x_244, v_file_240));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam2, 1, 2, (V[]){v_hd_242, v_k_243})});
}
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo(g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam1, 1, 3, (V[]){v_file_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam7(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V b_0 = heff_intLt(MK_INT(0LL), v_x_2415); V a_1 = v_x_2417; V a_2 = v_hd_2412; V a_3 = v_k_2413; V r_ = (g_heff_2ecommands_2echeckLast_24s411163256x943511502(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam6(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2416 = (g_heff_2esession_2ecachedProgram_24s595918180x507103762(v_x_2414));
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_2412), heff_clo(g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam7, 1, 3, (V[]){v_x_2415, v_hd_2412, v_k_2413})});
}
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(((V)&g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_str0), heff_get(heff_dup(v_x_2414), LBL_errors), MK_INT(0LL), heff_dup(v_hd_2412), heff_clo(g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam6, 1, 3, (V[]){v_x_2414, v_hd_2412, v_k_2413})));
}
V g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam4(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo(g_heff_2ecommands_2echeckCmd_24s1187483311x70246015_lam5, 1, 2, (V[]){v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_str1 = {{0x80000000u, K_STR, 0}, 12, 12, {46, 112, 114, 111, 118, 105, 100, 101, 114, 46, 106, 115}};
V g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam0, 2, 0};
V g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam2(V self, V *args); static Clo g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam2, 1, 0};
V g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam1(V self, V *args);
V g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam4(V self, V *args);
V g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam3(V self, V *args);
Clo g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_entry, 2, 0};

V g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288(V v_sources_240, V v_m_241) {
top: ;
  V v_t_242 = (g_heff_2ecommands_2epathOfModule(v_sources_240, heff_dup(v_m_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    return ((V)&g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam0_clo);
  }
  case TAG_Just: {
    V v_path_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
    V v_t_247 = heff_strSlice(heff_dup(v_path_245), v_t_246, heff_strLength(heff_dup(v_path_245)));
    V v_t_248 = heff_strEq(v_t_247, ((V)&g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_str0));
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
      v_t_2410 = heff_strSlice(v_path_245, MK_INT(0LL), v_t_249);
      break;
    }
    case TAG_False: {
      v_t_2410 = v_path_245;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_path_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_str1));
    V v_c_2419 = heff_clo(g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam1, 2, 1, (V[]){v_path_2411});
    return heff_clo(g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam3, 2, 2, (V[]){v_c_2419, v_m_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_path_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam2_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2417}));
  V f_ = heff_get(v_hd_2412, LBL_bind);
  args[0] = v_t_2418;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2424;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    v_x_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2423 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Just = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    v_x_2424 = heff_tag_at(v_ru_24x_2422_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_module__text, (V[]){v_m_241, v_t_2423})});
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V f_ = v_k_2421;
  args[0] = v_x_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo(g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288_lam4, 1, 2, (V[]){v_m_241, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_lam0, 2, 0};
V g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_lam3(V self, V *args);
V g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_lam2(V self, V *args);
V g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_lam1(V self, V *args);
Clo g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_entry, 2, 0};

V g_heff_2ecommands_2ereadProviders_24s1822069164x530433648(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ecommands_2ereadProviderAt_24s1333819663x148875288(v_sources_240, v_m_244));
    return heff_clo(g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_lam1, 2, 3, (V[]){v_c_246, heff_dup(v_sources_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ereadProviders_24s1822069164x530433648(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_x_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_x_2413 = heff_tag(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = ({ V a_0 = v_sources_240; V a_1 = v_rest_245; V r_ = (g_heff_2ecommands_2ereadProviders_24s1822069164x530433648(a_0, a_1)); heff_drop(v_sources_240); r_; });
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_lam3, 1, 2, (V[]){v_x_249, v_k_248})});
}
V g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2ecommands_2ereadProviders_24s1822069164x530433648_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecommands_2eemitErrs_24s852800528x545365095_str0 = {{0x80000000u, K_STR, 0}, 20, 20, {104, 101, 102, 102, 58, 32, 110, 111, 116, 32, 99, 111, 109, 112, 105, 108, 101, 100, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eemitErrs_24s852800528x545365095_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eemitErrs_24s852800528x545365095_lam0(V self, V *args);
Clo g_heff_2ecommands_2eemitErrs_24s852800528x545365095_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eemitErrs_24s852800528x545365095_entry, 3, 0};

V g_heff_2ecommands_2eemitErrs_24s852800528x545365095(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2eemitErrs_24s852800528x545365095_str0), v_e_243), ((V)&g_heff_2ecommands_2eemitErrs_24s852800528x545365095_str1));
    V v_t_246 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_WriteErr, 2, (V[]){v_t_245, NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2ecommands_2eemitErrs_24s852800528x545365095_lam0, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eemitErrs_24s852800528x545365095_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eemitErrs_24s852800528x545365095(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eemitErrs_24s852800528x545365095_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2411);
  return (g_heff_2ecommands_2eemitErrs_24s852800528x545365095(v_rest_244, v_p_241, v_p_242));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2ewriteOut_24s522201506x283476832_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ewriteOut_24s522201506x283476832_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ewriteOut_24s522201506x283476832_lam1(V self, V *args); static Clo g_heff_2ecommands_2ewriteOut_24s522201506x283476832_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteOut_24s522201506x283476832_lam1, 1, 0};
V g_heff_2ecommands_2ewriteOut_24s522201506x283476832_lam3(V self, V *args);
V g_heff_2ecommands_2ewriteOut_24s522201506x283476832_lam2(V self, V *args);
V g_heff_2ecommands_2ewriteOut_24s522201506x283476832_lam0(V self, V *args);
Clo g_heff_2ecommands_2ewriteOut_24s522201506x283476832_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteOut_24s522201506x283476832_entry, 5, 0};

V g_heff_2ecommands_2ewriteOut_24s522201506x283476832(V v_outPath_240, V v_done_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ecommands_2eemitErrs_24s852800528x545365095(heff_get(heff_dup(v_o_242), LBL_errors), heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2ewriteOut_24s522201506x283476832_lam0, 1, 5, (V[]){v_o_242, v_outPath_240, v_hd_243, v_done_241, v_k_244})));
}
V g_heff_2ecommands_2ewriteOut_24s522201506x283476832_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ewriteOut_24s522201506x283476832(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2ewriteOut_24s522201506x283476832_lam1(V self, V *args) {
  V v_ok_2410 = args[0];
  return v_ok_2410;
}
V g_heff_2ecommands_2ewriteOut_24s522201506x283476832_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2426}));
  return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2427, v_k_244});
}
V g_heff_2ecommands_2ewriteOut_24s522201506x283476832_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_outPath_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_True: {
    heff_drop(v_outPath_240);
    return heff_tail(v_done_241, 2, (V[]){v_hd_243, v_k_244});
  }
  case TAG_False: {
    heff_drop(v_done_241);
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2ewriteOut_24s522201506x283476832_str0), v_outPath_240), ((V)&g_heff_2ecommands_2ewriteOut_24s522201506x283476832_str1));
    V v_t_2417 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2420}));
    return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2421, heff_clo(g_heff_2ecommands_2ewriteOut_24s522201506x283476832_lam3, 1, 2, (V[]){v_hd_243, v_k_244})});
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ecommands_2ewriteOut_24s522201506x283476832_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_245);
  V v_t_246 = heff_get(heff_dup(v_o_242), LBL_errors);
  V v_t_249;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    v_t_249 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_246, 0ULL, 2);
    v_t_249 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    V v_t_2411 = heff_tag(TAG_WriteFile, 3, (V[]){heff_dup(v_outPath_240), heff_get(v_o_242, LBL_source), ((V)&g_heff_2ecommands_2ewriteOut_24s522201506x283476832_lam1_clo)});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2413})}));
    return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecommands_2ewriteOut_24s522201506x283476832_lam2, 1, 4, (V[]){v_done_241, v_hd_243, v_k_244, v_outPath_240})});
  }
  case TAG_False: {
    heff_drop(v_o_242);
    heff_drop(v_outPath_240);
    heff_drop(v_done_241);
    V v_t_2428 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2429 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2431}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2432, v_k_244});
  }
  default: return heff_nomatch(v_t_249);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
V g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_lam0(V self, V *args);
V g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_lam1(V self, V *args);
Clo g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_entry, 7, 0};

V g_heff_2ecommands_2ecompileFound_24s787082998x1432739843(V v_host_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_c_245, V v_available_246) {
top: ;
  V v_t_247 = (g_heff_2edriver_2ecandidatesOf(heff_dup(v_c_245)));
  V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_heff_2edriver_2enubStrD(v_t_248));
  V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_lam0, 1, 1, (V[]){heff_dup(v_available_246)}), v_t_249));
  V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = heff_dup(v_c_245); V a_2 = v_name_242; V r_ = (g_heff_2edriver_2efindRunnable(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Left: {
    V v_why_2413 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    heff_drop(v_host_240);
    heff_drop(v_outPath_243);
    heff_drop(v_done_244);
    heff_drop(v_c_245);
    return heff_clo(g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_lam1, 2, 2, (V[]){v_file_241, v_why_2413});
  }
  case TAG_Right: {
    V v_r_2428 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    heff_drop(v_file_241);
    V v_key_2429 = heff_get(heff_dup(v_r_2428), LBL_key);
    V v_eff_2430 = heff_get(v_r_2428, LBL_effect);
    V v_t_2431 = (g_heff_2eeffect_2eleaves(v_eff_2430));
    V v_xs_2432 = (g_prelude_2emap_24s656438675x1758438999(((V)&g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_str3), MK_INT(0LL), ((V)&g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_str4), ((V)&g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_str5), v_t_2431));
    V v_t_2433 = (g_heff_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_2432));
    V v_t_2434 = (g_heff_2eemit_2eprovsForGo(v_available_246, v_t_2433));
    V v_t_2435 = heff_get(heff_get(v_c_245, LBL_top), LBL_globals);
    V v_t_2436 = (g_heff_2elower_2elowerProgram(v_t_2435, heff_dup(v_key_2429)));
    V v_t_2437 = ({ V a_0 = v_host_240; V a_1 = v_t_2434; V a_2 = v_eff_2430; V a_3 = v_key_2429; V a_4 = v_t_2436; V r_ = (g_heff_2eemit_2ecompileLowered(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_key_2429); r_; });
    return heff_tail(((V)&g_heff_2ecommands_2ewriteOut_24s522201506x283476832_clo), 3, (V[]){v_outPath_243, v_done_244, v_t_2437});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileFound_24s787082998x1432739843(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[6]); return r;
}
V g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_lam0(V self, V *args) {
  V v_k_2410 = args[0];
  V v_available_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_246; V a_1 = v_k_2410; V r_ = (g_heff_2ecommands_2eprovidesLeaf(a_0, a_1)); heff_drop(v_available_246); r_; });
}
V g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2426}));
  return heff_tail(heff_get(v_hd_2414, LBL_bind), 2, (V[]){v_t_2427, v_k_2415});
}
V g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_file_241 = heff_env(self)[0];
  V v_why_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_str0), heff_strAppend(v_file_241, heff_strAppend(((V)&g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_str1), v_why_2413)));
  V v_t_2417 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2416, ((V)&g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_str2)), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2420}));
  V f_ = heff_get(heff_dup(v_hd_2414), LBL_bind);
  args[0] = v_t_2421;
  args[1] = heff_clo(g_heff_2ecommands_2ecompileFound_24s787082998x1432739843_lam2, 1, 2, (V[]){v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_str0 = {{0x80000000u, K_STR, 0}, 15, 15, {110, 111, 32, 102, 105, 108, 101, 115, 32, 103, 105, 118, 101, 110, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam0(V self, V *args); static Clo g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam0, 2, 0};
V g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam4(V self, V *args);
V g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam3(V self, V *args);
V g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam2(V self, V *args);
Clo g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_entry, 7, 0};

V g_heff_2ecommands_2ecompileLast_24s1363458628x687987283(V v_sources_240, V v_host_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_cs_246) {
top: ;
  V v_t_247 = (g_heff_2edriver_2elastChecked(v_cs_246));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_host_241);
    heff_drop(v_file_242);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    return ((V)&g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam0_clo);
  }
  case TAG_Just: {
    V v_c_2421 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_t_2422 = (g_heff_2edriver_2ecandidatesOf(heff_dup(v_c_2421)));
    V v_t_2423 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2422); r_; });
    V v_t_2424 = (g_heff_2edriver_2enubStrD(v_t_2423));
    V v_xs_2425 = (g_prelude_2emap_24s656438675x1758438999(((V)&g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_str1), MK_INT(0LL), ((V)&g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_str2), ((V)&g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_str3), v_t_2424));
    V v_t_2426 = (g_heff_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2425));
    V v_c_2427 = (g_heff_2ecommands_2ereadProviders_24s1822069164x530433648(v_sources_240, v_t_2426));
    return heff_clo(g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam2, 2, 7, (V[]){v_c_2427, v_host_241, v_file_242, v_name_243, v_outPath_244, v_done_245, v_c_2421});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileLast_24s1363458628x687987283(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[0]); heff_drop(a[6]); return r;
}
V g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get(v_hd_248, LBL_bind), 2, (V[]){v_t_2420, v_k_249});
}
V g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_t_2410 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_str0), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2413}));
  V f_ = heff_get(heff_dup(v_hd_248), LBL_bind);
  args[0] = v_t_2414;
  args[1] = heff_clo(g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam1, 1, 2, (V[]){v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam4(V self, V *args) {
  V v_p_2431 = args[0];
  V v_host_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_str4), heff_get(v_p_2431, LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2433 = (g_prelude_2emap_24s1865958870x1922568484(v_t_2432));
  V v_x1_2434 = (g_heff_2eemit_2ecatMaybesL(v_t_2433));
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nil: {
    heff_drop(v_host_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_2435 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 2);
    return heff_strEq(v_x_2435, v_host_241);
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
V g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_host_241 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_outPath_244 = heff_env(self)[3];
  V v_done_245 = heff_env(self)[4];
  V v_c_2421 = heff_env(self)[5];
  V v_hd_2428 = heff_env(self)[6];
  V v_k_2429 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2437 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam4, 1, 1, (V[]){heff_dup(v_host_241)}), v_x_2430));
  V v_t_2438 = ({ V a_0 = v_host_241; V a_1 = v_file_242; V a_2 = v_name_243; V a_3 = v_outPath_244; V a_4 = v_done_245; V a_5 = v_c_2421; V a_6 = v_t_2437; V r_ = heff_tr(g_heff_2ecommands_2ecompileFound_24s787082998x1432739843(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2437); r_; });
  return heff_tail(v_t_2438, 2, (V[]){v_hd_2428, v_k_2429});
}
V g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam2(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  V v_host_241 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_name_243 = heff_env(self)[3];
  V v_outPath_244 = heff_env(self)[4];
  V v_done_245 = heff_env(self)[5];
  V v_c_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2427;
  args[0] = heff_dup(v_hd_2428);
  args[1] = heff_clo(g_heff_2ecommands_2ecompileLast_24s1363458628x687987283_lam3, 1, 8, (V[]){v_host_241, v_file_242, v_name_243, v_outPath_244, v_done_245, v_c_2421, v_hd_2428, v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileDiags_24s921303827x759049455_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecompileDiags_24s921303827x759049455_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileDiags_24s921303827x759049455_entry, 10, 0};

V g_heff_2ecommands_2ecompileDiags_24s921303827x759049455(V v_sources_240, V v_host_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_badL_246, V v_cs_247, V v_hd_248, V v_k_249) {
top: ;
  return (g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672(heff_dup(v_cs_247), heff_dup(v_hd_248), heff_clo(g_heff_2ecommands_2ecompileDiags_24s921303827x759049455_lam0, 1, 10, (V[]){heff_dup(v_badL_246), v_hd_248, v_k_249, v_cs_247, heff_dup(v_sources_240), v_host_241, v_file_242, v_name_243, v_outPath_244, v_done_245})));
}
V g_heff_2ecommands_2ecompileDiags_24s921303827x759049455_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileDiags_24s921303827x759049455(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a[0]); heff_drop(a[6]); return r;
}
V g_heff_2ecommands_2ecompileDiags_24s921303827x759049455_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_badL_246 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_cs_247 = heff_env(self)[3];
  V v_sources_240 = heff_env(self)[4];
  V v_host_241 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2410);
  switch (heff_tag_of(v_badL_246)) {
  case TAG_True: {
    heff_drop(v_cs_247);
    heff_drop(v_sources_240);
    heff_drop(v_host_241);
    heff_drop(v_file_242);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    V v_t_2411 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2414}));
    return heff_tail(heff_get(v_hd_248, LBL_bind), 2, (V[]){v_t_2415, v_k_249});
  }
  case TAG_False: {
    V v_t_2416 = (g_prelude_2eany_24s827288872x1370860167(v_cs_247));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      heff_drop(v_cs_247);
      heff_drop(v_sources_240);
      heff_drop(v_host_241);
      heff_drop(v_file_242);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      V v_t_2417 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2420}));
      return heff_tail(heff_get(v_hd_248, LBL_bind), 2, (V[]){v_t_2421, v_k_249});
    }
    case TAG_False: {
      V v_t_2422 = ({ V a_0 = v_sources_240; V a_1 = v_host_241; V a_2 = v_file_242; V a_3 = v_name_243; V a_4 = v_outPath_244; V a_5 = v_done_245; V a_6 = v_cs_247; V r_ = (g_heff_2ecommands_2ecompileLast_24s1363458628x687987283(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sources_240); heff_drop(v_cs_247); r_; });
      return heff_tail(v_t_2422, 2, (V[]){v_hd_248, v_k_249});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_badL_246);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {109, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam3(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam2(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam1(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam0(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam9(V self, V *args); static Clo g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam9, 1, 0};
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam8(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam11(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam10(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam7(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam6(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam5(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam4(V self, V *args);
Clo g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_entry, 2, 0};

V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376(V v_file_240, V v_progArgs_241) {
top: ;
  V v_c_242 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  V v_c_2412 = heff_clo(g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam0, 2, 2, (V[]){v_c_242, heff_dup(v_file_240)});
  return heff_clo(g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam4, 2, 3, (V[]){v_c_2412, v_file_240, v_progArgs_241});
}
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2erunCmd_24s1580090152x1903096376(a[0], a[1]);
}
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = ({ V a_0 = v_x_249; V a_1 = heff_get(heff_dup(v_x_247), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_249); r_; });
  V v_x_2411 = (g_prelude_2efoldl_24s1838030138x788027388(v_x_247, v_t_2410));
  V f_ = v_k_244;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_248 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_248, 2, (V[]){v_hd_243, heff_clo(g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam3, 1, 2, (V[]){v_x_247, v_k_244})});
}
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246 = (g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(v_x_245, v_file_240));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam2, 1, 2, (V[]){v_hd_243, v_k_244})});
}
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo(g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam1, 1, 3, (V[]){v_file_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam9(V self, V *args) {
  V v_ok_2422 = args[0];
  return v_ok_2422;
}
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam8(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k2_2421 = args[1];
  V v_path_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_2419, ((V)&g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam9_clo)})});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2420), LBL_malg), 1, (V[]){v_t_2425}));
  V f_ = heff_get(v_hd_2420, LBL_bind);
  args[0] = v_t_2426;
  args[1] = v_k2_2421;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam11(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_as_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_tag(TAG_Exec, 3, (V[]){((V)&g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_str3), v_as_2431, NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2432), LBL_malg), 1, (V[]){v_t_2437}));
  V f_ = heff_get(v_hd_2432, LBL_bind);
  args[0] = v_t_2438;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam10(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_progArgs_241 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_x_2418 = heff_env(self)[4];
  V v_hd_2413 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2428);
  V v_t_2429 = (g_heff_2ecommands_2erunPath(heff_get(heff_dup(v_x_2415), LBL_paths), heff_dup(v_file_240)));
  V v_t_2430 = (g_heff_2ecommands_2erunPath(heff_get(heff_dup(v_x_2415), LBL_paths), heff_dup(v_file_240)));
  V v_as_2431 = heff_tag(TAG_Cons, 2, (V[]){v_t_2430, v_progArgs_241});
  return ({ V b_0 = heff_get(v_x_2415, LBL_sources); V a_1 = ((V)&g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_str1); V a_2 = v_file_240; V a_3 = heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_str2)}); V a_4 = v_t_2429; V a_5 = heff_clo(g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam11, 2, 1, (V[]){v_as_2431}); V b_6 = heff_intLt(MK_INT(0LL), v_x_2416); V a_7 = v_x_2418; V a_8 = v_hd_2413; V a_9 = v_k_2414; V r_ = (g_heff_2ecommands_2ecompileDiags_24s921303827x759049455(b_0, a_1, a_2, a_3, a_4, a_5, b_6, a_7, a_8, a_9)); heff_drop(b_0); heff_drop(b_6); r_; });
}
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam7(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_progArgs_241 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_path_2419 = (g_heff_2ecommands_2erunDir(heff_get(heff_dup(v_x_2415), LBL_paths)));
  V v_c_2427 = heff_clo(g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam8, 2, 1, (V[]){v_path_2419});
  return heff_tail(v_c_2427, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam10, 1, 7, (V[]){v_x_2415, v_file_240, v_progArgs_241, v_x_2416, v_x_2418, v_hd_2413, v_k_2414})});
}
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_progArgs_241 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2417 = (g_heff_2esession_2ecachedProgram_24s595918180x507103762(heff_dup(v_x_2415)));
  return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam7, 1, 6, (V[]){v_x_2415, v_hd_2413, v_file_240, v_progArgs_241, v_x_2416, v_k_2414})});
}
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_progArgs_241 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(((V)&g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_str0), heff_get(heff_dup(v_x_2415), LBL_errors), MK_INT(0LL), heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam6, 1, 5, (V[]){v_x_2415, v_hd_2413, v_file_240, v_progArgs_241, v_k_2414})));
}
V g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam4(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_progArgs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo(g_heff_2ecommands_2erunCmd_24s1580090152x1903096376_lam5, 1, 4, (V[]){v_hd_2413, v_file_240, v_progArgs_241, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam0(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam2(V self, V *args); static Clo g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam2, 1, 0};
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam4(V self, V *args); static Clo g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam4, 1, 0};
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam6(V self, V *args); static Clo g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam6, 2, 0};
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam8(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam7(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam5(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam3(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam1(V self, V *args);
Clo g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_entry, 2, 0};

V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_241));
    return heff_clo(g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_MkPair: {
      V v_top_247 = heff_field(v_x11_245, 0);
      V v_p_248 = heff_field(v_x11_245, 1);
      heff_take_n(v_x11_245, 3ULL, 2);
      return heff_clo(g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam1, 2, 4, (V[]){v_p_248, v_rest_246, v_acc_241, v_top_247});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249(a[0], a[1]);
}
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam2(V self, V *args) {
  V v_ns_2411 = args[0];
  return v_ns_2411;
}
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam4(V self, V *args) {
  V v_s_2417 = args[0];
  return v_s_2417;
}
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam6(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  heff_drop(v_hd_2431);
  V f_ = v_k_2432;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam8(V self, V *args) {
  V v_n_2437 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2438 = (g_std_2epath_2eparse(v_x_2424, v_p_248));
  V v_t_2439 = (g_std_2epath_2eparse(v_x_2424, v_n_2437));
  V v_p_2440 = (g_std_2epath_2ejoin_2eonto_240(v_t_2438, v_t_2439));
  V v_t_2441 = ({ V a_0 = heff_get(heff_dup(v_p_2440), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2440), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2442 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2440), LBL_drive), heff_get(v_p_2440, LBL_absolute), v_t_2441});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), ({ V a_0 = v_x_2424; V a_1 = v_t_2442; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2424); r_; })});
}
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_ns_2430 = heff_env(self)[4];
  V v_x_2424 = heff_env(self)[5];
  V v_p_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2434)) {
  case TAG_True: {
    heff_drop(v_ns_2430);
    heff_drop(v_x_2424);
    heff_drop(v_p_248);
    V v_t_2435 = (g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249(v_rest_246, v_acc_241));
    return heff_tail(v_t_2435, 2, (V[]){v_hd_249, v_k_2410});
  }
  case TAG_False: {
    V v_t_2436 = (g_prelude_2efilter_24s1642131147x1885675035(MK_INT(0LL), MK_INT(1LL), ((V)&g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_str2), v_ns_2430));
    V v_t_2443 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam8, 1, 2, (V[]){v_x_2424, v_p_248}), v_t_2436));
    V v_t_2444 = (g_prelude_2econcatList(v_t_2443, v_rest_246));
    V v_t_2445 = (g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249(v_t_2444, v_acc_241));
    return heff_tail(v_t_2445, 2, (V[]){v_hd_249, v_k_2410});
  }
  default: return heff_nomatch(v_x_2434);
  }
}
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  V v_top_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2423 = heff_strEq(v_x_2422, ((V)&g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_str0));
  V v_x_2424;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_True: {
    v_x_2424 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2424 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_top_247);
    heff_drop(v_x_2424);
    V v_t_2425 = heff_intSub(heff_strLength(heff_dup(v_p_248)), MK_INT(3LL));
    V v_t_2426 = heff_strSlice(heff_dup(v_p_248), v_t_2425, heff_strLength(heff_dup(v_p_248)));
    V v_t_2427 = heff_strEq(v_t_2426, ((V)&g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_str1));
    switch (heff_tag_of(v_t_2427)) {
    case TAG_True: {
      V v_t_2428 = (g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249(v_rest_246, heff_tag(TAG_Cons, 2, (V[]){v_p_248, v_acc_241})));
      return heff_tail(v_t_2428, 2, (V[]){v_hd_249, v_k_2410});
    }
    case TAG_False: {
      heff_drop(v_p_248);
      V v_t_2429 = (g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249(v_rest_246, v_acc_241));
      return heff_tail(v_t_2429, 2, (V[]){v_hd_249, v_k_2410});
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  case TAG_Just: {
    V v_ns_2430 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_c_2433;
    switch (heff_tag_of(v_top_247)) {
    case TAG_True: {
      v_c_2433 = ((V)&g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam6_clo);
      break;
    }
    case TAG_False: {
      v_c_2433 = (g_heff_2eload_2eisRoot_24s954538899x21349900(v_x_2424, heff_dup(v_p_248)));
      break;
    }
    default: heff_nomatch(v_top_247);
    }
    return heff_tail(v_c_2433, 2, (V[]){heff_dup(v_hd_249), heff_clo(g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam7, 1, 7, (V[]){v_rest_246, v_acc_241, v_hd_249, v_k_2410, v_ns_2430, v_x_2424, v_p_248})});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  V v_top_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam4_clo)})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2420})}));
  return heff_tail(heff_get(heff_dup(v_hd_249), LBL_bind), 2, (V[]){v_t_2421, heff_clo(g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam5, 1, 7, (V[]){v_x_2416, v_p_248, v_rest_246, v_acc_241, v_hd_249, v_k_2410, v_top_247})});
}
V g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_p_248 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_top_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){heff_dup(v_p_248), ((V)&g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam2_clo)})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2414}));
  V f_ = heff_get(heff_dup(v_hd_249), LBL_bind);
  args[0] = v_t_2415;
  args[1] = heff_clo(g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249_lam3, 1, 6, (V[]){v_hd_249, v_p_248, v_rest_246, v_acc_241, v_k_2410, v_top_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2etestFiles_24s195001740x1715824632_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[68]; } g_heff_2ecommands_2etestFiles_24s195001740x1715824632_str1 = {{0x80000000u, K_STR, 0}, 68, 68, {104, 101, 102, 102, 32, 116, 101, 115, 116, 58, 32, 110, 111, 32, 116, 101, 115, 116, 47, 32, 104, 101, 114, 101, 58, 32, 116, 101, 115, 116, 32, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116, 44, 32, 111, 114, 32, 103, 105, 118, 101, 32, 70, 73, 76, 69, 115, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2etestFiles_24s195001740x1715824632_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 115, 116}};
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam1(V self, V *args); static Clo g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam1, 1, 0};
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam4(V self, V *args);
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam3(V self, V *args);
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam2(V self, V *args);
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam0(V self, V *args); static Clo g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam0, 2, 0};
Clo g_heff_2ecommands_2etestFiles_24s195001740x1715824632_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFiles_24s195001740x1715824632_entry, 1, 0};

V g_heff_2ecommands_2etestFiles_24s195001740x1715824632(V v_given_240) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam0_clo);
  }
  case TAG_Cons: {
    V v_t_2427 = (g_prelude_2emap_24s1843312214x961377872(v_given_240));
    return (g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249(v_t_2427, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestFiles_24s195001740x1715824632(a[0]);
}
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam1(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2420);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2419, heff_clo(g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam4, 1, 1, (V[]){v_k_242})});
}
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    V v_t_249 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2etestFiles_24s195001740x1715824632_str1), NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2412}));
    return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam3, 1, 2, (V[]){v_hd_241, v_k_242})});
  }
  case TAG_Just: {
    heff_take_n(v_x_248, 0ULL, 1);
    V v_t_2422 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2ecommands_2etestFiles_24s195001740x1715824632_str2)});
    V v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
    V v_t_2424 = (g_heff_2ecommands_2etestFilesGo_24s767337449x1989744249(v_t_2423, NTAG(TAG_Nil)));
    return heff_tail(v_t_2424, 2, (V[]){v_hd_241, v_k_242});
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){((V)&g_heff_2ecommands_2etestFiles_24s195001740x1715824632_str0), ((V)&g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam1_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_246}));
  V f_ = heff_get(heff_dup(v_hd_241), LBL_bind);
  args[0] = v_t_247;
  args[1] = heff_clo(g_heff_2ecommands_2etestFiles_24s195001740x1715824632_lam2, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ediagCount_24s1773858402x841115473_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {101, 114, 114, 111, 114, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ediagCount_24s1773858402x841115473_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {93, 58, 32}};
V g_heff_2ecommands_2ediagCount_24s1773858402x841115473_lam0(V self, V *args); static Clo g_heff_2ecommands_2ediagCount_24s1773858402x841115473_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ediagCount_24s1773858402x841115473_lam0, 2, 0};
V g_heff_2ecommands_2ediagCount_24s1773858402x841115473_lam3(V self, V *args);
V g_heff_2ecommands_2ediagCount_24s1773858402x841115473_lam2(V self, V *args);
V g_heff_2ecommands_2ediagCount_24s1773858402x841115473_lam1(V self, V *args);
Clo g_heff_2ecommands_2ediagCount_24s1773858402x841115473_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ediagCount_24s1773858402x841115473_entry, 1, 0};

V g_heff_2ecommands_2ediagCount_24s1773858402x841115473(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecommands_2ediagCount_24s1773858402x841115473_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_t_245 = (g_prelude_2emap_24s752906154x1709852375(((V)&g_heff_2ecommands_2ediagCount_24s1773858402x841115473_str0), ((V)&g_heff_2ecommands_2ediagCount_24s1773858402x841115473_str1), heff_get(heff_dup(v_c_243), LBL_diags)));
    V v_c_246 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_clo), 3, (V[]){heff_get(heff_dup(v_c_243), LBL_module), v_t_245, MK_INT(0LL)}));
    return heff_clo(g_heff_2ecommands_2ediagCount_24s1773858402x841115473_lam1, 2, 2, (V[]){v_c_246, heff_dup(v_rest_244)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2ediagCount_24s1773858402x841115473_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ediagCount_24s1773858402x841115473(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ediagCount_24s1773858402x841115473_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ediagCount_24s1773858402x841115473_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_intAdd(v_x_249, v_x_2411);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ediagCount_24s1773858402x841115473_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2410 = ({ V a_0 = v_rest_244; V r_ = (g_heff_2ecommands_2ediagCount_24s1773858402x841115473(a_0)); heff_drop(v_rest_244); r_; });
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2ecommands_2ediagCount_24s1773858402x841115473_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2ecommands_2ediagCount_24s1773858402x841115473_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_rest_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2ecommands_2ediagCount_24s1773858402x841115473_lam2, 1, 3, (V[]){v_rest_244, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintFails_24s917669454x1451729436_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintFails_24s917669454x1451729436_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintFails_24s917669454x1451729436_lam0(V self, V *args); static Clo g_heff_2ecommands_2eprintFails_24s917669454x1451729436_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintFails_24s917669454x1451729436_lam0, 2, 0};
V g_heff_2ecommands_2eprintFails_24s917669454x1451729436_lam1(V self, V *args);
V g_heff_2ecommands_2eprintFails_24s917669454x1451729436_lam3(V self, V *args);
V g_heff_2ecommands_2eprintFails_24s917669454x1451729436_lam2(V self, V *args);
Clo g_heff_2ecommands_2eprintFails_24s917669454x1451729436_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintFails_24s917669454x1451729436_entry, 3, 0};

V g_heff_2ecommands_2eprintFails_24s917669454x1451729436(V v_f_240, V v_color_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecommands_2eprintFails_24s917669454x1451729436_lam0_clo);
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_get(heff_get(heff_dup(v_r_245), LBL_watch), LBL_expected);
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_t_249 = ((V)&g_heff_2ecommands_2eprintFails_24s917669454x1451729436_str0);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2410 = heff_get(heff_get(heff_dup(v_r_245), LBL_watch), LBL_value);
    V v_t_2411 = (g_heff_2ereport_2emismatch(v_color_241, v_t_249, v_t_2410));
    V v_str_2412 = (g_heff_2ecommands_2efailLine(heff_dup(v_f_240), v_r_245, v_t_2411));
    V v_c_2420 = heff_clo(g_heff_2ecommands_2eprintFails_24s917669454x1451729436_lam1, 2, 1, (V[]){v_str_2412});
    return heff_clo(g_heff_2ecommands_2eprintFails_24s917669454x1451729436_lam2, 2, 4, (V[]){v_c_2420, v_f_240, heff_dup(v_color_241), v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2eprintFails_24s917669454x1451729436_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprintFails_24s917669454x1451729436(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2eprintFails_24s917669454x1451729436_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eprintFails_24s917669454x1451729436_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_str_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2412, ((V)&g_heff_2ecommands_2eprintFails_24s917669454x1451729436_str1)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2413, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eprintFails_24s917669454x1451729436_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_color_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2421 = heff_env(self)[3];
  V v_k_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2423);
  V v_t_2424 = ({ V a_0 = v_f_240; V a_1 = v_color_241; V a_2 = v_rest_246; V r_ = (g_heff_2ecommands_2eprintFails_24s917669454x1451729436(a_0, a_1, a_2)); heff_drop(v_color_241); r_; });
  return heff_tail(v_t_2424, 2, (V[]){v_hd_2421, v_k_2422});
}
V g_heff_2ecommands_2eprintFails_24s917669454x1451729436_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_color_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2420;
  args[0] = heff_dup(v_hd_2421);
  args[1] = heff_clo(g_heff_2ecommands_2eprintFails_24s917669454x1451729436_lam3, 1, 5, (V[]){v_f_240, v_color_241, v_rest_246, v_hd_2421, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 32, 32, 32, 32, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam0(V self, V *args); static Clo g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam0, 2, 0};
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam1(V self, V *args);
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam4(V self, V *args); static Clo g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam4, 2, 0};
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam5(V self, V *args);
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam6(V self, V *args);
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam3(V self, V *args);
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam2(V self, V *args);
Clo g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_entry, 2, 0};

V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_str_246 = (g_heff_2ecommands_2eoutcomeLine(heff_dup(v_o_244)));
    V v_c_2414 = heff_clo(g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam1, 2, 1, (V[]){v_str_246});
    return heff_clo(g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam2, 2, 4, (V[]){v_c_2414, v_o_244, heff_dup(v_color_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_str_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_246, ((V)&g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_str0)), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2412}));
  V f_ = heff_get(v_hd_247, LBL_bind);
  args[0] = v_t_2413;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam5(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k2_2430 = args[1];
  V v_str_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2428, ((V)&g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_str4)), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2429), LBL_malg), 1, (V[]){v_t_2434}));
  V f_ = heff_get(v_hd_2429, LBL_bind);
  args[0] = v_t_2435;
  args[1] = v_k2_2430;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_color_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2415 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2437);
  V v_t_2438 = ({ V a_0 = v_color_240; V a_1 = v_rest_245; V r_ = (g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504(a_0, a_1)); heff_drop(v_color_240); r_; });
  return heff_tail(v_t_2438, 2, (V[]){v_hd_2415, v_k_2416});
}
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_o_244 = heff_env(self)[0];
  V v_color_240 = heff_env(self)[1];
  V v_hd_2415 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_k_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2417);
  V v_t_2418 = heff_get(heff_dup(v_o_244), LBL_ok);
  V v_c_2436;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    heff_drop(v_o_244);
    v_c_2436 = ((V)&g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam4_clo);
    break;
  }
  case TAG_False: {
    V v_t_2421 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_str1), heff_get(heff_dup(v_o_244), LBL_notes)));
    V v_t_2422 = heff_get(v_o_244, LBL_failure);
    V v_t_2424;
    switch (heff_tag_of(v_t_2422)) {
    case TAG_Nothing: {
      v_t_2424 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_f_2423 = heff_field(v_t_2422, 0);
      heff_take_n(v_t_2422, 1ULL, 1);
      v_t_2424 = (g_heff_2ecommands_2efailLines(v_color_240, v_f_2423));
      break;
    }
    default: heff_nomatch(v_t_2422);
    }
    V v_x2_2425 = (g_prelude_2econcatList(v_t_2421, v_t_2424));
    V v_str_2428;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nil: {
      v_str_2428 = ((V)&g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_xs_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      v_str_2428 = ({ V a_0 = ((V)&g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_str3); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    v_c_2436 = heff_clo(g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam5, 2, 1, (V[]){v_str_2428});
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_2415), heff_clo(g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam6, 1, 4, (V[]){v_color_240, v_rest_245, v_hd_2415, v_k_2416})});
}
V g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_o_244 = heff_env(self)[1];
  V v_color_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo(g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504_lam3, 1, 5, (V[]){v_o_244, v_color_240, v_hd_2415, v_rest_245, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestReport_24s576678775x1979662005_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {111, 107, 32, 32, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestReport_24s576678775x1979662005_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestReport_24s576678775x1979662005_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestReport_24s576678775x1979662005_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2etestReport_24s576678775x1979662005_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestReport_24s576678775x1979662005_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestReport_24s576678775x1979662005_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam0(V self, V *args); static Clo g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam0, 1, 0};
V g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam4(V self, V *args);
V g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam5(V self, V *args);
V g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam3(V self, V *args);
V g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam2(V self, V *args);
V g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam1(V self, V *args);
Clo g_heff_2ecommands_2etestReport_24s576678775x1979662005_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestReport_24s576678775x1979662005_entry, 6, 0};

V g_heff_2ecommands_2etestReport_24s576678775x1979662005(V v_f_240, V v_bad_241, V v_ts_242, V v_os_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_UseColor, 1, (V[]){((V)&g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam0_clo)})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_248})}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam1, 1, 6, (V[]){v_ts_242, v_f_240, v_hd_244, v_os_243, v_bad_241, v_k_245})});
}
V g_heff_2ecommands_2etestReport_24s576678775x1979662005_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestReport_24s576678775x1979662005(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam0(V self, V *args) {
  V v_b_246 = args[0];
  return v_b_246;
}
V g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam4(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k2_2431 = args[1];
  V v_str_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2429, ((V)&g_heff_2ecommands_2etestReport_24s576678775x1979662005_str6)), NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2430), LBL_malg), 1, (V[]){v_t_2435}));
  V f_ = heff_get(v_hd_2430, LBL_bind);
  args[0] = v_t_2436;
  args[1] = v_k2_2431;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_bad_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2438);
  V v_t_2439 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_xs_2440 = (g_prelude_2efilter_24s1514461241x1644469075(v_ts_242));
  V v_t_2441 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2440; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
  V v_t_2442 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_os_243));
  V v_xs_2443 = (g_prelude_2efilter_24s1700824619x1565819740(v_os_243));
  V v_t_2444 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2443; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
  V v_x_2445 = heff_rec(5, shape_total__failed__ok__tests__testsFailed, (V[]){v_t_2439, v_t_2441, heff_intEq(v_bad_241, MK_INT(0LL)), v_t_2442, v_t_2444});
  V f_ = v_k_245;
  args[0] = v_x_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_bad_241 = heff_env(self)[2];
  V v_f_240 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2415);
  V v_x1_2416 = (g_prelude_2efilter_24s1514461241x1644469075(heff_dup(v_ts_242)));
  V v_t_2423;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_Nil: {
    V v_x1_2417 = (g_prelude_2efilter_24s1700824619x1565819740(heff_dup(v_os_243)));
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nil: {
      V v_t_2418 = heff_intEq(heff_dup(v_bad_241), MK_INT(0LL));
      switch (heff_tag_of(v_t_2418)) {
      case TAG_True: {
        v_t_2423 = ((V)&g_heff_2ecommands_2etestReport_24s576678775x1979662005_str0);
        break;
      }
      case TAG_False: {
        v_t_2423 = ((V)&g_heff_2ecommands_2etestReport_24s576678775x1979662005_str1);
        break;
      }
      default: heff_nomatch(v_t_2418);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2417, 0ULL, 2);
      v_t_2423 = ((V)&g_heff_2ecommands_2etestReport_24s576678775x1979662005_str2);
      break;
    }
    default: heff_nomatch(v_x1_2417);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2416, 0ULL, 2);
    v_t_2423 = ((V)&g_heff_2ecommands_2etestReport_24s576678775x1979662005_str3);
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_t_2424 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_xs_2425 = (g_prelude_2efilter_24s1514461241x1644469075(heff_dup(v_ts_242)));
  V v_t_2426 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2425; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
  V v_t_2427 = heff_intShow(heff_intSub(v_t_2424, v_t_2426));
  V v_t_2428 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_str_2429 = heff_strAppend(v_t_2423, heff_strAppend(v_f_240, heff_strAppend(((V)&g_heff_2ecommands_2etestReport_24s576678775x1979662005_str4), heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2ecommands_2etestReport_24s576678775x1979662005_str5), heff_strAppend(heff_intShow(v_t_2428), (g_heff_2ecommands_2etestsSaid(heff_dup(v_os_243)))))))));
  V v_c_2437 = heff_clo(g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam4, 2, 1, (V[]){v_str_2429});
  return heff_tail(v_c_2437, 2, (V[]){v_hd_244, heff_clo(g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam5, 1, 4, (V[]){v_ts_242, v_os_243, v_bad_241, v_k_245})});
}
V g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_ts_242 = heff_env(self)[3];
  V v_bad_241 = heff_env(self)[4];
  V v_f_240 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2413);
  V v_c_2414 = ({ V a_0 = v_x_2410; V a_1 = heff_dup(v_os_243); V r_ = (g_heff_2ecommands_2eprintOutcomes_24s628758903x903030504(a_0, a_1)); heff_drop(v_x_2410); r_; });
  return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam3, 1, 6, (V[]){v_ts_242, v_os_243, v_bad_241, v_f_240, v_hd_244, v_k_245})});
}
V g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_os_243 = heff_env(self)[3];
  V v_bad_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2411 = (g_prelude_2efilter_24s1514461241x1644469075(heff_dup(v_ts_242)));
  V v_c_2412 = (g_heff_2ecommands_2eprintFails_24s917669454x1451729436(heff_dup(v_f_240), v_x_2410, v_t_2411));
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2etestReport_24s576678775x1979662005_lam2, 1, 7, (V[]){v_x_2410, v_os_243, v_hd_244, v_ts_242, v_bad_241, v_f_240, v_k_245})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestOneC_24s478685886x44287029_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2etestOneC_24s478685886x44287029_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 32, 48, 47, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestOneC_24s478685886x44287029_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2etestOneC_24s478685886x44287029_lam2(V self, V *args);
V g_heff_2ecommands_2etestOneC_24s478685886x44287029_lam3(V self, V *args);
V g_heff_2ecommands_2etestOneC_24s478685886x44287029_lam1(V self, V *args);
V g_heff_2ecommands_2etestOneC_24s478685886x44287029_lam0(V self, V *args);
Clo g_heff_2ecommands_2etestOneC_24s478685886x44287029_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestOneC_24s478685886x44287029_entry, 4, 0};

V g_heff_2ecommands_2etestOneC_24s478685886x44287029(V v_seed_240, V v_f_241, V v_bad0_242, V v_cs_243) {
top: ;
  V v_c_244 = (g_heff_2ecommands_2ediagCount_24s1773858402x841115473(v_cs_243));
  return heff_clo(g_heff_2ecommands_2etestOneC_24s478685886x44287029_lam0, 2, 5, (V[]){v_c_244, heff_dup(v_cs_243), v_f_241, v_bad0_242, v_seed_240});
}
V g_heff_2ecommands_2etestOneC_24s478685886x44287029_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2etestOneC_24s478685886x44287029(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2ecommands_2etestOneC_24s478685886x44287029_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_rec(5, shape_total__failed__ok__tests__testsFailed, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL)});
  V f_ = v_k_246;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2etestOneC_24s478685886x44287029_lam3(V self, V *args) {
  V v_w_2420 = args[0];
  V v_c_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_get(heff_dup(v_w_2420), LBL_expected);
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nothing: {
    heff_drop(v_w_2420);
    heff_drop(v_c_2417);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_ru_24t_2421_24Just = heff_take_reuse_n(v_t_2421, 0ULL, 1);
    V v_t_2423 = (g_heff_2edriver_2eownerOf(v_c_2417, heff_get(heff_dup(v_w_2420), LBL_from)));
    return heff_tag_at(v_ru_24t_2421_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_owner__watch, (V[]){v_t_2423, v_w_2420})});
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_heff_2ecommands_2etestOneC_24s478685886x44287029_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_bad0_242 = heff_env(self)[4];
  V v_seed_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_248 = ({ V a_0 = v_cs_243; V r_ = (g_heff_2edriver_2elastChecked(a_0)); heff_drop(v_cs_243); r_; });
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop(v_x_247);
    heff_drop(v_bad0_242);
    heff_drop(v_seed_240);
    V v_t_249 = heff_strAppend(((V)&g_heff_2ecommands_2etestOneC_24s478685886x44287029_str0), heff_strAppend(v_f_241, ((V)&g_heff_2ecommands_2etestOneC_24s478685886x44287029_str1)));
    V v_t_2410 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2ecommands_2etestOneC_24s478685886x44287029_str2)), NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2413}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecommands_2etestOneC_24s478685886x44287029_lam2, 1, 1, (V[]){v_k_246})});
  }
  case TAG_Just: {
    V v_c_2417 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    V v_t_2418 = heff_get(heff_get(heff_dup(v_c_2417), LBL_top), LBL_watches);
    V v_t_2419 = (g_heff_2edriver_2ewatchesGo(heff_dup(v_c_2417), MK_INT(0LL), v_t_2418));
    V v_t_2424 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2etestOneC_24s478685886x44287029_lam3, 1, 1, (V[]){heff_dup(v_c_2417)}), v_t_2419));
    V v_t_2425 = (g_heff_2edriver_2ecatMaybesD(v_t_2424));
    V v_t_2426 = heff_intLt(MK_INT(0LL), heff_intAdd(heff_dup(v_bad0_242), heff_dup(v_x_247)));
    V v_t_2427;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_True: {
      heff_drop(v_seed_240);
      heff_drop(v_c_2417);
      v_t_2427 = NTAG(TAG_Nil);
      break;
    }
    case TAG_False: {
      v_t_2427 = (g_heff_2edriver_2erunTests(v_seed_240, v_c_2417));
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    return (g_heff_2ecommands_2etestReport_24s576678775x1979662005(v_f_241, heff_intAdd(v_bad0_242, v_x_247), v_t_2425, v_t_2427, v_hd_245, v_k_246));
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ecommands_2etestOneC_24s478685886x44287029_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_cs_243 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_bad0_242 = heff_env(self)[3];
  V v_seed_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo(g_heff_2ecommands_2etestOneC_24s478685886x44287029_lam1, 1, 6, (V[]){v_cs_243, v_f_241, v_hd_245, v_k_246, v_bad0_242, v_seed_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2etestOneF_24s48196897x863364522_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam3(V self, V *args);
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam2(V self, V *args);
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam1(V self, V *args);
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam0(V self, V *args);
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam7(V self, V *args);
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam6(V self, V *args);
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam5(V self, V *args);
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam4(V self, V *args);
Clo g_heff_2ecommands_2etestOneF_24s48196897x863364522_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestOneF_24s48196897x863364522_entry, 2, 0};

V g_heff_2ecommands_2etestOneF_24s48196897x863364522(V v_seed_240, V v_f_241) {
top: ;
  V v_c_242 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  V v_c_2412 = heff_clo(g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam0, 2, 2, (V[]){v_c_242, heff_dup(v_f_241)});
  return heff_clo(g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam4, 2, 3, (V[]){v_c_2412, v_seed_240, v_f_241});
}
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestOneF_24s48196897x863364522(a[0], a[1]);
}
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = ({ V a_0 = v_x_249; V a_1 = heff_get(heff_dup(v_x_247), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_249); r_; });
  V v_x_2411 = (g_prelude_2efoldl_24s1838030138x788027388(v_x_247, v_t_2410));
  V f_ = v_k_244;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_248 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_248, 2, (V[]){v_hd_243, heff_clo(g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam3, 1, 2, (V[]){v_x_247, v_k_244})});
}
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246 = (g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(v_x_245, v_f_241));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam2, 1, 2, (V[]){v_hd_243, v_k_244})});
}
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo(g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam1, 1, 3, (V[]){v_f_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam7(V self, V *args) {
  V v_x_2418 = args[0];
  V v_seed_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2419 = ({ V a_0 = v_seed_240; V a_1 = v_f_241; V a_2 = v_x_2416; V a_3 = v_x_2418; V r_ = (g_heff_2ecommands_2etestOneC_24s478685886x44287029(a_0, a_1, a_2, a_3)); heff_drop(v_x_2418); r_; });
  return heff_tail(v_t_2419, 2, (V[]){v_hd_2413, v_k_2414});
}
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_seed_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2417 = (g_heff_2esession_2ecachedProgram_24s595918180x507103762(v_x_2415));
  return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam7, 1, 5, (V[]){v_seed_240, v_f_241, v_x_2416, v_hd_2413, v_k_2414})});
}
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(((V)&g_heff_2ecommands_2etestOneF_24s48196897x863364522_str0), heff_get(heff_dup(v_x_2415), LBL_errors), MK_INT(0LL), heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam6, 1, 5, (V[]){v_x_2415, v_hd_2413, v_seed_240, v_f_241, v_k_2414})));
}
V g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam4(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo(g_heff_2ecommands_2etestOneF_24s48196897x863364522_lam5, 1, 4, (V[]){v_hd_2413, v_seed_240, v_f_241, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestCmd_24s594351318x1837481428_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2etestCmd_24s594351318x1837481428_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestCmd_24s594351318x1837481428_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2etestCmd_24s594351318x1837481428_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {32, 116, 101, 115, 116, 115, 32, 104, 111, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestCmd_24s594351318x1837481428_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2etestCmd_24s594351318x1837481428_str5 = {{0x80000000u, K_STR, 0}, 18, 18, {32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 104, 111, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestCmd_24s594351318x1837481428_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam1(V self, V *args);
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam2(V self, V *args);
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam0(V self, V *args);
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam3(V self, V *args); static Clo g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam3, 1, 0};
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam6(V self, V *args);
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam5(V self, V *args);
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam4(V self, V *args);
Clo g_heff_2ecommands_2etestCmd_24s594351318x1837481428_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestCmd_24s594351318x1837481428_entry, 6, 0};

V g_heff_2ecommands_2etestCmd_24s594351318x1837481428(V v_tk_240, V v_seed_241, V v_x3_242, V v_acc_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seed_241);
    V v_t_246 = heff_tag(TAG_End, 2, (V[]){v_tk_240, NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_p_244), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})}));
    return heff_tail(heff_get(heff_dup(v_p_244), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam0, 1, 3, (V[]){v_acc_243, v_p_244, v_p_245})});
  }
  case TAG_Cons: {
    V v_f_2443 = heff_field(v_x3_242, 0);
    V v_rest_2444 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2446 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(v_tk_240), heff_dup(v_f_2443), MK_INT(0LL), ((V)&g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam3_clo)})});
    V v_t_2447 = heff_tr(heff_apply(heff_get(heff_dup(v_p_244), LBL_malg), 1, (V[]){v_t_2446}));
    return heff_tail(heff_get(heff_dup(v_p_244), LBL_bind), 2, (V[]){v_t_2447, heff_clo(g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam4, 1, 7, (V[]){v_seed_241, v_f_2443, v_p_244, v_acc_243, v_tk_240, v_rest_2444, v_p_245})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestCmd_24s594351318x1837481428(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k2_2417 = args[1];
  V v_str_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2415, ((V)&g_heff_2ecommands_2etestCmd_24s594351318x1837481428_str6)), NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2416), LBL_malg), 1, (V[]){v_t_2421}));
  V f_ = heff_get(v_hd_2416, LBL_bind);
  args[0] = v_t_2422;
  args[1] = v_k2_2417;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2424);
  V v_t_2425 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_acc_243), LBL_failed));
  switch (heff_tag_of(v_t_2425)) {
  case TAG_True: {
    heff_drop(v_acc_243);
    V v_t_2426 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_p_244), LBL_malg), 1, (V[]){v_t_2429}));
    return heff_tail(heff_get(v_p_244, LBL_bind), 2, (V[]){v_t_2430, v_p_245});
  }
  case TAG_False: {
    V v_t_2431 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_acc_243), LBL_testsFailed));
    switch (heff_tag_of(v_t_2431)) {
    case TAG_True: {
      heff_drop(v_acc_243);
      V v_t_2432 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_p_244), LBL_malg), 1, (V[]){v_t_2435}));
      return heff_tail(heff_get(v_p_244, LBL_bind), 2, (V[]){v_t_2436, v_p_245});
    }
    case TAG_False: {
      V v_t_2437 = heff_get(v_acc_243, LBL_ok);
      switch (heff_tag_of(v_t_2437)) {
      case TAG_True: {
        heff_drop(v_p_244);
        V f_ = v_p_245;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_False: {
        V v_t_2438 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2439 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2438})});
        V v_t_2440 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})});
        V v_t_2441 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})});
        V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_p_244), LBL_malg), 1, (V[]){v_t_2441}));
        return heff_tail(heff_get(v_p_244, LBL_bind), 2, (V[]){v_t_2442, v_p_245});
      }
      default: return heff_nomatch(v_t_2437);
      }
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  default: return heff_nomatch(v_t_2425);
  }
}
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_248);
  V v_t_249 = heff_intSub(heff_get(heff_dup(v_acc_243), LBL_total), heff_get(heff_dup(v_acc_243), LBL_failed));
  V v_t_2410 = heff_intShow(heff_get(heff_dup(v_acc_243), LBL_total));
  V v_tests_2411 = heff_get(heff_dup(v_acc_243), LBL_tests);
  V v_t_2412 = heff_intEq(heff_dup(v_tests_2411), MK_INT(0LL));
  V v_t_2414;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_tests_2411);
    v_t_2414 = ((V)&g_heff_2ecommands_2etestCmd_24s594351318x1837481428_str0);
    break;
  }
  case TAG_False: {
    V v_t_2413 = heff_intSub(heff_dup(v_tests_2411), heff_get(heff_dup(v_acc_243), LBL_testsFailed));
    v_t_2414 = heff_strAppend(((V)&g_heff_2ecommands_2etestCmd_24s594351318x1837481428_str1), heff_strAppend(heff_intShow(v_t_2413), heff_strAppend(((V)&g_heff_2ecommands_2etestCmd_24s594351318x1837481428_str2), heff_strAppend(heff_intShow(v_tests_2411), ((V)&g_heff_2ecommands_2etestCmd_24s594351318x1837481428_str3)))));
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_str_2415 = heff_strAppend(heff_intShow(v_t_249), heff_strAppend(((V)&g_heff_2ecommands_2etestCmd_24s594351318x1837481428_str4), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecommands_2etestCmd_24s594351318x1837481428_str5), v_t_2414))));
  V v_c_2423 = heff_clo(g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam1, 2, 1, (V[]){v_str_2415});
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_p_244), heff_clo(g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam2, 1, 3, (V[]){v_acc_243, v_p_244, v_p_245})});
}
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam3(V self, V *args) {
  V v_t_2445 = args[0];
  return v_t_2445;
}
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam6(V self, V *args) {
  V v_x_2453 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_x_2450 = heff_env(self)[1];
  V v_tk_240 = heff_env(self)[2];
  V v_seed_241 = heff_env(self)[3];
  V v_rest_2444 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2453);
  V v_t_2454 = heff_intAdd(heff_get(heff_dup(v_acc_243), LBL_total), heff_get(heff_dup(v_x_2450), LBL_total));
  V v_t_2455 = heff_intAdd(heff_get(heff_dup(v_acc_243), LBL_failed), heff_get(heff_dup(v_x_2450), LBL_failed));
  V v_t_2456 = heff_get(heff_dup(v_acc_243), LBL_ok);
  V v_t_2457;
  switch (heff_tag_of(v_t_2456)) {
  case TAG_True: {
    v_t_2457 = heff_get(heff_dup(v_x_2450), LBL_ok);
    break;
  }
  case TAG_False: {
    v_t_2457 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2456);
  }
  V v_t_2458 = heff_intAdd(heff_get(heff_dup(v_acc_243), LBL_tests), heff_get(heff_dup(v_x_2450), LBL_tests));
  V v_t_2459 = heff_intAdd(heff_get(v_acc_243, LBL_testsFailed), heff_get(v_x_2450, LBL_testsFailed));
  return (g_heff_2ecommands_2etestCmd_24s594351318x1837481428(v_tk_240, v_seed_241, v_rest_2444, heff_rec(5, shape_total__failed__ok__tests__testsFailed, (V[]){v_t_2454, v_t_2455, v_t_2457, v_t_2458, v_t_2459}), v_p_244, v_p_245));
}
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_tk_240 = heff_env(self)[3];
  V v_seed_241 = heff_env(self)[4];
  V v_rest_2444 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2451 = heff_tag(TAG_End, 2, (V[]){v_x_2448, NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tr(heff_apply(heff_get(heff_dup(v_p_244), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2451})}));
  return heff_tail(heff_get(heff_dup(v_p_244), LBL_bind), 2, (V[]){v_t_2452, heff_clo(g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam6, 1, 7, (V[]){v_acc_243, v_x_2450, v_tk_240, v_seed_241, v_rest_2444, v_p_244, v_p_245})});
}
V g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam4(V self, V *args) {
  V v_x_2448 = args[0];
  V v_seed_241 = heff_env(self)[0];
  V v_f_2443 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_tk_240 = heff_env(self)[4];
  V v_rest_2444 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2449 = (g_heff_2ecommands_2etestOneF_24s48196897x863364522(heff_dup(v_seed_241), v_f_2443));
  return heff_tail(v_c_2449, 2, (V[]){heff_dup(v_p_244), heff_clo(g_heff_2ecommands_2etestCmd_24s594351318x1837481428_lam5, 1, 7, (V[]){v_x_2448, v_p_244, v_acc_243, v_tk_240, v_seed_241, v_rest_2444, v_p_245})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {116, 101, 115, 116, 105, 110, 103}};
V g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_lam1(V self, V *args); static Clo g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_lam1, 1, 0};
V g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_lam0(V self, V *args);
V g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_lam3(V self, V *args);
V g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_lam2(V self, V *args);
Clo g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_entry, 2, 0};

V g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838(V v_seed_240, V v_files_241) {
top: ;
  V v_total_242 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_files_241));
  V v_c_248 = heff_clo(g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_lam0, 2, 1, (V[]){v_total_242});
  return heff_clo(g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_lam2, 2, 3, (V[]){v_c_248, v_seed_240, v_files_241});
}
V g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838(a[0], a[1]);
}
V g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_lam1(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k2_244 = args[1];
  V v_total_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_str0), v_total_242, ((V)&g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_lam1_clo)})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_246}));
  V f_ = heff_get(v_hd_243, LBL_bind);
  args[0] = v_t_247;
  args[1] = v_k2_244;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_seed_240 = heff_env(self)[0];
  V v_files_241 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_rec(5, shape_total__failed__ok__tests__testsFailed, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(0LL), MK_INT(0LL)});
  return (g_heff_2ecommands_2etestCmd_24s594351318x1837481428(v_x_2411, v_seed_240, v_files_241, v_t_2412, v_hd_249, v_k_2410));
}
V g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_lam2(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_files_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo(g_heff_2ecommands_2etestsCmd_24s1343606057x1476430838_lam3, 1, 4, (V[]){v_seed_240, v_files_241, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {45, 45, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_lam2(V self, V *args); static Clo g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_lam2, 1, 0};
V g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_lam1(V self, V *args);
V g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_lam3(V self, V *args);
V g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_lam0(V self, V *args);
Clo g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_entry, 5, 0};

V g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421(V v_file_240, V v_badL_241, V v_cs_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672(heff_dup(v_cs_242), heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_lam0, 1, 5, (V[]){v_cs_242, v_hd_243, v_k_244, heff_dup(v_badL_241), v_file_240})));
}
V g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_lam2(V self, V *args) {
  V v_ok_2425 = args[0];
  return v_ok_2425;
}
V g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_lam1(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_file_240 = heff_env(self)[0];
  V v_str_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){v_file_240, v_str_2422, ((V)&g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_lam2_clo)})});
  V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2423), LBL_malg), 1, (V[]){v_t_2428}));
  V f_ = heff_get(v_hd_2423, LBL_bind);
  args[0] = v_t_2429;
  args[1] = v_k2_2424;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2431)) {
  case TAG_True: {
    heff_drop(v_hd_243);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_2432 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2435}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2436, v_k_244});
  }
  default: return heff_nomatch(v_x_2431);
  }
}
V g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_badL_241 = heff_env(self)[3];
  V v_file_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_245);
  V v_t_246 = (g_heff_2edriver_2elastChecked(v_cs_242));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_cs_242);
    heff_drop(v_badL_241);
    heff_drop(v_file_240);
    V v_t_247 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2410}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2411, v_k_244});
  }
  case TAG_Just: {
    V v_c_2412 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
    V v_t_2413;
    switch (heff_tag_of(v_badL_241)) {
    case TAG_True: {
      heff_drop(v_cs_242);
      v_t_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      v_t_2413 = ({ V a_0 = v_cs_242; V r_ = (g_prelude_2eany_24s827288872x1370860167(a_0)); heff_drop(v_cs_242); r_; });
      break;
    }
    default: heff_nomatch(v_badL_241);
    }
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      heff_drop(v_file_240);
      heff_drop(v_c_2412);
      V v_t_2414 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2415 = heff_tag_at(v_ru_24t_246_24Just, TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2417}));
      return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2418, v_k_244});
    }
    case TAG_False: {
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      V v_t_2419 = heff_get(heff_get(heff_dup(v_c_2412), LBL_top), LBL_watches);
      V v_xs_2420 = (g_heff_2edriver_2ewatchesGo(heff_dup(v_c_2412), MK_INT(0LL), v_t_2419));
      V v_t_2421 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2420));
      V v_str_2422 = ({ V a_0 = ((V)&g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_str0); V a_1 = ((V)&g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_str1); V a_2 = MK_INT(0LL); V a_3 = heff_get(v_c_2412, LBL_source); V a_4 = v_t_2421; V r_ = (g_prelude_2efoldl_24s809825463x1159518974(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2421); r_; });
      V v_c_2430 = heff_clo(g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_lam1, 2, 2, (V[]){v_file_240, v_str_2422});
      return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421_lam3, 1, 2, (V[]){v_k_244, v_hd_243})});
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam3(V self, V *args);
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam2(V self, V *args);
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam1(V self, V *args);
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam0(V self, V *args);
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam7(V self, V *args);
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam6(V self, V *args);
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam5(V self, V *args);
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam4(V self, V *args);
Clo g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_entry, 1, 0};

V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604(V v_file_240) {
top: ;
  V v_c_241 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  V v_c_2411 = heff_clo(g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam0, 2, 2, (V[]){v_c_241, heff_dup(v_file_240)});
  return heff_clo(g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam4, 2, 2, (V[]){v_c_2411, v_file_240});
}
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604(a[0]);
}
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = ({ V a_0 = v_x_248; V a_1 = heff_get(heff_dup(v_x_246), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_248); r_; });
  V v_x_2410 = (g_prelude_2efoldl_24s1838030138x788027388(v_x_246, v_t_249));
  V f_ = v_k_243;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_247 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_247, 2, (V[]){v_hd_242, heff_clo(g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam3, 1, 2, (V[]){v_x_246, v_k_243})});
}
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(v_x_244, v_file_240));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam2, 1, 2, (V[]){v_hd_242, v_k_243})});
}
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo(g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam1, 1, 3, (V[]){v_file_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam7(V self, V *args) {
  V v_x_2417 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_hd_2412 = heff_env(self)[2];
  V v_k_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_file_240; V b_1 = heff_intLt(MK_INT(0LL), v_x_2415); V a_2 = v_x_2417; V a_3 = v_hd_2412; V a_4 = v_k_2413; V r_ = (g_heff_2ecommands_2epromoteDiags_24s193738686x1312178421(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
}
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam6(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_k_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2416 = (g_heff_2esession_2ecachedProgram_24s595918180x507103762(v_x_2414));
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_2412), heff_clo(g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam7, 1, 4, (V[]){v_file_240, v_x_2415, v_hd_2412, v_k_2413})});
}
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(((V)&g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_str0), heff_get(heff_dup(v_x_2414), LBL_errors), MK_INT(0LL), heff_dup(v_hd_2412), heff_clo(g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam6, 1, 4, (V[]){v_x_2414, v_hd_2412, v_file_240, v_k_2413})));
}
V g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam4(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo(g_heff_2ecommands_2epromoteCmd_24s1141850461x651086604_lam5, 1, 3, (V[]){v_hd_2412, v_file_240, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam3(V self, V *args);
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam0(V self, V *args);
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam7(V self, V *args);
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam6(V self, V *args);
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam5(V self, V *args);
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam4(V self, V *args);
Clo g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_entry, 5, 0};

V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221(V v_host_240, V v_name_241, V v_outPath_242, V v_file_243, V v_done_244) {
top: ;
  V v_c_245 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  V v_c_2415 = heff_clo(g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam0, 2, 2, (V[]){v_c_245, heff_dup(v_file_243)});
  return heff_clo(g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam4, 2, 6, (V[]){v_c_2415, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244});
}
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecompileThen_24s156302470x1672466221(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = ({ V a_0 = v_x_2412; V a_1 = heff_get(heff_dup(v_x_2410), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_2412); r_; });
  V v_x_2414 = (g_prelude_2efoldl_24s1838030138x788027388(v_x_2410, v_t_2413));
  V f_ = v_k_247;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2411 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_2411, 2, (V[]){v_hd_246, heff_clo(g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam3, 1, 2, (V[]){v_x_2410, v_k_247})});
}
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_file_243 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(v_x_248, v_file_243));
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam2, 1, 2, (V[]){v_hd_246, v_k_247})});
}
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_file_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo(g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam1, 1, 3, (V[]){v_file_243, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_x_2419 = heff_env(self)[6];
  V v_hd_2416 = heff_env(self)[7];
  V v_k_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return ({ V b_0 = heff_get(v_x_2418, LBL_sources); V a_1 = v_host_240; V a_2 = v_file_243; V a_3 = v_name_241; V a_4 = v_outPath_242; V a_5 = v_done_244; V b_6 = heff_intLt(MK_INT(0LL), v_x_2419); V a_7 = v_x_2421; V a_8 = v_hd_2416; V a_9 = v_k_2417; V r_ = (g_heff_2ecommands_2ecompileDiags_24s921303827x759049455(b_0, a_1, a_2, a_3, a_4, a_5, b_6, a_7, a_8, a_9)); heff_drop(b_0); heff_drop(b_6); r_; });
}
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_hd_2416 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  V v_file_243 = heff_env(self)[3];
  V v_name_241 = heff_env(self)[4];
  V v_outPath_242 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_k_2417 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2420 = (g_heff_2esession_2ecachedProgram_24s595918180x507103762(heff_dup(v_x_2418)));
  return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_hd_2416), heff_clo(g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam7, 1, 9, (V[]){v_x_2418, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_x_2419, v_hd_2416, v_k_2417})});
}
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_k_2417 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(((V)&g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_str0), heff_get(heff_dup(v_x_2418), LBL_errors), MK_INT(0LL), heff_dup(v_hd_2416), heff_clo(g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam6, 1, 8, (V[]){v_x_2418, v_hd_2416, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_2417})));
}
V g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam4(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo(g_heff_2ecommands_2ecompileThen_24s156302470x1672466221_lam5, 1, 7, (V[]){v_hd_2416, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_lam0(V self, V *args); static Clo g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_lam0, 1, 0};
V g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_lam1(V self, V *args);
Clo g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_entry, 5, 0};

V g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292(V v_outPath_240, V v_bad_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag(TAG_WriteFile, 3, (V[]){v_outPath_240, heff_get(heff_dup(v_o_242), LBL_source), ((V)&g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_lam0_clo)});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_248})}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_lam1, 1, 4, (V[]){v_o_242, v_hd_243, heff_dup(v_bad_241), v_k_244})});
}
V g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_lam0(V self, V *args) {
  V v_ok_245 = args[0];
  return v_ok_245;
}
V g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_o_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2411);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_True: {
    switch (heff_tag_of(v_bad_241)) {
    case TAG_True: {
      heff_drop(v_o_242);
      V v_t_2412 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2415}));
      return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2416, v_k_244});
    }
    case TAG_False: {
      V v_t_2417 = heff_get(v_o_242, LBL_errors);
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Nil: {
        heff_drop(v_hd_243);
        V f_ = v_k_244;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        V v_ru_24t_2417_24Cons = heff_take_reuse_n(v_t_2417, 0ULL, 2);
        V v_t_2420 = heff_tag_at(v_ru_24t_2417_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2421 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
        V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
        V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2423}));
        return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2424, v_k_244});
      }
      default: return heff_nomatch(v_t_2417);
      }
    }
    default: return heff_nomatch(v_bad_241);
    }
  }
  case TAG_False: {
    heff_drop(v_bad_241);
    heff_drop(v_o_242);
    V v_t_2425 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2428}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2429, v_k_244});
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_bad_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecommands_2eemitErrs_24s852800528x545365095(heff_get(heff_dup(v_o_242), LBL_errors), heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292_lam2, 1, 5, (V[]){v_x_2410, v_bad_241, v_hd_243, v_k_244, v_o_242})));
}
V g_heff_2ecommands_2ecompileJsDiags_24s1851946979x681440696_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecompileJsDiags_24s1851946979x681440696_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileJsDiags_24s1851946979x681440696_entry, 6, 0};

V g_heff_2ecommands_2ecompileJsDiags_24s1851946979x681440696(V v_file_240, V v_outPath_241, V v_badL_242, V v_cs_243, V v_hd_244, V v_k_245) {
top: ;
  return (g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672(heff_dup(v_cs_243), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ecompileJsDiags_24s1851946979x681440696_lam0, 1, 5, (V[]){v_cs_243, v_hd_244, v_k_245, heff_dup(v_badL_242), v_outPath_241})));
}
V g_heff_2ecommands_2ecompileJsDiags_24s1851946979x681440696_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileJsDiags_24s1851946979x681440696(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); heff_drop(a[2]); return r;
}
V g_heff_2ecommands_2ecompileJsDiags_24s1851946979x681440696_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_badL_242 = heff_env(self)[3];
  V v_outPath_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_246);
  V v_t_247 = (g_heff_2edriver_2elastChecked(v_cs_243));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_cs_243);
    heff_drop(v_badL_242);
    heff_drop(v_outPath_241);
    V v_t_248 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2411}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2412, v_k_245});
  }
  case TAG_Just: {
    V v_c_2413 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_badL_242)) {
    case TAG_True: {
      heff_drop(v_cs_243);
      v_t_2414 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      v_t_2414 = ({ V a_0 = v_cs_243; V r_ = (g_prelude_2eany_24s827288872x1370860167(a_0)); heff_drop(v_cs_243); r_; });
      break;
    }
    default: heff_nomatch(v_badL_242);
    }
    V v_t_2415 = heff_get(heff_get(heff_dup(v_c_2413), LBL_top), LBL_globals);
    V v_t_2416 = (g_prelude_2emap_24s546221959x1645923250(heff_get(v_c_2413, LBL_own)));
    V v_t_2417 = (g_heff_2eemit_2ecompileJs(v_t_2415, v_t_2416));
    return ({ V a_0 = v_outPath_241; V a_1 = v_t_2414; V a_2 = v_t_2417; V a_3 = v_hd_244; V a_4 = v_k_245; V r_ = (g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2414); r_; });
  }
  default: return heff_nomatch(v_t_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam3(V self, V *args);
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam0(V self, V *args);
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam7(V self, V *args);
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam6(V self, V *args);
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam5(V self, V *args);
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam4(V self, V *args);
Clo g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_entry, 2, 0};

V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856(V v_file_240, V v_outPath_241) {
top: ;
  V v_c_242 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  V v_c_2412 = heff_clo(g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam0, 2, 2, (V[]){v_c_242, heff_dup(v_file_240)});
  return heff_clo(g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam4, 2, 3, (V[]){v_c_2412, v_file_240, v_outPath_241});
}
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856(a[0], a[1]);
}
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = ({ V a_0 = v_x_249; V a_1 = heff_get(heff_dup(v_x_247), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_249); r_; });
  V v_x_2411 = (g_prelude_2efoldl_24s1838030138x788027388(v_x_247, v_t_2410));
  V f_ = v_k_244;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_248 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_248, 2, (V[]){v_hd_243, heff_clo(g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam3, 1, 2, (V[]){v_x_247, v_k_244})});
}
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246 = (g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(v_x_245, v_file_240));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam2, 1, 2, (V[]){v_hd_243, v_k_244})});
}
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo(g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam1, 1, 3, (V[]){v_file_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam7(V self, V *args) {
  V v_x_2418 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_outPath_241 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_file_240; V a_1 = v_outPath_241; V b_2 = heff_intLt(MK_INT(0LL), v_x_2416); V a_3 = v_x_2418; V a_4 = v_hd_2413; V a_5 = v_k_2414; V r_ = (g_heff_2ecommands_2ecompileJsDiags_24s1851946979x681440696(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(v_file_240); heff_drop(b_2); r_; });
}
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2417 = (g_heff_2esession_2ecachedProgram_24s595918180x507103762(v_x_2415));
  return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam7, 1, 5, (V[]){v_file_240, v_outPath_241, v_x_2416, v_hd_2413, v_k_2414})});
}
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_outPath_241 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(((V)&g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_str0), heff_get(heff_dup(v_x_2415), LBL_errors), MK_INT(0LL), heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam6, 1, 5, (V[]){v_x_2415, v_hd_2413, v_file_240, v_outPath_241, v_k_2414})));
}
V g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam4(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_outPath_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo(g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856_lam5, 1, 4, (V[]){v_hd_2413, v_file_240, v_outPath_241, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_str1 = {{0x80000000u, K_STR, 0}, 11, 11, {46, 112, 114, 111, 118, 105, 100, 101, 114, 46, 99}};
V g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam0, 2, 0};
V g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam2(V self, V *args); static Clo g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam2, 1, 0};
V g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam1(V self, V *args);
V g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam4(V self, V *args);
V g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam3(V self, V *args);
Clo g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_entry, 2, 0};

V g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493(V v_sources_240, V v_m_241) {
top: ;
  V v_t_242 = (g_heff_2ecommands_2epathOfModule(v_sources_240, heff_dup(v_m_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    return ((V)&g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam0_clo);
  }
  case TAG_Just: {
    V v_path_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
    V v_t_247 = heff_strSlice(heff_dup(v_path_245), v_t_246, heff_strLength(heff_dup(v_path_245)));
    V v_t_248 = heff_strEq(v_t_247, ((V)&g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_str0));
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
      v_t_2410 = heff_strSlice(v_path_245, MK_INT(0LL), v_t_249);
      break;
    }
    case TAG_False: {
      v_t_2410 = v_path_245;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_path_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_str1));
    V v_c_2419 = heff_clo(g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam1, 2, 1, (V[]){v_path_2411});
    return heff_clo(g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam3, 2, 2, (V[]){v_c_2419, v_m_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_path_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam2_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2417}));
  V f_ = heff_get(v_hd_2412, LBL_bind);
  args[0] = v_t_2418;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2424;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    v_x_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2423 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Just = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    v_x_2424 = heff_tag_at(v_ru_24x_2422_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_module__text, (V[]){v_m_241, v_t_2423})});
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V f_ = v_k_2421;
  args[0] = v_x_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo(g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493_lam4, 1, 2, (V[]){v_m_241, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_lam0, 2, 0};
V g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_lam3(V self, V *args);
V g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_lam2(V self, V *args);
V g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_lam1(V self, V *args);
Clo g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_entry, 2, 0};

V g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ecommands_2ereadProviderC_24s771361992x1650421493(v_sources_240, v_m_244));
    return heff_clo(g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_lam1, 2, 3, (V[]){v_c_246, heff_dup(v_sources_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_x_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_x_2413 = heff_tag(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = ({ V a_0 = v_sources_240; V a_1 = v_rest_245; V r_ = (g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080(a_0, a_1)); heff_drop(v_sources_240); r_; });
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_lam3, 1, 2, (V[]){v_x_249, v_k_248})});
}
V g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 117, 110, 116, 105, 109, 101, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 117, 110, 116, 105, 109, 101, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str5 = {{0x80000000u, K_STR, 0}, 22, 22, {104, 101, 102, 102, 58, 32, 110, 111, 32, 67, 32, 114, 117, 110, 116, 105, 109, 101, 32, 97, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam1(V self, V *args); static Clo g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam1, 1, 0};
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam4(V self, V *args); static Clo g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam4, 1, 0};
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam3(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam6(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam8(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam7(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam5(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam2(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam0(V self, V *args);
Clo g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_entry, 2, 0};

V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2elibDir_24s652053211x1514718967(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612(a[0], a[1]);
}
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam4(V self, V *args) {
  V v_t_2425 = args[0];
  return v_t_2425;
}
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam3(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_path_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2422, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam4_clo)})});
  V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2423), LBL_malg), 1, (V[]){v_t_2428}));
  V f_ = heff_get(v_hd_2423, LBL_bind);
  args[0] = v_t_2429;
  args[1] = v_k2_2424;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam6(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k2_2446 = args[1];
  V v_str_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2447 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2444, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str6)), NTAG(TAG_MkUnit)});
  V v_t_2448 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2445), LBL_malg), 1, (V[]){v_t_2450}));
  V f_ = heff_get(v_hd_2445, LBL_bind);
  args[0] = v_t_2451;
  args[1] = v_k2_2446;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam8(V self, V *args) {
  V v_x_2459 = args[0];
  V v_k_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2459);
  V f_ = v_k_241;
  args[0] = ((V)&g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str7);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam7(V self, V *args) {
  V v_x_2453 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2453);
  V v_t_2454 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2455 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2457}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2458, heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam8, 1, 1, (V[]){v_k_241})});
}
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Nothing: {
    V v_t_2432 = (g_std_2epath_2eparse(v_x_2410, v_x_242));
    V v_t_2433 = (g_std_2epath_2eparse(v_x_2410, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str3)));
    V v_p_2434 = (g_std_2epath_2ejoin_2eonto_240(v_t_2432, v_t_2433));
    V v_t_2435 = ({ V a_0 = heff_get(heff_dup(v_p_2434), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2434), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2436 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2434), LBL_drive), heff_get(v_p_2434, LBL_absolute), v_t_2435});
    V v_a_2437 = (g_std_2epath_2erender(v_x_2410, v_t_2436));
    V v_t_2438 = (g_std_2epath_2eparse(v_x_2410, v_a_2437));
    V v_t_2439 = (g_std_2epath_2eparse(v_x_2410, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str4)));
    V v_p_2440 = (g_std_2epath_2ejoin_2eonto_240(v_t_2438, v_t_2439));
    V v_t_2441 = ({ V a_0 = heff_get(heff_dup(v_p_2440), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2440), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2442 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2440), LBL_drive), heff_get(v_p_2440, LBL_absolute), v_t_2441});
    V v_t_2443 = ({ V a_0 = v_x_2410; V a_1 = v_t_2442; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2410); r_; });
    V v_str_2444 = heff_strAppend(((V)&g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str5), v_t_2443);
    V v_c_2452 = heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam6, 2, 1, (V[]){v_str_2444});
    return heff_tail(v_c_2452, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam7, 1, 2, (V[]){v_hd_240, v_k_241})});
  }
  case TAG_Just: {
    V v_text_2460 = heff_field(v_x_2431, 0);
    heff_take_n(v_x_2431, 1ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_x_242);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_text_2460;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2431);
  }
}
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_strEq(v_x_248, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str0));
  V v_x_2410;
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    v_x_2410 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2410 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_t_2411 = (g_std_2epath_2eparse(v_x_2410, heff_dup(v_x_242)));
  V v_t_2412 = (g_std_2epath_2eparse(v_x_2410, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str1)));
  V v_p_2413 = (g_std_2epath_2ejoin_2eonto_240(v_t_2411, v_t_2412));
  V v_t_2414 = ({ V a_0 = heff_get(heff_dup(v_p_2413), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2413), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2415 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2413), LBL_drive), heff_get(v_p_2413, LBL_absolute), v_t_2414});
  V v_a_2416 = (g_std_2epath_2erender(v_x_2410, v_t_2415));
  V v_t_2417 = (g_std_2epath_2eparse(v_x_2410, v_a_2416));
  V v_t_2418 = (g_std_2epath_2eparse(v_x_2410, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_str2)));
  V v_p_2419 = (g_std_2epath_2ejoin_2eonto_240(v_t_2417, v_t_2418));
  V v_t_2420 = ({ V a_0 = heff_get(heff_dup(v_p_2419), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2419), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2421 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2419), LBL_drive), heff_get(v_p_2419, LBL_absolute), v_t_2420});
  V v_path_2422 = (g_std_2epath_2erender(v_x_2410, v_t_2421));
  V v_c_2430 = heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam3, 2, 1, (V[]){v_path_2422});
  return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam5, 1, 4, (V[]){v_x_2410, v_x_242, v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam1_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_lam2, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam0(V self, V *args); static Clo g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam0, 1, 0};
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam2(V self, V *args);
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam3(V self, V *args); static Clo g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam3, 2, 0};
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam5(V self, V *args); static Clo g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam5, 1, 0};
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam4(V self, V *args);
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam6(V self, V *args);
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam1(V self, V *args);
Clo g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_entry, 5, 0};

V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654(V v_dir_240, V v_parts_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam0_clo)})});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2410})}));
    return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam1, 1, 6, (V[]){v_n_245, heff_dup(v_parts_241), v_dir_240, v_p_243, v_rest_246, v_p_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eremoveStale_24s978725467x1309498654(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam2(V self, V *args) {
  V v_p_2415 = args[0];
  V v_n_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418;
  switch (heff_tag_of(v_p_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_p_2415, 0);
    heff_take_n(v_p_2415, 1ULL, 2);
    v_t_2418 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_p_2415);
  }
  return heff_strEq(v_t_2418, v_n_245);
}
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam5(V self, V *args) {
  V v_ok_2430 = args[0];
  return v_ok_2430;
}
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam4(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k2_2429 = args[1];
  V v_path_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){v_path_2427, ((V)&g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam5_clo)})});
  V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2428), LBL_malg), 1, (V[]){v_t_2433}));
  V f_ = heff_get(v_hd_2428, LBL_bind);
  args[0] = v_t_2434;
  args[1] = v_k2_2429;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2436);
  return ({ V a_0 = v_dir_240; V a_1 = v_parts_241; V a_2 = v_rest_246; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ecommands_2eremoveStale_24s978725467x1309498654(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_241); r_; });
}
V g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_n_245 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2413 = heff_strEq(v_x_2412, ((V)&g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_str0));
  V v_x_2414;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_True: {
    v_x_2414 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2414 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  V v_t_2419 = (g_prelude_2eany(heff_clo(g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam2, 1, 1, (V[]){heff_dup(v_n_245)}), v_parts_241));
  V v_c_2435;
  switch (heff_tag_of(v_t_2419)) {
  case TAG_True: {
    heff_drop(v_n_245);
    heff_drop(v_x_2414);
    v_c_2435 = ((V)&g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam3_clo);
    break;
  }
  case TAG_False: {
    V v_t_2422 = (g_std_2epath_2eparse(v_x_2414, heff_dup(v_dir_240)));
    V v_t_2423 = (g_std_2epath_2eparse(v_x_2414, v_n_245));
    V v_p_2424 = (g_std_2epath_2ejoin_2eonto_240(v_t_2422, v_t_2423));
    V v_t_2425 = ({ V a_0 = heff_get(heff_dup(v_p_2424), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2424), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2426 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2424), LBL_drive), heff_get(v_p_2424, LBL_absolute), v_t_2425});
    V v_path_2427 = ({ V a_0 = v_x_2414; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2414); r_; });
    v_c_2435 = heff_clo(g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam4, 2, 1, (V[]){v_path_2427});
    break;
  }
  default: heff_nomatch(v_t_2419);
  }
  return heff_tail(v_c_2435, 2, (V[]){heff_dup(v_p_243), heff_clo(g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_lam6, 1, 5, (V[]){v_dir_240, v_parts_241, v_rest_246, v_p_243, v_p_244})});
}
V g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_lam0(V self, V *args); static Clo g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_lam0, 1, 0};
V g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_lam1(V self, V *args); static Clo g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_lam1, 1, 0};
Clo g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_entry, 5, 0};

V g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448(V v_path_240, V v_text_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){v_path_240, v_text_241, ((V)&g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_lam0_clo)})});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_248}));
    return heff_tail(heff_get(v_p_243, LBL_bind), 2, (V[]){v_t_249, v_p_244});
  }
  case TAG_Just: {
    V v_was_2410 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_2411 = heff_strEq(v_was_2410, heff_dup(v_text_241));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      heff_drop(v_path_240);
      heff_drop(v_text_241);
      heff_drop(v_p_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_True)});
    }
    case TAG_False: {
      V v_t_2413 = heff_tag_at(v_ru_24x3_242_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){v_path_240, v_text_241, ((V)&g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_lam1_clo)})});
      V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2415}));
      return heff_tail(heff_get(v_p_243, LBL_bind), 2, (V[]){v_t_2416, v_p_244});
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_lam0(V self, V *args) {
  V v_ok_245 = args[0];
  return v_ok_245;
}
V g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_lam1(V self, V *args) {
  V v_ok_2412 = args[0];
  return v_ok_2412;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam0(V self, V *args); static Clo g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam0, 1, 0};
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam3(V self, V *args); static Clo g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam3, 1, 0};
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam2(V self, V *args);
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam5(V self, V *args);
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam4(V self, V *args);
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam1(V self, V *args);
Clo g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_entry, 4, 0};

V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_name_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam0_clo)})});
      V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_p_242), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})}));
      return heff_tail(heff_get(heff_dup(v_p_242), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam1, 1, 6, (V[]){v_dir_240, v_name_246, v_p_242, v_text_247, v_rest_245, v_p_243})});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam3(V self, V *args) {
  V v_t_2424 = args[0];
  return v_t_2424;
}
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k2_2423 = args[1];
  V v_path_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2421, ((V)&g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam3_clo)})});
  V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2422), LBL_malg), 1, (V[]){v_t_2427}));
  V f_ = heff_get(v_hd_2422, LBL_bind);
  args[0] = v_t_2428;
  args[1] = v_k2_2423;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2438)) {
  case TAG_True: {
    return (g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080(v_dir_240, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_False: {
    heff_drop(v_dir_240);
    heff_drop(v_rest_245);
    heff_drop(v_p_242);
    V f_ = v_p_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2438);
  }
}
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_name_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2431 = (g_std_2epath_2eparse(v_x_2415, heff_dup(v_dir_240)));
  V v_t_2432 = (g_std_2epath_2eparse(v_x_2415, v_name_246));
  V v_p_2433 = (g_std_2epath_2ejoin_2eonto_240(v_t_2431, v_t_2432));
  V v_t_2434 = ({ V a_0 = heff_get(heff_dup(v_p_2433), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2433), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2435 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2433), LBL_drive), heff_get(v_p_2433, LBL_absolute), v_t_2434});
  V v_t_2436 = ({ V a_0 = v_x_2415; V a_1 = v_t_2435; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2415); r_; });
  V v_c_2437 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2ewriteChanged_24s1357880141x1442754448_clo), 3, (V[]){v_t_2436, v_text_247, v_x_2430}));
  return heff_tail(v_c_2437, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam5, 1, 4, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243})});
}
V g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_name_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2414 = heff_strEq(v_x_2413, ((V)&g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_str0));
  V v_x_2415;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    v_x_2415 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2415 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_t_2416 = (g_std_2epath_2eparse(v_x_2415, heff_dup(v_dir_240)));
  V v_t_2417 = (g_std_2epath_2eparse(v_x_2415, heff_dup(v_name_246)));
  V v_p_2418 = (g_std_2epath_2ejoin_2eonto_240(v_t_2416, v_t_2417));
  V v_t_2419 = ({ V a_0 = heff_get(heff_dup(v_p_2418), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2418), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2420 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2418), LBL_drive), heff_get(v_p_2418, LBL_absolute), v_t_2419});
  V v_path_2421 = (g_std_2epath_2erender(v_x_2415, v_t_2420));
  V v_c_2429 = heff_clo(g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam2, 2, 1, (V[]){v_path_2421});
  return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080_lam4, 1, 7, (V[]){v_x_2415, v_dir_240, v_name_246, v_text_247, v_p_242, v_rest_245, v_p_243})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2ewriteParts_24s814767795x657824955_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ewriteParts_24s814767795x657824955_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam1(V self, V *args); static Clo g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam1, 1, 0};
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam3(V self, V *args); static Clo g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam3, 1, 0};
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam7(V self, V *args);
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam6(V self, V *args);
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam5(V self, V *args);
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam4(V self, V *args);
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam2(V self, V *args);
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam0(V self, V *args);
Clo g_heff_2ecommands_2ewriteParts_24s814767795x657824955_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteParts_24s814767795x657824955_entry, 5, 0};

V g_heff_2ecommands_2ewriteParts_24s814767795x657824955(V v_dir_240, V v_done_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_parts_245 = heff_field(v_x3_242, 0);
    V v_errors_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    return (g_heff_2ecommands_2eemitErrs_24s852800528x545365095(heff_dup(v_errors_246), heff_dup(v_p_243), heff_clo(g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam0, 1, 6, (V[]){v_errors_246, v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ewriteParts_24s814767795x657824955(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam1(V self, V *args) {
  V v_ok_2411 = args[0];
  return v_ok_2411;
}
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam3(V self, V *args) {
  V v_ns_2417 = args[0];
  return v_ns_2417;
}
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2438}));
  return heff_tail(heff_get(v_p_243, LBL_bind), 2, (V[]){v_t_2439, v_p_244});
}
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_True: {
    heff_drop(v_dir_240);
    return heff_tail(v_done_241, 2, (V[]){v_p_243, v_p_244});
  }
  case TAG_False: {
    heff_drop(v_done_241);
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2ewriteParts_24s814767795x657824955_str0), v_dir_240), ((V)&g_heff_2ecommands_2ewriteParts_24s814767795x657824955_str1));
    V v_t_2429 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2432}));
    return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2433, heff_clo(g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam7, 1, 2, (V[]){v_p_243, v_p_244})});
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2426);
  return (g_heff_2ecommands_2ewritePartsGo_24s1360538462x507313080(heff_dup(v_dir_240), v_parts_245, heff_dup(v_p_243), heff_clo(g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam6, 1, 4, (V[]){v_done_241, v_p_243, v_p_244, v_dir_240})));
}
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2424;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    v_t_2424 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2423 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    v_t_2424 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V v_c_2425 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eremoveStale_24s978725467x1309498654_clo), 3, (V[]){heff_dup(v_dir_240), heff_dup(v_parts_245), v_t_2424}));
  return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_p_243), heff_clo(g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam5, 1, 5, (V[]){v_dir_240, v_parts_245, v_p_243, v_done_241, v_p_244})});
}
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_parts_245 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2416);
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){heff_dup(v_dir_240), ((V)&g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam3_clo)})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2420}));
  return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2421, heff_clo(g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam4, 1, 5, (V[]){v_dir_240, v_parts_245, v_p_243, v_done_241, v_p_244})});
}
V g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_errors_246 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_parts_245 = heff_env(self)[3];
  V v_done_241 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_247);
  V v_t_2410;
  switch (heff_tag_of(v_errors_246)) {
  case TAG_Nil: {
    v_t_2410 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_errors_246, 0ULL, 2);
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_errors_246);
  }
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){heff_dup(v_dir_240), ((V)&g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam1_clo)})});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2414}));
    return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2415, heff_clo(g_heff_2ecommands_2ewriteParts_24s814767795x657824955_lam2, 1, 5, (V[]){v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})});
  }
  case TAG_False: {
    heff_drop(v_dir_240);
    heff_drop(v_parts_245);
    heff_drop(v_done_241);
    V v_t_2440 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2441 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2443}));
    return heff_tail(heff_get(v_p_243, LBL_bind), 2, (V[]){v_t_2444, v_p_244});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
V g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_lam0(V self, V *args);
V g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_lam1(V self, V *args);
Clo g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_entry, 7, 0};

V g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181(V v_file_240, V v_name_241, V v_outPath_242, V v_runtime_243, V v_done_244, V v_c_245, V v_available_246) {
top: ;
  V v_t_247 = (g_heff_2edriver_2ecandidatesOf(heff_dup(v_c_245)));
  V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_heff_2edriver_2enubStrD(v_t_248));
  V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_lam0, 1, 1, (V[]){heff_dup(v_available_246)}), v_t_249));
  V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = heff_dup(v_c_245); V a_2 = v_name_241; V r_ = (g_heff_2edriver_2efindRunnable(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Left: {
    V v_why_2413 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    heff_drop(v_outPath_242);
    heff_drop(v_runtime_243);
    heff_drop(v_done_244);
    heff_drop(v_c_245);
    heff_drop(v_available_246);
    return heff_clo(g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_lam1, 2, 2, (V[]){v_file_240, v_why_2413});
  }
  case TAG_Right: {
    V v_r_2428 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    heff_drop(v_file_240);
    V v_t_2429 = heff_intSub(heff_strLength(heff_dup(v_outPath_242)), MK_INT(1LL));
    V v_t_2430 = heff_strSlice(heff_dup(v_outPath_242), v_t_2429, heff_strLength(heff_dup(v_outPath_242)));
    V v_t_2431 = heff_strEq(v_t_2430, ((V)&g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_str3));
    switch (heff_tag_of(v_t_2431)) {
    case TAG_True: {
      V v_t_2432 = heff_intSub(heff_strLength(heff_dup(v_outPath_242)), MK_INT(1LL));
      V v_t_2433 = heff_get(heff_get(v_c_245, LBL_top), LBL_globals);
      V v_l_2434 = (g_heff_2elower_2elowerProgramAnf(v_t_2433, heff_get(heff_dup(v_r_2428), LBL_key)));
      V v_t_2435 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2erunEnd_clo), 1, (V[]){heff_get(v_r_2428, LBL_effect)}));
      V v_t_2436 = heff_rec(2, shape_prefix__end, (V[]){NTAG(TAG_Nil), v_t_2435});
      V v_t_2437 = (g_heff_2eemitc_2eprogramParts(v_runtime_243, v_available_246, v_t_2436, heff_get(heff_dup(v_l_2434), LBL_defs)));
      V v_t_2438 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2437, heff_get(v_l_2434, LBL_errors)});
      return heff_tail(((V)&g_heff_2ecommands_2ewriteParts_24s814767795x657824955_clo), 3, (V[]){heff_strSlice(v_outPath_242, MK_INT(0LL), v_t_2432), v_done_244, v_t_2438});
    }
    case TAG_False: {
      V v_t_2439 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2erunEnd_clo), 1, (V[]){heff_get(heff_dup(v_r_2428), LBL_effect)}));
      V v_t_2440 = heff_rec(2, shape_prefix__end, (V[]){NTAG(TAG_Nil), v_t_2439});
      V v_t_2441 = heff_get(heff_get(v_c_245, LBL_top), LBL_globals);
      V v_t_2442 = (g_heff_2elower_2elowerProgramAnf(v_t_2441, heff_get(v_r_2428, LBL_key)));
      V v_t_2443 = (g_heff_2eemitc_2eoutputOf(v_runtime_243, v_available_246, v_t_2440, v_t_2442));
      return heff_tail(((V)&g_heff_2ecommands_2ewriteOut_24s522201506x283476832_clo), 3, (V[]){v_outPath_242, v_done_244, v_t_2443});
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_lam0(V self, V *args) {
  V v_k_2410 = args[0];
  V v_available_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_246; V a_1 = v_k_2410; V r_ = (g_heff_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_246); r_; });
}
V g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2426}));
  return heff_tail(heff_get(v_hd_2414, LBL_bind), 2, (V[]){v_t_2427, v_k_2415});
}
V g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_file_240 = heff_env(self)[0];
  V v_why_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_str0), heff_strAppend(v_file_240, heff_strAppend(((V)&g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_str1), v_why_2413)));
  V v_t_2417 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2416, ((V)&g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_str2)), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2420}));
  V f_ = heff_get(heff_dup(v_hd_2414), LBL_bind);
  args[0] = v_t_2421;
  args[1] = heff_clo(g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181_lam2, 1, 2, (V[]){v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_str0 = {{0x80000000u, K_STR, 0}, 15, 15, {110, 111, 32, 102, 105, 108, 101, 115, 32, 103, 105, 118, 101, 110, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
V g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam0(V self, V *args); static Clo g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam0, 2, 0};
V g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam4(V self, V *args);
V g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam3(V self, V *args);
V g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam2(V self, V *args);
Clo g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_entry, 6, 0};

V g_heff_2ecommands_2ecompileLastC_24s448887477x866119762(V v_sources_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_cs_245) {
top: ;
  V v_t_246 = (g_heff_2edriver_2elastChecked(v_cs_245));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_file_241);
    heff_drop(v_name_242);
    heff_drop(v_outPath_243);
    heff_drop(v_done_244);
    return ((V)&g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam0_clo);
  }
  case TAG_Just: {
    V v_c_2420 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    V v_t_2421 = (g_heff_2edriver_2ecandidatesOf(heff_dup(v_c_2420)));
    V v_t_2422 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2421); r_; });
    V v_t_2423 = (g_heff_2edriver_2enubStrD(v_t_2422));
    V v_xs_2424 = (g_prelude_2emap_24s656438675x1758438999(((V)&g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_str1), MK_INT(0LL), ((V)&g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_str2), ((V)&g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_str3), v_t_2423));
    V v_t_2425 = (g_heff_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2424));
    V v_c_2426 = (g_heff_2ecommands_2ereadProvidersC_24s982298092x1425986080(v_sources_240, v_t_2425));
    return heff_clo(g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam2, 2, 6, (V[]){v_c_2426, v_name_242, v_c_2420, v_outPath_243, v_file_241, v_done_244});
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileLastC_24s448887477x866119762(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); heff_drop(a[5]); return r;
}
V g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2419, v_k_248});
}
V g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_t_249 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_str0), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2412}));
  V f_ = heff_get(heff_dup(v_hd_247), LBL_bind);
  args[0] = v_t_2413;
  args[1] = heff_clo(g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam1, 1, 2, (V[]){v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_name_242 = heff_env(self)[0];
  V v_c_2420 = heff_env(self)[1];
  V v_outPath_243 = heff_env(self)[2];
  V v_hd_2427 = heff_env(self)[3];
  V v_k_2428 = heff_env(self)[4];
  V v_file_241 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_x_2429 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_name_242)) {
  case TAG_Nothing: {
    heff_drop(v_file_241);
    heff_drop(v_done_244);
    heff_drop(v_x_2429);
    V v_exports_2432 = (g_prelude_2emap_24s554277126x598800825(heff_get(heff_dup(v_c_2420), LBL_own)));
    V v_roots_2433 = (g_prelude_2emap_24s1448703749x94773476(heff_dup(v_exports_2432)));
    V v_t_2434 = heff_get(heff_get(v_c_2420, LBL_top), LBL_globals);
    V v_t_2435 = (g_heff_2eerase_2eeraseProgram(v_t_2434));
    V v_t_2436 = (g_heff_2elower_2eanfLowered(v_roots_2433, v_t_2435));
    V v_t_2437 = (g_heff_2eemitc_2echeckOut(v_x_2431, v_exports_2432, v_t_2436));
    return ({ V a_0 = v_outPath_243; V b_1 = NTAG(TAG_False); V a_2 = v_t_2437; V a_3 = v_hd_2427; V a_4 = v_k_2428; V r_ = (g_heff_2ecommands_2ecompileJsOut_24s1319381035x1869517292(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  }
  case TAG_Just: {
    V v_t_2439 = heff_tr(g_heff_2ecommands_2ecompileFoundC_24s1928820976x1862558181(v_file_241, v_name_242, v_outPath_243, v_x_2431, v_done_244, v_c_2420, v_x_2429));
    return heff_tail(v_t_2439, 2, (V[]){v_hd_2427, v_k_2428});
  }
  default: return heff_nomatch(v_name_242);
  }
}
V g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2427 = heff_env(self)[0];
  V v_name_242 = heff_env(self)[1];
  V v_c_2420 = heff_env(self)[2];
  V v_outPath_243 = heff_env(self)[3];
  V v_k_2428 = heff_env(self)[4];
  V v_file_241 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2430 = ((V)&g_heff_2ecommands_2ereadRuntimeC_24s2007722518x315613612_clo);
  return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_hd_2427), heff_clo(g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam4, 1, 8, (V[]){v_name_242, v_c_2420, v_outPath_243, v_hd_2427, v_k_2428, v_file_241, v_done_244, v_x_2429})});
}
V g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam2(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  V v_name_242 = heff_env(self)[1];
  V v_c_2420 = heff_env(self)[2];
  V v_outPath_243 = heff_env(self)[3];
  V v_file_241 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2426;
  args[0] = heff_dup(v_hd_2427);
  args[1] = heff_clo(g_heff_2ecommands_2ecompileLastC_24s448887477x866119762_lam3, 1, 7, (V[]){v_hd_2427, v_name_242, v_c_2420, v_outPath_243, v_k_2428, v_file_241, v_done_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecThen_24s903897371x1471440451_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam3(V self, V *args);
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam2(V self, V *args);
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam1(V self, V *args);
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam0(V self, V *args);
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam8(V self, V *args);
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam7(V self, V *args);
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam6(V self, V *args);
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam5(V self, V *args);
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam4(V self, V *args);
Clo g_heff_2ecommands_2ecThen_24s903897371x1471440451_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecThen_24s903897371x1471440451_entry, 4, 0};

V g_heff_2ecommands_2ecThen_24s903897371x1471440451(V v_name_240, V v_outPath_241, V v_file_242, V v_done_243) {
top: ;
  V v_c_244 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  V v_c_2414 = heff_clo(g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam0, 2, 2, (V[]){v_c_244, heff_dup(v_file_242)});
  return heff_clo(g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam4, 2, 5, (V[]){v_c_2414, v_file_242, v_name_240, v_outPath_241, v_done_243});
}
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecThen_24s903897371x1471440451(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = ({ V a_0 = v_x_2411; V a_1 = heff_get(heff_dup(v_x_249), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_2411); r_; });
  V v_x_2413 = (g_prelude_2efoldl_24s1838030138x788027388(v_x_249, v_t_2412));
  V f_ = v_k_246;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2410 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_2410, 2, (V[]){v_hd_245, heff_clo(g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam3, 1, 2, (V[]){v_x_249, v_k_246})});
}
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_248 = (g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(v_x_247, v_file_242));
  return heff_tail(v_c_248, 2, (V[]){heff_dup(v_hd_245), heff_clo(g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam2, 1, 2, (V[]){v_hd_245, v_k_246})});
}
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo(g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam1, 1, 3, (V[]){v_file_242, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam8(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  V v_file_242 = heff_env(self)[5];
  V v_name_240 = heff_env(self)[6];
  V v_outPath_241 = heff_env(self)[7];
  V v_done_243 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_intLt(MK_INT(0LL), v_x_2418);
  switch (heff_tag_of(v_t_2422)) {
  case TAG_True: {
    heff_drop(v_x_2420);
    heff_drop(v_x_2417);
    heff_drop(v_file_242);
    heff_drop(v_name_240);
    heff_drop(v_outPath_241);
    heff_drop(v_done_243);
    V v_t_2423 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2415), LBL_malg), 1, (V[]){v_t_2426}));
    return heff_tail(heff_get(v_hd_2415, LBL_bind), 2, (V[]){v_t_2427, v_k_2416});
  }
  case TAG_False: {
    V v_t_2428 = (g_prelude_2eany_24s827288872x1370860167(v_x_2420));
    switch (heff_tag_of(v_t_2428)) {
    case TAG_True: {
      heff_drop(v_x_2420);
      heff_drop(v_x_2417);
      heff_drop(v_file_242);
      heff_drop(v_name_240);
      heff_drop(v_outPath_241);
      heff_drop(v_done_243);
      V v_t_2429 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2430 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2415), LBL_malg), 1, (V[]){v_t_2432}));
      return heff_tail(heff_get(v_hd_2415, LBL_bind), 2, (V[]){v_t_2433, v_k_2416});
    }
    case TAG_False: {
      V v_t_2434 = ({ V b_0 = heff_get(v_x_2417, LBL_sources); V a_1 = v_file_242; V a_2 = v_name_240; V a_3 = v_outPath_241; V a_4 = v_done_243; V a_5 = v_x_2420; V r_ = (g_heff_2ecommands_2ecompileLastC_24s448887477x866119762(b_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(b_0); heff_drop(v_x_2420); r_; });
      return heff_tail(v_t_2434, 2, (V[]){v_hd_2415, v_k_2416});
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
  default: return heff_nomatch(v_t_2422);
  }
}
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam7(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_x_2418 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_file_242 = heff_env(self)[4];
  V v_name_240 = heff_env(self)[5];
  V v_outPath_241 = heff_env(self)[6];
  V v_done_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672(heff_dup(v_x_2420), heff_dup(v_hd_2415), heff_clo(g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam8, 1, 9, (V[]){v_x_2418, v_hd_2415, v_k_2416, v_x_2420, v_x_2417, v_file_242, v_name_240, v_outPath_241, v_done_243})));
}
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_name_240 = heff_env(self)[4];
  V v_outPath_241 = heff_env(self)[5];
  V v_done_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2419 = (g_heff_2esession_2ecachedProgram_24s595918180x507103762(heff_dup(v_x_2417)));
  return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_hd_2415), heff_clo(g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam7, 1, 8, (V[]){v_hd_2415, v_x_2418, v_k_2416, v_x_2417, v_file_242, v_name_240, v_outPath_241, v_done_243})});
}
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_outPath_241 = heff_env(self)[4];
  V v_done_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(((V)&g_heff_2ecommands_2ecThen_24s903897371x1471440451_str0), heff_get(heff_dup(v_x_2417), LBL_errors), MK_INT(0LL), heff_dup(v_hd_2415), heff_clo(g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam6, 1, 7, (V[]){v_x_2417, v_hd_2415, v_k_2416, v_file_242, v_name_240, v_outPath_241, v_done_243})));
}
V g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam4(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo(g_heff_2ecommands_2ecThen_24s903897371x1471440451_lam5, 1, 6, (V[]){v_hd_2415, v_k_2416, v_file_242, v_name_240, v_outPath_241, v_done_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecCmd_24s724601688x1192044019_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ecCmd_24s724601688x1192044019_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {42, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecCmd_24s724601688x1192044019_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {119, 114, 111, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[28]; } g_heff_2ecommands_2ecCmd_24s724601688x1192044019_str3 = {{0x80000000u, K_STR, 0}, 28, 28, {58, 32, 98, 117, 105, 108, 100, 32, 105, 116, 32, 119, 105, 116, 104, 32, 96, 122, 105, 103, 32, 99, 99, 32, 45, 79, 50, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2ecCmd_24s724601688x1192044019_str4 = {{0x80000000u, K_STR, 0}, 12, 12, {32, 45, 111, 32, 80, 82, 79, 71, 82, 65, 77, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecCmd_24s724601688x1192044019_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ecCmd_24s724601688x1192044019_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecCmd_24s724601688x1192044019_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecCmd_24s724601688x1192044019_entry, 3, 0};

V g_heff_2ecommands_2ecCmd_24s724601688x1192044019(V v_name_240, V v_outPath_241, V v_file_242) {
top: ;
  V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_outPath_241)), MK_INT(1LL));
  V v_t_244 = heff_strSlice(heff_dup(v_outPath_241), v_t_243, heff_strLength(heff_dup(v_outPath_241)));
  V v_t_245 = heff_strEq(v_t_244, ((V)&g_heff_2ecommands_2ecCmd_24s724601688x1192044019_str0));
  V v_t_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_t_246 = heff_strAppend(heff_dup(v_outPath_241), ((V)&g_heff_2ecommands_2ecCmd_24s724601688x1192044019_str1));
    break;
  }
  case TAG_False: {
    v_t_246 = heff_dup(v_outPath_241);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_str_247 = heff_strAppend(((V)&g_heff_2ecommands_2ecCmd_24s724601688x1192044019_str2), heff_strAppend(heff_dup(v_outPath_241), heff_strAppend(((V)&g_heff_2ecommands_2ecCmd_24s724601688x1192044019_str3), heff_strAppend(v_t_246, ((V)&g_heff_2ecommands_2ecCmd_24s724601688x1192044019_str4)))));
  return (g_heff_2ecommands_2ecThen_24s903897371x1471440451(v_name_240, v_outPath_241, v_file_242, heff_clo(g_heff_2ecommands_2ecCmd_24s724601688x1192044019_lam0, 2, 1, (V[]){v_str_247})));
}
V g_heff_2ecommands_2ecCmd_24s724601688x1192044019_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecCmd_24s724601688x1192044019(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2ecCmd_24s724601688x1192044019_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k2_249 = args[1];
  V v_str_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_247, ((V)&g_heff_2ecommands_2ecCmd_24s724601688x1192044019_str5)), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2413}));
  V f_ = heff_get(v_hd_248, LBL_bind);
  args[0] = v_t_2414;
  args[1] = v_k2_249;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {119, 114, 111, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str4 = {{0x80000000u, K_STR, 0}, 18, 18, {114, 117, 110, 32, 105, 116, 32, 119, 105, 116, 104, 32, 96, 110, 111, 100, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str5 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 65, 82, 71, 83, 46, 46, 46, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str9 = {{0x80000000u, K_STR, 0}, 6, 6, {119, 114, 111, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[91]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str10 = {{0x80000000u, K_STR, 0}, 91, 91, {58, 32, 108, 111, 97, 100, 32, 105, 116, 32, 105, 110, 32, 97, 32, 112, 97, 103, 101, 32, 119, 105, 116, 104, 32, 60, 115, 99, 114, 105, 112, 116, 32, 115, 114, 99, 61, 34, 46, 46, 46, 34, 62, 32, 40, 105, 116, 32, 105, 109, 112, 111, 114, 116, 115, 32, 110, 111, 116, 104, 105, 110, 103, 58, 32, 105, 116, 32, 111, 112, 101, 110, 115, 32, 102, 114, 111, 109, 32, 102, 105, 108, 101, 58, 47, 47, 32, 116, 111, 111, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str12 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 115, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[70]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str13 = {{0x80000000u, K_STR, 0}, 70, 70, {104, 101, 102, 102, 32, 99, 111, 109, 112, 105, 108, 101, 58, 32, 97, 110, 32, 69, 83, 32, 109, 111, 100, 117, 108, 101, 32, 114, 117, 110, 115, 32, 110, 111, 116, 104, 105, 110, 103, 58, 32, 110, 111, 32, 45, 45, 110, 97, 109, 101, 32, 119, 105, 116, 104, 32, 45, 45, 98, 97, 99, 107, 101, 110, 100, 61, 101, 115, 109, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str15 = {{0x80000000u, K_STR, 0}, 25, 25, {104, 101, 102, 102, 32, 99, 111, 109, 112, 105, 108, 101, 58, 32, 110, 111, 32, 98, 97, 99, 107, 101, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str16 = {{0x80000000u, K_STR, 0}, 22, 22, {58, 32, 101, 115, 109, 44, 32, 112, 97, 103, 101, 44, 32, 110, 111, 100, 101, 32, 111, 114, 32, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam0(V self, V *args);
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam3(V self, V *args);
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam2(V self, V *args); static Clo g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam2, 2, 0};
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam5(V self, V *args);
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam4(V self, V *args);
Clo g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_entry, 1, 0};

V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572(V v_o_240) {
top: ;
  V v_t_241 = heff_strEq(heff_get(heff_dup(v_o_240), LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    V v_outPath_242 = heff_get(heff_dup(v_o_240), LBL_outPath);
    return (g_heff_2ecommands_2ecompileThen_24s156302470x1672466221(((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str1), heff_get(heff_dup(v_o_240), LBL_name), heff_dup(v_outPath_242), heff_get(v_o_240, LBL_file), heff_clo(g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam0, 2, 1, (V[]){v_outPath_242})));
  }
  case TAG_False: {
    V v_t_2411 = heff_strEq(heff_get(heff_dup(v_o_240), LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str7));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      V v_outPath_2412 = heff_get(heff_dup(v_o_240), LBL_outPath);
      return (g_heff_2ecommands_2ecompileThen_24s156302470x1672466221(((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str8), heff_get(heff_dup(v_o_240), LBL_name), heff_dup(v_outPath_2412), heff_get(v_o_240, LBL_file), heff_clo(g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam1, 2, 1, (V[]){v_outPath_2412})));
    }
    case TAG_False: {
      V v_t_2421 = heff_strEq(heff_get(heff_dup(v_o_240), LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str12));
      switch (heff_tag_of(v_t_2421)) {
      case TAG_True: {
        V v_t_2422 = heff_get(heff_dup(v_o_240), LBL_name);
        switch (heff_tag_of(v_t_2422)) {
        case TAG_Nothing: {
          return (g_heff_2ecommands_2ecompileJsCmd_24s1872655077x89964856(heff_get(heff_dup(v_o_240), LBL_file), heff_get(v_o_240, LBL_outPath)));
        }
        case TAG_Just: {
          heff_take_n(v_t_2422, 0ULL, 1);
          heff_drop(v_o_240);
          return ((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam2_clo);
        }
        default: return heff_nomatch(v_t_2422);
        }
      }
      case TAG_False: {
        V v_t_2437 = heff_strEq(heff_get(heff_dup(v_o_240), LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str14));
        switch (heff_tag_of(v_t_2437)) {
        case TAG_True: {
          return (g_heff_2ecommands_2ecCmd_24s724601688x1192044019(heff_get(heff_dup(v_o_240), LBL_name), heff_get(heff_dup(v_o_240), LBL_outPath), heff_get(v_o_240, LBL_file)));
        }
        case TAG_False: {
          return heff_clo(g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam4, 2, 1, (V[]){v_o_240});
        }
        default: return heff_nomatch(v_t_2437);
        }
      }
      default: return heff_nomatch(v_t_2421);
      }
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecompileTo_24s1529513209x792324572(a[0]);
}
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k2_244 = args[1];
  V v_outPath_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str2), heff_strAppend(heff_dup(v_outPath_242), heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str3), heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str4), heff_strAppend(v_outPath_242, ((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str5))))));
  V v_t_246 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str6)), NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_249}));
  V f_ = heff_get(v_hd_243, LBL_bind);
  args[0] = v_t_2410;
  args[1] = v_k2_244;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_outPath_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str9), heff_strAppend(v_outPath_2412, ((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str10)));
  V v_t_2416 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2415, ((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str11)), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2419}));
  V f_ = heff_get(v_hd_2413, LBL_bind);
  args[0] = v_t_2420;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_2424 = heff_env(self)[0];
  V v_k_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2431);
  V v_t_2432 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2424), LBL_malg), 1, (V[]){v_t_2435}));
  return heff_tail(heff_get(v_hd_2424, LBL_bind), 2, (V[]){v_t_2436, v_k_2425});
}
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_t_2426 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str13), NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2424), LBL_malg), 1, (V[]){v_t_2429}));
  V f_ = heff_get(heff_dup(v_hd_2424), LBL_bind);
  args[0] = v_t_2430;
  args[1] = heff_clo(g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam3, 1, 2, (V[]){v_hd_2424, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam5(V self, V *args) {
  V v_x_2446 = args[0];
  V v_hd_2438 = heff_env(self)[0];
  V v_k_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2446);
  V v_t_2447 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2448 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2438), LBL_malg), 1, (V[]){v_t_2450}));
  return heff_tail(heff_get(v_hd_2438, LBL_bind), 2, (V[]){v_t_2451, v_k_2439});
}
V g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam4(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_o_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str15), heff_strAppend(heff_get(v_o_240, LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str16)));
  V v_t_2441 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2440, ((V)&g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_str17)), NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2438), LBL_malg), 1, (V[]){v_t_2444}));
  V f_ = heff_get(heff_dup(v_hd_2438), LBL_bind);
  args[0] = v_t_2445;
  args[1] = heff_clo(g_heff_2ecommands_2ecompileTo_24s1529513209x792324572_lam5, 1, 2, (V[]){v_hd_2438, v_k_2439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintLines_24s1854861431x875412566_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintLines_24s1854861431x875412566_lam0(V self, V *args);
Clo g_heff_2ecommands_2eprintLines_24s1854861431x875412566_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintLines_24s1854861431x875412566_entry, 3, 0};

V g_heff_2ecommands_2eprintLines_24s1854861431x875412566(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_243, ((V)&g_heff_2ecommands_2eprintLines_24s1854861431x875412566_str0)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_248}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2eprintLines_24s1854861431x875412566_lam0, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprintLines_24s1854861431x875412566_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eprintLines_24s1854861431x875412566(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eprintLines_24s1854861431x875412566_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2410);
  return (g_heff_2ecommands_2eprintLines_24s1854861431x875412566(v_rest_244, v_p_241, v_p_242));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam3(V self, V *args);
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam2(V self, V *args);
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam1(V self, V *args);
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam0(V self, V *args);
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam8(V self, V *args);
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam7(V self, V *args);
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam6(V self, V *args);
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam5(V self, V *args);
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam4(V self, V *args);
Clo g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_entry, 1, 0};

V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381(V v_file_240) {
top: ;
  V v_c_241 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  V v_c_2411 = heff_clo(g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam0, 2, 2, (V[]){v_c_241, v_file_240});
  return heff_clo(g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam4, 2, 1, (V[]){v_c_2411});
}
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eexplainCmd_24s901348957x426363381(a[0]);
}
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = ({ V a_0 = v_x_248; V a_1 = heff_get(heff_dup(v_x_246), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_248); r_; });
  V v_x_2410 = (g_prelude_2efoldl_24s1838030138x788027388(v_x_246, v_t_249));
  V f_ = v_k_243;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_247 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_247, 2, (V[]){v_hd_242, heff_clo(g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam3, 1, 2, (V[]){v_x_246, v_k_243})});
}
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(v_x_244, v_file_240));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam2, 1, 2, (V[]){v_hd_242, v_k_243})});
}
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo(g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam1, 1, 3, (V[]){v_file_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam8(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2418);
  V v_t_2419 = ({ V a_0 = v_x_2417; V r_ = (g_heff_2edriver_2elastChecked(a_0)); heff_drop(v_x_2417); r_; });
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Nothing: {
    V v_t_2420 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2423}));
    return heff_tail(heff_get(v_hd_2412, LBL_bind), 2, (V[]){v_t_2424, v_k_2413});
  }
  case TAG_Just: {
    V v_c_2425 = heff_field(v_t_2419, 0);
    heff_take_n(v_t_2419, 1ULL, 1);
    V v_t_2426 = (g_heff_2equery_2eexplain(v_c_2425));
    return (g_heff_2ecommands_2eprintLines_24s1854861431x875412566(v_t_2426, v_hd_2412, v_k_2413));
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam7(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672(heff_dup(v_x_2417), heff_dup(v_hd_2412), heff_clo(g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam8, 1, 3, (V[]){v_x_2417, v_hd_2412, v_k_2413})));
}
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam6(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2415);
  V v_c_2416 = (g_heff_2esession_2ecachedProgram_24s595918180x507103762(v_x_2414));
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_2412), heff_clo(g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam7, 1, 2, (V[]){v_hd_2412, v_k_2413})});
}
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(((V)&g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_str0), heff_get(heff_dup(v_x_2414), LBL_errors), MK_INT(0LL), heff_dup(v_hd_2412), heff_clo(g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam6, 1, 3, (V[]){v_x_2414, v_hd_2412, v_k_2413})));
}
V g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam4(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo(g_heff_2ecommands_2eexplainCmd_24s901348957x426363381_lam5, 1, 2, (V[]){v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_str1 = {{0x80000000u, K_STR, 0}, 13, 13, {110, 111, 116, 104, 105, 110, 103, 32, 116, 104, 101, 114, 101}};
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam3(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam2(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam1(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam0(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam9(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam8(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam7(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam6(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam5(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam4(V self, V *args);
Clo g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_entry, 2, 0};

V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198(V v_file_240, V v_offs_241) {
top: ;
  V v_c_242 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  V v_c_2412 = heff_clo(g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam0, 2, 2, (V[]){v_c_242, v_file_240});
  return heff_clo(g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam4, 2, 2, (V[]){v_c_2412, v_offs_241});
}
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198(a[0], a[1]);
}
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = ({ V a_0 = v_x_249; V a_1 = heff_get(heff_dup(v_x_247), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_249); r_; });
  V v_x_2411 = (g_prelude_2efoldl_24s1838030138x788027388(v_x_247, v_t_2410));
  V f_ = v_k_244;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_248 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_248, 2, (V[]){v_hd_243, heff_clo(g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam3, 1, 2, (V[]){v_x_247, v_k_244})});
}
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246 = (g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(v_x_245, v_file_240));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam2, 1, 2, (V[]){v_hd_243, v_k_244})});
}
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo(g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam1, 1, 3, (V[]){v_file_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam9(V self, V *args) {
  V v_off_2427 = args[0];
  V v_c_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = (g_prelude_2eparseInt(v_off_2427));
  V v_x2_2430;
  switch (heff_tag_of(v_t_2428)) {
  case TAG_Nothing: {
    heff_drop(v_c_2426);
    v_x2_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_o_2429 = heff_field(v_t_2428, 0);
    heff_take_n(v_t_2428, 1ULL, 1);
    v_x2_2430 = (g_heff_2equery_2etypeAt(v_c_2426, v_o_2429));
    break;
  }
  default: heff_nomatch(v_t_2428);
  }
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_str1);
  }
  case TAG_Just: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    heff_take_n(v_x2_2430, 1ULL, 1);
    return v_x_2431;
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam8(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  V v_offs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2419);
  V v_t_2420 = ({ V a_0 = v_x_2418; V r_ = (g_heff_2edriver_2elastChecked(a_0)); heff_drop(v_x_2418); r_; });
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Nothing: {
    heff_drop(v_offs_241);
    V v_t_2421 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2424}));
    return heff_tail(heff_get(v_hd_2413, LBL_bind), 2, (V[]){v_t_2425, v_k_2414});
  }
  case TAG_Just: {
    V v_c_2426 = heff_field(v_t_2420, 0);
    heff_take_n(v_t_2420, 1ULL, 1);
    V v_t_2432 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam9, 1, 1, (V[]){v_c_2426}), v_offs_241));
    return (g_heff_2ecommands_2eprintLines_24s1854861431x875412566(v_t_2432, v_hd_2413, v_k_2414));
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam7(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  V v_offs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672(heff_dup(v_x_2418), heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam8, 1, 4, (V[]){v_x_2418, v_hd_2413, v_k_2414, v_offs_241})));
}
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  V v_offs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2416);
  V v_c_2417 = (g_heff_2esession_2ecachedProgram_24s595918180x507103762(v_x_2415));
  return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam7, 1, 3, (V[]){v_hd_2413, v_k_2414, v_offs_241})});
}
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  V v_offs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(((V)&g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_str0), heff_get(heff_dup(v_x_2415), LBL_errors), MK_INT(0LL), heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam6, 1, 4, (V[]){v_x_2415, v_hd_2413, v_k_2414, v_offs_241})));
}
V g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam4(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo(g_heff_2ecommands_2etypeAtCmd_24s2107774873x2082256198_lam5, 1, 3, (V[]){v_hd_2413, v_k_2414, v_offs_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2efmtSrc_24s136663724x956277246_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2efmtSrc_24s136663724x956277246_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 110, 111, 116, 32, 102, 111, 114, 109, 97, 116, 116, 101, 100, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efmtSrc_24s136663724x956277246_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efmtSrc_24s136663724x956277246_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam1(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam0(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam2(V self, V *args); static Clo g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam2, 2, 0};
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam4(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam3(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam6(V self, V *args); static Clo g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam6, 1, 0};
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam7(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam5(V self, V *args);
Clo g_heff_2ecommands_2efmtSrc_24s136663724x956277246_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtSrc_24s136663724x956277246_entry, 4, 0};

V g_heff_2ecommands_2efmtSrc_24s136663724x956277246(V v_checkOnly_240, V v_f_241, V v_src_242, V v_fix_243) {
top: ;
  V v_t_244 = (g_heff_2efmt_2elayout_2eformatUncheckedIn(v_fix_243, heff_dup(v_src_242)));
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Left: {
    V v_why_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Left = heff_take_reuse_n(v_t_244, 1ULL, 1);
    v_t_247 = heff_tag_at(v_ru_24t_244_24Left, TAG_Left, 1, (V[]){v_why_245});
    break;
  }
  case TAG_Right: {
    V v_out_246 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_t_247 = (g_heff_2eformat_2echeck(heff_dup(v_src_242), v_out_246));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_Left: {
    V v_why_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    heff_drop(v_src_242);
    return heff_clo(g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam0, 2, 2, (V[]){v_f_241, v_why_248});
  }
  case TAG_Right: {
    V v_out_2418 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_t_2419 = heff_strEq(heff_dup(v_out_2418), v_src_242);
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      heff_drop(v_f_241);
      heff_drop(v_out_2418);
      return ((V)&g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam2_clo);
    }
    case TAG_False: {
      switch (heff_tag_of(v_checkOnly_240)) {
      case TAG_True: {
        heff_drop(v_out_2418);
        return heff_clo(g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam3, 2, 1, (V[]){v_f_241});
      }
      case TAG_False: {
        return heff_clo(g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam5, 2, 2, (V[]){v_f_241, v_out_2418});
      }
      default: return heff_nomatch(v_checkOnly_240);
      }
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2efmtSrc_24s136663724x956277246(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2417);
  V f_ = v_k_2410;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_f_241 = heff_env(self)[0];
  V v_why_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecommands_2efmtSrc_24s136663724x956277246_str0), heff_strAppend(v_f_241, heff_strAppend(((V)&g_heff_2ecommands_2efmtSrc_24s136663724x956277246_str1), v_why_248)));
  V v_t_2412 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ecommands_2efmtSrc_24s136663724x956277246_str2)), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2415}));
  V f_ = heff_get(v_hd_249, LBL_bind);
  args[0] = v_t_2416;
  args[1] = heff_clo(g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam1, 1, 1, (V[]){v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2429);
  V f_ = v_k_2423;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_f_241, ((V)&g_heff_2ecommands_2efmtSrc_24s136663724x956277246_str3)), NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2422), LBL_malg), 1, (V[]){v_t_2427}));
  V f_ = heff_get(v_hd_2422, LBL_bind);
  args[0] = v_t_2428;
  args[1] = heff_clo(g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam4, 1, 1, (V[]){v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam6(V self, V *args) {
  V v_ok_2432 = args[0];
  return v_ok_2432;
}
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2437);
  V f_ = v_k_2431;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam5(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_f_241 = heff_env(self)[0];
  V v_out_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){v_f_241, v_out_2418, ((V)&g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam6_clo)})});
  V v_t_2434 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2430), LBL_malg), 1, (V[]){v_t_2435}));
  V f_ = heff_get(v_hd_2430, LBL_bind);
  args[0] = v_t_2436;
  args[1] = heff_clo(g_heff_2ecommands_2efmtSrc_24s136663724x956277246_lam7, 1, 1, (V[]){v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2efmtOne_24s852482434x948630519_str0 = {{0x80000000u, K_STR, 0}, 18, 18, {104, 101, 102, 102, 58, 32, 99, 97, 110, 110, 111, 116, 32, 114, 101, 97, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efmtOne_24s852482434x948630519_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam0(V self, V *args); static Clo g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam0, 1, 0};
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam2(V self, V *args);
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam6(V self, V *args);
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam5(V self, V *args);
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam4(V self, V *args);
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam3(V self, V *args);
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam7(V self, V *args);
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam1(V self, V *args);
Clo g_heff_2ecommands_2efmtOne_24s852482434x948630519_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtOne_24s852482434x948630519_entry, 4, 0};

V g_heff_2ecommands_2efmtOne_24s852482434x948630519(V v_checkOnly_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){heff_dup(v_f_241), ((V)&g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam0_clo)})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam1, 1, 4, (V[]){v_f_241, v_hd_242, v_k_243, heff_dup(v_checkOnly_240)})});
}
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2efmtOne_24s852482434x948630519(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam0(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2416);
  V f_ = v_k_243;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = ({ V a_0 = v_x_2425; V a_1 = heff_get(heff_dup(v_x_2423), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_2425); r_; });
  V v_x_2427 = (g_prelude_2efoldl_24s1838030138x788027388(v_x_2423, v_t_2426));
  V f_ = v_k_2420;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_2419 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2424 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_2424, 2, (V[]){v_hd_2419, heff_clo(g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam6, 1, 2, (V[]){v_x_2423, v_k_2420})});
}
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_2419 = heff_env(self)[1];
  V v_k_2420 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2422 = (g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(v_x_2421, v_f_241));
  return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_hd_2419), heff_clo(g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam5, 1, 2, (V[]){v_hd_2419, v_k_2420})});
}
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo(g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam4, 1, 3, (V[]){v_f_241, v_hd_2419, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam7(V self, V *args) {
  V v_x_2429 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_src_2417 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2430 = (g_heff_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get(v_x_2429, LBL_sources)));
  V v_t_2431 = ({ V a_0 = v_checkOnly_240; V a_1 = v_f_241; V a_2 = v_src_2417; V a_3 = v_t_2430; V r_ = (g_heff_2ecommands_2efmtSrc_24s136663724x956277246(a_0, a_1, a_2, a_3)); heff_drop(v_checkOnly_240); r_; });
  return heff_tail(v_t_2431, 2, (V[]){v_hd_242, v_k_243});
}
V g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_checkOnly_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop(v_checkOnly_240);
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2efmtOne_24s852482434x948630519_str0), v_f_241), ((V)&g_heff_2ecommands_2efmtOne_24s852482434x948630519_str1));
    V v_t_2411 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2414}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2415, heff_clo(g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam2, 1, 1, (V[]){v_k_243})});
  }
  case TAG_Just: {
    V v_src_2417 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_c_2418 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
    V v_c_2428 = heff_clo(g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam3, 2, 2, (V[]){v_c_2418, heff_dup(v_f_241)});
    return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2efmtOne_24s852482434x948630519_lam7, 1, 5, (V[]){v_checkOnly_240, v_f_241, v_src_2417, v_hd_242, v_k_243})});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2ecommands_2efmtAll_24s486731757x642131866_lam0(V self, V *args);
Clo g_heff_2ecommands_2efmtAll_24s486731757x642131866_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtAll_24s486731757x642131866_entry, 5, 0};

V g_heff_2ecommands_2efmtAll_24s486731757x642131866(V v_checkOnly_240, V v_x2_241, V v_bad_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_bad_242});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    return (g_heff_2ecommands_2efmtOne_24s852482434x948630519(v_checkOnly_240, heff_dup(v_f_245), heff_dup(v_p_243), heff_clo(g_heff_2ecommands_2efmtAll_24s486731757x642131866_lam0, 1, 5, (V[]){heff_dup(v_checkOnly_240), heff_dup(v_rest_246), v_bad_242, v_p_243, v_p_244})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2efmtAll_24s486731757x642131866_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2efmtAll_24s486731757x642131866(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2efmtAll_24s486731757x642131866_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_bad_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_checkOnly_240; V a_1 = v_rest_246; V a_2 = heff_intAdd(v_bad_242, v_x_247); V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ecommands_2efmtAll_24s486731757x642131866(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_checkOnly_240); heff_drop(v_rest_246); r_; });
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2eexisting_24s150974492x1363885069_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
V g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam0(V self, V *args); static Clo g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam0, 1, 0};
V g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam3(V self, V *args); static Clo g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam3, 1, 0};
V g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam2(V self, V *args);
V g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam5(V self, V *args);
V g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam4(V self, V *args);
V g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam1(V self, V *args);
Clo g_heff_2ecommands_2eexisting_24s150974492x1363885069_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eexisting_24s150974492x1363885069_entry, 4, 0};

V g_heff_2ecommands_2eexisting_24s150974492x1363885069(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      heff_take_n(v_x21_244, 1ULL, 2);
      V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam0_clo)})});
      V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_p_242), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})}));
      return heff_tail(heff_get(heff_dup(v_p_242), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam1, 1, 5, (V[]){v_dir_240, v_f_246, v_p_242, v_rest_245, v_p_243})});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eexisting_24s150974492x1363885069_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eexisting_24s150974492x1363885069(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam3(V self, V *args) {
  V v_t_2424 = args[0];
  return v_t_2424;
}
V g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k2_2423 = args[1];
  V v_path_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2421, ((V)&g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam3_clo)})});
  V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2422), LBL_malg), 1, (V[]){v_t_2427}));
  V f_ = heff_get(v_hd_2422, LBL_bind);
  args[0] = v_t_2428;
  args[1] = v_k2_2423;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2430 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Nothing: {
    heff_drop(v_f_246);
    V f_ = v_p_243;
    args[0] = v_x_2431;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    heff_take_n(v_x_2430, 0ULL, 1);
    V f_ = v_p_243;
    args[0] = heff_tag(TAG_Cons, 2, (V[]){v_f_246, v_x_2431});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_f_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecommands_2eexisting_24s150974492x1363885069(v_dir_240, v_rest_245, v_p_242, heff_clo(g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam5, 1, 3, (V[]){v_x_2430, v_p_243, v_f_246})));
}
V g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = heff_strEq(v_x_2413, ((V)&g_heff_2ecommands_2eexisting_24s150974492x1363885069_str0));
  V v_x_2415;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    v_x_2415 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2415 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_t_2416 = (g_std_2epath_2eparse(v_x_2415, heff_dup(v_dir_240)));
  V v_t_2417 = (g_std_2epath_2eparse(v_x_2415, heff_dup(v_f_246)));
  V v_p_2418 = (g_std_2epath_2ejoin_2eonto_240(v_t_2416, v_t_2417));
  V v_t_2419 = ({ V a_0 = heff_get(heff_dup(v_p_2418), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2418), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2420 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2418), LBL_drive), heff_get(v_p_2418, LBL_absolute), v_t_2419});
  V v_path_2421 = ({ V a_0 = v_x_2415; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2415); r_; });
  V v_c_2429 = heff_clo(g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam2, 2, 1, (V[]){v_path_2421});
  return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2eexisting_24s150974492x1363885069_lam4, 1, 5, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243, v_f_246})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_str2 = {{0x80000000u, K_STR, 0}, 19, 19, {104, 101, 102, 102, 58, 32, 99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam0(V self, V *args); static Clo g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam0, 1, 0};
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam3(V self, V *args); static Clo g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam3, 1, 0};
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam2(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam6(V self, V *args); static Clo g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam6, 1, 0};
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam5(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam8(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam9(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam7(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam4(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam1(V self, V *args);
Clo g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_entry, 4, 0};

V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam0_clo)})});
      V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_p_242), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})}));
      return heff_tail(heff_get(heff_dup(v_p_242), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam1, 1, 6, (V[]){v_dir_240, v_f_246, v_p_242, v_text_247, v_rest_245, v_p_243})});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam3(V self, V *args) {
  V v_ok_2430 = args[0];
  return v_ok_2430;
}
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam2(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k2_2429 = args[1];
  V v_path_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_2427, ((V)&g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam3_clo)})});
  V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2428), LBL_malg), 1, (V[]){v_t_2433}));
  V f_ = heff_get(v_hd_2428, LBL_bind);
  args[0] = v_t_2434;
  args[1] = v_k2_2429;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam6(V self, V *args) {
  V v_ok_2452 = args[0];
  return v_ok_2452;
}
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam5(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k2_2451 = args[1];
  V v_path_2442 = heff_env(self)[0];
  V v_str_2449 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2453 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){v_path_2442, v_str_2449, ((V)&g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam6_clo)})});
  V v_t_2454 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2450), LBL_malg), 1, (V[]){v_t_2455}));
  V f_ = heff_get(v_hd_2450, LBL_bind);
  args[0] = v_t_2456;
  args[1] = v_k2_2451;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam8(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k2_2467 = args[1];
  V v_str_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2468 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2465, ((V)&g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_str3)), NTAG(TAG_MkUnit)});
  V v_t_2469 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2466), LBL_malg), 1, (V[]){v_t_2471}));
  V f_ = heff_get(v_hd_2466, LBL_bind);
  args[0] = v_t_2472;
  args[1] = v_k2_2467;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam9(V self, V *args) {
  V v_x_2474 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2474);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam7(V self, V *args) {
  V v_x_2458 = args[0];
  V v_x_2436 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_x_2415 = heff_env(self)[5];
  V v_f_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2459;
  switch (heff_tag_of(v_x_2436)) {
  case TAG_True: {
    v_t_2459 = v_x_2458;
    break;
  }
  case TAG_False: {
    heff_drop(v_x_2458);
    v_t_2459 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2436);
  }
  switch (heff_tag_of(v_t_2459)) {
  case TAG_True: {
    heff_drop(v_x_2415);
    heff_drop(v_f_246);
    return (g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198(v_dir_240, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_False: {
    heff_drop(v_rest_245);
    V v_t_2460 = (g_std_2epath_2eparse(v_x_2415, v_dir_240));
    V v_t_2461 = (g_std_2epath_2eparse(v_x_2415, v_f_246));
    V v_p_2462 = (g_std_2epath_2ejoin_2eonto_240(v_t_2460, v_t_2461));
    V v_t_2463 = ({ V a_0 = heff_get(heff_dup(v_p_2462), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2462), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2464 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2462), LBL_drive), heff_get(v_p_2462, LBL_absolute), v_t_2463});
    V v_str_2465 = heff_strAppend(((V)&g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_str2), ({ V a_0 = v_x_2415; V a_1 = v_t_2464; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2415); r_; }));
    V v_c_2473 = heff_clo(g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam8, 2, 1, (V[]){v_str_2465});
    return heff_tail(v_c_2473, 2, (V[]){v_p_242, heff_clo(g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam9, 1, 1, (V[]){v_p_243})});
  }
  default: return heff_nomatch(v_t_2459);
  }
}
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2437 = (g_std_2epath_2eparse(v_x_2415, heff_dup(v_dir_240)));
  V v_t_2438 = (g_std_2epath_2eparse(v_x_2415, heff_dup(v_f_246)));
  V v_p_2439 = (g_std_2epath_2ejoin_2eonto_240(v_t_2437, v_t_2438));
  V v_t_2440 = ({ V a_0 = heff_get(heff_dup(v_p_2439), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2439), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2441 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2439), LBL_drive), heff_get(v_p_2439, LBL_absolute), v_t_2440});
  V v_path_2442 = (g_std_2epath_2erender(v_x_2415, v_t_2441));
  V v_t_2443 = heff_intSub(heff_strLength(heff_dup(v_f_246)), MK_INT(3LL));
  V v_t_2444 = heff_strSlice(heff_dup(v_f_246), v_t_2443, heff_strLength(heff_dup(v_f_246)));
  V v_t_2445 = heff_strEq(v_t_2444, ((V)&g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_str1));
  V v_str_2449;
  switch (heff_tag_of(v_t_2445)) {
  case TAG_True: {
    V v_t_2446 = (g_heff_2eformat_2eformat(heff_dup(v_text_247)));
    switch (heff_tag_of(v_t_2446)) {
    case TAG_Left: {
      heff_take_n(v_t_2446, 0ULL, 1);
      v_str_2449 = v_text_247;
      break;
    }
    case TAG_Right: {
      V v_out_2448 = heff_field(v_t_2446, 0);
      heff_take_n(v_t_2446, 1ULL, 1);
      heff_drop(v_text_247);
      v_str_2449 = v_out_2448;
      break;
    }
    default: heff_nomatch(v_t_2446);
    }
    break;
  }
  case TAG_False: {
    v_str_2449 = v_text_247;
    break;
  }
  default: heff_nomatch(v_t_2445);
  }
  V v_c_2457 = heff_clo(g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam5, 2, 2, (V[]){v_path_2442, v_str_2449});
  return heff_tail(v_c_2457, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam7, 1, 7, (V[]){v_x_2436, v_dir_240, v_rest_245, v_p_242, v_p_243, v_x_2415, v_f_246})});
}
V g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2414 = heff_strEq(v_x_2413, ((V)&g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_str0));
  V v_x_2415;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    v_x_2415 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2415 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_t_2416 = (g_std_2epath_2eparse(v_x_2415, heff_dup(v_dir_240)));
  V v_t_2417 = (g_std_2epath_2eparse(v_x_2415, heff_dup(v_f_246)));
  V v_p_2418 = (g_std_2epath_2ejoin_2eonto_240(v_t_2416, v_t_2417));
  V v_t_2419 = ({ V a_0 = heff_get(heff_dup(v_p_2418), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2418), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2420 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2418), LBL_drive), heff_get(v_p_2418, LBL_absolute), v_t_2419});
  V v_s_2421 = (g_std_2epath_2erender(v_x_2415, v_t_2420));
  V v_p_2422 = (g_std_2epath_2eparse(v_x_2415, v_s_2421));
  V v_t_2423 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2422), LBL_segments)));
  V v_xs_2424 = (g_prelude_2edrop(MK_INT(1LL), v_t_2423));
  V v_t_2425 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2424));
  V v_t_2426 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2422), LBL_drive), heff_get(v_p_2422, LBL_absolute), v_t_2425});
  V v_path_2427 = (g_std_2epath_2erender(v_x_2415, v_t_2426));
  V v_c_2435 = heff_clo(g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam2, 2, 1, (V[]){v_path_2427});
  return heff_tail(v_c_2435, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198_lam4, 1, 7, (V[]){v_x_2415, v_dir_240, v_f_246, v_text_247, v_p_242, v_rest_245, v_p_243})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {80, 87, 68}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {48, 46, 49, 46, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {104, 101, 102, 102, 58, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[73]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str4 = {{0x80000000u, K_STR, 0}, 73, 73, {96, 32, 99, 97, 110, 110, 111, 116, 32, 110, 97, 109, 101, 32, 97, 32, 112, 97, 99, 107, 97, 103, 101, 58, 32, 97, 32, 108, 111, 119, 101, 114, 99, 97, 115, 101, 32, 108, 101, 116, 116, 101, 114, 44, 32, 116, 104, 101, 110, 32, 108, 101, 116, 116, 101, 114, 115, 44, 32, 100, 105, 103, 105, 116, 115, 32, 97, 110, 100, 32, 96, 95, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str6 = {{0x80000000u, K_STR, 0}, 23, 23, {104, 101, 102, 102, 58, 32, 97, 32, 110, 101, 119, 32, 112, 114, 111, 106, 101, 99, 116, 32, 105, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[56]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str7 = {{0x80000000u, K_STR, 0}, 56, 56, {59, 32, 116, 104, 101, 114, 101, 44, 32, 96, 104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 96, 32, 98, 117, 105, 108, 100, 115, 32, 105, 116, 32, 97, 110, 100, 32, 96, 104, 101, 102, 102, 32, 116, 101, 115, 116, 96, 32, 116, 101, 115, 116, 115, 32, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str11 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str12 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 104, 97, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str13 = {{0x80000000u, K_STR, 0}, 25, 25, {32, 97, 108, 114, 101, 97, 100, 121, 59, 32, 110, 111, 116, 104, 105, 110, 103, 32, 119, 114, 105, 116, 116, 101, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam0(V self, V *args); static Clo g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam0, 1, 0};
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam3(V self, V *args); static Clo g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam3, 1, 0};
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam5(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam7(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam10(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam11(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam12(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam13(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam9(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam8(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam6(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam4(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam2(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam1(V self, V *args);
Clo g_heff_2ecommands_2einitCmd_24s1172576284x845887128_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2einitCmd_24s1172576284x845887128_entry, 3, 0};

V g_heff_2ecommands_2einitCmd_24s1172576284x845887128(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str0), ((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam0_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam1, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242})});
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2einitCmd_24s1172576284x845887128(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam0(V self, V *args) {
  V v_v_243 = args[0];
  return v_v_243;
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam3(V self, V *args) {
  V v_s_2411 = args[0];
  return v_s_2411;
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam5(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam7(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_x_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam10(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2440);
  V v_t_2441 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2444}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2445, v_k_242});
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam11(V self, V *args) {
  V v_x_2446 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2446)) {
  case TAG_True: {
    V v_t_2447 = heff_strAppend(((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str6), heff_strAppend(v_dir_240, ((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str7)));
    V v_t_2448 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2447, ((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str8)), NTAG(TAG_MkUnit)});
    V v_t_2449 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2451}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2452, v_k_242});
  }
  case TAG_False: {
    heff_drop(v_dir_240);
    V v_t_2453 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2454 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2456}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2457, v_k_242});
  }
  default: return heff_nomatch(v_x_2446);
  }
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam12(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k2_2465 = args[1];
  V v_str_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2463, ((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str14)), NTAG(TAG_MkUnit)});
  V v_t_2467 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2464), LBL_malg), 1, (V[]){v_t_2469}));
  V f_ = heff_get(v_hd_2464, LBL_bind);
  args[0] = v_t_2470;
  args[1] = v_k2_2465;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam13(V self, V *args) {
  V v_x_2472 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2472);
  V v_t_2473 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2474 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2476}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2477, v_k_242});
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam9(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  V v_x_2430 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2432 = (g_heff_2eproject_2eisName(heff_dup(v_x_2423)));
  V v_t_2433;
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_True: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_2432);
  }
  switch (heff_tag_of(v_t_2433)) {
  case TAG_True: {
    heff_drop(v_x_2431);
    heff_drop(v_dir_240);
    heff_drop(v_x_2430);
    V v_t_2434 = heff_strAppend(((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str3), heff_strAppend(v_x_2423, ((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str4)));
    V v_t_2435 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2434, ((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str5)), NTAG(TAG_MkUnit)});
    V v_t_2436 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2438}));
    return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2439, heff_clo(g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam10, 1, 2, (V[]){v_hd_241, v_k_242})});
  }
  case TAG_False: {
    heff_drop(v_x_2423);
    switch (heff_tag_of(v_x_2431)) {
    case TAG_Nil: {
      return (g_heff_2ecommands_2ewriteAll_24s1322816495x1717668198(heff_dup(v_dir_240), v_x_2430, heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam11, 1, 3, (V[]){v_dir_240, v_hd_241, v_k_242})));
    }
    case TAG_Cons: {
      heff_drop(v_x_2430);
      V v_t_2462;
      switch (heff_tag_of(v_x_2431)) {
      case TAG_Nil: {
        v_t_2462 = ((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str9);
        break;
      }
      case TAG_Cons: {
        V v_x_2460 = heff_field(v_x_2431, 0);
        V v_xs_2461 = heff_field(v_x_2431, 1);
        heff_take_n(v_x_2431, 3ULL, 2);
        v_t_2462 = ({ V a_0 = ((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str10); V a_1 = v_x_2460; V a_2 = v_xs_2461; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2461); r_; });
        break;
      }
      default: heff_nomatch(v_x_2431);
      }
      V v_str_2463 = heff_strAppend(((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str11), heff_strAppend(v_dir_240, heff_strAppend(((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str12), heff_strAppend(v_t_2462, ((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str13)))));
      V v_c_2471 = heff_clo(g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam12, 2, 1, (V[]){v_str_2463});
      return heff_tail(v_c_2471, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam13, 1, 2, (V[]){v_hd_241, v_k_242})});
    }
    default: return heff_nomatch(v_x_2431);
    }
  }
  default: return heff_nomatch(v_t_2433);
  }
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam8(V self, V *args) {
  V v_x_2430 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecommands_2eexisting_24s150974492x1363885069(heff_dup(v_dir_240), heff_dup(v_x_2430), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam9, 1, 5, (V[]){v_x_2423, v_hd_241, v_k_242, v_dir_240, v_x_2430})));
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2425;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    v_t_2425 = ((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2424 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    v_t_2425 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_x_2426 = (g_heff_2ecommands_2eprojectFiles(heff_dup(v_x_2423), v_t_2425));
  V v_c_2429 = heff_clo(g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam7, 2, 1, (V[]){v_x_2426});
  return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam8, 1, 4, (V[]){v_dir_240, v_hd_241, v_x_2423, v_k_242})});
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = heff_strEq(v_x_2416, ((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_str1));
  V v_x_2418;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    v_x_2418 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2418 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  V v_x_2419 = ({ V a_0 = v_x_2418; V a_1 = heff_dup(v_dir_240); V a_2 = v_x_248; V r_ = (g_heff_2ecommands_2eprojectName(a_0, a_1, a_2)); heff_drop(v_x_2418); r_; });
  V v_c_2422 = heff_clo(g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam5, 2, 1, (V[]){v_x_2419});
  return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam6, 1, 4, (V[]){v_x_2410, v_hd_241, v_dir_240, v_k_242})});
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam3_clo)})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2414})}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2415, heff_clo(g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam4, 1, 5, (V[]){v_dir_240, v_x_248, v_hd_241, v_x_2410, v_k_242})});
}
V g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s1172576284x845887128_lam2, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_248, v_k_242})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetFails_24s970500795x1113151702_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 32, 103, 101, 116, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetFails_24s970500795x1113151702_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2egetFails_24s970500795x1113151702_lam0(V self, V *args);
Clo g_heff_2ecommands_2egetFails_24s970500795x1113151702_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetFails_24s970500795x1113151702_entry, 3, 0};

V g_heff_2ecommands_2egetFails_24s970500795x1113151702(V v_why_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2egetFails_24s970500795x1113151702_str0), v_why_240), ((V)&g_heff_2ecommands_2egetFails_24s970500795x1113151702_str1));
  V v_t_244 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_243, NTAG(TAG_MkUnit)});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2egetFails_24s970500795x1113151702_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2egetFails_24s970500795x1113151702_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2egetFails_24s970500795x1113151702(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2egetFails_24s970500795x1113151702_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_249);
  V v_t_2410 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2414, v_k_242});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 97, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str1 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 101, 116, 99, 104, 105, 110, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str3 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {45, 45, 98, 114, 97, 110, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str7 = {{0x80000000u, K_STR, 0}, 7, 7, {45, 45, 113, 117, 105, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {45, 45, 100, 101, 112, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str9 = {{0x80000000u, K_STR, 0}, 25, 25, {97, 100, 118, 105, 99, 101, 46, 100, 101, 116, 97, 99, 104, 101, 100, 72, 101, 97, 100, 61, 102, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str10 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 108, 111, 110, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str12 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str13 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str14 = {{0x80000000u, K_STR, 0}, 13, 13, {99, 97, 110, 110, 111, 116, 32, 102, 101, 116, 99, 104, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 40, 116, 97, 103, 32, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str17 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str18 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str19 = {{0x80000000u, K_STR, 0}, 11, 11, {72, 69, 65, 68, 94, 123, 116, 114, 101, 101, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str20 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 101, 118, 45, 112, 97, 114, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str21 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str22 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 67}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str23 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str24 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 114, 101, 101, 58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str25 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 97, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str27 = {{0x80000000u, K_STR, 0}, 18, 18, {104, 101, 102, 102, 32, 103, 101, 116, 58, 32, 102, 101, 116, 99, 104, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str30 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 97, 110, 110, 111, 116, 32, 107, 101, 101, 112, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2efetched_24s1467657534x990122053_str32 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 105, 110, 32}};
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam0(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam3(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s1467657534x990122053_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s1467657534x990122053_lam3, 1, 0};
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam5(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s1467657534x990122053_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s1467657534x990122053_lam5, 1, 0};
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam8(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s1467657534x990122053_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s1467657534x990122053_lam8, 1, 0};
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam7(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam10(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s1467657534x990122053_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s1467657534x990122053_lam10, 1, 0};
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam13(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s1467657534x990122053_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s1467657534x990122053_lam13, 1, 0};
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam12(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam16(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s1467657534x990122053_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s1467657534x990122053_lam16, 1, 0};
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam17(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam18(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s1467657534x990122053_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s1467657534x990122053_lam18, 1, 0};
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam21(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s1467657534x990122053_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s1467657534x990122053_lam21, 1, 0};
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam20(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam23(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s1467657534x990122053_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s1467657534x990122053_lam23, 1, 0};
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam25(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam27(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s1467657534x990122053_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s1467657534x990122053_lam27, 1, 0};
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam29(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam28(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam26(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam24(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam22(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam19(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam15(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam14(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam11(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam9(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam6(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam4(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam2(V self, V *args);
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam1(V self, V *args);
Clo g_heff_2ecommands_2efetched_24s1467657534x990122053_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s1467657534x990122053_entry, 3, 0};

V g_heff_2ecommands_2efetched_24s1467657534x990122053(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_x_243 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_241), heff_dup(v_v_242)));
  V v_c_246 = heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam0, 2, 1, (V[]){v_x_243});
  return heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam1, 2, 4, (V[]){v_c_246, v_ps_240, v_path_241, v_v_242});
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2efetched_24s1467657534x990122053(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_x_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam3(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam5(V self, V *args) {
  V v_ok_2416 = args[0];
  return v_ok_2416;
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam8(V self, V *args) {
  V v_ok_2431 = args[0];
  return v_ok_2431;
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam7(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k2_2430 = args[1];
  V v_path_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_2428, ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_lam8_clo)})});
  V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2429), LBL_malg), 1, (V[]){v_t_2434}));
  V f_ = heff_get(v_hd_2429, LBL_bind);
  args[0] = v_t_2435;
  args[1] = v_k2_2430;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam10(V self, V *args) {
  V v_t_2439 = args[0];
  return v_t_2439;
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam13(V self, V *args) {
  V v_r_2452 = args[0];
  return v_r_2452;
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam12(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k2_2451 = args[1];
  V v_as_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2453 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str12), v_as_2449, ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_lam13_clo)})});
  V v_t_2454 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2450), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2455})}));
  V f_ = heff_get(v_hd_2450, LBL_bind);
  args[0] = v_t_2456;
  args[1] = v_k2_2451;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam16(V self, V *args) {
  V v_ok_2464 = args[0];
  return v_ok_2464;
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam17(V self, V *args) {
  V v_x_2469 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_x_2458 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2469);
  V v_t_2470 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str13), (g_heff_2eproject_2erepoOf(heff_dup(v_path_241))));
  V v_s_2471 = heff_get(v_x_2458, LBL_err);
  V v_t_2472 = (g_prelude_2eskipSpaces(heff_dup(v_s_2471), MK_INT(0LL), MK_INT(1LL)));
  V v_t_2473 = heff_intSub(heff_strLength(heff_dup(v_s_2471)), MK_INT(1LL));
  V v_t_2474 = (g_prelude_2eskipSpaces(heff_dup(v_s_2471), v_t_2473, MK_INT(-1LL)));
  V v_t_2475 = heff_strSlice(v_s_2471, v_t_2472, heff_intAdd(v_t_2474, MK_INT(1LL)));
  V v_t_2476 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str14), heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str15), heff_strAppend(heff_dup(v_v_242), heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str16), heff_strAppend(v_v_242, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str17), heff_strAppend(v_t_2470, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str18), v_t_2475)))))))));
  V v_x_2477 = heff_tag(TAG_Left, 1, (V[]){v_t_2476});
  V f_ = v_k_248;
  args[0] = v_x_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam18(V self, V *args) {
  V v_r_2480 = args[0];
  return v_r_2480;
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam21(V self, V *args) {
  V v_ok_2496 = args[0];
  return v_ok_2496;
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam20(V self, V *args) {
  V v_hd_2494 = args[0];
  V v_k2_2495 = args[1];
  V v_path_2493 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2497 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){v_path_2493, ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_lam21_clo)})});
  V v_t_2498 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2494), LBL_malg), 1, (V[]){v_t_2499}));
  V f_ = heff_get(v_hd_2494, LBL_bind);
  args[0] = v_t_24100;
  args[1] = v_k2_2495;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam23(V self, V *args) {
  V v_ok_24103 = args[0];
  return v_ok_24103;
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam25(V self, V *args) {
  V v_hd_24115 = args[0];
  V v_k_24116 = args[1];
  V v_x_24114 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24115);
  V f_ = v_k_24116;
  args[0] = v_x_24114;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam27(V self, V *args) {
  V v_ok_24119 = args[0];
  return v_ok_24119;
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam29(V self, V *args) {
  V v_x_24133 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_24118 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24133);
  V f_ = v_k_248;
  args[0] = heff_tag(TAG_Right, 1, (V[]){v_x_24118});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam28(V self, V *args) {
  V v_x_24124 = args[0];
  V v_x_2486 = heff_env(self)[0];
  V v_x_24108 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_x_24118 = heff_env(self)[6];
  V v_x_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_24125 = heff_intEq(heff_get(v_x_2486, LBL_status), MK_INT(0LL));
  V v_t_24126;
  switch (heff_tag_of(v_t_24125)) {
  case TAG_True: {
    switch (heff_tag_of(v_x_24108)) {
    case TAG_True: {
      v_t_24126 = v_x_24124;
      break;
    }
    case TAG_False: {
      heff_drop(v_x_24124);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_24108);
    }
    break;
  }
  case TAG_False: {
    heff_drop(v_x_24124);
    heff_drop(v_x_24108);
    v_t_24126 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_24125);
  }
  switch (heff_tag_of(v_t_24126)) {
  case TAG_True: {
    heff_drop(v_x_249);
    V v_t_24127 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str27), heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str28), v_v_242)));
    V v_t_24128 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_24127, ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str29)), NTAG(TAG_MkUnit)});
    V v_t_24129 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24128})});
    V v_t_24130 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24129})});
    V v_t_24131 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24130})});
    V v_t_24132 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_24131}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_24132, heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam29, 1, 2, (V[]){v_k_248, v_x_24118})});
  }
  case TAG_False: {
    heff_drop(v_hd_247);
    heff_drop(v_x_24118);
    V v_t_24134 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str30), heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str31), heff_strAppend(v_v_242, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str32), v_x_249)))));
    V f_ = v_k_248;
    args[0] = heff_tag(TAG_Left, 1, (V[]){v_t_24134});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_24126);
  }
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam26(V self, V *args) {
  V v_x_24118 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_x_2486 = heff_env(self)[2];
  V v_x_24108 = heff_env(self)[3];
  V v_path_241 = heff_env(self)[4];
  V v_v_242 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_24120 = heff_tag(TAG_WriteFile, 3, (V[]){heff_strAppend(heff_dup(v_x_249), ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str25)), heff_strAppend(heff_dup(v_x_24118), ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str26)), ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_lam27_clo)});
  V v_t_24121 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24120})});
  V v_t_24122 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24121})});
  V v_t_24123 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24122})}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_24123, heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam28, 1, 8, (V[]){v_x_2486, v_x_24108, v_path_241, v_v_242, v_hd_247, v_k_248, v_x_24118, v_x_249})});
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam24(V self, V *args) {
  V v_x_24108 = args[0];
  V v_x_2486 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_s_24109 = heff_get(heff_dup(v_x_2486), LBL_out);
  V v_t_24110 = (g_prelude_2eskipSpaces(heff_dup(v_s_24109), MK_INT(0LL), MK_INT(1LL)));
  V v_t_24111 = heff_intSub(heff_strLength(heff_dup(v_s_24109)), MK_INT(1LL));
  V v_t_24112 = (g_prelude_2eskipSpaces(heff_dup(v_s_24109), v_t_24111, MK_INT(-1LL)));
  V v_t_24113 = heff_strSlice(v_s_24109, v_t_24110, heff_intAdd(v_t_24112, MK_INT(1LL)));
  V v_x_24114 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str24), v_t_24113);
  V v_c_24117 = heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam25, 2, 1, (V[]){v_x_24114});
  return heff_tail(v_c_24117, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam26, 1, 7, (V[]){v_x_249, v_hd_247, v_x_2486, v_x_24108, v_path_241, v_v_242, v_k_248})});
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam22(V self, V *args) {
  V v_x_24102 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_x_2486 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24102);
  V v_t_24104 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadOnly, 2, (V[]){heff_dup(v_x_249), ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_lam23_clo)})});
  V v_t_24105 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_24106}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_24107, heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam24, 1, 6, (V[]){v_x_2486, v_hd_247, v_x_249, v_path_241, v_v_242, v_k_248})});
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam19(V self, V *args) {
  V v_x_2486 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2487 = heff_get(v_ps_240, LBL_style);
  V v_t_2488 = (g_std_2epath_2eparse(v_st_2487, heff_dup(v_x_249)));
  V v_t_2489 = (g_std_2epath_2eparse(v_st_2487, ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str23)));
  V v_p_2490 = (g_std_2epath_2ejoin_2eonto_240(v_t_2488, v_t_2489));
  V v_t_2491 = ({ V a_0 = heff_get(heff_dup(v_p_2490), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2490), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2492 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2490), LBL_drive), heff_get(v_p_2490, LBL_absolute), v_t_2491});
  V v_path_2493 = ({ V a_0 = v_st_2487; V a_1 = v_t_2492; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2487); r_; });
  V v_c_24101 = heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam20, 2, 1, (V[]){v_path_2493});
  return heff_tail(v_c_24101, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam22, 1, 6, (V[]){v_x_249, v_hd_247, v_x_2486, v_path_241, v_v_242, v_k_248})});
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam15(V self, V *args) {
  V v_x_2461 = args[0];
  V v_x_2458 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_ps_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2461);
  V v_t_2462 = heff_intEq(heff_get(heff_dup(v_x_2458), LBL_status), MK_INT(0LL));
  V v_t_2463;
  switch (heff_tag_of(v_t_2462)) {
  case TAG_True: {
    v_t_2463 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2463 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2462);
  }
  switch (heff_tag_of(v_t_2463)) {
  case TAG_True: {
    heff_drop(v_ps_240);
    V v_t_2465 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){v_x_249, ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_lam16_clo)})});
    V v_t_2466 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2467}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2468, heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam17, 1, 4, (V[]){v_path_241, v_x_2458, v_v_242, v_k_248})});
  }
  case TAG_False: {
    heff_drop(v_x_2458);
    V v_t_2478 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str19), NTAG(TAG_Nil)});
    V v_t_2479 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_249), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str20), v_t_2478})});
    V v_t_2481 = heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str21), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str22), v_t_2479}), ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_lam18_clo)});
    V v_t_2482 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2484}));
    return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2485, heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam19, 1, 6, (V[]){v_ps_240, v_x_249, v_hd_247, v_path_241, v_v_242, v_k_248})});
  }
  default: return heff_nomatch(v_t_2463);
  }
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam14(V self, V *args) {
  V v_x_2458 = args[0];
  V v_x_2442 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_ps_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2459 = heff_tag(TAG_End, 2, (V[]){v_x_2442, NTAG(TAG_MkUnit)});
  V v_t_2460 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2459})}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2460, heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam15, 1, 7, (V[]){v_x_2458, v_x_249, v_hd_247, v_path_241, v_v_242, v_k_248, v_ps_240})});
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam11(V self, V *args) {
  V v_x_2442 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2443 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str3), (g_heff_2eproject_2erepoOf(heff_dup(v_path_241))));
  V v_t_2444 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_249), NTAG(TAG_Nil)});
  V v_t_2445 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str4), heff_dup(v_v_242)), heff_tag(TAG_Cons, 2, (V[]){v_t_2443, v_t_2444})});
  V v_t_2446 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str6), v_t_2445})});
  V v_t_2447 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str8), v_t_2446})});
  V v_t_2448 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str10), v_t_2447})});
  V v_as_2449 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str11), v_t_2448});
  V v_c_2457 = heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam12, 2, 1, (V[]){v_as_2449});
  return heff_tail(v_c_2457, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam14, 1, 7, (V[]){v_x_2442, v_hd_247, v_x_249, v_path_241, v_v_242, v_k_248, v_ps_240})});
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str1), heff_strAppend(heff_dup(v_path_241), heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str2), heff_dup(v_v_242))));
  V v_t_2440 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2438, MK_INT(0LL), ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_lam10_clo)})});
  V v_t_2441 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2440}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2441, heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam11, 1, 6, (V[]){v_path_241, v_x_249, v_v_242, v_hd_247, v_k_248, v_ps_240})});
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2421);
  V v_st_2422 = heff_get(heff_dup(v_ps_240), LBL_style);
  V v_p_2423 = (g_std_2epath_2eparse(v_st_2422, heff_dup(v_x_249)));
  V v_t_2424 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2423), LBL_segments)));
  V v_xs_2425 = (g_prelude_2edrop(MK_INT(1LL), v_t_2424));
  V v_t_2426 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2425));
  V v_t_2427 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2423), LBL_drive), heff_get(v_p_2423, LBL_absolute), v_t_2426});
  V v_path_2428 = ({ V a_0 = v_st_2422; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); r_; });
  V v_c_2436 = heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam7, 2, 1, (V[]){v_path_2428});
  return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam9, 1, 6, (V[]){v_path_241, v_v_242, v_hd_247, v_x_249, v_k_248, v_ps_240})});
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){heff_dup(v_x_249), ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_lam5_clo)})});
    V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2419}));
    return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2420, heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam6, 1, 6, (V[]){v_ps_240, v_x_249, v_hd_247, v_path_241, v_v_242, v_k_248})});
  }
  case TAG_Just: {
    V v_h_24135 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Just = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    heff_drop(v_x_249);
    heff_drop(v_hd_247);
    heff_drop(v_ps_240);
    heff_drop(v_path_241);
    heff_drop(v_v_242);
    V v_t_24136 = (g_prelude_2eskipSpaces(heff_dup(v_h_24135), MK_INT(0LL), MK_INT(1LL)));
    V v_t_24137 = heff_intSub(heff_strLength(heff_dup(v_h_24135)), MK_INT(1LL));
    V v_t_24138 = (g_prelude_2eskipSpaces(heff_dup(v_h_24135), v_t_24137, MK_INT(-1LL)));
    V v_t_24139 = heff_strSlice(v_h_24135, v_t_24136, heff_intAdd(v_t_24138, MK_INT(1LL)));
    V v_x_24140 = heff_tag_at(v_ru_24x_2415_24Just, TAG_Right, 1, (V[]){v_t_24139});
    V f_ = v_k_248;
    args[0] = v_x_24140;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag(TAG_ReadFile, 2, (V[]){heff_strAppend(heff_dup(v_x_249), ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_str0)), ((V)&g_heff_2ecommands_2efetched_24s1467657534x990122053_lam3_clo)});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2413})}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam4, 1, 6, (V[]){v_x_249, v_hd_247, v_ps_240, v_path_241, v_v_242, v_k_248})});
}
V g_heff_2ecommands_2efetched_24s1467657534x990122053_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2ecommands_2efetched_24s1467657534x990122053_lam2, 1, 5, (V[]){v_hd_247, v_ps_240, v_path_241, v_v_242, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 114, 101, 113, 117, 105, 114, 101, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 105, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_str5 = {{0x80000000u, K_STR, 0}, 20, 20, {44, 32, 97, 110, 100, 32, 104, 101, 102, 102, 46, 115, 117, 109, 32, 115, 97, 121, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_str6 = {{0x80000000u, K_STR, 0}, 24, 24, {58, 32, 105, 116, 115, 32, 116, 97, 103, 32, 104, 97, 115, 32, 98, 101, 101, 110, 32, 109, 111, 118, 101, 100}};
V g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam0(V self, V *args);
V g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam1(V self, V *args);
V g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam4(V self, V *args);
V g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam3(V self, V *args);
V g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam2(V self, V *args);
Clo g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_entry, 6, 0};

V g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_t_247 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam0, 1, 1, (V[]){heff_dup(v_path_244)}), heff_get(heff_dup(v_root_241), LBL_require)));
  V v_t_2414;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nil: {
    heff_drop(v_root_241);
    v_t_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 2);
    V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam1, 1, 1, (V[]){v_r_248}), heff_get(v_root_241, LBL_replace)));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nil: {
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 2);
      v_t_2414 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_p_2412, LBL_dir)});
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    V v_c_2415 = (g_heff_2ecommands_2efetched_24s1467657534x990122053(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    return heff_clo(g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam2, 2, 6, (V[]){v_c_2415, v_by_243, v_path_244, v_v_245, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2435 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_st_2436 = heff_get(heff_dup(v_ps_240), LBL_style);
    V v_t_2437 = (g_std_2epath_2eparse(v_st_2436, heff_get(heff_dup(v_ps_240), LBL_root)));
    V v_t_2438 = (g_std_2epath_2eparse(v_st_2436, v_d_2435));
    V v_p_2439 = (g_std_2epath_2ejoin_2eonto_240(v_t_2437, v_t_2438));
    V v_t_2440 = ({ V a_0 = heff_get(heff_dup(v_p_2439), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2439), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2441 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2439), LBL_drive), heff_get(v_p_2439, LBL_absolute), v_t_2440});
    V v_t_2442 = ({ V a_0 = v_st_2436; V a_1 = v_t_2441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2436); r_; });
    return (g_heff_2eload_2ereadPkgAt_24s1743338588x1287501617(v_ps_240, v_t_2442, v_path_244));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam0(V self, V *args) {
  V v_r_246 = args[0];
  V v_path_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_r_246, LBL_path), v_path_244);
}
V g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam1(V self, V *args) {
  V v_p_2410 = args[0];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_p_2410, LBL_name), heff_get(v_r_248, LBL_name));
}
V g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam4(V self, V *args) {
  V v_s_2422 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_v_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_strEq(heff_get(heff_dup(v_s_2422), LBL_path), v_path_244);
  switch (heff_tag_of(v_t_2423)) {
  case TAG_True: {
    return heff_strEq(heff_get(v_s_2422, LBL_version), v_v_245);
  }
  case TAG_False: {
    heff_drop(v_s_2422);
    heff_drop(v_v_245);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2423);
  }
}
V g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_by_243 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_v_245 = heff_env(self)[2];
  V v_k_2417 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2416 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_why_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_ps_240);
    heff_drop(v_hd_2416);
    V v_t_2420 = heff_strAppend(v_by_243, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_str0), heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_str1), heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_str2), v_why_2419))))));
    V f_ = v_k_2417;
    args[0] = heff_tag(TAG_Left, 1, (V[]){v_t_2420});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_h_2421 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    heff_drop(v_by_243);
    V v_t_2424 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam4, 1, 2, (V[]){heff_dup(v_path_244), heff_dup(v_v_245)}), v_sums_242));
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x_2418_24Right, 1);
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_s_2425 = heff_field(v_t_2424, 0);
      heff_take_n(v_t_2424, 1ULL, 2);
      v_t_2427 = heff_tag_at(v_ru_24x_2418_24Right, TAG_Just, 1, (V[]){heff_get(v_s_2425, LBL_hash)});
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nothing: {
      heff_drop(v_h_2421);
      V v_t_2428 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
      V v_t_2429 = (g_heff_2eload_2ereadPkgAt_24s1743338588x1287501617(v_ps_240, v_t_2428, v_path_244));
      return heff_tail(v_t_2429, 2, (V[]){v_hd_2416, v_k_2417});
    }
    case TAG_Just: {
      V v_want_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      V v_t_2431 = heff_strEq(heff_dup(v_h_2421), heff_dup(v_want_2430));
      switch (heff_tag_of(v_t_2431)) {
      case TAG_True: {
        heff_drop(v_h_2421);
        heff_drop(v_want_2430);
        V v_t_2432 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2433 = (g_heff_2eload_2ereadPkgAt_24s1743338588x1287501617(v_ps_240, v_t_2432, v_path_244));
        return heff_tail(v_t_2433, 2, (V[]){v_hd_2416, v_k_2417});
      }
      case TAG_False: {
        heff_drop(v_ps_240);
        heff_drop(v_hd_2416);
        V v_t_2434 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_str3), heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_str4), heff_strAppend(v_h_2421, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_str5), heff_strAppend(v_want_2430, ((V)&g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_str6))))))));
        V f_ = v_k_2417;
        args[0] = heff_tag(TAG_Left, 1, (V[]){v_t_2434});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_t_2431);
      }
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_by_243 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_v_245 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo(g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881_lam3, 1, 7, (V[]){v_by_243, v_path_244, v_v_245, v_k_2417, v_sums_242, v_ps_240, v_hd_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2esumsOf_24s591159322x49660413_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 97, 115, 104}};
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam0(V self, V *args); static Clo g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam0, 2, 0};
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam4(V self, V *args); static Clo g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam4, 1, 0};
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam3(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam6(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam7(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam5(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam2(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam1(V self, V *args);
Clo g_heff_2ecommands_2esumsOf_24s591159322x49660413_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2esumsOf_24s591159322x49660413_entry, 3, 0};

V g_heff_2ecommands_2esumsOf_24s591159322x49660413(V v_ps_240, V v_root_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_root_241);
    return ((V)&g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = (g_heff_2ecommands_2esumsOf_24s591159322x49660413(heff_dup(v_ps_240), heff_dup(v_root_241), v_rest_246));
    return heff_clo(g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam1, 2, 4, (V[]){v_c_247, v_ps_240, v_x_245, v_root_241});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2esumsOf_24s591159322x49660413(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam4(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam3(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_path_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2412, ((V)&g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam4_clo)})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2413, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam6(V self, V *args) {
  V v_r_2422 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_r_2422, LBL_path), heff_get(v_x_245, LBL_path));
}
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam7(V self, V *args) {
  V v_p_2432 = args[0];
  V v_r_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_p_2432, LBL_name), heff_get(v_r_2430, LBL_name));
}
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2423 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam6, 1, 1, (V[]){heff_dup(v_x_245)}), heff_get(heff_dup(v_root_241), LBL_require)));
  V v_x_2442;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Nil: {
    heff_drop(v_root_241);
    switch (heff_tag_of(v_x_2421)) {
    case TAG_Nothing: {
      heff_drop(v_x_245);
      v_x_2442 = v_x_2410;
      break;
    }
    case TAG_Just: {
      V v_t_2424 = heff_field(v_x_2421, 0);
      heff_take_n(v_x_2421, 1ULL, 1);
      V v_t_2425 = (g_prelude_2eskipSpaces(heff_dup(v_t_2424), MK_INT(0LL), MK_INT(1LL)));
      V v_t_2426 = heff_intSub(heff_strLength(heff_dup(v_t_2424)), MK_INT(1LL));
      V v_t_2427 = (g_prelude_2eskipSpaces(heff_dup(v_t_2424), v_t_2426, MK_INT(-1LL)));
      V v_t_2428 = heff_strSlice(v_t_2424, v_t_2425, heff_intAdd(v_t_2427, MK_INT(1LL)));
      V v_t_2429 = heff_rec(3, shape_path__version__hash, (V[]){heff_get(heff_dup(v_x_245), LBL_path), heff_get(v_x_245, LBL_version), v_t_2428});
      v_x_2442 = heff_tag(TAG_Cons, 2, (V[]){v_t_2429, v_x_2410});
      break;
    }
    default: heff_nomatch(v_x_2421);
    }
    break;
  }
  case TAG_Cons: {
    V v_r_2430 = heff_field(v_t_2423, 0);
    V v_ru_24t_2423_24Cons = heff_take_reuse_n(v_t_2423, 1ULL, 2);
    V v_t_2433 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam7, 1, 1, (V[]){v_r_2430}), heff_get(v_root_241, LBL_replace)));
    switch (heff_tag_of(v_t_2433)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_x_2421)) {
      case TAG_Nothing: {
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24t_2423_24Cons, 2);
        v_x_2442 = v_x_2410;
        break;
      }
      case TAG_Just: {
        V v_t_2434 = heff_field(v_x_2421, 0);
        heff_take_n(v_x_2421, 1ULL, 1);
        V v_t_2435 = (g_prelude_2eskipSpaces(heff_dup(v_t_2434), MK_INT(0LL), MK_INT(1LL)));
        V v_t_2436 = heff_intSub(heff_strLength(heff_dup(v_t_2434)), MK_INT(1LL));
        V v_t_2437 = (g_prelude_2eskipSpaces(heff_dup(v_t_2434), v_t_2436, MK_INT(-1LL)));
        V v_t_2438 = heff_strSlice(v_t_2434, v_t_2435, heff_intAdd(v_t_2437, MK_INT(1LL)));
        V v_t_2439 = heff_rec(3, shape_path__version__hash, (V[]){heff_get(heff_dup(v_x_245), LBL_path), heff_get(v_x_245, LBL_version), v_t_2438});
        v_x_2442 = heff_tag_at(v_ru_24t_2423_24Cons, TAG_Cons, 2, (V[]){v_t_2439, v_x_2410});
        break;
      }
      default: heff_nomatch(v_x_2421);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2433, 0ULL, 2);
      heff_drop(v_x_2421);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24t_2423_24Cons, 2);
      v_x_2442 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_t_2433);
    }
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V f_ = v_k_249;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = (g_heff_2eload_2ecachedDir(v_ps_240, heff_get(heff_dup(v_x_245), LBL_path), heff_get(heff_dup(v_x_245), LBL_version)));
  V v_path_2412 = heff_strAppend(v_t_2411, ((V)&g_heff_2ecommands_2esumsOf_24s591159322x49660413_str0));
  V v_c_2420 = heff_clo(g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam3, 2, 1, (V[]){v_path_2412});
  return heff_tail(v_c_2420, 2, (V[]){v_hd_248, heff_clo(g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam5, 1, 4, (V[]){v_x_245, v_root_241, v_x_2410, v_k_249})});
}
V g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo(g_heff_2ecommands_2esumsOf_24s591159322x49660413_lam2, 1, 5, (V[]){v_ps_240, v_x_245, v_hd_248, v_root_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str1 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[51]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str3 = {{0x80000000u, K_STR, 0}, 51, 51, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 114, 101, 97, 100, 58, 32, 103, 101, 116, 32, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str5 = {{0x80000000u, K_STR, 0}, 11, 11, {116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str15 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str17 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 46, 115, 117, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str18 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 32, 103, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str19 = {{0x80000000u, K_STR, 0}, 21, 21, {99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32, 104, 101, 102, 102, 46, 115, 117, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str20 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str21 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 32, 103, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str22 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 32, 103, 101, 116, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str23 = {{0x80000000u, K_STR, 0}, 27, 27, {32, 112, 97, 99, 107, 97, 103, 101, 115, 44, 32, 104, 101, 102, 102, 46, 115, 117, 109, 32, 119, 114, 105, 116, 116, 101, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam3(V self, V *args); static Clo g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam3, 1, 0};
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam6(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam7(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam10(V self, V *args); static Clo g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam10, 2, 0};
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam12(V self, V *args); static Clo g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam12, 1, 0};
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam11(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam18(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam17(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam16(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam15(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam21(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam20(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam19(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam14(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam13(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam9(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam8(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam5(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam4(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam2(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam1(V self, V *args);
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam0(V self, V *args);

static V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_val;
static int g_heff_2ecommands_2egetAll_24s1612850816x2083342759_st;
static V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_init(void) {
  V v_c_240 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  return heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam0, 2, 1, (V[]){v_c_240});
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_get(void) {
  if (g_heff_2ecommands_2egetAll_24s1612850816x2083342759_st == 2) return g_heff_2ecommands_2egetAll_24s1612850816x2083342759_val;
  if (g_heff_2ecommands_2egetAll_24s1612850816x2083342759_st == 1) heff_fail("defined by itself");
  g_heff_2ecommands_2egetAll_24s1612850816x2083342759_st = 1;
  g_heff_2ecommands_2egetAll_24s1612850816x2083342759_val = heff_tr(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_init());
  g_heff_2ecommands_2egetAll_24s1612850816x2083342759_st = 2;
  return g_heff_2ecommands_2egetAll_24s1612850816x2083342759_val;
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam3(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam6(V self, V *args) {
  V v_r_2423 = args[0];
  V v_by_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_rec(3, shape_by__path__version, (V[]){v_by_2422, heff_get(heff_dup(v_r_2423), LBL_path), heff_get(v_r_2423, LBL_version)});
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam7(V self, V *args) {
  V v_by_2425 = args[0];
  V v_path_2426 = args[1];
  V v_v_2427 = args[2];
  V v_x_245 = heff_env(self)[0];
  V v_root_2416 = heff_env(self)[1];
  V v_sums_2420 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2efetchedPkg_24s1974783760x2027298881(v_x_245, v_root_2416, v_sums_2420, v_by_2425, v_path_2426, v_v_2427));
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam10(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam12(V self, V *args) {
  V v_ok_2450 = args[0];
  return v_ok_2450;
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam11(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k2_2449 = args[1];
  V v_str_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str17), v_str_2447, ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam12_clo)})});
  V v_t_2452 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2448), LBL_malg), 1, (V[]){v_t_2453}));
  V f_ = heff_get(v_hd_2448, LBL_bind);
  args[0] = v_t_2454;
  args[1] = v_k2_2449;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam18(V self, V *args) {
  V v_x_2476 = args[0];
  V v_x_2474 = heff_env(self)[0];
  V v_k_2471 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2477 = ({ V a_0 = v_x_2476; V a_1 = heff_get(heff_dup(v_x_2474), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_2476); r_; });
  V v_x_2478 = (g_prelude_2efoldl_24s1838030138x788027388(v_x_2474, v_t_2477));
  V f_ = v_k_2471;
  args[0] = v_x_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam17(V self, V *args) {
  V v_x_2474 = args[0];
  V v_hd_2470 = heff_env(self)[0];
  V v_k_2471 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2475 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_2475, 2, (V[]){v_hd_2470, heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam18, 1, 2, (V[]){v_x_2474, v_k_2471})});
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam16(V self, V *args) {
  V v_x_2472 = args[0];
  V v_hd_2470 = heff_env(self)[0];
  V v_k_2471 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2473 = (g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(v_x_2472, ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str20)));
  return heff_tail(v_c_2473, 2, (V[]){heff_dup(v_hd_2470), heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam17, 1, 2, (V[]){v_hd_2470, v_k_2471})});
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam15(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  V v_c_2469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2469;
  args[0] = heff_dup(v_hd_2470);
  args[1] = heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam16, 1, 2, (V[]){v_hd_2470, v_k_2471});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam21(V self, V *args) {
  V v_x_2492 = args[0];
  V v_seen_2490 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2492; V a_1 = v_seen_2490; V r_ = (g_prelude_2efoldl_24s701395232x704703097(a_0, a_1)); heff_drop(v_seen_2490); r_; });
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam20(V self, V *args) {
  V v_x_2481 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2482 = heff_intLt(MK_INT(0LL), v_x_2481);
  switch (heff_tag_of(v_t_2482)) {
  case TAG_True: {
    heff_drop(v_x_2429);
    V v_t_2483 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2484 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2486}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2487, v_k_242});
  }
  case TAG_False: {
    V v_seen_2490;
    switch (heff_tag_of(v_x_2429)) {
    case TAG_MkPair: {
      V v_x_2488 = heff_field(v_x_2429, 0);
      heff_take_n(v_x_2429, 1ULL, 2);
      v_seen_2490 = v_x_2488;
      break;
    }
    default: heff_nomatch(v_x_2429);
    }
    V v_t_2491 = (g_prelude_2efoldl_24s1064255209x1797926961(NTAG(TAG_Nil), heff_dup(v_seen_2490)));
    V v_xs_2493 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam21, 1, 1, (V[]){v_seen_2490}), v_t_2491));
    V v_t_2494 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2493; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_2493); r_; });
    V v_str_2495 = heff_strAppend(((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str22), heff_strAppend(heff_intShow(v_t_2494), ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str23)));
    V v_t_2496 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2495, ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str24)), NTAG(TAG_MkUnit)});
    V v_t_2497 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2499}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_24100, v_k_242});
  }
  default: return heff_nomatch(v_t_2482);
  }
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam19(V self, V *args) {
  V v_x_2480 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str21), heff_get(v_x_2480, LBL_errors), MK_INT(0LL), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam20, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2429})));
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam14(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2456 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2462 = heff_intLt(MK_INT(0LL), v_x_2461);
  switch (heff_tag_of(v_t_2462)) {
  case TAG_True: {
    heff_drop(v_x_2456);
    heff_drop(v_x_2429);
    V v_t_2463 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2464 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2466}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2467, v_k_242});
  }
  case TAG_False: {
    V v_t_2468;
    switch (heff_tag_of(v_x_2456)) {
    case TAG_True: {
      v_t_2468 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2468 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_2456);
    }
    switch (heff_tag_of(v_t_2468)) {
    case TAG_True: {
      heff_drop(v_x_2429);
      return (g_heff_2ecommands_2egetFails_24s970500795x1113151702(((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str19), v_hd_241, v_k_242));
    }
    case TAG_False: {
      V v_c_2469 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
      V v_c_2479 = heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam15, 2, 1, (V[]){v_c_2469});
      return heff_tail(v_c_2479, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam19, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2429})});
    }
    default: return heff_nomatch(v_t_2468);
    }
  }
  default: return heff_nomatch(v_t_2462);
  }
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam13(V self, V *args) {
  V v_x_2456 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2459;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_MkPair: {
    V v_y_2458 = heff_dup(heff_field(v_x_2429, 1));
    v_t_2459 = v_y_2458;
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  V v_c_2460 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_clo), 3, (V[]){((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str18), v_t_2459, MK_INT(0LL)}));
  return heff_tail(v_c_2460, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam14, 1, 4, (V[]){v_hd_241, v_k_242, v_x_2456, v_x_2429})});
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam9(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2435 = (g_prelude_2esortBy_24s1510757765x2064206644(heff_dup(v_x_2434)));
  V v_x2_2436 = (g_prelude_2emap_24s173337351x1152519035(((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str6), ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str7), ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str8), v_t_2435));
  V v_t_2439;
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_Nil: {
    v_t_2439 = ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str9);
    break;
  }
  case TAG_Cons: {
    V v_x_2437 = heff_field(v_x2_2436, 0);
    V v_xs_2438 = heff_field(v_x2_2436, 1);
    heff_take_n(v_x2_2436, 3ULL, 2);
    v_t_2439 = ({ V a_0 = ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str10); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2436);
  }
  V v_t_2440 = heff_strEq(v_t_2439, ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str11));
  V v_c_2455;
  switch (heff_tag_of(v_t_2440)) {
  case TAG_True: {
    heff_drop(v_x_2434);
    v_c_2455 = ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam10_clo);
    break;
  }
  case TAG_False: {
    V v_t_2443 = (g_prelude_2esortBy_24s1510757765x2064206644(v_x_2434));
    V v_x2_2444 = (g_prelude_2emap_24s173337351x1152519035(((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str12), ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str13), ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str14), v_t_2443));
    V v_str_2447;
    switch (heff_tag_of(v_x2_2444)) {
    case TAG_Nil: {
      v_str_2447 = ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str15);
      break;
    }
    case TAG_Cons: {
      V v_x_2445 = heff_field(v_x2_2444, 0);
      V v_xs_2446 = heff_field(v_x2_2444, 1);
      heff_take_n(v_x2_2444, 3ULL, 2);
      v_str_2447 = ({ V a_0 = ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str16); V a_1 = v_x_2445; V a_2 = v_xs_2446; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2446); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2444);
    }
    v_c_2455 = heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam11, 2, 1, (V[]){v_str_2447});
    break;
  }
  default: heff_nomatch(v_t_2440);
  }
  return heff_tail(v_c_2455, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam13, 1, 3, (V[]){v_x_2429, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam8(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_root_2416 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2432;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_MkPair: {
    V v_x_2430 = heff_dup(heff_field(v_x_2429, 0));
    v_t_2432 = v_x_2430;
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  V v_c_2433 = (g_heff_2ecommands_2esumsOf_24s591159322x49660413(v_x_245, v_root_2416, v_t_2432));
  return heff_tail(v_c_2433, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam9, 1, 3, (V[]){v_hd_241, v_x_2429, v_k_242})});
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_root_2416 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_why_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_drop(v_root_2416);
    heff_drop(v_x_245);
    return (g_heff_2ecommands_2egetFails_24s970500795x1113151702(v_why_2419, v_hd_241, v_k_242));
  }
  case TAG_Right: {
    V v_sums_2420 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    V v_t_2421 = heff_strEq(heff_get(heff_dup(v_root_2416), LBL_module), ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str4));
    V v_by_2422;
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      v_by_2422 = ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str5);
      break;
    }
    case TAG_False: {
      v_by_2422 = heff_get(heff_dup(v_root_2416), LBL_module);
      break;
    }
    default: heff_nomatch(v_t_2421);
    }
    V v_t_2424 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam6, 1, 1, (V[]){v_by_2422}), heff_get(heff_dup(v_root_2416), LBL_require)));
    V v_c_2428 = (g_heff_2eload_2eversionsGo_24s1827927732x1970474346(heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam7, 3, 3, (V[]){heff_dup(v_x_245), heff_dup(v_root_2416), v_sums_2420}), heff_get(heff_dup(v_root_2416), LBL_module), v_t_2424, NTAG(TAG_Nil), NTAG(TAG_Nil)));
    return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam8, 1, 4, (V[]){v_x_245, v_root_2416, v_hd_241, v_k_242})});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    v_t_2413 = ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2414 = (g_heff_2eproject_2ereadPackage(v_t_2413));
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Left: {
    heff_take_n(v_t_2414, 0ULL, 1);
    heff_drop(v_x_245);
    return (g_heff_2ecommands_2egetFails_24s970500795x1113151702(((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str3), v_hd_241, v_k_242));
  }
  case TAG_Right: {
    V v_root_2416 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    V v_c_2417 = (g_heff_2eload_2ereadSumAt_24s957792674x1765222920(heff_dup(v_x_245)));
    return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam5, 1, 4, (V[]){v_hd_241, v_k_242, v_root_2416, v_x_245})});
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str1), ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam3_clo)})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_249}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam4, 1, 3, (V[]){v_hd_241, v_k_242, v_x_245})});
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244 = (g_heff_2eload_2epathsFor_24s382934904x1572524859(v_x_243, ((V)&g_heff_2ecommands_2egetAll_24s1612850816x2083342759_str0)));
  return heff_tail(v_c_244, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam2, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_240;
  args[0] = heff_dup(v_hd_241);
  args[1] = heff_clo(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_lam1, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str0 = {{0x80000000u, K_STR, 0}, 30, 30, {102, 105, 110, 100, 105, 110, 103, 32, 116, 104, 101, 32, 110, 101, 119, 101, 115, 116, 32, 118, 101, 114, 115, 105, 111, 110, 32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {45, 45, 116, 97, 103, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {45, 45, 114, 101, 102, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {108, 115, 45, 114, 101, 109, 111, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str7 = {{0x80000000u, K_STR, 0}, 24, 24, {99, 97, 110, 110, 111, 116, 32, 108, 105, 115, 116, 32, 116, 104, 101, 32, 116, 97, 103, 115, 32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str10 = {{0x80000000u, K_STR, 0}, 11, 11, {114, 101, 102, 115, 47, 116, 97, 103, 115, 47, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str11 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str15 = {{0x80000000u, K_STR, 0}, 9, 9, {116, 104, 97, 116, 32, 111, 102, 32, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str16 = {{0x80000000u, K_STR, 0}, 6, 6, {48, 32, 111, 114, 32, 49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str17 = {{0x80000000u, K_STR, 0}, 6, 6, {48, 32, 111, 114, 32, 49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str18 = {{0x80000000u, K_STR, 0}, 6, 6, {48, 32, 111, 114, 32, 49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str19 = {{0x80000000u, K_STR, 0}, 10, 10, {110, 111, 32, 116, 97, 103, 32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str20 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 105, 115, 32, 97, 32, 118, 101, 114, 115, 105, 111, 110, 32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str21 = {{0x80000000u, K_STR, 0}, 20, 20, {32, 40, 118, 65, 46, 66, 46, 67, 44, 32, 105, 116, 115, 32, 109, 97, 106, 111, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s456807686x23137961_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam0(V self, V *args); static Clo g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam0, 1, 0};
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam3(V self, V *args); static Clo g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam3, 1, 0};
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam2(V self, V *args);
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam6(V self, V *args);
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam5(V self, V *args);
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam4(V self, V *args);
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam1(V self, V *args);
Clo g_heff_2ecommands_2enewestTag_24s456807686x23137961_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enewestTag_24s456807686x23137961_entry, 3, 0};

V g_heff_2ecommands_2enewestTag_24s456807686x23137961(V v_path_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str0), heff_dup(v_path_240)), MK_INT(0LL), ((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam0_clo)});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam1, 1, 3, (V[]){v_path_240, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2enewestTag_24s456807686x23137961(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam0(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam3(V self, V *args) {
  V v_r_2413 = args[0];
  return v_r_2413;
}
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k2_2412 = args[1];
  V v_as_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str5), v_as_2410, ((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam3_clo)})});
  V v_t_2415 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2416})}));
  V f_ = heff_get(v_hd_2411, LBL_bind);
  args[0] = v_t_2417;
  args[1] = v_k2_2412;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam6(V self, V *args) {
  V v_best_2433 = args[0];
  V v_line_2434 = args[1];
  V v_path_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_it_2435 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str10), v_line_2434, MK_INT(0LL), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_2435)) {
  case TAG_Nil: {
    heff_drop(v_path_240);
    return v_best_2433;
  }
  case TAG_Cons: {
    V v_it2_2437 = heff_field(v_it_2435, 1);
    heff_take_n(v_it_2435, 2ULL, 2);
    switch (heff_tag_of(v_it2_2437)) {
    case TAG_Nil: {
      heff_drop(v_path_240);
      return v_best_2433;
    }
    case TAG_Cons: {
      V v_v_2438 = heff_field(v_it2_2437, 0);
      V v_it22_2439 = heff_field(v_it2_2437, 1);
      heff_take_n(v_it2_2437, 3ULL, 2);
      switch (heff_tag_of(v_it22_2439)) {
      case TAG_Nil: {
        V v_t_2440 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), MK_INT(0LL), MK_INT(1LL)));
        V v_t_2441 = heff_intSub(heff_strLength(heff_dup(v_v_2438)), MK_INT(1LL));
        V v_t_2442 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), v_t_2441, MK_INT(-1LL)));
        V v_t_2443 = heff_strSlice(heff_dup(v_v_2438), v_t_2440, heff_intAdd(v_t_2442, MK_INT(1LL)));
        V v_t_2444 = (g_heff_2eproject_2eversion(v_t_2443));
        switch (heff_tag_of(v_t_2444)) {
        case TAG_Nothing: {
          heff_drop(v_path_240);
          heff_drop(v_v_2438);
          return v_best_2433;
        }
        case TAG_Just: {
          V v_ru_24t_2444_24Just = heff_take_reuse_n(v_t_2444, 0ULL, 1);
          V v_t_2446 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), MK_INT(0LL), MK_INT(1LL)));
          V v_t_2447 = heff_intSub(heff_strLength(heff_dup(v_v_2438)), MK_INT(1LL));
          V v_t_2448 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), v_t_2447, MK_INT(-1LL)));
          V v_t_2449 = heff_strSlice(heff_dup(v_v_2438), v_t_2446, heff_intAdd(v_t_2448, MK_INT(1LL)));
          V v_t_2450 = (g_heff_2eproject_2emajorMismatch(v_path_240, v_t_2449));
          switch (heff_tag_of(v_t_2450)) {
          case TAG_Nothing: {
            switch (heff_tag_of(v_best_2433)) {
            case TAG_Nothing: {
              V v_t_2451 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), MK_INT(0LL), MK_INT(1LL)));
              V v_t_2452 = heff_intSub(heff_strLength(heff_dup(v_v_2438)), MK_INT(1LL));
              V v_t_2453 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), v_t_2452, MK_INT(-1LL)));
              V v_t_2454 = heff_strSlice(v_v_2438, v_t_2451, heff_intAdd(v_t_2453, MK_INT(1LL)));
              return heff_tag_at(v_ru_24t_2444_24Just, TAG_Just, 1, (V[]){v_t_2454});
            }
            case TAG_Just: {
              V v_b_2455 = heff_dup(heff_field(v_best_2433, 0));
              V v_t_2456 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), MK_INT(0LL), MK_INT(1LL)));
              V v_t_2457 = heff_intSub(heff_strLength(heff_dup(v_v_2438)), MK_INT(1LL));
              V v_t_2458 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), v_t_2457, MK_INT(-1LL)));
              V v_a_2459 = heff_strSlice(heff_dup(v_v_2438), v_t_2456, heff_intAdd(v_t_2458, MK_INT(1LL)));
              V v_x2_2460 = (g_heff_2eproject_2eversion(v_a_2459));
              V v_t_2462;
              switch (heff_tag_of(v_x2_2460)) {
              case TAG_Nothing: {
                v_t_2462 = NTAG(TAG_Nil);
                break;
              }
              case TAG_Just: {
                V v_x_2461 = heff_field(v_x2_2460, 0);
                heff_take_n(v_x2_2460, 1ULL, 1);
                v_t_2462 = v_x_2461;
                break;
              }
              default: heff_nomatch(v_x2_2460);
              }
              V v_x2_2463 = (g_heff_2eproject_2eversion(v_b_2455));
              V v_t_2465;
              switch (heff_tag_of(v_x2_2463)) {
              case TAG_Nothing: {
                v_t_2465 = NTAG(TAG_Nil);
                break;
              }
              case TAG_Just: {
                V v_x_2464 = heff_field(v_x2_2463, 0);
                heff_take_n(v_x2_2463, 1ULL, 1);
                v_t_2465 = v_x_2464;
                break;
              }
              default: heff_nomatch(v_x2_2463);
              }
              V v_t_2466 = ({ V a_0 = v_t_2462; V a_1 = v_t_2465; V r_ = (g_heff_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_2462); heff_drop(v_t_2465); r_; });
              switch (heff_tag_of(v_t_2466)) {
              case TAG_True: {
                heff_drop_tag(v_best_2433, 1);
                V v_t_2467 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), MK_INT(0LL), MK_INT(1LL)));
                V v_t_2468 = heff_intSub(heff_strLength(heff_dup(v_v_2438)), MK_INT(1LL));
                V v_t_2469 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), v_t_2468, MK_INT(-1LL)));
                V v_t_2470 = heff_strSlice(v_v_2438, v_t_2467, heff_intAdd(v_t_2469, MK_INT(1LL)));
                return heff_tag_at(v_ru_24t_2444_24Just, TAG_Just, 1, (V[]){v_t_2470});
              }
              case TAG_False: {
                heff_drop(v_v_2438);
                heff_drop_cell(v_ru_24t_2444_24Just, 1);
                return v_best_2433;
              }
              default: return heff_nomatch(v_t_2466);
              }
            }
            default: return heff_nomatch(v_best_2433);
            }
          }
          case TAG_Just: {
            heff_take_n(v_t_2450, 0ULL, 1);
            heff_drop(v_v_2438);
            heff_drop_cell(v_ru_24t_2444_24Just, 1);
            return v_best_2433;
          }
          default: return heff_nomatch(v_t_2450);
          }
        }
        default: return heff_nomatch(v_t_2444);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it22_2439, 0ULL, 2);
        heff_drop(v_path_240);
        heff_drop(v_v_2438);
        return v_best_2433;
      }
      default: return heff_nomatch(v_it22_2439);
      }
    }
    default: return heff_nomatch(v_it2_2437);
    }
  }
  default: return heff_nomatch(v_it_2435);
  }
}
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_intEq(heff_get(heff_dup(v_x_2419), LBL_status), MK_INT(0LL));
  V v_t_2424;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_True: {
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2424 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_x_2493;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_True: {
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str6), (g_heff_2eproject_2erepoOf(v_path_240)));
    V v_s_2426 = heff_get(v_x_2419, LBL_err);
    V v_t_2427 = (g_prelude_2eskipSpaces(heff_dup(v_s_2426), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2428 = heff_intSub(heff_strLength(heff_dup(v_s_2426)), MK_INT(1LL));
    V v_t_2429 = (g_prelude_2eskipSpaces(heff_dup(v_s_2426), v_t_2428, MK_INT(-1LL)));
    V v_t_2430 = heff_strSlice(v_s_2426, v_t_2427, heff_intAdd(v_t_2429, MK_INT(1LL)));
    V v_t_2431 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str7), heff_strAppend(v_t_2425, heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str8), v_t_2430)));
    v_x_2493 = heff_tag(TAG_Left, 1, (V[]){v_t_2431});
    break;
  }
  case TAG_False: {
    V v_t_2432 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str9), heff_get(v_x_2419, LBL_out), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2474 = ({ V a_0 = heff_clo(g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam6, 2, 1, (V[]){heff_dup(v_path_240)}); V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2432; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2432); r_; });
    switch (heff_tag_of(v_t_2474)) {
    case TAG_Nothing: {
      V v_t_2475 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str11), (g_heff_2eproject_2erepoOf(heff_dup(v_path_240))));
      V v_xs_2476 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str12), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2477 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2476));
      V v_x_2480;
      switch (heff_tag_of(v_t_2477)) {
      case TAG_Nil: {
        v_x_2480 = heff_dup(v_path_240);
        break;
      }
      case TAG_Cons: {
        V v_x_2478 = heff_field(v_t_2477, 0);
        heff_take_n(v_t_2477, 1ULL, 2);
        v_x_2480 = v_x_2478;
        break;
      }
      default: heff_nomatch(v_t_2477);
      }
      V v_t_2481 = heff_intLe(MK_INT(2LL), heff_strLength(heff_dup(v_x_2480)));
      V v_t_2490;
      switch (heff_tag_of(v_t_2481)) {
      case TAG_True: {
        V v_t_2482 = heff_strEq(heff_strSlice(heff_dup(v_x_2480), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str13));
        switch (heff_tag_of(v_t_2482)) {
        case TAG_True: {
          V v_t_2483 = heff_strSlice(heff_dup(v_x_2480), MK_INT(1LL), heff_strLength(v_x_2480));
          V v_t_2484 = (g_heff_2eproject_2eisNumber(v_t_2483));
          switch (heff_tag_of(v_t_2484)) {
          case TAG_True: {
            V v_xs_2485 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str14), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
            V v_t_2486 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2485));
            V v_t_2489;
            switch (heff_tag_of(v_t_2486)) {
            case TAG_Nil: {
              v_t_2489 = heff_dup(v_path_240);
              break;
            }
            case TAG_Cons: {
              V v_x_2487 = heff_field(v_t_2486, 0);
              heff_take_n(v_t_2486, 1ULL, 2);
              v_t_2489 = v_x_2487;
              break;
            }
            default: heff_nomatch(v_t_2486);
            }
            v_t_2490 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str15), v_t_2489);
            break;
          }
          case TAG_False: {
            v_t_2490 = ((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str16);
            break;
          }
          default: heff_nomatch(v_t_2484);
          }
          break;
        }
        case TAG_False: {
          heff_drop(v_x_2480);
          v_t_2490 = ((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str17);
          break;
        }
        default: heff_nomatch(v_t_2482);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_x_2480);
        v_t_2490 = ((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str18);
        break;
      }
      default: heff_nomatch(v_t_2481);
      }
      V v_t_2491 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str19), heff_strAppend(v_t_2475, heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str20), heff_strAppend(v_path_240, heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str21), heff_strAppend(v_t_2490, ((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str22)))))));
      v_x_2493 = heff_tag(TAG_Left, 1, (V[]){v_t_2491});
      break;
    }
    case TAG_Just: {
      V v_v_2492 = heff_field(v_t_2474, 0);
      V v_ru_24t_2474_24Just = heff_take_reuse_n(v_t_2474, 1ULL, 1);
      heff_drop(v_path_240);
      v_x_2493 = heff_tag_at(v_ru_24t_2474_24Just, TAG_Right, 1, (V[]){v_v_2492});
      break;
    }
    default: heff_nomatch(v_t_2474);
    }
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  V f_ = v_k_242;
  args[0] = v_x_2493;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_path_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2420 = heff_tag(TAG_End, 2, (V[]){v_x_246, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2421, heff_clo(g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam5, 1, 3, (V[]){v_x_2419, v_path_240, v_k_242})});
}
V g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str1), (g_heff_2eproject_2erepoOf(heff_dup(v_path_240))));
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str2), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str3), v_t_248})});
  V v_as_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_str4), v_t_249});
  V v_c_2418 = heff_clo(g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam2, 2, 1, (V[]){v_as_2410});
  return heff_tail(v_c_2418, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2enewestTag_24s456807686x23137961_lam4, 1, 4, (V[]){v_x_246, v_hd_241, v_path_240, v_k_242})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str2 = {{0x80000000u, K_STR, 0}, 27, 27, {96, 32, 105, 115, 32, 114, 101, 113, 117, 105, 114, 101, 100, 32, 97, 108, 114, 101, 97, 100, 121, 58, 32, 97, 100, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str3 = {{0x80000000u, K_STR, 0}, 30, 30, {32, 116, 111, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 98, 121, 32, 97, 110, 111, 116, 104, 101, 114, 32, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str4 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str6 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str7 = {{0x80000000u, K_STR, 0}, 30, 30, {104, 101, 102, 102, 32, 103, 101, 116, 58, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 114, 101, 113, 117, 105, 114, 101, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str10 = {{0x80000000u, K_STR, 0}, 23, 23, {99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam2(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam4(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam5(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam6(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam7(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam9(V self, V *args); static Clo g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam9, 1, 0};
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam8(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam11(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam12(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam10(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam3(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam1(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam0(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam14(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam13(V self, V *args);
Clo g_heff_2ecommands_2egetRequire_24s714371532x1125504469_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetRequire_24s714371532x1125504469_entry, 5, 0};

V g_heff_2ecommands_2egetRequire_24s714371532x1125504469(V v_ps_240, V v_text_241, V v_pk_242, V v_path_243, V v_v_244) {
top: ;
  V v_t_245 = (g_heff_2eproject_2emajorMismatch(heff_dup(v_path_243), heff_dup(v_v_244)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_c_246 = (g_heff_2ecommands_2efetched_24s1467657534x990122053(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
    return heff_clo(g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam0, 2, 6, (V[]){v_c_246, v_ps_240, v_path_243, v_v_244, v_pk_242, v_text_241});
  }
  case TAG_Just: {
    V v_why_2456 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    heff_drop(v_ps_240);
    heff_drop(v_text_241);
    heff_drop(v_pk_242);
    heff_drop(v_v_244);
    return heff_clo(g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam13, 2, 2, (V[]){v_path_243, v_why_2456});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2egetRequire_24s714371532x1125504469(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2411);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2424);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam5(V self, V *args) {
  V v_r_2426 = args[0];
  V v_path_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_r_2426, LBL_path), v_path_243);
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam6(V self, V *args) {
  V v_r_2428 = args[0];
  V v_name_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_r_2428, LBL_name), v_name_2425);
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam7(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2431);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam9(V self, V *args) {
  V v_ok_2441 = args[0];
  return v_ok_2441;
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam8(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k2_2440 = args[1];
  V v_str_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){((V)&g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str6), v_str_2438, ((V)&g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam9_clo)})});
  V v_t_2443 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2439), LBL_malg), 1, (V[]){v_t_2444}));
  V f_ = heff_get(v_hd_2439, LBL_bind);
  args[0] = v_t_2445;
  args[1] = v_k2_2440;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam11(V self, V *args) {
  V v_x_2454 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2454);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam12(V self, V *args) {
  V v_x_2455 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2455);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam10(V self, V *args) {
  V v_x_2447 = args[0];
  V v_path_243 = heff_env(self)[0];
  V v_v_244 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2447)) {
  case TAG_True: {
    V v_t_2448 = heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str7), heff_strAppend(v_path_243, heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str8), v_v_244)));
    V v_t_2449 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2448, ((V)&g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str9)), NTAG(TAG_MkUnit)});
    V v_t_2450 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2452}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2453, heff_clo(g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam11, 1, 1, (V[]){v_k_248})});
  }
  case TAG_False: {
    heff_drop(v_path_243);
    heff_drop(v_v_244);
    return (g_heff_2ecommands_2egetFails_24s970500795x1113151702(((V)&g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str10), v_hd_247, heff_clo(g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam12, 1, 1, (V[]){v_k_248})));
  }
  default: return heff_nomatch(v_x_2447);
  }
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  V v_pk_242 = heff_env(self)[3];
  V v_v_244 = heff_env(self)[4];
  V v_text_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    V v_why_2423 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    heff_drop(v_path_243);
    heff_drop(v_pk_242);
    heff_drop(v_v_244);
    heff_drop(v_text_241);
    return (g_heff_2ecommands_2egetFails_24s970500795x1113151702(v_why_2423, v_hd_247, heff_clo(g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam4, 1, 1, (V[]){v_k_248})));
  }
  case TAG_Right: {
    V v_name_2425 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    V v_x1_2427 = ({ V a_0 = heff_clo(g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam5, 1, 1, (V[]){heff_dup(v_path_243)}); V b_1 = heff_get(heff_dup(v_pk_242), LBL_require); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2429;
    switch (heff_tag_of(v_x1_2427)) {
    case TAG_True: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2429 = ({ V a_0 = heff_clo(g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam6, 1, 1, (V[]){heff_dup(v_name_2425)}); V b_1 = heff_get(heff_dup(v_pk_242), LBL_require); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2427);
    }
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      heff_drop(v_pk_242);
      heff_drop(v_v_244);
      heff_drop(v_text_241);
      V v_t_2430 = heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str1), heff_strAppend(v_name_2425, heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str2), heff_strAppend(v_path_243, ((V)&g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str3)))));
      return (g_heff_2ecommands_2egetFails_24s970500795x1113151702(v_t_2430, v_hd_247, heff_clo(g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam7, 1, 1, (V[]){v_k_248})));
    }
    case TAG_False: {
      V v_t_2432 = (g_heff_2ecommands_2erequiring(v_pk_242, v_name_2425, heff_dup(v_path_243), heff_dup(v_v_244)));
      V v_text_2433 = (g_heff_2eproject_2ewithPackage(v_text_241, v_t_2432));
      V v_t_2434 = heff_strEq(heff_strSlice(((V)&g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str4), MK_INT(7LL), MK_INT(10LL)), ((V)&g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str5));
      V v_str_2438;
      switch (heff_tag_of(v_t_2434)) {
      case TAG_True: {
        V v_t_2435 = (g_heff_2eformat_2eformat(heff_dup(v_text_2433)));
        switch (heff_tag_of(v_t_2435)) {
        case TAG_Left: {
          heff_take_n(v_t_2435, 0ULL, 1);
          v_str_2438 = v_text_2433;
          break;
        }
        case TAG_Right: {
          V v_out_2437 = heff_field(v_t_2435, 0);
          heff_take_n(v_t_2435, 1ULL, 1);
          heff_drop(v_text_2433);
          v_str_2438 = v_out_2437;
          break;
        }
        default: heff_nomatch(v_t_2435);
        }
        break;
      }
      case TAG_False: {
        v_str_2438 = v_text_2433;
        break;
      }
      default: heff_nomatch(v_t_2434);
      }
      V v_c_2446 = heff_clo(g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam8, 2, 1, (V[]){v_str_2438});
      return heff_tail(v_c_2446, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam10, 1, 4, (V[]){v_path_243, v_v_244, v_hd_247, v_k_248})});
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_path_243 = heff_env(self)[3];
  V v_v_244 = heff_env(self)[4];
  V v_pk_242 = heff_env(self)[5];
  V v_text_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    V v_why_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_ps_240);
    heff_drop(v_path_243);
    heff_drop(v_v_244);
    heff_drop(v_pk_242);
    heff_drop(v_text_241);
    return (g_heff_2ecommands_2egetFails_24s970500795x1113151702(v_why_2410, v_hd_247, heff_clo(g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam2, 1, 1, (V[]){v_k_248})));
  }
  case TAG_Right: {
    heff_take_n(v_x_249, 0ULL, 1);
    V v_st_2413 = heff_get(heff_dup(v_ps_240), LBL_style);
    V v_a_2414 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
    V v_t_2415 = (g_std_2epath_2eparse(v_st_2413, v_a_2414));
    V v_t_2416 = (g_std_2epath_2eparse(v_st_2413, ((V)&g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str0)));
    V v_p_2417 = (g_std_2epath_2ejoin_2eonto_240(v_t_2415, v_t_2416));
    V v_t_2418 = ({ V a_0 = heff_get(heff_dup(v_p_2417), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2417), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2419 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2417), LBL_drive), heff_get(v_p_2417, LBL_absolute), v_t_2418});
    V v_t_2420 = ({ V a_0 = v_st_2413; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2413); r_; });
    V v_c_2421 = heff_tr(heff_apply(((V)&g_heff_2eload_2eownDir_24s36575787x1607510651_clo), 2, (V[]){v_ps_240, v_t_2420}));
    return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam3, 1, 6, (V[]){v_hd_247, v_k_248, v_path_243, v_pk_242, v_v_244, v_text_241})});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  V v_v_244 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  V v_text_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam1, 1, 7, (V[]){v_hd_247, v_k_248, v_ps_240, v_path_243, v_v_244, v_pk_242, v_text_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam14(V self, V *args) {
  V v_x_2460 = args[0];
  V v_k_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2460);
  V f_ = v_k_2458;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam13(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  V v_path_243 = heff_env(self)[0];
  V v_why_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = heff_strAppend(v_path_243, heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s714371532x1125504469_str11), v_why_2456));
  return (g_heff_2ecommands_2egetFails_24s970500795x1113151702(v_t_2459, v_hd_2457, heff_clo(g_heff_2ecommands_2egetRequire_24s714371532x1125504469_lam14, 1, 1, (V[]){v_k_2458})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetCmd_24s10896657x118494199_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2ecommands_2egetCmd_24s10896657x118494199_str1 = {{0x80000000u, K_STR, 0}, 45, 45, {110, 111, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 104, 101, 114, 101, 58, 32, 103, 101, 116, 32, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2ecommands_2egetCmd_24s10896657x118494199_str2 = {{0x80000000u, K_STR, 0}, 24, 24, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 114, 101, 97, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetCmd_24s10896657x118494199_str3 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetCmd_24s10896657x118494199_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {64}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetCmd_24s10896657x118494199_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {64}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetCmd_24s10896657x118494199_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2egetCmd_24s10896657x118494199_str7 = {{0x80000000u, K_STR, 0}, 22, 22, {96, 32, 105, 115, 32, 110, 111, 32, 118, 101, 114, 115, 105, 111, 110, 58, 32, 97, 46, 98, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetCmd_24s10896657x118494199_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {64}};
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam0(V self, V *args); static Clo g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam0, 1, 0};
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam4(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam6(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam5(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam3(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam2(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam1(V self, V *args);
Clo g_heff_2ecommands_2egetCmd_24s10896657x118494199_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetCmd_24s10896657x118494199_entry, 3, 0};

V g_heff_2ecommands_2egetCmd_24s10896657x118494199(V v_spec_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ecommands_2egetCmd_24s10896657x118494199_str0), ((V)&g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam0_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_spec_240})});
}
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2egetCmd_24s10896657x118494199(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam0(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam4(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_v_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = heff_tag(TAG_Right, 1, (V[]){v_v_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam6(V self, V *args) {
  V v_x_2462 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2462)) {
  case TAG_True: {
    return heff_tail(heff_dup(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_get()), 2, (V[]){v_hd_241, v_k_242});
  }
  case TAG_False: {
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2462);
  }
}
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_s_2413 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_t_249 = heff_env(self)[4];
  V v_pk_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2444)) {
  case TAG_Left: {
    V v_why_2445 = heff_field(v_x_2444, 0);
    heff_take_n(v_x_2444, 1ULL, 1);
    heff_drop(v_s_2413);
    heff_drop(v_x_2417);
    heff_drop(v_t_249);
    heff_drop(v_pk_2412);
    return (g_heff_2ecommands_2egetFails_24s970500795x1113151702(v_why_2445, v_hd_241, v_k_242));
  }
  case TAG_Right: {
    V v_ver_2446 = heff_field(v_x_2444, 0);
    V v_ru_24x_2444_24Right = heff_take_reuse_n(v_x_2444, 1ULL, 1);
    V v_t_2447 = (g_heff_2eproject_2eversion(heff_dup(v_ver_2446)));
    switch (heff_tag_of(v_t_2447)) {
    case TAG_Nothing: {
      heff_drop(v_s_2413);
      heff_drop(v_x_2417);
      heff_drop(v_t_249);
      heff_drop(v_pk_2412);
      heff_drop_cell(v_ru_24x_2444_24Right, 1);
      V v_t_2448 = heff_strAppend(((V)&g_heff_2ecommands_2egetCmd_24s10896657x118494199_str6), heff_strAppend(v_ver_2446, ((V)&g_heff_2ecommands_2egetCmd_24s10896657x118494199_str7)));
      return (g_heff_2ecommands_2egetFails_24s970500795x1113151702(v_t_2448, v_hd_241, v_k_242));
    }
    case TAG_Just: {
      heff_take_n(v_t_2447, 0ULL, 1);
      V v_it_2450 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2egetCmd_24s10896657x118494199_str8), heff_dup(v_s_2413), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_x1_2457;
      switch (heff_tag_of(v_it_2450)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x_2444_24Right, 1);
        v_x1_2457 = heff_tag(TAG_MkPair, 2, (V[]){v_s_2413, NTAG(TAG_Nothing)});
        break;
      }
      case TAG_Cons: {
        V v_path_2451 = heff_field(v_it_2450, 0);
        V v_it2_2452 = heff_field(v_it_2450, 1);
        V v_ru_24it_2450_24Cons = heff_take_reuse_n(v_it_2450, 3ULL, 2);
        switch (heff_tag_of(v_it2_2452)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x_2444_24Right, 1);
          heff_drop(v_path_2451);
          v_x1_2457 = heff_tag_at(v_ru_24it_2450_24Cons, TAG_MkPair, 2, (V[]){v_s_2413, NTAG(TAG_Nothing)});
          break;
        }
        case TAG_Cons: {
          V v_v_2453 = heff_field(v_it2_2452, 0);
          V v_it22_2454 = heff_field(v_it2_2452, 1);
          heff_take_n(v_it2_2452, 3ULL, 2);
          switch (heff_tag_of(v_it22_2454)) {
          case TAG_Nil: {
            heff_drop(v_s_2413);
            v_x1_2457 = heff_tag_at(v_ru_24it_2450_24Cons, TAG_MkPair, 2, (V[]){v_path_2451, heff_tag_at(v_ru_24x_2444_24Right, TAG_Just, 1, (V[]){v_v_2453})});
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_it22_2454, 0ULL, 2);
            heff_drop_cell(v_ru_24x_2444_24Right, 1);
            heff_drop(v_path_2451);
            heff_drop(v_v_2453);
            v_x1_2457 = heff_tag_at(v_ru_24it_2450_24Cons, TAG_MkPair, 2, (V[]){v_s_2413, NTAG(TAG_Nothing)});
            break;
          }
          default: heff_nomatch(v_it22_2454);
          }
          break;
        }
        default: heff_nomatch(v_it2_2452);
        }
        break;
      }
      default: heff_nomatch(v_it_2450);
      }
      V v_t_2460;
      switch (heff_tag_of(v_x1_2457)) {
      case TAG_MkPair: {
        V v_x_2458 = heff_field(v_x1_2457, 0);
        heff_take_n(v_x1_2457, 1ULL, 2);
        v_t_2460 = v_x_2458;
        break;
      }
      default: heff_nomatch(v_x1_2457);
      }
      V v_c_2461 = (g_heff_2ecommands_2egetRequire_24s714371532x1125504469(v_x_2417, v_t_249, v_pk_2412, v_t_2460, v_ver_2446));
      return heff_tail(v_c_2461, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam6, 1, 2, (V[]){v_hd_241, v_k_242})});
    }
    default: return heff_nomatch(v_t_2447);
    }
  }
  default: return heff_nomatch(v_x_2444);
  }
}
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_s_2413 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_249 = heff_env(self)[3];
  V v_pk_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_it_2418 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2egetCmd_24s10896657x118494199_str4), heff_dup(v_s_2413), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_x1_2425;
  switch (heff_tag_of(v_it_2418)) {
  case TAG_Nil: {
    v_x1_2425 = heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_s_2413), NTAG(TAG_Nothing)});
    break;
  }
  case TAG_Cons: {
    V v_path_2419 = heff_field(v_it_2418, 0);
    V v_it2_2420 = heff_field(v_it_2418, 1);
    V v_ru_24it_2418_24Cons = heff_take_reuse_n(v_it_2418, 3ULL, 2);
    switch (heff_tag_of(v_it2_2420)) {
    case TAG_Nil: {
      heff_drop(v_path_2419);
      v_x1_2425 = heff_tag_at(v_ru_24it_2418_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2413), NTAG(TAG_Nothing)});
      break;
    }
    case TAG_Cons: {
      V v_v_2421 = heff_field(v_it2_2420, 0);
      V v_it22_2422 = heff_field(v_it2_2420, 1);
      heff_take_n(v_it2_2420, 3ULL, 2);
      switch (heff_tag_of(v_it22_2422)) {
      case TAG_Nil: {
        v_x1_2425 = heff_tag_at(v_ru_24it_2418_24Cons, TAG_MkPair, 2, (V[]){v_path_2419, heff_tag(TAG_Just, 1, (V[]){v_v_2421})});
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_it22_2422, 0ULL, 2);
        heff_drop(v_path_2419);
        heff_drop(v_v_2421);
        v_x1_2425 = heff_tag_at(v_ru_24it_2418_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2413), NTAG(TAG_Nothing)});
        break;
      }
      default: heff_nomatch(v_it22_2422);
      }
      break;
    }
    default: heff_nomatch(v_it2_2420);
    }
    break;
  }
  default: heff_nomatch(v_it_2418);
  }
  V v_t_2428;
  switch (heff_tag_of(v_x1_2425)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_field(v_x1_2425, 1);
    heff_take_n(v_x1_2425, 2ULL, 2);
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_x1_2425);
  }
  V v_c_2443;
  switch (heff_tag_of(v_t_2428)) {
  case TAG_Nothing: {
    V v_it_2429 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2egetCmd_24s10896657x118494199_str5), heff_dup(v_s_2413), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x1_2436;
    switch (heff_tag_of(v_it_2429)) {
    case TAG_Nil: {
      v_x1_2436 = heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_s_2413), NTAG(TAG_Nothing)});
      break;
    }
    case TAG_Cons: {
      V v_path_2430 = heff_field(v_it_2429, 0);
      V v_it2_2431 = heff_field(v_it_2429, 1);
      V v_ru_24it_2429_24Cons = heff_take_reuse_n(v_it_2429, 3ULL, 2);
      switch (heff_tag_of(v_it2_2431)) {
      case TAG_Nil: {
        heff_drop(v_path_2430);
        v_x1_2436 = heff_tag_at(v_ru_24it_2429_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2413), NTAG(TAG_Nothing)});
        break;
      }
      case TAG_Cons: {
        V v_v_2432 = heff_field(v_it2_2431, 0);
        V v_it22_2433 = heff_field(v_it2_2431, 1);
        heff_take_n(v_it2_2431, 3ULL, 2);
        switch (heff_tag_of(v_it22_2433)) {
        case TAG_Nil: {
          v_x1_2436 = heff_tag_at(v_ru_24it_2429_24Cons, TAG_MkPair, 2, (V[]){v_path_2430, heff_tag(TAG_Just, 1, (V[]){v_v_2432})});
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2433, 0ULL, 2);
          heff_drop(v_path_2430);
          heff_drop(v_v_2432);
          v_x1_2436 = heff_tag_at(v_ru_24it_2429_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2413), NTAG(TAG_Nothing)});
          break;
        }
        default: heff_nomatch(v_it22_2433);
        }
        break;
      }
      default: heff_nomatch(v_it2_2431);
      }
      break;
    }
    default: heff_nomatch(v_it_2429);
    }
    V v_t_2439;
    switch (heff_tag_of(v_x1_2436)) {
    case TAG_MkPair: {
      V v_x_2437 = heff_field(v_x1_2436, 0);
      heff_take_n(v_x1_2436, 1ULL, 2);
      v_t_2439 = v_x_2437;
      break;
    }
    default: heff_nomatch(v_x1_2436);
    }
    v_c_2443 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2enewestTag_24s456807686x23137961_clo), 1, (V[]){v_t_2439}));
    break;
  }
  case TAG_Just: {
    V v_v_2440 = heff_field(v_t_2428, 0);
    heff_take_n(v_t_2428, 1ULL, 1);
    v_c_2443 = heff_clo(g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam4, 2, 1, (V[]){v_v_2440});
    break;
  }
  default: heff_nomatch(v_t_2428);
  }
  return heff_tail(v_c_2443, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam5, 1, 6, (V[]){v_hd_241, v_k_242, v_s_2413, v_x_2417, v_t_249, v_pk_2412})});
}
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_s_2413 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_249 = heff_env(self)[3];
  V v_pk_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2416 = (g_heff_2eload_2epathsFor_24s382934904x1572524859(v_x_2415, ((V)&g_heff_2ecommands_2egetCmd_24s10896657x118494199_str3)));
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam3, 1, 5, (V[]){v_s_2413, v_hd_241, v_k_242, v_t_249, v_pk_2412})});
}
V g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_spec_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    heff_drop(v_spec_240);
    return (g_heff_2ecommands_2egetFails_24s970500795x1113151702(((V)&g_heff_2ecommands_2egetCmd_24s10896657x118494199_str1), v_hd_241, v_k_242));
  }
  case TAG_Just: {
    V v_t_249 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    V v_t_2410 = (g_heff_2eproject_2ereadPackage(heff_dup(v_t_249)));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Left: {
      heff_take_n(v_t_2410, 0ULL, 1);
      heff_drop(v_spec_240);
      heff_drop(v_t_249);
      return (g_heff_2ecommands_2egetFails_24s970500795x1113151702(((V)&g_heff_2ecommands_2egetCmd_24s10896657x118494199_str2), v_hd_241, v_k_242));
    }
    case TAG_Right: {
      V v_pk_2412 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      switch (heff_tag_of(v_spec_240)) {
      case TAG_Nothing: {
        heff_drop(v_t_249);
        heff_drop(v_pk_2412);
        return heff_tail(heff_dup(g_heff_2ecommands_2egetAll_24s1612850816x2083342759_get()), 2, (V[]){v_hd_241, v_k_242});
      }
      case TAG_Just: {
        V v_s_2413 = heff_field(v_spec_240, 0);
        heff_take_n(v_spec_240, 1ULL, 1);
        V v_c_2414 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
        return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetCmd_24s10896657x118494199_lam2, 1, 5, (V[]){v_hd_241, v_s_2413, v_k_242, v_t_249, v_pk_2412})});
      }
      default: return heff_nomatch(v_spec_240);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x_248);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam0(V self, V *args);
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam2(V self, V *args); static Clo g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam2, 1, 0};
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam4(V self, V *args); static Clo g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam4, 1, 0};
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam6(V self, V *args);
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam5(V self, V *args);
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam3(V self, V *args);
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam1(V self, V *args);
Clo g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_entry, 2, 0};

V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_241));
    return heff_clo(g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return heff_clo(g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam1, 2, 3, (V[]){v_p_245, v_rest_246, v_acc_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798(a[0], a[1]);
}
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam2(V self, V *args) {
  V v_ns_249 = args[0];
  return v_ns_249;
}
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam4(V self, V *args) {
  V v_s_2421 = args[0];
  return v_s_2421;
}
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam6(V self, V *args) {
  V v_n_2430 = args[0];
  V v_x_2428 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = (g_std_2epath_2eparse(v_x_2428, v_p_245));
  V v_t_2432 = (g_std_2epath_2eparse(v_x_2428, v_n_2430));
  V v_p_2433 = (g_std_2epath_2ejoin_2eonto_240(v_t_2431, v_t_2432));
  V v_t_2434 = ({ V a_0 = heff_get(heff_dup(v_p_2433), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2433), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2435 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2433), LBL_drive), heff_get(v_p_2433, LBL_absolute), v_t_2434});
  return ({ V a_0 = v_x_2428; V a_1 = v_t_2435; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2428); r_; });
}
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_ns_2420 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2427 = heff_strEq(v_x_2426, ((V)&g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_str1));
  V v_x_2428;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_True: {
    v_x_2428 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2428 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  V v_t_2429 = (g_prelude_2efilter_24s1642131147x1885675035(MK_INT(0LL), MK_INT(1LL), ((V)&g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_str2), v_ns_2420));
  V v_t_2436 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam6, 1, 2, (V[]){v_x_2428, v_p_245}), v_t_2429));
  V v_t_2437 = (g_prelude_2econcatList(v_t_2436, v_rest_246));
  V v_t_2438 = (g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798(v_t_2437, v_acc_241));
  return heff_tail(v_t_2438, 2, (V[]){v_hd_247, v_k_248});
}
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    V v_t_2415 = heff_intSub(heff_strLength(heff_dup(v_p_245)), MK_INT(3LL));
    V v_t_2416 = heff_strSlice(heff_dup(v_p_245), v_t_2415, heff_strLength(heff_dup(v_p_245)));
    V v_t_2417 = heff_strEq(v_t_2416, ((V)&g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_str0));
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      V v_t_2418 = (g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798(v_rest_246, heff_tag(TAG_Cons, 2, (V[]){v_p_245, v_acc_241})));
      return heff_tail(v_t_2418, 2, (V[]){v_hd_247, v_k_248});
    }
    case TAG_False: {
      heff_drop(v_p_245);
      V v_t_2419 = (g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798(v_rest_246, v_acc_241));
      return heff_tail(v_t_2419, 2, (V[]){v_hd_247, v_k_248});
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  case TAG_Just: {
    V v_ns_2420 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Just = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    V v_t_2422 = heff_tag_at(v_ru_24x_2414_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam4_clo)})});
    V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2424})}));
    return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2425, heff_clo(g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam5, 1, 6, (V[]){v_ns_2420, v_p_245, v_rest_246, v_acc_241, v_hd_247, v_k_248})});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){heff_dup(v_p_245), ((V)&g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam2_clo)})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2412}));
  V f_ = heff_get(heff_dup(v_hd_247), LBL_bind);
  args[0] = v_t_2413;
  args[1] = heff_clo(g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798_lam3, 1, 5, (V[]){v_p_245, v_rest_246, v_acc_241, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2echeckModule_24s137050040x160185575_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2echeckModule_24s137050040x160185575_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam3(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam5(V self, V *args); static Clo g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam5, 1, 0};
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam4(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam10(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam9(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam8(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam7(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam14(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam15(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam18(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam17(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam16(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam13(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam12(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam11(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam6(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam2(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam1(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam0(V self, V *args);
Clo g_heff_2ecommands_2echeckModule_24s137050040x160185575_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2echeckModule_24s137050040x160185575_entry, 3, 0};

V g_heff_2ecommands_2echeckModule_24s137050040x160185575(V v_chk_240, V v_acc_241, V v_f_242) {
top: ;
  V v_c_243 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  return heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam0, 2, 4, (V[]){v_c_243, v_f_242, v_acc_241, v_chk_240});
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2echeckModule_24s137050040x160185575(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2413);
  V f_ = v_k_245;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam5(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam4(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_chk_240 = heff_env(self)[0];
  V v_name_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){v_chk_240, v_name_2414, MK_INT(0LL), ((V)&g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam5_clo)})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2415), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2415, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2416;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam10(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2427 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = ({ V a_0 = v_x_2429; V a_1 = heff_get(heff_dup(v_x_2427), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_2429); r_; });
  V v_x_2431 = (g_prelude_2efoldl_24s1838030138x788027388(v_x_2427, v_t_2430));
  V f_ = v_k_2424;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam9(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_2423 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2428 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_2428, 2, (V[]){v_hd_2423, heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam10, 1, 2, (V[]){v_x_2427, v_k_2424})});
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam8(V self, V *args) {
  V v_x_2425 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_2423 = heff_env(self)[1];
  V v_k_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2426 = (g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(v_x_2425, v_f_242));
  return heff_tail(v_c_2426, 2, (V[]){heff_dup(v_hd_2423), heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam9, 1, 2, (V[]){v_hd_2423, v_k_2424})});
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam7(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam8, 1, 3, (V[]){v_f_242, v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam14(V self, V *args) {
  V v_c_2437 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_ps_2438 = heff_get(heff_dup(v_x_2433), LBL_paths);
  V v_d_2439 = heff_get(heff_get(v_x_2433, LBL_paths), LBL_src);
  V v_t_2440 = heff_strEq(heff_dup(v_d_2439), ((V)&g_heff_2ecommands_2echeckModule_24s137050040x160185575_str1));
  switch (heff_tag_of(v_t_2440)) {
  case TAG_True: {
    heff_drop(v_x_248);
    heff_drop(v_f_242);
    heff_drop(v_ps_2438);
    heff_drop(v_d_2439);
    V v_x1_2441 = ({ V a_0 = heff_get(v_c_2437, LBL_module); V b_1 = heff_get(v_acc_241, LBL_seen); V r_ = (g_heff_2ecommands_2eelemStrM(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2441)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2441);
    }
  }
  case TAG_False: {
    V v_t_2442 = (g_heff_2eload_2efromCwd(heff_dup(v_ps_2438), v_d_2439));
    V v_t_2443 = (g_heff_2eload_2efromCwd(heff_dup(v_ps_2438), heff_get(heff_dup(v_c_2437), LBL_path)));
    V v_t_2444 = ({ V b_0 = heff_get(v_ps_2438, LBL_style); V a_1 = v_t_2442; V a_2 = v_t_2443; V r_ = (g_std_2epath_2eisUnder(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_t_2444)) {
    case TAG_True: {
      heff_drop(v_x_248);
      heff_drop(v_f_242);
      V v_x1_2445 = ({ V a_0 = heff_get(v_c_2437, LBL_module); V b_1 = heff_get(v_acc_241, LBL_seen); V r_ = (g_heff_2ecommands_2eelemStrM(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_x1_2445)) {
      case TAG_True: {
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_2445);
      }
    }
    case TAG_False: {
      V v_t_2446 = (g_heff_2eload_2emoduleOf(v_x_248, v_f_242));
      V v_t_2447 = heff_strEq(heff_get(heff_dup(v_c_2437), LBL_module), v_t_2446);
      switch (heff_tag_of(v_t_2447)) {
      case TAG_True: {
        V v_x1_2448 = ({ V a_0 = heff_get(v_c_2437, LBL_module); V b_1 = heff_get(v_acc_241, LBL_seen); V r_ = (g_heff_2ecommands_2eelemStrM(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_x1_2448)) {
        case TAG_True: {
          return NTAG(TAG_False);
        }
        case TAG_False: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_x1_2448);
        }
      }
      case TAG_False: {
        heff_drop(v_c_2437);
        heff_drop(v_acc_241);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2447);
      }
    }
    default: return heff_nomatch(v_t_2444);
    }
  }
  default: return heff_nomatch(v_t_2440);
  }
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam15(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_x_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2450);
  V f_ = v_k_2451;
  args[0] = v_x_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam18(V self, V *args) {
  V v_x_2457 = args[0];
  V v_x_2453 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2457);
  V v_t_2458 = (g_prelude_2emap_24s772488398x992379409(heff_dup(v_x_2453)));
  V v_t_2459 = (g_prelude_2econcatList(v_t_2458, heff_get(heff_dup(v_acc_241), LBL_seen)));
  V v_t_2460 = heff_intAdd(heff_get(v_acc_241, LBL_errors), v_x_2434);
  V v_t_2461 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_x_2453; V r_ = (g_prelude_2efoldl_24s656731303x133259214(a_0, a_1, a_2, a_3)); heff_drop(v_x_2453); r_; });
  V v_x_2462 = heff_rec(2, shape_seen__errors, (V[]){v_t_2459, heff_intAdd(v_t_2460, v_t_2461)});
  V f_ = v_k_245;
  args[0] = v_x_2462;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam17(V self, V *args) {
  V v_x_2454 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_2453 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_x_2434 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2454);
  V v_t_2455 = heff_tag(TAG_End, 2, (V[]){v_x_2421, NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2455})}));
  return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2456, heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam18, 1, 4, (V[]){v_x_2453, v_acc_241, v_x_2434, v_k_245})});
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam16(V self, V *args) {
  V v_x_2453 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672(heff_dup(v_x_2453), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam17, 1, 6, (V[]){v_x_2421, v_hd_244, v_x_2453, v_acc_241, v_x_2434, v_k_245})));
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam13(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_x_2421 = heff_env(self)[5];
  V v_x_2434 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2449 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam14, 1, 4, (V[]){v_x_2433, heff_dup(v_acc_241), v_x_248, v_f_242}), v_x_2436));
  V v_c_2452 = heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam15, 2, 1, (V[]){v_x_2449});
  return heff_tail(v_c_2452, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam16, 1, 5, (V[]){v_hd_244, v_x_2421, v_acc_241, v_x_2434, v_k_245})});
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam12(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_x_2421 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2435 = (g_heff_2esession_2ecachedProgram_24s595918180x507103762(heff_dup(v_x_2433)));
  return heff_tail(v_c_2435, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam13, 1, 8, (V[]){v_x_2433, v_acc_241, v_x_248, v_f_242, v_hd_244, v_x_2421, v_x_2434, v_k_245})});
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam11(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_x_2421 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(((V)&g_heff_2ecommands_2echeckModule_24s137050040x160185575_str0), heff_get(heff_dup(v_x_2433), LBL_errors), MK_INT(0LL), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam12, 1, 7, (V[]){v_x_2433, v_hd_244, v_acc_241, v_x_248, v_f_242, v_x_2421, v_k_245})));
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2422 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  V v_c_2432 = heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam7, 2, 2, (V[]){v_c_2422, heff_dup(v_f_242)});
  return heff_tail(v_c_2432, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam11, 1, 6, (V[]){v_hd_244, v_acc_241, v_x_248, v_f_242, v_x_2421, v_k_245})});
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_chk_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = (g_heff_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_242)));
  V v_t_2410 = ({ V a_0 = v_t_249; V b_1 = heff_get(heff_dup(v_acc_241), LBL_seen); V r_ = (g_heff_2ecommands_2eelemStrM(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_x_248);
    heff_drop(v_f_242);
    V v_t_2411 = heff_tag(TAG_Complete, 2, (V[]){v_chk_240, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam3, 1, 2, (V[]){v_k_245, v_acc_241})});
  }
  case TAG_False: {
    V v_name_2414 = (g_heff_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_242)));
    V v_c_2420 = heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam4, 2, 2, (V[]){v_chk_240, v_name_2414});
    return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam6, 1, 5, (V[]){v_f_242, v_hd_244, v_acc_241, v_x_248, v_k_245})});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_chk_240 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2eload_2epathsFor_24s382934904x1572524859(v_x_246, heff_dup(v_f_242)));
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam2, 1, 5, (V[]){v_f_242, v_acc_241, v_chk_240, v_hd_244, v_k_245})});
}
V g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_chk_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo(g_heff_2ecommands_2echeckModule_24s137050040x160185575_lam1, 1, 5, (V[]){v_f_242, v_hd_244, v_acc_241, v_chk_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2echeckModules_24s831911915x2085898913_lam0(V self, V *args);
V g_heff_2ecommands_2echeckModules_24s831911915x2085898913_lam2(V self, V *args);
V g_heff_2ecommands_2echeckModules_24s831911915x2085898913_lam1(V self, V *args);
Clo g_heff_2ecommands_2echeckModules_24s831911915x2085898913_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2echeckModules_24s831911915x2085898913_entry, 3, 0};

V g_heff_2ecommands_2echeckModules_24s831911915x2085898913(V v_chk_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_chk_240);
    return heff_clo(g_heff_2ecommands_2echeckModules_24s831911915x2085898913_lam0, 2, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ecommands_2echeckModule_24s137050040x160185575(heff_dup(v_chk_240), v_acc_241, heff_dup(v_f_245)));
    return heff_clo(g_heff_2ecommands_2echeckModules_24s831911915x2085898913_lam1, 2, 3, (V[]){v_c_247, v_chk_240, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2echeckModules_24s831911915x2085898913_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2echeckModules_24s831911915x2085898913(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2ecommands_2echeckModules_24s831911915x2085898913_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2echeckModules_24s831911915x2085898913_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_chk_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = v_chk_240; V a_1 = v_x_2410; V a_2 = v_rest_246; V r_ = (g_heff_2ecommands_2echeckModules_24s831911915x2085898913(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  return heff_tail(v_t_2411, 2, (V[]){v_hd_248, v_k_249});
}
V g_heff_2ecommands_2echeckModules_24s831911915x2085898913_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_chk_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo(g_heff_2ecommands_2echeckModules_24s831911915x2085898913_lam2, 1, 4, (V[]){v_chk_240, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {104, 101, 102, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_str2 = {{0x80000000u, K_STR, 0}, 15, 15, {58, 32, 110, 111, 116, 104, 105, 110, 103, 32, 98, 117, 105, 108, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_lam0(V self, V *args);
Clo g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_entry, 4, 0};

V g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297(V v_cmd_240, V v_what_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_str0), heff_strAppend(v_cmd_240, heff_strAppend(((V)&g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_str1), heff_strAppend(v_what_241, ((V)&g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_str2)))));
  V v_t_245 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_244, ((V)&g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_str3)), NTAG(TAG_MkUnit)});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_lam0, 1, 2, (V[]){v_hd_242, v_k_243})});
}
V g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2410);
  V v_t_2411 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2415, v_k_243});
}
V g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam0(V self, V *args); static Clo g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam0, 1, 0};
V g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam2(V self, V *args); static Clo g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam2, 1, 0};
V g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam3(V self, V *args);
V g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam1(V self, V *args);
Clo g_heff_2ecommands_2eisThere_24s1074617931x1177790477_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eisThere_24s1074617931x1177790477_entry, 3, 0};

V g_heff_2ecommands_2eisThere_24s1074617931x1177790477(V v_path_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){heff_dup(v_path_240), ((V)&g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam0_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam1, 1, 3, (V[]){v_path_240, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2eisThere_24s1074617931x1177790477_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eisThere_24s1074617931x1177790477(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam0(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam2(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2416;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    v_x_2416 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2414, 0ULL, 1);
    v_x_2416 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V f_ = v_k_242;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_240, ((V)&g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam2_clo)})});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2412}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2ecommands_2eisThere_24s1074617931x1177790477_lam3, 1, 1, (V[]){v_k_242})});
  }
  case TAG_Just: {
    heff_take_n(v_x_248, 0ULL, 1);
    heff_drop(v_path_240);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2ecommands_2enotInProject_24s862706981x126166655_lam0(V self, V *args); static Clo g_heff_2ecommands_2enotInProject_24s862706981x126166655_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enotInProject_24s862706981x126166655_lam0, 2, 0};
V g_heff_2ecommands_2enotInProject_24s862706981x126166655_lam3(V self, V *args);
V g_heff_2ecommands_2enotInProject_24s862706981x126166655_lam2(V self, V *args);
V g_heff_2ecommands_2enotInProject_24s862706981x126166655_lam1(V self, V *args);
Clo g_heff_2ecommands_2enotInProject_24s862706981x126166655_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enotInProject_24s862706981x126166655_entry, 3, 0};

V g_heff_2ecommands_2enotInProject_24s862706981x126166655(V v_st_240, V v_t_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    return ((V)&g_heff_2ecommands_2enotInProject_24s862706981x126166655_lam0_clo);
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_root)));
    V v_t_248 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
    V v_p_249 = (g_std_2epath_2ejoin_2eonto_240(v_t_247, v_t_248));
    V v_t_2410 = ({ V a_0 = heff_get(heff_dup(v_p_249), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_249), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2411 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_249), LBL_drive), heff_get(v_p_249, LBL_absolute), v_t_2410});
    V v_t_2412 = (g_std_2epath_2erender(v_st_240, v_t_2411));
    V v_c_2413 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eisThere_24s1074617931x1177790477_clo), 1, (V[]){v_t_2412}));
    return heff_clo(g_heff_2ecommands_2enotInProject_24s862706981x126166655_lam1, 2, 5, (V[]){v_c_2413, heff_dup(v_st_240), v_t_241, v_rest_246, v_n_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2enotInProject_24s862706981x126166655_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2enotInProject_24s862706981x126166655(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2enotInProject_24s862706981x126166655_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2enotInProject_24s862706981x126166655_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_n_245 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2419;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_True: {
    heff_drop(v_n_245);
    v_x_2419 = v_x_2418;
    break;
  }
  case TAG_False: {
    v_x_2419 = heff_tag(TAG_Cons, 2, (V[]){v_n_245, v_x_2418});
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V f_ = v_k_2415;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2enotInProject_24s862706981x126166655_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2414 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_k_2415 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2417 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_rest_246; V r_ = (g_heff_2ecommands_2enotInProject_24s862706981x126166655(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  return heff_tail(v_c_2417, 2, (V[]){v_hd_2414, heff_clo(g_heff_2ecommands_2enotInProject_24s862706981x126166655_lam3, 1, 3, (V[]){v_x_2416, v_n_245, v_k_2415})});
}
V g_heff_2ecommands_2enotInProject_24s862706981x126166655_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo(g_heff_2ecommands_2enotInProject_24s862706981x126166655_lam2, 1, 6, (V[]){v_st_240, v_t_241, v_rest_246, v_hd_2414, v_n_245, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {98, 117, 105, 108, 100, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str5 = {{0x80000000u, K_STR, 0}, 11, 11, {58, 32, 105, 116, 32, 115, 104, 105, 112, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[33]; } g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str6 = {{0x80000000u, K_STR, 0}, 33, 33, {44, 32, 119, 104, 105, 99, 104, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 104, 97, 118, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eappShips_24s1825547416x1770957888_lam0(V self, V *args);
V g_heff_2ecommands_2eappShips_24s1825547416x1770957888_lam1(V self, V *args);
V g_heff_2ecommands_2eappShips_24s1825547416x1770957888_lam3(V self, V *args);
V g_heff_2ecommands_2eappShips_24s1825547416x1770957888_lam2(V self, V *args);
Clo g_heff_2ecommands_2eappShips_24s1825547416x1770957888_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eappShips_24s1825547416x1770957888_entry, 6, 0};

V g_heff_2ecommands_2eappShips_24s1825547416x1770957888(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_a_244, V v_missing_245) {
top: ;
  switch (heff_tag_of(v_missing_245)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    return heff_clo(g_heff_2ecommands_2eappShips_24s1825547416x1770957888_lam0, 2, 3, (V[]){v_x_243, v_a_244, v_acc_242});
  }
  case TAG_Cons: {
    heff_drop(v_a_244);
    V v_t_2412 = (g_heff_2ecommands_2eappFile(v_st_240, v_t_241, v_x_243, ((V)&g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str0)));
    V v_x2_2413 = (g_prelude_2emap_24s1537567598x716246174(((V)&g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str1), ((V)&g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str2), v_missing_245));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str4); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_str_2417 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str5), heff_strAppend(v_t_2416, ((V)&g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str6))));
    V v_c_2425 = heff_clo(g_heff_2ecommands_2eappShips_24s1825547416x1770957888_lam1, 2, 1, (V[]){v_str_2417});
    return heff_clo(g_heff_2ecommands_2eappShips_24s1825547416x1770957888_lam2, 2, 2, (V[]){v_c_2425, v_acc_242});
  }
  default: return heff_nomatch(v_missing_245);
  }
}
V g_heff_2ecommands_2eappShips_24s1825547416x1770957888_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eappShips_24s1825547416x1770957888(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eappShips_24s1825547416x1770957888_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_246);
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_name__build, (V[]){v_x_243, v_a_244}), heff_get(heff_dup(v_acc_242), LBL_apps)});
  V v_t_249 = heff_rec(2, shape_apps__bad, (V[]){v_t_248, heff_get(v_acc_242, LBL_bad)});
  V f_ = v_k_247;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eappShips_24s1825547416x1770957888_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k2_2419 = args[1];
  V v_str_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2417, ((V)&g_heff_2ecommands_2eappShips_24s1825547416x1770957888_str7)), NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2418), LBL_malg), 1, (V[]){v_t_2423}));
  V f_ = heff_get(v_hd_2418, LBL_bind);
  args[0] = v_t_2424;
  args[1] = v_k2_2419;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eappShips_24s1825547416x1770957888_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_intAdd(heff_get(heff_dup(v_acc_242), LBL_bad), MK_INT(1LL));
  V v_t_2430 = heff_rec(2, shape_apps__bad, (V[]){heff_get(v_acc_242, LBL_apps), v_t_2429});
  V f_ = v_k_2427;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eappShips_24s1825547416x1770957888_lam2(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2425;
  args[0] = v_hd_2426;
  args[1] = heff_clo(g_heff_2ecommands_2eappShips_24s1825547416x1770957888_lam3, 1, 2, (V[]){v_acc_242, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eappRead_24s850601752x1675975415_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {98, 117, 105, 108, 100, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eappRead_24s850601752x1675975415_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam0(V self, V *args);
V g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam1(V self, V *args);
V g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam3(V self, V *args);
V g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam2(V self, V *args);
V g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam5(V self, V *args);
V g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam4(V self, V *args);
Clo g_heff_2ecommands_2eappRead_24s850601752x1675975415_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eappRead_24s850601752x1675975415_entry, 5, 0};

V g_heff_2ecommands_2eappRead_24s850601752x1675975415(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    heff_drop(v_x_243);
    return heff_clo(g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Just: {
    V v_text_247 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V v_t_248 = (g_heff_2eproject_2ereadBuild(heff_dup(v_text_247)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Left: {
      V v_p_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      V v_t_2410 = (g_heff_2ecommands_2eappFile(v_st_240, v_t_241, v_x_243, ((V)&g_heff_2ecommands_2eappRead_24s850601752x1675975415_str0)));
      V v_str_2411 = (g_heff_2eload_2eproblemMsg(v_t_2410, v_text_247, v_p_249));
      V v_c_2419 = heff_clo(g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam1, 2, 1, (V[]){v_str_2411});
      return heff_clo(g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam2, 2, 2, (V[]){v_c_2419, v_acc_242});
    }
    case TAG_Right: {
      V v_a_2425 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      heff_drop(v_text_247);
      V v_c_2426 = (g_heff_2ecommands_2enotInProject_24s862706981x126166655(v_st_240, heff_dup(v_t_241), heff_get(heff_dup(v_a_2425), LBL_ships)));
      return heff_clo(g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam4, 2, 6, (V[]){v_c_2426, heff_dup(v_st_240), v_t_241, v_acc_242, v_x_243, v_a_2425});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecommands_2eappRead_24s850601752x1675975415_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eappRead_24s850601752x1675975415(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_str_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2411, ((V)&g_heff_2ecommands_2eappRead_24s850601752x1675975415_str1)), NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2417}));
  V f_ = heff_get(v_hd_2412, LBL_bind);
  args[0] = v_t_2418;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_intAdd(heff_get(heff_dup(v_acc_242), LBL_bad), MK_INT(1LL));
  V v_t_2424 = heff_rec(2, shape_apps__bad, (V[]){heff_get(v_acc_242, LBL_apps), v_t_2423});
  V f_ = v_k_2421;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo(g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam3, 1, 2, (V[]){v_acc_242, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_a_2425 = heff_env(self)[4];
  V v_hd_2427 = heff_env(self)[5];
  V v_k_2428 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2430 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_acc_242; V a_3 = v_x_243; V a_4 = v_a_2425; V a_5 = v_x_2429; V r_ = (g_heff_2ecommands_2eappShips_24s1825547416x1770957888(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_240); r_; });
  return heff_tail(v_t_2430, 2, (V[]){v_hd_2427, v_k_2428});
}
V g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam4(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_a_2425 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2426;
  args[0] = heff_dup(v_hd_2427);
  args[1] = heff_clo(g_heff_2ecommands_2eappRead_24s850601752x1675975415_lam5, 1, 7, (V[]){v_st_240, v_t_241, v_acc_242, v_x_243, v_a_2425, v_hd_2427, v_k_2428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eappsIn_24s1939917301x724821635_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {98, 117, 105, 108, 100, 46, 104, 102}};
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam0(V self, V *args);
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam2(V self, V *args); static Clo g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam2, 1, 0};
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam1(V self, V *args);
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam6(V self, V *args);
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam5(V self, V *args);
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam4(V self, V *args);
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam3(V self, V *args);
Clo g_heff_2ecommands_2eappsIn_24s1939917301x724821635_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eappsIn_24s1939917301x724821635_entry, 5, 0};

V g_heff_2ecommands_2eappsIn_24s1939917301x724821635(V v_st_240, V v_t_241, V v_rd_242, V v_acc_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    heff_drop(v_rd_242);
    V v_t_245 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_243), LBL_apps)));
    V v_x_246 = heff_rec(2, shape_apps__bad, (V[]){v_t_245, heff_get(v_acc_243, LBL_bad)});
    return heff_clo(g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam0, 2, 1, (V[]){v_x_246});
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x5_244, 0);
    V v_rest_2410 = heff_field(v_x5_244, 1);
    heff_take_n(v_x5_244, 3ULL, 2);
    V v_path_2411 = (g_heff_2ecommands_2eappFile(v_st_240, heff_dup(v_t_241), heff_dup(v_x_249), ((V)&g_heff_2ecommands_2eappsIn_24s1939917301x724821635_str0)));
    V v_c_2419 = heff_clo(g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam1, 2, 1, (V[]){v_path_2411});
    return heff_clo(g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam3, 2, 7, (V[]){v_c_2419, heff_dup(v_st_240), v_t_241, v_acc_243, v_x_249, v_rd_242, v_rest_2410});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eappsIn_24s1939917301x724821635(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_x_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_path_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam2_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2417}));
  V f_ = heff_get(v_hd_2412, LBL_bind);
  args[0] = v_t_2418;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_rd_242 = heff_env(self)[2];
  V v_x_2424 = heff_env(self)[3];
  V v_rest_2410 = heff_env(self)[4];
  V v_hd_2420 = heff_env(self)[5];
  V v_k_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2427);
  V v_t_2428 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_rd_242; V a_3 = v_x_2424; V a_4 = v_rest_2410; V r_ = (g_heff_2ecommands_2eappsIn_24s1939917301x724821635(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_240); r_; });
  return heff_tail(v_t_2428, 2, (V[]){v_hd_2420, v_k_2421});
}
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_rd_242 = heff_env(self)[0];
  V v_hd_2420 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_rest_2410 = heff_env(self)[4];
  V v_k_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2425 = heff_tag(TAG_Complete, 2, (V[]){heff_dup(v_rd_242), NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2420), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})}));
  return heff_tail(heff_get(heff_dup(v_hd_2420), LBL_bind), 2, (V[]){v_t_2426, heff_clo(g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam6, 1, 7, (V[]){v_st_240, v_t_241, v_rd_242, v_x_2424, v_rest_2410, v_hd_2420, v_k_2421})});
}
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_hd_2420 = heff_env(self)[4];
  V v_rd_242 = heff_env(self)[5];
  V v_rest_2410 = heff_env(self)[6];
  V v_k_2421 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2423 = (g_heff_2ecommands_2eappRead_24s850601752x1675975415(v_st_240, heff_dup(v_t_241), v_acc_243, v_x_249, v_x_2422));
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_hd_2420), heff_clo(g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam5, 1, 6, (V[]){v_rd_242, v_hd_2420, v_st_240, v_t_241, v_rest_2410, v_k_2421})});
}
V g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_x_249 = heff_env(self)[4];
  V v_rd_242 = heff_env(self)[5];
  V v_rest_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo(g_heff_2ecommands_2eappsIn_24s1939917301x724821635_lam4, 1, 8, (V[]){v_st_240, v_t_241, v_acc_243, v_x_249, v_hd_2420, v_rd_242, v_rest_2410, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {122, 105, 103, 32, 99, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {45, 108, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {99, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {122, 105, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str10 = {{0x80000000u, K_STR, 0}, 37, 37, {104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 58, 32, 96, 122, 105, 103, 32, 99, 99, 96, 32, 99, 111, 117, 108, 100, 32, 110, 111, 116, 32, 98, 117, 105, 108, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam1(V self, V *args); static Clo g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam1, 1, 0};
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam0(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam4(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam5(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam8(V self, V *args); static Clo g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam8, 1, 0};
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam7(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam11(V self, V *args); static Clo g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam11, 1, 0};
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam10(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam14(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam16(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam17(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam15(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam13(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam12(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam9(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam6(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam3(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam2(V self, V *args);
Clo g_heff_2ecommands_2ezigCc_24s1182148294x862333141_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ezigCc_24s1182148294x862333141_entry, 5, 0};

V g_heff_2ecommands_2ezigCc_24s1182148294x862333141(V v_st_240, V v_t_241, V v_p_242, V v_x_243, V v_next_244) {
top: ;
  V v_path_245 = (g_heff_2ecommands_2epartsDir(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243)));
  V v_c_2413 = heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam0, 2, 1, (V[]){v_path_245});
  return heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam2, 2, 6, (V[]){v_c_2413, heff_dup(v_st_240), v_t_241, v_x_243, v_p_242, v_next_244});
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ezigCc_24s1182148294x862333141(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam1(V self, V *args) {
  V v_ns_248 = args[0];
  return v_ns_248;
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k2_247 = args[1];
  V v_path_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){v_path_245, ((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam1_clo)})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2411}));
  V f_ = heff_get(v_hd_246, LBL_bind);
  args[0] = v_t_2412;
  args[1] = v_k2_247;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam4(V self, V *args) {
  V v_n_2420 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2421 = (g_heff_2ecommands_2epartsDir(v_st_240, v_t_241, v_x_243));
  V v_t_2422 = (g_std_2epath_2eparse(v_st_240, v_a_2421));
  V v_t_2423 = (g_std_2epath_2eparse(v_st_240, v_n_2420));
  V v_p_2424 = (g_std_2epath_2ejoin_2eonto_240(v_t_2422, v_t_2423));
  V v_t_2425 = ({ V a_0 = heff_get(heff_dup(v_p_2424), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2424), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2426 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2424), LBL_drive), heff_get(v_p_2424, LBL_absolute), v_t_2425});
  return ({ V a_0 = v_st_240; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam5(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_x_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam8(V self, V *args) {
  V v_t_2436 = args[0];
  return v_t_2436;
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam7(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k2_2435 = args[1];
  V v_p_242 = heff_env(self)[0];
  V v_total_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){v_p_242, ((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str2), v_total_2433, ((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam8_clo)})});
  V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2434), LBL_malg), 1, (V[]){v_t_2437}));
  V f_ = heff_get(v_hd_2434, LBL_bind);
  args[0] = v_t_2438;
  args[1] = v_k2_2435;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam11(V self, V *args) {
  V v_r_2455 = args[0];
  return v_r_2455;
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam10(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k2_2454 = args[1];
  V v_x_2440 = heff_env(self)[0];
  V v_as_2452 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2456 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_RunUnder, 4, (V[]){v_x_2440, ((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str7), v_as_2452, ((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam11_clo)})});
  V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2453), LBL_malg), 1, (V[]){v_t_2456}));
  V f_ = heff_get(v_hd_2453, LBL_bind);
  args[0] = v_t_2457;
  args[1] = v_k2_2454;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam14(V self, V *args) {
  V v_x_2476 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2476);
  return heff_tail(v_next_244, 2, (V[]){v_hd_2414, v_k_2415});
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam16(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k2_2490 = args[1];
  V v_str_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2491 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2488, ((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str11)), NTAG(TAG_MkUnit)});
  V v_t_2492 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2489), LBL_malg), 1, (V[]){v_t_2494}));
  V f_ = heff_get(v_hd_2489, LBL_bind);
  args[0] = v_t_2495;
  args[1] = v_k2_2490;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam17(V self, V *args) {
  V v_x_2497 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2497);
  V v_t_2498 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2499 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_24101}));
  return heff_tail(heff_get(v_hd_2414, LBL_bind), 2, (V[]){v_t_24102, v_k_2415});
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam15(V self, V *args) {
  V v_x_2482 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_hd_2414 = heff_env(self)[3];
  V v_k_2415 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2482);
  V v_t_2483 = (g_std_2epath_2eparse(v_st_240, heff_get(v_t_241, LBL_bin)));
  V v_t_2484 = (g_std_2epath_2eparse(v_st_240, v_x_243));
  V v_p_2485 = (g_std_2epath_2ejoin_2eonto_240(v_t_2483, v_t_2484));
  V v_t_2486 = ({ V a_0 = heff_get(heff_dup(v_p_2485), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2485), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2487 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2485), LBL_drive), heff_get(v_p_2485, LBL_absolute), v_t_2486});
  V v_str_2488 = heff_strAppend(((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str10), ({ V a_0 = v_st_240; V a_1 = v_t_2487; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; }));
  V v_c_2496 = heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam16, 2, 1, (V[]){v_str_2488});
  return heff_tail(v_c_2496, 2, (V[]){heff_dup(v_hd_2414), heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam17, 1, 2, (V[]){v_hd_2414, v_k_2415})});
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam13(V self, V *args) {
  V v_x_2462 = args[0];
  V v_x_2459 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_hd_2414 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2462);
  V v_t_2463 = heff_intEq(heff_get(heff_dup(v_x_2459), LBL_status), MK_INT(0LL));
  switch (heff_tag_of(v_t_2463)) {
  case TAG_True: {
    heff_drop(v_x_2459);
    V v_t_2464 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_bin)));
    V v_t_2465 = (g_std_2epath_2eparse(v_st_240, v_x_243));
    V v_p_2466 = (g_std_2epath_2ejoin_2eonto_240(v_t_2464, v_t_2465));
    V v_t_2467 = ({ V a_0 = heff_get(heff_dup(v_p_2466), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2466), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2468 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2466), LBL_drive), heff_get(v_p_2466, LBL_absolute), v_t_2467});
    V v_path_2469 = ({ V a_0 = v_st_240; V a_1 = v_t_2468; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
    V v_t_2470 = heff_strAppend(heff_get(v_t_241, LBL_said), heff_strAppend(((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str8), v_path_2469));
    V v_t_2471 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2470, ((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str9)), NTAG(TAG_MkUnit)});
    V v_t_2472 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2474}));
    return heff_tail(heff_get(heff_dup(v_hd_2414), LBL_bind), 2, (V[]){v_t_2475, heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam14, 1, 3, (V[]){v_next_244, v_hd_2414, v_k_2415})});
  }
  case TAG_False: {
    heff_drop(v_next_244);
    V v_t_2477 = heff_tag(TAG_WriteErr, 2, (V[]){heff_get(v_x_2459, LBL_err), NTAG(TAG_MkUnit)});
    V v_t_2478 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2480}));
    return heff_tail(heff_get(heff_dup(v_hd_2414), LBL_bind), 2, (V[]){v_t_2481, heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam15, 1, 5, (V[]){v_st_240, v_t_241, v_x_243, v_hd_2414, v_k_2415})});
  }
  default: return heff_nomatch(v_t_2463);
  }
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam12(V self, V *args) {
  V v_x_2459 = args[0];
  V v_x_2440 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2460 = heff_tag(TAG_End, 2, (V[]){v_x_2440, NTAG(TAG_MkUnit)});
  V v_t_2461 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2460})}));
  return heff_tail(heff_get(heff_dup(v_hd_2414), LBL_bind), 2, (V[]){v_t_2461, heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam13, 1, 7, (V[]){v_x_2459, v_st_240, v_t_241, v_x_243, v_hd_2414, v_next_244, v_k_2415})});
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam9(V self, V *args) {
  V v_x_2440 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2431 = heff_env(self)[3];
  V v_hd_2414 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2441 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str3), NTAG(TAG_Nil)});
  V v_t_2442 = heff_tag(TAG_Cons, 2, (V[]){heff_get(heff_dup(v_t_241), LBL_opt), v_t_2441});
  V v_t_2443 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_bin)));
  V v_t_2444 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_243)));
  V v_p_2445 = (g_std_2epath_2ejoin_2eonto_240(v_t_2443, v_t_2444));
  V v_t_2446 = ({ V a_0 = heff_get(heff_dup(v_p_2445), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2445), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2447 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2445), LBL_drive), heff_get(v_p_2445, LBL_absolute), v_t_2446});
  V v_t_2448 = (g_std_2epath_2erender(v_st_240, v_t_2447));
  V v_t_2449 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str4), NTAG(TAG_Nil)});
  V v_t_2450 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str5), heff_tag(TAG_Cons, 2, (V[]){v_t_2448, v_t_2449})});
  V v_t_2451 = (g_prelude_2econcatList(v_x_2431, v_t_2450));
  V v_as_2452 = (g_prelude_2econcatList(heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str6), v_t_2442}), v_t_2451));
  V v_c_2458 = heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam10, 2, 2, (V[]){heff_dup(v_x_2440), v_as_2452});
  return heff_tail(v_c_2458, 2, (V[]){heff_dup(v_hd_2414), heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam12, 1, 7, (V[]){v_x_2440, v_hd_2414, v_st_240, v_t_241, v_x_243, v_next_244, v_k_2415})});
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2432 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_x_2431));
  V v_total_2433 = heff_intAdd(v_t_2432, MK_INT(1LL));
  V v_c_2439 = heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam7, 2, 2, (V[]){v_p_242, v_total_2433});
  return heff_tail(v_c_2439, 2, (V[]){heff_dup(v_hd_2414), heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam9, 1, 7, (V[]){v_t_241, v_st_240, v_x_243, v_x_2431, v_hd_2414, v_next_244, v_k_2415})});
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_hd_2414 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2418;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2417 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    v_t_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V v_t_2419 = (g_prelude_2efilter_24s419026844x1025599777(((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str0), ((V)&g_heff_2ecommands_2ezigCc_24s1182148294x862333141_str1), v_t_2418));
  V v_x_2427 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam4, 1, 3, (V[]){heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_x_243)}), v_t_2419));
  V v_c_2430 = heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam5, 2, 1, (V[]){v_x_2427});
  return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_hd_2414), heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam6, 1, 7, (V[]){v_p_242, v_hd_2414, v_t_241, v_st_240, v_x_243, v_next_244, v_k_2415})});
}
V g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo(g_heff_2ecommands_2ezigCc_24s1182148294x862333141_lam3, 1, 7, (V[]){v_st_240, v_t_241, v_x_243, v_hd_2414, v_p_242, v_next_244, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2enodeDone_24s1556319424x570941549_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {43, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2enodeDone_24s1556319424x570941549_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 104, 109, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enodeDone_24s1556319424x570941549_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enodeDone_24s1556319424x570941549_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam1(V self, V *args); static Clo g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam1, 1, 0};
V g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam0(V self, V *args);
V g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam4(V self, V *args);
V g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam3(V self, V *args);
V g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam2(V self, V *args);
Clo g_heff_2ecommands_2enodeDone_24s1556319424x570941549_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enodeDone_24s1556319424x570941549_entry, 4, 0};

V g_heff_2ecommands_2enodeDone_24s1556319424x570941549(V v_st_240, V v_t_241, V v_x_242, V v_next_243) {
top: ;
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_bin)));
  V v_t_245 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_242)));
  V v_p_246 = (g_std_2epath_2ejoin_2eonto_240(v_t_244, v_t_245));
  V v_t_247 = ({ V a_0 = heff_get(heff_dup(v_p_246), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_246), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_248 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_246), LBL_drive), heff_get(v_p_246, LBL_absolute), v_t_247});
  V v_t_249 = (g_std_2epath_2erender(v_st_240, v_t_248));
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_as_2411 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2enodeDone_24s1556319424x570941549_str0), v_t_2410});
  V v_c_2419 = heff_clo(g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam0, 2, 1, (V[]){v_as_2411});
  return heff_clo(g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam2, 2, 5, (V[]){v_c_2419, heff_dup(v_st_240), v_t_241, v_x_242, v_next_243});
}
V g_heff_2ecommands_2enodeDone_24s1556319424x570941549_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2enodeDone_24s1556319424x570941549(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam1(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_as_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2enodeDone_24s1556319424x570941549_str1), v_as_2411, ((V)&g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam1_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2417})}));
  V f_ = heff_get(v_hd_2412, LBL_bind);
  args[0] = v_t_2418;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_hd_2420 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2435);
  return heff_tail(v_next_243, 2, (V[]){v_hd_2420, v_k_2421});
}
V g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_hd_2420 = heff_env(self)[3];
  V v_next_243 = heff_env(self)[4];
  V v_k_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2422);
  V v_t_2423 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_bin)));
  V v_t_2424 = (g_std_2epath_2eparse(v_st_240, v_x_242));
  V v_p_2425 = (g_std_2epath_2ejoin_2eonto_240(v_t_2423, v_t_2424));
  V v_t_2426 = ({ V a_0 = heff_get(heff_dup(v_p_2425), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2425), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2427 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2425), LBL_drive), heff_get(v_p_2425, LBL_absolute), v_t_2426});
  V v_path_2428 = ({ V a_0 = v_st_240; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  V v_t_2429 = heff_strAppend(heff_get(v_t_241, LBL_said), heff_strAppend(((V)&g_heff_2ecommands_2enodeDone_24s1556319424x570941549_str2), v_path_2428));
  V v_t_2430 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2429, ((V)&g_heff_2ecommands_2enodeDone_24s1556319424x570941549_str3)), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2420), LBL_malg), 1, (V[]){v_t_2433}));
  return heff_tail(heff_get(heff_dup(v_hd_2420), LBL_bind), 2, (V[]){v_t_2434, heff_clo(g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam4, 1, 3, (V[]){v_next_243, v_hd_2420, v_k_2421})});
}
V g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_next_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo(g_heff_2ecommands_2enodeDone_24s1556319424x570941549_lam3, 1, 6, (V[]){v_st_240, v_t_241, v_x_242, v_hd_2420, v_next_243, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str1 = {{0x80000000u, K_STR, 0}, 14, 14, {99, 111, 109, 112, 105, 108, 105, 110, 103, 32, 116, 111, 32, 67}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 97, 105, 110, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str5 = {{0x80000000u, K_STR, 0}, 21, 21, {99, 111, 109, 112, 105, 108, 105, 110, 103, 32, 102, 111, 114, 32, 78, 111, 100, 101, 46, 106, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str6 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 97, 105, 110, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str8 = {{0x80000000u, K_STR, 0}, 20, 20, {99, 111, 109, 112, 105, 108, 105, 110, 103, 32, 102, 111, 114, 32, 97, 32, 112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 106, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str10 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 97, 105, 110, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 106, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str14 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str15 = {{0x80000000u, K_STR, 0}, 12, 12, {112, 97, 115, 115, 101, 100, 32, 111, 118, 101, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str16 = {{0x80000000u, K_STR, 0}, 32, 32, {58, 32, 97, 32, 112, 97, 103, 101, 39, 115, 32, 115, 99, 114, 105, 112, 116, 44, 32, 110, 111, 116, 32, 97, 32, 112, 114, 111, 103, 114, 97, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam0(V self, V *args); static Clo g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam0, 1, 0};
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam2(V self, V *args); static Clo g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam2, 1, 0};
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam5(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam4(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam7(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam6(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam3(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam1(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam8(V self, V *args); static Clo g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam8, 1, 0};
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam10(V self, V *args); static Clo g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam10, 1, 0};
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam13(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam12(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam15(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam14(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam11(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam9(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam16(V self, V *args); static Clo g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam16, 1, 0};
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam18(V self, V *args); static Clo g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam18, 1, 0};
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam22(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam21(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam20(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam24(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam23(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam19(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam17(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam26(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam25(V self, V *args);
Clo g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_entry, 8, 0};

V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526(V v_st_240, V v_t_241, V v_bp_242, V v_x_243, V v_a_244, V v_next_245, V v_p_246, V v_p_247) {
top: ;
  V v_t_248 = heff_strEq(heff_get(heff_dup(v_a_244), LBL_backend), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str0));
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(2LL), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam0_clo)})});
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2410}));
    return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam1, 1, 7, (V[]){v_p_246, v_a_244, heff_dup(v_st_240), v_t_241, v_x_243, v_next_245, v_p_247})});
  }
  case TAG_False: {
    V v_t_2432 = heff_strEq(heff_get(heff_dup(v_a_244), LBL_backend), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str4));
    switch (heff_tag_of(v_t_2432)) {
    case TAG_True: {
      V v_t_2434 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(1LL), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam8_clo)})});
      V v_t_2435 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2434}));
      return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2435, heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam9, 1, 7, (V[]){v_p_246, v_a_244, heff_dup(v_st_240), v_t_241, v_x_243, v_next_245, v_p_247})});
    }
    case TAG_False: {
      V v_t_2461 = heff_get(heff_dup(v_t_241), LBL_pages);
      switch (heff_tag_of(v_t_2461)) {
      case TAG_True: {
        V v_t_2463 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(1LL), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam16_clo)})});
        V v_t_2464 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2463}));
        return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2464, heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam17, 1, 7, (V[]){v_p_246, v_a_244, heff_dup(v_st_240), v_t_241, v_x_243, v_next_245, v_p_247})});
      }
      case TAG_False: {
        heff_drop(v_t_241);
        heff_drop(v_a_244);
        V v_t_24103 = heff_strAppend(((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str15), heff_strAppend(v_x_243, ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str16)));
        V v_t_24104 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_24103, ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str17)), NTAG(TAG_MkUnit)});
        V v_t_24105 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24104})});
        V v_t_24106 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24105})});
        V v_t_24107 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24106})});
        V v_t_24108 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_24107}));
        return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_24108, heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam25, 1, 4, (V[]){v_bp_242, v_p_246, v_next_245, v_p_247})});
      }
      default: return heff_nomatch(v_t_2461);
      }
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ebuildApp_24s1767461951x119932526(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam0(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_2420 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2424);
  return heff_tail(v_next_245, 2, (V[]){v_hd_2420, v_k_2421});
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam4(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_x_2412 = heff_env(self)[0];
  V v_next_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tag(TAG_End, 2, (V[]){v_x_2412, NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2420), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})}));
  V f_ = heff_get(heff_dup(v_hd_2420), LBL_bind);
  args[0] = v_t_2423;
  args[1] = heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam5, 1, 3, (V[]){v_next_245, v_hd_2420, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_next_2425 = heff_env(self)[0];
  V v_hd_2426 = heff_env(self)[1];
  V v_k_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2430);
  return heff_tail(v_next_2425, 2, (V[]){v_hd_2426, v_k_2427});
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_x_2416 = heff_env(self)[0];
  V v_next_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = heff_tag(TAG_End, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2426), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})}));
  V f_ = heff_get(heff_dup(v_hd_2426), LBL_bind);
  args[0] = v_t_2429;
  args[1] = heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam7, 1, 3, (V[]){v_next_2425, v_hd_2426, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_246 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2417 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_a_244, LBL_run)});
  V v_t_2418 = (g_heff_2ecommands_2epartsDir(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243)));
  V v_t_2419 = (g_heff_2ecommands_2eappFile(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str2)));
  V v_next_2425 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = heff_dup(v_x_2412); V a_3 = v_x_243; V a_4 = heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam4, 2, 2, (V[]){v_x_2412, v_next_245}); V r_ = (g_heff_2ecommands_2ezigCc_24s1182148294x862333141(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_240); r_; });
  V v_t_2431 = (g_heff_2ecommands_2ecThen_24s903897371x1471440451(v_t_2417, heff_strAppend(v_t_2418, ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str3)), v_t_2419, heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam6, 2, 2, (V[]){v_x_2416, v_next_2425})));
  return heff_tail(v_t_2431, 2, (V[]){v_p_246, v_p_247});
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(v_x_2412), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str1), MK_INT(0LL), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam2_clo)})});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2415, heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam3, 1, 8, (V[]){v_a_244, v_st_240, v_t_241, v_x_243, v_x_2412, v_next_245, v_p_246, v_p_247})});
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam8(V self, V *args) {
  V v_t_2433 = args[0];
  return v_t_2433;
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam10(V self, V *args) {
  V v_t_2437 = args[0];
  return v_t_2437;
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam13(V self, V *args) {
  V v_x_2453 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_2449 = heff_env(self)[1];
  V v_k_2450 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2453);
  return heff_tail(v_next_245, 2, (V[]){v_hd_2449, v_k_2450});
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam12(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  V v_x_2436 = heff_env(self)[0];
  V v_next_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_tag(TAG_End, 2, (V[]){v_x_2436, NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2449), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2451})}));
  V f_ = heff_get(heff_dup(v_hd_2449), LBL_bind);
  args[0] = v_t_2452;
  args[1] = heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam13, 1, 3, (V[]){v_next_245, v_hd_2449, v_k_2450});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam15(V self, V *args) {
  V v_x_2459 = args[0];
  V v_next_2454 = heff_env(self)[0];
  V v_hd_2455 = heff_env(self)[1];
  V v_k_2456 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2459);
  return heff_tail(v_next_2454, 2, (V[]){v_hd_2455, v_k_2456});
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam14(V self, V *args) {
  V v_hd_2455 = args[0];
  V v_k_2456 = args[1];
  V v_x_2440 = heff_env(self)[0];
  V v_next_2454 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2457 = heff_tag(TAG_End, 2, (V[]){v_x_2440, NTAG(TAG_MkUnit)});
  V v_t_2458 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2455), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2457})}));
  V f_ = heff_get(heff_dup(v_hd_2455), LBL_bind);
  args[0] = v_t_2458;
  args[1] = heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam15, 1, 3, (V[]){v_next_2454, v_hd_2455, v_k_2456});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam11(V self, V *args) {
  V v_x_2440 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_246 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2441 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_a_244, LBL_run)});
  V v_t_2442 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_bin)));
  V v_t_2443 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_243)));
  V v_p_2444 = (g_std_2epath_2ejoin_2eonto_240(v_t_2442, v_t_2443));
  V v_t_2445 = ({ V a_0 = heff_get(heff_dup(v_p_2444), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2444), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2446 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2444), LBL_drive), heff_get(v_p_2444, LBL_absolute), v_t_2445});
  V v_t_2447 = (g_std_2epath_2erender(v_st_240, v_t_2446));
  V v_t_2448 = (g_heff_2ecommands_2eappFile(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str6)));
  V v_next_2454 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_243; V a_3 = heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam12, 2, 2, (V[]){v_x_2436, v_next_245}); V r_ = (g_heff_2ecommands_2enodeDone_24s1556319424x570941549(a_0, a_1, a_2, a_3)); heff_drop(v_st_240); r_; });
  V v_t_2460 = (g_heff_2ecommands_2ecompileThen_24s156302470x1672466221(((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str7), v_t_2441, v_t_2447, v_t_2448, heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam14, 2, 2, (V[]){v_x_2440, v_next_2454})));
  return heff_tail(v_t_2460, 2, (V[]){v_p_246, v_p_247});
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam9(V self, V *args) {
  V v_x_2436 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2438 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(v_x_2436), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str5), MK_INT(0LL), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam10_clo)})});
  V v_t_2439 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2438}));
  return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2439, heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam11, 1, 8, (V[]){v_a_244, v_st_240, v_t_241, v_x_243, v_x_2436, v_next_245, v_p_246, v_p_247})});
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam16(V self, V *args) {
  V v_t_2462 = args[0];
  return v_t_2462;
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam18(V self, V *args) {
  V v_t_2466 = args[0];
  return v_t_2466;
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam22(V self, V *args) {
  V v_x_2495 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_2484 = heff_env(self)[1];
  V v_k_2485 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2495);
  return heff_tail(v_next_245, 2, (V[]){v_hd_2484, v_k_2485});
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam21(V self, V *args) {
  V v_x_2492 = args[0];
  V v_x_2465 = heff_env(self)[0];
  V v_hd_2484 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  V v_k_2485 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2492);
  V v_t_2493 = heff_tag(TAG_End, 2, (V[]){v_x_2465, NTAG(TAG_MkUnit)});
  V v_t_2494 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2484), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2493})}));
  return heff_tail(heff_get(heff_dup(v_hd_2484), LBL_bind), 2, (V[]){v_t_2494, heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam22, 1, 3, (V[]){v_next_245, v_hd_2484, v_k_2485})});
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam20(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  V v_t_241 = heff_env(self)[0];
  V v_path_2483 = heff_env(self)[1];
  V v_x_2465 = heff_env(self)[2];
  V v_next_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2486 = heff_strAppend(heff_get(v_t_241, LBL_said), heff_strAppend(((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str12), v_path_2483));
  V v_t_2487 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2486, ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str13)), NTAG(TAG_MkUnit)});
  V v_t_2488 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2484), LBL_malg), 1, (V[]){v_t_2490}));
  V f_ = heff_get(heff_dup(v_hd_2484), LBL_bind);
  args[0] = v_t_2491;
  args[1] = heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam21, 1, 4, (V[]){v_x_2465, v_hd_2484, v_next_245, v_k_2485});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam24(V self, V *args) {
  V v_x_24101 = args[0];
  V v_next_2496 = heff_env(self)[0];
  V v_hd_2497 = heff_env(self)[1];
  V v_k_2498 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24101);
  return heff_tail(v_next_2496, 2, (V[]){v_hd_2497, v_k_2498});
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam23(V self, V *args) {
  V v_hd_2497 = args[0];
  V v_k_2498 = args[1];
  V v_x_2469 = heff_env(self)[0];
  V v_next_2496 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2499 = heff_tag(TAG_End, 2, (V[]){v_x_2469, NTAG(TAG_MkUnit)});
  V v_t_24100 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2497), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2499})}));
  V f_ = heff_get(heff_dup(v_hd_2497), LBL_bind);
  args[0] = v_t_24100;
  args[1] = heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam24, 1, 3, (V[]){v_next_2496, v_hd_2497, v_k_2498});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam19(V self, V *args) {
  V v_x_2469 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2465 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_246 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2470 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_a_244, LBL_run)});
  V v_t_2471 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_bin)));
  V v_t_2472 = (g_std_2epath_2eparse(v_st_240, heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str9))));
  V v_p_2473 = (g_std_2epath_2ejoin_2eonto_240(v_t_2471, v_t_2472));
  V v_t_2474 = ({ V a_0 = heff_get(heff_dup(v_p_2473), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2473), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2475 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2473), LBL_drive), heff_get(v_p_2473, LBL_absolute), v_t_2474});
  V v_t_2476 = (g_std_2epath_2erender(v_st_240, v_t_2475));
  V v_t_2477 = (g_heff_2ecommands_2eappFile(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str10)));
  V v_t_2478 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_bin)));
  V v_t_2479 = (g_std_2epath_2eparse(v_st_240, heff_strAppend(v_x_243, ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str11))));
  V v_p_2480 = (g_std_2epath_2ejoin_2eonto_240(v_t_2478, v_t_2479));
  V v_t_2481 = ({ V a_0 = heff_get(heff_dup(v_p_2480), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2480), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2482 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2480), LBL_drive), heff_get(v_p_2480, LBL_absolute), v_t_2481});
  V v_path_2483 = ({ V a_0 = v_st_240; V a_1 = v_t_2482; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  V v_next_2496 = heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam20, 2, 4, (V[]){v_t_241, v_path_2483, v_x_2465, v_next_245});
  V v_t_24102 = (g_heff_2ecommands_2ecompileThen_24s156302470x1672466221(((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str14), v_t_2470, v_t_2476, v_t_2477, heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam23, 2, 2, (V[]){v_x_2469, v_next_2496})));
  return heff_tail(v_t_24102, 2, (V[]){v_p_246, v_p_247});
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam17(V self, V *args) {
  V v_x_2465 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2467 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(v_x_2465), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_str8), MK_INT(0LL), ((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam18_clo)})});
  V v_t_2468 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2467}));
  return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2468, heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam19, 1, 8, (V[]){v_a_244, v_st_240, v_t_241, v_x_243, v_x_2465, v_next_245, v_p_246, v_p_247})});
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam26(V self, V *args) {
  V v_x_24112 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24112);
  return heff_tail(v_next_245, 2, (V[]){v_p_246, v_p_247});
}
V g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam25(V self, V *args) {
  V v_x_24109 = args[0];
  V v_bp_242 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_24109);
  V v_t_24110 = heff_tag(TAG_Complete, 2, (V[]){v_bp_242, NTAG(TAG_MkUnit)});
  V v_t_24111 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24110})}));
  return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_24111, heff_clo(g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_lam26, 1, 3, (V[]){v_next_245, v_p_246, v_p_247})});
}
Clo g_heff_2ecommands_2ebuildEach_24s385407377x1706379496_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildEach_24s385407377x1706379496_entry, 5, 0};

V g_heff_2ecommands_2ebuildEach_24s385407377x1706379496(V v_st_240, V v_t_241, V v_bp_242, V v_done_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_bp_242);
    return v_done_243;
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(g_heff_2ecommands_2ebuildEach_24s385407377x1706379496(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_bp_242), v_done_243, v_rest_246));
    return heff_tail(((V)&g_heff_2ecommands_2ebuildApp_24s1767461951x119932526_clo), 6, (V[]){v_st_240, v_t_241, v_bp_242, heff_get(heff_dup(v_a_245), LBL_name), heff_get(heff_dup(v_a_245), LBL_build), v_t_247});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecommands_2ebuildEach_24s385407377x1706379496_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ebuildEach_24s385407377x1706379496(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[4]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2eshipFails_24s1573494380x931648657_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eshipFails_24s1573494380x931648657_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eshipFails_24s1573494380x931648657_lam0(V self, V *args);
Clo g_heff_2ecommands_2eshipFails_24s1573494380x931648657_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipFails_24s1573494380x931648657_entry, 3, 0};

V g_heff_2ecommands_2eshipFails_24s1573494380x931648657(V v_why_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2eshipFails_24s1573494380x931648657_str0), v_why_240), ((V)&g_heff_2ecommands_2eshipFails_24s1573494380x931648657_str1));
  V v_t_244 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_243, NTAG(TAG_MkUnit)});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2eshipFails_24s1573494380x931648657_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2eshipFails_24s1573494380x931648657_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eshipFails_24s1573494380x931648657(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eshipFails_24s1573494380x931648657_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_249);
  V v_t_2410 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2414, v_k_242});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {99, 97, 110, 110, 111, 116, 32, 112, 117, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_str3 = {{0x80000000u, K_STR, 0}, 13, 13, {32, 105, 110, 32, 112, 108, 97, 99, 101, 32, 111, 102, 32}};
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam0(V self, V *args); static Clo g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam0, 1, 0};
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam2(V self, V *args);
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam1(V self, V *args);
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam3(V self, V *args); static Clo g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam3, 1, 0};
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam5(V self, V *args); static Clo g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam5, 1, 0};
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam6(V self, V *args);
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam4(V self, V *args);
Clo g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_entry, 8, 0};

V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548(V v_t_240, V v_fresh_241, V v_old_242, V v_to_243, V v_next_244, V v_x6_245, V v_p_246, V v_p_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_True: {
    heff_drop(v_fresh_241);
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){v_old_242, ((V)&g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam0_clo)})});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2411}));
    return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam1, 1, 5, (V[]){v_t_240, v_to_243, v_p_246, v_next_244, v_p_247})});
  }
  case TAG_False: {
    heff_drop(v_t_240);
    heff_drop(v_next_244);
    V v_t_2422 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Move, 3, (V[]){v_old_242, heff_dup(v_to_243), ((V)&g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam3_clo)})});
    V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2424}));
    return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2425, heff_clo(g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam4, 1, 4, (V[]){v_fresh_241, v_p_246, v_to_243, v_p_247})});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eshipMoved_24s819912483x1275605548(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[5]); return r;
}
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam0(V self, V *args) {
  V v_ok_248 = args[0];
  return v_ok_248;
}
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2420);
  return heff_tail(v_next_244, 2, (V[]){v_p_246, v_p_247});
}
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_next_244 = heff_env(self)[3];
  V v_p_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2413);
  V v_t_2414 = heff_strAppend(heff_get(v_t_240, LBL_said), heff_strAppend(((V)&g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_str0), v_to_243));
  V v_t_2415 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2414, ((V)&g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_str1)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2419, heff_clo(g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam2, 1, 3, (V[]){v_next_244, v_p_246, v_p_247})});
}
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam3(V self, V *args) {
  V v_ok_2421 = args[0];
  return v_ok_2421;
}
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam5(V self, V *args) {
  V v_ok_2427 = args[0];
  return v_ok_2427;
}
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2432);
  V v_t_2433 = heff_strAppend(((V)&g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_str2), heff_strAppend(v_fresh_241, heff_strAppend(((V)&g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_str3), v_to_243)));
  return (g_heff_2ecommands_2eshipFails_24s1573494380x931648657(v_t_2433, v_p_246, v_p_247));
}
V g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_to_243 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2426);
  V v_t_2428 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){heff_dup(v_fresh_241), ((V)&g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam5_clo)})});
  V v_t_2429 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2430}));
  return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2431, heff_clo(g_heff_2ecommands_2eshipMoved_24s819912483x1275605548_lam6, 1, 4, (V[]){v_fresh_241, v_to_243, v_p_246, v_p_247})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eshipOne_24s392735153x883961245_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eshipOne_24s392735153x883961245_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 110, 101, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eshipOne_24s392735153x883961245_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eshipOne_24s392735153x883961245_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 111, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2eshipOne_24s392735153x883961245_str4 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 97, 110, 110, 111, 116, 32, 99, 111, 112, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eshipOne_24s392735153x883961245_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 116, 111, 32}};
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam0(V self, V *args); static Clo g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam0, 1, 0};
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam2(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam4(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam6(V self, V *args); static Clo g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam6, 1, 0};
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam8(V self, V *args); static Clo g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam8, 1, 0};
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam11(V self, V *args); static Clo g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam11, 1, 0};
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam10(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam14(V self, V *args); static Clo g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam14, 1, 0};
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam13(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam17(V self, V *args); static Clo g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam17, 1, 0};
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam16(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam20(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam19(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam18(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam15(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam21(V self, V *args); static Clo g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam21, 1, 0};
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam22(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam12(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam9(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam7(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam5(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam3(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam1(V self, V *args);
Clo g_heff_2ecommands_2eshipOne_24s392735153x883961245_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s392735153x883961245_entry, 8, 0};

V g_heff_2ecommands_2eshipOne_24s392735153x883961245(V v_st_240, V v_t_241, V v_home_242, V v_sh_243, V v_next_244, V v_n_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){v_sh_243, heff_dup(v_n_245), MK_INT(0LL), ((V)&g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam0_clo)})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_249}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam1, 1, 7, (V[]){heff_dup(v_st_240), v_home_242, v_n_245, v_hd_246, v_t_241, v_next_244, v_k_247})});
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eshipOne_24s392735153x883961245(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_x_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam4(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_x_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = v_x_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam6(V self, V *args) {
  V v_ok_2434 = args[0];
  return v_ok_2434;
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam8(V self, V *args) {
  V v_ok_2440 = args[0];
  return v_ok_2440;
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam11(V self, V *args) {
  V v_ok_2454 = args[0];
  return v_ok_2454;
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam10(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k2_2453 = args[1];
  V v_path_2451 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2455 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Copy, 3, (V[]){v_path_2451, v_x_2422, ((V)&g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam11_clo)})});
  V v_t_2456 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2452), LBL_malg), 1, (V[]){v_t_2457}));
  V f_ = heff_get(v_hd_2452, LBL_bind);
  args[0] = v_t_2458;
  args[1] = v_k2_2453;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam14(V self, V *args) {
  V v_ok_2469 = args[0];
  return v_ok_2469;
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam13(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k2_2468 = args[1];
  V v_path_2466 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2470 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Move, 3, (V[]){v_path_2466, v_x_2433, ((V)&g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam14_clo)})});
  V v_t_2471 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2467), LBL_malg), 1, (V[]){v_t_2472}));
  V f_ = heff_get(v_hd_2467, LBL_bind);
  args[0] = v_t_2473;
  args[1] = v_k2_2468;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam17(V self, V *args) {
  V v_ok_2484 = args[0];
  return v_ok_2484;
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam16(V self, V *args) {
  V v_hd_2482 = args[0];
  V v_k2_2483 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_to_2481 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2485 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Move, 3, (V[]){v_x_2422, v_to_2481, ((V)&g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam17_clo)})});
  V v_t_2486 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2482), LBL_malg), 1, (V[]){v_t_2487}));
  V f_ = heff_get(v_hd_2482, LBL_bind);
  args[0] = v_t_2488;
  args[1] = v_k2_2483;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam20(V self, V *args) {
  V v_x_24101 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_2497 = heff_env(self)[1];
  V v_k_2498 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24101);
  return heff_tail(v_next_244, 2, (V[]){v_hd_2497, v_k_2498});
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam19(V self, V *args) {
  V v_hd_2497 = args[0];
  V v_k_2498 = args[1];
  V v_x_2411 = heff_env(self)[0];
  V v_next_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2499 = heff_tag(TAG_End, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  V v_t_24100 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2497), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2499})}));
  V f_ = heff_get(heff_dup(v_hd_2497), LBL_bind);
  args[0] = v_t_24100;
  args[1] = heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam20, 1, 3, (V[]){v_next_244, v_hd_2497, v_k_2498});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam18(V self, V *args) {
  V v_x_2490 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_2422 = heff_env(self)[4];
  V v_x_2433 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  V v_next_244 = heff_env(self)[7];
  V v_hd_246 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2491 = (g_std_2epath_2eparse(v_st_240, v_home_242));
  V v_t_2492 = (g_std_2epath_2eparse(v_st_240, v_n_245));
  V v_p_2493 = (g_std_2epath_2ejoin_2eonto_240(v_t_2491, v_t_2492));
  V v_t_2494 = ({ V a_0 = heff_get(heff_dup(v_p_2493), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2493), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2495 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2493), LBL_drive), heff_get(v_p_2493, LBL_absolute), v_t_2494});
  V v_t_2496 = ({ V a_0 = v_st_240; V a_1 = v_t_2495; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  return ({ V a_0 = v_t_241; V a_1 = v_x_2422; V a_2 = v_x_2433; V a_3 = v_t_2496; V a_4 = heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam19, 2, 2, (V[]){v_x_2411, v_next_244}); V a_5 = v_x_2490; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2ecommands_2eshipMoved_24s819912483x1275605548(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2490); r_; });
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam15(V self, V *args) {
  V v_x_2475 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_t_241 = heff_env(self)[5];
  V v_x_2433 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2475);
  V v_t_2476 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
  V v_t_2477 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
  V v_p_2478 = (g_std_2epath_2ejoin_2eonto_240(v_t_2476, v_t_2477));
  V v_t_2479 = ({ V a_0 = heff_get(heff_dup(v_p_2478), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2478), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2480 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2478), LBL_drive), heff_get(v_p_2478, LBL_absolute), v_t_2479});
  V v_to_2481 = (g_std_2epath_2erender(v_st_240, v_t_2480));
  V v_c_2489 = heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam16, 2, 2, (V[]){heff_dup(v_x_2422), v_to_2481});
  return heff_tail(v_c_2489, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam18, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_t_241, v_x_2422, v_x_2433, v_x_2411, v_next_244, v_hd_246, v_k_247})});
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam21(V self, V *args) {
  V v_ok_24102 = args[0];
  return v_ok_24102;
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam22(V self, V *args) {
  V v_x_24107 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24107);
  V v_t_24108 = (g_std_2epath_2eparse(v_st_240, heff_get(v_t_241, LBL_root)));
  V v_t_24109 = (g_std_2epath_2eparse(v_st_240, v_n_245));
  V v_p_24110 = (g_std_2epath_2ejoin_2eonto_240(v_t_24108, v_t_24109));
  V v_t_24111 = ({ V a_0 = heff_get(heff_dup(v_p_24110), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_24110), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24112 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_24110), LBL_drive), heff_get(v_p_24110, LBL_absolute), v_t_24111});
  V v_t_24113 = ({ V a_0 = v_st_240; V a_1 = v_t_24112; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  V v_t_24114 = heff_strAppend(((V)&g_heff_2ecommands_2eshipOne_24s392735153x883961245_str4), heff_strAppend(v_t_24113, heff_strAppend(((V)&g_heff_2ecommands_2eshipOne_24s392735153x883961245_str5), v_x_2422)));
  return (g_heff_2ecommands_2eshipFails_24s1573494380x931648657(v_t_24114, v_hd_246, v_k_247));
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam12(V self, V *args) {
  V v_x_2460 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2433 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_x_2422 = heff_env(self)[5];
  V v_t_241 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2460)) {
  case TAG_True: {
    V v_t_2461 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
    V v_t_2462 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
    V v_p_2463 = (g_std_2epath_2ejoin_2eonto_240(v_t_2461, v_t_2462));
    V v_t_2464 = ({ V a_0 = heff_get(heff_dup(v_p_2463), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2463), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2465 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2463), LBL_drive), heff_get(v_p_2463, LBL_absolute), v_t_2464});
    V v_path_2466 = (g_std_2epath_2erender(v_st_240, v_t_2465));
    V v_c_2474 = heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam13, 2, 2, (V[]){v_path_2466, heff_dup(v_x_2433)});
    return heff_tail(v_c_2474, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam15, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_x_2422, v_hd_246, v_t_241, v_x_2433, v_x_2411, v_next_244, v_k_247})});
  }
  case TAG_False: {
    heff_drop(v_home_242);
    heff_drop(v_x_2433);
    heff_drop(v_x_2411);
    heff_drop(v_next_244);
    V v_t_24103 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){heff_dup(v_x_2422), ((V)&g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam21_clo)})});
    V v_t_24104 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24103})});
    V v_t_24105 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24104})});
    V v_t_24106 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24105}));
    return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_24106, heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam22, 1, 6, (V[]){v_st_240, v_t_241, v_n_245, v_x_2422, v_hd_246, v_k_247})});
  }
  default: return heff_nomatch(v_x_2460);
  }
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam9(V self, V *args) {
  V v_x_2445 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_home_242 = heff_env(self)[5];
  V v_x_2433 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2445);
  V v_t_2446 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_root)));
  V v_t_2447 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
  V v_p_2448 = (g_std_2epath_2ejoin_2eonto_240(v_t_2446, v_t_2447));
  V v_t_2449 = ({ V a_0 = heff_get(heff_dup(v_p_2448), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2448), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2450 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2448), LBL_drive), heff_get(v_p_2448, LBL_absolute), v_t_2449});
  V v_path_2451 = (g_std_2epath_2erender(v_st_240, v_t_2450));
  V v_c_2459 = heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam10, 2, 2, (V[]){v_path_2451, heff_dup(v_x_2422)});
  return heff_tail(v_c_2459, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam12, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_x_2433, v_hd_246, v_x_2422, v_t_241, v_x_2411, v_next_244, v_k_247})});
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_x_2422 = heff_env(self)[5];
  V v_home_242 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2439);
  V v_t_2441 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){heff_dup(v_x_2433), ((V)&g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam8_clo)})});
  V v_t_2442 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2443}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2444, heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam9, 1, 10, (V[]){v_st_240, v_t_241, v_n_245, v_x_2422, v_hd_246, v_home_242, v_x_2433, v_x_2411, v_next_244, v_k_247})});
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2422 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_home_242 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  V v_next_244 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){heff_dup(v_x_2422), ((V)&g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam6_clo)})});
  V v_t_2436 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2437}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2438, heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam7, 1, 10, (V[]){v_x_2433, v_hd_246, v_st_240, v_t_241, v_n_245, v_x_2422, v_home_242, v_x_2411, v_next_244, v_k_247})});
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2423 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
  V v_t_2424 = heff_strAppend(((V)&g_heff_2ecommands_2eshipOne_24s392735153x883961245_str2), heff_strAppend(heff_dup(v_n_245), ((V)&g_heff_2ecommands_2eshipOne_24s392735153x883961245_str3)));
  V v_t_2425 = (g_std_2epath_2eparse(v_st_240, v_t_2424));
  V v_p_2426 = (g_std_2epath_2ejoin_2eonto_240(v_t_2423, v_t_2425));
  V v_t_2427 = ({ V a_0 = heff_get(heff_dup(v_p_2426), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2426), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2428 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2426), LBL_drive), heff_get(v_p_2426, LBL_absolute), v_t_2427});
  V v_x_2429 = (g_std_2epath_2erender(v_st_240, v_t_2428));
  V v_c_2432 = heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam4, 2, 1, (V[]){v_x_2429});
  return heff_tail(v_c_2432, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam5, 1, 9, (V[]){v_x_2422, v_hd_246, v_st_240, v_t_241, v_n_245, v_home_242, v_x_2411, v_next_244, v_k_247})});
}
V g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecommands_2eshipOne_24s392735153x883961245_str0), heff_strAppend(heff_dup(v_n_245), ((V)&g_heff_2ecommands_2eshipOne_24s392735153x883961245_str1)));
  V v_t_2414 = (g_std_2epath_2eparse(v_st_240, v_t_2413));
  V v_p_2415 = (g_std_2epath_2ejoin_2eonto_240(v_t_2412, v_t_2414));
  V v_t_2416 = ({ V a_0 = heff_get(heff_dup(v_p_2415), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2415), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2417 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2415), LBL_drive), heff_get(v_p_2415, LBL_absolute), v_t_2416});
  V v_x_2418 = (g_std_2epath_2erender(v_st_240, v_t_2417));
  V v_c_2421 = heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam2, 2, 1, (V[]){v_x_2418});
  return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2ecommands_2eshipOne_24s392735153x883961245_lam3, 1, 8, (V[]){v_st_240, v_home_242, v_n_245, v_hd_246, v_t_241, v_x_2411, v_next_244, v_k_247})});
}
Clo g_heff_2ecommands_2eshipAll_24s1787275079x301132786_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipAll_24s1787275079x301132786_entry, 6, 0};

V g_heff_2ecommands_2eshipAll_24s1787275079x301132786(V v_st_240, V v_t_241, V v_home_242, V v_sh_243, V v_next_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_home_242);
    heff_drop(v_sh_243);
    return v_next_244;
  }
  case TAG_Cons: {
    V v_n_246 = heff_field(v_x6_245, 0);
    V v_rest_247 = heff_field(v_x6_245, 1);
    V v_t_248 = heff_tr(g_heff_2ecommands_2eshipAll_24s1787275079x301132786(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_home_242), heff_dup(v_sh_243), v_next_244, v_rest_247));
    return heff_tail(((V)&g_heff_2ecommands_2eshipOne_24s392735153x883961245_clo), 6, (V[]){v_st_240, v_t_241, v_home_242, v_sh_243, v_t_248, heff_dup(v_n_246)});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecommands_2eshipAll_24s1787275079x301132786_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eshipAll_24s1787275079x301132786(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[5]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2eshipIn_24s1932155328x737088526_str0 = {{0x80000000u, K_STR, 0}, 14, 14, {105, 110, 115, 116, 97, 108, 108, 105, 110, 103, 32, 105, 110, 32}};
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam0(V self, V *args); static Clo g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam0, 2, 0};
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam2(V self, V *args); static Clo g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam2, 1, 0};
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam1(V self, V *args);
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam6(V self, V *args);
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam5(V self, V *args);
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam4(V self, V *args);
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam3(V self, V *args);
Clo g_heff_2ecommands_2eshipIn_24s1932155328x737088526_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipIn_24s1932155328x737088526_entry, 4, 0};

V g_heff_2ecommands_2eshipIn_24s1932155328x737088526(V v_st_240, V v_t_241, V v_progs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nothing: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_progs_242);
    return ((V)&g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam0_clo);
  }
  case TAG_Just: {
    V v_home_246 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_247 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_dup(v_progs_242)));
    V v_xs_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_prelude_2efoldl_24s847320519x792667925(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_xs_249 = (g_heff_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_248));
    V v_total_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_249; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    V v_c_2416 = heff_clo(g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam1, 2, 2, (V[]){heff_dup(v_home_246), v_total_2410});
    return heff_clo(g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam3, 2, 5, (V[]){v_c_2416, v_progs_242, v_st_240, v_t_241, v_home_246});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eshipIn_24s1932155328x737088526(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_a_245 = args[1];
  heff_drop(v_a_244);
  V f_ = v_a_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k2_2412 = args[1];
  V v_home_246 = heff_env(self)[0];
  V v_total_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ecommands_2eshipIn_24s1932155328x737088526_str0), v_home_246), v_total_2410, ((V)&g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam2_clo)});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})}));
  V f_ = heff_get(v_hd_2411, LBL_bind);
  args[0] = v_t_2415;
  args[1] = v_k2_2412;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2427);
  V f_ = v_k_2424;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam5(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tag(TAG_End, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2423), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})}));
  V f_ = heff_get(v_hd_2423, LBL_bind);
  args[0] = v_t_2426;
  args[1] = heff_clo(g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam6, 1, 1, (V[]){v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_progs_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_home_246 = heff_env(self)[3];
  V v_hd_2417 = heff_env(self)[4];
  V v_k_2418 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_progs_242));
  V v_xs_2421 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2420; V r_ = (g_prelude_2efoldl_24s847320519x792667925(a_0, a_1)); heff_drop(v_t_2420); r_; });
  V v_t_2422 = (g_heff_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2421));
  V v_t_2428 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_home_246; V a_3 = heff_dup(v_x_2419); V a_4 = heff_clo(g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam5, 2, 1, (V[]){v_x_2419}); V a_5 = v_t_2422; V r_ = heff_tr(g_heff_2ecommands_2eshipAll_24s1787275079x301132786(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2422); r_; });
  return heff_tail(v_t_2428, 2, (V[]){v_hd_2417, v_k_2418});
}
V g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam3(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_progs_242 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_home_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo(g_heff_2ecommands_2eshipIn_24s1932155328x737088526_lam4, 1, 6, (V[]){v_progs_242, v_st_240, v_t_241, v_home_246, v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_str2 = {{0x80000000u, K_STR, 0}, 17, 17, {98, 117, 105, 108, 100, 105, 110, 103, 32, 112, 114, 111, 103, 114, 97, 109, 115}};
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam0(V self, V *args); static Clo g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam0, 1, 0};
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam3(V self, V *args); static Clo g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam3, 1, 0};
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam2(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam6(V self, V *args); static Clo g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam6, 1, 0};
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam5(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam9(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam8(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam7(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam4(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam1(V self, V *args);
Clo g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_entry, 5, 0};

V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035(V v_st_240, V v_t_241, V v_progs_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag(TAG_MkDir, 2, (V[]){heff_get(heff_dup(v_t_241), LBL_bin), ((V)&g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam0_clo)});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_248})}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam1, 1, 5, (V[]){v_st_240, v_t_241, v_hd_243, v_progs_242, v_k_244})});
}
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam0(V self, V *args) {
  V v_ok_245 = args[0];
  return v_ok_245;
}
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam3(V self, V *args) {
  V v_ok_2425 = args[0];
  return v_ok_2425;
}
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam2(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_path_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_2422, ((V)&g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam3_clo)})});
  V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2423), LBL_malg), 1, (V[]){v_t_2428}));
  V f_ = heff_get(v_hd_2423, LBL_bind);
  args[0] = v_t_2429;
  args[1] = v_k2_2424;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam6(V self, V *args) {
  V v_t_2435 = args[0];
  return v_t_2435;
}
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam5(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k2_2434 = args[1];
  V v_total_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_str2), v_total_2432, ((V)&g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam6_clo)})});
  V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2433), LBL_malg), 1, (V[]){v_t_2436}));
  V f_ = heff_get(v_hd_2433, LBL_bind);
  args[0] = v_t_2437;
  args[1] = v_k2_2434;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam9(V self, V *args) {
  V v_x_2445 = args[0];
  V v_next_2440 = heff_env(self)[0];
  V v_hd_2441 = heff_env(self)[1];
  V v_k_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2445);
  return heff_tail(v_next_2440, 2, (V[]){v_hd_2441, v_k_2442});
}
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam8(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_x_2439 = heff_env(self)[0];
  V v_next_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2443 = heff_tag(TAG_End, 2, (V[]){v_x_2439, NTAG(TAG_MkUnit)});
  V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2441), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2443})}));
  V f_ = heff_get(heff_dup(v_hd_2441), LBL_bind);
  args[0] = v_t_2444;
  args[1] = heff_clo(g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam9, 1, 3, (V[]){v_next_2440, v_hd_2441, v_k_2442});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_progs_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_next_2440 = (g_heff_2ecommands_2eshipIn_24s1932155328x737088526(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_progs_242), heff_get(heff_dup(v_t_241), LBL_shipTo)));
  V v_t_2446 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = heff_dup(v_x_2439); V a_3 = heff_clo(g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam8, 2, 2, (V[]){v_x_2439, v_next_2440}); V a_4 = v_progs_242; V r_ = heff_tr(g_heff_2ecommands_2ebuildEach_24s385407377x1706379496(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_progs_242); r_; });
  return heff_tail(v_t_2446, 2, (V[]){v_hd_243, v_k_244});
}
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_progs_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2431);
  V v_total_2432 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_progs_242));
  V v_c_2438 = heff_clo(g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam5, 2, 1, (V[]){v_total_2432});
  return heff_tail(v_c_2438, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam7, 1, 5, (V[]){v_st_240, v_t_241, v_progs_242, v_hd_243, v_k_244})});
}
V g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_progs_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_str0)));
  V v_t_2412 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_str1)));
  V v_p_2413 = (g_std_2epath_2ejoin_2eonto_240(v_t_2411, v_t_2412));
  V v_t_2414 = ({ V a_0 = heff_get(heff_dup(v_p_2413), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2413), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2415 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2413), LBL_drive), heff_get(v_p_2413, LBL_absolute), v_t_2414});
  V v_p_2416 = (g_std_2epath_2erender(v_st_240, v_t_2415));
  V v_t_2417 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_root)));
  V v_t_2418 = (g_std_2epath_2eparse(v_st_240, v_p_2416));
  V v_p_2419 = (g_std_2epath_2ejoin_2eonto_240(v_t_2417, v_t_2418));
  V v_t_2420 = ({ V a_0 = heff_get(heff_dup(v_p_2419), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2419), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2421 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2419), LBL_drive), heff_get(v_p_2419, LBL_absolute), v_t_2420});
  V v_path_2422 = (g_std_2epath_2erender(v_st_240, v_t_2421));
  V v_c_2430 = heff_clo(g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam2, 2, 1, (V[]){v_path_2422});
  return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035_lam4, 1, 5, (V[]){v_progs_242, v_hd_243, v_st_240, v_t_241, v_k_244})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {99, 104, 101, 99, 107, 105, 110, 103, 32, 109, 111, 100, 117, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {49, 32, 101, 114, 114, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 101, 114, 114, 111, 114, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str4 = {{0x80000000u, K_STR, 0}, 25, 25, {32, 105, 110, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 109, 111, 100, 117, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {49, 32, 109, 111, 100, 117, 108, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 109, 111, 100, 117, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {104, 101, 102, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str9 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 99, 104, 101, 99, 107, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str12 = {{0x80000000u, K_STR, 0}, 30, 30, {114, 101, 97, 100, 105, 110, 103, 32, 116, 104, 101, 32, 112, 114, 111, 103, 114, 97, 109, 115, 39, 32, 98, 117, 105, 108, 100, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str13 = {{0x80000000u, K_STR, 0}, 7, 7, {49, 32, 101, 114, 114, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str14 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 101, 114, 114, 111, 114, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str15 = {{0x80000000u, K_STR, 0}, 26, 26, {32, 105, 110, 32, 116, 104, 101, 32, 112, 114, 111, 103, 114, 97, 109, 115, 39, 32, 98, 117, 105, 108, 100, 46, 104, 102}};
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam3(V self, V *args); static Clo g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam3, 1, 0};
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam2(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam7(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam10(V self, V *args); static Clo g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam10, 1, 0};
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam9(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam13(V self, V *args); static Clo g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam13, 1, 0};
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam12(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam16(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam15(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam14(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam11(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam8(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam6(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam5(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam4(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam1(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam0(V self, V *args);
Clo g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_entry, 3, 0};

V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661(V v_st_240, V v_cmd_241, V v_t_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_242), LBL_root)));
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str0)));
  V v_p_245 = (g_std_2epath_2ejoin_2eonto_240(v_t_243, v_t_244));
  V v_t_246 = ({ V a_0 = heff_get(heff_dup(v_p_245), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_245), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_245), LBL_drive), heff_get(v_p_245, LBL_absolute), v_t_246});
  V v_t_248 = (g_std_2epath_2erender(v_st_240, v_t_247));
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_c_2410 = (g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798(v_t_249, NTAG(TAG_Nil)));
  return heff_clo(g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam0, 2, 4, (V[]){v_c_2410, v_cmd_241, v_st_240, v_t_242});
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam3(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_total_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str1), v_total_2414, ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam3_clo)})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2415), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2415, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2416;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam7(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k2_2437 = args[1];
  V v_str_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2435, ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str10)), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2436), LBL_malg), 1, (V[]){v_t_2441}));
  V f_ = heff_get(v_hd_2436, LBL_bind);
  args[0] = v_t_2442;
  args[1] = v_k2_2437;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam10(V self, V *args) {
  V v_ns_2453 = args[0];
  return v_ns_2453;
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam9(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k2_2452 = args[1];
  V v_path_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2454 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){v_path_2450, ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam10_clo)})});
  V v_t_2455 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2451), LBL_malg), 1, (V[]){v_t_2456}));
  V f_ = heff_get(v_hd_2451, LBL_bind);
  args[0] = v_t_2457;
  args[1] = v_k2_2452;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam13(V self, V *args) {
  V v_t_2465 = args[0];
  return v_t_2465;
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam12(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k2_2464 = args[1];
  V v_total_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str12), v_total_2462, ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam13_clo)})});
  V v_t_2467 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2463), LBL_malg), 1, (V[]){v_t_2466}));
  V f_ = heff_get(v_hd_2463, LBL_bind);
  args[0] = v_t_2467;
  args[1] = v_k2_2464;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam16(V self, V *args) {
  V v_x_2477 = args[0];
  V v_x_2474 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2477);
  V v_t_2478 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_x_2474), LBL_bad));
  switch (heff_tag_of(v_t_2478)) {
  case TAG_True: {
    heff_drop(v_st_240);
    heff_drop(v_t_242);
    V v_n_2479 = heff_get(v_x_2474, LBL_bad);
    V v_t_2480 = heff_intEq(heff_dup(v_n_2479), MK_INT(1LL));
    V v_t_2481;
    switch (heff_tag_of(v_t_2480)) {
    case TAG_True: {
      heff_drop(v_n_2479);
      v_t_2481 = ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str13);
      break;
    }
    case TAG_False: {
      v_t_2481 = heff_strAppend(heff_intShow(v_n_2479), ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str14));
      break;
    }
    default: heff_nomatch(v_t_2480);
    }
    return (g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297(v_cmd_241, heff_strAppend(v_t_2481, ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str15)), v_hd_2411, v_k_2412));
  }
  case TAG_False: {
    heff_drop(v_cmd_241);
    V v_t_2482 = heff_get(heff_dup(v_x_2474), LBL_apps);
    switch (heff_tag_of(v_t_2482)) {
    case TAG_Nil: {
      heff_drop(v_x_2474);
      heff_drop(v_hd_2411);
      heff_drop(v_st_240);
      heff_drop(v_t_242);
      V f_ = v_k_2412;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      heff_take_n(v_t_2482, 0ULL, 2);
      return (g_heff_2ecommands_2ebuildPrograms_24s802958621x1138554035(v_st_240, v_t_242, heff_get(v_x_2474, LBL_apps), v_hd_2411, v_k_2412));
    }
    default: return heff_nomatch(v_t_2482);
    }
  }
  default: return heff_nomatch(v_t_2478);
  }
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam15(V self, V *args) {
  V v_x_2474 = args[0];
  V v_x_2469 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2475 = heff_tag(TAG_End, 2, (V[]){v_x_2469, NTAG(TAG_MkUnit)});
  V v_t_2476 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2475})}));
  return heff_tail(heff_get(heff_dup(v_hd_2411), LBL_bind), 2, (V[]){v_t_2476, heff_clo(g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam16, 1, 6, (V[]){v_x_2474, v_cmd_241, v_hd_2411, v_k_2412, v_st_240, v_t_242})});
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam14(V self, V *args) {
  V v_x_2469 = args[0];
  V v_x_2459 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_cmd_241 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2470 = heff_rec(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2472;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_Nothing: {
    v_t_2472 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2471 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    v_t_2472 = v_x_2471;
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V v_c_2473 = (g_heff_2ecommands_2eappsIn_24s1939917301x724821635(v_st_240, heff_dup(v_t_242), heff_dup(v_x_2469), v_t_2470, v_t_2472));
  return heff_tail(v_c_2473, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam15, 1, 6, (V[]){v_x_2469, v_hd_2411, v_cmd_241, v_k_2412, v_st_240, v_t_242})});
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam11(V self, V *args) {
  V v_x_2459 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_xs_2461;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_Nothing: {
    v_xs_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2460 = heff_dup(heff_field(v_x_2459, 0));
    v_xs_2461 = v_x_2460;
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V v_total_2462 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2461; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_2461); r_; });
  V v_c_2468 = heff_clo(g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam12, 2, 1, (V[]){v_total_2462});
  return heff_tail(v_c_2468, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam14, 1, 6, (V[]){v_x_2459, v_st_240, v_t_242, v_hd_2411, v_cmd_241, v_k_2412})});
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam8(V self, V *args) {
  V v_x_2444 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2444);
  V v_t_2445 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_242), LBL_root)));
  V v_t_2446 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str11)));
  V v_p_2447 = (g_std_2epath_2ejoin_2eonto_240(v_t_2445, v_t_2446));
  V v_t_2448 = ({ V a_0 = heff_get(heff_dup(v_p_2447), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2447), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2449 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2447), LBL_drive), heff_get(v_p_2447, LBL_absolute), v_t_2448});
  V v_path_2450 = (g_std_2epath_2erender(v_st_240, v_t_2449));
  V v_c_2458 = heff_clo(g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam9, 2, 1, (V[]){v_path_2450});
  return heff_tail(v_c_2458, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam11, 1, 5, (V[]){v_hd_2411, v_st_240, v_t_242, v_cmd_241, v_k_2412})});
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_x_2424), LBL_errors));
  switch (heff_tag_of(v_t_2428)) {
  case TAG_True: {
    heff_drop(v_st_240);
    heff_drop(v_t_242);
    V v_n_2429 = heff_get(v_x_2424, LBL_errors);
    V v_t_2430 = heff_intEq(heff_dup(v_n_2429), MK_INT(1LL));
    V v_t_2431;
    switch (heff_tag_of(v_t_2430)) {
    case TAG_True: {
      heff_drop(v_n_2429);
      v_t_2431 = ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str2);
      break;
    }
    case TAG_False: {
      v_t_2431 = heff_strAppend(heff_intShow(v_n_2429), ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str3));
      break;
    }
    default: heff_nomatch(v_t_2430);
    }
    return (g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297(v_cmd_241, heff_strAppend(v_t_2431, ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str4)), v_hd_2411, v_k_2412));
  }
  case TAG_False: {
    V v_n_2432 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get(v_x_2424, LBL_seen); V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2433 = heff_intEq(heff_dup(v_n_2432), MK_INT(1LL));
    V v_t_2434;
    switch (heff_tag_of(v_t_2433)) {
    case TAG_True: {
      heff_drop(v_n_2432);
      v_t_2434 = ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str5);
      break;
    }
    case TAG_False: {
      v_t_2434 = heff_strAppend(heff_intShow(v_n_2432), ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str6));
      break;
    }
    default: heff_nomatch(v_t_2433);
    }
    V v_str_2435 = heff_strAppend(((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str7), heff_strAppend(heff_dup(v_cmd_241), heff_strAppend(((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str8), heff_strAppend(v_t_2434, ((V)&g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_str9)))));
    V v_c_2443 = heff_clo(g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam7, 2, 1, (V[]){v_str_2435});
    return heff_tail(v_c_2443, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam8, 1, 5, (V[]){v_st_240, v_t_242, v_hd_2411, v_cmd_241, v_k_2412})});
  }
  default: return heff_nomatch(v_t_2428);
  }
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2425 = heff_tag(TAG_End, 2, (V[]){v_x_2421, NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})}));
  return heff_tail(heff_get(heff_dup(v_hd_2411), LBL_bind), 2, (V[]){v_t_2426, heff_clo(g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam6, 1, 6, (V[]){v_x_2424, v_cmd_241, v_hd_2411, v_k_2412, v_st_240, v_t_242})});
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = heff_rec(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2423 = ({ V a_0 = heff_dup(v_x_2421); V a_1 = v_t_2422; V a_2 = v_x_2413; V r_ = (g_heff_2ecommands_2echeckModules_24s831911915x2085898913(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam5, 1, 6, (V[]){v_x_2421, v_hd_2411, v_cmd_241, v_k_2412, v_st_240, v_t_242})});
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_total_2414 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_x_2413));
  V v_c_2420 = heff_clo(g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam2, 2, 1, (V[]){v_total_2414});
  return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam4, 1, 6, (V[]){v_x_2413, v_hd_2411, v_cmd_241, v_k_2412, v_st_240, v_t_242})});
}
V g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo(g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661_lam1, 1, 5, (V[]){v_hd_2411, v_cmd_241, v_k_2412, v_st_240, v_t_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[60]; } g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_str2 = {{0x80000000u, K_STR, 0}, 60, 60, {104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 58, 32, 110, 111, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 104, 101, 114, 101, 58, 32, 98, 117, 105, 108, 100, 32, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam0(V self, V *args); static Clo g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam0, 1, 0};
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam2(V self, V *args); static Clo g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam2, 1, 0};
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam4(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam3(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam1(V self, V *args);
Clo g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_entry, 2, 0};

V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_str0), ((V)&g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273(a[0], a[1]);
}
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam0(V self, V *args) {
  V v_t_242 = args[0];
  return v_t_242;
}
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam2(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2425}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2426, v_k_241});
}
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414 = heff_strEq(v_x_2413, ((V)&g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_str1));
  V v_x_2415;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    v_x_2415 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2415 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    heff_drop(v_x_2415);
    V v_t_2416 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_str2), NTAG(TAG_MkUnit)});
    V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2419}));
    return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2420, heff_clo(g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam4, 1, 2, (V[]){v_hd_240, v_k_241})});
  }
  case TAG_Just: {
    heff_take_n(v_x_247, 0ULL, 1);
    V v_t_2428 = (g_heff_2ecommands_2ebuildTarget(v_x_2415, ((V)&g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_str3)));
    V v_t_2429 = (g_heff_2ecommands_2ebuildProject_24s1466262979x1248780661(v_x_2415, ((V)&g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_str4), v_t_2428));
    return heff_tail(v_t_2429, 2, (V[]){v_hd_240, v_k_241});
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam2_clo)})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2ebuildCmd_24s1765228052x2109465273_lam3, 1, 3, (V[]){v_x_247, v_hd_240, v_k_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2eheffHome_24s914773566x189787564_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {72, 69, 70, 70, 95, 72, 79, 77, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eheffHome_24s914773566x189787564_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {72, 79, 77, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2eheffHome_24s914773566x189787564_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {85, 83, 69, 82, 80, 82, 79, 70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2eheffHome_24s914773566x189787564_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eheffHome_24s914773566x189787564_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2eheffHome_24s914773566x189787564_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam0(V self, V *args); static Clo g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam0, 1, 0};
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam2(V self, V *args); static Clo g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam2, 1, 0};
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam4(V self, V *args); static Clo g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam4, 1, 0};
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam6(V self, V *args); static Clo g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam6, 1, 0};
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam7(V self, V *args);
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam5(V self, V *args);
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam3(V self, V *args);
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam1(V self, V *args);
Clo g_heff_2ecommands_2eheffHome_24s914773566x189787564_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffHome_24s914773566x189787564_entry, 2, 0};

V g_heff_2ecommands_2eheffHome_24s914773566x189787564(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2eheffHome_24s914773566x189787564_str0), ((V)&g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_245})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eheffHome_24s914773566x189787564(a[0], a[1]);
}
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam2(V self, V *args) {
  V v_v_248 = args[0];
  return v_v_248;
}
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam4(V self, V *args) {
  V v_v_2414 = args[0];
  return v_v_2414;
}
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam6(V self, V *args) {
  V v_s_2420 = args[0];
  return v_s_2420;
}
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2426 = heff_strEq(v_x_2425, ((V)&g_heff_2ecommands_2eheffHome_24s914773566x189787564_str3));
  V v_x_2427;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_True: {
    v_x_2427 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2427 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  V v_x_2438;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_d_2429;
    switch (heff_tag_of(v_x_2419)) {
    case TAG_Nothing: {
      v_d_2429 = ((V)&g_heff_2ecommands_2eheffHome_24s914773566x189787564_str4);
      break;
    }
    case TAG_Just: {
      V v_x_2428 = heff_field(v_x_2419, 0);
      heff_take_n(v_x_2419, 1ULL, 1);
      v_d_2429 = v_x_2428;
      break;
    }
    default: heff_nomatch(v_x_2419);
    }
    V v_a_2431;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_Nothing: {
      v_a_2431 = v_d_2429;
      break;
    }
    case TAG_Just: {
      V v_x_2430 = heff_field(v_x_2413, 0);
      heff_take_n(v_x_2413, 1ULL, 1);
      heff_drop(v_d_2429);
      v_a_2431 = v_x_2430;
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_t_2432 = (g_std_2epath_2eparse(v_x_2427, v_a_2431));
    V v_t_2433 = (g_std_2epath_2eparse(v_x_2427, ((V)&g_heff_2ecommands_2eheffHome_24s914773566x189787564_str5)));
    V v_p_2434 = (g_std_2epath_2ejoin_2eonto_240(v_t_2432, v_t_2433));
    V v_t_2435 = ({ V a_0 = heff_get(heff_dup(v_p_2434), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2434), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2436 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2434), LBL_drive), heff_get(v_p_2434, LBL_absolute), v_t_2435});
    v_x_2438 = ({ V a_0 = v_x_2427; V a_1 = v_t_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2427); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2437 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    heff_drop(v_x_2419);
    heff_drop(v_x_2413);
    heff_drop(v_x_2427);
    v_x_2438 = v_d_2437;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V f_ = v_k_241;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam6_clo)})});
  V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2423})}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2424, heff_clo(g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam7, 1, 4, (V[]){v_x_247, v_x_2419, v_x_2413, v_k_241})});
}
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2eheffHome_24s914773566x189787564_str2), ((V)&g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam4_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2417})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2418, heff_clo(g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam5, 1, 4, (V[]){v_hd_240, v_x_247, v_x_2413, v_k_241})});
}
V g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2eheffHome_24s914773566x189787564_str1), ((V)&g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam2_clo)})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2eheffHome_24s914773566x189787564_lam3, 1, 3, (V[]){v_hd_240, v_x_247, v_k_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2eshipIn_24s921163756x271563113_str0 = {{0x80000000u, K_STR, 0}, 14, 14, {105, 110, 115, 116, 97, 108, 108, 105, 110, 103, 32, 105, 110, 32}};
V g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam1(V self, V *args); static Clo g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam1, 1, 0};
V g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam0(V self, V *args);
V g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam5(V self, V *args);
V g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam4(V self, V *args);
V g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam3(V self, V *args);
V g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam2(V self, V *args);
Clo g_heff_2ecommands_2eshipIn_24s921163756x271563113_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipIn_24s921163756x271563113_entry, 5, 0};

V g_heff_2ecommands_2eshipIn_24s921163756x271563113(V v_st_240, V v_t_241, V v_done_242, V v_progs_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_progs_243);
    return v_done_242;
  }
  case TAG_Just: {
    V v_home_245 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V v_t_246 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_dup(v_progs_243)));
    V v_xs_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_prelude_2efoldl_24s847320519x792667925(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_xs_248 = (g_heff_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_247));
    V v_total_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_248; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    V v_c_2415 = heff_clo(g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam0, 2, 2, (V[]){heff_dup(v_home_245), v_total_249});
    return heff_clo(g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam2, 2, 6, (V[]){v_c_2415, v_progs_243, v_st_240, v_t_241, v_home_245, v_done_242});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecommands_2eshipIn_24s921163756x271563113_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eshipIn_24s921163756x271563113(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam1(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k2_2411 = args[1];
  V v_home_245 = heff_env(self)[0];
  V v_total_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ecommands_2eshipIn_24s921163756x271563113_str0), v_home_245), v_total_249, ((V)&g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam1_clo)});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2410), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})}));
  V f_ = heff_get(v_hd_2410, LBL_bind);
  args[0] = v_t_2414;
  args[1] = v_k2_2411;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_done_242 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2426);
  return heff_tail(v_done_242, 2, (V[]){v_hd_2422, v_k_2423});
}
V g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam4(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_x_2418 = heff_env(self)[0];
  V v_done_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_tag(TAG_End, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2422), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})}));
  V f_ = heff_get(heff_dup(v_hd_2422), LBL_bind);
  args[0] = v_t_2425;
  args[1] = heff_clo(g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam5, 1, 3, (V[]){v_done_242, v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_home_245 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_hd_2416 = heff_env(self)[5];
  V v_k_2417 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2419 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_progs_243));
  V v_xs_2420 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_prelude_2efoldl_24s847320519x792667925(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_t_2421 = (g_heff_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2420));
  V v_t_2427 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_home_245; V a_3 = heff_dup(v_x_2418); V a_4 = heff_clo(g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam4, 2, 2, (V[]){v_x_2418, v_done_242}); V a_5 = v_t_2421; V r_ = heff_tr(g_heff_2ecommands_2eshipAll_24s1787275079x301132786(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2421); r_; });
  return heff_tail(v_t_2427, 2, (V[]){v_hd_2416, v_k_2417});
}
V g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_progs_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_home_245 = heff_env(self)[4];
  V v_done_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo(g_heff_2ecommands_2eshipIn_24s921163756x271563113_lam3, 1, 7, (V[]){v_progs_243, v_st_240, v_t_241, v_home_245, v_done_242, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_str2 = {{0x80000000u, K_STR, 0}, 17, 17, {98, 117, 105, 108, 100, 105, 110, 103, 32, 112, 114, 111, 103, 114, 97, 109, 115}};
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam0(V self, V *args); static Clo g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam0, 1, 0};
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam3(V self, V *args); static Clo g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam3, 1, 0};
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam2(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam6(V self, V *args); static Clo g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam6, 1, 0};
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam5(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam9(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam8(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam7(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam4(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam1(V self, V *args);
Clo g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_entry, 6, 0};

V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042(V v_st_240, V v_t_241, V v_done_242, V v_progs_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_MkDir, 2, (V[]){heff_get(heff_dup(v_t_241), LBL_bin), ((V)&g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam0_clo)});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_249})}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam1, 1, 6, (V[]){v_st_240, v_t_241, v_hd_244, v_progs_243, v_done_242, v_k_245})});
}
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam0(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam3(V self, V *args) {
  V v_ok_2426 = args[0];
  return v_ok_2426;
}
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_path_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_2423, ((V)&g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam3_clo)})});
  V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2424), LBL_malg), 1, (V[]){v_t_2429}));
  V f_ = heff_get(v_hd_2424, LBL_bind);
  args[0] = v_t_2430;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam6(V self, V *args) {
  V v_t_2436 = args[0];
  return v_t_2436;
}
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam5(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k2_2435 = args[1];
  V v_total_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2437 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_str2), v_total_2433, ((V)&g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam6_clo)})});
  V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2434), LBL_malg), 1, (V[]){v_t_2437}));
  V f_ = heff_get(v_hd_2434, LBL_bind);
  args[0] = v_t_2438;
  args[1] = v_k2_2435;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam9(V self, V *args) {
  V v_x_2446 = args[0];
  V v_next_2441 = heff_env(self)[0];
  V v_hd_2442 = heff_env(self)[1];
  V v_k_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2446);
  return heff_tail(v_next_2441, 2, (V[]){v_hd_2442, v_k_2443});
}
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam8(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  V v_x_2440 = heff_env(self)[0];
  V v_next_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2444 = heff_tag(TAG_End, 2, (V[]){v_x_2440, NTAG(TAG_MkUnit)});
  V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2442), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2444})}));
  V f_ = heff_get(heff_dup(v_hd_2442), LBL_bind);
  args[0] = v_t_2445;
  args[1] = heff_clo(g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam9, 1, 3, (V[]){v_next_2441, v_hd_2442, v_k_2443});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_next_2441 = (g_heff_2ecommands_2eshipIn_24s921163756x271563113(heff_dup(v_st_240), heff_dup(v_t_241), v_done_242, heff_dup(v_progs_243), heff_get(heff_dup(v_t_241), LBL_shipTo)));
  V v_t_2447 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = heff_dup(v_x_2440); V a_3 = heff_clo(g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam8, 2, 2, (V[]){v_x_2440, v_next_2441}); V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ecommands_2ebuildEach_24s385407377x1706379496(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_progs_243); r_; });
  return heff_tail(v_t_2447, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2432);
  V v_total_2433 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_progs_243));
  V v_c_2439 = heff_clo(g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam5, 2, 1, (V[]){v_total_2433});
  return heff_tail(v_c_2439, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam7, 1, 6, (V[]){v_st_240, v_t_241, v_done_242, v_progs_243, v_hd_244, v_k_245})});
}
V g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2411);
  V v_t_2412 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_str0)));
  V v_t_2413 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_str1)));
  V v_p_2414 = (g_std_2epath_2ejoin_2eonto_240(v_t_2412, v_t_2413));
  V v_t_2415 = ({ V a_0 = heff_get(heff_dup(v_p_2414), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2414), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2416 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2414), LBL_drive), heff_get(v_p_2414, LBL_absolute), v_t_2415});
  V v_p_2417 = (g_std_2epath_2erender(v_st_240, v_t_2416));
  V v_t_2418 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_root)));
  V v_t_2419 = (g_std_2epath_2eparse(v_st_240, v_p_2417));
  V v_p_2420 = (g_std_2epath_2ejoin_2eonto_240(v_t_2418, v_t_2419));
  V v_t_2421 = ({ V a_0 = heff_get(heff_dup(v_p_2420), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2420), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2422 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2420), LBL_drive), heff_get(v_p_2420, LBL_absolute), v_t_2421});
  V v_path_2423 = (g_std_2epath_2erender(v_st_240, v_t_2422));
  V v_c_2431 = heff_clo(g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam2, 2, 1, (V[]){v_path_2423});
  return heff_tail(v_c_2431, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042_lam4, 1, 6, (V[]){v_progs_243, v_hd_244, v_st_240, v_t_241, v_done_242, v_k_245})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {99, 104, 101, 99, 107, 105, 110, 103, 32, 109, 111, 100, 117, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {49, 32, 101, 114, 114, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 101, 114, 114, 111, 114, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str4 = {{0x80000000u, K_STR, 0}, 25, 25, {32, 105, 110, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 109, 111, 100, 117, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {49, 32, 109, 111, 100, 117, 108, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 109, 111, 100, 117, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {104, 101, 102, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str9 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 99, 104, 101, 99, 107, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str12 = {{0x80000000u, K_STR, 0}, 30, 30, {114, 101, 97, 100, 105, 110, 103, 32, 116, 104, 101, 32, 112, 114, 111, 103, 114, 97, 109, 115, 39, 32, 98, 117, 105, 108, 100, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str13 = {{0x80000000u, K_STR, 0}, 7, 7, {49, 32, 101, 114, 114, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str14 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 101, 114, 114, 111, 114, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str15 = {{0x80000000u, K_STR, 0}, 26, 26, {32, 105, 110, 32, 116, 104, 101, 32, 112, 114, 111, 103, 114, 97, 109, 115, 39, 32, 98, 117, 105, 108, 100, 46, 104, 102}};
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam3(V self, V *args); static Clo g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam3, 1, 0};
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam2(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam7(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam10(V self, V *args); static Clo g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam10, 1, 0};
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam9(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam13(V self, V *args); static Clo g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam13, 1, 0};
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam12(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam16(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam15(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam14(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam11(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam8(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam6(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam5(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam4(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam1(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam0(V self, V *args);
Clo g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_entry, 5, 0};

V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318(V v_st_240, V v_cmd_241, V v_t_242, V v_none_243, V v_done_244) {
top: ;
  V v_t_245 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_242), LBL_root)));
  V v_t_246 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str0)));
  V v_p_247 = (g_std_2epath_2ejoin_2eonto_240(v_t_245, v_t_246));
  V v_t_248 = ({ V a_0 = heff_get(heff_dup(v_p_247), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_247), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_249 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_247), LBL_drive), heff_get(v_p_247, LBL_absolute), v_t_248});
  V v_t_2410 = (g_std_2epath_2erender(v_st_240, v_t_249));
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_c_2412 = (g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798(v_t_2411, NTAG(TAG_Nil)));
  return heff_clo(g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam0, 2, 6, (V[]){v_c_2412, v_cmd_241, v_st_240, v_t_242, v_none_243, v_done_244});
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam3(V self, V *args) {
  V v_t_2419 = args[0];
  return v_t_2419;
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_total_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str1), v_total_2416, ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam3_clo)})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_2420}));
  V f_ = heff_get(v_hd_2417, LBL_bind);
  args[0] = v_t_2421;
  args[1] = v_k2_2418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam7(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k2_2439 = args[1];
  V v_str_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2437, ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str10)), NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2438), LBL_malg), 1, (V[]){v_t_2443}));
  V f_ = heff_get(v_hd_2438, LBL_bind);
  args[0] = v_t_2444;
  args[1] = v_k2_2439;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam10(V self, V *args) {
  V v_ns_2455 = args[0];
  return v_ns_2455;
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam9(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k2_2454 = args[1];
  V v_path_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){v_path_2452, ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam10_clo)})});
  V v_t_2457 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2453), LBL_malg), 1, (V[]){v_t_2458}));
  V f_ = heff_get(v_hd_2453, LBL_bind);
  args[0] = v_t_2459;
  args[1] = v_k2_2454;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam13(V self, V *args) {
  V v_t_2467 = args[0];
  return v_t_2467;
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam12(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k2_2466 = args[1];
  V v_total_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2468 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str12), v_total_2464, ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam13_clo)})});
  V v_t_2469 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2465), LBL_malg), 1, (V[]){v_t_2468}));
  V f_ = heff_get(v_hd_2465, LBL_bind);
  args[0] = v_t_2469;
  args[1] = v_k2_2466;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam16(V self, V *args) {
  V v_x_2479 = args[0];
  V v_x_2476 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  V v_none_243 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2479);
  V v_t_2480 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_x_2476), LBL_bad));
  switch (heff_tag_of(v_t_2480)) {
  case TAG_True: {
    heff_drop(v_none_243);
    heff_drop(v_st_240);
    heff_drop(v_t_242);
    heff_drop(v_done_244);
    V v_n_2481 = heff_get(v_x_2476, LBL_bad);
    V v_t_2482 = heff_intEq(heff_dup(v_n_2481), MK_INT(1LL));
    V v_t_2483;
    switch (heff_tag_of(v_t_2482)) {
    case TAG_True: {
      heff_drop(v_n_2481);
      v_t_2483 = ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str13);
      break;
    }
    case TAG_False: {
      v_t_2483 = heff_strAppend(heff_intShow(v_n_2481), ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str14));
      break;
    }
    default: heff_nomatch(v_t_2482);
    }
    return (g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297(v_cmd_241, heff_strAppend(v_t_2483, ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str15)), v_hd_2413, v_k_2414));
  }
  case TAG_False: {
    heff_drop(v_cmd_241);
    V v_t_2484 = heff_get(heff_dup(v_x_2476), LBL_apps);
    switch (heff_tag_of(v_t_2484)) {
    case TAG_Nil: {
      heff_drop(v_x_2476);
      heff_drop(v_st_240);
      heff_drop(v_t_242);
      heff_drop(v_done_244);
      return heff_tail(v_none_243, 2, (V[]){v_hd_2413, v_k_2414});
    }
    case TAG_Cons: {
      heff_take_n(v_t_2484, 0ULL, 2);
      heff_drop(v_none_243);
      return (g_heff_2ecommands_2ebuildPrograms_24s1786421268x2116043042(v_st_240, v_t_242, v_done_244, heff_get(v_x_2476, LBL_apps), v_hd_2413, v_k_2414));
    }
    default: return heff_nomatch(v_t_2484);
    }
  }
  default: return heff_nomatch(v_t_2480);
  }
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam15(V self, V *args) {
  V v_x_2476 = args[0];
  V v_x_2471 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  V v_none_243 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2477 = heff_tag(TAG_End, 2, (V[]){v_x_2471, NTAG(TAG_MkUnit)});
  V v_t_2478 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2477})}));
  return heff_tail(heff_get(heff_dup(v_hd_2413), LBL_bind), 2, (V[]){v_t_2478, heff_clo(g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam16, 1, 8, (V[]){v_x_2476, v_cmd_241, v_hd_2413, v_k_2414, v_none_243, v_st_240, v_t_242, v_done_244})});
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam14(V self, V *args) {
  V v_x_2471 = args[0];
  V v_x_2461 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_cmd_241 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2472 = heff_rec(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2474;
  switch (heff_tag_of(v_x_2461)) {
  case TAG_Nothing: {
    v_t_2474 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2473 = heff_field(v_x_2461, 0);
    heff_take_n(v_x_2461, 1ULL, 1);
    v_t_2474 = v_x_2473;
    break;
  }
  default: heff_nomatch(v_x_2461);
  }
  V v_c_2475 = (g_heff_2ecommands_2eappsIn_24s1939917301x724821635(v_st_240, heff_dup(v_t_242), heff_dup(v_x_2471), v_t_2472, v_t_2474));
  return heff_tail(v_c_2475, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam15, 1, 8, (V[]){v_x_2471, v_hd_2413, v_cmd_241, v_k_2414, v_none_243, v_st_240, v_t_242, v_done_244})});
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam11(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_xs_2463;
  switch (heff_tag_of(v_x_2461)) {
  case TAG_Nothing: {
    v_xs_2463 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2462 = heff_dup(heff_field(v_x_2461, 0));
    v_xs_2463 = v_x_2462;
    break;
  }
  default: heff_nomatch(v_x_2461);
  }
  V v_total_2464 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2463; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_2463); r_; });
  V v_c_2470 = heff_clo(g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam12, 2, 1, (V[]){v_total_2464});
  return heff_tail(v_c_2470, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam14, 1, 8, (V[]){v_x_2461, v_st_240, v_t_242, v_hd_2413, v_cmd_241, v_k_2414, v_none_243, v_done_244})});
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam8(V self, V *args) {
  V v_x_2446 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2446);
  V v_t_2447 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_242), LBL_root)));
  V v_t_2448 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str11)));
  V v_p_2449 = (g_std_2epath_2ejoin_2eonto_240(v_t_2447, v_t_2448));
  V v_t_2450 = ({ V a_0 = heff_get(heff_dup(v_p_2449), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2449), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2451 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2449), LBL_drive), heff_get(v_p_2449, LBL_absolute), v_t_2450});
  V v_path_2452 = (g_std_2epath_2erender(v_st_240, v_t_2451));
  V v_c_2460 = heff_clo(g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam9, 2, 1, (V[]){v_path_2452});
  return heff_tail(v_c_2460, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam11, 1, 7, (V[]){v_hd_2413, v_st_240, v_t_242, v_cmd_241, v_k_2414, v_none_243, v_done_244})});
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2426 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2429);
  V v_t_2430 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_x_2426), LBL_errors));
  switch (heff_tag_of(v_t_2430)) {
  case TAG_True: {
    heff_drop(v_st_240);
    heff_drop(v_t_242);
    heff_drop(v_none_243);
    heff_drop(v_done_244);
    V v_n_2431 = heff_get(v_x_2426, LBL_errors);
    V v_t_2432 = heff_intEq(heff_dup(v_n_2431), MK_INT(1LL));
    V v_t_2433;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_True: {
      heff_drop(v_n_2431);
      v_t_2433 = ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str2);
      break;
    }
    case TAG_False: {
      v_t_2433 = heff_strAppend(heff_intShow(v_n_2431), ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str3));
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    return (g_heff_2ecommands_2enothingBuilt_24s1493772807x2141061297(v_cmd_241, heff_strAppend(v_t_2433, ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str4)), v_hd_2413, v_k_2414));
  }
  case TAG_False: {
    V v_n_2434 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get(v_x_2426, LBL_seen); V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2435 = heff_intEq(heff_dup(v_n_2434), MK_INT(1LL));
    V v_t_2436;
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      heff_drop(v_n_2434);
      v_t_2436 = ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str5);
      break;
    }
    case TAG_False: {
      v_t_2436 = heff_strAppend(heff_intShow(v_n_2434), ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str6));
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    V v_str_2437 = heff_strAppend(((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str7), heff_strAppend(heff_dup(v_cmd_241), heff_strAppend(((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str8), heff_strAppend(v_t_2436, ((V)&g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_str9)))));
    V v_c_2445 = heff_clo(g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam7, 2, 1, (V[]){v_str_2437});
    return heff_tail(v_c_2445, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam8, 1, 7, (V[]){v_st_240, v_t_242, v_hd_2413, v_cmd_241, v_k_2414, v_none_243, v_done_244})});
  }
  default: return heff_nomatch(v_t_2430);
  }
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2427 = heff_tag(TAG_End, 2, (V[]){v_x_2423, NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})}));
  return heff_tail(heff_get(heff_dup(v_hd_2413), LBL_bind), 2, (V[]){v_t_2428, heff_clo(g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam6, 1, 8, (V[]){v_x_2426, v_cmd_241, v_hd_2413, v_k_2414, v_st_240, v_t_242, v_none_243, v_done_244})});
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2424 = heff_rec(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2425 = ({ V a_0 = heff_dup(v_x_2423); V a_1 = v_t_2424; V a_2 = v_x_2415; V r_ = (g_heff_2ecommands_2echeckModules_24s831911915x2085898913(a_0, a_1, a_2)); heff_drop(v_x_2415); r_; });
  return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam5, 1, 8, (V[]){v_x_2423, v_hd_2413, v_cmd_241, v_k_2414, v_st_240, v_t_242, v_none_243, v_done_244})});
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_total_2416 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_x_2415));
  V v_c_2422 = heff_clo(g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam2, 2, 1, (V[]){v_total_2416});
  return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam4, 1, 8, (V[]){v_x_2415, v_hd_2413, v_cmd_241, v_k_2414, v_st_240, v_t_242, v_none_243, v_done_244})});
}
V g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_none_243 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo(g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318_lam1, 1, 7, (V[]){v_hd_2413, v_cmd_241, v_k_2414, v_st_240, v_t_242, v_none_243, v_done_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {80, 65, 84, 72}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str7 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 32, 105, 110, 115, 116, 97, 108, 108, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[60]; } g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str8 = {{0x80000000u, K_STR, 0}, 60, 60, {32, 105, 115, 32, 110, 111, 116, 32, 111, 110, 32, 116, 104, 101, 32, 80, 65, 84, 72, 58, 32, 97, 100, 100, 32, 105, 116, 32, 116, 104, 101, 114, 101, 32, 116, 111, 32, 114, 117, 110, 32, 116, 104, 101, 109, 32, 98, 121, 32, 116, 104, 101, 105, 114, 32, 110, 97, 109, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam0(V self, V *args); static Clo g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam0, 1, 0};
V g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam2(V self, V *args); static Clo g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam2, 1, 0};
V g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam4(V self, V *args);
V g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam3(V self, V *args);
V g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam1(V self, V *args);
Clo g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_entry, 4, 0};

V g_heff_2ecommands_2eonPathHint_24s240252977x1122862838(V v_st_240, V v_bin_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam0_clo)})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam1, 1, 4, (V[]){v_hd_242, heff_dup(v_st_240), v_bin_241, v_k_243})});
}
V g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eonPathHint_24s240252977x1122862838(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam2(V self, V *args) {
  V v_v_2410 = args[0];
  return v_v_2410;
}
V g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam4(V self, V *args) {
  V v_d_2422 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bin_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = (g_std_2epath_2eparse(v_st_240, v_d_2422));
  V v_t_2424 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str5)));
  V v_p_2425 = (g_std_2epath_2ejoin_2eonto_240(v_t_2423, v_t_2424));
  V v_t_2426 = ({ V a_0 = heff_get(heff_dup(v_p_2425), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2425), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2427 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2425), LBL_drive), heff_get(v_p_2425, LBL_absolute), v_t_2426});
  V v_t_2428 = (g_std_2epath_2erender(v_st_240, v_t_2427));
  V v_t_2429 = (g_std_2epath_2eparse(v_st_240, v_bin_241));
  V v_t_2430 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str6)));
  V v_p_2431 = (g_std_2epath_2ejoin_2eonto_240(v_t_2429, v_t_2430));
  V v_t_2432 = ({ V a_0 = heff_get(heff_dup(v_p_2431), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2431), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2433 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2431), LBL_drive), heff_get(v_p_2431, LBL_absolute), v_t_2432});
  V v_t_2434 = ({ V a_0 = v_st_240; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  return heff_strEq(v_t_2428, v_t_2434);
}
V g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_2417;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    v_path_2417 = ((V)&g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2416 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    v_path_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_t_2418 = heff_strEq(v_x_249, ((V)&g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str2));
  V v_sep_2419;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    v_sep_2419 = ((V)&g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str3);
    break;
  }
  case TAG_False: {
    v_sep_2419 = ((V)&g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str4);
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V v_t_2420 = heff_intEq(heff_strLength(heff_dup(v_sep_2419)), MK_INT(0LL));
  V v_t_2421;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_True: {
    heff_drop(v_sep_2419);
    v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){v_path_2417, NTAG(TAG_Nil)});
    break;
  }
  case TAG_False: {
    v_t_2421 = (g_prelude_2esplitFrom(v_sep_2419, v_path_2417, MK_INT(0LL), NTAG(TAG_Nil)));
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  V v_t_2435 = ({ V a_0 = heff_clo(g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam4, 1, 2, (V[]){v_st_240, heff_dup(v_bin_241)}); V a_1 = v_t_2421; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_t_2421); r_; });
  switch (heff_tag_of(v_t_2435)) {
  case TAG_True: {
    heff_drop(v_bin_241);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_2436 = heff_strAppend(((V)&g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str7), heff_strAppend(v_bin_241, ((V)&g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str8)));
    V v_t_2437 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str9)), NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2440}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2441, v_k_243});
  }
  default: return heff_nomatch(v_t_2435);
  }
}
V g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_str0), ((V)&g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam2_clo)})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2413})}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_lam3, 1, 5, (V[]){v_x_249, v_st_240, v_bin_241, v_k_243, v_hd_242})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str1 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {105, 110, 115, 116, 97, 108, 108, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {45, 79, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str5 = {{0x80000000u, K_STR, 0}, 31, 31, {104, 101, 102, 102, 32, 105, 110, 115, 116, 97, 108, 108, 58, 32, 110, 111, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 105, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str7 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 110, 115, 116, 97, 108, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str8 = {{0x80000000u, K_STR, 0}, 29, 29, {104, 101, 102, 102, 32, 105, 110, 115, 116, 97, 108, 108, 58, 32, 110, 111, 32, 112, 114, 111, 103, 114, 97, 109, 115, 32, 105, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str9 = {{0x80000000u, K_STR, 0}, 41, 41, {58, 32, 97, 112, 112, 47, 88, 47, 32, 119, 105, 116, 104, 32, 97, 32, 98, 117, 105, 108, 100, 46, 104, 102, 32, 105, 115, 32, 116, 104, 101, 32, 112, 114, 111, 103, 114, 97, 109, 32, 88}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam0(V self, V *args); static Clo g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam0, 1, 0};
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam4(V self, V *args); static Clo g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam4, 1, 0};
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam3(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam6(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam8(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam10(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam9(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam7(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam5(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam2(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam1(V self, V *args);
Clo g_heff_2ecommands_2einstallCmd_24s141488678x313111314_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2einstallCmd_24s141488678x313111314_entry, 3, 0};

V g_heff_2ecommands_2einstallCmd_24s141488678x313111314(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam0_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam1, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242})});
}
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2einstallCmd_24s141488678x313111314(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam4(V self, V *args) {
  V v_t_2420 = args[0];
  return v_t_2420;
}
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k2_2419 = args[1];
  V v_path_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2417, ((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam4_clo)})});
  V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2418), LBL_malg), 1, (V[]){v_t_2423}));
  V f_ = heff_get(v_hd_2418, LBL_bind);
  args[0] = v_t_2424;
  args[1] = v_k2_2419;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam6(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_x_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2434);
  V f_ = v_k_2435;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam8(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  V v_t_2445 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2448}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2449, v_k_242});
}
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam10(V self, V *args) {
  V v_x_2460 = args[0];
  V v_hd_2452 = heff_env(self)[0];
  V v_k_2453 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2460);
  V v_t_2461 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2462 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2452), LBL_malg), 1, (V[]){v_t_2464}));
  return heff_tail(heff_get(v_hd_2452, LBL_bind), 2, (V[]){v_t_2465, v_k_2453});
}
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam9(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k_2453 = args[1];
  V v_dir_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2454 = heff_strAppend(((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str8), heff_strAppend(v_dir_240, ((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str9)));
  V v_t_2455 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2454, ((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str10)), NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2452), LBL_malg), 1, (V[]){v_t_2458}));
  V f_ = heff_get(heff_dup(v_hd_2452), LBL_bind);
  args[0] = v_t_2459;
  args[1] = heff_clo(g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam10, 1, 2, (V[]){v_hd_2452, v_k_2453});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2426 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_x_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Nothing: {
    heff_drop(v_x_2437);
    heff_drop(v_x_2410);
    V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str5), v_dir_240), ((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str6));
    V v_t_2439 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2438, NTAG(TAG_MkUnit)});
    V v_t_2440 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2442}));
    return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2443, heff_clo(g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam8, 1, 2, (V[]){v_hd_241, v_k_242})});
  }
  case TAG_Just: {
    heff_take_n(v_x_2426, 0ULL, 1);
    V v_t_2451 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eonPathHint_24s240252977x1122862838_clo), 2, (V[]){heff_dup(v_x_2410), heff_get(heff_dup(v_x_2437), LBL_bin)}));
    V v_t_2466 = (g_heff_2ecommands_2ebuildProject_24s1488529449x1365175318(v_x_2410, ((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str7), v_x_2437, heff_clo(g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam9, 2, 1, (V[]){v_dir_240}), v_t_2451));
    return heff_tail(v_t_2466, 2, (V[]){v_hd_241, v_k_242});
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2427 = (g_std_2epath_2eparse(v_x_2410, heff_dup(v_x_2411)));
  V v_t_2428 = (g_std_2epath_2eparse(v_x_2410, ((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str2)));
  V v_p_2429 = (g_std_2epath_2ejoin_2eonto_240(v_t_2427, v_t_2428));
  V v_t_2430 = ({ V a_0 = heff_get(heff_dup(v_p_2429), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2429), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2431 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2429), LBL_drive), heff_get(v_p_2429, LBL_absolute), v_t_2430});
  V v_t_2432 = (g_std_2epath_2erender(v_x_2410, v_t_2431));
  V v_x_2433 = heff_rec(6, shape_root__bin__said__pages__shipTo__opt, (V[]){heff_dup(v_dir_240), v_t_2432, ((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str3), NTAG(TAG_False), heff_tag(TAG_Just, 1, (V[]){v_x_2411}), ((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str4)});
  V v_c_2436 = heff_clo(g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam6, 2, 1, (V[]){v_x_2433});
  return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam7, 1, 5, (V[]){v_x_2426, v_dir_240, v_hd_241, v_k_242, v_x_2410})});
}
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = (g_std_2epath_2eparse(v_x_2410, heff_dup(v_dir_240)));
  V v_t_2413 = (g_std_2epath_2eparse(v_x_2410, ((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str1)));
  V v_p_2414 = (g_std_2epath_2ejoin_2eonto_240(v_t_2412, v_t_2413));
  V v_t_2415 = ({ V a_0 = heff_get(heff_dup(v_p_2414), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2414), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2416 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2414), LBL_drive), heff_get(v_p_2414, LBL_absolute), v_t_2415});
  V v_path_2417 = (g_std_2epath_2erender(v_x_2410, v_t_2416));
  V v_c_2425 = heff_clo(g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam3, 2, 1, (V[]){v_path_2417});
  return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam5, 1, 5, (V[]){v_x_2410, v_x_2411, v_dir_240, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_strEq(v_x_248, ((V)&g_heff_2ecommands_2einstallCmd_24s141488678x313111314_str0));
  V v_x_2410;
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    v_x_2410 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2410 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  return (g_heff_2ecommands_2eheffHome_24s914773566x189787564(heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einstallCmd_24s141488678x313111314_lam2, 1, 4, (V[]){v_x_2410, v_dir_240, v_hd_241, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2epublishFails_24s1138740946x688035206_str0 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 32, 112, 117, 98, 108, 105, 115, 104, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishFails_24s1138740946x688035206_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2epublishFails_24s1138740946x688035206_lam0(V self, V *args);
Clo g_heff_2ecommands_2epublishFails_24s1138740946x688035206_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishFails_24s1138740946x688035206_entry, 3, 0};

V g_heff_2ecommands_2epublishFails_24s1138740946x688035206(V v_why_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2epublishFails_24s1138740946x688035206_str0), v_why_240), ((V)&g_heff_2ecommands_2epublishFails_24s1138740946x688035206_str1));
  V v_t_244 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_243, NTAG(TAG_MkUnit)});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2epublishFails_24s1138740946x688035206_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2epublishFails_24s1138740946x688035206_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishFails_24s1138740946x688035206(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2epublishFails_24s1138740946x688035206_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_249);
  V v_t_2410 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2414, v_k_242});
}
V g_heff_2ecommands_2etestAll_24s1250025441x1950168553_lam0(V self, V *args);
V g_heff_2ecommands_2etestAll_24s1250025441x1950168553_lam2(V self, V *args);
V g_heff_2ecommands_2etestAll_24s1250025441x1950168553_lam1(V self, V *args);
Clo g_heff_2ecommands_2etestAll_24s1250025441x1950168553_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestAll_24s1250025441x1950168553_entry, 2, 0};

V g_heff_2ecommands_2etestAll_24s1250025441x1950168553(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_clo(g_heff_2ecommands_2etestAll_24s1250025441x1950168553_lam0, 2, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_c_246 = (g_heff_2ecommands_2etestOneF_24s48196897x863364522(heff_dup(g_heff_2ecommands_2edefaultSeed_get()), heff_dup(v_f_244)));
    return heff_clo(g_heff_2ecommands_2etestAll_24s1250025441x1950168553_lam1, 2, 3, (V[]){v_c_246, v_acc_241, heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2etestAll_24s1250025441x1950168553_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2etestAll_24s1250025441x1950168553(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2etestAll_24s1250025441x1950168553_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_acc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2etestAll_24s1250025441x1950168553_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_intAdd(heff_get(heff_dup(v_acc_241), LBL_total), heff_get(heff_dup(v_x_249), LBL_total));
  V v_t_2411 = heff_intAdd(heff_get(heff_dup(v_acc_241), LBL_failed), heff_get(heff_dup(v_x_249), LBL_failed));
  V v_t_2412 = heff_get(heff_dup(v_acc_241), LBL_ok);
  V v_t_2413;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    v_t_2413 = heff_get(heff_dup(v_x_249), LBL_ok);
    break;
  }
  case TAG_False: {
    v_t_2413 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_t_2414 = heff_intAdd(heff_get(heff_dup(v_acc_241), LBL_tests), heff_get(heff_dup(v_x_249), LBL_tests));
  V v_t_2415 = heff_intAdd(heff_get(v_acc_241, LBL_testsFailed), heff_get(v_x_249, LBL_testsFailed));
  V v_t_2416 = ({ V a_0 = v_rest_245; V a_1 = heff_rec(5, shape_total__failed__ok__tests__testsFailed, (V[]){v_t_2410, v_t_2411, v_t_2413, v_t_2414, v_t_2415}); V r_ = (g_heff_2ecommands_2etestAll_24s1250025441x1950168553(a_0, a_1)); heff_drop(v_rest_245); r_; });
  return heff_tail(v_t_2416, 2, (V[]){v_hd_247, v_k_248});
}
V g_heff_2ecommands_2etestAll_24s1250025441x1950168553_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2ecommands_2etestAll_24s1250025441x1950168553_lam2, 1, 4, (V[]){v_acc_241, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2egitOk_24s1652772014x1583161201_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egitOk_24s1652772014x1583161201_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egitOk_24s1652772014x1583161201_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2egitOk_24s1652772014x1583161201_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {58, 32, 103, 105, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2egitOk_24s1652772014x1583161201_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
V g_heff_2ecommands_2egitOk_24s1652772014x1583161201_lam0(V self, V *args); static Clo g_heff_2ecommands_2egitOk_24s1652772014x1583161201_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egitOk_24s1652772014x1583161201_lam0, 1, 0};
V g_heff_2ecommands_2egitOk_24s1652772014x1583161201_lam1(V self, V *args);
Clo g_heff_2ecommands_2egitOk_24s1652772014x1583161201_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egitOk_24s1652772014x1583161201_entry, 4, 0};

V g_heff_2ecommands_2egitOk_24s1652772014x1583161201(V v_what_240, V v_as_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2egitOk_24s1652772014x1583161201_str0), heff_dup(v_as_241), ((V)&g_heff_2ecommands_2egitOk_24s1652772014x1583161201_lam0_clo)})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})}));
  return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2egitOk_24s1652772014x1583161201_lam1, 1, 3, (V[]){v_as_241, v_what_240, v_k_243})});
}
V g_heff_2ecommands_2egitOk_24s1652772014x1583161201_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2egitOk_24s1652772014x1583161201(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2egitOk_24s1652772014x1583161201_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_heff_2ecommands_2egitOk_24s1652772014x1583161201_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_as_241 = heff_env(self)[0];
  V v_what_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_intEq(heff_get(heff_dup(v_x_249), LBL_status), MK_INT(0LL));
  V v_x_2420;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_x_249);
    heff_drop(v_as_241);
    heff_drop(v_what_240);
    v_x_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_False: {
    V v_t_2413;
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecommands_2egitOk_24s1652772014x1583161201_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_as_241, 0);
      V v_xs_2412 = heff_field(v_as_241, 1);
      heff_take_n(v_as_241, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecommands_2egitOk_24s1652772014x1583161201_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_as_241);
    }
    V v_s_2414 = heff_get(v_x_249, LBL_err);
    V v_t_2415 = (g_prelude_2eskipSpaces(heff_dup(v_s_2414), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2416 = heff_intSub(heff_strLength(heff_dup(v_s_2414)), MK_INT(1LL));
    V v_t_2417 = (g_prelude_2eskipSpaces(heff_dup(v_s_2414), v_t_2416, MK_INT(-1LL)));
    V v_t_2418 = heff_strSlice(v_s_2414, v_t_2415, heff_intAdd(v_t_2417, MK_INT(1LL)));
    V v_t_2419 = heff_strAppend(v_what_240, heff_strAppend(((V)&g_heff_2ecommands_2egitOk_24s1652772014x1583161201_str3), heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ecommands_2egitOk_24s1652772014x1583161201_str4), v_t_2418))));
    v_x_2420 = heff_tag(TAG_Just, 1, (V[]){v_t_2419});
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V f_ = v_k_243;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str5 = {{0x80000000u, K_STR, 0}, 10, 10, {110, 111, 116, 32, 116, 97, 103, 103, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 117, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str8 = {{0x80000000u, K_STR, 0}, 6, 6, {111, 114, 105, 103, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str9 = {{0x80000000u, K_STR, 0}, 18, 18, {116, 97, 103, 103, 101, 100, 44, 32, 110, 111, 116, 32, 112, 117, 115, 104, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str10 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 32, 112, 117, 98, 108, 105, 115, 104, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str12 = {{0x80000000u, K_STR, 0}, 7, 7, {44, 32, 116, 97, 103, 32, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2epublishTag_24s146522991x1682623660_lam1(V self, V *args);
V g_heff_2ecommands_2epublishTag_24s146522991x1682623660_lam0(V self, V *args);
Clo g_heff_2ecommands_2epublishTag_24s146522991x1682623660_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishTag_24s146522991x1682623660_entry, 4, 0};

V g_heff_2ecommands_2epublishTag_24s146522991x1682623660(V v_v_240, V v_pk_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str0), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str1), heff_dup(v_v_240)), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str2), v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str4), v_t_245})});
  HEFF_LAST return g_heff_2ecommands_2egitOk_24s1652772014x1583161201(((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str5), v_t_246, heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2epublishTag_24s146522991x1682623660_lam0, 1, 4, (V[]){v_v_240, v_hd_242, v_pk_241, v_k_243}));
}
V g_heff_2ecommands_2epublishTag_24s146522991x1682623660_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishTag_24s146522991x1682623660(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2epublishTag_24s146522991x1682623660_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_pk_241 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str10), heff_strAppend(heff_get(v_pk_241, LBL_module), heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str11), heff_strAppend(heff_dup(v_v_240), heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str12), v_v_240)))));
    V v_t_2412 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str13)), NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2415}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2416, v_k_243});
  }
  case TAG_Just: {
    V v_why_2417 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    heff_drop(v_pk_241);
    heff_drop(v_v_240);
    return (g_heff_2ecommands_2epublishFails_24s1138740946x688035206(v_why_2417, v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ecommands_2epublishTag_24s146522991x1682623660_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str6), heff_dup(v_v_240)), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str8), v_t_248})});
    return (g_heff_2ecommands_2egitOk_24s1652772014x1583161201(((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_str9), v_t_249, heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2epublishTag_24s146522991x1682623660_lam1, 1, 4, (V[]){v_pk_241, v_v_240, v_hd_242, v_k_243})));
  }
  case TAG_Just: {
    V v_why_2418 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop(v_pk_241);
    return (g_heff_2ecommands_2epublishFails_24s1138740946x688035206(v_why_2418, v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_x_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s632403930x348860581_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2epublishTested_24s632403930x348860581_str1 = {{0x80000000u, K_STR, 0}, 27, 27, {32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 100, 111, 32, 110, 111, 116, 32, 104, 111, 108, 100, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s632403930x348860581_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2epublishTested_24s632403930x348860581_str3 = {{0x80000000u, K_STR, 0}, 37, 37, {32, 116, 101, 115, 116, 115, 32, 102, 97, 105, 108, 44, 32, 111, 114, 32, 97, 32, 102, 105, 108, 101, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 99, 104, 101, 99, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s632403930x348860581_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2epublishTested_24s632403930x348860581_str5 = {{0x80000000u, K_STR, 0}, 27, 27, {32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 100, 111, 32, 110, 111, 116, 32, 104, 111, 108, 100, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s632403930x348860581_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2epublishTested_24s632403930x348860581_str7 = {{0x80000000u, K_STR, 0}, 37, 37, {32, 116, 101, 115, 116, 115, 32, 102, 97, 105, 108, 44, 32, 111, 114, 32, 97, 32, 102, 105, 108, 101, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 99, 104, 101, 99, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s632403930x348860581_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2epublishTested_24s632403930x348860581_str9 = {{0x80000000u, K_STR, 0}, 27, 27, {32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 100, 111, 32, 110, 111, 116, 32, 104, 111, 108, 100, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s632403930x348860581_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2epublishTested_24s632403930x348860581_str11 = {{0x80000000u, K_STR, 0}, 37, 37, {32, 116, 101, 115, 116, 115, 32, 102, 97, 105, 108, 44, 32, 111, 114, 32, 97, 32, 102, 105, 108, 101, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 99, 104, 101, 99, 107}};
Clo g_heff_2ecommands_2epublishTested_24s632403930x348860581_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishTested_24s632403930x348860581_entry, 3, 0};

V g_heff_2ecommands_2epublishTested_24s632403930x348860581(V v_v_240, V v_pk_241, V v_r_242) {
top: ;
  V v_t_243 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_r_242), LBL_failed));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_v_240);
    heff_drop(v_pk_241);
    V v_t_244 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_failed));
    V v_t_245 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_total));
    V v_t_246 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_testsFailed));
    V v_t_247 = heff_intShow(heff_get(v_r_242, LBL_tests));
    V v_t_248 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s632403930x348860581_str0), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s632403930x348860581_str1), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s632403930x348860581_str2), heff_strAppend(v_t_247, ((V)&g_heff_2ecommands_2epublishTested_24s632403930x348860581_str3))))))));
    return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s1138740946x688035206_clo), 1, (V[]){v_t_248});
  }
  case TAG_False: {
    V v_t_249 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_r_242), LBL_testsFailed));
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_v_240);
      heff_drop(v_pk_241);
      V v_t_2410 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_failed));
      V v_t_2411 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_total));
      V v_t_2412 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_testsFailed));
      V v_t_2413 = heff_intShow(heff_get(v_r_242, LBL_tests));
      V v_t_2414 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s632403930x348860581_str4), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s632403930x348860581_str5), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s632403930x348860581_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2ecommands_2epublishTested_24s632403930x348860581_str7))))))));
      return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s1138740946x688035206_clo), 1, (V[]){v_t_2414});
    }
    case TAG_False: {
      V v_t_2415 = heff_get(heff_dup(v_r_242), LBL_ok);
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop(v_r_242);
        return heff_tail(((V)&g_heff_2ecommands_2epublishTag_24s146522991x1682623660_clo), 2, (V[]){v_v_240, v_pk_241});
      }
      case TAG_False: {
        heff_drop(v_v_240);
        heff_drop(v_pk_241);
        V v_t_2416 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_failed));
        V v_t_2417 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_total));
        V v_t_2418 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_testsFailed));
        V v_t_2419 = heff_intShow(heff_get(v_r_242, LBL_tests));
        V v_t_2420 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s632403930x348860581_str8), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s632403930x348860581_str9), heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s632403930x348860581_str10), heff_strAppend(v_t_2419, ((V)&g_heff_2ecommands_2epublishTested_24s632403930x348860581_str11))))))));
        return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s1138740946x688035206_clo), 1, (V[]){v_t_2420});
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecommands_2epublishTested_24s632403930x348860581_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishTested_24s632403930x348860581(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str0 = {{0x80000000u, K_STR, 0}, 11, 11, {45, 45, 112, 111, 114, 99, 101, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 116, 97, 116, 117, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {114, 101, 102, 115, 47, 116, 97, 103, 115, 47, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {45, 45, 118, 101, 114, 105, 102, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str7 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 101, 118, 45, 112, 97, 114, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str8 = {{0x80000000u, K_STR, 0}, 25, 25, {110, 111, 116, 32, 105, 110, 32, 97, 32, 103, 105, 116, 32, 114, 101, 112, 111, 115, 105, 116, 111, 114, 121, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[52]; } g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str10 = {{0x80000000u, K_STR, 0}, 52, 52, {119, 104, 97, 116, 32, 105, 115, 32, 112, 117, 98, 108, 105, 115, 104, 101, 100, 32, 105, 115, 32, 119, 104, 97, 116, 32, 105, 115, 32, 99, 111, 109, 109, 105, 116, 116, 101, 100, 58, 32, 99, 111, 109, 109, 105, 116, 32, 102, 105, 114, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str12 = {{0x80000000u, K_STR, 0}, 18, 18, {32, 105, 115, 32, 116, 97, 103, 103, 101, 100, 32, 97, 108, 114, 101, 97, 100, 121}};
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam0(V self, V *args); static Clo g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam0, 1, 0};
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam2(V self, V *args); static Clo g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam2, 1, 0};
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam5(V self, V *args);
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam4(V self, V *args);
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam3(V self, V *args);
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam1(V self, V *args);
Clo g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_entry, 5, 0};

V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200(V v_v_240, V v_pk_241, V v_src_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str0), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str2), v_t_245}), ((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam0_clo)});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2410}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam1, 1, 5, (V[]){v_v_240, v_hd_243, v_k_244, v_src_242, v_pk_241})});
}
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishGit_24s1205594551x1436887200(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam2(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam5(V self, V *args) {
  V v_x_2443 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_pk_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2444 = heff_tr(g_heff_2ecommands_2epublishTested_24s632403930x348860581(v_v_240, v_pk_241, v_x_2443));
  return heff_tail(v_t_2444, 2, (V[]){v_hd_243, v_k_244});
}
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2441 = heff_rec(5, shape_total__failed__ok__tests__testsFailed, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(0LL), MK_INT(0LL)});
  V v_c_2442 = ({ V a_0 = v_x_2440; V a_1 = v_t_2441; V r_ = (g_heff_2ecommands_2etestAll_24s1250025441x1950168553(a_0, a_1)); heff_drop(v_x_2440); r_; });
  return heff_tail(v_c_2442, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam5, 1, 4, (V[]){v_v_240, v_pk_241, v_hd_243, v_k_244})});
}
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  V v_src_242 = heff_env(self)[4];
  V v_pk_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = heff_intEq(heff_get(heff_dup(v_x_2412), LBL_status), MK_INT(0LL));
  V v_t_2423;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_True: {
    v_t_2423 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2423 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  switch (heff_tag_of(v_t_2423)) {
  case TAG_True: {
    heff_drop(v_x_2421);
    heff_drop(v_v_240);
    heff_drop(v_src_242);
    heff_drop(v_pk_241);
    V v_s_2424 = heff_get(v_x_2412, LBL_err);
    V v_t_2425 = (g_prelude_2eskipSpaces(heff_dup(v_s_2424), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2426 = heff_intSub(heff_strLength(heff_dup(v_s_2424)), MK_INT(1LL));
    V v_t_2427 = (g_prelude_2eskipSpaces(heff_dup(v_s_2424), v_t_2426, MK_INT(-1LL)));
    V v_t_2428 = heff_strSlice(v_s_2424, v_t_2425, heff_intAdd(v_t_2427, MK_INT(1LL)));
    return (g_heff_2ecommands_2epublishFails_24s1138740946x688035206(heff_strAppend(((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str8), v_t_2428), v_hd_243, v_k_244));
  }
  case TAG_False: {
    V v_s_2429 = heff_get(v_x_2412, LBL_out);
    V v_t_2430 = (g_prelude_2eskipSpaces(heff_dup(v_s_2429), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2431 = heff_intSub(heff_strLength(heff_dup(v_s_2429)), MK_INT(1LL));
    V v_t_2432 = (g_prelude_2eskipSpaces(heff_dup(v_s_2429), v_t_2431, MK_INT(-1LL)));
    V v_t_2433 = heff_strSlice(v_s_2429, v_t_2430, heff_intAdd(v_t_2432, MK_INT(1LL)));
    V v_x1_2434 = heff_strEq(v_t_2433, ((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str9));
    V v_t_2435;
    switch (heff_tag_of(v_x1_2434)) {
    case TAG_True: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_2434);
    }
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      heff_drop(v_x_2421);
      heff_drop(v_v_240);
      heff_drop(v_src_242);
      heff_drop(v_pk_241);
      return (g_heff_2ecommands_2epublishFails_24s1138740946x688035206(((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str10), v_hd_243, v_k_244));
    }
    case TAG_False: {
      V v_t_2436 = heff_intEq(heff_get(v_x_2421, LBL_status), MK_INT(0LL));
      switch (heff_tag_of(v_t_2436)) {
      case TAG_True: {
        heff_drop(v_src_242);
        heff_drop(v_pk_241);
        V v_t_2437 = heff_strAppend(((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str11), heff_strAppend(v_v_240, ((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str12)));
        return (g_heff_2ecommands_2epublishFails_24s1138740946x688035206(v_t_2437, v_hd_243, v_k_244));
      }
      case TAG_False: {
        V v_t_2438 = heff_tag(TAG_Cons, 2, (V[]){v_src_242, NTAG(TAG_Nil)});
        V v_c_2439 = (g_heff_2ecommands_2ehfFilesGo_24s597012047x2013333798(v_t_2438, NTAG(TAG_Nil)));
        return heff_tail(v_c_2439, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam4, 1, 4, (V[]){v_hd_243, v_v_240, v_pk_241, v_k_244})});
      }
      default: return heff_nomatch(v_t_2436);
      }
    }
    default: return heff_nomatch(v_t_2435);
    }
  }
  default: return heff_nomatch(v_t_2423);
  }
}
V g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_src_242 = heff_env(self)[3];
  V v_pk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str3), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str4), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str5), v_t_2413})});
  V v_t_2416 = heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str6), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_str7), v_t_2414}), ((V)&g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam2_clo)});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2420, heff_clo(g_heff_2ecommands_2epublishGit_24s1205594551x1436887200_lam3, 1, 6, (V[]){v_x_2412, v_hd_243, v_k_244, v_v_240, v_src_242, v_pk_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishChecked_24s261068515x607614241_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishChecked_24s261068515x607614241_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2epublishChecked_24s261068515x607614241_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
V g_heff_2ecommands_2epublishChecked_24s261068515x607614241_lam1(V self, V *args);
V g_heff_2ecommands_2epublishChecked_24s261068515x607614241_lam0(V self, V *args);
Clo g_heff_2ecommands_2epublishChecked_24s261068515x607614241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishChecked_24s261068515x607614241_entry, 3, 0};

V g_heff_2ecommands_2epublishChecked_24s261068515x607614241(V v_v_240, V v_l_241, V v_pk_242) {
top: ;
  V v_t_243 = (g_heff_2eproject_2emajorMismatch(heff_get(heff_dup(v_pk_242), LBL_module), heff_dup(v_v_240)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_st_244 = heff_get(heff_get(heff_dup(v_l_241), LBL_paths), LBL_style);
    V v_t_245 = heff_get(heff_get(heff_dup(v_l_241), LBL_paths), LBL_root);
    V v_t_246 = (g_std_2epath_2eparse(v_st_244, v_t_245));
    V v_t_247 = (g_std_2epath_2eparse(v_st_244, ((V)&g_heff_2ecommands_2epublishChecked_24s261068515x607614241_str0)));
    V v_p_248 = (g_std_2epath_2ejoin_2eonto_240(v_t_246, v_t_247));
    V v_t_249 = ({ V a_0 = heff_get(heff_dup(v_p_248), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_248), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2410 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_248), LBL_drive), heff_get(v_p_248, LBL_absolute), v_t_249});
    V v_t_2411 = ({ V a_0 = v_st_244; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); r_; });
    V v_c_2412 = heff_tr(heff_apply(((V)&g_heff_2eload_2eownDir_24s36575787x1607510651_clo), 2, (V[]){heff_get(heff_dup(v_l_241), LBL_paths), v_t_2411}));
    return heff_clo(g_heff_2ecommands_2epublishChecked_24s261068515x607614241_lam0, 2, 4, (V[]){v_c_2412, v_l_241, v_v_240, v_pk_242});
  }
  case TAG_Just: {
    V v_why_2426 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop(v_l_241);
    V v_t_2427 = heff_strAppend(heff_get(v_pk_242, LBL_module), heff_strAppend(((V)&g_heff_2ecommands_2epublishChecked_24s261068515x607614241_str2), v_why_2426));
    return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s1138740946x688035206_clo), 1, (V[]){v_t_2427});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecommands_2epublishChecked_24s261068515x607614241_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishChecked_24s261068515x607614241(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2epublishChecked_24s261068515x607614241_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_why_2416 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    heff_drop(v_l_241);
    heff_drop(v_v_240);
    heff_drop(v_pk_242);
    return (g_heff_2ecommands_2epublishFails_24s1138740946x688035206(v_why_2416, v_hd_2413, v_k_2414));
  }
  case TAG_Right: {
    heff_take_n(v_x_2415, 0ULL, 1);
    V v_st_2418 = heff_get(heff_get(heff_dup(v_l_241), LBL_paths), LBL_style);
    V v_t_2419 = heff_get(heff_get(v_l_241, LBL_paths), LBL_root);
    V v_t_2420 = (g_std_2epath_2eparse(v_st_2418, v_t_2419));
    V v_t_2421 = (g_std_2epath_2eparse(v_st_2418, ((V)&g_heff_2ecommands_2epublishChecked_24s261068515x607614241_str1)));
    V v_p_2422 = (g_std_2epath_2ejoin_2eonto_240(v_t_2420, v_t_2421));
    V v_t_2423 = ({ V a_0 = heff_get(heff_dup(v_p_2422), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2422), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2424 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_2422), LBL_drive), heff_get(v_p_2422, LBL_absolute), v_t_2423});
    V v_t_2425 = ({ V a_0 = v_st_2418; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); r_; });
    return (g_heff_2ecommands_2epublishGit_24s1205594551x1436887200(v_v_240, v_pk_242, v_t_2425, v_hd_2413, v_k_2414));
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ecommands_2epublishChecked_24s261068515x607614241_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  V v_pk_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo(g_heff_2ecommands_2epublishChecked_24s261068515x607614241_lam1, 1, 5, (V[]){v_hd_2413, v_k_2414, v_l_241, v_v_240, v_pk_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str1 = {{0x80000000u, K_STR, 0}, 22, 22, {96, 32, 105, 115, 32, 110, 111, 32, 118, 101, 114, 115, 105, 111, 110, 58, 32, 97, 46, 98, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str2 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[49]; } g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str3 = {{0x80000000u, K_STR, 0}, 49, 49, {110, 111, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 104, 101, 114, 101, 58, 32, 112, 117, 98, 108, 105, 115, 104, 32, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str4 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str6 = {{0x80000000u, K_STR, 0}, 24, 24, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 114, 101, 97, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str7 = {{0x80000000u, K_STR, 0}, 42, 42, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 105, 115, 32, 110, 111, 32, 80, 97, 99, 107, 97, 103, 101, 32, 40, 108, 105, 98, 47, 109, 97, 110, 105, 102, 101, 115, 116, 46, 104, 102, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str8 = {{0x80000000u, K_STR, 0}, 42, 42, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 105, 115, 32, 110, 111, 32, 80, 97, 99, 107, 97, 103, 101, 32, 40, 108, 105, 98, 47, 109, 97, 110, 105, 102, 101, 115, 116, 46, 104, 102, 41}};
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam1(V self, V *args); static Clo g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam1, 1, 0};
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam6(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam5(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam4(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam3(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam10(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam9(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam8(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam7(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam2(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam0(V self, V *args);
Clo g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_entry, 1, 0};

V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439(V v_v_240) {
top: ;
  V v_t_241 = (g_heff_2eproject_2eversion(heff_dup(v_v_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    V v_t_242 = heff_strAppend(((V)&g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str0), heff_strAppend(v_v_240, ((V)&g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str1)));
    return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s1138740946x688035206_clo), 1, (V[]){v_t_242});
  }
  case TAG_Just: {
    heff_take_n(v_t_241, 0ULL, 1);
    return heff_clo(g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam0, 2, 1, (V[]){v_v_240});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishCmd_24s1854035793x159922439(a[0]);
}
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam1(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = ({ V a_0 = v_x_2420; V a_1 = heff_get(heff_dup(v_x_2418), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_2420); r_; });
  V v_x_2422 = (g_prelude_2efoldl_24s1838030138x788027388(v_x_2418, v_t_2421));
  V f_ = v_k_2415;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2419 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_2419, 2, (V[]){v_hd_2414, heff_clo(g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam6, 1, 2, (V[]){v_x_2418, v_k_2415})});
}
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2417 = (g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(v_x_2416, ((V)&g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str4)));
  return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_2414), heff_clo(g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam5, 1, 2, (V[]){v_hd_2414, v_k_2415})});
}
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo(g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam4, 1, 2, (V[]){v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam10(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_x_2427 = heff_env(self)[4];
  V v_v_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_get(heff_dup(v_x_2424), LBL_package);
  switch (heff_tag_of(v_t_2429)) {
  case TAG_Nothing: {
    heff_drop(v_x_2424);
    heff_drop(v_x_2425);
    heff_drop(v_x_2427);
    heff_drop(v_v_240);
    return (g_heff_2ecommands_2epublishFails_24s1138740946x688035206(((V)&g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str6), v_hd_244, v_k_245));
  }
  case TAG_Just: {
    V v_pk_2430 = heff_field(v_t_2429, 0);
    heff_take_n(v_t_2429, 1ULL, 1);
    V v_t_2431 = heff_intLt(MK_INT(0LL), v_x_2425);
    switch (heff_tag_of(v_t_2431)) {
    case TAG_True: {
      heff_drop(v_x_2424);
      heff_drop(v_x_2427);
      heff_drop(v_v_240);
      heff_drop(v_pk_2430);
      return (g_heff_2ecommands_2epublishFails_24s1138740946x688035206(((V)&g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str7), v_hd_244, v_k_245));
    }
    case TAG_False: {
      V v_t_2432 = ({ V a_0 = v_x_2427; V r_ = (g_prelude_2eany_24s827288872x1370860167(a_0)); heff_drop(v_x_2427); r_; });
      switch (heff_tag_of(v_t_2432)) {
      case TAG_True: {
        heff_drop(v_x_2424);
        heff_drop(v_v_240);
        heff_drop(v_pk_2430);
        return (g_heff_2ecommands_2epublishFails_24s1138740946x688035206(((V)&g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str8), v_hd_244, v_k_245));
      }
      case TAG_False: {
        V v_t_2433 = heff_tr(g_heff_2ecommands_2epublishChecked_24s261068515x607614241(v_v_240, v_x_2424, v_pk_2430));
        return heff_tail(v_t_2433, 2, (V[]){v_hd_244, v_k_245});
      }
      default: return heff_nomatch(v_t_2432);
      }
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  default: return heff_nomatch(v_t_2429);
  }
}
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam9(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_v_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672(heff_dup(v_x_2427), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam10, 1, 6, (V[]){v_x_2424, v_hd_244, v_k_245, v_x_2425, v_x_2427, v_v_240})));
}
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam8(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2426 = (g_heff_2esession_2ecachedProgram_24s595918180x507103762(heff_dup(v_x_2424)));
  return heff_tail(v_c_2426, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam9, 1, 5, (V[]){v_hd_244, v_x_2424, v_k_245, v_x_2425, v_v_240})});
}
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam7(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(((V)&g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str5), heff_get(heff_dup(v_x_2424), LBL_errors), MK_INT(0LL), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam8, 1, 4, (V[]){v_x_2424, v_hd_244, v_k_245, v_v_240})));
}
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    heff_drop(v_v_240);
    return (g_heff_2ecommands_2epublishFails_24s1138740946x688035206(((V)&g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str3), v_hd_244, v_k_245));
  }
  case TAG_Just: {
    heff_take_n(v_x_2411, 0ULL, 1);
    V v_c_2413 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
    V v_c_2423 = heff_clo(g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam3, 2, 1, (V[]){v_c_2413});
    return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam7, 1, 3, (V[]){v_hd_244, v_k_245, v_v_240})});
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_str2), ((V)&g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam1_clo)})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_249}));
  V f_ = heff_get(heff_dup(v_hd_244), LBL_bind);
  args[0] = v_t_2410;
  args[1] = heff_clo(g_heff_2ecommands_2epublishCmd_24s1854035793x159922439_lam2, 1, 3, (V[]){v_hd_244, v_k_245, v_v_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2ecommands_2eversionCmd_24s622085897x237111290_str0 = {{0x80000000u, K_STR, 0}, 23, 23, {110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 116, 104, 101, 114, 101, 32, 105, 115, 32, 110, 111, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2eversionCmd_24s622085897x237111290_str1 = {{0x80000000u, K_STR, 0}, 11, 11, {110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2eversionCmd_24s622085897x237111290_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {104, 101, 102, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2eversionCmd_24s622085897x237111290_str3 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 32, 118, 101, 114, 115, 105, 111, 110, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eversionCmd_24s622085897x237111290_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eversionCmd_24s622085897x237111290_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eversionCmd_24s622085897x237111290_lam1(V self, V *args); static Clo g_heff_2ecommands_2eversionCmd_24s622085897x237111290_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eversionCmd_24s622085897x237111290_lam1, 1, 0};
V g_heff_2ecommands_2eversionCmd_24s622085897x237111290_lam3(V self, V *args);
V g_heff_2ecommands_2eversionCmd_24s622085897x237111290_lam2(V self, V *args);
V g_heff_2ecommands_2eversionCmd_24s622085897x237111290_lam0(V self, V *args);
Clo g_heff_2ecommands_2eversionCmd_24s622085897x237111290_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eversionCmd_24s622085897x237111290_entry, 2, 0};

V g_heff_2ecommands_2eversionCmd_24s622085897x237111290(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2eownPackage_24s2030161483x1635646466(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2eversionCmd_24s622085897x237111290_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecommands_2eversionCmd_24s622085897x237111290_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eversionCmd_24s622085897x237111290(a[0], a[1]);
}
V g_heff_2ecommands_2eversionCmd_24s622085897x237111290_lam1(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ecommands_2eversionCmd_24s622085897x237111290_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2423);
  V v_t_2424 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2427}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2428, v_k_241});
}
V g_heff_2ecommands_2eversionCmd_24s622085897x237111290_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_t_2415 = heff_tag(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2eversionCmd_24s622085897x237111290_str0), v_x_242)});
    break;
  }
  case TAG_Just: {
    V v_src_249 = heff_field(v_x_248, 0);
    V v_ru_24x_248_24Just = heff_take_reuse_n(v_x_248, 1ULL, 1);
    V v_x3_2410 = (g_heff_2eproject_2ereadPackage(heff_dup(v_src_249)));
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Left: {
      V v_p_2411 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      V v_t_2412 = heff_strAppend(((V)&g_heff_2ecommands_2eversionCmd_24s622085897x237111290_str1), (g_heff_2eload_2eproblemMsg(v_x_242, v_src_249, v_p_2411)));
      v_t_2415 = heff_tag_at(v_ru_24x_248_24Just, TAG_Left, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_Right: {
      V v_p_2413 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_src_249);
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ecommands_2eversionCmd_24s622085897x237111290_str2), heff_get(v_p_2413, LBL_heff));
      v_t_2415 = heff_tag_at(v_ru_24x_248_24Just, TAG_Right, 1, (V[]){v_t_2414});
      break;
    }
    default: heff_nomatch(v_x3_2410);
    }
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Left: {
    V v_why_2416 = heff_field(v_t_2415, 0);
    V v_ru_24t_2415_24Left = heff_take_reuse_n(v_t_2415, 1ULL, 1);
    V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2eversionCmd_24s622085897x237111290_str3), v_why_2416), ((V)&g_heff_2ecommands_2eversionCmd_24s622085897x237111290_str4));
    V v_t_2418 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2417, NTAG(TAG_MkUnit)});
    V v_t_2419 = heff_tag_at(v_ru_24t_2415_24Left, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2421}));
    return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2422, heff_clo(g_heff_2ecommands_2eversionCmd_24s622085897x237111290_lam3, 1, 2, (V[]){v_hd_240, v_k_241})});
  }
  case TAG_Right: {
    V v_line_2429 = heff_field(v_t_2415, 0);
    V v_ru_24t_2415_24Right = heff_take_reuse_n(v_t_2415, 1ULL, 1);
    V v_t_2430 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_line_2429, ((V)&g_heff_2ecommands_2eversionCmd_24s622085897x237111290_str5)), NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_at(v_ru_24t_2415_24Right, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2433}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2434, v_k_241});
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2ecommands_2eversionCmd_24s622085897x237111290_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){heff_dup(v_x_242), ((V)&g_heff_2ecommands_2eversionCmd_24s622085897x237111290_lam1_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2eversionCmd_24s622085897x237111290_lam2, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2ereadAll_24s31913908x765275890_str0 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 97, 110, 110, 111, 116, 32, 114, 101, 97, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadAll_24s31913908x765275890_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ereadAll_24s31913908x765275890_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadAll_24s31913908x765275890_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ereadAll_24s31913908x765275890_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ereadAll_24s31913908x765275890_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 105, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadAll_24s31913908x765275890_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadAll_24s31913908x765275890_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadAll_24s31913908x765275890_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ereadAll_24s31913908x765275890_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ereadAll_24s31913908x765275890_str10 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 105, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadAll_24s31913908x765275890_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadAll_24s31913908x765275890_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam0, 1, 0};
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam3(V self, V *args);
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam2(V self, V *args);
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam4(V self, V *args); static Clo g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam4, 1, 0};
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam7(V self, V *args);
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam6(V self, V *args);
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam5(V self, V *args);
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam1(V self, V *args);
Clo g_heff_2ecommands_2ereadAll_24s31913908x765275890_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadAll_24s31913908x765275890_entry, 4, 0};

V g_heff_2ecommands_2ereadAll_24s31913908x765275890(V v_before_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_before_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag_at(v_ru_24x2_241_24Cons, TAG_ReadFile, 2, (V[]){heff_dup(v_path_244), ((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam0_clo)})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_p_242), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(heff_dup(v_p_242), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam1, 1, 5, (V[]){v_path_244, v_p_242, v_p_243, v_before_240, v_rest_245})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ereadAll_24s31913908x765275890(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam0(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2424);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(v_p_242), LBL_malg), 1, (V[]){v_t_2422}));
  return heff_tail(heff_get(v_p_242, LBL_bind), 2, (V[]){v_t_2423, heff_clo(g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam3, 1, 1, (V[]){v_p_243})});
}
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam4(V self, V *args) {
  V v_s_2426 = args[0];
  return v_s_2426;
}
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam7(V self, V *args) {
  V v_i_2438 = args[0];
  V v_before_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2439 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){v_i_2438}));
  return ({ V a_0 = v_t_2439; V a_1 = v_before_240; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_before_240); r_; });
}
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_src_2425 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_m_2437 = (g_heff_2eload_2emoduleOf(heff_rec(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_str8), ((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_str9), ((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_str10), ((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_str11), ((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_str12), v_x_2433}), heff_dup(v_path_244)));
  V v_t_2440 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam7, 1, 1, (V[]){v_before_240}), heff_dup(g_heff_2eimport_2eimplicitModules_get())));
  V v_t_2441 = heff_rec(5, shape_module__path__source__renames__implicit, (V[]){v_m_2437, v_path_244, v_src_2425, NTAG(TAG_Nil), v_t_2440});
  V v_x_2442 = heff_tag(TAG_Cons, 2, (V[]){v_t_2441, v_x_2436});
  V f_ = v_p_243;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_before_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_src_2425 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2432 = heff_strEq(v_x_2431, ((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_str2));
  V v_x_2433;
  switch (heff_tag_of(v_t_2432)) {
  case TAG_True: {
    v_x_2433 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_2433 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_2432);
  }
  V v_t_2434 = (g_heff_2eload_2emoduleOf(heff_rec(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_str3), ((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_str4), ((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_str5), ((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_str6), ((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_str7), heff_dup(v_x_2433)}), heff_dup(v_path_244)));
  V v_c_2435 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_clo), 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_t_2434, heff_dup(v_before_240)}), v_rest_245}));
  return heff_tail(v_c_2435, 2, (V[]){v_p_242, heff_clo(g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam6, 1, 5, (V[]){v_x_2433, v_path_244, v_before_240, v_src_2425, v_p_243})});
}
V g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_before_240 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    heff_drop(v_before_240);
    heff_drop(v_rest_245);
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_str0), v_path_244), ((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_str1));
    V v_t_2413 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_p_242), LBL_malg), 1, (V[]){v_t_2416}));
    return heff_tail(heff_get(heff_dup(v_p_242), LBL_bind), 2, (V[]){v_t_2417, heff_clo(g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam2, 1, 2, (V[]){v_p_242, v_p_243})});
  }
  case TAG_Just: {
    V v_src_2425 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Just = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_t_2427 = heff_tag_at(v_ru_24x_2411_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam4_clo)})});
    V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_p_242), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2429})}));
    return heff_tail(heff_get(heff_dup(v_p_242), LBL_bind), 2, (V[]){v_t_2430, heff_clo(g_heff_2ecommands_2ereadAll_24s31913908x765275890_lam5, 1, 6, (V[]){v_path_244, v_before_240, v_rest_245, v_p_242, v_src_2425, v_p_243})});
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ecommands_2eprintDefs_24s214761775x657534145_lam0(V self, V *args); static Clo g_heff_2ecommands_2eprintDefs_24s214761775x657534145_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintDefs_24s214761775x657534145_lam0, 2, 0};
V g_heff_2ecommands_2eprintDefs_24s214761775x657534145_lam2(V self, V *args);
V g_heff_2ecommands_2eprintDefs_24s214761775x657534145_lam1(V self, V *args);
Clo g_heff_2ecommands_2eprintDefs_24s214761775x657534145_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintDefs_24s214761775x657534145_entry, 2, 0};

V g_heff_2ecommands_2eprintDefs_24s214761775x657534145(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    return ((V)&g_heff_2ecommands_2eprintDefs_24s214761775x657534145_lam0_clo);
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2edriver_2edumpLines(heff_dup(v_c_240), heff_dup(v_k_244)));
    V v_c_247 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintLines_24s1854861431x875412566_clo), 1, (V[]){v_t_246}));
    return heff_clo(g_heff_2ecommands_2eprintDefs_24s214761775x657534145_lam1, 2, 3, (V[]){v_c_247, v_c_240, heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eprintDefs_24s214761775x657534145_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprintDefs_24s214761775x657534145(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2eprintDefs_24s214761775x657534145_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eprintDefs_24s214761775x657534145_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  V v_t_2411 = ({ V a_0 = v_c_240; V a_1 = v_rest_245; V r_ = (g_heff_2ecommands_2eprintDefs_24s214761775x657534145(a_0, a_1)); heff_drop(v_rest_245); r_; });
  return heff_tail(v_t_2411, 2, (V[]){v_hd_248, v_k_249});
}
V g_heff_2ecommands_2eprintDefs_24s214761775x657534145_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo(g_heff_2ecommands_2eprintDefs_24s214761775x657534145_lam2, 1, 4, (V[]){v_c_240, v_rest_245, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2eprintAll_24s1507602401x266242271_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {101, 114, 114, 111, 114, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eprintAll_24s1507602401x266242271_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {93, 58, 32}};
V g_heff_2ecommands_2eprintAll_24s1507602401x266242271_lam0(V self, V *args);
V g_heff_2ecommands_2eprintAll_24s1507602401x266242271_lam3(V self, V *args);
V g_heff_2ecommands_2eprintAll_24s1507602401x266242271_lam2(V self, V *args);
V g_heff_2ecommands_2eprintAll_24s1507602401x266242271_lam1(V self, V *args);
Clo g_heff_2ecommands_2eprintAll_24s1507602401x266242271_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintAll_24s1507602401x266242271_entry, 2, 0};

V g_heff_2ecommands_2eprintAll_24s1507602401x266242271(V v_x1_240, V v_bad_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_clo(g_heff_2ecommands_2eprintAll_24s1507602401x266242271_lam0, 2, 1, (V[]){v_bad_241});
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_t_246 = (g_prelude_2emap_24s2025198057x415178258(heff_get(heff_dup(v_c_244), LBL_own)));
    V v_c_247 = ({ V a_0 = heff_dup(v_c_244); V a_1 = v_t_246; V r_ = (g_heff_2ecommands_2eprintDefs_24s214761775x657534145(a_0, a_1)); heff_drop(v_t_246); r_; });
    return heff_clo(g_heff_2ecommands_2eprintAll_24s1507602401x266242271_lam1, 2, 4, (V[]){v_c_247, heff_dup(v_c_244), heff_dup(v_rest_245), v_bad_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprintAll_24s1507602401x266242271_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprintAll_24s1507602401x266242271(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eprintAll_24s1507602401x266242271_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_bad_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_bad_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eprintAll_24s1507602401x266242271_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = ({ V a_0 = v_rest_245; V a_1 = heff_intAdd(v_bad_241, v_x_2413); V r_ = (g_heff_2ecommands_2eprintAll_24s1507602401x266242271(a_0, a_1)); heff_drop(v_rest_245); r_; });
  return heff_tail(v_t_2414, 2, (V[]){v_hd_248, v_k_249});
}
V g_heff_2ecommands_2eprintAll_24s1507602401x266242271_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = (g_prelude_2emap_24s752906154x1709852375(((V)&g_heff_2ecommands_2eprintAll_24s1507602401x266242271_str0), ((V)&g_heff_2ecommands_2eprintAll_24s1507602401x266242271_str1), heff_get(heff_dup(v_c_244), LBL_diags)));
  V v_c_2412 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703_clo), 3, (V[]){heff_get(v_c_244, LBL_module), v_t_2411, MK_INT(0LL)}));
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_248), heff_clo(g_heff_2ecommands_2eprintAll_24s1507602401x266242271_lam3, 1, 4, (V[]){v_rest_245, v_bad_241, v_hd_248, v_k_249})});
}
V g_heff_2ecommands_2eprintAll_24s1507602401x266242271_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo(g_heff_2ecommands_2eprintAll_24s1507602401x266242271_lam2, 1, 5, (V[]){v_c_244, v_hd_248, v_rest_245, v_bad_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_lam1(V self, V *args);
V g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_lam0(V self, V *args);
Clo g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_entry, 3, 0};

V g_heff_2ecommands_2eselfcheck_24s1104448856x189651634(V v_paths_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecommands_2ereadAll_24s31913908x765275890(NTAG(TAG_Nil), v_paths_240, heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_lam0, 1, 2, (V[]){v_hd_241, v_k_242})));
}
V g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eselfcheck_24s1104448856x189651634(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_intEq(v_x_246, MK_INT(0LL));
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_248 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2411}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2412, v_k_242});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = (g_prelude_2efoldl_24s1053087238x1725706605(NTAG(TAG_Nil), v_x_243));
  V v_c_245 = ({ V a_0 = v_t_244; V a_1 = MK_INT(0LL); V r_ = (g_heff_2ecommands_2eprintAll_24s1507602401x266242271(a_0, a_1)); heff_drop(v_t_244); r_; });
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eselfcheck_24s1104448856x189651634_lam1, 1, 2, (V[]){v_k_242, v_hd_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eprintEvals_24s200975221x1971863026_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintEvals_24s200975221x1971863026_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintEvals_24s200975221x1971863026_lam0(V self, V *args);
Clo g_heff_2ecommands_2eprintEvals_24s200975221x1971863026_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintEvals_24s200975221x1971863026_entry, 3, 0};

V g_heff_2ecommands_2eprintEvals_24s200975221x1971863026(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_get(heff_dup(v_d_243), LBL_name), heff_strAppend(((V)&g_heff_2ecommands_2eprintEvals_24s200975221x1971863026_str0), heff_get(v_d_243, LBL_value)));
    V v_t_246 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ecommands_2eprintEvals_24s200975221x1971863026_str1)), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2ecommands_2eprintEvals_24s200975221x1971863026_lam0, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprintEvals_24s200975221x1971863026_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eprintEvals_24s200975221x1971863026(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eprintEvals_24s200975221x1971863026_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2411);
  return (g_heff_2ecommands_2eprintEvals_24s200975221x1971863026(v_rest_244, v_p_241, v_p_242));
}
V g_heff_2ecommands_2eevalDiags_24s622182990x1910901847_lam1(V self, V *args);
V g_heff_2ecommands_2eevalDiags_24s622182990x1910901847_lam0(V self, V *args);
Clo g_heff_2ecommands_2eevalDiags_24s622182990x1910901847_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eevalDiags_24s622182990x1910901847_entry, 4, 0};

V g_heff_2ecommands_2eevalDiags_24s622182990x1910901847(V v_badL_240, V v_cs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecommands_2eputFileDiags_24s1991821944x198252672(heff_dup(v_cs_241), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2eevalDiags_24s622182990x1910901847_lam0, 1, 4, (V[]){v_cs_241, v_hd_242, v_k_243, heff_dup(v_badL_240)})));
}
V g_heff_2ecommands_2eevalDiags_24s622182990x1910901847_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eevalDiags_24s622182990x1910901847(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eevalDiags_24s622182990x1910901847_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_badL_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2414);
  switch (heff_tag_of(v_badL_240)) {
  case TAG_True: {
    heff_drop(v_cs_241);
    V v_t_2415 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2418}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2419, v_k_243});
  }
  case TAG_False: {
    V v_t_2420 = ({ V a_0 = v_cs_241; V r_ = (g_prelude_2eany_24s827288872x1370860167(a_0)); heff_drop(v_cs_241); r_; });
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      V v_t_2421 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2424}));
      return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2425, v_k_243});
    }
    case TAG_False: {
      heff_drop(v_hd_242);
      V f_ = v_k_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  default: return heff_nomatch(v_badL_240);
  }
}
V g_heff_2ecommands_2eevalDiags_24s622182990x1910901847_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_badL_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_244);
  V v_t_245 = (g_heff_2edriver_2elastChecked(v_cs_241));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_cs_241);
    heff_drop(v_badL_240);
    V v_t_246 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2410, v_k_243});
  }
  case TAG_Just: {
    V v_c_2411 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_2412 = (g_heff_2edriver_2eevaluate(v_c_2411));
    V v_c_2413 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintEvals_24s200975221x1971863026_clo), 1, (V[]){v_t_2412}));
    return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2eevalDiags_24s622182990x1910901847_lam1, 1, 4, (V[]){v_badL_240, v_hd_242, v_k_243, v_cs_241})});
  }
  default: return heff_nomatch(v_t_245);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam3(V self, V *args);
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam2(V self, V *args);
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam1(V self, V *args);
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam0(V self, V *args);
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam7(V self, V *args);
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam6(V self, V *args);
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam5(V self, V *args);
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam4(V self, V *args);
Clo g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_entry, 1, 0};

V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915(V v_file_240) {
top: ;
  V v_c_241 = ((V)&g_heff_2ecommands_2ehostNow_24s95879950x2015218488_clo);
  V v_c_2411 = heff_clo(g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam0, 2, 2, (V[]){v_c_241, v_file_240});
  return heff_clo(g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam4, 2, 1, (V[]){v_c_2411});
}
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eevalCmd_24s365229053x1921966915(a[0]);
}
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = ({ V a_0 = v_x_248; V a_1 = heff_get(heff_dup(v_x_246), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_248); r_; });
  V v_x_2410 = (g_prelude_2efoldl_24s1838030138x788027388(v_x_246, v_t_249));
  V f_ = v_k_243;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_247 = ((V)&g_heff_2ecommands_2eownVersion_24s1137751716x1393321329_clo);
  return heff_tail(v_c_247, 2, (V[]){v_hd_242, heff_clo(g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam3, 1, 2, (V[]){v_x_246, v_k_243})});
}
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2eload_2eloadProgramWith_24s1589620423x205198563(v_x_244, v_file_240));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam2, 1, 2, (V[]){v_hd_242, v_k_243})});
}
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo(g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam1, 1, 3, (V[]){v_file_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam7(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V b_0 = heff_intLt(MK_INT(0LL), v_x_2415); V a_1 = v_x_2417; V a_2 = v_hd_2412; V a_3 = v_k_2413; V r_ = (g_heff_2ecommands_2eevalDiags_24s622182990x1910901847(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam6(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2416 = (g_heff_2esession_2ecachedProgram_24s595918180x507103762(v_x_2414));
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_2412), heff_clo(g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam7, 1, 3, (V[]){v_x_2415, v_hd_2412, v_k_2413})});
}
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecommands_2eprintErrs_24s1770014196x1667468703(((V)&g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_str0), heff_get(heff_dup(v_x_2414), LBL_errors), MK_INT(0LL), heff_dup(v_hd_2412), heff_clo(g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam6, 1, 3, (V[]){v_x_2414, v_hd_2412, v_k_2413})));
}
V g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam4(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo(g_heff_2ecommands_2eevalCmd_24s365229053x1921966915_lam5, 1, 2, (V[]){v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}