// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eownRoot_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eownRoot_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {111, 117, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eownRoot_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2eownRoot_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
Clo g_heff_2ecommands_2eownRoot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eownRoot_entry, 2, 0};

V g_heff_2ecommands_2eownRoot(V v_st_240, V v_self_241) {
top: ;
  V v_p_242 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_self_241)));
  V v_t_243 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_242), LBL_segments)));
  V v_xs_244 = (g_prelude_2edrop(MK_INT(1LL), v_t_243));
  V v_t_245 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_244));
  V v_t_246 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_242), LBL_drive), heff_get(v_p_242, LBL_absolute), v_t_245});
  V v_s_247 = (g_std_2epath_2erender(v_st_240, v_t_246));
  V v_t_248 = (g_std_2epath_2eparse(v_st_240, v_s_247));
  V v_xs_249 = heff_get(v_t_248, LBL_segments);
  V v_x1_2410 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_249));
  V v_x2_2413;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nil: {
    v_x2_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 2);
    v_x2_2413 = heff_tag(TAG_Just, 1, (V[]){v_x_2411});
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  V v_t_2415;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nothing: {
    v_t_2415 = ((V)&g_heff_2ecommands_2eownRoot_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    heff_take_n(v_x2_2413, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  V v_t_2416 = heff_strEq(v_t_2415, ((V)&g_heff_2ecommands_2eownRoot_str1));
  V v_t_2437;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    V v_p_2417 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_self_241)));
    V v_t_2418 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2417), LBL_segments)));
    V v_xs_2419 = (g_prelude_2edrop(MK_INT(1LL), v_t_2418));
    V v_t_2420 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2419));
    V v_t_2421 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2417), LBL_drive), heff_get(v_p_2417, LBL_absolute), v_t_2420});
    V v_s_2422 = (g_std_2epath_2erender(v_st_240, v_t_2421));
    V v_p_2423 = (g_std_2epath_2eparse(v_st_240, v_s_2422));
    V v_t_2424 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2423), LBL_segments)));
    V v_xs_2425 = (g_prelude_2edrop(MK_INT(1LL), v_t_2424));
    V v_t_2426 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2425));
    V v_t_2427 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2423), LBL_drive), heff_get(v_p_2423, LBL_absolute), v_t_2426});
    V v_s_2428 = (g_std_2epath_2erender(v_st_240, v_t_2427));
    V v_t_2429 = (g_std_2epath_2eparse(v_st_240, v_s_2428));
    V v_xs_2430 = heff_get(v_t_2429, LBL_segments);
    V v_x1_2431 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2430));
    V v_x2_2434;
    switch (heff_tag_of(v_x1_2431)) {
    case TAG_Nil: {
      v_x2_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2432 = heff_field(v_x1_2431, 0);
      heff_take_n(v_x1_2431, 1ULL, 2);
      v_x2_2434 = heff_tag(TAG_Just, 1, (V[]){v_x_2432});
      break;
    }
    default: heff_nomatch(v_x1_2431);
    }
    V v_t_2436;
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_Nothing: {
      v_t_2436 = ((V)&g_heff_2ecommands_2eownRoot_str2);
      break;
    }
    case TAG_Just: {
      V v_x_2435 = heff_field(v_x2_2434, 0);
      heff_take_n(v_x2_2434, 1ULL, 1);
      v_t_2436 = v_x_2435;
      break;
    }
    default: heff_nomatch(v_x2_2434);
    }
    v_t_2437 = heff_strEq(v_t_2436, ((V)&g_heff_2ecommands_2eownRoot_str3));
    break;
  }
  case TAG_False: {
    v_t_2437 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  switch (heff_tag_of(v_t_2437)) {
  case TAG_True: {
    V v_p_2438 = (g_std_2epath_2eparse(v_st_240, v_self_241));
    V v_t_2439 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2438), LBL_segments)));
    V v_xs_2440 = (g_prelude_2edrop(MK_INT(1LL), v_t_2439));
    V v_t_2441 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2440));
    V v_t_2442 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2438), LBL_drive), heff_get(v_p_2438, LBL_absolute), v_t_2441});
    V v_s_2443 = (g_std_2epath_2erender(v_st_240, v_t_2442));
    V v_p_2444 = (g_std_2epath_2eparse(v_st_240, v_s_2443));
    V v_t_2445 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2444), LBL_segments)));
    V v_xs_2446 = (g_prelude_2edrop(MK_INT(1LL), v_t_2445));
    V v_t_2447 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2446));
    V v_t_2448 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2444), LBL_drive), heff_get(v_p_2444, LBL_absolute), v_t_2447});
    V v_s_2449 = (g_std_2epath_2erender(v_st_240, v_t_2448));
    V v_p_2450 = (g_std_2epath_2eparse(v_st_240, v_s_2449));
    V v_t_2451 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2450), LBL_segments)));
    V v_xs_2452 = (g_prelude_2edrop(MK_INT(1LL), v_t_2451));
    V v_t_2453 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2452));
    V v_t_2454 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2450), LBL_drive), heff_get(v_p_2450, LBL_absolute), v_t_2453});
    HEFF_LAST return g_std_2epath_2erender(v_st_240, v_t_2454);
  }
  case TAG_False: {
    V v_p_2455 = (g_std_2epath_2eparse(v_st_240, v_self_241));
    V v_t_2456 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2455), LBL_segments)));
    V v_xs_2457 = (g_prelude_2edrop(MK_INT(1LL), v_t_2456));
    V v_t_2458 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2457));
    V v_t_2459 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2455), LBL_drive), heff_get(v_p_2455, LBL_absolute), v_t_2458});
    V v_s_2460 = (g_std_2epath_2erender(v_st_240, v_t_2459));
    V v_p_2461 = (g_std_2epath_2eparse(v_st_240, v_s_2460));
    V v_t_2462 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2461), LBL_segments)));
    V v_xs_2463 = (g_prelude_2edrop(MK_INT(1LL), v_t_2462));
    V v_t_2464 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2463));
    V v_t_2465 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2461), LBL_drive), heff_get(v_p_2461, LBL_absolute), v_t_2464});
    HEFF_LAST return g_std_2epath_2erender(v_st_240, v_t_2465);
  }
  default: return heff_nomatch(v_t_2437);
  }
}
V g_heff_2ecommands_2eownRoot_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eownRoot(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2eheffVersions_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {48, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2eheffVersions_str1 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 40, 116, 104, 101, 32, 115, 97, 109, 101, 32, 48, 46, 120, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eheffVersions_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2eheffVersions_str3 = {{0x80000000u, K_STR, 0}, 13, 13, {32, 105, 115, 32, 102, 111, 114, 32, 104, 101, 102, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2ecommands_2eheffVersions_str4 = {{0x80000000u, K_STR, 0}, 19, 19, {44, 32, 97, 110, 100, 32, 116, 104, 105, 115, 32, 104, 101, 102, 102, 32, 105, 115, 32}};
Clo g_heff_2ecommands_2eheffVersions_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffVersions_entry, 5, 0};

V g_heff_2ecommands_2eheffVersions(V v_who_240, V v_wanted_241, V v_running_242, V v_x4_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_who_240);
    heff_drop(v_wanted_241);
    heff_drop(v_running_242);
    heff_drop(v_x5_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_w_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nothing: {
      heff_drop(v_who_240);
      heff_drop(v_wanted_241);
      heff_drop(v_running_242);
      heff_drop(v_w_245);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_r_246 = heff_field(v_x5_244, 0);
      heff_take_n(v_x5_244, 1ULL, 1);
      V v_t_247 = ({ V a_0 = v_w_245; V a_1 = v_r_246; V r_ = (g_heff_2eproject_2ecompatible(a_0, a_1)); heff_drop(v_w_245); heff_drop(v_r_246); r_; });
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_who_240);
        heff_drop(v_wanted_241);
        heff_drop(v_running_242);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V v_t_248 = heff_strEq(heff_strSlice(heff_dup(v_wanted_241), MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2ecommands_2eheffVersions_str0));
        V v_t_249;
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          v_t_249 = ((V)&g_heff_2ecommands_2eheffVersions_str1);
          break;
        }
        case TAG_False: {
          v_t_249 = ((V)&g_heff_2ecommands_2eheffVersions_str2);
          break;
        }
        default: heff_nomatch(v_t_248);
        }
        V v_t_2410 = heff_strAppend(v_who_240, heff_strAppend(((V)&g_heff_2ecommands_2eheffVersions_str3), heff_strAppend(v_wanted_241, heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecommands_2eheffVersions_str4), v_running_242)))));
        return heff_tag_at(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){v_t_2410});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecommands_2eheffVersions_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eheffVersions(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eheffErrors_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eheffErrors_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2ecommands_2eheffErrors_str2 = {{0x80000000u, K_STR, 0}, 23, 23, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 58, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2eheffErrors_str3 = {{0x80000000u, K_STR, 0}, 12, 12, {116, 104, 101, 32, 112, 97, 99, 107, 97, 103, 101, 32}};
V g_heff_2ecommands_2eheffErrors_lam0(V self, V *args);
Clo g_heff_2ecommands_2eheffErrors_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffErrors_entry, 2, 0};

V g_heff_2ecommands_2eheffErrors(V v_running_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_project_242 = heff_field(v_x2_241, 0);
    V v_deps_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strEq(heff_get(heff_dup(v_project_242), LBL_heff), ((V)&g_heff_2ecommands_2eheffErrors_str0));
    V v_xs_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_project_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      v_xs_245 = v_deps_243;
      break;
    }
    case TAG_False: {
      v_xs_245 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_project_242, v_deps_243});
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_t_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_245));
    return ({ V a_0 = heff_clo(g_heff_2ecommands_2eheffErrors_lam0, 2, 1, (V[]){heff_dup(v_running_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eheffErrors_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eheffErrors(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eheffErrors_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_running_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_strEq(heff_get(heff_dup(v_x_248), LBL_own), ((V)&g_heff_2ecommands_2eheffErrors_str1));
  V v_who_2410;
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    v_who_2410 = ((V)&g_heff_2ecommands_2eheffErrors_str2);
    break;
  }
  case TAG_False: {
    v_who_2410 = heff_strAppend(((V)&g_heff_2ecommands_2eheffErrors_str3), heff_get(heff_dup(v_x_248), LBL_path));
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_wanted_2411 = heff_get(v_x_248, LBL_heff);
  V v_t_2417;
  switch (heff_tag_of(v_running_240)) {
  case TAG_Nothing: {
    heff_drop(v_who_2410);
    heff_drop(v_wanted_2411);
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_running_2412 = heff_field(v_running_240, 0);
    heff_take_n(v_running_240, 1ULL, 1);
    V v_t_2413 = (g_heff_2eproject_2eversion(heff_dup(v_wanted_2411)));
    V v_t_2414 = (g_heff_2eproject_2eversion(heff_dup(v_running_2412)));
    V v_t_2415 = (g_heff_2ecommands_2eheffVersions(v_who_2410, v_wanted_2411, v_running_2412, v_t_2413, v_t_2414));
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_why_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){v_why_2416, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    break;
  }
  default: heff_nomatch(v_running_240);
  }
  return (g_prelude_2econcatList(v_t_2417, v_acc_247));
}
Clo g_heff_2ecommands_2eelemStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eelemStrM_entry, 2, 0};

V g_heff_2ecommands_2eelemStrM(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_strEq(heff_dup(v_x_240), heff_dup(v_y_242));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eelemStrM_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eelemStrM(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecommands_2enubStrGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enubStrGo_entry, 2, 0};

V g_heff_2ecommands_2enubStrGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecommands_2eelemStrM(heff_dup(v_x_242), v_seen_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), (g_heff_2ecommands_2enubStrGo(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_rest_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2enubStrGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2enubStrGo(a[0], a[1]);
}
Clo g_heff_2ecommands_2epathOfModule_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epathOfModule_entry, 2, 0};

V g_heff_2ecommands_2epathOfModule(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_m_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_strEq(heff_get(heff_dup(v_s_242), LBL_module), heff_dup(v_m_241));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_m_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_get(heff_dup(v_s_242), LBL_path)});
    }
    case TAG_False: {
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2epathOfModule_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2epathOfModule(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeaf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeaf_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeaf_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeaf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2ecommands_2eprovidesLeaf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprovidesLeaf_entry, 2, 0};

V g_heff_2ecommands_2eprovidesLeaf(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeaf_str0), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x2_245 = (g_heff_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ecommands_2eprovidesLeaf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = v_x_246; V a_1 = v_xs_247; V r_ = (g_prelude_2efoldl_24s13(a_0, a_1)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_strEq(heff_get(heff_dup(v_p_242), LBL_module), v_t_248);
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V v_t_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeaf_str2), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeaf_str3), heff_get(heff_dup(v_p_242), LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2413 = (g_prelude_2emap_24s609(v_t_2412));
      V v_t_2414 = (g_heff_2eemit_2ecatMaybesL(v_t_2413));
      V v_t_2415 = (g_prelude_2efilter_24s608(v_t_2414));
      V v_t_2416 = ({ V a_0 = v_t_2411; V a_1 = v_t_2415; V r_ = (g_heff_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2415); r_; });
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        heff_drop(v_k_241);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    case TAG_False: {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprovidesLeaf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprovidesLeaf(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2erunDir_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {46, 104, 101, 102, 102, 47, 114, 117, 110}};
Clo g_heff_2ecommands_2erunDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erunDir_entry, 1, 0};

V g_heff_2ecommands_2erunDir(V v_paths_240) {
top: ;
  V v_st_241 = heff_get(heff_dup(v_paths_240), LBL_style);
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_get(v_paths_240, LBL_root)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ecommands_2erunDir_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = ({ V a_0 = heff_get(heff_dup(v_p_244), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_244), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_246 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_244), LBL_drive), heff_get(v_p_244, LBL_absolute), v_t_245});
  return ({ V a_0 = v_st_241; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); r_; });
}
V g_heff_2ecommands_2erunDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2erunDir(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2erunPath_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunPath_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 109, 106, 115}};
Clo g_heff_2ecommands_2erunPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erunPath_entry, 2, 0};

V g_heff_2ecommands_2erunPath(V v_paths_240, V v_file_241) {
top: ;
  V v_t_242 = (g_heff_2ecommands_2erunDir(heff_dup(v_paths_240)));
  V v_p_243 = ({ V b_0 = heff_get(heff_dup(v_paths_240), LBL_style); V a_1 = v_file_241; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_244 = ({ V a_0 = heff_get(heff_dup(v_p_243), LBL_absolute); V b_1 = heff_get(v_p_243, LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecommands_2erunPath_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = v_x_245; V a_1 = v_xs_246; V r_ = (g_prelude_2efoldl_24s89(a_0, a_1)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  return (g_heff_2eload_2eunder(v_paths_240, v_t_242, heff_strAppend(v_t_247, ((V)&g_heff_2ecommands_2erunPath_str1))));
}
V g_heff_2ecommands_2erunPath_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2erunPath(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeafC_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeafC_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeafC_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeafC_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2ecommands_2eprovidesLeafC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprovidesLeafC_entry, 2, 0};

V g_heff_2ecommands_2eprovidesLeafC(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeafC_str0), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x2_245 = (g_heff_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ecommands_2eprovidesLeafC_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = v_x_246; V a_1 = v_xs_247; V r_ = (g_prelude_2efoldl_24s13(a_0, a_1)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_strEq(heff_get(heff_dup(v_p_242), LBL_module), v_t_248);
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V v_t_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeafC_str2), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeafC_str3), heff_get(heff_dup(v_p_242), LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2413 = (g_prelude_2emap_24s677(v_t_2412));
      V v_t_2414 = (g_heff_2eemitc_2ecatMaybesC(v_t_2413));
      V v_t_2415 = ({ V a_0 = v_t_2411; V a_1 = v_t_2414; V r_ = (g_heff_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2414); r_; });
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop(v_k_241);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    case TAG_False: {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprovidesLeafC_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprovidesLeafC(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildTarget_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildTarget_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildTarget_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 114, 111, 116, 101}};
Clo g_heff_2ecommands_2ebuildTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildTarget_entry, 2, 0};

V g_heff_2ecommands_2ebuildTarget(V v_st_240, V v_root_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildTarget_str0)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildTarget_str1)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = ({ V a_0 = heff_get(heff_dup(v_p_244), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_244), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_246 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_244), LBL_drive), heff_get(v_p_244, LBL_absolute), v_t_245});
  V v_b_247 = (g_std_2epath_2erender(v_st_240, v_t_246));
  V v_t_248 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_root_241)));
  V v_t_249 = (g_std_2epath_2eparse(v_st_240, v_b_247));
  V v_p_2410 = (g_std_2epath_2ejoin_2eonto_240(v_t_248, v_t_249));
  V v_t_2411 = ({ V a_0 = heff_get(heff_dup(v_p_2410), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2410), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2412 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2410), LBL_drive), heff_get(v_p_2410, LBL_absolute), v_t_2411});
  V v_t_2413 = (g_std_2epath_2erender(v_st_240, v_t_2412));
  return heff_rec(5, shape_283_22_287_231_301, (V[]){v_root_241, v_t_2413, ((V)&g_heff_2ecommands_2ebuildTarget_str2), NTAG(TAG_True), NTAG(TAG_Nothing)});
}
V g_heff_2ecommands_2ebuildTarget_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ebuildTarget(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eappFile_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
Clo g_heff_2ecommands_2eappFile_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eappFile_entry, 4, 0};

V g_heff_2ecommands_2eappFile(V v_st_240, V v_t_241, V v_x_242, V v_f_243) {
top: ;
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2eappFile_str0)));
  V v_t_245 = (g_std_2epath_2eparse(v_st_240, v_x_242));
  V v_p_246 = (g_std_2epath_2ejoin_2eonto_240(v_t_244, v_t_245));
  V v_t_247 = ({ V a_0 = heff_get(heff_dup(v_p_246), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_246), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_248 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_246), LBL_drive), heff_get(v_p_246, LBL_absolute), v_t_247});
  V v_a_249 = (g_std_2epath_2erender(v_st_240, v_t_248));
  V v_t_2410 = (g_std_2epath_2eparse(v_st_240, v_a_249));
  V v_t_2411 = (g_std_2epath_2eparse(v_st_240, v_f_243));
  V v_p_2412 = (g_std_2epath_2ejoin_2eonto_240(v_t_2410, v_t_2411));
  V v_t_2413 = ({ V a_0 = heff_get(heff_dup(v_p_2412), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2412), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2414 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2412), LBL_drive), heff_get(v_p_2412, LBL_absolute), v_t_2413});
  V v_p_2415 = (g_std_2epath_2erender(v_st_240, v_t_2414));
  V v_t_2416 = (g_std_2epath_2eparse(v_st_240, heff_get(v_t_241, LBL_root)));
  V v_t_2417 = (g_std_2epath_2eparse(v_st_240, v_p_2415));
  V v_p_2418 = (g_std_2epath_2ejoin_2eonto_240(v_t_2416, v_t_2417));
  V v_t_2419 = ({ V a_0 = heff_get(heff_dup(v_p_2418), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2418), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2420 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2418), LBL_drive), heff_get(v_p_2418, LBL_absolute), v_t_2419});
  return (g_std_2epath_2erender(v_st_240, v_t_2420));
}
V g_heff_2ecommands_2eappFile_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eappFile(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2epartsDir_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2epartsDir_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
Clo g_heff_2ecommands_2epartsDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epartsDir_entry, 3, 0};

V g_heff_2ecommands_2epartsDir(V v_st_240, V v_t_241, V v_x_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2epartsDir_str0)));
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2epartsDir_str1)));
  V v_p_245 = (g_std_2epath_2ejoin_2eonto_240(v_t_243, v_t_244));
  V v_t_246 = ({ V a_0 = heff_get(heff_dup(v_p_245), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_245), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_245), LBL_drive), heff_get(v_p_245, LBL_absolute), v_t_246});
  V v_a_248 = (g_std_2epath_2erender(v_st_240, v_t_247));
  V v_t_249 = (g_std_2epath_2eparse(v_st_240, v_a_248));
  V v_t_2410 = (g_std_2epath_2eparse(v_st_240, v_x_242));
  V v_p_2411 = (g_std_2epath_2ejoin_2eonto_240(v_t_249, v_t_2410));
  V v_t_2412 = ({ V a_0 = heff_get(heff_dup(v_p_2411), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2411), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2413 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2411), LBL_drive), heff_get(v_p_2411, LBL_absolute), v_t_2412});
  V v_p_2414 = (g_std_2epath_2erender(v_st_240, v_t_2413));
  V v_t_2415 = (g_std_2epath_2eparse(v_st_240, heff_get(v_t_241, LBL_root)));
  V v_t_2416 = (g_std_2epath_2eparse(v_st_240, v_p_2414));
  V v_p_2417 = (g_std_2epath_2ejoin_2eonto_240(v_t_2415, v_t_2416));
  V v_t_2418 = ({ V a_0 = heff_get(heff_dup(v_p_2417), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2417), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2419 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2417), LBL_drive), heff_get(v_p_2417, LBL_absolute), v_t_2418});
  return (g_std_2epath_2erender(v_st_240, v_t_2419));
}
V g_heff_2ecommands_2epartsDir_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2epartsDir(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efailLine_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efailLine_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efailLine_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efailLine_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 65, 73, 76, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efailLine_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2efailLine_str5 = {{0x80000000u, K_STR, 0}, 12, 12, {10, 32, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2efailLine_str6 = {{0x80000000u, K_STR, 0}, 12, 12, {10, 32, 32, 98, 117, 116, 32, 103, 111, 116, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2efailLine_str7 = {{0x80000000u, K_STR, 0}, 12, 12, {10, 32, 32, 100, 105, 102, 102, 32, 32, 32, 32, 32}};
Clo g_heff_2ecommands_2efailLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efailLine_entry, 3, 0};

V g_heff_2ecommands_2efailLine(V v_f_240, V v_r_241, V v_m_242) {
top: ;
  V v_t_243 = heff_get(heff_dup(v_r_241), LBL_owner);
  V v_t_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_heff_2ecommands_2efailLine_str0);
    break;
  }
  case TAG_Just: {
    V v_n_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    v_t_245 = heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str1), heff_strAppend(v_n_244, ((V)&g_heff_2ecommands_2efailLine_str2)));
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_246 = heff_get(heff_get(v_r_241, LBL_watch), LBL_expr);
  return heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str3), heff_strAppend(v_f_240, heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str4), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str5), heff_strAppend(heff_get(heff_dup(v_m_242), LBL_expected), heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str6), heff_strAppend(heff_get(heff_dup(v_m_242), LBL_got), heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str7), heff_get(v_m_242, LBL_diff)))))))))));
}
V g_heff_2ecommands_2efailLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2efailLine(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2estatistic_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2estatistic_str1 = {{0x80000000u, K_STR, 0}, 12, 12, {32, 103, 105, 118, 101, 110, 32, 117, 112, 32, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2estatistic_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2estatistic_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {37}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2estatistic_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2estatistic_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2estatistic_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2estatistic_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 114, 117, 110, 115}};
V g_heff_2ecommands_2estatistic_lam0(V self, V *args);
Clo g_heff_2ecommands_2estatistic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2estatistic_entry, 1, 0};

V g_heff_2ecommands_2estatistic(V v_o_240) {
top: ;
  V v_t_241 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_runs));
  V v_t_242 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_o_240), LBL_discarded));
  V v_t_244;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_discarded));
    v_t_244 = heff_strAppend(((V)&g_heff_2ecommands_2estatistic_str0), heff_strAppend(v_t_243, ((V)&g_heff_2ecommands_2estatistic_str1)));
    break;
  }
  case TAG_False: {
    v_t_244 = ((V)&g_heff_2ecommands_2estatistic_str2);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_x2_2416 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2estatistic_lam0, 1, 1, (V[]){heff_dup(v_o_240)}), heff_get(v_o_240, LBL_labels)));
  V v_t_2419;
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nil: {
    v_t_2419 = ((V)&g_heff_2ecommands_2estatistic_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_xs_2418 = heff_field(v_x2_2416, 1);
    heff_take_n(v_x2_2416, 3ULL, 2);
    v_t_2419 = ({ V a_0 = v_x_2417; V a_1 = v_xs_2418; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2418); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2416);
  }
  return heff_strAppend(v_t_241, heff_strAppend(((V)&g_heff_2ecommands_2estatistic_str7), heff_strAppend(v_t_244, v_t_2419)));
}
V g_heff_2ecommands_2estatistic_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2estatistic(a[0]);
}
V g_heff_2ecommands_2estatistic_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_o_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_n_248;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_y_247 = heff_dup(heff_field(v_p_245, 1));
    v_n_248 = v_y_247;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_total_249 = heff_get(v_o_240, LBL_runs);
  V v_t_2410 = heff_intEq(heff_dup(v_total_249), MK_INT(0LL));
  V v_t_2411;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_n_248);
    heff_drop(v_total_249);
    v_t_2411 = MK_INT(0LL);
    break;
  }
  case TAG_False: {
    v_t_2411 = heff_intDiv(heff_intMul(v_n_248, MK_INT(100LL)), v_total_249);
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_t_2412 = heff_strAppend(heff_intShow(v_t_2411), ((V)&g_heff_2ecommands_2estatistic_str3));
  V v_t_2415;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_p_245, 0);
    heff_take_n(v_p_245, 1ULL, 2);
    v_t_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  return heff_strAppend(((V)&g_heff_2ecommands_2estatistic_str4), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ecommands_2estatistic_str5), v_t_2415)));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eoutcomeLine_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 111, 107, 32, 32, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eoutcomeLine_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eoutcomeLine_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eoutcomeLine_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eoutcomeLine_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2eoutcomeLine_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2eoutcomeLine_str6 = {{0x80000000u, K_STR, 0}, 12, 12, {32, 103, 105, 118, 101, 110, 32, 117, 112, 32, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eoutcomeLine_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eoutcomeLine_str8 = {{0x80000000u, K_STR, 0}, 10, 10, {110, 111, 116, 32, 115, 104, 114, 117, 110, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2eoutcomeLine_str9 = {{0x80000000u, K_STR, 0}, 11, 11, {115, 104, 114, 117, 110, 107, 32, 111, 110, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2eoutcomeLine_str10 = {{0x80000000u, K_STR, 0}, 7, 7, {115, 104, 114, 117, 110, 107, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2eoutcomeLine_str11 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 116, 105, 109, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2eoutcomeLine_str12 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 32, 40, 102, 97, 105, 108, 101, 100, 32, 97, 102, 116, 101, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eoutcomeLine_str13 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 114, 117, 110, 115, 32, 104, 101, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2eoutcomeLine_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {59, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2eoutcomeLine_str15 = {{0x80000000u, K_STR, 0}, 16, 16, {59, 32, 97, 103, 97, 105, 110, 58, 32, 45, 45, 115, 101, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eoutcomeLine_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2ecommands_2eoutcomeLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eoutcomeLine_entry, 1, 0};

V g_heff_2ecommands_2eoutcomeLine(V v_o_240) {
top: ;
  V v_t_241 = heff_get(heff_dup(v_o_240), LBL_ok);
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    v_t_242 = ((V)&g_heff_2ecommands_2eoutcomeLine_str0);
    break;
  }
  case TAG_False: {
    v_t_242 = ((V)&g_heff_2ecommands_2eoutcomeLine_str1);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_243 = heff_get(heff_dup(v_o_240), LBL_property);
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_244 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_244 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_2416;
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    v_t_2416 = ((V)&g_heff_2ecommands_2eoutcomeLine_str2);
    break;
  }
  case TAG_False: {
    V v_t_245 = heff_get(heff_dup(v_o_240), LBL_ok);
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = (g_heff_2ecommands_2estatistic(heff_dup(v_o_240)));
      v_t_2416 = heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str3), heff_strAppend(v_t_246, ((V)&g_heff_2ecommands_2eoutcomeLine_str4)));
      break;
    }
    case TAG_False: {
      V v_t_247 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_runs));
      V v_t_248 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_o_240), LBL_discarded));
      V v_t_2410;
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        V v_t_249 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_discarded));
        v_t_2410 = heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str5), heff_strAppend(v_t_249, ((V)&g_heff_2ecommands_2eoutcomeLine_str6)));
        break;
      }
      case TAG_False: {
        v_t_2410 = ((V)&g_heff_2ecommands_2eoutcomeLine_str7);
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V v_n_2411 = heff_get(heff_dup(v_o_240), LBL_shrinks);
      V v_t_2412 = heff_intEq(heff_dup(v_n_2411), MK_INT(0LL));
      V v_t_2414;
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_n_2411);
        v_t_2414 = ((V)&g_heff_2ecommands_2eoutcomeLine_str8);
        break;
      }
      case TAG_False: {
        V v_t_2413 = heff_intEq(heff_dup(v_n_2411), MK_INT(1LL));
        switch (heff_tag_of(v_t_2413)) {
        case TAG_True: {
          heff_drop(v_n_2411);
          v_t_2414 = ((V)&g_heff_2ecommands_2eoutcomeLine_str9);
          break;
        }
        case TAG_False: {
          v_t_2414 = heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str10), heff_strAppend(heff_intShow(v_n_2411), ((V)&g_heff_2ecommands_2eoutcomeLine_str11)));
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      V v_t_2415 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_seed));
      v_t_2416 = heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str12), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str13), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str14), heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str15), heff_strAppend(v_t_2415, ((V)&g_heff_2ecommands_2eoutcomeLine_str16)))))))));
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  return heff_strAppend(v_t_242, heff_strAppend(heff_get(v_o_240, LBL_name), v_t_2416));
}
V g_heff_2ecommands_2eoutcomeLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eoutcomeLine(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2efailLines_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 32, 32, 32, 32, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2efailLines_str1 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 32, 32, 32, 32, 32, 32, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2efailLines_str2 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 32, 32, 32, 32, 32, 32, 32, 98, 117, 116, 32, 103, 111, 116, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2efailLines_str3 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 32, 32, 32, 32, 32, 32, 32, 100, 105, 102, 102, 32, 32, 32, 32, 32}};
Clo g_heff_2ecommands_2efailLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efailLines_entry, 2, 0};

V g_heff_2ecommands_2efailLines(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_FailBecause: {
    V v_why_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2efailLines_str0), v_why_242), NTAG(TAG_Nil)});
  }
  case TAG_FailDiffer: {
    V v_expected_243 = heff_field(v_x2_241, 0);
    V v_got_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24FailDiffer = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_245 = (g_heff_2ereport_2emismatch(v_color_240, v_expected_243, v_got_244));
    V v_t_246 = heff_strAppend(((V)&g_heff_2ecommands_2efailLines_str1), heff_get(heff_dup(v_m_245), LBL_expected));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ecommands_2efailLines_str2), heff_get(heff_dup(v_m_245), LBL_got));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecommands_2efailLines_str3), heff_get(v_m_245, LBL_diff));
    V v_t_249 = heff_tag_at(v_ru_24x2_241_24FailDiffer, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_246, heff_tag(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2efailLines_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2efailLines(a[0], a[1]); heff_drop(a[0]); return r;
}

static V g_heff_2ecommands_2edefaultSeed_val;
static int g_heff_2ecommands_2edefaultSeed_st;
static V g_heff_2ecommands_2edefaultSeed_init(void) {
  return MK_INT(2026LL);
}
V g_heff_2ecommands_2edefaultSeed_get(void) {
  if (g_heff_2ecommands_2edefaultSeed_st == 2) return g_heff_2ecommands_2edefaultSeed_val;
  if (g_heff_2ecommands_2edefaultSeed_st == 1) heff_fail("defined by itself");
  g_heff_2ecommands_2edefaultSeed_st = 1;
  g_heff_2ecommands_2edefaultSeed_val = heff_tr(g_heff_2ecommands_2edefaultSeed_init());
  g_heff_2ecommands_2edefaultSeed_st = 2;
  return g_heff_2ecommands_2edefaultSeed_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectName_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectName_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectName_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectName_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2ecommands_2eprojectName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprojectName_entry, 3, 0};

V g_heff_2ecommands_2eprojectName(V v_st_240, V v_dir_241, V v_x3_242) {
top: ;
  V v_t_243 = heff_strEq(heff_dup(v_dir_241), ((V)&g_heff_2ecommands_2eprojectName_str0));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      V v_t_244 = (g_std_2epath_2eparse(v_st_240, v_dir_241));
      V v_xs_245 = heff_get(v_t_244, LBL_segments);
      V v_x1_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_245));
      V v_x2_249;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nil: {
        v_x2_249 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 2);
        v_x2_249 = heff_tag(TAG_Just, 1, (V[]){v_x_247});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        return ((V)&g_heff_2ecommands_2eprojectName_str1);
      }
      case TAG_Just: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        heff_take_n(v_x2_249, 1ULL, 1);
        return v_x_2410;
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    case TAG_Just: {
      V v_pwd_2411 = heff_field(v_x3_242, 0);
      V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
      heff_drop(v_dir_241);
      V v_t_2412 = (g_std_2epath_2eparse(v_st_240, v_pwd_2411));
      V v_xs_2413 = heff_get(v_t_2412, LBL_segments);
      V v_x1_2414 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2413));
      V v_x2_2417;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        v_x2_2417 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 2);
        v_x2_2417 = heff_tag_at(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_x_2415});
        break;
      }
      default: heff_nomatch(v_x1_2414);
      }
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_Nothing: {
        return ((V)&g_heff_2ecommands_2eprojectName_str2);
      }
      case TAG_Just: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        heff_take_n(v_x2_2417, 1ULL, 1);
        return v_x_2418;
      }
      default: return heff_nomatch(v_x2_2417);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_False: {
    heff_drop(v_x3_242);
    V v_t_2419 = (g_std_2epath_2eparse(v_st_240, v_dir_241));
    V v_xs_2420 = heff_get(v_t_2419, LBL_segments);
    V v_x1_2421 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2420));
    V v_x2_2424;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_Nil: {
      v_x2_2424 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 2);
      v_x2_2424 = heff_tag(TAG_Just, 1, (V[]){v_x_2422});
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nothing: {
      return ((V)&g_heff_2ecommands_2eprojectName_str3);
    }
    case TAG_Just: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      heff_take_n(v_x2_2424, 1ULL, 1);
      return v_x_2425;
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecommands_2eprojectName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprojectName(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2emoduleText_str0 = {{0x80000000u, K_STR, 0}, 18, 18, {45, 45, 32, 96, 104, 101, 102, 102, 32, 116, 101, 115, 116, 32, 115, 114, 99, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2emoduleText_str1 = {{0x80000000u, K_STR, 0}, 14, 14, {47, 103, 114, 101, 101, 116, 105, 110, 103, 46, 104, 102, 96, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2emoduleText_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2emoduleText_str3 = {{0x80000000u, K_STR, 0}, 22, 22, {45, 45, 32, 62, 62, 62, 32, 103, 114, 101, 101, 116, 105, 110, 103, 32, 34, 104, 101, 102, 102, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2emoduleText_str4 = {{0x80000000u, K_STR, 0}, 17, 17, {45, 45, 32, 34, 72, 101, 108, 108, 111, 44, 32, 104, 101, 102, 102, 33, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[40]; } g_heff_2ecommands_2emoduleText_str5 = {{0x80000000u, K_STR, 0}, 40, 40, {103, 114, 101, 101, 116, 105, 110, 103, 32, 110, 97, 109, 101, 32, 61, 32, 34, 72, 101, 108, 108, 111, 44, 32, 34, 32, 43, 43, 32, 110, 97, 109, 101, 32, 43, 43, 32, 34, 33, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2emoduleText_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2emoduleText_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2emoduleText_str8 = {{0x80000000u, K_STR, 0}, 27, 27, {103, 114, 101, 101, 116, 105, 110, 103, 32, 58, 32, 83, 116, 114, 105, 110, 103, 32, 45, 62, 32, 83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2emoduleText_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2emoduleText_str10 = {{0x80000000u, K_STR, 0}, 14, 14, {105, 109, 112, 111, 114, 116, 32, 112, 114, 101, 108, 117, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_heff_2ecommands_2emoduleText_str11 = {{0x80000000u, K_STR, 0}, 57, 57, {45, 45, 32, 99, 104, 101, 99, 107, 115, 32, 116, 104, 101, 109, 32, 97, 108, 108, 44, 32, 97, 110, 100, 32, 116, 104, 105, 115, 32, 111, 110, 101, 39, 115, 32, 119, 97, 116, 99, 104, 101, 115, 32, 97, 114, 101, 32, 99, 104, 101, 99, 107, 101, 100, 32, 98, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[66]; } g_heff_2ecommands_2emoduleText_str12 = {{0x80000000u, K_STR, 0}, 66, 66, {45, 45, 32, 65, 32, 109, 111, 100, 117, 108, 101, 32, 111, 102, 32, 116, 104, 101, 32, 112, 97, 99, 107, 97, 103, 101, 44, 32, 97, 115, 32, 101, 118, 101, 114, 121, 32, 102, 105, 108, 101, 32, 111, 102, 32, 115, 114, 99, 47, 32, 105, 115, 58, 32, 96, 104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 96}};
Clo g_heff_2ecommands_2emoduleText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emoduleText_entry, 1, 0};

V g_heff_2ecommands_2emoduleText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ecommands_2emoduleText_str0), heff_strAppend(v_name_240, ((V)&g_heff_2ecommands_2emoduleText_str1)));
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str2), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str4), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str6), v_t_243})});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str8), v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str10), v_t_245})});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2emoduleText_str11), heff_tag(TAG_Cons, 2, (V[]){v_t_241, v_t_246})});
  return ({ V a_0 = ((V)&g_heff_2ecommands_2emoduleText_str12); V a_1 = v_t_247; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop_tag(v_t_247, 2); r_; });
}
V g_heff_2ecommands_2emoduleText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2emoduleText(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2eprogramText_str0 = {{0x80000000u, K_STR, 0}, 15, 15, {45, 45, 32, 84, 104, 101, 32, 112, 114, 111, 103, 114, 97, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2ecommands_2eprogramText_str1 = {{0x80000000u, K_STR, 0}, 42, 42, {58, 32, 96, 104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 96, 32, 98, 117, 105, 108, 100, 115, 32, 105, 116, 32, 116, 111, 32, 46, 104, 101, 102, 102, 47, 98, 105, 110, 47, 44, 32, 97, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2eprogramText_str2 = {{0x80000000u, K_STR, 0}, 37, 37, {45, 45, 32, 119, 105, 116, 104, 111, 117, 116, 32, 97, 32, 98, 117, 105, 108, 100, 44, 32, 98, 121, 32, 96, 104, 101, 102, 102, 32, 114, 117, 110, 32, 97, 112, 112, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eprogramText_str3 = {{0x80000000u, K_STR, 0}, 10, 10, {47, 109, 97, 105, 110, 46, 104, 102, 96, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2eprogramText_str4 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 109, 112, 111, 114, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2eprogramText_str5 = {{0x80000000u, K_STR, 0}, 9, 9, {46, 103, 114, 101, 101, 116, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprogramText_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecommands_2eprogramText_str7 = {{0x80000000u, K_STR, 0}, 20, 20, {109, 97, 105, 110, 32, 58, 32, 67, 111, 32, 115, 116, 100, 105, 111, 32, 85, 110, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[33]; } g_heff_2ecommands_2eprogramText_str8 = {{0x80000000u, K_STR, 0}, 33, 33, {109, 97, 105, 110, 32, 61, 32, 112, 114, 111, 103, 114, 97, 109, 32, 40, 105, 111, 32, 58, 61, 32, 104, 101, 114, 101, 32, 115, 116, 100, 105, 111, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2ecommands_2eprogramText_str9 = {{0x80000000u, K_STR, 0}, 34, 34, {112, 114, 111, 103, 114, 97, 109, 32, 61, 32, 112, 114, 105, 110, 116, 32, 40, 103, 114, 101, 101, 116, 105, 110, 103, 32, 34, 119, 111, 114, 108, 100, 34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprogramText_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprogramText_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[50]; } g_heff_2ecommands_2eprogramText_str12 = {{0x80000000u, K_STR, 0}, 50, 50, {112, 114, 111, 103, 114, 97, 109, 32, 58, 32, 123, 123, 105, 111, 32, 58, 32, 115, 116, 100, 105, 111, 32, 60, 58, 32, 115, 116, 100, 105, 111, 125, 125, 32, 45, 62, 32, 67, 111, 32, 115, 116, 100, 105, 111, 32, 85, 110, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2eprogramText_str13 = {{0x80000000u, K_STR, 0}, 14, 14, {105, 109, 112, 111, 114, 116, 32, 112, 114, 101, 108, 117, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2eprogramText_str14 = {{0x80000000u, K_STR, 0}, 13, 13, {105, 109, 112, 111, 114, 116, 32, 115, 116, 100, 46, 105, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2eprogramText_str15 = {{0x80000000u, K_STR, 0}, 9, 9, {105, 109, 112, 111, 114, 116, 32, 99, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprogramText_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[71]; } g_heff_2ecommands_2eprogramText_str17 = {{0x80000000u, K_STR, 0}, 71, 71, {45, 45, 32, 98, 117, 105, 108, 100, 46, 104, 102, 32, 115, 97, 121, 115, 44, 32, 97, 110, 100, 32, 96, 104, 101, 102, 102, 32, 105, 110, 115, 116, 97, 108, 108, 96, 32, 105, 110, 116, 111, 32, 126, 47, 46, 104, 101, 102, 102, 47, 98, 105, 110, 47, 59, 32, 114, 117, 110, 32, 111, 110, 32, 78, 111, 100, 101, 46, 106, 115, 44}};
Clo g_heff_2ecommands_2eprogramText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprogramText_entry, 1, 0};

V g_heff_2ecommands_2eprogramText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ecommands_2eprogramText_str0), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ecommands_2eprogramText_str1)));
  V v_t_242 = heff_strAppend(((V)&g_heff_2ecommands_2eprogramText_str2), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ecommands_2eprogramText_str3)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ecommands_2eprogramText_str4), heff_strAppend(v_name_240, ((V)&g_heff_2ecommands_2eprogramText_str5)));
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str6), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str8), v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str10), v_t_245})});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str11), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str12), v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str13), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str14), v_t_247})});
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str15), heff_tag(TAG_Cons, 2, (V[]){v_t_243, v_t_248})});
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_242, heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str16), v_t_249})});
  return ({ V a_0 = v_t_241; V b_1 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprogramText_str17), v_t_2410}); V r_ = (g_prelude_2efoldl_24s3(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2ecommands_2eprogramText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eprogramText(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildText_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2ebuildText_str1 = {{0x80000000u, K_STR, 0}, 13, 13, {98, 117, 105, 108, 100, 32, 58, 32, 66, 117, 105, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2ebuildText_str2 = {{0x80000000u, K_STR, 0}, 37, 37, {98, 117, 105, 108, 100, 32, 61, 32, 123, 32, 98, 97, 99, 107, 101, 110, 100, 32, 61, 32, 67, 44, 32, 114, 117, 110, 32, 61, 32, 34, 109, 97, 105, 110, 34, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2ebuildText_str3 = {{0x80000000u, K_STR, 0}, 15, 15, {105, 109, 112, 111, 114, 116, 32, 109, 97, 110, 105, 102, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildText_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2ecommands_2ebuildText_str5 = {{0x80000000u, K_STR, 0}, 21, 21, {45, 45, 32, 104, 101, 102, 102, 32, 104, 111, 109, 101, 32, 119, 105, 116, 104, 32, 105, 116, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildText_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[71]; } g_heff_2ecommands_2ebuildText_str7 = {{0x80000000u, K_STR, 0}, 71, 71, {45, 45, 32, 78, 111, 100, 101, 46, 106, 115, 32, 112, 114, 111, 103, 114, 97, 109, 32, 111, 102, 32, 105, 116, 46, 32, 32, 65, 32, 102, 105, 101, 108, 100, 32, 96, 115, 104, 105, 112, 115, 32, 61, 32, 91, 46, 46, 46, 93, 96, 32, 119, 111, 117, 108, 100, 32, 110, 97, 109, 101, 32, 102, 105, 108, 101, 115, 32, 97, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[69]; } g_heff_2ecommands_2ebuildText_str8 = {{0x80000000u, K_STR, 0}, 69, 69, {45, 45, 32, 100, 105, 114, 101, 99, 116, 111, 114, 105, 101, 115, 32, 111, 102, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116, 32, 102, 111, 114, 32, 96, 104, 101, 102, 102, 32, 105, 110, 115, 116, 97, 108, 108, 96, 32, 116, 111, 32, 112, 117, 116, 32, 105, 110, 32, 116, 104, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[69]; } g_heff_2ecommands_2ebuildText_str9 = {{0x80000000u, K_STR, 0}, 69, 69, {45, 45, 32, 109, 97, 105, 110, 46, 104, 102, 39, 115, 32, 96, 109, 97, 105, 110, 96, 44, 32, 99, 111, 109, 112, 105, 108, 101, 100, 32, 116, 104, 114, 111, 117, 103, 104, 32, 67, 32, 40, 98, 121, 32, 96, 122, 105, 103, 32, 99, 99, 96, 41, 59, 32, 96, 78, 111, 100, 101, 96, 32, 109, 97, 107, 101, 115, 32, 97}};

static V g_heff_2ecommands_2ebuildText_val;
static int g_heff_2ecommands_2ebuildText_st;
static V g_heff_2ecommands_2ebuildText_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str2), v_t_240})});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str4), v_t_241})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str6), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ebuildText_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ecommands_2ebuildText_str9); V a_1 = v_t_244; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ecommands_2ebuildText_get(void) {
  if (g_heff_2ecommands_2ebuildText_st == 2) return g_heff_2ecommands_2ebuildText_val;
  if (g_heff_2ecommands_2ebuildText_st == 1) heff_fail("defined by itself");
  g_heff_2ecommands_2ebuildText_st = 1;
  g_heff_2ecommands_2ebuildText_val = heff_tr(g_heff_2ecommands_2ebuildText_init());
  g_heff_2ecommands_2ebuildText_st = 2;
  return g_heff_2ecommands_2ebuildText_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2etestText_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 109, 112, 111, 114, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2etestText_str1 = {{0x80000000u, K_STR, 0}, 9, 9, {46, 103, 114, 101, 101, 116, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestText_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2etestText_str3 = {{0x80000000u, K_STR, 0}, 8, 8, {103, 114, 101, 101, 116, 115, 32, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[69]; } g_heff_2ecommands_2etestText_str4 = {{0x80000000u, K_STR, 0}, 69, 69, {32, 32, 117, 110, 105, 116, 32, 34, 103, 114, 101, 101, 116, 105, 110, 103, 34, 32, 40, 101, 113, 117, 97, 108, 32, 115, 104, 111, 119, 83, 116, 114, 105, 110, 103, 32, 40, 103, 114, 101, 101, 116, 105, 110, 103, 32, 34, 116, 101, 115, 116, 34, 41, 32, 34, 72, 101, 108, 108, 111, 44, 32, 116, 101, 115, 116, 33, 34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestText_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2etestText_str6 = {{0x80000000u, K_STR, 0}, 13, 13, {103, 114, 101, 101, 116, 115, 32, 58, 32, 84, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2etestText_str7 = {{0x80000000u, K_STR, 0}, 14, 14, {105, 109, 112, 111, 114, 116, 32, 112, 114, 101, 108, 117, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestText_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2etestText_str9 = {{0x80000000u, K_STR, 0}, 12, 12, {105, 109, 112, 111, 114, 116, 32, 99, 104, 101, 99, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[69]; } g_heff_2ecommands_2etestText_str10 = {{0x80000000u, K_STR, 0}, 69, 69, {45, 45, 32, 96, 104, 101, 102, 102, 32, 116, 101, 115, 116, 96, 32, 114, 117, 110, 115, 32, 116, 104, 101, 32, 116, 101, 115, 116, 115, 32, 111, 102, 32, 101, 118, 101, 114, 121, 32, 102, 105, 108, 101, 32, 111, 102, 32, 116, 101, 115, 116, 47, 58, 32, 116, 104, 101, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[52]; } g_heff_2ecommands_2etestText_str11 = {{0x80000000u, K_STR, 0}, 52, 52, {45, 45, 32, 111, 102, 32, 116, 121, 112, 101, 32, 96, 84, 101, 115, 116, 96, 32, 40, 108, 105, 98, 47, 99, 104, 101, 99, 107, 46, 104, 102, 41, 44, 32, 97, 102, 116, 101, 114, 32, 116, 104, 101, 32, 119, 97, 116, 99, 104, 101, 115, 46}};
Clo g_heff_2ecommands_2etestText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestText_entry, 1, 0};

V g_heff_2ecommands_2etestText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ecommands_2etestText_str0), heff_strAppend(v_name_240, ((V)&g_heff_2ecommands_2etestText_str1)));
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str2), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str4), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str6), v_t_243})});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){v_t_241, heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str7), v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str8), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str9), v_t_245})});
  return ({ V a_0 = ((V)&g_heff_2ecommands_2etestText_str10); V b_1 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2etestText_str11), v_t_246}); V r_ = (g_prelude_2efoldl_24s3(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2ecommands_2etestText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestText(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2eprojectFiles_str0 = {{0x80000000u, K_STR, 0}, 22, 22, {112, 97, 99, 107, 97, 103, 101, 32, 61, 32, 123, 32, 109, 111, 100, 117, 108, 101, 32, 61, 32, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2eprojectFiles_str1 = {{0x80000000u, K_STR, 0}, 11, 11, {34, 44, 32, 104, 101, 102, 102, 32, 61, 32, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eprojectFiles_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {34, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2eprojectFiles_str4 = {{0x80000000u, K_STR, 0}, 17, 17, {112, 97, 99, 107, 97, 103, 101, 32, 58, 32, 80, 97, 99, 107, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eprojectFiles_str5 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2eprojectFiles_str6 = {{0x80000000u, K_STR, 0}, 15, 15, {105, 109, 112, 111, 114, 116, 32, 109, 97, 110, 105, 102, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eprojectFiles_str9 = {{0x80000000u, K_STR, 0}, 10, 10, {46, 103, 105, 116, 105, 103, 110, 111, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2eprojectFiles_str10 = {{0x80000000u, K_STR, 0}, 6, 6, {46, 104, 101, 102, 102, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eprojectFiles_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {115, 114, 99, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2eprojectFiles_str12 = {{0x80000000u, K_STR, 0}, 12, 12, {47, 103, 114, 101, 101, 116, 105, 110, 103, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eprojectFiles_str13 = {{0x80000000u, K_STR, 0}, 4, 4, {97, 112, 112, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eprojectFiles_str14 = {{0x80000000u, K_STR, 0}, 8, 8, {47, 109, 97, 105, 110, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eprojectFiles_str15 = {{0x80000000u, K_STR, 0}, 4, 4, {97, 112, 112, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2eprojectFiles_str16 = {{0x80000000u, K_STR, 0}, 9, 9, {47, 98, 117, 105, 108, 100, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2eprojectFiles_str17 = {{0x80000000u, K_STR, 0}, 16, 16, {116, 101, 115, 116, 47, 103, 114, 101, 101, 116, 105, 110, 103, 46, 104, 102}};
Clo g_heff_2ecommands_2eprojectFiles_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprojectFiles_entry, 2, 0};

V g_heff_2ecommands_2eprojectFiles(V v_name_240, V v_v_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str0), heff_strAppend(heff_dup(v_name_240), heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str1), heff_strAppend(v_v_241, ((V)&g_heff_2ecommands_2eprojectFiles_str2)))));
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str3), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str4), heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_243})});
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str5), ({ V a_0 = ((V)&g_heff_2ecommands_2eprojectFiles_str6); V b_1 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str7), v_t_244}); V r_ = (g_prelude_2efoldl_24s3(a_0, b_1)); heff_drop(b_1); r_; })});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str8), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str9), ({ V a_0 = ((V)&g_heff_2ecommands_2eprojectFiles_str10); V a_1 = v_t_246; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop_tag(v_t_246, 2); r_; })});
  V v_t_248 = heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str11), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ecommands_2eprojectFiles_str12)));
  V v_t_249 = heff_tag(TAG_MkPair, 2, (V[]){v_t_248, (g_heff_2ecommands_2emoduleText(heff_dup(v_name_240)))});
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str13), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ecommands_2eprojectFiles_str14)));
  V v_t_2411 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2410, (g_heff_2ecommands_2eprogramText(heff_dup(v_name_240)))});
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str15), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ecommands_2eprojectFiles_str16)));
  V v_t_2413 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str17), (g_heff_2ecommands_2etestText(v_name_240))});
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_2412, heff_dup(g_heff_2ecommands_2ebuildText_get())}), v_t_2414});
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, heff_tag(TAG_Cons, 2, (V[]){v_t_2411, v_t_2415})});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_245, heff_tag(TAG_Cons, 2, (V[]){v_t_247, v_t_2416})});
}
V g_heff_2ecommands_2eprojectFiles_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eprojectFiles(a[0], a[1]);
}
V g_heff_2ecommands_2erequiring_lam0(V self, V *args);
V g_heff_2ecommands_2erequiring_lam1(V self, V *args);
Clo g_heff_2ecommands_2erequiring_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erequiring_entry, 4, 0};

V g_heff_2ecommands_2erequiring(V v_pk_240, V v_name_241, V v_path_242, V v_v_243) {
top: ;
  V v_t_245 = ({ V a_0 = heff_clo(g_heff_2ecommands_2erequiring_lam0, 1, 1, (V[]){heff_dup(v_path_242)}); V b_1 = heff_get(heff_dup(v_pk_240), LBL_require); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_249;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_name_241);
    v_t_249 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2erequiring_lam1, 1, 2, (V[]){v_path_242, v_v_243}), heff_get(heff_dup(v_pk_240), LBL_require)));
    break;
  }
  case TAG_False: {
    V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(3, shape_198_239_370, (V[]){v_name_241, v_path_242, v_v_243}), NTAG(TAG_Nil)});
    v_t_249 = (g_prelude_2econcatList(heff_get(heff_dup(v_pk_240), LBL_require), v_t_248));
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_rec(4, shape_192_124_275_274, (V[]){heff_get(heff_dup(v_pk_240), LBL_module), heff_get(heff_dup(v_pk_240), LBL_heff), v_t_249, heff_get(v_pk_240, LBL_replace)});
}
V g_heff_2ecommands_2erequiring_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2erequiring(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2erequiring_lam0(V self, V *args) {
  V v_r_244 = args[0];
  V v_path_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_r_244, LBL_path), v_path_242);
}
V g_heff_2ecommands_2erequiring_lam1(V self, V *args) {
  V v_r_246 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_v_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_strEq(heff_get(heff_dup(v_r_246), LBL_path), heff_dup(v_path_242));
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    return heff_rec(3, shape_198_239_370, (V[]){heff_get(v_r_246, LBL_name), v_path_242, v_v_243});
  }
  case TAG_False: {
    heff_drop(v_path_242);
    heff_drop(v_v_243);
    return v_r_246;
  }
  default: return heff_nomatch(v_t_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2eprintErrs_24s887_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintErrs_24s887_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintErrs_24s887_lam0(V self, V *args);
Clo g_heff_2ecommands_2eprintErrs_24s887_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintErrs_24s887_entry, 5, 0};

V g_heff_2ecommands_2eprintErrs_24s887(V v_m_240, V v_x2_241, V v_n_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_n_242});
  }
  case TAG_Cons: {
    V v_l_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_dup(v_m_240), heff_strAppend(((V)&g_heff_2ecommands_2eprintErrs_24s887_str0), v_l_245));
    V v_t_248 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2ecommands_2eprintErrs_24s887_str1)), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2411}));
    return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2eprintErrs_24s887_lam0, 1, 5, (V[]){v_m_240, v_rest_246, v_n_242, v_p_243, v_p_244})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eprintErrs_24s887_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eprintErrs_24s887(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2eprintErrs_24s887_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2413);
  return (g_heff_2ecommands_2eprintErrs_24s887(v_m_240, v_rest_246, heff_intAdd(v_n_242, MK_INT(1LL)), v_p_243, v_p_244));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecommands_2eemitErrs_24s902_str0 = {{0x80000000u, K_STR, 0}, 20, 20, {104, 101, 102, 102, 58, 32, 110, 111, 116, 32, 99, 111, 109, 112, 105, 108, 101, 100, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eemitErrs_24s902_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eemitErrs_24s902_lam0(V self, V *args);
Clo g_heff_2ecommands_2eemitErrs_24s902_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eemitErrs_24s902_entry, 3, 0};

V g_heff_2ecommands_2eemitErrs_24s902(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2eemitErrs_24s902_str0), v_e_243), ((V)&g_heff_2ecommands_2eemitErrs_24s902_str1));
    V v_t_246 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_WriteErr, 2, (V[]){v_t_245, NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2ecommands_2eemitErrs_24s902_lam0, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eemitErrs_24s902_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eemitErrs_24s902(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eemitErrs_24s902_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2411);
  return (g_heff_2ecommands_2eemitErrs_24s902(v_rest_244, v_p_241, v_p_242));
}
V g_heff_2ecommands_2ediagCount_24s909_lam0(V self, V *args); static Clo g_heff_2ecommands_2ediagCount_24s909_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ediagCount_24s909_lam0, 2, 0};
V g_heff_2ecommands_2ediagCount_24s909_lam3(V self, V *args);
V g_heff_2ecommands_2ediagCount_24s909_lam2(V self, V *args);
V g_heff_2ecommands_2ediagCount_24s909_lam1(V self, V *args);
Clo g_heff_2ecommands_2ediagCount_24s909_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ediagCount_24s909_entry, 1, 0};

V g_heff_2ecommands_2ediagCount_24s909(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecommands_2ediagCount_24s909_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_t_245 = (g_prelude_2emap_24s485(heff_get(heff_dup(v_c_243), LBL_diags)));
    V v_c_246 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintErrs_24s887_clo), 3, (V[]){heff_get(heff_dup(v_c_243), LBL_module), v_t_245, MK_INT(0LL)}));
    return heff_clo(g_heff_2ecommands_2ediagCount_24s909_lam1, 2, 2, (V[]){v_c_246, heff_dup(v_rest_244)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2ediagCount_24s909_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ediagCount_24s909(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ediagCount_24s909_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ediagCount_24s909_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_intAdd(v_x_249, v_x_2411);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ediagCount_24s909_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2410 = ({ V a_0 = v_rest_244; V r_ = (g_heff_2ecommands_2ediagCount_24s909(a_0)); heff_drop(v_rest_244); r_; });
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2ecommands_2ediagCount_24s909_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2ecommands_2ediagCount_24s909_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_rest_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2ecommands_2ediagCount_24s909_lam2, 1, 3, (V[]){v_rest_244, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintFails_24s911_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintFails_24s911_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintFails_24s911_lam0(V self, V *args); static Clo g_heff_2ecommands_2eprintFails_24s911_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintFails_24s911_lam0, 2, 0};
V g_heff_2ecommands_2eprintFails_24s911_lam1(V self, V *args);
V g_heff_2ecommands_2eprintFails_24s911_lam3(V self, V *args);
V g_heff_2ecommands_2eprintFails_24s911_lam2(V self, V *args);
Clo g_heff_2ecommands_2eprintFails_24s911_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintFails_24s911_entry, 3, 0};

V g_heff_2ecommands_2eprintFails_24s911(V v_f_240, V v_color_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecommands_2eprintFails_24s911_lam0_clo);
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_get(heff_get(heff_dup(v_r_245), LBL_watch), LBL_expected);
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_t_249 = ((V)&g_heff_2ecommands_2eprintFails_24s911_str0);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2410 = heff_get(heff_get(heff_dup(v_r_245), LBL_watch), LBL_value);
    V v_t_2411 = (g_heff_2ereport_2emismatch(v_color_241, v_t_249, v_t_2410));
    V v_str_2412 = (g_heff_2ecommands_2efailLine(heff_dup(v_f_240), v_r_245, v_t_2411));
    V v_c_2420 = heff_clo(g_heff_2ecommands_2eprintFails_24s911_lam1, 2, 1, (V[]){v_str_2412});
    return heff_clo(g_heff_2ecommands_2eprintFails_24s911_lam2, 2, 4, (V[]){v_c_2420, v_f_240, heff_dup(v_color_241), v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2eprintFails_24s911_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprintFails_24s911(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2eprintFails_24s911_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eprintFails_24s911_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_str_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2412, ((V)&g_heff_2ecommands_2eprintFails_24s911_str1)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2413, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eprintFails_24s911_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_color_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2421 = heff_env(self)[3];
  V v_k_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2423);
  V v_t_2424 = ({ V a_0 = v_f_240; V a_1 = v_color_241; V a_2 = v_rest_246; V r_ = (g_heff_2ecommands_2eprintFails_24s911(a_0, a_1, a_2)); heff_drop(v_color_241); r_; });
  return heff_tail(v_t_2424, 2, (V[]){v_hd_2421, v_k_2422});
}
V g_heff_2ecommands_2eprintFails_24s911_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_color_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2420;
  args[0] = heff_dup(v_hd_2421);
  args[1] = heff_clo(g_heff_2ecommands_2eprintFails_24s911_lam3, 1, 5, (V[]){v_f_240, v_color_241, v_rest_246, v_hd_2421, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintOutcomes_24s912_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintOutcomes_24s912_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintOutcomes_24s912_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintOutcomes_24s912_lam0(V self, V *args); static Clo g_heff_2ecommands_2eprintOutcomes_24s912_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintOutcomes_24s912_lam0, 2, 0};
V g_heff_2ecommands_2eprintOutcomes_24s912_lam1(V self, V *args);
V g_heff_2ecommands_2eprintOutcomes_24s912_lam4(V self, V *args); static Clo g_heff_2ecommands_2eprintOutcomes_24s912_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintOutcomes_24s912_lam4, 2, 0};
V g_heff_2ecommands_2eprintOutcomes_24s912_lam5(V self, V *args);
V g_heff_2ecommands_2eprintOutcomes_24s912_lam6(V self, V *args);
V g_heff_2ecommands_2eprintOutcomes_24s912_lam3(V self, V *args);
V g_heff_2ecommands_2eprintOutcomes_24s912_lam2(V self, V *args);
Clo g_heff_2ecommands_2eprintOutcomes_24s912_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintOutcomes_24s912_entry, 2, 0};

V g_heff_2ecommands_2eprintOutcomes_24s912(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecommands_2eprintOutcomes_24s912_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_str_246 = (g_heff_2ecommands_2eoutcomeLine(heff_dup(v_o_244)));
    V v_c_2414 = heff_clo(g_heff_2ecommands_2eprintOutcomes_24s912_lam1, 2, 1, (V[]){v_str_246});
    return heff_clo(g_heff_2ecommands_2eprintOutcomes_24s912_lam2, 2, 4, (V[]){v_c_2414, v_o_244, heff_dup(v_color_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eprintOutcomes_24s912_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprintOutcomes_24s912(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eprintOutcomes_24s912_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eprintOutcomes_24s912_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_str_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_246, ((V)&g_heff_2ecommands_2eprintOutcomes_24s912_str0)), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2412}));
  V f_ = heff_get(v_hd_247, LBL_bind);
  args[0] = v_t_2413;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eprintOutcomes_24s912_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eprintOutcomes_24s912_lam5(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k2_2430 = args[1];
  V v_str_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2428, ((V)&g_heff_2ecommands_2eprintOutcomes_24s912_str2)), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2429), LBL_malg), 1, (V[]){v_t_2434}));
  V f_ = heff_get(v_hd_2429, LBL_bind);
  args[0] = v_t_2435;
  args[1] = v_k2_2430;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eprintOutcomes_24s912_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_color_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2415 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2437);
  V v_t_2438 = ({ V a_0 = v_color_240; V a_1 = v_rest_245; V r_ = (g_heff_2ecommands_2eprintOutcomes_24s912(a_0, a_1)); heff_drop(v_color_240); r_; });
  return heff_tail(v_t_2438, 2, (V[]){v_hd_2415, v_k_2416});
}
V g_heff_2ecommands_2eprintOutcomes_24s912_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_o_244 = heff_env(self)[0];
  V v_color_240 = heff_env(self)[1];
  V v_hd_2415 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_k_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2417);
  V v_t_2418 = heff_get(heff_dup(v_o_244), LBL_ok);
  V v_c_2436;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    heff_drop(v_o_244);
    v_c_2436 = ((V)&g_heff_2ecommands_2eprintOutcomes_24s912_lam4_clo);
    break;
  }
  case TAG_False: {
    V v_t_2421 = (g_prelude_2emap_24s811(heff_get(heff_dup(v_o_244), LBL_notes)));
    V v_t_2422 = heff_get(v_o_244, LBL_failure);
    V v_t_2424;
    switch (heff_tag_of(v_t_2422)) {
    case TAG_Nothing: {
      v_t_2424 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_f_2423 = heff_field(v_t_2422, 0);
      heff_take_n(v_t_2422, 1ULL, 1);
      v_t_2424 = (g_heff_2ecommands_2efailLines(v_color_240, v_f_2423));
      break;
    }
    default: heff_nomatch(v_t_2422);
    }
    V v_x2_2425 = (g_prelude_2econcatList(v_t_2421, v_t_2424));
    V v_str_2428;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nil: {
      v_str_2428 = ((V)&g_heff_2ecommands_2eprintOutcomes_24s912_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_xs_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      v_str_2428 = ({ V a_0 = v_x_2426; V a_1 = v_xs_2427; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2427); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    v_c_2436 = heff_clo(g_heff_2ecommands_2eprintOutcomes_24s912_lam5, 2, 1, (V[]){v_str_2428});
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_2415), heff_clo(g_heff_2ecommands_2eprintOutcomes_24s912_lam6, 1, 4, (V[]){v_color_240, v_rest_245, v_hd_2415, v_k_2416})});
}
V g_heff_2ecommands_2eprintOutcomes_24s912_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_o_244 = heff_env(self)[1];
  V v_color_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo(g_heff_2ecommands_2eprintOutcomes_24s912_lam3, 1, 5, (V[]){v_o_244, v_color_240, v_hd_2415, v_rest_245, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintLines_24s930_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintLines_24s930_lam0(V self, V *args);
Clo g_heff_2ecommands_2eprintLines_24s930_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintLines_24s930_entry, 3, 0};

V g_heff_2ecommands_2eprintLines_24s930(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_243, ((V)&g_heff_2ecommands_2eprintLines_24s930_str0)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_248}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2eprintLines_24s930_lam0, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprintLines_24s930_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eprintLines_24s930(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eprintLines_24s930_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2410);
  return (g_heff_2ecommands_2eprintLines_24s930(v_rest_244, v_p_241, v_p_242));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eappShips_24s958_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {98, 117, 105, 108, 100, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eappShips_24s958_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2eappShips_24s958_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {58, 32, 105, 116, 32, 115, 104, 105, 112, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[33]; } g_heff_2ecommands_2eappShips_24s958_str3 = {{0x80000000u, K_STR, 0}, 33, 33, {44, 32, 119, 104, 105, 99, 104, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 104, 97, 118, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eappShips_24s958_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eappShips_24s958_lam0(V self, V *args);
V g_heff_2ecommands_2eappShips_24s958_lam1(V self, V *args);
V g_heff_2ecommands_2eappShips_24s958_lam3(V self, V *args);
V g_heff_2ecommands_2eappShips_24s958_lam2(V self, V *args);
Clo g_heff_2ecommands_2eappShips_24s958_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eappShips_24s958_entry, 6, 0};

V g_heff_2ecommands_2eappShips_24s958(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_a_244, V v_missing_245) {
top: ;
  switch (heff_tag_of(v_missing_245)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    return heff_clo(g_heff_2ecommands_2eappShips_24s958_lam0, 2, 3, (V[]){v_x_243, v_a_244, v_acc_242});
  }
  case TAG_Cons: {
    heff_drop(v_a_244);
    V v_t_2412 = (g_heff_2ecommands_2eappFile(v_st_240, v_t_241, v_x_243, ((V)&g_heff_2ecommands_2eappShips_24s958_str0)));
    V v_x2_2413 = (g_prelude_2emap_24s801(v_missing_245));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ecommands_2eappShips_24s958_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = v_x_2414; V a_1 = v_xs_2415; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_str_2417 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ecommands_2eappShips_24s958_str2), heff_strAppend(v_t_2416, ((V)&g_heff_2ecommands_2eappShips_24s958_str3))));
    V v_c_2425 = heff_clo(g_heff_2ecommands_2eappShips_24s958_lam1, 2, 1, (V[]){v_str_2417});
    return heff_clo(g_heff_2ecommands_2eappShips_24s958_lam2, 2, 2, (V[]){v_c_2425, v_acc_242});
  }
  default: return heff_nomatch(v_missing_245);
  }
}
V g_heff_2ecommands_2eappShips_24s958_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eappShips_24s958(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eappShips_24s958_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_246);
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_198_33, (V[]){v_x_243, v_a_244}), heff_get(heff_dup(v_acc_242), LBL_apps)});
  V v_t_249 = heff_rec(2, shape_11_19, (V[]){v_t_248, heff_get(v_acc_242, LBL_bad)});
  V f_ = v_k_247;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eappShips_24s958_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k2_2419 = args[1];
  V v_str_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2417, ((V)&g_heff_2ecommands_2eappShips_24s958_str4)), NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2418), LBL_malg), 1, (V[]){v_t_2423}));
  V f_ = heff_get(v_hd_2418, LBL_bind);
  args[0] = v_t_2424;
  args[1] = v_k2_2419;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eappShips_24s958_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_intAdd(heff_get(heff_dup(v_acc_242), LBL_bad), MK_INT(1LL));
  V v_t_2430 = heff_rec(2, shape_11_19, (V[]){heff_get(v_acc_242, LBL_apps), v_t_2429});
  V f_ = v_k_2427;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eappShips_24s958_lam2(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2425;
  args[0] = v_hd_2426;
  args[1] = heff_clo(g_heff_2ecommands_2eappShips_24s958_lam3, 1, 2, (V[]){v_acc_242, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eprintDefs_24s1025_lam0(V self, V *args); static Clo g_heff_2ecommands_2eprintDefs_24s1025_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintDefs_24s1025_lam0, 2, 0};
V g_heff_2ecommands_2eprintDefs_24s1025_lam2(V self, V *args);
V g_heff_2ecommands_2eprintDefs_24s1025_lam1(V self, V *args);
Clo g_heff_2ecommands_2eprintDefs_24s1025_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintDefs_24s1025_entry, 2, 0};

V g_heff_2ecommands_2eprintDefs_24s1025(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    return ((V)&g_heff_2ecommands_2eprintDefs_24s1025_lam0_clo);
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2edriver_2edumpLines(heff_dup(v_c_240), heff_dup(v_k_244)));
    V v_c_247 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintLines_24s930_clo), 1, (V[]){v_t_246}));
    return heff_clo(g_heff_2ecommands_2eprintDefs_24s1025_lam1, 2, 3, (V[]){v_c_247, v_c_240, heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eprintDefs_24s1025_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprintDefs_24s1025(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2eprintDefs_24s1025_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eprintDefs_24s1025_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  V v_t_2411 = ({ V a_0 = v_c_240; V a_1 = v_rest_245; V r_ = (g_heff_2ecommands_2eprintDefs_24s1025(a_0, a_1)); heff_drop(v_rest_245); r_; });
  return heff_tail(v_t_2411, 2, (V[]){v_hd_248, v_k_249});
}
V g_heff_2ecommands_2eprintDefs_24s1025_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo(g_heff_2ecommands_2eprintDefs_24s1025_lam2, 1, 4, (V[]){v_c_240, v_rest_245, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eprintAll_24s1024_lam0(V self, V *args);
V g_heff_2ecommands_2eprintAll_24s1024_lam3(V self, V *args);
V g_heff_2ecommands_2eprintAll_24s1024_lam2(V self, V *args);
V g_heff_2ecommands_2eprintAll_24s1024_lam1(V self, V *args);
Clo g_heff_2ecommands_2eprintAll_24s1024_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintAll_24s1024_entry, 2, 0};

V g_heff_2ecommands_2eprintAll_24s1024(V v_x1_240, V v_bad_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_clo(g_heff_2ecommands_2eprintAll_24s1024_lam0, 2, 1, (V[]){v_bad_241});
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_t_246 = (g_prelude_2emap_24s484(heff_get(heff_dup(v_c_244), LBL_own)));
    V v_c_247 = ({ V a_0 = heff_dup(v_c_244); V a_1 = v_t_246; V r_ = (g_heff_2ecommands_2eprintDefs_24s1025(a_0, a_1)); heff_drop(v_t_246); r_; });
    return heff_clo(g_heff_2ecommands_2eprintAll_24s1024_lam1, 2, 4, (V[]){v_c_247, heff_dup(v_c_244), heff_dup(v_rest_245), v_bad_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprintAll_24s1024_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprintAll_24s1024(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eprintAll_24s1024_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_bad_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_bad_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eprintAll_24s1024_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = ({ V a_0 = v_rest_245; V a_1 = heff_intAdd(v_bad_241, v_x_2413); V r_ = (g_heff_2ecommands_2eprintAll_24s1024(a_0, a_1)); heff_drop(v_rest_245); r_; });
  return heff_tail(v_t_2414, 2, (V[]){v_hd_248, v_k_249});
}
V g_heff_2ecommands_2eprintAll_24s1024_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = (g_prelude_2emap_24s485(heff_get(heff_dup(v_c_244), LBL_diags)));
  V v_c_2412 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintErrs_24s887_clo), 3, (V[]){heff_get(v_c_244, LBL_module), v_t_2411, MK_INT(0LL)}));
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_248), heff_clo(g_heff_2ecommands_2eprintAll_24s1024_lam3, 1, 4, (V[]){v_rest_245, v_bad_241, v_hd_248, v_k_249})});
}
V g_heff_2ecommands_2eprintAll_24s1024_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo(g_heff_2ecommands_2eprintAll_24s1024_lam2, 1, 5, (V[]){v_c_244, v_hd_248, v_rest_245, v_bad_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eprintEvals_24s1028_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintEvals_24s1028_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintEvals_24s1028_lam0(V self, V *args);
Clo g_heff_2ecommands_2eprintEvals_24s1028_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintEvals_24s1028_entry, 3, 0};

V g_heff_2ecommands_2eprintEvals_24s1028(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_get(heff_dup(v_d_243), LBL_name), heff_strAppend(((V)&g_heff_2ecommands_2eprintEvals_24s1028_str0), heff_get(v_d_243, LBL_value)));
    V v_t_246 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ecommands_2eprintEvals_24s1028_str1)), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2ecommands_2eprintEvals_24s1028_lam0, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprintEvals_24s1028_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eprintEvals_24s1028(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eprintEvals_24s1028_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2411);
  return (g_heff_2ecommands_2eprintEvals_24s1028(v_rest_244, v_p_241, v_p_242));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2estyleNow_24s863_24s1035_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
V g_heff_2ecommands_2estyleNow_24s863_24s1035_lam0(V self, V *args); static Clo g_heff_2ecommands_2estyleNow_24s863_24s1035_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2estyleNow_24s863_24s1035_lam0, 1, 0};
V g_heff_2ecommands_2estyleNow_24s863_24s1035_lam1(V self, V *args);
Clo g_heff_2ecommands_2estyleNow_24s863_24s1035_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2estyleNow_24s863_24s1035_entry, 2, 0};

V g_heff_2ecommands_2estyleNow_24s863_24s1035(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2estyleNow_24s863_24s1035_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_245})}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecommands_2estyleNow_24s863_24s1035_lam1, 1, 1, (V[]){v_k_241})});
}
V g_heff_2ecommands_2estyleNow_24s863_24s1035_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2estyleNow_24s863_24s1035(a[0], a[1]);
}
V g_heff_2ecommands_2estyleNow_24s863_24s1035_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return v_s_242;
}
V g_heff_2ecommands_2estyleNow_24s863_24s1035_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_strEq(v_x_247, ((V)&g_heff_2ecommands_2estyleNow_24s863_24s1035_str0));
  V v_x_249;
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    v_x_249 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    v_x_249 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V f_ = v_k_241;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2elibDir_24s862_24s1034_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {72, 69, 70, 70, 95, 76, 73, 66}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2elibDir_24s862_24s1034_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 105, 98}};
V g_heff_2ecommands_2elibDir_24s862_24s1034_lam0(V self, V *args); static Clo g_heff_2ecommands_2elibDir_24s862_24s1034_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2elibDir_24s862_24s1034_lam0, 1, 0};
V g_heff_2ecommands_2elibDir_24s862_24s1034_lam3(V self, V *args); static Clo g_heff_2ecommands_2elibDir_24s862_24s1034_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2elibDir_24s862_24s1034_lam3, 1, 0};
V g_heff_2ecommands_2elibDir_24s862_24s1034_lam4(V self, V *args);
V g_heff_2ecommands_2elibDir_24s862_24s1034_lam2(V self, V *args);
V g_heff_2ecommands_2elibDir_24s862_24s1034_lam1(V self, V *args);
Clo g_heff_2ecommands_2elibDir_24s862_24s1034_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2elibDir_24s862_24s1034_entry, 2, 0};

V g_heff_2ecommands_2elibDir_24s862_24s1034(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2elibDir_24s862_24s1034_str0), ((V)&g_heff_2ecommands_2elibDir_24s862_24s1034_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_245})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecommands_2elibDir_24s862_24s1034_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2elibDir_24s862_24s1034_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2elibDir_24s862_24s1034(a[0], a[1]);
}
V g_heff_2ecommands_2elibDir_24s862_24s1034_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ecommands_2elibDir_24s862_24s1034_lam3(V self, V *args) {
  V v_s_249 = args[0];
  return v_s_249;
}
V g_heff_2ecommands_2elibDir_24s862_24s1034_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2415 = (g_heff_2ecommands_2eownRoot(v_x_248, v_x_2414));
  V v_t_2416 = (g_std_2epath_2eparse(v_x_248, v_a_2415));
  V v_t_2417 = (g_std_2epath_2eparse(v_x_248, ((V)&g_heff_2ecommands_2elibDir_24s862_24s1034_str1)));
  V v_p_2418 = (g_std_2epath_2ejoin_2eonto_240(v_t_2416, v_t_2417));
  V v_t_2419 = ({ V a_0 = heff_get(heff_dup(v_p_2418), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2418), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2420 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2418), LBL_drive), heff_get(v_p_2418, LBL_absolute), v_t_2419});
  V v_x_2421 = ({ V a_0 = v_x_248; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_248); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2elibDir_24s862_24s1034_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ecommands_2elibDir_24s862_24s1034_lam3_clo)})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2412})}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2ecommands_2elibDir_24s862_24s1034_lam4, 1, 2, (V[]){v_x_248, v_k_241})});
}
V g_heff_2ecommands_2elibDir_24s862_24s1034_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    return (g_heff_2ecommands_2estyleNow_24s863_24s1035(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2elibDir_24s862_24s1034_lam2, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    V v_lib_2422 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_lib_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2emodDir_24s864_24s1036_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {72, 69, 70, 70, 95, 77, 79, 68, 67, 65, 67, 72, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2emodDir_24s864_24s1036_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {72, 79, 77, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2emodDir_24s864_24s1036_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {85, 83, 69, 82, 80, 82, 79, 70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2emodDir_24s864_24s1036_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2emodDir_24s864_24s1036_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {46, 99, 97, 99, 104, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2emodDir_24s864_24s1036_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2emodDir_24s864_24s1036_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {109, 111, 100}};
V g_heff_2ecommands_2emodDir_24s864_24s1036_lam0(V self, V *args); static Clo g_heff_2ecommands_2emodDir_24s864_24s1036_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emodDir_24s864_24s1036_lam0, 1, 0};
V g_heff_2ecommands_2emodDir_24s864_24s1036_lam2(V self, V *args); static Clo g_heff_2ecommands_2emodDir_24s864_24s1036_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emodDir_24s864_24s1036_lam2, 1, 0};
V g_heff_2ecommands_2emodDir_24s864_24s1036_lam4(V self, V *args); static Clo g_heff_2ecommands_2emodDir_24s864_24s1036_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emodDir_24s864_24s1036_lam4, 1, 0};
V g_heff_2ecommands_2emodDir_24s864_24s1036_lam6(V self, V *args);
V g_heff_2ecommands_2emodDir_24s864_24s1036_lam5(V self, V *args);
V g_heff_2ecommands_2emodDir_24s864_24s1036_lam3(V self, V *args);
V g_heff_2ecommands_2emodDir_24s864_24s1036_lam1(V self, V *args);
Clo g_heff_2ecommands_2emodDir_24s864_24s1036_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emodDir_24s864_24s1036_entry, 2, 0};

V g_heff_2ecommands_2emodDir_24s864_24s1036(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2emodDir_24s864_24s1036_str0), ((V)&g_heff_2ecommands_2emodDir_24s864_24s1036_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_245})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecommands_2emodDir_24s864_24s1036_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2emodDir_24s864_24s1036_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2emodDir_24s864_24s1036(a[0], a[1]);
}
V g_heff_2ecommands_2emodDir_24s864_24s1036_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ecommands_2emodDir_24s864_24s1036_lam2(V self, V *args) {
  V v_v_248 = args[0];
  return v_v_248;
}
V g_heff_2ecommands_2emodDir_24s864_24s1036_lam4(V self, V *args) {
  V v_v_2414 = args[0];
  return v_v_2414;
}
V g_heff_2ecommands_2emodDir_24s864_24s1036_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2443;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_d_2422;
    switch (heff_tag_of(v_x_2419)) {
    case TAG_Nothing: {
      v_d_2422 = ((V)&g_heff_2ecommands_2emodDir_24s864_24s1036_str3);
      break;
    }
    case TAG_Just: {
      V v_x_2421 = heff_field(v_x_2419, 0);
      heff_take_n(v_x_2419, 1ULL, 1);
      v_d_2422 = v_x_2421;
      break;
    }
    default: heff_nomatch(v_x_2419);
    }
    V v_a_2424;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_Nothing: {
      v_a_2424 = v_d_2422;
      break;
    }
    case TAG_Just: {
      V v_x_2423 = heff_field(v_x_2413, 0);
      heff_take_n(v_x_2413, 1ULL, 1);
      heff_drop(v_d_2422);
      v_a_2424 = v_x_2423;
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_t_2425 = (g_std_2epath_2eparse(v_x_2420, v_a_2424));
    V v_t_2426 = (g_std_2epath_2eparse(v_x_2420, ((V)&g_heff_2ecommands_2emodDir_24s864_24s1036_str4)));
    V v_p_2427 = (g_std_2epath_2ejoin_2eonto_240(v_t_2425, v_t_2426));
    V v_t_2428 = ({ V a_0 = heff_get(heff_dup(v_p_2427), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2427), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2429 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2427), LBL_drive), heff_get(v_p_2427, LBL_absolute), v_t_2428});
    V v_a_2430 = (g_std_2epath_2erender(v_x_2420, v_t_2429));
    V v_t_2431 = (g_std_2epath_2eparse(v_x_2420, ((V)&g_heff_2ecommands_2emodDir_24s864_24s1036_str5)));
    V v_t_2432 = (g_std_2epath_2eparse(v_x_2420, ((V)&g_heff_2ecommands_2emodDir_24s864_24s1036_str6)));
    V v_p_2433 = (g_std_2epath_2ejoin_2eonto_240(v_t_2431, v_t_2432));
    V v_t_2434 = ({ V a_0 = heff_get(heff_dup(v_p_2433), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2433), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2435 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2433), LBL_drive), heff_get(v_p_2433, LBL_absolute), v_t_2434});
    V v_b_2436 = (g_std_2epath_2erender(v_x_2420, v_t_2435));
    V v_t_2437 = (g_std_2epath_2eparse(v_x_2420, v_a_2430));
    V v_t_2438 = (g_std_2epath_2eparse(v_x_2420, v_b_2436));
    V v_p_2439 = (g_std_2epath_2ejoin_2eonto_240(v_t_2437, v_t_2438));
    V v_t_2440 = ({ V a_0 = heff_get(heff_dup(v_p_2439), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2439), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2441 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2439), LBL_drive), heff_get(v_p_2439, LBL_absolute), v_t_2440});
    v_x_2443 = ({ V a_0 = v_x_2420; V a_1 = v_t_2441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2420); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2442 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    heff_drop(v_x_2420);
    heff_drop(v_x_2419);
    heff_drop(v_x_2413);
    v_x_2443 = v_d_2442;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V f_ = v_k_241;
  args[0] = v_x_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2emodDir_24s864_24s1036_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecommands_2estyleNow_24s863_24s1035(v_hd_240, heff_clo(g_heff_2ecommands_2emodDir_24s864_24s1036_lam6, 1, 4, (V[]){v_x_247, v_x_2419, v_x_2413, v_k_241})));
}
V g_heff_2ecommands_2emodDir_24s864_24s1036_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2emodDir_24s864_24s1036_str2), ((V)&g_heff_2ecommands_2emodDir_24s864_24s1036_lam4_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2417})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2418, heff_clo(g_heff_2ecommands_2emodDir_24s864_24s1036_lam5, 1, 4, (V[]){v_hd_240, v_x_247, v_x_2413, v_k_241})});
}
V g_heff_2ecommands_2emodDir_24s864_24s1036_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2emodDir_24s864_24s1036_str1), ((V)&g_heff_2ecommands_2emodDir_24s864_24s1036_lam2_clo)})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2emodDir_24s864_24s1036_lam3, 1, 3, (V[]){v_hd_240, v_x_247, v_k_241})});
}
V g_heff_2ecommands_2ehostNow_24s861_24s1033_lam2(V self, V *args);
V g_heff_2ecommands_2ehostNow_24s861_24s1033_lam1(V self, V *args);
V g_heff_2ecommands_2ehostNow_24s861_24s1033_lam0(V self, V *args);
Clo g_heff_2ecommands_2ehostNow_24s861_24s1033_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ehostNow_24s861_24s1033_entry, 2, 0};

V g_heff_2ecommands_2ehostNow_24s861_24s1033(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2elibDir_24s862_24s1034(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ehostNow_24s861_24s1033_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecommands_2ehostNow_24s861_24s1033_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ehostNow_24s861_24s1033(a[0], a[1]);
}
V g_heff_2ecommands_2ehostNow_24s861_24s1033_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_rec(3, shape_174_191_327, (V[]){v_x_242, v_x_243, v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ehostNow_24s861_24s1033_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2estyleNow_24s863_24s1035(v_hd_240, heff_clo(g_heff_2ecommands_2ehostNow_24s861_24s1033_lam2, 1, 3, (V[]){v_k_241, v_x_242, v_x_243})));
}
V g_heff_2ecommands_2ehostNow_24s861_24s1033_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecommands_2emodDir_24s864_24s1036(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ehostNow_24s861_24s1033_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eownPackage_24s886_24s1038_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
V g_heff_2ecommands_2eownPackage_24s886_24s1038_lam1(V self, V *args); static Clo g_heff_2ecommands_2eownPackage_24s886_24s1038_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eownPackage_24s886_24s1038_lam1, 1, 0};
V g_heff_2ecommands_2eownPackage_24s886_24s1038_lam2(V self, V *args);
V g_heff_2ecommands_2eownPackage_24s886_24s1038_lam0(V self, V *args);
Clo g_heff_2ecommands_2eownPackage_24s886_24s1038_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eownPackage_24s886_24s1038_entry, 2, 0};

V g_heff_2ecommands_2eownPackage_24s886_24s1038(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2estyleNow_24s863_24s1035(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2eownPackage_24s886_24s1038_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecommands_2eownPackage_24s886_24s1038_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eownPackage_24s886_24s1038(a[0], a[1]);
}
V g_heff_2ecommands_2eownPackage_24s886_24s1038_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ecommands_2eownPackage_24s886_24s1038_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_249 = (g_heff_2ecommands_2eownRoot(v_x_242, v_x_248));
  V v_t_2410 = (g_std_2epath_2eparse(v_x_242, v_a_249));
  V v_t_2411 = (g_std_2epath_2eparse(v_x_242, ((V)&g_heff_2ecommands_2eownPackage_24s886_24s1038_str0)));
  V v_p_2412 = (g_std_2epath_2ejoin_2eonto_240(v_t_2410, v_t_2411));
  V v_t_2413 = ({ V a_0 = heff_get(heff_dup(v_p_2412), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2412), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2414 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2412), LBL_drive), heff_get(v_p_2412, LBL_absolute), v_t_2413});
  V v_x_2415 = ({ V a_0 = v_x_242; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_242); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eownPackage_24s886_24s1038_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ecommands_2eownPackage_24s886_24s1038_lam1_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2eownPackage_24s886_24s1038_lam2, 1, 2, (V[]){v_x_242, v_k_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetFails_24s941_24s1074_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 32, 103, 101, 116, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetFails_24s941_24s1074_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2egetFails_24s941_24s1074_lam0(V self, V *args);
Clo g_heff_2ecommands_2egetFails_24s941_24s1074_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetFails_24s941_24s1074_entry, 3, 0};

V g_heff_2ecommands_2egetFails_24s941_24s1074(V v_why_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2egetFails_24s941_24s1074_str0), v_why_240), ((V)&g_heff_2ecommands_2egetFails_24s941_24s1074_str1));
  V v_t_244 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_243, NTAG(TAG_MkUnit)});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2egetFails_24s941_24s1074_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2egetFails_24s941_24s1074_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2egetFails_24s941_24s1074(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2egetFails_24s941_24s1074_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_249);
  V v_t_2410 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2414, v_k_242});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2enothingBuilt_24s953_24s1085_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {104, 101, 102, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2enothingBuilt_24s953_24s1085_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2enothingBuilt_24s953_24s1085_str2 = {{0x80000000u, K_STR, 0}, 15, 15, {58, 32, 110, 111, 116, 104, 105, 110, 103, 32, 98, 117, 105, 108, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enothingBuilt_24s953_24s1085_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2enothingBuilt_24s953_24s1085_lam0(V self, V *args);
Clo g_heff_2ecommands_2enothingBuilt_24s953_24s1085_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enothingBuilt_24s953_24s1085_entry, 4, 0};

V g_heff_2ecommands_2enothingBuilt_24s953_24s1085(V v_cmd_240, V v_what_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecommands_2enothingBuilt_24s953_24s1085_str0), heff_strAppend(v_cmd_240, heff_strAppend(((V)&g_heff_2ecommands_2enothingBuilt_24s953_24s1085_str1), heff_strAppend(v_what_241, ((V)&g_heff_2ecommands_2enothingBuilt_24s953_24s1085_str2)))));
  V v_t_245 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_244, ((V)&g_heff_2ecommands_2enothingBuilt_24s953_24s1085_str3)), NTAG(TAG_MkUnit)});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2enothingBuilt_24s953_24s1085_lam0, 1, 2, (V[]){v_hd_242, v_k_243})});
}
V g_heff_2ecommands_2enothingBuilt_24s953_24s1085_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2enothingBuilt_24s953_24s1085(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2enothingBuilt_24s953_24s1085_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2410);
  V v_t_2411 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2415, v_k_243});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2eshipFails_24s965_24s1091_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eshipFails_24s965_24s1091_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eshipFails_24s965_24s1091_lam0(V self, V *args);
Clo g_heff_2ecommands_2eshipFails_24s965_24s1091_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipFails_24s965_24s1091_entry, 3, 0};

V g_heff_2ecommands_2eshipFails_24s965_24s1091(V v_why_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2eshipFails_24s965_24s1091_str0), v_why_240), ((V)&g_heff_2ecommands_2eshipFails_24s965_24s1091_str1));
  V v_t_244 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_243, NTAG(TAG_MkUnit)});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2eshipFails_24s965_24s1091_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2eshipFails_24s965_24s1091_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eshipFails_24s965_24s1091(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eshipFails_24s965_24s1091_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_249);
  V v_t_2410 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2414, v_k_242});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2enodeDone_24s969_24s1095_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {43, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2enodeDone_24s969_24s1095_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 104, 109, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enodeDone_24s969_24s1095_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enodeDone_24s969_24s1095_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2enodeDone_24s969_24s1095_lam1(V self, V *args); static Clo g_heff_2ecommands_2enodeDone_24s969_24s1095_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enodeDone_24s969_24s1095_lam1, 1, 0};
V g_heff_2ecommands_2enodeDone_24s969_24s1095_lam0(V self, V *args);
V g_heff_2ecommands_2enodeDone_24s969_24s1095_lam4(V self, V *args);
V g_heff_2ecommands_2enodeDone_24s969_24s1095_lam3(V self, V *args);
V g_heff_2ecommands_2enodeDone_24s969_24s1095_lam2(V self, V *args);
Clo g_heff_2ecommands_2enodeDone_24s969_24s1095_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enodeDone_24s969_24s1095_entry, 4, 0};

V g_heff_2ecommands_2enodeDone_24s969_24s1095(V v_st_240, V v_t_241, V v_x_242, V v_next_243) {
top: ;
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_bin)));
  V v_t_245 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_242)));
  V v_p_246 = (g_std_2epath_2ejoin_2eonto_240(v_t_244, v_t_245));
  V v_t_247 = ({ V a_0 = heff_get(heff_dup(v_p_246), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_246), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_248 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_246), LBL_drive), heff_get(v_p_246, LBL_absolute), v_t_247});
  V v_t_249 = (g_std_2epath_2erender(v_st_240, v_t_248));
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_as_2411 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2enodeDone_24s969_24s1095_str0), v_t_2410});
  V v_c_2419 = heff_clo(g_heff_2ecommands_2enodeDone_24s969_24s1095_lam0, 2, 1, (V[]){v_as_2411});
  return heff_clo(g_heff_2ecommands_2enodeDone_24s969_24s1095_lam2, 2, 5, (V[]){v_c_2419, heff_dup(v_st_240), v_t_241, v_x_242, v_next_243});
}
V g_heff_2ecommands_2enodeDone_24s969_24s1095_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2enodeDone_24s969_24s1095(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2enodeDone_24s969_24s1095_lam1(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ecommands_2enodeDone_24s969_24s1095_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_as_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2enodeDone_24s969_24s1095_str1), v_as_2411, ((V)&g_heff_2ecommands_2enodeDone_24s969_24s1095_lam1_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2417})}));
  V f_ = heff_get(v_hd_2412, LBL_bind);
  args[0] = v_t_2418;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2enodeDone_24s969_24s1095_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_hd_2420 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2435);
  return heff_tail(v_next_243, 2, (V[]){v_hd_2420, v_k_2421});
}
V g_heff_2ecommands_2enodeDone_24s969_24s1095_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_hd_2420 = heff_env(self)[3];
  V v_next_243 = heff_env(self)[4];
  V v_k_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2422);
  V v_t_2423 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_bin)));
  V v_t_2424 = (g_std_2epath_2eparse(v_st_240, v_x_242));
  V v_p_2425 = (g_std_2epath_2ejoin_2eonto_240(v_t_2423, v_t_2424));
  V v_t_2426 = ({ V a_0 = heff_get(heff_dup(v_p_2425), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2425), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2427 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2425), LBL_drive), heff_get(v_p_2425, LBL_absolute), v_t_2426});
  V v_path_2428 = ({ V a_0 = v_st_240; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  V v_t_2429 = heff_strAppend(heff_get(v_t_241, LBL_said), heff_strAppend(((V)&g_heff_2ecommands_2enodeDone_24s969_24s1095_str2), v_path_2428));
  V v_t_2430 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2429, ((V)&g_heff_2ecommands_2enodeDone_24s969_24s1095_str3)), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2420), LBL_malg), 1, (V[]){v_t_2433}));
  return heff_tail(heff_get(heff_dup(v_hd_2420), LBL_bind), 2, (V[]){v_t_2434, heff_clo(g_heff_2ecommands_2enodeDone_24s969_24s1095_lam4, 1, 3, (V[]){v_next_243, v_hd_2420, v_k_2421})});
}
V g_heff_2ecommands_2enodeDone_24s969_24s1095_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_next_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo(g_heff_2ecommands_2enodeDone_24s969_24s1095_lam3, 1, 6, (V[]){v_st_240, v_t_241, v_x_242, v_hd_2420, v_next_243, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2eheffHome_24s971_24s1097_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {72, 69, 70, 70, 95, 72, 79, 77, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eheffHome_24s971_24s1097_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {72, 79, 77, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2eheffHome_24s971_24s1097_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {85, 83, 69, 82, 80, 82, 79, 70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eheffHome_24s971_24s1097_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2eheffHome_24s971_24s1097_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
V g_heff_2ecommands_2eheffHome_24s971_24s1097_lam0(V self, V *args); static Clo g_heff_2ecommands_2eheffHome_24s971_24s1097_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffHome_24s971_24s1097_lam0, 1, 0};
V g_heff_2ecommands_2eheffHome_24s971_24s1097_lam2(V self, V *args); static Clo g_heff_2ecommands_2eheffHome_24s971_24s1097_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffHome_24s971_24s1097_lam2, 1, 0};
V g_heff_2ecommands_2eheffHome_24s971_24s1097_lam4(V self, V *args); static Clo g_heff_2ecommands_2eheffHome_24s971_24s1097_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffHome_24s971_24s1097_lam4, 1, 0};
V g_heff_2ecommands_2eheffHome_24s971_24s1097_lam6(V self, V *args);
V g_heff_2ecommands_2eheffHome_24s971_24s1097_lam5(V self, V *args);
V g_heff_2ecommands_2eheffHome_24s971_24s1097_lam3(V self, V *args);
V g_heff_2ecommands_2eheffHome_24s971_24s1097_lam1(V self, V *args);
Clo g_heff_2ecommands_2eheffHome_24s971_24s1097_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffHome_24s971_24s1097_entry, 2, 0};

V g_heff_2ecommands_2eheffHome_24s971_24s1097(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2eheffHome_24s971_24s1097_str0), ((V)&g_heff_2ecommands_2eheffHome_24s971_24s1097_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_245})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecommands_2eheffHome_24s971_24s1097_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2eheffHome_24s971_24s1097_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eheffHome_24s971_24s1097(a[0], a[1]);
}
V g_heff_2ecommands_2eheffHome_24s971_24s1097_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ecommands_2eheffHome_24s971_24s1097_lam2(V self, V *args) {
  V v_v_248 = args[0];
  return v_v_248;
}
V g_heff_2ecommands_2eheffHome_24s971_24s1097_lam4(V self, V *args) {
  V v_v_2414 = args[0];
  return v_v_2414;
}
V g_heff_2ecommands_2eheffHome_24s971_24s1097_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2431;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_d_2422;
    switch (heff_tag_of(v_x_2419)) {
    case TAG_Nothing: {
      v_d_2422 = ((V)&g_heff_2ecommands_2eheffHome_24s971_24s1097_str3);
      break;
    }
    case TAG_Just: {
      V v_x_2421 = heff_field(v_x_2419, 0);
      heff_take_n(v_x_2419, 1ULL, 1);
      v_d_2422 = v_x_2421;
      break;
    }
    default: heff_nomatch(v_x_2419);
    }
    V v_a_2424;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_Nothing: {
      v_a_2424 = v_d_2422;
      break;
    }
    case TAG_Just: {
      V v_x_2423 = heff_field(v_x_2413, 0);
      heff_take_n(v_x_2413, 1ULL, 1);
      heff_drop(v_d_2422);
      v_a_2424 = v_x_2423;
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_t_2425 = (g_std_2epath_2eparse(v_x_2420, v_a_2424));
    V v_t_2426 = (g_std_2epath_2eparse(v_x_2420, ((V)&g_heff_2ecommands_2eheffHome_24s971_24s1097_str4)));
    V v_p_2427 = (g_std_2epath_2ejoin_2eonto_240(v_t_2425, v_t_2426));
    V v_t_2428 = ({ V a_0 = heff_get(heff_dup(v_p_2427), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2427), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2429 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2427), LBL_drive), heff_get(v_p_2427, LBL_absolute), v_t_2428});
    v_x_2431 = ({ V a_0 = v_x_2420; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2420); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2430 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    heff_drop(v_x_2420);
    heff_drop(v_x_2419);
    heff_drop(v_x_2413);
    v_x_2431 = v_d_2430;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V f_ = v_k_241;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eheffHome_24s971_24s1097_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecommands_2estyleNow_24s863_24s1035(v_hd_240, heff_clo(g_heff_2ecommands_2eheffHome_24s971_24s1097_lam6, 1, 4, (V[]){v_x_247, v_x_2419, v_x_2413, v_k_241})));
}
V g_heff_2ecommands_2eheffHome_24s971_24s1097_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2eheffHome_24s971_24s1097_str2), ((V)&g_heff_2ecommands_2eheffHome_24s971_24s1097_lam4_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2417})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2418, heff_clo(g_heff_2ecommands_2eheffHome_24s971_24s1097_lam5, 1, 4, (V[]){v_hd_240, v_x_247, v_x_2413, v_k_241})});
}
V g_heff_2ecommands_2eheffHome_24s971_24s1097_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2eheffHome_24s971_24s1097_str1), ((V)&g_heff_2ecommands_2eheffHome_24s971_24s1097_lam2_clo)})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2eheffHome_24s971_24s1097_lam3, 1, 3, (V[]){v_hd_240, v_x_247, v_k_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eonPathHint_24s972_24s1098_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {80, 65, 84, 72}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eonPathHint_24s972_24s1098_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2eonPathHint_24s972_24s1098_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eonPathHint_24s972_24s1098_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eonPathHint_24s972_24s1098_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eonPathHint_24s972_24s1098_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eonPathHint_24s972_24s1098_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2eonPathHint_24s972_24s1098_str7 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 32, 105, 110, 115, 116, 97, 108, 108, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[60]; } g_heff_2ecommands_2eonPathHint_24s972_24s1098_str8 = {{0x80000000u, K_STR, 0}, 60, 60, {32, 105, 115, 32, 110, 111, 116, 32, 111, 110, 32, 116, 104, 101, 32, 80, 65, 84, 72, 58, 32, 97, 100, 100, 32, 105, 116, 32, 116, 104, 101, 114, 101, 32, 116, 111, 32, 114, 117, 110, 32, 116, 104, 101, 109, 32, 98, 121, 32, 116, 104, 101, 105, 114, 32, 110, 97, 109, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eonPathHint_24s972_24s1098_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam0(V self, V *args); static Clo g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam0, 1, 0};
V g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam2(V self, V *args); static Clo g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam2, 1, 0};
V g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam4(V self, V *args);
V g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam3(V self, V *args);
V g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam1(V self, V *args);
Clo g_heff_2ecommands_2eonPathHint_24s972_24s1098_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eonPathHint_24s972_24s1098_entry, 4, 0};

V g_heff_2ecommands_2eonPathHint_24s972_24s1098(V v_st_240, V v_bin_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam0_clo)})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam1, 1, 4, (V[]){v_hd_242, heff_dup(v_st_240), v_bin_241, v_k_243})});
}
V g_heff_2ecommands_2eonPathHint_24s972_24s1098_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eonPathHint_24s972_24s1098(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam2(V self, V *args) {
  V v_v_2410 = args[0];
  return v_v_2410;
}
V g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam4(V self, V *args) {
  V v_d_2422 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bin_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = (g_std_2epath_2eparse(v_st_240, v_d_2422));
  V v_t_2424 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2eonPathHint_24s972_24s1098_str5)));
  V v_p_2425 = (g_std_2epath_2ejoin_2eonto_240(v_t_2423, v_t_2424));
  V v_t_2426 = ({ V a_0 = heff_get(heff_dup(v_p_2425), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2425), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2427 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2425), LBL_drive), heff_get(v_p_2425, LBL_absolute), v_t_2426});
  V v_t_2428 = (g_std_2epath_2erender(v_st_240, v_t_2427));
  V v_t_2429 = (g_std_2epath_2eparse(v_st_240, v_bin_241));
  V v_t_2430 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2eonPathHint_24s972_24s1098_str6)));
  V v_p_2431 = (g_std_2epath_2ejoin_2eonto_240(v_t_2429, v_t_2430));
  V v_t_2432 = ({ V a_0 = heff_get(heff_dup(v_p_2431), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2431), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2433 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2431), LBL_drive), heff_get(v_p_2431, LBL_absolute), v_t_2432});
  V v_t_2434 = ({ V a_0 = v_st_240; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  return heff_strEq(v_t_2428, v_t_2434);
}
V g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_2417;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    v_path_2417 = ((V)&g_heff_2ecommands_2eonPathHint_24s972_24s1098_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2416 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    v_path_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_t_2418 = heff_strEq(v_x_249, ((V)&g_heff_2ecommands_2eonPathHint_24s972_24s1098_str2));
  V v_sep_2419;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    v_sep_2419 = ((V)&g_heff_2ecommands_2eonPathHint_24s972_24s1098_str3);
    break;
  }
  case TAG_False: {
    v_sep_2419 = ((V)&g_heff_2ecommands_2eonPathHint_24s972_24s1098_str4);
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V v_t_2420 = heff_intEq(heff_strLength(heff_dup(v_sep_2419)), MK_INT(0LL));
  V v_t_2421;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_True: {
    heff_drop(v_sep_2419);
    v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){v_path_2417, NTAG(TAG_Nil)});
    break;
  }
  case TAG_False: {
    v_t_2421 = (g_prelude_2esplitFrom(v_sep_2419, v_path_2417, MK_INT(0LL), NTAG(TAG_Nil)));
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  V v_t_2435 = ({ V a_0 = heff_clo(g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam4, 1, 2, (V[]){v_st_240, heff_dup(v_bin_241)}); V a_1 = v_t_2421; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_t_2421); r_; });
  switch (heff_tag_of(v_t_2435)) {
  case TAG_True: {
    heff_drop(v_bin_241);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_2436 = heff_strAppend(((V)&g_heff_2ecommands_2eonPathHint_24s972_24s1098_str7), heff_strAppend(v_bin_241, ((V)&g_heff_2ecommands_2eonPathHint_24s972_24s1098_str8)));
    V v_t_2437 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2ecommands_2eonPathHint_24s972_24s1098_str9)), NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2440}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2441, v_k_243});
  }
  default: return heff_nomatch(v_t_2435);
  }
}
V g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2eonPathHint_24s972_24s1098_str0), ((V)&g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam2_clo)})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2413})}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecommands_2eonPathHint_24s972_24s1098_lam3, 1, 5, (V[]){v_x_249, v_st_240, v_bin_241, v_k_243, v_hd_242})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2epublishFails_24s977_24s1103_str0 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 32, 112, 117, 98, 108, 105, 115, 104, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishFails_24s977_24s1103_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2epublishFails_24s977_24s1103_lam0(V self, V *args);
Clo g_heff_2ecommands_2epublishFails_24s977_24s1103_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishFails_24s977_24s1103_entry, 3, 0};

V g_heff_2ecommands_2epublishFails_24s977_24s1103(V v_why_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2epublishFails_24s977_24s1103_str0), v_why_240), ((V)&g_heff_2ecommands_2epublishFails_24s977_24s1103_str1));
  V v_t_244 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_243, NTAG(TAG_MkUnit)});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2epublishFails_24s977_24s1103_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2epublishFails_24s977_24s1103_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishFails_24s977_24s1103(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2epublishFails_24s977_24s1103_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_249);
  V v_t_2410 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2414, v_k_242});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2epublishFails_24s977_24s1104_str0 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 32, 112, 117, 98, 108, 105, 115, 104, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishFails_24s977_24s1104_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2epublishFails_24s977_24s1104_lam0(V self, V *args);
Clo g_heff_2ecommands_2epublishFails_24s977_24s1104_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishFails_24s977_24s1104_entry, 3, 0};

V g_heff_2ecommands_2epublishFails_24s977_24s1104(V v_why_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2epublishFails_24s977_24s1104_str0), v_why_240), ((V)&g_heff_2ecommands_2epublishFails_24s977_24s1104_str1));
  V v_t_244 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_243, NTAG(TAG_MkUnit)});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2epublishFails_24s977_24s1104_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2epublishFails_24s977_24s1104_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishFails_24s977_24s1104(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2epublishFails_24s977_24s1104_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_249);
  V v_t_2410 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2414, v_k_242});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2egitOk_24s983_24s1110_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egitOk_24s983_24s1110_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2egitOk_24s983_24s1110_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {58, 32, 103, 105, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2egitOk_24s983_24s1110_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
V g_heff_2ecommands_2egitOk_24s983_24s1110_lam0(V self, V *args); static Clo g_heff_2ecommands_2egitOk_24s983_24s1110_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egitOk_24s983_24s1110_lam0, 1, 0};
V g_heff_2ecommands_2egitOk_24s983_24s1110_lam1(V self, V *args);
Clo g_heff_2ecommands_2egitOk_24s983_24s1110_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egitOk_24s983_24s1110_entry, 4, 0};

V g_heff_2ecommands_2egitOk_24s983_24s1110(V v_what_240, V v_as_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2egitOk_24s983_24s1110_str0), heff_dup(v_as_241), ((V)&g_heff_2ecommands_2egitOk_24s983_24s1110_lam0_clo)})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})}));
  return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2egitOk_24s983_24s1110_lam1, 1, 3, (V[]){v_as_241, v_what_240, v_k_243})});
}
V g_heff_2ecommands_2egitOk_24s983_24s1110_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2egitOk_24s983_24s1110(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2egitOk_24s983_24s1110_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_heff_2ecommands_2egitOk_24s983_24s1110_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_as_241 = heff_env(self)[0];
  V v_what_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_intEq(heff_get(heff_dup(v_x_249), LBL_status), MK_INT(0LL));
  V v_x_2420;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_x_249);
    heff_drop(v_as_241);
    heff_drop(v_what_240);
    v_x_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_False: {
    V v_t_2413;
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecommands_2egitOk_24s983_24s1110_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_as_241, 0);
      V v_xs_2412 = heff_field(v_as_241, 1);
      heff_take_n(v_as_241, 3ULL, 2);
      v_t_2413 = ({ V a_0 = v_x_2411; V a_1 = v_xs_2412; V r_ = (g_prelude_2efoldl_24s4(a_0, a_1)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_as_241);
    }
    V v_s_2414 = heff_get(v_x_249, LBL_err);
    V v_t_2415 = (g_prelude_2eskipSpaces(heff_dup(v_s_2414), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2416 = heff_intSub(heff_strLength(heff_dup(v_s_2414)), MK_INT(1LL));
    V v_t_2417 = (g_prelude_2eskipSpaces(heff_dup(v_s_2414), v_t_2416, MK_INT(-1LL)));
    V v_t_2418 = heff_strSlice(v_s_2414, v_t_2415, heff_intAdd(v_t_2417, MK_INT(1LL)));
    V v_t_2419 = heff_strAppend(v_what_240, heff_strAppend(((V)&g_heff_2ecommands_2egitOk_24s983_24s1110_str2), heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ecommands_2egitOk_24s983_24s1110_str3), v_t_2418))));
    v_x_2420 = heff_tag(TAG_Just, 1, (V[]){v_t_2419});
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V f_ = v_k_243;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s982_24s1109_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s982_24s1109_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2epublishTag_24s982_24s1109_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishTag_24s982_24s1109_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2epublishTag_24s982_24s1109_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2epublishTag_24s982_24s1109_str5 = {{0x80000000u, K_STR, 0}, 10, 10, {110, 111, 116, 32, 116, 97, 103, 103, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s982_24s1109_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTag_24s982_24s1109_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 117, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2epublishTag_24s982_24s1109_str8 = {{0x80000000u, K_STR, 0}, 6, 6, {111, 114, 105, 103, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2epublishTag_24s982_24s1109_str9 = {{0x80000000u, K_STR, 0}, 18, 18, {116, 97, 103, 103, 101, 100, 44, 32, 110, 111, 116, 32, 112, 117, 115, 104, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2epublishTag_24s982_24s1109_str10 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 32, 112, 117, 98, 108, 105, 115, 104, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s982_24s1109_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2epublishTag_24s982_24s1109_str12 = {{0x80000000u, K_STR, 0}, 7, 7, {44, 32, 116, 97, 103, 32, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s982_24s1109_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2epublishTag_24s982_24s1109_lam1(V self, V *args);
V g_heff_2ecommands_2epublishTag_24s982_24s1109_lam0(V self, V *args);
Clo g_heff_2ecommands_2epublishTag_24s982_24s1109_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishTag_24s982_24s1109_entry, 4, 0};

V g_heff_2ecommands_2epublishTag_24s982_24s1109(V v_v_240, V v_pk_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_str0), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_str1), heff_dup(v_v_240)), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_str2), v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_str4), v_t_245})});
  HEFF_LAST return g_heff_2ecommands_2egitOk_24s983_24s1110(((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_str5), v_t_246, heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2epublishTag_24s982_24s1109_lam0, 1, 4, (V[]){v_v_240, v_hd_242, v_pk_241, v_k_243}));
}
V g_heff_2ecommands_2epublishTag_24s982_24s1109_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishTag_24s982_24s1109(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2epublishTag_24s982_24s1109_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_pk_241 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_str10), heff_strAppend(heff_get(v_pk_241, LBL_module), heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_str11), heff_strAppend(heff_dup(v_v_240), heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_str12), v_v_240)))));
    V v_t_2412 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_str13)), NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2415}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2416, v_k_243});
  }
  case TAG_Just: {
    V v_why_2417 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    heff_drop(v_pk_241);
    heff_drop(v_v_240);
    return (g_heff_2ecommands_2epublishFails_24s977_24s1104(v_why_2417, v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ecommands_2epublishTag_24s982_24s1109_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_str6), heff_dup(v_v_240)), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_str8), v_t_248})});
    return (g_heff_2ecommands_2egitOk_24s983_24s1110(((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_str9), v_t_249, heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2epublishTag_24s982_24s1109_lam1, 1, 4, (V[]){v_pk_241, v_v_240, v_hd_242, v_k_243})));
  }
  case TAG_Just: {
    V v_why_2418 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop(v_pk_241);
    return (g_heff_2ecommands_2epublishFails_24s977_24s1104(v_why_2418, v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_x_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s981_24s1108_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2epublishTested_24s981_24s1108_str1 = {{0x80000000u, K_STR, 0}, 27, 27, {32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 100, 111, 32, 110, 111, 116, 32, 104, 111, 108, 100, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s981_24s1108_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2epublishTested_24s981_24s1108_str3 = {{0x80000000u, K_STR, 0}, 37, 37, {32, 116, 101, 115, 116, 115, 32, 102, 97, 105, 108, 44, 32, 111, 114, 32, 97, 32, 102, 105, 108, 101, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 99, 104, 101, 99, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s981_24s1108_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2epublishTested_24s981_24s1108_str5 = {{0x80000000u, K_STR, 0}, 27, 27, {32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 100, 111, 32, 110, 111, 116, 32, 104, 111, 108, 100, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s981_24s1108_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2epublishTested_24s981_24s1108_str7 = {{0x80000000u, K_STR, 0}, 37, 37, {32, 116, 101, 115, 116, 115, 32, 102, 97, 105, 108, 44, 32, 111, 114, 32, 97, 32, 102, 105, 108, 101, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 99, 104, 101, 99, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s981_24s1108_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2epublishTested_24s981_24s1108_str9 = {{0x80000000u, K_STR, 0}, 27, 27, {32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 100, 111, 32, 110, 111, 116, 32, 104, 111, 108, 100, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s981_24s1108_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2epublishTested_24s981_24s1108_str11 = {{0x80000000u, K_STR, 0}, 37, 37, {32, 116, 101, 115, 116, 115, 32, 102, 97, 105, 108, 44, 32, 111, 114, 32, 97, 32, 102, 105, 108, 101, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 99, 104, 101, 99, 107}};
Clo g_heff_2ecommands_2epublishTested_24s981_24s1108_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishTested_24s981_24s1108_entry, 3, 0};

V g_heff_2ecommands_2epublishTested_24s981_24s1108(V v_v_240, V v_pk_241, V v_r_242) {
top: ;
  V v_t_243 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_r_242), LBL_failed));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_v_240);
    heff_drop(v_pk_241);
    V v_t_244 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_failed));
    V v_t_245 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_total));
    V v_t_246 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_testsFailed));
    V v_t_247 = heff_intShow(heff_get(v_r_242, LBL_tests));
    V v_t_248 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s981_24s1108_str0), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s981_24s1108_str1), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s981_24s1108_str2), heff_strAppend(v_t_247, ((V)&g_heff_2ecommands_2epublishTested_24s981_24s1108_str3))))))));
    return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s977_24s1103_clo), 1, (V[]){v_t_248});
  }
  case TAG_False: {
    V v_t_249 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_r_242), LBL_testsFailed));
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_v_240);
      heff_drop(v_pk_241);
      V v_t_2410 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_failed));
      V v_t_2411 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_total));
      V v_t_2412 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_testsFailed));
      V v_t_2413 = heff_intShow(heff_get(v_r_242, LBL_tests));
      V v_t_2414 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s981_24s1108_str4), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s981_24s1108_str5), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s981_24s1108_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2ecommands_2epublishTested_24s981_24s1108_str7))))))));
      return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s977_24s1103_clo), 1, (V[]){v_t_2414});
    }
    case TAG_False: {
      V v_t_2415 = heff_get(heff_dup(v_r_242), LBL_ok);
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop(v_r_242);
        return heff_tail(((V)&g_heff_2ecommands_2epublishTag_24s982_24s1109_clo), 2, (V[]){v_v_240, v_pk_241});
      }
      case TAG_False: {
        heff_drop(v_v_240);
        heff_drop(v_pk_241);
        V v_t_2416 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_failed));
        V v_t_2417 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_total));
        V v_t_2418 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_testsFailed));
        V v_t_2419 = heff_intShow(heff_get(v_r_242, LBL_tests));
        V v_t_2420 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s981_24s1108_str8), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s981_24s1108_str9), heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s981_24s1108_str10), heff_strAppend(v_t_2419, ((V)&g_heff_2ecommands_2epublishTested_24s981_24s1108_str11))))))));
        return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s977_24s1103_clo), 1, (V[]){v_t_2420});
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecommands_2epublishTested_24s981_24s1108_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishTested_24s981_24s1108(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144_lam1(V self, V *args); static Clo g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144_lam1, 1, 0};
V g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144_lam2(V self, V *args);
V g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144_lam0(V self, V *args);
Clo g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144_entry, 2, 0};

V g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2eownPackage_24s886_24s1038(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144(a[0], a[1]);
}
V g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144_lam1(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2413;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_x_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_249 = heff_field(v_x_248, 0);
    V v_ru_24x_248_24Just = heff_take_reuse_n(v_x_248, 1ULL, 1);
    V v_t_2410 = (g_heff_2eproject_2ereadPackage(v_src_249));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Left: {
      heff_take_n(v_t_2410, 0ULL, 1);
      heff_drop_cell(v_ru_24x_248_24Just, 1);
      v_x_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2412 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      v_x_2413 = heff_tag_at(v_ru_24x_248_24Just, TAG_Just, 1, (V[]){heff_get(v_p_2412, LBL_heff)});
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V f_ = v_k_241;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_x_242, ((V)&g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144_lam1_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144_lam2, 1, 1, (V[]){v_k_241})});
}
V g_heff_2ecommands_2eload_24s860_24s1032_24s1125_lam2(V self, V *args);
V g_heff_2ecommands_2eload_24s860_24s1032_24s1125_lam1(V self, V *args);
V g_heff_2ecommands_2eload_24s860_24s1032_24s1125_lam0(V self, V *args);
Clo g_heff_2ecommands_2eload_24s860_24s1032_24s1125_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eload_24s860_24s1032_24s1125_entry, 3, 0};

V g_heff_2ecommands_2eload_24s860_24s1032_24s1125(V v_file_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecommands_2ehostNow_24s861_24s1033(heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eload_24s860_24s1032_24s1125_lam0, 1, 3, (V[]){v_file_240, v_hd_241, v_k_242})));
}
V g_heff_2ecommands_2eload_24s860_24s1032_24s1125_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eload_24s860_24s1032_24s1125(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eload_24s860_24s1032_24s1125_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = ({ V a_0 = v_x_246; V a_1 = heff_get(heff_dup(v_x_245), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_246); r_; });
  V v_x_248 = (g_prelude_2efoldl_24s797(v_x_245, v_t_247));
  V f_ = v_k_242;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eload_24s860_24s1032_24s1125_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144(v_hd_241, heff_clo(g_heff_2ecommands_2eload_24s860_24s1032_24s1125_lam2, 1, 2, (V[]){v_x_245, v_k_242})));
}
V g_heff_2ecommands_2eload_24s860_24s1032_24s1125_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_244 = heff_tr(heff_apply(heff_dup(g_heff_2eload_2eloadProgram_24s865_24s1126_get()), 2, (V[]){v_x_243, v_file_240}));
  return heff_tail(v_c_244, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eload_24s860_24s1032_24s1125_lam1, 1, 2, (V[]){v_hd_241, v_k_242})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_str1 = {{0x80000000u, K_STR, 0}, 12, 12, {46, 112, 114, 111, 118, 105, 100, 101, 114, 46, 106, 115}};
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam0, 2, 0};
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam2(V self, V *args); static Clo g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam2, 1, 0};
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam1(V self, V *args);
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam4(V self, V *args);
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam3(V self, V *args);
Clo g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_entry, 2, 0};

V g_heff_2ecommands_2ereadProviderAt_24s899_24s1149(V v_sources_240, V v_m_241) {
top: ;
  V v_t_242 = (g_heff_2ecommands_2epathOfModule(v_sources_240, heff_dup(v_m_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    return ((V)&g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam0_clo);
  }
  case TAG_Just: {
    V v_path_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
    V v_t_247 = heff_strSlice(heff_dup(v_path_245), v_t_246, heff_strLength(heff_dup(v_path_245)));
    V v_t_248 = heff_strEq(v_t_247, ((V)&g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_str0));
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
      v_t_2410 = heff_strSlice(v_path_245, MK_INT(0LL), v_t_249);
      break;
    }
    case TAG_False: {
      v_t_2410 = v_path_245;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_path_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_str1));
    V v_c_2419 = heff_clo(g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam1, 2, 1, (V[]){v_path_2411});
    return heff_clo(g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam3, 2, 2, (V[]){v_c_2419, v_m_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ereadProviderAt_24s899_24s1149(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_path_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam2_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2417}));
  V f_ = heff_get(v_hd_2412, LBL_bind);
  args[0] = v_t_2418;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2424;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    v_x_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2423 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Just = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    v_x_2424 = heff_tag_at(v_ru_24x_2422_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_192_337, (V[]){v_m_241, v_t_2423})});
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V f_ = v_k_2421;
  args[0] = v_x_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo(g_heff_2ecommands_2ereadProviderAt_24s899_24s1149_lam4, 1, 2, (V[]){v_m_241, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ereadProviders_24s898_24s1148_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadProviders_24s898_24s1148_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviders_24s898_24s1148_lam0, 2, 0};
V g_heff_2ecommands_2ereadProviders_24s898_24s1148_lam3(V self, V *args);
V g_heff_2ecommands_2ereadProviders_24s898_24s1148_lam2(V self, V *args);
V g_heff_2ecommands_2ereadProviders_24s898_24s1148_lam1(V self, V *args);
Clo g_heff_2ecommands_2ereadProviders_24s898_24s1148_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviders_24s898_24s1148_entry, 2, 0};

V g_heff_2ecommands_2ereadProviders_24s898_24s1148(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecommands_2ereadProviders_24s898_24s1148_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ecommands_2ereadProviderAt_24s899_24s1149(v_sources_240, v_m_244));
    return heff_clo(g_heff_2ecommands_2ereadProviders_24s898_24s1148_lam1, 2, 3, (V[]){v_c_246, heff_dup(v_sources_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2ereadProviders_24s898_24s1148_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ereadProviders_24s898_24s1148(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ereadProviders_24s898_24s1148_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProviders_24s898_24s1148_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_x_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_x_2413 = heff_tag(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProviders_24s898_24s1148_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = ({ V a_0 = v_sources_240; V a_1 = v_rest_245; V r_ = (g_heff_2ecommands_2ereadProviders_24s898_24s1148(a_0, a_1)); heff_drop(v_sources_240); r_; });
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2ecommands_2ereadProviders_24s898_24s1148_lam3, 1, 2, (V[]){v_x_249, v_k_248})});
}
V g_heff_2ecommands_2ereadProviders_24s898_24s1148_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2ecommands_2ereadProviders_24s898_24s1148_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_lam1(V self, V *args); static Clo g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_lam1, 1, 0};
V g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_lam3(V self, V *args);
V g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_lam2(V self, V *args);
V g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_lam0(V self, V *args);
Clo g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_entry, 5, 0};

V g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151(V v_outPath_240, V v_done_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ecommands_2eemitErrs_24s902(heff_get(heff_dup(v_o_242), LBL_errors), heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_lam0, 1, 5, (V[]){v_o_242, v_outPath_240, v_hd_243, v_done_241, v_k_244})));
}
V g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_lam1(V self, V *args) {
  V v_ok_2410 = args[0];
  return v_ok_2410;
}
V g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2426}));
  return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2427, v_k_244});
}
V g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_outPath_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_True: {
    heff_drop(v_outPath_240);
    return heff_tail(v_done_241, 2, (V[]){v_hd_243, v_k_244});
  }
  case TAG_False: {
    heff_drop(v_done_241);
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_str0), v_outPath_240), ((V)&g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_str1));
    V v_t_2417 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2420}));
    return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2421, heff_clo(g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_lam3, 1, 2, (V[]){v_hd_243, v_k_244})});
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_245);
  V v_t_246 = heff_get(heff_dup(v_o_242), LBL_errors);
  V v_t_249;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    v_t_249 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_246, 0ULL, 2);
    v_t_249 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    V v_t_2411 = heff_tag(TAG_WriteFile, 3, (V[]){heff_dup(v_outPath_240), heff_get(v_o_242, LBL_source), ((V)&g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_lam1_clo)});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2413})}));
    return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_lam2, 1, 4, (V[]){v_done_241, v_hd_243, v_k_244, v_outPath_240})});
  }
  case TAG_False: {
    heff_drop(v_o_242);
    heff_drop(v_outPath_240);
    heff_drop(v_done_241);
    V v_t_2428 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2429 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2431}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2432, v_k_244});
  }
  default: return heff_nomatch(v_t_249);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_lam0(V self, V *args);
V g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_lam1(V self, V *args);
Clo g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_entry, 7, 0};

V g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150(V v_host_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_c_245, V v_available_246) {
top: ;
  V v_t_247 = (g_heff_2edriver_2ecandidatesOf(heff_dup(v_c_245)));
  V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_heff_2edriver_2enubStrD(v_t_248));
  V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_lam0, 1, 1, (V[]){heff_dup(v_available_246)}), v_t_249));
  V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = heff_dup(v_c_245); V a_2 = v_name_242; V r_ = (g_heff_2edriver_2efindRunnable(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Left: {
    V v_why_2413 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    heff_drop(v_host_240);
    heff_drop(v_outPath_243);
    heff_drop(v_done_244);
    heff_drop(v_c_245);
    return heff_clo(g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_lam1, 2, 2, (V[]){v_file_241, v_why_2413});
  }
  case TAG_Right: {
    V v_r_2428 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    heff_drop(v_file_241);
    V v_t_2429 = heff_get(heff_get(v_c_245, LBL_top), LBL_globals);
    V v_t_2430 = (g_heff_2eemit_2ecompileProgram(v_host_240, v_available_246, v_t_2429, heff_get(heff_dup(v_r_2428), LBL_key), heff_get(v_r_2428, LBL_effect)));
    return heff_tail(((V)&g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_clo), 3, (V[]){v_outPath_243, v_done_244, v_t_2430});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[6]); return r;
}
V g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_lam0(V self, V *args) {
  V v_k_2410 = args[0];
  V v_available_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_246; V a_1 = v_k_2410; V r_ = (g_heff_2ecommands_2eprovidesLeaf(a_0, a_1)); heff_drop(v_available_246); r_; });
}
V g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2426}));
  return heff_tail(heff_get(v_hd_2414, LBL_bind), 2, (V[]){v_t_2427, v_k_2415});
}
V g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_file_241 = heff_env(self)[0];
  V v_why_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_str0), heff_strAppend(v_file_241, heff_strAppend(((V)&g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_str1), v_why_2413)));
  V v_t_2417 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2416, ((V)&g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_str2)), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2420}));
  V f_ = heff_get(heff_dup(v_hd_2414), LBL_bind);
  args[0] = v_t_2421;
  args[1] = heff_clo(g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150_lam2, 1, 2, (V[]){v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_str0 = {{0x80000000u, K_STR, 0}, 15, 15, {110, 111, 32, 102, 105, 108, 101, 115, 32, 103, 105, 118, 101, 110, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam0(V self, V *args); static Clo g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam0, 2, 0};
V g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam4(V self, V *args);
V g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam3(V self, V *args);
V g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam2(V self, V *args);
Clo g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_entry, 7, 0};

V g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147(V v_sources_240, V v_host_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_cs_246) {
top: ;
  V v_t_247 = (g_heff_2edriver_2elastChecked(v_cs_246));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_host_241);
    heff_drop(v_file_242);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    return ((V)&g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam0_clo);
  }
  case TAG_Just: {
    V v_c_2421 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_t_2422 = (g_heff_2edriver_2ecandidatesOf(heff_dup(v_c_2421)));
    V v_t_2423 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2422); r_; });
    V v_t_2424 = (g_heff_2edriver_2enubStrD(v_t_2423));
    V v_xs_2425 = (g_prelude_2emap_24s613(v_t_2424));
    V v_t_2426 = (g_heff_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2425));
    V v_c_2427 = (g_heff_2ecommands_2ereadProviders_24s898_24s1148(v_sources_240, v_t_2426));
    return heff_clo(g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam2, 2, 7, (V[]){v_c_2427, v_host_241, v_file_242, v_name_243, v_outPath_244, v_done_245, v_c_2421});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[0]); heff_drop(a[6]); return r;
}
V g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get(v_hd_248, LBL_bind), 2, (V[]){v_t_2420, v_k_249});
}
V g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_t_2410 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_str0), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2413}));
  V f_ = heff_get(heff_dup(v_hd_248), LBL_bind);
  args[0] = v_t_2414;
  args[1] = heff_clo(g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam1, 1, 2, (V[]){v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam4(V self, V *args) {
  V v_p_2431 = args[0];
  V v_host_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_str1), heff_get(v_p_2431, LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2433 = (g_prelude_2emap_24s610(v_t_2432));
  V v_x1_2434 = (g_heff_2eemit_2ecatMaybesL(v_t_2433));
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nil: {
    heff_drop(v_host_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_2435 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 2);
    return heff_strEq(v_x_2435, v_host_241);
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
V g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_host_241 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_outPath_244 = heff_env(self)[3];
  V v_done_245 = heff_env(self)[4];
  V v_c_2421 = heff_env(self)[5];
  V v_hd_2428 = heff_env(self)[6];
  V v_k_2429 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2437 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam4, 1, 1, (V[]){heff_dup(v_host_241)}), v_x_2430));
  V v_t_2438 = ({ V a_0 = v_host_241; V a_1 = v_file_242; V a_2 = v_name_243; V a_3 = v_outPath_244; V a_4 = v_done_245; V a_5 = v_c_2421; V a_6 = v_t_2437; V r_ = heff_tr(g_heff_2ecommands_2ecompileFound_24s900_24s1043_24s1150(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2437); r_; });
  return heff_tail(v_t_2438, 2, (V[]){v_hd_2428, v_k_2429});
}
V g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam2(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  V v_host_241 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_name_243 = heff_env(self)[3];
  V v_outPath_244 = heff_env(self)[4];
  V v_done_245 = heff_env(self)[5];
  V v_c_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2427;
  args[0] = heff_dup(v_hd_2428);
  args[1] = heff_clo(g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147_lam3, 1, 8, (V[]){v_host_241, v_file_242, v_name_243, v_outPath_244, v_done_245, v_c_2421, v_hd_2428, v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam0(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam2(V self, V *args); static Clo g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam2, 1, 0};
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam5(V self, V *args); static Clo g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam5, 2, 0};
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam7(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam6(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam4(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam3(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam1(V self, V *args);
Clo g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_entry, 2, 0};

V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
    return heff_clo(g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_MkPair: {
      V v_top_247 = heff_field(v_x11_245, 0);
      V v_p_248 = heff_field(v_x11_245, 1);
      heff_take_n(v_x11_245, 3ULL, 2);
      return heff_clo(g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam1, 2, 4, (V[]){v_p_248, v_rest_246, v_acc_241, v_top_247});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153(a[0], a[1]);
}
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam2(V self, V *args) {
  V v_ns_2411 = args[0];
  return v_ns_2411;
}
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam5(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam7(V self, V *args) {
  V v_n_2430 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = (g_std_2epath_2eparse(v_x_2417, v_p_248));
  V v_t_2432 = (g_std_2epath_2eparse(v_x_2417, v_n_2430));
  V v_p_2433 = (g_std_2epath_2ejoin_2eonto_240(v_t_2431, v_t_2432));
  V v_t_2434 = ({ V a_0 = heff_get(heff_dup(v_p_2433), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2433), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2435 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2433), LBL_drive), heff_get(v_p_2433, LBL_absolute), v_t_2434});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), ({ V a_0 = v_x_2417; V a_1 = v_t_2435; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2417); r_; })});
}
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_ns_2423 = heff_env(self)[4];
  V v_x_2417 = heff_env(self)[5];
  V v_p_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_True: {
    heff_drop(v_ns_2423);
    heff_drop(v_x_2417);
    heff_drop(v_p_248);
    V v_t_2428 = (g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153(v_rest_246, v_acc_241));
    return heff_tail(v_t_2428, 2, (V[]){v_hd_249, v_k_2410});
  }
  case TAG_False: {
    V v_t_2429 = (g_prelude_2efilter_24s804(v_ns_2423));
    V v_t_2436 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam7, 1, 2, (V[]){v_x_2417, v_p_248}), v_t_2429));
    V v_t_2437 = (g_prelude_2econcatList(v_t_2436, v_rest_246));
    V v_t_2438 = (g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153(v_t_2437, v_acc_241));
    return heff_tail(v_t_2438, 2, (V[]){v_hd_249, v_k_2410});
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  V v_top_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_x_2417);
    heff_drop(v_top_247);
    V v_t_2418 = heff_intSub(heff_strLength(heff_dup(v_p_248)), MK_INT(3LL));
    V v_t_2419 = heff_strSlice(heff_dup(v_p_248), v_t_2418, heff_strLength(heff_dup(v_p_248)));
    V v_t_2420 = heff_strEq(v_t_2419, ((V)&g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_str0));
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      V v_t_2421 = (g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153(v_rest_246, heff_tag(TAG_Cons, 2, (V[]){v_p_248, v_acc_241})));
      return heff_tail(v_t_2421, 2, (V[]){v_hd_249, v_k_2410});
    }
    case TAG_False: {
      heff_drop(v_p_248);
      V v_t_2422 = (g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153(v_rest_246, v_acc_241));
      return heff_tail(v_t_2422, 2, (V[]){v_hd_249, v_k_2410});
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  case TAG_Just: {
    V v_ns_2423 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_c_2426;
    switch (heff_tag_of(v_top_247)) {
    case TAG_True: {
      v_c_2426 = ((V)&g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam5_clo);
      break;
    }
    case TAG_False: {
      v_c_2426 = (g_heff_2eload_2eisRoot_24s869_24s1130(v_x_2417, heff_dup(v_p_248)));
      break;
    }
    default: heff_nomatch(v_top_247);
    }
    return heff_tail(v_c_2426, 2, (V[]){heff_dup(v_hd_249), heff_clo(g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam6, 1, 7, (V[]){v_rest_246, v_acc_241, v_hd_249, v_k_2410, v_ns_2423, v_x_2417, v_p_248})});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  V v_top_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ecommands_2estyleNow_24s863_24s1035(heff_dup(v_hd_249), heff_clo(g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam4, 1, 7, (V[]){v_x_2416, v_p_248, v_rest_246, v_acc_241, v_hd_249, v_k_2410, v_top_247})));
}
V g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_p_248 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_top_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){heff_dup(v_p_248), ((V)&g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam2_clo)})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2414}));
  V f_ = heff_get(heff_dup(v_hd_249), LBL_bind);
  args[0] = v_t_2415;
  args[1] = heff_clo(g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153_lam3, 1, 6, (V[]){v_hd_249, v_p_248, v_rest_246, v_acc_241, v_k_2410, v_top_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[68]; } g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_str1 = {{0x80000000u, K_STR, 0}, 68, 68, {104, 101, 102, 102, 32, 116, 101, 115, 116, 58, 32, 110, 111, 32, 116, 101, 115, 116, 47, 32, 104, 101, 114, 101, 58, 32, 116, 101, 115, 116, 32, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116, 44, 32, 111, 114, 32, 103, 105, 118, 101, 32, 70, 73, 76, 69, 115, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 101, 115, 116}};
V g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam1(V self, V *args); static Clo g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam1, 1, 0};
V g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam4(V self, V *args);
V g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam3(V self, V *args);
V g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam2(V self, V *args);
V g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam0(V self, V *args); static Clo g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam0, 2, 0};
Clo g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_entry, 1, 0};

V g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152(V v_given_240) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam0_clo);
  }
  case TAG_Cons: {
    V v_t_2427 = (g_prelude_2emap_24s813(v_given_240));
    return (g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153(v_t_2427, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152(a[0]);
}
V g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam1(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2420);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2419, heff_clo(g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam4, 1, 1, (V[]){v_k_242})});
}
V g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    V v_t_249 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_str1), NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2412}));
    return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam3, 1, 2, (V[]){v_hd_241, v_k_242})});
  }
  case TAG_Just: {
    heff_take_n(v_x_248, 0ULL, 1);
    V v_t_2422 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_str2)});
    V v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
    V v_t_2424 = (g_heff_2ecommands_2etestFilesGo_24s904_24s1046_24s1153(v_t_2423, NTAG(TAG_Nil)));
    return heff_tail(v_t_2424, 2, (V[]){v_hd_241, v_k_242});
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){((V)&g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_str0), ((V)&g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam1_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_246}));
  V f_ = heff_get(heff_dup(v_hd_241), LBL_bind);
  args[0] = v_t_247;
  args[1] = heff_clo(g_heff_2ecommands_2etestFiles_24s903_24s1045_24s1152_lam2, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163_lam0(V self, V *args); static Clo g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163_lam0, 1, 0};
V g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163_lam1(V self, V *args);
Clo g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163_entry, 5, 0};

V g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163(V v_outPath_240, V v_bad_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag(TAG_WriteFile, 3, (V[]){v_outPath_240, heff_get(heff_dup(v_o_242), LBL_source), ((V)&g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163_lam0_clo)});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_248})}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163_lam1, 1, 4, (V[]){v_o_242, v_hd_243, heff_dup(v_bad_241), v_k_244})});
}
V g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163_lam0(V self, V *args) {
  V v_ok_245 = args[0];
  return v_ok_245;
}
V g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_o_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2411);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_True: {
    switch (heff_tag_of(v_bad_241)) {
    case TAG_True: {
      heff_drop(v_o_242);
      V v_t_2412 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2415}));
      return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2416, v_k_244});
    }
    case TAG_False: {
      V v_t_2417 = heff_get(v_o_242, LBL_errors);
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Nil: {
        heff_drop(v_hd_243);
        V f_ = v_k_244;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        V v_ru_24t_2417_24Cons = heff_take_reuse_n(v_t_2417, 0ULL, 2);
        V v_t_2420 = heff_tag_at(v_ru_24t_2417_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2421 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
        V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
        V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2423}));
        return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2424, v_k_244});
      }
      default: return heff_nomatch(v_t_2417);
      }
    }
    default: return heff_nomatch(v_bad_241);
    }
  }
  case TAG_False: {
    heff_drop(v_bad_241);
    heff_drop(v_o_242);
    V v_t_2425 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2428}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2429, v_k_244});
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_bad_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecommands_2eemitErrs_24s902(heff_get(heff_dup(v_o_242), LBL_errors), heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163_lam2, 1, 5, (V[]){v_x_2410, v_bad_241, v_hd_243, v_k_244, v_o_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ereadProviderC_24s923_24s1168_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2ereadProviderC_24s923_24s1168_str1 = {{0x80000000u, K_STR, 0}, 11, 11, {46, 112, 114, 111, 118, 105, 100, 101, 114, 46, 99}};
V g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam0, 2, 0};
V g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam2(V self, V *args); static Clo g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam2, 1, 0};
V g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam1(V self, V *args);
V g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam4(V self, V *args);
V g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam3(V self, V *args);
Clo g_heff_2ecommands_2ereadProviderC_24s923_24s1168_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderC_24s923_24s1168_entry, 2, 0};

V g_heff_2ecommands_2ereadProviderC_24s923_24s1168(V v_sources_240, V v_m_241) {
top: ;
  V v_t_242 = (g_heff_2ecommands_2epathOfModule(v_sources_240, heff_dup(v_m_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    return ((V)&g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam0_clo);
  }
  case TAG_Just: {
    V v_path_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
    V v_t_247 = heff_strSlice(heff_dup(v_path_245), v_t_246, heff_strLength(heff_dup(v_path_245)));
    V v_t_248 = heff_strEq(v_t_247, ((V)&g_heff_2ecommands_2ereadProviderC_24s923_24s1168_str0));
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
      v_t_2410 = heff_strSlice(v_path_245, MK_INT(0LL), v_t_249);
      break;
    }
    case TAG_False: {
      v_t_2410 = v_path_245;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_path_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2ecommands_2ereadProviderC_24s923_24s1168_str1));
    V v_c_2419 = heff_clo(g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam1, 2, 1, (V[]){v_path_2411});
    return heff_clo(g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam3, 2, 2, (V[]){v_c_2419, v_m_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecommands_2ereadProviderC_24s923_24s1168_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ereadProviderC_24s923_24s1168(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_path_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam2_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2417}));
  V f_ = heff_get(v_hd_2412, LBL_bind);
  args[0] = v_t_2418;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2424;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    v_x_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2423 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Just = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    v_x_2424 = heff_tag_at(v_ru_24x_2422_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_192_337, (V[]){v_m_241, v_t_2423})});
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V f_ = v_k_2421;
  args[0] = v_x_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo(g_heff_2ecommands_2ereadProviderC_24s923_24s1168_lam4, 1, 2, (V[]){v_m_241, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_lam0, 2, 0};
V g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_lam3(V self, V *args);
V g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_lam2(V self, V *args);
V g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_lam1(V self, V *args);
Clo g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_entry, 2, 0};

V g_heff_2ecommands_2ereadProvidersC_24s922_24s1167(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ecommands_2ereadProviderC_24s923_24s1168(v_sources_240, v_m_244));
    return heff_clo(g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_lam1, 2, 3, (V[]){v_c_246, heff_dup(v_sources_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ereadProvidersC_24s922_24s1167(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_x_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_x_2413 = heff_tag(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = ({ V a_0 = v_sources_240; V a_1 = v_rest_245; V r_ = (g_heff_2ecommands_2ereadProvidersC_24s922_24s1167(a_0, a_1)); heff_drop(v_sources_240); r_; });
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_lam3, 1, 2, (V[]){v_x_249, v_k_248})});
}
V g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2ecommands_2ereadProvidersC_24s922_24s1167_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_lam2(V self, V *args); static Clo g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_lam2, 1, 0};
V g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_lam1(V self, V *args);
V g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_lam3(V self, V *args);
V g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_lam0(V self, V *args);
Clo g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_entry, 4, 0};

V g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_name_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      return (g_heff_2ecommands_2estyleNow_24s863_24s1035(heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_lam0, 1, 6, (V[]){v_dir_240, heff_dup(v_name_246), heff_dup(v_text_247), v_p_242, heff_dup(v_rest_245), v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_lam2(V self, V *args) {
  V v_ok_2417 = args[0];
  return v_ok_2417;
}
V g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_path_2414 = heff_env(self)[0];
  V v_text_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){v_path_2414, v_text_247, ((V)&g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_lam2_clo)})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2415), LBL_malg), 1, (V[]){v_t_2420}));
  V f_ = heff_get(v_hd_2415, LBL_bind);
  args[0] = v_t_2421;
  args[1] = v_k2_2416;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_True: {
    return ({ V a_0 = v_dir_240; V a_1 = v_rest_245; V a_2 = v_p_242; V a_3 = v_p_243; V r_ = (g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
  }
  case TAG_False: {
    heff_drop(v_dir_240);
    heff_drop(v_rest_245);
    heff_drop(v_p_242);
    V f_ = v_p_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_name_246 = heff_env(self)[1];
  V v_text_247 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_249 = (g_std_2epath_2eparse(v_x_248, heff_dup(v_dir_240)));
  V v_t_2410 = (g_std_2epath_2eparse(v_x_248, v_name_246));
  V v_p_2411 = (g_std_2epath_2ejoin_2eonto_240(v_t_249, v_t_2410));
  V v_t_2412 = ({ V a_0 = heff_get(heff_dup(v_p_2411), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2411), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2413 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2411), LBL_drive), heff_get(v_p_2411, LBL_absolute), v_t_2412});
  V v_path_2414 = ({ V a_0 = v_x_248; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_248); r_; });
  V v_c_2422 = heff_clo(g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_lam1, 2, 2, (V[]){v_path_2414, v_text_247});
  return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171_lam3, 1, 4, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam1(V self, V *args); static Clo g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam1, 1, 0};
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam3(V self, V *args); static Clo g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam3, 1, 0};
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam6(V self, V *args);
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam5(V self, V *args);
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam4(V self, V *args);
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam2(V self, V *args);
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam0(V self, V *args);
Clo g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_entry, 5, 0};

V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170(V v_dir_240, V v_done_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_parts_245 = heff_field(v_x3_242, 0);
    V v_errors_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    return (g_heff_2ecommands_2eemitErrs_24s902(heff_dup(v_errors_246), heff_dup(v_p_243), heff_clo(g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam0, 1, 6, (V[]){v_errors_246, v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam1(V self, V *args) {
  V v_ok_2411 = args[0];
  return v_ok_2411;
}
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam3(V self, V *args) {
  V v_ok_2417 = args[0];
  return v_ok_2417;
}
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2434}));
  return heff_tail(heff_get(v_p_243, LBL_bind), 2, (V[]){v_t_2435, v_p_244});
}
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_True: {
    heff_drop(v_dir_240);
    return heff_tail(v_done_241, 2, (V[]){v_p_243, v_p_244});
  }
  case TAG_False: {
    heff_drop(v_done_241);
    V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_str0), v_dir_240), ((V)&g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_str1));
    V v_t_2425 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2424, NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2428}));
    return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2429, heff_clo(g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam6, 1, 2, (V[]){v_p_243, v_p_244})});
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2422);
  return ({ V a_0 = heff_dup(v_dir_240); V a_1 = v_parts_245; V a_2 = heff_dup(v_p_243); V a_3 = heff_clo(g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam5, 1, 4, (V[]){v_done_241, v_p_243, v_p_244, v_dir_240}); V r_ = (g_heff_2ecommands_2ewritePartsGo_24s927_24s1063_24s1171(a_0, a_1, a_2, a_3)); heff_drop(v_parts_245); r_; });
}
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_parts_245 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2416);
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){heff_dup(v_dir_240), ((V)&g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam3_clo)})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2420}));
  return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2421, heff_clo(g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam4, 1, 5, (V[]){v_dir_240, v_parts_245, v_p_243, v_done_241, v_p_244})});
}
V g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_errors_246 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_parts_245 = heff_env(self)[3];
  V v_done_241 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_247);
  V v_t_2410;
  switch (heff_tag_of(v_errors_246)) {
  case TAG_Nil: {
    v_t_2410 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_errors_246, 0ULL, 2);
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_errors_246);
  }
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){heff_dup(v_dir_240), ((V)&g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam1_clo)})});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2414}));
    return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2415, heff_clo(g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_lam2, 1, 5, (V[]){v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})});
  }
  case TAG_False: {
    heff_drop(v_dir_240);
    heff_drop(v_parts_245);
    heff_drop(v_done_241);
    V v_t_2436 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2437 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2439}));
    return heff_tail(heff_get(v_p_243, LBL_bind), 2, (V[]){v_t_2440, v_p_244});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
V g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_lam0(V self, V *args);
V g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_lam1(V self, V *args);
Clo g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_entry, 7, 0};

V g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169(V v_file_240, V v_name_241, V v_outPath_242, V v_runtime_243, V v_done_244, V v_c_245, V v_available_246) {
top: ;
  V v_t_247 = (g_heff_2edriver_2ecandidatesOf(heff_dup(v_c_245)));
  V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_heff_2edriver_2enubStrD(v_t_248));
  V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_lam0, 1, 1, (V[]){heff_dup(v_available_246)}), v_t_249));
  V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = heff_dup(v_c_245); V a_2 = v_name_241; V r_ = (g_heff_2edriver_2efindRunnable(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Left: {
    V v_why_2413 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    heff_drop(v_outPath_242);
    heff_drop(v_runtime_243);
    heff_drop(v_done_244);
    heff_drop(v_c_245);
    heff_drop(v_available_246);
    return heff_clo(g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_lam1, 2, 2, (V[]){v_file_240, v_why_2413});
  }
  case TAG_Right: {
    V v_r_2428 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    heff_drop(v_file_240);
    V v_t_2429 = heff_intSub(heff_strLength(heff_dup(v_outPath_242)), MK_INT(1LL));
    V v_t_2430 = heff_strSlice(heff_dup(v_outPath_242), v_t_2429, heff_strLength(heff_dup(v_outPath_242)));
    V v_t_2431 = heff_strEq(v_t_2430, ((V)&g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_str3));
    switch (heff_tag_of(v_t_2431)) {
    case TAG_True: {
      V v_t_2432 = heff_intSub(heff_strLength(heff_dup(v_outPath_242)), MK_INT(1LL));
      V v_t_2433 = heff_get(heff_get(v_c_245, LBL_top), LBL_globals);
      V v_l_2434 = (g_heff_2elower_2elowerProgramAnf(v_t_2433, heff_get(heff_dup(v_r_2428), LBL_key)));
      V v_t_2435 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2erunEnd_clo), 1, (V[]){heff_get(v_r_2428, LBL_effect)}));
      V v_t_2436 = heff_rec(2, shape_253_83, (V[]){NTAG(TAG_Nil), v_t_2435});
      V v_t_2437 = (g_heff_2eemitc_2eprogramParts(v_runtime_243, v_available_246, v_t_2436, heff_get(heff_dup(v_l_2434), LBL_defs)));
      V v_t_2438 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2437, heff_get(v_l_2434, LBL_errors)});
      return heff_tail(((V)&g_heff_2ecommands_2ewriteParts_24s926_24s1062_24s1170_clo), 3, (V[]){heff_strSlice(v_outPath_242, MK_INT(0LL), v_t_2432), v_done_244, v_t_2438});
    }
    case TAG_False: {
      V v_t_2439 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2erunEnd_clo), 1, (V[]){heff_get(heff_dup(v_r_2428), LBL_effect)}));
      V v_t_2440 = heff_rec(2, shape_253_83, (V[]){NTAG(TAG_Nil), v_t_2439});
      V v_t_2441 = heff_get(heff_get(v_c_245, LBL_top), LBL_globals);
      V v_t_2442 = (g_heff_2elower_2elowerProgramAnf(v_t_2441, heff_get(v_r_2428, LBL_key)));
      V v_t_2443 = (g_heff_2eemitc_2eoutputOf(v_runtime_243, v_available_246, v_t_2440, v_t_2442));
      return heff_tail(((V)&g_heff_2ecommands_2ewriteOut_24s901_24s1044_24s1151_clo), 3, (V[]){v_outPath_242, v_done_244, v_t_2443});
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_lam0(V self, V *args) {
  V v_k_2410 = args[0];
  V v_available_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_246; V a_1 = v_k_2410; V r_ = (g_heff_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_246); r_; });
}
V g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2426}));
  return heff_tail(heff_get(v_hd_2414, LBL_bind), 2, (V[]){v_t_2427, v_k_2415});
}
V g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_file_240 = heff_env(self)[0];
  V v_why_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_str0), heff_strAppend(v_file_240, heff_strAppend(((V)&g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_str1), v_why_2413)));
  V v_t_2417 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2416, ((V)&g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_str2)), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2420}));
  V f_ = heff_get(heff_dup(v_hd_2414), LBL_bind);
  args[0] = v_t_2421;
  args[1] = heff_clo(g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169_lam2, 1, 2, (V[]){v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_str1 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 117, 110, 116, 105, 109, 101, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 117, 110, 116, 105, 109, 101, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_str4 = {{0x80000000u, K_STR, 0}, 22, 22, {104, 101, 102, 102, 58, 32, 110, 111, 32, 67, 32, 114, 117, 110, 116, 105, 109, 101, 32, 97, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam3(V self, V *args); static Clo g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam3, 1, 0};
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam2(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam5(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam7(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam6(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam4(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam1(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam0(V self, V *args);
Clo g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_entry, 2, 0};

V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2elibDir_24s862_24s1034(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172(a[0], a[1]);
}
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam3(V self, V *args) {
  V v_t_2418 = args[0];
  return v_t_2418;
}
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k2_2417 = args[1];
  V v_path_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2415, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam3_clo)})});
  V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2416), LBL_malg), 1, (V[]){v_t_2421}));
  V f_ = heff_get(v_hd_2416, LBL_bind);
  args[0] = v_t_2422;
  args[1] = v_k2_2417;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam5(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k2_2439 = args[1];
  V v_str_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2437, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_str5)), NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2438), LBL_malg), 1, (V[]){v_t_2443}));
  V f_ = heff_get(v_hd_2438, LBL_bind);
  args[0] = v_t_2444;
  args[1] = v_k2_2439;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam7(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2452);
  V f_ = v_k_241;
  args[0] = ((V)&g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_str6);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam6(V self, V *args) {
  V v_x_2446 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2446);
  V v_t_2447 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2448 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2450}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2451, heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam7, 1, 1, (V[]){v_k_241})});
}
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Nothing: {
    V v_t_2425 = (g_std_2epath_2eparse(v_x_243, v_x_242));
    V v_t_2426 = (g_std_2epath_2eparse(v_x_243, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_str2)));
    V v_p_2427 = (g_std_2epath_2ejoin_2eonto_240(v_t_2425, v_t_2426));
    V v_t_2428 = ({ V a_0 = heff_get(heff_dup(v_p_2427), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2427), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2429 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2427), LBL_drive), heff_get(v_p_2427, LBL_absolute), v_t_2428});
    V v_a_2430 = (g_std_2epath_2erender(v_x_243, v_t_2429));
    V v_t_2431 = (g_std_2epath_2eparse(v_x_243, v_a_2430));
    V v_t_2432 = (g_std_2epath_2eparse(v_x_243, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_str3)));
    V v_p_2433 = (g_std_2epath_2ejoin_2eonto_240(v_t_2431, v_t_2432));
    V v_t_2434 = ({ V a_0 = heff_get(heff_dup(v_p_2433), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2433), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2435 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2433), LBL_drive), heff_get(v_p_2433, LBL_absolute), v_t_2434});
    V v_t_2436 = ({ V a_0 = v_x_243; V a_1 = v_t_2435; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_243); r_; });
    V v_str_2437 = heff_strAppend(((V)&g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_str4), v_t_2436);
    V v_c_2445 = heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam5, 2, 1, (V[]){v_str_2437});
    return heff_tail(v_c_2445, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam6, 1, 2, (V[]){v_hd_240, v_k_241})});
  }
  case TAG_Just: {
    V v_text_2453 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    heff_drop(v_x_243);
    heff_drop(v_x_242);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_text_2453;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = (g_std_2epath_2eparse(v_x_243, heff_dup(v_x_242)));
  V v_t_245 = (g_std_2epath_2eparse(v_x_243, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_str0)));
  V v_p_246 = (g_std_2epath_2ejoin_2eonto_240(v_t_244, v_t_245));
  V v_t_247 = ({ V a_0 = heff_get(heff_dup(v_p_246), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_246), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_248 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_246), LBL_drive), heff_get(v_p_246, LBL_absolute), v_t_247});
  V v_a_249 = (g_std_2epath_2erender(v_x_243, v_t_248));
  V v_t_2410 = (g_std_2epath_2eparse(v_x_243, v_a_249));
  V v_t_2411 = (g_std_2epath_2eparse(v_x_243, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_str1)));
  V v_p_2412 = (g_std_2epath_2ejoin_2eonto_240(v_t_2410, v_t_2411));
  V v_t_2413 = ({ V a_0 = heff_get(heff_dup(v_p_2412), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2412), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2414 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2412), LBL_drive), heff_get(v_p_2412, LBL_absolute), v_t_2413});
  V v_path_2415 = (g_std_2epath_2erender(v_x_243, v_t_2414));
  V v_c_2423 = heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam2, 2, 1, (V[]){v_path_2415});
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam4, 1, 4, (V[]){v_x_243, v_x_242, v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecommands_2estyleNow_24s863_24s1035(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172_lam1, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_str0 = {{0x80000000u, K_STR, 0}, 15, 15, {110, 111, 32, 102, 105, 108, 101, 115, 32, 103, 105, 118, 101, 110, 10}};
V g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam0(V self, V *args); static Clo g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam0, 2, 0};
V g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam4(V self, V *args);
V g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam3(V self, V *args);
V g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam2(V self, V *args);
Clo g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_entry, 6, 0};

V g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166(V v_sources_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_cs_245) {
top: ;
  V v_t_246 = (g_heff_2edriver_2elastChecked(v_cs_245));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_file_241);
    heff_drop(v_name_242);
    heff_drop(v_outPath_243);
    heff_drop(v_done_244);
    return ((V)&g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam0_clo);
  }
  case TAG_Just: {
    V v_c_2420 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    V v_t_2421 = (g_heff_2edriver_2ecandidatesOf(heff_dup(v_c_2420)));
    V v_t_2422 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2421); r_; });
    V v_t_2423 = (g_heff_2edriver_2enubStrD(v_t_2422));
    V v_xs_2424 = (g_prelude_2emap_24s613(v_t_2423));
    V v_t_2425 = (g_heff_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2424));
    V v_c_2426 = (g_heff_2ecommands_2ereadProvidersC_24s922_24s1167(v_sources_240, v_t_2425));
    return heff_clo(g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam2, 2, 6, (V[]){v_c_2426, v_name_242, v_c_2420, v_outPath_243, v_file_241, v_done_244});
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); heff_drop(a[5]); return r;
}
V g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2419, v_k_248});
}
V g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_t_249 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_str0), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2412}));
  V f_ = heff_get(heff_dup(v_hd_247), LBL_bind);
  args[0] = v_t_2413;
  args[1] = heff_clo(g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam1, 1, 2, (V[]){v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_name_242 = heff_env(self)[0];
  V v_c_2420 = heff_env(self)[1];
  V v_outPath_243 = heff_env(self)[2];
  V v_hd_2427 = heff_env(self)[3];
  V v_k_2428 = heff_env(self)[4];
  V v_file_241 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_x_2429 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_name_242)) {
  case TAG_Nothing: {
    heff_drop(v_file_241);
    heff_drop(v_done_244);
    heff_drop(v_x_2429);
    V v_exports_2431 = (g_prelude_2emap_24s800(heff_get(heff_dup(v_c_2420), LBL_own)));
    V v_roots_2432 = (g_prelude_2emap_24s513(heff_dup(v_exports_2431)));
    V v_t_2433 = heff_get(heff_get(v_c_2420, LBL_top), LBL_globals);
    V v_t_2434 = (g_heff_2eerase_2eeraseProgram(v_t_2433));
    V v_t_2435 = (g_heff_2elower_2eanfLowered(v_roots_2432, v_t_2434));
    V v_t_2436 = (g_heff_2eemitc_2echeckOut(v_x_2430, v_exports_2431, v_t_2435));
    return ({ V a_0 = v_outPath_243; V b_1 = NTAG(TAG_False); V a_2 = v_t_2436; V a_3 = v_hd_2427; V a_4 = v_k_2428; V r_ = (g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  }
  case TAG_Just: {
    V v_t_2438 = heff_tr(g_heff_2ecommands_2ecompileFoundC_24s925_24s1061_24s1169(v_file_241, v_name_242, v_outPath_243, v_x_2430, v_done_244, v_c_2420, v_x_2429));
    return heff_tail(v_t_2438, 2, (V[]){v_hd_2427, v_k_2428});
  }
  default: return heff_nomatch(v_name_242);
  }
}
V g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2427 = heff_env(self)[0];
  V v_name_242 = heff_env(self)[1];
  V v_c_2420 = heff_env(self)[2];
  V v_outPath_243 = heff_env(self)[3];
  V v_k_2428 = heff_env(self)[4];
  V v_file_241 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ecommands_2ereadRuntimeC_24s924_24s1060_24s1172(heff_dup(v_hd_2427), heff_clo(g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam4, 1, 8, (V[]){v_name_242, v_c_2420, v_outPath_243, v_hd_2427, v_k_2428, v_file_241, v_done_244, v_x_2429})));
}
V g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam2(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  V v_name_242 = heff_env(self)[1];
  V v_c_2420 = heff_env(self)[2];
  V v_outPath_243 = heff_env(self)[3];
  V v_file_241 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2426;
  args[0] = heff_dup(v_hd_2427);
  args[1] = heff_clo(g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166_lam3, 1, 7, (V[]){v_hd_2427, v_name_242, v_c_2420, v_outPath_243, v_k_2428, v_file_241, v_done_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2efmtSrc_24s935_24s1178_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2efmtSrc_24s935_24s1178_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 110, 111, 116, 32, 102, 111, 114, 109, 97, 116, 116, 101, 100, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efmtSrc_24s935_24s1178_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efmtSrc_24s935_24s1178_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam1(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam0(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam2(V self, V *args); static Clo g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam2, 2, 0};
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam4(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam3(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam6(V self, V *args); static Clo g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam6, 1, 0};
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam7(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam5(V self, V *args);
Clo g_heff_2ecommands_2efmtSrc_24s935_24s1178_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtSrc_24s935_24s1178_entry, 4, 0};

V g_heff_2ecommands_2efmtSrc_24s935_24s1178(V v_checkOnly_240, V v_f_241, V v_src_242, V v_fix_243) {
top: ;
  V v_t_244 = (g_heff_2efmt_2elayout_2eformatUncheckedIn(v_fix_243, heff_dup(v_src_242)));
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Left: {
    V v_why_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Left = heff_take_reuse_n(v_t_244, 1ULL, 1);
    v_t_247 = heff_tag_at(v_ru_24t_244_24Left, TAG_Left, 1, (V[]){v_why_245});
    break;
  }
  case TAG_Right: {
    V v_out_246 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_t_247 = (g_heff_2eformat_2echeck(heff_dup(v_src_242), v_out_246));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_Left: {
    V v_why_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    heff_drop(v_src_242);
    return heff_clo(g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam0, 2, 2, (V[]){v_f_241, v_why_248});
  }
  case TAG_Right: {
    V v_out_2418 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_t_2419 = heff_strEq(heff_dup(v_out_2418), v_src_242);
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      heff_drop(v_f_241);
      heff_drop(v_out_2418);
      return ((V)&g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam2_clo);
    }
    case TAG_False: {
      switch (heff_tag_of(v_checkOnly_240)) {
      case TAG_True: {
        heff_drop(v_out_2418);
        return heff_clo(g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam3, 2, 1, (V[]){v_f_241});
      }
      case TAG_False: {
        return heff_clo(g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam5, 2, 2, (V[]){v_f_241, v_out_2418});
      }
      default: return heff_nomatch(v_checkOnly_240);
      }
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2efmtSrc_24s935_24s1178(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2417);
  V f_ = v_k_2410;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_f_241 = heff_env(self)[0];
  V v_why_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecommands_2efmtSrc_24s935_24s1178_str0), heff_strAppend(v_f_241, heff_strAppend(((V)&g_heff_2ecommands_2efmtSrc_24s935_24s1178_str1), v_why_248)));
  V v_t_2412 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ecommands_2efmtSrc_24s935_24s1178_str2)), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2415}));
  V f_ = heff_get(v_hd_249, LBL_bind);
  args[0] = v_t_2416;
  args[1] = heff_clo(g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam1, 1, 1, (V[]){v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2429);
  V f_ = v_k_2423;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_f_241, ((V)&g_heff_2ecommands_2efmtSrc_24s935_24s1178_str3)), NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2422), LBL_malg), 1, (V[]){v_t_2427}));
  V f_ = heff_get(v_hd_2422, LBL_bind);
  args[0] = v_t_2428;
  args[1] = heff_clo(g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam4, 1, 1, (V[]){v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam6(V self, V *args) {
  V v_ok_2432 = args[0];
  return v_ok_2432;
}
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2437);
  V f_ = v_k_2431;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam5(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_f_241 = heff_env(self)[0];
  V v_out_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){v_f_241, v_out_2418, ((V)&g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam6_clo)})});
  V v_t_2434 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2430), LBL_malg), 1, (V[]){v_t_2435}));
  V f_ = heff_get(v_hd_2430, LBL_bind);
  args[0] = v_t_2436;
  args[1] = heff_clo(g_heff_2ecommands_2efmtSrc_24s935_24s1178_lam7, 1, 1, (V[]){v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_str0 = {{0x80000000u, K_STR, 0}, 18, 18, {104, 101, 102, 102, 58, 32, 99, 97, 110, 110, 111, 116, 32, 114, 101, 97, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_lam0(V self, V *args); static Clo g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_lam0, 1, 0};
V g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_lam2(V self, V *args);
V g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_lam3(V self, V *args);
V g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_lam1(V self, V *args);
Clo g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_entry, 4, 0};

V g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177(V v_checkOnly_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){heff_dup(v_f_241), ((V)&g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_lam0_clo)})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_lam1, 1, 4, (V[]){v_f_241, v_hd_242, v_k_243, heff_dup(v_checkOnly_240)})});
}
V g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_lam0(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2416);
  V f_ = v_k_243;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_src_2417 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2419 = (g_heff_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get(v_x_2418, LBL_sources)));
  V v_t_2420 = ({ V a_0 = v_checkOnly_240; V a_1 = v_f_241; V a_2 = v_src_2417; V a_3 = v_t_2419; V r_ = (g_heff_2ecommands_2efmtSrc_24s935_24s1178(a_0, a_1, a_2, a_3)); heff_drop(v_checkOnly_240); r_; });
  return heff_tail(v_t_2420, 2, (V[]){v_hd_242, v_k_243});
}
V g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_checkOnly_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop(v_checkOnly_240);
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_str0), v_f_241), ((V)&g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_str1));
    V v_t_2411 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2414}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2415, heff_clo(g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_lam2, 1, 1, (V[]){v_k_243})});
  }
  case TAG_Just: {
    V v_src_2417 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    return (g_heff_2ecommands_2eload_24s860_24s1032_24s1125(heff_dup(v_f_241), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177_lam3, 1, 5, (V[]){v_checkOnly_240, v_f_241, v_src_2417, v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2ecommands_2efmtAll_24s933_24s1067_24s1176_lam0(V self, V *args);
Clo g_heff_2ecommands_2efmtAll_24s933_24s1067_24s1176_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtAll_24s933_24s1067_24s1176_entry, 5, 0};

V g_heff_2ecommands_2efmtAll_24s933_24s1067_24s1176(V v_checkOnly_240, V v_x2_241, V v_bad_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_bad_242});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    return (g_heff_2ecommands_2efmtOne_24s934_24s1068_24s1177(v_checkOnly_240, heff_dup(v_f_245), heff_dup(v_p_243), heff_clo(g_heff_2ecommands_2efmtAll_24s933_24s1067_24s1176_lam0, 1, 5, (V[]){heff_dup(v_checkOnly_240), heff_dup(v_rest_246), v_bad_242, v_p_243, v_p_244})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2efmtAll_24s933_24s1067_24s1176_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2efmtAll_24s933_24s1067_24s1176(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2efmtAll_24s933_24s1067_24s1176_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_bad_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_checkOnly_240; V a_1 = v_rest_246; V a_2 = heff_intAdd(v_bad_242, v_x_247); V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ecommands_2efmtAll_24s933_24s1067_24s1176(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_checkOnly_240); heff_drop(v_rest_246); r_; });
}
V g_heff_2ecommands_2efmtCmd_24s932_24s1066_24s1175_lam0(V self, V *args);
Clo g_heff_2ecommands_2efmtCmd_24s932_24s1066_24s1175_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtCmd_24s932_24s1066_24s1175_entry, 4, 0};

V g_heff_2ecommands_2efmtCmd_24s932_24s1066_24s1175(V v_check_240, V v_files_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecommands_2efmtAll_24s933_24s1067_24s1176(v_check_240, v_files_241, MK_INT(0LL), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2efmtCmd_24s932_24s1066_24s1175_lam0, 1, 2, (V[]){v_hd_242, v_k_243})));
}
V g_heff_2ecommands_2efmtCmd_24s932_24s1066_24s1175_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2efmtCmd_24s932_24s1066_24s1175(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2efmtCmd_24s932_24s1066_24s1175_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_intLt(MK_INT(0LL), v_x_244);
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    V v_t_246 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2410, v_k_243});
  }
  case TAG_False: {
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_245);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_str1 = {{0x80000000u, K_STR, 0}, 19, 19, {104, 101, 102, 102, 58, 32, 99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam2(V self, V *args); static Clo g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam2, 1, 0};
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam1(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam5(V self, V *args); static Clo g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam5, 1, 0};
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam4(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam7(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam8(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam6(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam3(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam0(V self, V *args);
Clo g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_entry, 4, 0};

V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      return (g_heff_2ecommands_2estyleNow_24s863_24s1035(heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam0, 1, 6, (V[]){v_dir_240, v_f_246, v_p_242, v_text_247, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam2(V self, V *args) {
  V v_ok_2423 = args[0];
  return v_ok_2423;
}
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam1(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_path_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_2420, ((V)&g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam2_clo)})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2421), LBL_malg), 1, (V[]){v_t_2426}));
  V f_ = heff_get(v_hd_2421, LBL_bind);
  args[0] = v_t_2427;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam5(V self, V *args) {
  V v_ok_2445 = args[0];
  return v_ok_2445;
}
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam4(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_path_2435 = heff_env(self)[0];
  V v_str_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){v_path_2435, v_str_2442, ((V)&g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam5_clo)})});
  V v_t_2447 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2443), LBL_malg), 1, (V[]){v_t_2448}));
  V f_ = heff_get(v_hd_2443, LBL_bind);
  args[0] = v_t_2449;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam7(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k2_2460 = args[1];
  V v_str_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2461 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2458, ((V)&g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_str2)), NTAG(TAG_MkUnit)});
  V v_t_2462 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2459), LBL_malg), 1, (V[]){v_t_2464}));
  V f_ = heff_get(v_hd_2459, LBL_bind);
  args[0] = v_t_2465;
  args[1] = v_k2_2460;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam8(V self, V *args) {
  V v_x_2467 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2467);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam6(V self, V *args) {
  V v_x_2451 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_x_248 = heff_env(self)[5];
  V v_f_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2452;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_True: {
    v_t_2452 = v_x_2451;
    break;
  }
  case TAG_False: {
    heff_drop(v_x_2451);
    v_t_2452 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  switch (heff_tag_of(v_t_2452)) {
  case TAG_True: {
    heff_drop(v_x_248);
    heff_drop(v_f_246);
    return (g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181(v_dir_240, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_False: {
    heff_drop(v_rest_245);
    V v_t_2453 = (g_std_2epath_2eparse(v_x_248, v_dir_240));
    V v_t_2454 = (g_std_2epath_2eparse(v_x_248, v_f_246));
    V v_p_2455 = (g_std_2epath_2ejoin_2eonto_240(v_t_2453, v_t_2454));
    V v_t_2456 = ({ V a_0 = heff_get(heff_dup(v_p_2455), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2455), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2457 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2455), LBL_drive), heff_get(v_p_2455, LBL_absolute), v_t_2456});
    V v_str_2458 = heff_strAppend(((V)&g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_str1), ({ V a_0 = v_x_248; V a_1 = v_t_2457; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_248); r_; }));
    V v_c_2466 = heff_clo(g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam7, 2, 1, (V[]){v_str_2458});
    return heff_tail(v_c_2466, 2, (V[]){v_p_242, heff_clo(g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam8, 1, 1, (V[]){v_p_243})});
  }
  default: return heff_nomatch(v_t_2452);
  }
}
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2430 = (g_std_2epath_2eparse(v_x_248, heff_dup(v_dir_240)));
  V v_t_2431 = (g_std_2epath_2eparse(v_x_248, heff_dup(v_f_246)));
  V v_p_2432 = (g_std_2epath_2ejoin_2eonto_240(v_t_2430, v_t_2431));
  V v_t_2433 = ({ V a_0 = heff_get(heff_dup(v_p_2432), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2432), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2434 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2432), LBL_drive), heff_get(v_p_2432, LBL_absolute), v_t_2433});
  V v_path_2435 = (g_std_2epath_2erender(v_x_248, v_t_2434));
  V v_t_2436 = heff_intSub(heff_strLength(heff_dup(v_f_246)), MK_INT(3LL));
  V v_t_2437 = heff_strSlice(heff_dup(v_f_246), v_t_2436, heff_strLength(heff_dup(v_f_246)));
  V v_t_2438 = heff_strEq(v_t_2437, ((V)&g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_str0));
  V v_str_2442;
  switch (heff_tag_of(v_t_2438)) {
  case TAG_True: {
    V v_t_2439 = (g_heff_2eformat_2eformat(heff_dup(v_text_247)));
    switch (heff_tag_of(v_t_2439)) {
    case TAG_Left: {
      heff_take_n(v_t_2439, 0ULL, 1);
      v_str_2442 = v_text_247;
      break;
    }
    case TAG_Right: {
      V v_out_2441 = heff_field(v_t_2439, 0);
      heff_take_n(v_t_2439, 1ULL, 1);
      heff_drop(v_text_247);
      v_str_2442 = v_out_2441;
      break;
    }
    default: heff_nomatch(v_t_2439);
    }
    break;
  }
  case TAG_False: {
    v_str_2442 = v_text_247;
    break;
  }
  default: heff_nomatch(v_t_2438);
  }
  V v_c_2450 = heff_clo(g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam4, 2, 2, (V[]){v_path_2435, v_str_2442});
  return heff_tail(v_c_2450, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam6, 1, 7, (V[]){v_x_2429, v_dir_240, v_rest_245, v_p_242, v_p_243, v_x_248, v_f_246})});
}
V g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_249 = (g_std_2epath_2eparse(v_x_248, heff_dup(v_dir_240)));
  V v_t_2410 = (g_std_2epath_2eparse(v_x_248, heff_dup(v_f_246)));
  V v_p_2411 = (g_std_2epath_2ejoin_2eonto_240(v_t_249, v_t_2410));
  V v_t_2412 = ({ V a_0 = heff_get(heff_dup(v_p_2411), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2411), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2413 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2411), LBL_drive), heff_get(v_p_2411, LBL_absolute), v_t_2412});
  V v_s_2414 = (g_std_2epath_2erender(v_x_248, v_t_2413));
  V v_p_2415 = (g_std_2epath_2eparse(v_x_248, v_s_2414));
  V v_t_2416 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2415), LBL_segments)));
  V v_xs_2417 = (g_prelude_2edrop(MK_INT(1LL), v_t_2416));
  V v_t_2418 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2417));
  V v_t_2419 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2415), LBL_drive), heff_get(v_p_2415, LBL_absolute), v_t_2418});
  V v_path_2420 = (g_std_2epath_2erender(v_x_248, v_t_2419));
  V v_c_2428 = heff_clo(g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam1, 2, 1, (V[]){v_path_2420});
  return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181_lam3, 1, 7, (V[]){v_x_248, v_dir_240, v_f_246, v_text_247, v_p_242, v_rest_245, v_p_243})});
}
V g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam2(V self, V *args); static Clo g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam2, 1, 0};
V g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam1(V self, V *args);
V g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam4(V self, V *args);
V g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam3(V self, V *args);
V g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam0(V self, V *args);
Clo g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_entry, 4, 0};

V g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      heff_take_n(v_x21_244, 1ULL, 2);
      return (g_heff_2ecommands_2estyleNow_24s863_24s1035(heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam0, 1, 5, (V[]){v_dir_240, v_f_246, v_p_242, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam2(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_path_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2414, ((V)&g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam2_clo)})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2415), LBL_malg), 1, (V[]){v_t_2420}));
  V f_ = heff_get(v_hd_2415, LBL_bind);
  args[0] = v_t_2421;
  args[1] = v_k2_2416;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Nothing: {
    heff_drop(v_f_246);
    V f_ = v_p_243;
    args[0] = v_x_2424;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    heff_take_n(v_x_2423, 0ULL, 1);
    V f_ = v_p_243;
    args[0] = heff_tag(TAG_Cons, 2, (V[]){v_f_246, v_x_2424});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_f_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182(v_dir_240, v_rest_245, v_p_242, heff_clo(g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam4, 1, 3, (V[]){v_x_2423, v_p_243, v_f_246})));
}
V g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = (g_std_2epath_2eparse(v_x_248, heff_dup(v_dir_240)));
  V v_t_2410 = (g_std_2epath_2eparse(v_x_248, heff_dup(v_f_246)));
  V v_p_2411 = (g_std_2epath_2ejoin_2eonto_240(v_t_249, v_t_2410));
  V v_t_2412 = ({ V a_0 = heff_get(heff_dup(v_p_2411), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2411), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2413 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2411), LBL_drive), heff_get(v_p_2411, LBL_absolute), v_t_2412});
  V v_path_2414 = ({ V a_0 = v_x_248; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_248); r_; });
  V v_c_2422 = heff_clo(g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam1, 2, 1, (V[]){v_path_2414});
  return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182_lam3, 1, 5, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243, v_f_246})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {80, 87, 68}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {48, 46, 49, 46, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {104, 101, 102, 102, 58, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[73]; } g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str3 = {{0x80000000u, K_STR, 0}, 73, 73, {96, 32, 99, 97, 110, 110, 111, 116, 32, 110, 97, 109, 101, 32, 97, 32, 112, 97, 99, 107, 97, 103, 101, 58, 32, 97, 32, 108, 111, 119, 101, 114, 99, 97, 115, 101, 32, 108, 101, 116, 116, 101, 114, 44, 32, 116, 104, 101, 110, 32, 108, 101, 116, 116, 101, 114, 115, 44, 32, 100, 105, 103, 105, 116, 115, 32, 97, 110, 100, 32, 96, 95, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str5 = {{0x80000000u, K_STR, 0}, 23, 23, {104, 101, 102, 102, 58, 32, 97, 32, 110, 101, 119, 32, 112, 114, 111, 106, 101, 99, 116, 32, 105, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[56]; } g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str6 = {{0x80000000u, K_STR, 0}, 56, 56, {59, 32, 116, 104, 101, 114, 101, 44, 32, 96, 104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 96, 32, 98, 117, 105, 108, 100, 115, 32, 105, 116, 32, 97, 110, 100, 32, 96, 104, 101, 102, 102, 32, 116, 101, 115, 116, 96, 32, 116, 101, 115, 116, 115, 32, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str9 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str10 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 104, 97, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str11 = {{0x80000000u, K_STR, 0}, 25, 25, {32, 97, 108, 114, 101, 97, 100, 121, 59, 32, 110, 111, 116, 104, 105, 110, 103, 32, 119, 114, 105, 116, 116, 101, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam0(V self, V *args); static Clo g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam0, 1, 0};
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam4(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam6(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam9(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam10(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam11(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam12(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam8(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam7(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam5(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam3(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam2(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam1(V self, V *args);
Clo g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_entry, 3, 0};

V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str0), ((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam0_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam1, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242})});
}
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam0(V self, V *args) {
  V v_v_243 = args[0];
  return v_v_243;
}
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam4(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam6(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_x_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam9(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2432);
  V v_t_2433 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2436}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2437, v_k_242});
}
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam10(V self, V *args) {
  V v_x_2438 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2438)) {
  case TAG_True: {
    V v_t_2439 = heff_strAppend(((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str5), heff_strAppend(v_dir_240, ((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str6)));
    V v_t_2440 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2439, ((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str7)), NTAG(TAG_MkUnit)});
    V v_t_2441 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2443}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2444, v_k_242});
  }
  case TAG_False: {
    heff_drop(v_dir_240);
    V v_t_2445 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2446 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2448}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2449, v_k_242});
  }
  default: return heff_nomatch(v_x_2438);
  }
}
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam11(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_str_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2455, ((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str12)), NTAG(TAG_MkUnit)});
  V v_t_2459 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2456), LBL_malg), 1, (V[]){v_t_2461}));
  V f_ = heff_get(v_hd_2456, LBL_bind);
  args[0] = v_t_2462;
  args[1] = v_k2_2457;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam12(V self, V *args) {
  V v_x_2464 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2464);
  V v_t_2465 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2466 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2468}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2469, v_k_242});
}
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam8(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  V v_x_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2424 = (g_heff_2eproject_2eisName(heff_dup(v_x_2415)));
  V v_t_2425;
  switch (heff_tag_of(v_x1_2424)) {
  case TAG_True: {
    v_t_2425 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2425 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_2424);
  }
  switch (heff_tag_of(v_t_2425)) {
  case TAG_True: {
    heff_drop(v_x_2423);
    heff_drop(v_dir_240);
    heff_drop(v_x_2422);
    V v_t_2426 = heff_strAppend(((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str2), heff_strAppend(v_x_2415, ((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str3)));
    V v_t_2427 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2426, ((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str4)), NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2430}));
    return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2431, heff_clo(g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam9, 1, 2, (V[]){v_hd_241, v_k_242})});
  }
  case TAG_False: {
    heff_drop(v_x_2415);
    switch (heff_tag_of(v_x_2423)) {
    case TAG_Nil: {
      return (g_heff_2ecommands_2ewriteAll_24s939_24s1072_24s1181(heff_dup(v_dir_240), v_x_2422, heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam10, 1, 3, (V[]){v_dir_240, v_hd_241, v_k_242})));
    }
    case TAG_Cons: {
      heff_drop(v_x_2422);
      V v_t_2454;
      switch (heff_tag_of(v_x_2423)) {
      case TAG_Nil: {
        v_t_2454 = ((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str8);
        break;
      }
      case TAG_Cons: {
        V v_x_2452 = heff_field(v_x_2423, 0);
        V v_xs_2453 = heff_field(v_x_2423, 1);
        heff_take_n(v_x_2423, 3ULL, 2);
        v_t_2454 = ({ V a_0 = v_x_2452; V a_1 = v_xs_2453; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2453); r_; });
        break;
      }
      default: heff_nomatch(v_x_2423);
      }
      V v_str_2455 = heff_strAppend(((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str9), heff_strAppend(v_dir_240, heff_strAppend(((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str10), heff_strAppend(v_t_2454, ((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str11)))));
      V v_c_2463 = heff_clo(g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam11, 2, 1, (V[]){v_str_2455});
      return heff_tail(v_c_2463, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam12, 1, 2, (V[]){v_hd_241, v_k_242})});
    }
    default: return heff_nomatch(v_x_2423);
    }
  }
  default: return heff_nomatch(v_t_2425);
  }
}
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam7(V self, V *args) {
  V v_x_2422 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecommands_2eexisting_24s938_24s1071_24s1182(heff_dup(v_dir_240), heff_dup(v_x_2422), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam8, 1, 5, (V[]){v_x_2415, v_hd_241, v_k_242, v_dir_240, v_x_2422})));
}
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2417;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_t_2417 = ((V)&g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2416 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_t_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_x_2418 = (g_heff_2ecommands_2eprojectFiles(heff_dup(v_x_2415), v_t_2417));
  V v_c_2421 = heff_clo(g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam6, 2, 1, (V[]){v_x_2418});
  return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam7, 1, 4, (V[]){v_dir_240, v_hd_241, v_x_2415, v_k_242})});
}
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2411 = ({ V a_0 = v_x_2410; V a_1 = heff_dup(v_dir_240); V a_2 = v_x_248; V r_ = (g_heff_2ecommands_2eprojectName(a_0, a_1, a_2)); heff_drop(v_x_2410); r_; });
  V v_c_2414 = heff_clo(g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam4, 2, 1, (V[]){v_x_2411});
  return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam5, 1, 4, (V[]){v_x_249, v_hd_241, v_dir_240, v_k_242})});
}
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecommands_2estyleNow_24s863_24s1035(heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam3, 1, 5, (V[]){v_dir_240, v_x_248, v_hd_241, v_x_249, v_k_242})));
}
V g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2eownVersion_24s885_24s1037_24s1144(heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s937_24s1070_24s1180_lam2, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_248, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2esumsOf_24s945_24s1187_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 97, 115, 104}};
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam0(V self, V *args); static Clo g_heff_2ecommands_2esumsOf_24s945_24s1187_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2esumsOf_24s945_24s1187_lam0, 2, 0};
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam4(V self, V *args); static Clo g_heff_2ecommands_2esumsOf_24s945_24s1187_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2esumsOf_24s945_24s1187_lam4, 1, 0};
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam3(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam6(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam7(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam5(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam2(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam1(V self, V *args);
Clo g_heff_2ecommands_2esumsOf_24s945_24s1187_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2esumsOf_24s945_24s1187_entry, 3, 0};

V g_heff_2ecommands_2esumsOf_24s945_24s1187(V v_ps_240, V v_root_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_root_241);
    return ((V)&g_heff_2ecommands_2esumsOf_24s945_24s1187_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = (g_heff_2ecommands_2esumsOf_24s945_24s1187(heff_dup(v_ps_240), heff_dup(v_root_241), v_rest_246));
    return heff_clo(g_heff_2ecommands_2esumsOf_24s945_24s1187_lam1, 2, 4, (V[]){v_c_247, v_ps_240, v_x_245, v_root_241});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2esumsOf_24s945_24s1187_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2esumsOf_24s945_24s1187(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam4(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam3(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_path_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2412, ((V)&g_heff_2ecommands_2esumsOf_24s945_24s1187_lam4_clo)})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2413, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam6(V self, V *args) {
  V v_r_2422 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_r_2422, LBL_path), heff_get(v_x_245, LBL_path));
}
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam7(V self, V *args) {
  V v_p_2432 = args[0];
  V v_r_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_p_2432, LBL_name), heff_get(v_r_2430, LBL_name));
}
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2423 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2esumsOf_24s945_24s1187_lam6, 1, 1, (V[]){heff_dup(v_x_245)}), heff_get(heff_dup(v_root_241), LBL_require)));
  V v_x_2442;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Nil: {
    heff_drop(v_root_241);
    switch (heff_tag_of(v_x_2421)) {
    case TAG_Nothing: {
      heff_drop(v_x_245);
      v_x_2442 = v_x_2410;
      break;
    }
    case TAG_Just: {
      V v_t_2424 = heff_field(v_x_2421, 0);
      heff_take_n(v_x_2421, 1ULL, 1);
      V v_t_2425 = (g_prelude_2eskipSpaces(heff_dup(v_t_2424), MK_INT(0LL), MK_INT(1LL)));
      V v_t_2426 = heff_intSub(heff_strLength(heff_dup(v_t_2424)), MK_INT(1LL));
      V v_t_2427 = (g_prelude_2eskipSpaces(heff_dup(v_t_2424), v_t_2426, MK_INT(-1LL)));
      V v_t_2428 = heff_strSlice(v_t_2424, v_t_2425, heff_intAdd(v_t_2427, MK_INT(1LL)));
      V v_t_2429 = heff_rec(3, shape_239_370_121, (V[]){heff_get(heff_dup(v_x_245), LBL_path), heff_get(v_x_245, LBL_version), v_t_2428});
      v_x_2442 = heff_tag(TAG_Cons, 2, (V[]){v_t_2429, v_x_2410});
      break;
    }
    default: heff_nomatch(v_x_2421);
    }
    break;
  }
  case TAG_Cons: {
    V v_r_2430 = heff_field(v_t_2423, 0);
    V v_ru_24t_2423_24Cons = heff_take_reuse_n(v_t_2423, 1ULL, 2);
    V v_t_2433 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2esumsOf_24s945_24s1187_lam7, 1, 1, (V[]){v_r_2430}), heff_get(v_root_241, LBL_replace)));
    switch (heff_tag_of(v_t_2433)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_x_2421)) {
      case TAG_Nothing: {
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24t_2423_24Cons, 2);
        v_x_2442 = v_x_2410;
        break;
      }
      case TAG_Just: {
        V v_t_2434 = heff_field(v_x_2421, 0);
        heff_take_n(v_x_2421, 1ULL, 1);
        V v_t_2435 = (g_prelude_2eskipSpaces(heff_dup(v_t_2434), MK_INT(0LL), MK_INT(1LL)));
        V v_t_2436 = heff_intSub(heff_strLength(heff_dup(v_t_2434)), MK_INT(1LL));
        V v_t_2437 = (g_prelude_2eskipSpaces(heff_dup(v_t_2434), v_t_2436, MK_INT(-1LL)));
        V v_t_2438 = heff_strSlice(v_t_2434, v_t_2435, heff_intAdd(v_t_2437, MK_INT(1LL)));
        V v_t_2439 = heff_rec(3, shape_239_370_121, (V[]){heff_get(heff_dup(v_x_245), LBL_path), heff_get(v_x_245, LBL_version), v_t_2438});
        v_x_2442 = heff_tag_at(v_ru_24t_2423_24Cons, TAG_Cons, 2, (V[]){v_t_2439, v_x_2410});
        break;
      }
      default: heff_nomatch(v_x_2421);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2433, 0ULL, 2);
      heff_drop(v_x_2421);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24t_2423_24Cons, 2);
      v_x_2442 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_t_2433);
    }
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V f_ = v_k_249;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = (g_heff_2eload_2ecachedDir(v_ps_240, heff_get(heff_dup(v_x_245), LBL_path), heff_get(heff_dup(v_x_245), LBL_version)));
  V v_path_2412 = heff_strAppend(v_t_2411, ((V)&g_heff_2ecommands_2esumsOf_24s945_24s1187_str0));
  V v_c_2420 = heff_clo(g_heff_2ecommands_2esumsOf_24s945_24s1187_lam3, 2, 1, (V[]){v_path_2412});
  return heff_tail(v_c_2420, 2, (V[]){v_hd_248, heff_clo(g_heff_2ecommands_2esumsOf_24s945_24s1187_lam5, 1, 4, (V[]){v_x_245, v_root_241, v_x_2410, v_k_249})});
}
V g_heff_2ecommands_2esumsOf_24s945_24s1187_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo(g_heff_2ecommands_2esumsOf_24s945_24s1187_lam2, 1, 5, (V[]){v_ps_240, v_x_245, v_hd_248, v_root_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
V g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam0(V self, V *args);
V g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam2(V self, V *args); static Clo g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam2, 1, 0};
V g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam5(V self, V *args);
V g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam4(V self, V *args);
V g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam3(V self, V *args);
V g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam1(V self, V *args);
Clo g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_entry, 2, 0};

V g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
    return heff_clo(g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return heff_clo(g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam1, 2, 3, (V[]){v_p_245, v_rest_246, v_acc_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191(a[0], a[1]);
}
V g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam2(V self, V *args) {
  V v_ns_249 = args[0];
  return v_ns_249;
}
V g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam5(V self, V *args) {
  V v_n_2423 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = (g_std_2epath_2eparse(v_x_2421, v_p_245));
  V v_t_2425 = (g_std_2epath_2eparse(v_x_2421, v_n_2423));
  V v_p_2426 = (g_std_2epath_2ejoin_2eonto_240(v_t_2424, v_t_2425));
  V v_t_2427 = ({ V a_0 = heff_get(heff_dup(v_p_2426), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2426), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2428 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2426), LBL_drive), heff_get(v_p_2426, LBL_absolute), v_t_2427});
  return ({ V a_0 = v_x_2421; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2421); r_; });
}
V g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_ns_2420 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = (g_prelude_2efilter_24s804(v_ns_2420));
  V v_t_2429 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam5, 1, 2, (V[]){v_x_2421, v_p_245}), v_t_2422));
  V v_t_2430 = (g_prelude_2econcatList(v_t_2429, v_rest_246));
  V v_t_2431 = (g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191(v_t_2430, v_acc_241));
  return heff_tail(v_t_2431, 2, (V[]){v_hd_247, v_k_248});
}
V g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    V v_t_2415 = heff_intSub(heff_strLength(heff_dup(v_p_245)), MK_INT(3LL));
    V v_t_2416 = heff_strSlice(heff_dup(v_p_245), v_t_2415, heff_strLength(heff_dup(v_p_245)));
    V v_t_2417 = heff_strEq(v_t_2416, ((V)&g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_str0));
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      V v_t_2418 = (g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191(v_rest_246, heff_tag(TAG_Cons, 2, (V[]){v_p_245, v_acc_241})));
      return heff_tail(v_t_2418, 2, (V[]){v_hd_247, v_k_248});
    }
    case TAG_False: {
      heff_drop(v_p_245);
      V v_t_2419 = (g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191(v_rest_246, v_acc_241));
      return heff_tail(v_t_2419, 2, (V[]){v_hd_247, v_k_248});
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  case TAG_Just: {
    V v_ns_2420 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    return (g_heff_2ecommands_2estyleNow_24s863_24s1035(heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam4, 1, 6, (V[]){v_ns_2420, v_p_245, v_rest_246, v_acc_241, v_hd_247, v_k_248})));
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){heff_dup(v_p_245), ((V)&g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam2_clo)})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2412}));
  V f_ = heff_get(heff_dup(v_hd_247), LBL_bind);
  args[0] = v_t_2413;
  args[1] = heff_clo(g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191_lam3, 1, 5, (V[]){v_p_245, v_rest_246, v_acc_241, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eisThere_24s957_24s1195_lam0(V self, V *args); static Clo g_heff_2ecommands_2eisThere_24s957_24s1195_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eisThere_24s957_24s1195_lam0, 1, 0};
V g_heff_2ecommands_2eisThere_24s957_24s1195_lam2(V self, V *args); static Clo g_heff_2ecommands_2eisThere_24s957_24s1195_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eisThere_24s957_24s1195_lam2, 1, 0};
V g_heff_2ecommands_2eisThere_24s957_24s1195_lam3(V self, V *args);
V g_heff_2ecommands_2eisThere_24s957_24s1195_lam1(V self, V *args);
Clo g_heff_2ecommands_2eisThere_24s957_24s1195_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eisThere_24s957_24s1195_entry, 3, 0};

V g_heff_2ecommands_2eisThere_24s957_24s1195(V v_path_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){heff_dup(v_path_240), ((V)&g_heff_2ecommands_2eisThere_24s957_24s1195_lam0_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2eisThere_24s957_24s1195_lam1, 1, 3, (V[]){v_path_240, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2eisThere_24s957_24s1195_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eisThere_24s957_24s1195(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eisThere_24s957_24s1195_lam0(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ecommands_2eisThere_24s957_24s1195_lam2(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ecommands_2eisThere_24s957_24s1195_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2416;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    v_x_2416 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2414, 0ULL, 1);
    v_x_2416 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V f_ = v_k_242;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eisThere_24s957_24s1195_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_240, ((V)&g_heff_2ecommands_2eisThere_24s957_24s1195_lam2_clo)})});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2412}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2ecommands_2eisThere_24s957_24s1195_lam3, 1, 1, (V[]){v_k_242})});
  }
  case TAG_Just: {
    heff_take_n(v_x_248, 0ULL, 1);
    heff_drop(v_path_240);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2ecommands_2enotInProject_24s956_24s1194_lam0(V self, V *args); static Clo g_heff_2ecommands_2enotInProject_24s956_24s1194_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enotInProject_24s956_24s1194_lam0, 2, 0};
V g_heff_2ecommands_2enotInProject_24s956_24s1194_lam3(V self, V *args);
V g_heff_2ecommands_2enotInProject_24s956_24s1194_lam2(V self, V *args);
V g_heff_2ecommands_2enotInProject_24s956_24s1194_lam1(V self, V *args);
Clo g_heff_2ecommands_2enotInProject_24s956_24s1194_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enotInProject_24s956_24s1194_entry, 3, 0};

V g_heff_2ecommands_2enotInProject_24s956_24s1194(V v_st_240, V v_t_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    return ((V)&g_heff_2ecommands_2enotInProject_24s956_24s1194_lam0_clo);
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_root)));
    V v_t_248 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
    V v_p_249 = (g_std_2epath_2ejoin_2eonto_240(v_t_247, v_t_248));
    V v_t_2410 = ({ V a_0 = heff_get(heff_dup(v_p_249), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_249), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2411 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_249), LBL_drive), heff_get(v_p_249, LBL_absolute), v_t_2410});
    V v_t_2412 = (g_std_2epath_2erender(v_st_240, v_t_2411));
    V v_c_2413 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eisThere_24s957_24s1195_clo), 1, (V[]){v_t_2412}));
    return heff_clo(g_heff_2ecommands_2enotInProject_24s956_24s1194_lam1, 2, 5, (V[]){v_c_2413, heff_dup(v_st_240), v_t_241, v_rest_246, v_n_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2enotInProject_24s956_24s1194_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2enotInProject_24s956_24s1194(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2enotInProject_24s956_24s1194_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2enotInProject_24s956_24s1194_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_n_245 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2419;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_True: {
    heff_drop(v_n_245);
    v_x_2419 = v_x_2418;
    break;
  }
  case TAG_False: {
    v_x_2419 = heff_tag(TAG_Cons, 2, (V[]){v_n_245, v_x_2418});
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V f_ = v_k_2415;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2enotInProject_24s956_24s1194_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2414 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_k_2415 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2417 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_rest_246; V r_ = (g_heff_2ecommands_2enotInProject_24s956_24s1194(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  return heff_tail(v_c_2417, 2, (V[]){v_hd_2414, heff_clo(g_heff_2ecommands_2enotInProject_24s956_24s1194_lam3, 1, 3, (V[]){v_x_2416, v_n_245, v_k_2415})});
}
V g_heff_2ecommands_2enotInProject_24s956_24s1194_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo(g_heff_2ecommands_2enotInProject_24s956_24s1194_lam2, 1, 6, (V[]){v_st_240, v_t_241, v_rest_246, v_hd_2414, v_n_245, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eappRead_24s955_24s1193_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {98, 117, 105, 108, 100, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eappRead_24s955_24s1193_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eappRead_24s955_24s1193_lam0(V self, V *args);
V g_heff_2ecommands_2eappRead_24s955_24s1193_lam1(V self, V *args);
V g_heff_2ecommands_2eappRead_24s955_24s1193_lam3(V self, V *args);
V g_heff_2ecommands_2eappRead_24s955_24s1193_lam2(V self, V *args);
V g_heff_2ecommands_2eappRead_24s955_24s1193_lam5(V self, V *args);
V g_heff_2ecommands_2eappRead_24s955_24s1193_lam4(V self, V *args);
Clo g_heff_2ecommands_2eappRead_24s955_24s1193_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eappRead_24s955_24s1193_entry, 5, 0};

V g_heff_2ecommands_2eappRead_24s955_24s1193(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    heff_drop(v_x_243);
    return heff_clo(g_heff_2ecommands_2eappRead_24s955_24s1193_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Just: {
    V v_text_247 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V v_t_248 = (g_heff_2eproject_2ereadBuild(heff_dup(v_text_247)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Left: {
      V v_p_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      V v_t_2410 = (g_heff_2ecommands_2eappFile(v_st_240, v_t_241, v_x_243, ((V)&g_heff_2ecommands_2eappRead_24s955_24s1193_str0)));
      V v_str_2411 = (g_heff_2eload_2eproblemMsg(v_t_2410, v_text_247, v_p_249));
      V v_c_2419 = heff_clo(g_heff_2ecommands_2eappRead_24s955_24s1193_lam1, 2, 1, (V[]){v_str_2411});
      return heff_clo(g_heff_2ecommands_2eappRead_24s955_24s1193_lam2, 2, 2, (V[]){v_c_2419, v_acc_242});
    }
    case TAG_Right: {
      V v_a_2425 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      heff_drop(v_text_247);
      V v_c_2426 = (g_heff_2ecommands_2enotInProject_24s956_24s1194(v_st_240, heff_dup(v_t_241), heff_get(heff_dup(v_a_2425), LBL_ships)));
      return heff_clo(g_heff_2ecommands_2eappRead_24s955_24s1193_lam4, 2, 6, (V[]){v_c_2426, heff_dup(v_st_240), v_t_241, v_acc_242, v_x_243, v_a_2425});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecommands_2eappRead_24s955_24s1193_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eappRead_24s955_24s1193(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eappRead_24s955_24s1193_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eappRead_24s955_24s1193_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_str_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2411, ((V)&g_heff_2ecommands_2eappRead_24s955_24s1193_str1)), NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2417}));
  V f_ = heff_get(v_hd_2412, LBL_bind);
  args[0] = v_t_2418;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eappRead_24s955_24s1193_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_intAdd(heff_get(heff_dup(v_acc_242), LBL_bad), MK_INT(1LL));
  V v_t_2424 = heff_rec(2, shape_11_19, (V[]){heff_get(v_acc_242, LBL_apps), v_t_2423});
  V f_ = v_k_2421;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eappRead_24s955_24s1193_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo(g_heff_2ecommands_2eappRead_24s955_24s1193_lam3, 1, 2, (V[]){v_acc_242, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eappRead_24s955_24s1193_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_a_2425 = heff_env(self)[4];
  V v_hd_2427 = heff_env(self)[5];
  V v_k_2428 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2430 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_acc_242; V a_3 = v_x_243; V a_4 = v_a_2425; V a_5 = v_x_2429; V r_ = (g_heff_2ecommands_2eappShips_24s958(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_st_240); r_; });
  return heff_tail(v_t_2430, 2, (V[]){v_hd_2427, v_k_2428});
}
V g_heff_2ecommands_2eappRead_24s955_24s1193_lam4(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_a_2425 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2426;
  args[0] = heff_dup(v_hd_2427);
  args[1] = heff_clo(g_heff_2ecommands_2eappRead_24s955_24s1193_lam5, 1, 7, (V[]){v_st_240, v_t_241, v_acc_242, v_x_243, v_a_2425, v_hd_2427, v_k_2428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {99, 97, 110, 110, 111, 116, 32, 112, 117, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_str3 = {{0x80000000u, K_STR, 0}, 13, 13, {32, 105, 110, 32, 112, 108, 97, 99, 101, 32, 111, 102, 32}};
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam0(V self, V *args); static Clo g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam0, 1, 0};
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam2(V self, V *args);
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam1(V self, V *args);
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam3(V self, V *args); static Clo g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam3, 1, 0};
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam5(V self, V *args); static Clo g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam5, 1, 0};
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam6(V self, V *args);
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam4(V self, V *args);
Clo g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_entry, 8, 0};

V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200(V v_t_240, V v_fresh_241, V v_old_242, V v_to_243, V v_next_244, V v_x6_245, V v_p_246, V v_p_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_True: {
    heff_drop(v_fresh_241);
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){v_old_242, ((V)&g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam0_clo)})});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2411}));
    return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam1, 1, 5, (V[]){v_t_240, v_to_243, v_p_246, v_next_244, v_p_247})});
  }
  case TAG_False: {
    heff_drop(v_t_240);
    heff_drop(v_next_244);
    V v_t_2422 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Move, 3, (V[]){v_old_242, heff_dup(v_to_243), ((V)&g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam3_clo)})});
    V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2424}));
    return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2425, heff_clo(g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam4, 1, 4, (V[]){v_fresh_241, v_p_246, v_to_243, v_p_247})});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[5]); return r;
}
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam0(V self, V *args) {
  V v_ok_248 = args[0];
  return v_ok_248;
}
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2420);
  return heff_tail(v_next_244, 2, (V[]){v_p_246, v_p_247});
}
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_next_244 = heff_env(self)[3];
  V v_p_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2413);
  V v_t_2414 = heff_strAppend(heff_get(v_t_240, LBL_said), heff_strAppend(((V)&g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_str0), v_to_243));
  V v_t_2415 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2414, ((V)&g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_str1)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2419, heff_clo(g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam2, 1, 3, (V[]){v_next_244, v_p_246, v_p_247})});
}
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam3(V self, V *args) {
  V v_ok_2421 = args[0];
  return v_ok_2421;
}
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam5(V self, V *args) {
  V v_ok_2427 = args[0];
  return v_ok_2427;
}
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2432);
  V v_t_2433 = heff_strAppend(((V)&g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_str2), heff_strAppend(v_fresh_241, heff_strAppend(((V)&g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_str3), v_to_243)));
  return (g_heff_2ecommands_2eshipFails_24s965_24s1091(v_t_2433, v_p_246, v_p_247));
}
V g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_to_243 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2426);
  V v_t_2428 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){heff_dup(v_fresh_241), ((V)&g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam5_clo)})});
  V v_t_2429 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2430}));
  return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2431, heff_clo(g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200_lam6, 1, 4, (V[]){v_fresh_241, v_to_243, v_p_246, v_p_247})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_str0 = {{0x80000000u, K_STR, 0}, 23, 23, {110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32, 116, 104, 101, 114, 101, 32, 105, 115, 32, 110, 111, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_str1 = {{0x80000000u, K_STR, 0}, 11, 11, {110, 111, 116, 32, 107, 110, 111, 119, 110, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {104, 101, 102, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_str3 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 32, 118, 101, 114, 115, 105, 111, 110, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_lam1(V self, V *args); static Clo g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_lam1, 1, 0};
V g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_lam3(V self, V *args);
V g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_lam2(V self, V *args);
V g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_lam0(V self, V *args);
Clo g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_entry, 2, 0};

V g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2eownPackage_24s886_24s1038(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241(a[0], a[1]);
}
V g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_lam1(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2423);
  V v_t_2424 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2427}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2428, v_k_241});
}
V g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_t_2415 = heff_tag(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_str0), v_x_242)});
    break;
  }
  case TAG_Just: {
    V v_src_249 = heff_field(v_x_248, 0);
    V v_ru_24x_248_24Just = heff_take_reuse_n(v_x_248, 1ULL, 1);
    V v_x3_2410 = (g_heff_2eproject_2ereadPackage(heff_dup(v_src_249)));
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Left: {
      V v_p_2411 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      V v_t_2412 = heff_strAppend(((V)&g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_str1), (g_heff_2eload_2eproblemMsg(v_x_242, v_src_249, v_p_2411)));
      v_t_2415 = heff_tag_at(v_ru_24x_248_24Just, TAG_Left, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_Right: {
      V v_p_2413 = heff_field(v_x3_2410, 0);
      heff_take_n(v_x3_2410, 1ULL, 1);
      heff_drop(v_x_242);
      heff_drop(v_src_249);
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_str2), heff_get(v_p_2413, LBL_heff));
      v_t_2415 = heff_tag_at(v_ru_24x_248_24Just, TAG_Right, 1, (V[]){v_t_2414});
      break;
    }
    default: heff_nomatch(v_x3_2410);
    }
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Left: {
    V v_why_2416 = heff_field(v_t_2415, 0);
    V v_ru_24t_2415_24Left = heff_take_reuse_n(v_t_2415, 1ULL, 1);
    V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_str3), v_why_2416), ((V)&g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_str4));
    V v_t_2418 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2417, NTAG(TAG_MkUnit)});
    V v_t_2419 = heff_tag_at(v_ru_24t_2415_24Left, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2421}));
    return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2422, heff_clo(g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_lam3, 1, 2, (V[]){v_hd_240, v_k_241})});
  }
  case TAG_Right: {
    V v_line_2429 = heff_field(v_t_2415, 0);
    V v_ru_24t_2415_24Right = heff_take_reuse_n(v_t_2415, 1ULL, 1);
    V v_t_2430 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_line_2429, ((V)&g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_str5)), NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_at(v_ru_24t_2415_24Right, TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2433}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2434, v_k_241});
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){heff_dup(v_x_242), ((V)&g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_lam1_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2eversionCmd_24s1021_24s1112_24s1241_lam2, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_str0 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 97, 110, 110, 111, 116, 32, 114, 101, 97, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 105, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam0, 1, 0};
V g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam3(V self, V *args);
V g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam2(V self, V *args);
V g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam5(V self, V *args);
V g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam4(V self, V *args);
V g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam1(V self, V *args);
Clo g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_entry, 3, 0};

V g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_path_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag_at(v_ru_24x1_240_24Cons, TAG_ReadFile, 2, (V[]){heff_dup(v_path_243), ((V)&g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam0_clo)})});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_248}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam1, 1, 4, (V[]){v_path_243, v_p_241, v_p_242, v_rest_244})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam0(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_p_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2423);
  V f_ = v_p_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2417);
  V v_t_2418 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_2421}));
  return heff_tail(heff_get(v_p_241, LBL_bind), 2, (V[]){v_t_2422, heff_clo(g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam3, 1, 1, (V[]){v_p_242})});
}
V g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_path_243 = heff_env(self)[1];
  V v_src_2424 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2428 = (g_heff_2eload_2emoduleOf(heff_rec(5, shape_283_317_174_191_327, (V[]){((V)&g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_str2), ((V)&g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_str3), ((V)&g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_str4), ((V)&g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_str5), v_x_2425}), heff_dup(v_path_243)));
  V v_t_2429 = heff_rec(4, shape_192_239_311_272, (V[]){v_t_2428, v_path_243, v_src_2424, NTAG(TAG_Nil)});
  V v_x_2430 = heff_tag(TAG_Cons, 2, (V[]){v_t_2429, v_x_2427});
  V f_ = v_p_242;
  args[0] = v_x_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  V v_src_2424 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2426 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_clo), 1, (V[]){v_rest_244}));
  return heff_tail(v_c_2426, 2, (V[]){v_p_241, heff_clo(g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam5, 1, 4, (V[]){v_x_2425, v_path_243, v_src_2424, v_p_242})});
}
V g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_path_243 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_rest_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_drop(v_rest_244);
    V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_str0), v_path_243), ((V)&g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_str1));
    V v_t_2412 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_2415}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_2416, heff_clo(g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam2, 1, 2, (V[]){v_p_241, v_p_242})});
  }
  case TAG_Just: {
    V v_src_2424 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    return (g_heff_2ecommands_2estyleNow_24s863_24s1035(heff_dup(v_p_241), heff_clo(g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243_lam4, 1, 5, (V[]){v_rest_244, v_p_241, v_path_243, v_src_2424, v_p_242})));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ecommands_2eselfcheck_24s1022_24s1113_24s1242_lam1(V self, V *args);
V g_heff_2ecommands_2eselfcheck_24s1022_24s1113_24s1242_lam0(V self, V *args);
Clo g_heff_2ecommands_2eselfcheck_24s1022_24s1113_24s1242_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eselfcheck_24s1022_24s1113_24s1242_entry, 3, 0};

V g_heff_2ecommands_2eselfcheck_24s1022_24s1113_24s1242(V v_paths_240, V v_hd_241, V v_k_242) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2ereadAll_24s1023_24s1114_24s1243(v_paths_240, heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eselfcheck_24s1022_24s1113_24s1242_lam0, 1, 2, (V[]){v_hd_241, v_k_242}));
}
V g_heff_2ecommands_2eselfcheck_24s1022_24s1113_24s1242_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eselfcheck_24s1022_24s1113_24s1242(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eselfcheck_24s1022_24s1113_24s1242_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_intEq(v_x_246, MK_INT(0LL));
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_248 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2411}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2412, v_k_242});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecommands_2eselfcheck_24s1022_24s1113_24s1242_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = (g_prelude_2efoldl_24s481(NTAG(TAG_Nil), v_x_243));
  V v_c_245 = ({ V a_0 = v_t_244; V a_1 = MK_INT(0LL); V r_ = (g_heff_2ecommands_2eprintAll_24s1024(a_0, a_1)); heff_drop(v_t_244); r_; });
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eselfcheck_24s1022_24s1113_24s1242_lam1, 1, 2, (V[]){v_k_242, v_hd_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eputFileDiags_24s894_24s1249_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam0(V self, V *args); static Clo g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam0, 1, 0};
V g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam2(V self, V *args); static Clo g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam2, 2, 0};
V g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam3(V self, V *args);
V g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam4(V self, V *args);
V g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam5(V self, V *args);
V g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam1(V self, V *args);
Clo g_heff_2ecommands_2eputFileDiags_24s894_24s1249_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eputFileDiags_24s894_24s1249_entry, 3, 0};

V g_heff_2ecommands_2eputFileDiags_24s894_24s1249(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ErrColor, 1, (V[]){((V)&g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam0_clo)})});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam1, 1, 4, (V[]){v_c_243, v_p_241, v_rest_244, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eputFileDiags_24s894_24s1249_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eputFileDiags_24s894_24s1249(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam0(V self, V *args) {
  V v_b_245 = args[0];
  return v_b_245;
}
V g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam3(V self, V *args) {
  V v_d_2416 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_x_249; V a_1 = heff_get(heff_dup(v_c_243), LBL_path); V a_2 = heff_get(v_c_243, LBL_source); V a_3 = v_d_2416; V r_ = (g_heff_2erender_2efileDiag(a_0, a_1, a_2, a_3)); heff_drop(v_x_249); r_; });
}
V g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam4(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_str_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tag(TAG_WriteErr, 2, (V[]){v_str_2420, NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2421), LBL_malg), 1, (V[]){v_t_2426}));
  V f_ = heff_get(v_hd_2421, LBL_bind);
  args[0] = v_t_2427;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2429);
  return (g_heff_2ecommands_2eputFileDiags_24s894_24s1249(v_rest_244, v_p_241, v_p_242));
}
V g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_get(heff_dup(v_c_243), LBL_diags);
  V v_t_2413;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nil: {
    v_t_2413 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2410, 0ULL, 2);
    v_t_2413 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_c_2428;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_True: {
    heff_drop(v_x_249);
    heff_drop(v_c_243);
    v_c_2428 = ((V)&g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam2_clo);
    break;
  }
  case TAG_False: {
    V v_x2_2417 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam3, 1, 2, (V[]){v_x_249, heff_dup(v_c_243)}), heff_get(v_c_243, LBL_diags)));
    V v_str_2420;
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_Nil: {
      v_str_2420 = ((V)&g_heff_2ecommands_2eputFileDiags_24s894_24s1249_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_xs_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      v_str_2420 = ({ V a_0 = v_x_2418; V a_1 = v_xs_2419; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2417);
    }
    v_c_2428 = heff_clo(g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam4, 2, 1, (V[]){v_str_2420});
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_p_241), heff_clo(g_heff_2ecommands_2eputFileDiags_24s894_24s1249_lam5, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242})});
}
V g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248_lam1(V self, V *args);
V g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248_lam2(V self, V *args);
V g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248_lam0(V self, V *args);
Clo g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248_entry, 4, 0};

V g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248(V v_badLoad_240, V v_cs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecommands_2eputFileDiags_24s894_24s1249(heff_dup(v_cs_241), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248_lam0, 1, 4, (V[]){v_cs_241, v_hd_242, v_k_243, heff_dup(v_badLoad_240)})));
}
V g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_str_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tag(TAG_Write, 2, (V[]){v_str_2412, NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2413, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_badLoad_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2421);
  switch (heff_tag_of(v_badLoad_240)) {
  case TAG_True: {
    heff_drop(v_cs_241);
    V v_t_2422 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2425}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2426, v_k_243});
  }
  case TAG_False: {
    V v_t_2427 = ({ V a_0 = v_cs_241; V r_ = (g_prelude_2eany_24s798(a_0)); heff_drop(v_cs_241); r_; });
    switch (heff_tag_of(v_t_2427)) {
    case TAG_True: {
      V v_t_2428 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2429 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2428})});
      V v_t_2430 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2431}));
      return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2432, v_k_243});
    }
    case TAG_False: {
      heff_drop(v_hd_242);
      V f_ = v_k_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  default: return heff_nomatch(v_badLoad_240);
  }
}
V g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_badLoad_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_244);
  V v_t_245 = (g_heff_2edriver_2elastChecked(v_cs_241));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_cs_241);
    heff_drop(v_badLoad_240);
    V v_t_246 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2410, v_k_243});
  }
  case TAG_Just: {
    V v_c_2411 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_str_2412 = (g_heff_2edriver_2einterface(v_c_2411));
    V v_c_2420 = heff_clo(g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248_lam1, 2, 1, (V[]){v_str_2412});
    return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248_lam2, 1, 4, (V[]){v_badLoad_240, v_hd_242, v_k_243, v_cs_241})});
  }
  default: return heff_nomatch(v_t_245);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_lam2(V self, V *args);
V g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_lam1(V self, V *args);
V g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_lam0(V self, V *args);
Clo g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_entry, 3, 0};

V g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247(V v_file_240, V v_hd_241, V v_k_242) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2eload_24s860_24s1032_24s1125(v_file_240, heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_lam0, 1, 2, (V[]){v_hd_241, v_k_242}));
}
V g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V b_0 = heff_intLt(MK_INT(0LL), v_x_244); V a_1 = v_x_246; V a_2 = v_hd_241; V a_3 = v_k_242; V r_ = (g_heff_2ecommands_2echeckLast_24s893_24s1039_24s1248(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
V g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(v_x_243));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_lam2, 1, 3, (V[]){v_x_244, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_str0), heff_get(heff_dup(v_x_243), LBL_errors), MK_INT(0LL), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2echeckCmd_24s859_24s1031_24s1119_24s1247_lam1, 1, 3, (V[]){v_x_243, v_hd_241, v_k_242})));
}
V g_heff_2ecommands_2ecompileDiags_24s896_24s1041_24s1146_24s1251_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecompileDiags_24s896_24s1041_24s1146_24s1251_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileDiags_24s896_24s1041_24s1146_24s1251_entry, 10, 0};

V g_heff_2ecommands_2ecompileDiags_24s896_24s1041_24s1146_24s1251(V v_sources_240, V v_host_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_badL_246, V v_cs_247, V v_hd_248, V v_k_249) {
top: ;
  return (g_heff_2ecommands_2eputFileDiags_24s894_24s1249(heff_dup(v_cs_247), heff_dup(v_hd_248), heff_clo(g_heff_2ecommands_2ecompileDiags_24s896_24s1041_24s1146_24s1251_lam0, 1, 10, (V[]){heff_dup(v_badL_246), v_hd_248, v_k_249, v_cs_247, heff_dup(v_sources_240), v_host_241, v_file_242, v_name_243, v_outPath_244, v_done_245})));
}
V g_heff_2ecommands_2ecompileDiags_24s896_24s1041_24s1146_24s1251_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileDiags_24s896_24s1041_24s1146_24s1251(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a[0]); heff_drop(a[6]); return r;
}
V g_heff_2ecommands_2ecompileDiags_24s896_24s1041_24s1146_24s1251_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_badL_246 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_cs_247 = heff_env(self)[3];
  V v_sources_240 = heff_env(self)[4];
  V v_host_241 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2410);
  switch (heff_tag_of(v_badL_246)) {
  case TAG_True: {
    heff_drop(v_cs_247);
    heff_drop(v_sources_240);
    heff_drop(v_host_241);
    heff_drop(v_file_242);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    V v_t_2411 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2414}));
    return heff_tail(heff_get(v_hd_248, LBL_bind), 2, (V[]){v_t_2415, v_k_249});
  }
  case TAG_False: {
    V v_t_2416 = (g_prelude_2eany_24s798(v_cs_247));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      heff_drop(v_cs_247);
      heff_drop(v_sources_240);
      heff_drop(v_host_241);
      heff_drop(v_file_242);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      V v_t_2417 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2420}));
      return heff_tail(heff_get(v_hd_248, LBL_bind), 2, (V[]){v_t_2421, v_k_249});
    }
    case TAG_False: {
      V v_t_2422 = ({ V a_0 = v_sources_240; V a_1 = v_host_241; V a_2 = v_file_242; V a_3 = v_name_243; V a_4 = v_outPath_244; V a_5 = v_done_245; V a_6 = v_cs_247; V r_ = (g_heff_2ecommands_2ecompileLast_24s897_24s1042_24s1147(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sources_240); heff_drop(v_cs_247); r_; });
      return heff_tail(v_t_2422, 2, (V[]){v_hd_248, v_k_249});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_badL_246);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {109, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam4(V self, V *args); static Clo g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam4, 1, 0};
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam3(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam6(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam5(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam2(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam1(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam0(V self, V *args);
Clo g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_entry, 4, 0};

V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250(V v_file_240, V v_progArgs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecommands_2eload_24s860_24s1032_24s1125(heff_dup(v_file_240), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam0, 1, 4, (V[]){v_hd_242, v_file_240, v_progArgs_241, v_k_243})));
}
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam4(V self, V *args) {
  V v_ok_2411 = args[0];
  return v_ok_2411;
}
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam3(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_path_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_248, ((V)&g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam4_clo)})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2414}));
  V f_ = heff_get(v_hd_249, LBL_bind);
  args[0] = v_t_2415;
  args[1] = v_k2_2410;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam6(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_as_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tag(TAG_Exec, 3, (V[]){((V)&g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_str3), v_as_2420, NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2421), LBL_malg), 1, (V[]){v_t_2426}));
  V f_ = heff_get(v_hd_2421, LBL_bind);
  args[0] = v_t_2427;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_progArgs_241 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_hd_242 = heff_env(self)[5];
  V v_k_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2417);
  V v_t_2418 = (g_heff_2ecommands_2erunPath(heff_get(heff_dup(v_x_244), LBL_paths), heff_dup(v_file_240)));
  V v_t_2419 = (g_heff_2ecommands_2erunPath(heff_get(heff_dup(v_x_244), LBL_paths), heff_dup(v_file_240)));
  V v_as_2420 = heff_tag(TAG_Cons, 2, (V[]){v_t_2419, v_progArgs_241});
  return ({ V b_0 = heff_get(v_x_244, LBL_sources); V a_1 = ((V)&g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_str1); V a_2 = v_file_240; V a_3 = heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_str2)}); V a_4 = v_t_2418; V a_5 = heff_clo(g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam6, 2, 1, (V[]){v_as_2420}); V b_6 = heff_intLt(MK_INT(0LL), v_x_245); V a_7 = v_x_247; V a_8 = v_hd_242; V a_9 = v_k_243; V r_ = (g_heff_2ecommands_2ecompileDiags_24s896_24s1041_24s1146_24s1251(b_0, a_1, a_2, a_3, a_4, a_5, b_6, a_7, a_8, a_9)); heff_drop(b_0); heff_drop(b_6); r_; });
}
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_progArgs_241 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_k_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_path_248 = (g_heff_2ecommands_2erunDir(heff_get(heff_dup(v_x_244), LBL_paths)));
  V v_c_2416 = heff_clo(g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam3, 2, 1, (V[]){v_path_248});
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam5, 1, 7, (V[]){v_x_244, v_file_240, v_progArgs_241, v_x_245, v_x_247, v_hd_242, v_k_243})});
}
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_progArgs_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_246 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(heff_dup(v_x_244)));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam2, 1, 6, (V[]){v_x_244, v_hd_242, v_file_240, v_progArgs_241, v_x_245, v_k_243})});
}
V g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_progArgs_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_str0), heff_get(heff_dup(v_x_244), LBL_errors), MK_INT(0LL), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2erunCmd_24s895_24s1040_24s1145_24s1250_lam1, 1, 5, (V[]){v_x_244, v_hd_242, v_file_240, v_progArgs_241, v_k_243})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestReport_24s910_24s1256_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {111, 107, 32, 32, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestReport_24s910_24s1256_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestReport_24s910_24s1256_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestReport_24s910_24s1256_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestReport_24s910_24s1256_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2etestReport_24s910_24s1256_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {44, 32, 116, 101, 115, 116, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestReport_24s910_24s1256_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2etestReport_24s910_24s1256_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestReport_24s910_24s1256_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestReport_24s910_24s1256_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2etestReport_24s910_24s1256_lam0(V self, V *args); static Clo g_heff_2ecommands_2etestReport_24s910_24s1256_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestReport_24s910_24s1256_lam0, 1, 0};
V g_heff_2ecommands_2etestReport_24s910_24s1256_lam4(V self, V *args);
V g_heff_2ecommands_2etestReport_24s910_24s1256_lam5(V self, V *args);
V g_heff_2ecommands_2etestReport_24s910_24s1256_lam3(V self, V *args);
V g_heff_2ecommands_2etestReport_24s910_24s1256_lam2(V self, V *args);
V g_heff_2ecommands_2etestReport_24s910_24s1256_lam1(V self, V *args);
Clo g_heff_2ecommands_2etestReport_24s910_24s1256_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestReport_24s910_24s1256_entry, 6, 0};

V g_heff_2ecommands_2etestReport_24s910_24s1256(V v_f_240, V v_bad_241, V v_ts_242, V v_os_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_UseColor, 1, (V[]){((V)&g_heff_2ecommands_2etestReport_24s910_24s1256_lam0_clo)})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_248})}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2etestReport_24s910_24s1256_lam1, 1, 6, (V[]){v_ts_242, v_f_240, v_hd_244, v_os_243, v_bad_241, v_k_245})});
}
V g_heff_2ecommands_2etestReport_24s910_24s1256_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestReport_24s910_24s1256(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecommands_2etestReport_24s910_24s1256_lam0(V self, V *args) {
  V v_b_246 = args[0];
  return v_b_246;
}
V g_heff_2ecommands_2etestReport_24s910_24s1256_lam4(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k2_2439 = args[1];
  V v_str_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2437, ((V)&g_heff_2ecommands_2etestReport_24s910_24s1256_str9)), NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2438), LBL_malg), 1, (V[]){v_t_2443}));
  V f_ = heff_get(v_hd_2438, LBL_bind);
  args[0] = v_t_2444;
  args[1] = v_k2_2439;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2etestReport_24s910_24s1256_lam5(V self, V *args) {
  V v_x_2446 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_bad_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2446);
  V v_t_2447 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_ts_242));
  V v_xs_2448 = (g_prelude_2efilter_24s810(v_ts_242));
  V v_t_2449 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2448; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2448); r_; });
  V v_t_2450 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_os_243));
  V v_xs_2451 = (g_prelude_2efilter_24s812(v_os_243));
  V v_t_2452 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2451; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2451); r_; });
  V v_x_2453 = heff_rec(5, shape_345_96_212_335_336, (V[]){v_t_2447, v_t_2449, heff_intEq(v_bad_241, MK_INT(0LL)), v_t_2450, v_t_2452});
  V f_ = v_k_245;
  args[0] = v_x_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2etestReport_24s910_24s1256_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_bad_241 = heff_env(self)[2];
  V v_f_240 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2415);
  V v_x1_2416 = (g_prelude_2efilter_24s810(heff_dup(v_ts_242)));
  V v_t_2423;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_Nil: {
    V v_x1_2417 = (g_prelude_2efilter_24s812(heff_dup(v_os_243)));
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nil: {
      V v_t_2418 = heff_intEq(heff_dup(v_bad_241), MK_INT(0LL));
      switch (heff_tag_of(v_t_2418)) {
      case TAG_True: {
        v_t_2423 = ((V)&g_heff_2ecommands_2etestReport_24s910_24s1256_str0);
        break;
      }
      case TAG_False: {
        v_t_2423 = ((V)&g_heff_2ecommands_2etestReport_24s910_24s1256_str1);
        break;
      }
      default: heff_nomatch(v_t_2418);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2417, 0ULL, 2);
      v_t_2423 = ((V)&g_heff_2ecommands_2etestReport_24s910_24s1256_str2);
      break;
    }
    default: heff_nomatch(v_x1_2417);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2416, 0ULL, 2);
    v_t_2423 = ((V)&g_heff_2ecommands_2etestReport_24s910_24s1256_str3);
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_t_2424 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_ts_242));
  V v_xs_2425 = (g_prelude_2efilter_24s810(heff_dup(v_ts_242)));
  V v_t_2426 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2425; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2425); r_; });
  V v_t_2427 = heff_intShow(heff_intSub(v_t_2424, v_t_2426));
  V v_t_2428 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_ts_242));
  V v_t_2436;
  switch (heff_tag_of(v_os_243)) {
  case TAG_Nil: {
    v_t_2436 = ((V)&g_heff_2ecommands_2etestReport_24s910_24s1256_str4);
    break;
  }
  case TAG_Cons: {
    V v_t_2431 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_os_243));
    V v_xs_2432 = (g_prelude_2efilter_24s812(heff_dup(v_os_243)));
    V v_t_2433 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2432; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2432); r_; });
    V v_t_2434 = heff_intShow(heff_intSub(v_t_2431, v_t_2433));
    V v_t_2435 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_os_243));
    v_t_2436 = heff_strAppend(((V)&g_heff_2ecommands_2etestReport_24s910_24s1256_str5), heff_strAppend(v_t_2434, heff_strAppend(((V)&g_heff_2ecommands_2etestReport_24s910_24s1256_str6), heff_intShow(v_t_2435))));
    break;
  }
  default: heff_nomatch(v_os_243);
  }
  V v_str_2437 = heff_strAppend(v_t_2423, heff_strAppend(v_f_240, heff_strAppend(((V)&g_heff_2ecommands_2etestReport_24s910_24s1256_str7), heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2ecommands_2etestReport_24s910_24s1256_str8), heff_strAppend(heff_intShow(v_t_2428), v_t_2436))))));
  V v_c_2445 = heff_clo(g_heff_2ecommands_2etestReport_24s910_24s1256_lam4, 2, 1, (V[]){v_str_2437});
  return heff_tail(v_c_2445, 2, (V[]){v_hd_244, heff_clo(g_heff_2ecommands_2etestReport_24s910_24s1256_lam5, 1, 4, (V[]){v_ts_242, v_os_243, v_bad_241, v_k_245})});
}
V g_heff_2ecommands_2etestReport_24s910_24s1256_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_ts_242 = heff_env(self)[3];
  V v_bad_241 = heff_env(self)[4];
  V v_f_240 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2413);
  V v_c_2414 = ({ V a_0 = v_x_2410; V a_1 = heff_dup(v_os_243); V r_ = (g_heff_2ecommands_2eprintOutcomes_24s912(a_0, a_1)); heff_drop(v_x_2410); r_; });
  return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2etestReport_24s910_24s1256_lam3, 1, 6, (V[]){v_ts_242, v_os_243, v_bad_241, v_f_240, v_hd_244, v_k_245})});
}
V g_heff_2ecommands_2etestReport_24s910_24s1256_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_os_243 = heff_env(self)[3];
  V v_bad_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2411 = (g_prelude_2efilter_24s810(heff_dup(v_ts_242)));
  V v_c_2412 = (g_heff_2ecommands_2eprintFails_24s911(heff_dup(v_f_240), v_x_2410, v_t_2411));
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2etestReport_24s910_24s1256_lam2, 1, 7, (V[]){v_x_2410, v_os_243, v_hd_244, v_ts_242, v_bad_241, v_f_240, v_k_245})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestOneC_24s908_24s1255_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2etestOneC_24s908_24s1255_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 32, 48, 47, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestOneC_24s908_24s1255_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2etestOneC_24s908_24s1255_lam2(V self, V *args);
V g_heff_2ecommands_2etestOneC_24s908_24s1255_lam3(V self, V *args);
V g_heff_2ecommands_2etestOneC_24s908_24s1255_lam1(V self, V *args);
V g_heff_2ecommands_2etestOneC_24s908_24s1255_lam0(V self, V *args);
Clo g_heff_2ecommands_2etestOneC_24s908_24s1255_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestOneC_24s908_24s1255_entry, 4, 0};

V g_heff_2ecommands_2etestOneC_24s908_24s1255(V v_seed_240, V v_f_241, V v_bad0_242, V v_cs_243) {
top: ;
  V v_c_244 = (g_heff_2ecommands_2ediagCount_24s909(v_cs_243));
  return heff_clo(g_heff_2ecommands_2etestOneC_24s908_24s1255_lam0, 2, 5, (V[]){v_c_244, heff_dup(v_cs_243), v_f_241, v_bad0_242, v_seed_240});
}
V g_heff_2ecommands_2etestOneC_24s908_24s1255_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2etestOneC_24s908_24s1255(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2ecommands_2etestOneC_24s908_24s1255_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_rec(5, shape_345_96_212_335_336, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL)});
  V f_ = v_k_246;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2etestOneC_24s908_24s1255_lam3(V self, V *args) {
  V v_w_2420 = args[0];
  V v_c_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_get(heff_dup(v_w_2420), LBL_expected);
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nothing: {
    heff_drop(v_w_2420);
    heff_drop(v_c_2417);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_ru_24t_2421_24Just = heff_take_reuse_n(v_t_2421, 0ULL, 1);
    V v_t_2423 = (g_heff_2edriver_2eownerOf(v_c_2417, heff_get(heff_dup(v_w_2420), LBL_from)));
    return heff_tag_at(v_ru_24t_2421_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_227_373, (V[]){v_t_2423, v_w_2420})});
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_heff_2ecommands_2etestOneC_24s908_24s1255_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_bad0_242 = heff_env(self)[4];
  V v_seed_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_248 = ({ V a_0 = v_cs_243; V r_ = (g_heff_2edriver_2elastChecked(a_0)); heff_drop(v_cs_243); r_; });
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop(v_x_247);
    heff_drop(v_bad0_242);
    heff_drop(v_seed_240);
    V v_t_249 = heff_strAppend(((V)&g_heff_2ecommands_2etestOneC_24s908_24s1255_str0), heff_strAppend(v_f_241, ((V)&g_heff_2ecommands_2etestOneC_24s908_24s1255_str1)));
    V v_t_2410 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2ecommands_2etestOneC_24s908_24s1255_str2)), NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2413}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecommands_2etestOneC_24s908_24s1255_lam2, 1, 1, (V[]){v_k_246})});
  }
  case TAG_Just: {
    V v_c_2417 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    V v_t_2418 = heff_get(heff_get(heff_dup(v_c_2417), LBL_top), LBL_watches);
    V v_t_2419 = (g_heff_2edriver_2ewatchesGo(heff_dup(v_c_2417), MK_INT(0LL), v_t_2418));
    V v_t_2424 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2etestOneC_24s908_24s1255_lam3, 1, 1, (V[]){heff_dup(v_c_2417)}), v_t_2419));
    V v_t_2425 = (g_heff_2edriver_2ecatMaybesD(v_t_2424));
    V v_t_2426 = heff_intLt(MK_INT(0LL), heff_intAdd(heff_dup(v_bad0_242), heff_dup(v_x_247)));
    V v_t_2427;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_True: {
      heff_drop(v_seed_240);
      heff_drop(v_c_2417);
      v_t_2427 = NTAG(TAG_Nil);
      break;
    }
    case TAG_False: {
      v_t_2427 = (g_heff_2edriver_2erunTests(v_seed_240, v_c_2417));
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    return (g_heff_2ecommands_2etestReport_24s910_24s1256(v_f_241, heff_intAdd(v_bad0_242, v_x_247), v_t_2425, v_t_2427, v_hd_245, v_k_246));
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ecommands_2etestOneC_24s908_24s1255_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_cs_243 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_bad0_242 = heff_env(self)[3];
  V v_seed_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo(g_heff_2ecommands_2etestOneC_24s908_24s1255_lam1, 1, 6, (V[]){v_cs_243, v_f_241, v_hd_245, v_k_246, v_bad0_242, v_seed_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254_lam2(V self, V *args);
V g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254_lam1(V self, V *args);
V g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254_lam0(V self, V *args);
Clo g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254_entry, 4, 0};

V g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254(V v_seed_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecommands_2eload_24s860_24s1032_24s1125(heff_dup(v_f_241), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254_lam0, 1, 4, (V[]){v_hd_242, v_seed_240, v_f_241, v_k_243})));
}
V g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_seed_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = ({ V a_0 = v_seed_240; V a_1 = v_f_241; V a_2 = v_x_245; V a_3 = v_x_247; V r_ = (g_heff_2ecommands_2etestOneC_24s908_24s1255(a_0, a_1, a_2, a_3)); heff_drop(v_x_247); r_; });
  return heff_tail(v_t_248, 2, (V[]){v_hd_242, v_k_243});
}
V g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_seed_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_246 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(v_x_244));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254_lam2, 1, 5, (V[]){v_seed_240, v_f_241, v_x_245, v_hd_242, v_k_243})});
}
V g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254_str0), heff_get(heff_dup(v_x_244), LBL_errors), MK_INT(0LL), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254_lam1, 1, 5, (V[]){v_x_244, v_hd_242, v_seed_240, v_f_241, v_k_243})));
}
V g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_lam2(V self, V *args); static Clo g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_lam2, 1, 0};
V g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_lam1(V self, V *args);
V g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_lam3(V self, V *args);
V g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_lam0(V self, V *args);
Clo g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_entry, 5, 0};

V g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258(V v_file_240, V v_badL_241, V v_cs_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ecommands_2eputFileDiags_24s894_24s1249(heff_dup(v_cs_242), heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_lam0, 1, 5, (V[]){v_cs_242, v_hd_243, v_k_244, heff_dup(v_badL_241), v_file_240})));
}
V g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_lam2(V self, V *args) {
  V v_ok_2425 = args[0];
  return v_ok_2425;
}
V g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_lam1(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_file_240 = heff_env(self)[0];
  V v_str_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){v_file_240, v_str_2422, ((V)&g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_lam2_clo)})});
  V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2423), LBL_malg), 1, (V[]){v_t_2428}));
  V f_ = heff_get(v_hd_2423, LBL_bind);
  args[0] = v_t_2429;
  args[1] = v_k2_2424;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2431)) {
  case TAG_True: {
    heff_drop(v_hd_243);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_2432 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2435}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2436, v_k_244});
  }
  default: return heff_nomatch(v_x_2431);
  }
}
V g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_badL_241 = heff_env(self)[3];
  V v_file_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_245);
  V v_t_246 = (g_heff_2edriver_2elastChecked(v_cs_242));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_cs_242);
    heff_drop(v_badL_241);
    heff_drop(v_file_240);
    V v_t_247 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2410}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2411, v_k_244});
  }
  case TAG_Just: {
    V v_c_2412 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
    V v_t_2413;
    switch (heff_tag_of(v_badL_241)) {
    case TAG_True: {
      heff_drop(v_cs_242);
      v_t_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      v_t_2413 = ({ V a_0 = v_cs_242; V r_ = (g_prelude_2eany_24s798(a_0)); heff_drop(v_cs_242); r_; });
      break;
    }
    default: heff_nomatch(v_badL_241);
    }
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      heff_drop(v_file_240);
      heff_drop(v_c_2412);
      V v_t_2414 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2415 = heff_tag_at(v_ru_24t_246_24Just, TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2417}));
      return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2418, v_k_244});
    }
    case TAG_False: {
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      V v_t_2419 = heff_get(heff_get(heff_dup(v_c_2412), LBL_top), LBL_watches);
      V v_xs_2420 = (g_heff_2edriver_2ewatchesGo(heff_dup(v_c_2412), MK_INT(0LL), v_t_2419));
      V v_t_2421 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2420));
      V v_str_2422 = ({ V a_0 = heff_get(v_c_2412, LBL_source); V a_1 = v_t_2421; V r_ = (g_prelude_2efoldl_24s490(a_0, a_1)); heff_drop(v_t_2421); r_; });
      V v_c_2430 = heff_clo(g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_lam1, 2, 2, (V[]){v_file_240, v_str_2422});
      return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258_lam3, 1, 2, (V[]){v_k_244, v_hd_243})});
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_lam2(V self, V *args);
V g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_lam1(V self, V *args);
V g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_lam0(V self, V *args);
Clo g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_entry, 3, 0};

V g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257(V v_file_240, V v_hd_241, V v_k_242) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2eload_24s860_24s1032_24s1125(heff_dup(v_file_240), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_lam0, 1, 3, (V[]){v_hd_241, v_file_240, v_k_242}));
}
V g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_file_240; V b_1 = heff_intLt(MK_INT(0LL), v_x_244); V a_2 = v_x_246; V a_3 = v_hd_241; V a_4 = v_k_242; V r_ = (g_heff_2ecommands_2epromoteDiags_24s914_24s1051_24s1158_24s1258(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
}
V g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_245 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(v_x_243));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_lam2, 1, 4, (V[]){v_file_240, v_x_244, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_str0), heff_get(heff_dup(v_x_243), LBL_errors), MK_INT(0LL), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2epromoteCmd_24s913_24s1050_24s1157_24s1257_lam1, 1, 4, (V[]){v_x_243, v_hd_241, v_file_240, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_entry, 7, 0};

V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260(V v_host_240, V v_name_241, V v_outPath_242, V v_file_243, V v_done_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2ecommands_2eload_24s860_24s1032_24s1125(heff_dup(v_file_243), heff_dup(v_hd_245), heff_clo(g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_lam0, 1, 7, (V[]){v_hd_245, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_246})));
}
V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_x_248 = heff_env(self)[6];
  V v_hd_245 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return ({ V b_0 = heff_get(v_x_247, LBL_sources); V a_1 = v_host_240; V a_2 = v_file_243; V a_3 = v_name_241; V a_4 = v_outPath_242; V a_5 = v_done_244; V b_6 = heff_intLt(MK_INT(0LL), v_x_248); V a_7 = v_x_2410; V a_8 = v_hd_245; V a_9 = v_k_246; V r_ = (g_heff_2ecommands_2ecompileDiags_24s896_24s1041_24s1146_24s1251(b_0, a_1, a_2, a_3, a_4, a_5, b_6, a_7, a_8, a_9)); heff_drop(b_0); heff_drop(b_6); r_; });
}
V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  V v_file_243 = heff_env(self)[3];
  V v_name_241 = heff_env(self)[4];
  V v_outPath_242 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_249 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(heff_dup(v_x_247)));
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_hd_245), heff_clo(g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_lam2, 1, 9, (V[]){v_x_247, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_x_248, v_hd_245, v_k_246})});
}
V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_str0), heff_get(heff_dup(v_x_247), LBL_errors), MK_INT(0LL), heff_dup(v_hd_245), heff_clo(g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_lam1, 1, 8, (V[]){v_x_247, v_hd_245, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_246})));
}
V g_heff_2ecommands_2ecompileJsDiags_24s917_24s1055_24s1162_24s1262_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecompileJsDiags_24s917_24s1055_24s1162_24s1262_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileJsDiags_24s917_24s1055_24s1162_24s1262_entry, 6, 0};

V g_heff_2ecommands_2ecompileJsDiags_24s917_24s1055_24s1162_24s1262(V v_file_240, V v_outPath_241, V v_badL_242, V v_cs_243, V v_hd_244, V v_k_245) {
top: ;
  return (g_heff_2ecommands_2eputFileDiags_24s894_24s1249(heff_dup(v_cs_243), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ecompileJsDiags_24s917_24s1055_24s1162_24s1262_lam0, 1, 5, (V[]){v_cs_243, v_hd_244, v_k_245, heff_dup(v_badL_242), v_outPath_241})));
}
V g_heff_2ecommands_2ecompileJsDiags_24s917_24s1055_24s1162_24s1262_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileJsDiags_24s917_24s1055_24s1162_24s1262(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); heff_drop(a[2]); return r;
}
V g_heff_2ecommands_2ecompileJsDiags_24s917_24s1055_24s1162_24s1262_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_badL_242 = heff_env(self)[3];
  V v_outPath_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_246);
  V v_t_247 = (g_heff_2edriver_2elastChecked(v_cs_243));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_cs_243);
    heff_drop(v_badL_242);
    heff_drop(v_outPath_241);
    V v_t_248 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2411}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2412, v_k_245});
  }
  case TAG_Just: {
    V v_c_2413 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_badL_242)) {
    case TAG_True: {
      heff_drop(v_cs_243);
      v_t_2414 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      v_t_2414 = ({ V a_0 = v_cs_243; V r_ = (g_prelude_2eany_24s798(a_0)); heff_drop(v_cs_243); r_; });
      break;
    }
    default: heff_nomatch(v_badL_242);
    }
    V v_t_2415 = heff_get(heff_get(heff_dup(v_c_2413), LBL_top), LBL_globals);
    V v_t_2416 = (g_prelude_2emap_24s799(heff_get(v_c_2413, LBL_own)));
    V v_t_2417 = (g_heff_2eemit_2ecompileJs(v_t_2415, v_t_2416));
    return ({ V a_0 = v_outPath_241; V a_1 = v_t_2414; V a_2 = v_t_2417; V a_3 = v_hd_244; V a_4 = v_k_245; V r_ = (g_heff_2ecommands_2ecompileJsOut_24s918_24s1056_24s1163(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2414); r_; });
  }
  default: return heff_nomatch(v_t_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_entry, 4, 0};

V g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261(V v_file_240, V v_outPath_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecommands_2eload_24s860_24s1032_24s1125(heff_dup(v_file_240), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_lam0, 1, 4, (V[]){v_hd_242, v_file_240, v_outPath_241, v_k_243})));
}
V g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_outPath_241 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_file_240; V a_1 = v_outPath_241; V b_2 = heff_intLt(MK_INT(0LL), v_x_245); V a_3 = v_x_247; V a_4 = v_hd_242; V a_5 = v_k_243; V r_ = (g_heff_2ecommands_2ecompileJsDiags_24s917_24s1055_24s1162_24s1262(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(v_file_240); heff_drop(b_2); r_; });
}
V g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_246 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(v_x_244));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_lam2, 1, 5, (V[]){v_file_240, v_outPath_241, v_x_245, v_hd_242, v_k_243})});
}
V g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_outPath_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_str0), heff_get(heff_dup(v_x_244), LBL_errors), MK_INT(0LL), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_lam1, 1, 5, (V[]){v_x_244, v_hd_242, v_file_240, v_outPath_241, v_k_243})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_lam3(V self, V *args);
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_lam2(V self, V *args);
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_lam1(V self, V *args);
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_entry, 6, 0};

V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264(V v_name_240, V v_outPath_241, V v_file_242, V v_done_243, V v_hd_244, V v_k_245) {
top: ;
  return (g_heff_2ecommands_2eload_24s860_24s1032_24s1125(heff_dup(v_file_242), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_lam0, 1, 6, (V[]){v_hd_244, v_k_245, v_file_242, v_name_240, v_outPath_241, v_done_243})));
}
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  V v_file_242 = heff_env(self)[5];
  V v_name_240 = heff_env(self)[6];
  V v_outPath_241 = heff_env(self)[7];
  V v_done_243 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2410);
  V v_t_2411 = heff_intLt(MK_INT(0LL), v_x_247);
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    heff_drop(v_x_249);
    heff_drop(v_x_246);
    heff_drop(v_file_242);
    heff_drop(v_name_240);
    heff_drop(v_outPath_241);
    heff_drop(v_done_243);
    V v_t_2412 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2415}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2416, v_k_245});
  }
  case TAG_False: {
    V v_t_2417 = (g_prelude_2eany_24s798(v_x_249));
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      heff_drop(v_x_249);
      heff_drop(v_x_246);
      heff_drop(v_file_242);
      heff_drop(v_name_240);
      heff_drop(v_outPath_241);
      heff_drop(v_done_243);
      V v_t_2418 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2421}));
      return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2422, v_k_245});
    }
    case TAG_False: {
      V v_t_2423 = ({ V b_0 = heff_get(v_x_246, LBL_sources); V a_1 = v_file_242; V a_2 = v_name_240; V a_3 = v_outPath_241; V a_4 = v_done_243; V a_5 = v_x_249; V r_ = (g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166(b_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(b_0); heff_drop(v_x_249); r_; });
      return heff_tail(v_t_2423, 2, (V[]){v_hd_244, v_k_245});
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_file_242 = heff_env(self)[4];
  V v_name_240 = heff_env(self)[5];
  V v_outPath_241 = heff_env(self)[6];
  V v_done_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ecommands_2eputFileDiags_24s894_24s1249(heff_dup(v_x_249), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_lam3, 1, 9, (V[]){v_x_247, v_hd_244, v_k_245, v_x_249, v_x_246, v_file_242, v_name_240, v_outPath_241, v_done_243})));
}
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_name_240 = heff_env(self)[4];
  V v_outPath_241 = heff_env(self)[5];
  V v_done_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_248 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(heff_dup(v_x_246)));
  return heff_tail(v_c_248, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_lam2, 1, 8, (V[]){v_hd_244, v_x_247, v_k_245, v_x_246, v_file_242, v_name_240, v_outPath_241, v_done_243})});
}
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_outPath_241 = heff_env(self)[4];
  V v_done_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_str0), heff_get(heff_dup(v_x_246), LBL_errors), MK_INT(0LL), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_lam1, 1, 7, (V[]){v_x_246, v_hd_244, v_k_245, v_file_242, v_name_240, v_outPath_241, v_done_243})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {42, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {119, 114, 111, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[28]; } g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_str3 = {{0x80000000u, K_STR, 0}, 28, 28, {58, 32, 98, 117, 105, 108, 100, 32, 105, 116, 32, 119, 105, 116, 104, 32, 96, 122, 105, 103, 32, 99, 99, 32, 45, 79, 50, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_str4 = {{0x80000000u, K_STR, 0}, 12, 12, {32, 45, 111, 32, 80, 82, 79, 71, 82, 65, 77, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_entry, 3, 0};

V g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263(V v_name_240, V v_outPath_241, V v_file_242) {
top: ;
  V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_outPath_241)), MK_INT(1LL));
  V v_t_244 = heff_strSlice(heff_dup(v_outPath_241), v_t_243, heff_strLength(heff_dup(v_outPath_241)));
  V v_t_245 = heff_strEq(v_t_244, ((V)&g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_str0));
  V v_t_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_t_246 = heff_strAppend(heff_dup(v_outPath_241), ((V)&g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_str1));
    break;
  }
  case TAG_False: {
    v_t_246 = heff_dup(v_outPath_241);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_str_247 = heff_strAppend(((V)&g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_str2), heff_strAppend(heff_dup(v_outPath_241), heff_strAppend(((V)&g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_str3), heff_strAppend(v_t_246, ((V)&g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_str4)))));
  return heff_tail(((V)&g_heff_2ecommands_2ecThen_24s920_24s1058_24s1165_24s1264_clo), 4, (V[]){v_name_240, v_outPath_241, v_file_242, heff_clo(g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_lam0, 2, 1, (V[]){v_str_247})});
}
V g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k2_249 = args[1];
  V v_str_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_247, ((V)&g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263_str5)), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2413}));
  V f_ = heff_get(v_hd_248, LBL_bind);
  args[0] = v_t_2414;
  args[1] = v_k2_249;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {119, 114, 111, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str4 = {{0x80000000u, K_STR, 0}, 18, 18, {114, 117, 110, 32, 105, 116, 32, 119, 105, 116, 104, 32, 96, 110, 111, 100, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str5 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 65, 82, 71, 83, 46, 46, 46, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str9 = {{0x80000000u, K_STR, 0}, 6, 6, {119, 114, 111, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[91]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str10 = {{0x80000000u, K_STR, 0}, 91, 91, {58, 32, 108, 111, 97, 100, 32, 105, 116, 32, 105, 110, 32, 97, 32, 112, 97, 103, 101, 32, 119, 105, 116, 104, 32, 60, 115, 99, 114, 105, 112, 116, 32, 115, 114, 99, 61, 34, 46, 46, 46, 34, 62, 32, 40, 105, 116, 32, 105, 109, 112, 111, 114, 116, 115, 32, 110, 111, 116, 104, 105, 110, 103, 58, 32, 105, 116, 32, 111, 112, 101, 110, 115, 32, 102, 114, 111, 109, 32, 102, 105, 108, 101, 58, 47, 47, 32, 116, 111, 111, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str12 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 115, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[70]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str13 = {{0x80000000u, K_STR, 0}, 70, 70, {104, 101, 102, 102, 32, 99, 111, 109, 112, 105, 108, 101, 58, 32, 97, 110, 32, 69, 83, 32, 109, 111, 100, 117, 108, 101, 32, 114, 117, 110, 115, 32, 110, 111, 116, 104, 105, 110, 103, 58, 32, 110, 111, 32, 45, 45, 110, 97, 109, 101, 32, 119, 105, 116, 104, 32, 45, 45, 98, 97, 99, 107, 101, 110, 100, 61, 101, 115, 109, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str15 = {{0x80000000u, K_STR, 0}, 25, 25, {104, 101, 102, 102, 32, 99, 111, 109, 112, 105, 108, 101, 58, 32, 110, 111, 32, 98, 97, 99, 107, 101, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str16 = {{0x80000000u, K_STR, 0}, 22, 22, {58, 32, 101, 115, 109, 44, 32, 112, 97, 103, 101, 44, 32, 110, 111, 100, 101, 32, 111, 114, 32, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam0(V self, V *args);
V g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam3(V self, V *args);
V g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam2(V self, V *args); static Clo g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam2, 2, 0};
V g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam5(V self, V *args);
V g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam4(V self, V *args);
Clo g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_entry, 1, 0};

V g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259(V v_o_240) {
top: ;
  V v_t_241 = heff_strEq(heff_get(heff_dup(v_o_240), LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    V v_outPath_242 = heff_get(heff_dup(v_o_240), LBL_outPath);
    return heff_tail(((V)&g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_clo), 5, (V[]){((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str1), heff_get(heff_dup(v_o_240), LBL_name), heff_dup(v_outPath_242), heff_get(v_o_240, LBL_file), heff_clo(g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam0, 2, 1, (V[]){v_outPath_242})});
  }
  case TAG_False: {
    V v_t_2411 = heff_strEq(heff_get(heff_dup(v_o_240), LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str7));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      V v_outPath_2412 = heff_get(heff_dup(v_o_240), LBL_outPath);
      return heff_tail(((V)&g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1160_24s1260_clo), 5, (V[]){((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str8), heff_get(heff_dup(v_o_240), LBL_name), heff_dup(v_outPath_2412), heff_get(v_o_240, LBL_file), heff_clo(g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam1, 2, 1, (V[]){v_outPath_2412})});
    }
    case TAG_False: {
      V v_t_2421 = heff_strEq(heff_get(heff_dup(v_o_240), LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str12));
      switch (heff_tag_of(v_t_2421)) {
      case TAG_True: {
        V v_t_2422 = heff_get(heff_dup(v_o_240), LBL_name);
        switch (heff_tag_of(v_t_2422)) {
        case TAG_Nothing: {
          return heff_tail(((V)&g_heff_2ecommands_2ecompileJsCmd_24s916_24s1054_24s1161_24s1261_clo), 2, (V[]){heff_get(heff_dup(v_o_240), LBL_file), heff_get(v_o_240, LBL_outPath)});
        }
        case TAG_Just: {
          heff_take_n(v_t_2422, 0ULL, 1);
          heff_drop(v_o_240);
          return ((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam2_clo);
        }
        default: return heff_nomatch(v_t_2422);
        }
      }
      case TAG_False: {
        V v_t_2437 = heff_strEq(heff_get(heff_dup(v_o_240), LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str14));
        switch (heff_tag_of(v_t_2437)) {
        case TAG_True: {
          return (g_heff_2ecommands_2ecCmd_24s919_24s1057_24s1164_24s1263(heff_get(heff_dup(v_o_240), LBL_name), heff_get(heff_dup(v_o_240), LBL_outPath), heff_get(v_o_240, LBL_file)));
        }
        case TAG_False: {
          return heff_clo(g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam4, 2, 1, (V[]){v_o_240});
        }
        default: return heff_nomatch(v_t_2437);
        }
      }
      default: return heff_nomatch(v_t_2421);
      }
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259(a[0]);
}
V g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k2_244 = args[1];
  V v_outPath_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str2), heff_strAppend(heff_dup(v_outPath_242), heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str3), heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str4), heff_strAppend(v_outPath_242, ((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str5))))));
  V v_t_246 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str6)), NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_249}));
  V f_ = heff_get(v_hd_243, LBL_bind);
  args[0] = v_t_2410;
  args[1] = v_k2_244;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_outPath_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str9), heff_strAppend(v_outPath_2412, ((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str10)));
  V v_t_2416 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2415, ((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str11)), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2419}));
  V f_ = heff_get(v_hd_2413, LBL_bind);
  args[0] = v_t_2420;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_2424 = heff_env(self)[0];
  V v_k_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2431);
  V v_t_2432 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2424), LBL_malg), 1, (V[]){v_t_2435}));
  return heff_tail(heff_get(v_hd_2424, LBL_bind), 2, (V[]){v_t_2436, v_k_2425});
}
V g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_t_2426 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str13), NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2424), LBL_malg), 1, (V[]){v_t_2429}));
  V f_ = heff_get(heff_dup(v_hd_2424), LBL_bind);
  args[0] = v_t_2430;
  args[1] = heff_clo(g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam3, 1, 2, (V[]){v_hd_2424, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam5(V self, V *args) {
  V v_x_2446 = args[0];
  V v_hd_2438 = heff_env(self)[0];
  V v_k_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2446);
  V v_t_2447 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2448 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2438), LBL_malg), 1, (V[]){v_t_2450}));
  return heff_tail(heff_get(v_hd_2438, LBL_bind), 2, (V[]){v_t_2451, v_k_2439});
}
V g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam4(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_o_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str15), heff_strAppend(heff_get(v_o_240, LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str16)));
  V v_t_2441 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2440, ((V)&g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_str17)), NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2438), LBL_malg), 1, (V[]){v_t_2444}));
  V f_ = heff_get(heff_dup(v_hd_2438), LBL_bind);
  args[0] = v_t_2445;
  args[1] = heff_clo(g_heff_2ecommands_2ecompileTo_24s915_24s1052_24s1159_24s1259_lam5, 1, 2, (V[]){v_hd_2438, v_k_2439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_lam3(V self, V *args);
V g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_lam2(V self, V *args);
V g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_lam1(V self, V *args);
V g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_lam0(V self, V *args);
Clo g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_entry, 3, 0};

V g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265(V v_file_240, V v_hd_241, V v_k_242) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2eload_24s860_24s1032_24s1125(v_file_240, heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_lam0, 1, 2, (V[]){v_hd_241, v_k_242}));
}
V g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_247);
  V v_t_248 = ({ V a_0 = v_x_246; V r_ = (g_heff_2edriver_2elastChecked(a_0)); heff_drop(v_x_246); r_; });
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    V v_t_249 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2412}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2413, v_k_242});
  }
  case TAG_Just: {
    V v_c_2414 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    V v_t_2415 = (g_heff_2equery_2eexplain(v_c_2414));
    return (g_heff_2ecommands_2eprintLines_24s930(v_t_2415, v_hd_241, v_k_242));
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecommands_2eputFileDiags_24s894_24s1249(heff_dup(v_x_246), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_lam3, 1, 3, (V[]){v_x_246, v_hd_241, v_k_242})));
}
V g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_244);
  V v_c_245 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(v_x_243));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_lam2, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_str0), heff_get(heff_dup(v_x_243), LBL_errors), MK_INT(0LL), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eexplainCmd_24s929_24s1064_24s1173_24s1265_lam1, 1, 3, (V[]){v_x_243, v_hd_241, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_str1 = {{0x80000000u, K_STR, 0}, 13, 13, {110, 111, 116, 104, 105, 110, 103, 32, 116, 104, 101, 114, 101}};
V g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam4(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam3(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam2(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam1(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam0(V self, V *args);
Clo g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_entry, 4, 0};

V g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266(V v_file_240, V v_offs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecommands_2eload_24s860_24s1032_24s1125(v_file_240, heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam0, 1, 3, (V[]){v_hd_242, v_k_243, v_offs_241})));
}
V g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam4(V self, V *args) {
  V v_off_2416 = args[0];
  V v_c_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = (g_prelude_2eparseInt(v_off_2416));
  V v_x2_2419;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nothing: {
    heff_drop(v_c_2415);
    v_x2_2419 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_o_2418 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    v_x2_2419 = (g_heff_2equery_2etypeAt(v_c_2415, v_o_2418));
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_str1);
  }
  case TAG_Just: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    heff_take_n(v_x2_2419, 1ULL, 1);
    return v_x_2420;
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_offs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_248);
  V v_t_249 = ({ V a_0 = v_x_247; V r_ = (g_heff_2edriver_2elastChecked(a_0)); heff_drop(v_x_247); r_; });
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    heff_drop(v_offs_241);
    V v_t_2410 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2413}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2414, v_k_243});
  }
  case TAG_Just: {
    V v_c_2415 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    V v_t_2421 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam4, 1, 1, (V[]){v_c_2415}), v_offs_241));
    return (g_heff_2ecommands_2eprintLines_24s930(v_t_2421, v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_offs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2eputFileDiags_24s894_24s1249(heff_dup(v_x_247), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam3, 1, 4, (V[]){v_x_247, v_hd_242, v_k_243, v_offs_241})));
}
V g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_offs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_245);
  V v_c_246 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(v_x_244));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam2, 1, 3, (V[]){v_hd_242, v_k_243, v_offs_241})});
}
V g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_offs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_str0), heff_get(heff_dup(v_x_244), LBL_errors), MK_INT(0LL), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2etypeAtCmd_24s931_24s1065_24s1174_24s1266_lam1, 1, 4, (V[]){v_x_244, v_hd_242, v_k_243, v_offs_241})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_lam3(V self, V *args);
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_lam2(V self, V *args);
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_lam1(V self, V *args);
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_entry, 6, 0};

V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273(V v_name_240, V v_outPath_241, V v_file_242, V v_done_243, V v_hd_244, V v_k_245) {
top: ;
  return (g_heff_2ecommands_2eload_24s860_24s1032_24s1125(heff_dup(v_file_242), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_lam0, 1, 6, (V[]){v_hd_244, v_k_245, v_file_242, v_name_240, v_outPath_241, v_done_243})));
}
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  V v_file_242 = heff_env(self)[5];
  V v_name_240 = heff_env(self)[6];
  V v_outPath_241 = heff_env(self)[7];
  V v_done_243 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2410);
  V v_t_2411 = heff_intLt(MK_INT(0LL), v_x_247);
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    heff_drop(v_x_249);
    heff_drop(v_x_246);
    heff_drop(v_file_242);
    heff_drop(v_name_240);
    heff_drop(v_outPath_241);
    heff_drop(v_done_243);
    V v_t_2412 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2415}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2416, v_k_245});
  }
  case TAG_False: {
    V v_t_2417 = (g_prelude_2eany_24s798(v_x_249));
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      heff_drop(v_x_249);
      heff_drop(v_x_246);
      heff_drop(v_file_242);
      heff_drop(v_name_240);
      heff_drop(v_outPath_241);
      heff_drop(v_done_243);
      V v_t_2418 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2421}));
      return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2422, v_k_245});
    }
    case TAG_False: {
      V v_t_2423 = ({ V b_0 = heff_get(v_x_246, LBL_sources); V a_1 = v_file_242; V a_2 = v_name_240; V a_3 = v_outPath_241; V a_4 = v_done_243; V a_5 = v_x_249; V r_ = (g_heff_2ecommands_2ecompileLastC_24s921_24s1059_24s1166(b_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(b_0); heff_drop(v_x_249); r_; });
      return heff_tail(v_t_2423, 2, (V[]){v_hd_244, v_k_245});
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_file_242 = heff_env(self)[4];
  V v_name_240 = heff_env(self)[5];
  V v_outPath_241 = heff_env(self)[6];
  V v_done_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ecommands_2eputFileDiags_24s894_24s1249(heff_dup(v_x_249), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_lam3, 1, 9, (V[]){v_x_247, v_hd_244, v_k_245, v_x_249, v_x_246, v_file_242, v_name_240, v_outPath_241, v_done_243})));
}
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_name_240 = heff_env(self)[4];
  V v_outPath_241 = heff_env(self)[5];
  V v_done_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_248 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(heff_dup(v_x_246)));
  return heff_tail(v_c_248, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_lam2, 1, 8, (V[]){v_hd_244, v_x_247, v_k_245, v_x_246, v_file_242, v_name_240, v_outPath_241, v_done_243})});
}
V g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_outPath_241 = heff_env(self)[4];
  V v_done_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_str0), heff_get(heff_dup(v_x_246), LBL_errors), MK_INT(0LL), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273_lam1, 1, 7, (V[]){v_x_246, v_hd_244, v_k_245, v_file_242, v_name_240, v_outPath_241, v_done_243})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274_entry, 7, 0};

V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274(V v_host_240, V v_name_241, V v_outPath_242, V v_file_243, V v_done_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2ecommands_2eload_24s860_24s1032_24s1125(heff_dup(v_file_243), heff_dup(v_hd_245), heff_clo(g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274_lam0, 1, 7, (V[]){v_hd_245, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_246})));
}
V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_x_248 = heff_env(self)[6];
  V v_hd_245 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return ({ V b_0 = heff_get(v_x_247, LBL_sources); V a_1 = v_host_240; V a_2 = v_file_243; V a_3 = v_name_241; V a_4 = v_outPath_242; V a_5 = v_done_244; V b_6 = heff_intLt(MK_INT(0LL), v_x_248); V a_7 = v_x_2410; V a_8 = v_hd_245; V a_9 = v_k_246; V r_ = (g_heff_2ecommands_2ecompileDiags_24s896_24s1041_24s1146_24s1251(b_0, a_1, a_2, a_3, a_4, a_5, b_6, a_7, a_8, a_9)); heff_drop(b_0); heff_drop(b_6); r_; });
}
V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  V v_file_243 = heff_env(self)[3];
  V v_name_241 = heff_env(self)[4];
  V v_outPath_242 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_249 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(heff_dup(v_x_247)));
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_hd_245), heff_clo(g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274_lam2, 1, 9, (V[]){v_x_247, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_x_248, v_hd_245, v_k_246})});
}
V g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274_str0), heff_get(heff_dup(v_x_247), LBL_errors), MK_INT(0LL), heff_dup(v_hd_245), heff_clo(g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274_lam1, 1, 8, (V[]){v_x_247, v_hd_245, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_246})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_lam3(V self, V *args);
V g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_lam2(V self, V *args);
V g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_lam1(V self, V *args);
V g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_lam0(V self, V *args);
Clo g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_entry, 4, 0};

V g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283(V v_x1_240, V v_acc_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    return (g_heff_2ecommands_2eload_24s860_24s1032_24s1125(heff_dup(v_f_244), heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_lam0, 1, 5, (V[]){v_p_242, heff_dup(v_f_244), v_acc_241, heff_dup(v_rest_245), v_p_243})));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_intAdd(heff_get(heff_dup(v_acc_241), LBL_total), heff_get(heff_dup(v_x_2411), LBL_total));
  V v_t_2413 = heff_intAdd(heff_get(heff_dup(v_acc_241), LBL_failed), heff_get(heff_dup(v_x_2411), LBL_failed));
  V v_t_2414 = heff_get(heff_dup(v_acc_241), LBL_ok);
  V v_t_2415;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    v_t_2415 = heff_get(heff_dup(v_x_2411), LBL_ok);
    break;
  }
  case TAG_False: {
    v_t_2415 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_t_2416 = heff_intAdd(heff_get(heff_dup(v_acc_241), LBL_tests), heff_get(heff_dup(v_x_2411), LBL_tests));
  V v_t_2417 = heff_intAdd(heff_get(v_acc_241, LBL_testsFailed), heff_get(v_x_2411, LBL_testsFailed));
  return ({ V a_0 = v_rest_245; V a_1 = heff_rec(5, shape_345_96_212_335_336, (V[]){v_t_2412, v_t_2413, v_t_2415, v_t_2416, v_t_2417}); V a_2 = v_p_242; V a_3 = v_p_243; V r_ = (g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
}
V g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_244 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2410 = ({ V a_0 = heff_dup(g_heff_2ecommands_2edefaultSeed_get()); V a_1 = v_f_244; V a_2 = v_x_247; V a_3 = v_x_249; V r_ = (g_heff_2ecommands_2etestOneC_24s908_24s1255(a_0, a_1, a_2, a_3)); heff_drop(v_x_249); r_; });
  return heff_tail(v_t_2410, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_lam3, 1, 4, (V[]){v_acc_241, v_rest_245, v_p_242, v_p_243})});
}
V g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_f_244 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_248 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(v_x_246));
  return heff_tail(v_c_248, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_lam2, 1, 6, (V[]){v_f_244, v_x_247, v_p_242, v_acc_241, v_rest_245, v_p_243})});
}
V g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_str0), heff_get(heff_dup(v_x_246), LBL_errors), MK_INT(0LL), heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283_lam1, 1, 6, (V[]){v_x_246, v_p_242, v_f_244, v_acc_241, v_rest_245, v_p_243})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str0 = {{0x80000000u, K_STR, 0}, 11, 11, {45, 45, 112, 111, 114, 99, 101, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 116, 97, 116, 117, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {114, 101, 102, 115, 47, 116, 97, 103, 115, 47, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {45, 45, 118, 101, 114, 105, 102, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str7 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 101, 118, 45, 112, 97, 114, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str8 = {{0x80000000u, K_STR, 0}, 25, 25, {110, 111, 116, 32, 105, 110, 32, 97, 32, 103, 105, 116, 32, 114, 101, 112, 111, 115, 105, 116, 111, 114, 121, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[52]; } g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str10 = {{0x80000000u, K_STR, 0}, 52, 52, {119, 104, 97, 116, 32, 105, 115, 32, 112, 117, 98, 108, 105, 115, 104, 101, 100, 32, 105, 115, 32, 119, 104, 97, 116, 32, 105, 115, 32, 99, 111, 109, 109, 105, 116, 116, 101, 100, 58, 32, 99, 111, 109, 109, 105, 116, 32, 102, 105, 114, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str12 = {{0x80000000u, K_STR, 0}, 18, 18, {32, 105, 115, 32, 116, 97, 103, 103, 101, 100, 32, 97, 108, 114, 101, 97, 100, 121}};
V g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam0(V self, V *args); static Clo g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam0, 1, 0};
V g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam2(V self, V *args); static Clo g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam2, 1, 0};
V g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam5(V self, V *args);
V g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam4(V self, V *args);
V g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam3(V self, V *args);
V g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam1(V self, V *args);
Clo g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_entry, 5, 0};

V g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282(V v_v_240, V v_pk_241, V v_src_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str0), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str2), v_t_245}), ((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam0_clo)});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2410}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam1, 1, 5, (V[]){v_v_240, v_hd_243, v_k_244, v_src_242, v_pk_241})});
}
V g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam2(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam5(V self, V *args) {
  V v_x_2442 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_pk_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2443 = heff_tr(g_heff_2ecommands_2epublishTested_24s981_24s1108(v_v_240, v_pk_241, v_x_2442));
  return heff_tail(v_t_2443, 2, (V[]){v_hd_243, v_k_244});
}
V g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2441 = heff_rec(5, shape_345_96_212_335_336, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(0LL), MK_INT(0LL)});
  return ({ V a_0 = v_x_2440; V a_1 = v_t_2441; V a_2 = heff_dup(v_hd_243); V a_3 = heff_clo(g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam5, 1, 4, (V[]){v_v_240, v_pk_241, v_hd_243, v_k_244}); V r_ = (g_heff_2ecommands_2etestAll_24s980_24s1107_24s1215_24s1283(a_0, a_1, a_2, a_3)); heff_drop(v_x_2440); r_; });
}
V g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  V v_src_242 = heff_env(self)[4];
  V v_pk_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = heff_intEq(heff_get(heff_dup(v_x_2412), LBL_status), MK_INT(0LL));
  V v_t_2423;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_True: {
    v_t_2423 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2423 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  switch (heff_tag_of(v_t_2423)) {
  case TAG_True: {
    heff_drop(v_x_2421);
    heff_drop(v_v_240);
    heff_drop(v_src_242);
    heff_drop(v_pk_241);
    V v_s_2424 = heff_get(v_x_2412, LBL_err);
    V v_t_2425 = (g_prelude_2eskipSpaces(heff_dup(v_s_2424), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2426 = heff_intSub(heff_strLength(heff_dup(v_s_2424)), MK_INT(1LL));
    V v_t_2427 = (g_prelude_2eskipSpaces(heff_dup(v_s_2424), v_t_2426, MK_INT(-1LL)));
    V v_t_2428 = heff_strSlice(v_s_2424, v_t_2425, heff_intAdd(v_t_2427, MK_INT(1LL)));
    return (g_heff_2ecommands_2epublishFails_24s977_24s1104(heff_strAppend(((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str8), v_t_2428), v_hd_243, v_k_244));
  }
  case TAG_False: {
    V v_s_2429 = heff_get(v_x_2412, LBL_out);
    V v_t_2430 = (g_prelude_2eskipSpaces(heff_dup(v_s_2429), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2431 = heff_intSub(heff_strLength(heff_dup(v_s_2429)), MK_INT(1LL));
    V v_t_2432 = (g_prelude_2eskipSpaces(heff_dup(v_s_2429), v_t_2431, MK_INT(-1LL)));
    V v_t_2433 = heff_strSlice(v_s_2429, v_t_2430, heff_intAdd(v_t_2432, MK_INT(1LL)));
    V v_x1_2434 = heff_strEq(v_t_2433, ((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str9));
    V v_t_2435;
    switch (heff_tag_of(v_x1_2434)) {
    case TAG_True: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_2434);
    }
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      heff_drop(v_x_2421);
      heff_drop(v_v_240);
      heff_drop(v_src_242);
      heff_drop(v_pk_241);
      return (g_heff_2ecommands_2epublishFails_24s977_24s1104(((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str10), v_hd_243, v_k_244));
    }
    case TAG_False: {
      V v_t_2436 = heff_intEq(heff_get(v_x_2421, LBL_status), MK_INT(0LL));
      switch (heff_tag_of(v_t_2436)) {
      case TAG_True: {
        heff_drop(v_src_242);
        heff_drop(v_pk_241);
        V v_t_2437 = heff_strAppend(((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str11), heff_strAppend(v_v_240, ((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str12)));
        return (g_heff_2ecommands_2epublishFails_24s977_24s1104(v_t_2437, v_hd_243, v_k_244));
      }
      case TAG_False: {
        V v_t_2438 = heff_tag(TAG_Cons, 2, (V[]){v_src_242, NTAG(TAG_Nil)});
        V v_c_2439 = (g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191(v_t_2438, NTAG(TAG_Nil)));
        return heff_tail(v_c_2439, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam4, 1, 4, (V[]){v_hd_243, v_v_240, v_pk_241, v_k_244})});
      }
      default: return heff_nomatch(v_t_2436);
      }
    }
    default: return heff_nomatch(v_t_2435);
    }
  }
  default: return heff_nomatch(v_t_2423);
  }
}
V g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_src_242 = heff_env(self)[3];
  V v_pk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str3), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str4), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str5), v_t_2413})});
  V v_t_2416 = heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str6), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_str7), v_t_2414}), ((V)&g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam2_clo)});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2420, heff_clo(g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282_lam3, 1, 6, (V[]){v_x_2412, v_hd_243, v_k_244, v_v_240, v_src_242, v_pk_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
V g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_lam1(V self, V *args);
V g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_lam0(V self, V *args);
Clo g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_entry, 3, 0};

V g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281(V v_v_240, V v_l_241, V v_pk_242) {
top: ;
  V v_t_243 = (g_heff_2eproject_2emajorMismatch(heff_get(heff_dup(v_pk_242), LBL_module), heff_dup(v_v_240)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_st_244 = heff_get(heff_get(heff_dup(v_l_241), LBL_paths), LBL_style);
    V v_t_245 = heff_get(heff_get(heff_dup(v_l_241), LBL_paths), LBL_root);
    V v_t_246 = (g_std_2epath_2eparse(v_st_244, v_t_245));
    V v_t_247 = (g_std_2epath_2eparse(v_st_244, ((V)&g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_str0)));
    V v_p_248 = (g_std_2epath_2ejoin_2eonto_240(v_t_246, v_t_247));
    V v_t_249 = ({ V a_0 = heff_get(heff_dup(v_p_248), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_248), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2410 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_248), LBL_drive), heff_get(v_p_248, LBL_absolute), v_t_249});
    V v_t_2411 = ({ V a_0 = v_st_244; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); r_; });
    V v_c_2412 = heff_tr(heff_apply(((V)&g_heff_2eload_2eownDir_24s880_24s1139_clo), 2, (V[]){heff_get(heff_dup(v_l_241), LBL_paths), v_t_2411}));
    return heff_clo(g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_lam0, 2, 4, (V[]){v_c_2412, v_l_241, v_v_240, v_pk_242});
  }
  case TAG_Just: {
    V v_why_2426 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop(v_l_241);
    V v_t_2427 = heff_strAppend(heff_get(v_pk_242, LBL_module), heff_strAppend(((V)&g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_str2), v_why_2426));
    return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s977_24s1103_clo), 1, (V[]){v_t_2427});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_why_2416 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    heff_drop(v_l_241);
    heff_drop(v_v_240);
    heff_drop(v_pk_242);
    return (g_heff_2ecommands_2epublishFails_24s977_24s1104(v_why_2416, v_hd_2413, v_k_2414));
  }
  case TAG_Right: {
    heff_take_n(v_x_2415, 0ULL, 1);
    V v_st_2418 = heff_get(heff_get(heff_dup(v_l_241), LBL_paths), LBL_style);
    V v_t_2419 = heff_get(heff_get(v_l_241, LBL_paths), LBL_root);
    V v_t_2420 = (g_std_2epath_2eparse(v_st_2418, v_t_2419));
    V v_t_2421 = (g_std_2epath_2eparse(v_st_2418, ((V)&g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_str1)));
    V v_p_2422 = (g_std_2epath_2ejoin_2eonto_240(v_t_2420, v_t_2421));
    V v_t_2423 = ({ V a_0 = heff_get(heff_dup(v_p_2422), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2422), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2424 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2422), LBL_drive), heff_get(v_p_2422, LBL_absolute), v_t_2423});
    V v_t_2425 = ({ V a_0 = v_st_2418; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); r_; });
    return (g_heff_2ecommands_2epublishGit_24s979_24s1106_24s1214_24s1282(v_v_240, v_pk_242, v_t_2425, v_hd_2413, v_k_2414));
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  V v_pk_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo(g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281_lam1, 1, 5, (V[]){v_hd_2413, v_k_2414, v_l_241, v_v_240, v_pk_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str1 = {{0x80000000u, K_STR, 0}, 22, 22, {96, 32, 105, 115, 32, 110, 111, 32, 118, 101, 114, 115, 105, 111, 110, 58, 32, 97, 46, 98, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str2 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[49]; } g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str3 = {{0x80000000u, K_STR, 0}, 49, 49, {110, 111, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 104, 101, 114, 101, 58, 32, 112, 117, 98, 108, 105, 115, 104, 32, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str4 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str6 = {{0x80000000u, K_STR, 0}, 24, 24, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 114, 101, 97, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str7 = {{0x80000000u, K_STR, 0}, 42, 42, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 105, 115, 32, 110, 111, 32, 80, 97, 99, 107, 97, 103, 101, 32, 40, 108, 105, 98, 47, 109, 97, 110, 105, 102, 101, 115, 116, 46, 104, 102, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str8 = {{0x80000000u, K_STR, 0}, 42, 42, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 105, 115, 32, 110, 111, 32, 80, 97, 99, 107, 97, 103, 101, 32, 40, 108, 105, 98, 47, 109, 97, 110, 105, 102, 101, 115, 116, 46, 104, 102, 41}};
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam1(V self, V *args); static Clo g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam1, 1, 0};
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam6(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam5(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam4(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam3(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam2(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam0(V self, V *args);
Clo g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_entry, 1, 0};

V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280(V v_v_240) {
top: ;
  V v_t_241 = (g_heff_2eproject_2eversion(heff_dup(v_v_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    V v_t_242 = heff_strAppend(((V)&g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str0), heff_strAppend(v_v_240, ((V)&g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str1)));
    return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s977_24s1103_clo), 1, (V[]){v_t_242});
  }
  case TAG_Just: {
    heff_take_n(v_t_241, 0ULL, 1);
    return heff_clo(g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam0, 2, 1, (V[]){v_v_240});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280(a[0]);
}
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam1(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_v_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2417);
  V v_t_2418 = heff_get(heff_dup(v_x_2413), LBL_package);
  switch (heff_tag_of(v_t_2418)) {
  case TAG_Nothing: {
    heff_drop(v_x_2413);
    heff_drop(v_x_2414);
    heff_drop(v_x_2416);
    heff_drop(v_v_240);
    return (g_heff_2ecommands_2epublishFails_24s977_24s1104(((V)&g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str6), v_hd_244, v_k_245));
  }
  case TAG_Just: {
    V v_pk_2419 = heff_field(v_t_2418, 0);
    heff_take_n(v_t_2418, 1ULL, 1);
    V v_t_2420 = heff_intLt(MK_INT(0LL), v_x_2414);
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      heff_drop(v_x_2413);
      heff_drop(v_x_2416);
      heff_drop(v_v_240);
      heff_drop(v_pk_2419);
      return (g_heff_2ecommands_2epublishFails_24s977_24s1104(((V)&g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str7), v_hd_244, v_k_245));
    }
    case TAG_False: {
      V v_t_2421 = ({ V a_0 = v_x_2416; V r_ = (g_prelude_2eany_24s798(a_0)); heff_drop(v_x_2416); r_; });
      switch (heff_tag_of(v_t_2421)) {
      case TAG_True: {
        heff_drop(v_x_2413);
        heff_drop(v_v_240);
        heff_drop(v_pk_2419);
        return (g_heff_2ecommands_2epublishFails_24s977_24s1104(((V)&g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str8), v_hd_244, v_k_245));
      }
      case TAG_False: {
        V v_t_2422 = heff_tr(g_heff_2ecommands_2epublishChecked_24s978_24s1105_24s1213_24s1281(v_v_240, v_x_2413, v_pk_2419));
        return heff_tail(v_t_2422, 2, (V[]){v_hd_244, v_k_245});
      }
      default: return heff_nomatch(v_t_2421);
      }
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_v_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecommands_2eputFileDiags_24s894_24s1249(heff_dup(v_x_2416), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam6, 1, 6, (V[]){v_x_2413, v_hd_244, v_k_245, v_x_2414, v_x_2416, v_v_240})));
}
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2415 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(heff_dup(v_x_2413)));
  return heff_tail(v_c_2415, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam5, 1, 5, (V[]){v_hd_244, v_x_2413, v_k_245, v_x_2414, v_v_240})});
}
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str5), heff_get(heff_dup(v_x_2413), LBL_errors), MK_INT(0LL), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam4, 1, 4, (V[]){v_x_2413, v_hd_244, v_k_245, v_v_240})));
}
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    heff_drop(v_v_240);
    return (g_heff_2ecommands_2epublishFails_24s977_24s1104(((V)&g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str3), v_hd_244, v_k_245));
  }
  case TAG_Just: {
    heff_take_n(v_x_2411, 0ULL, 1);
    return (g_heff_2ecommands_2eload_24s860_24s1032_24s1125(((V)&g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str4), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam3, 1, 3, (V[]){v_hd_244, v_k_245, v_v_240})));
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_str2), ((V)&g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam1_clo)})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_249}));
  V f_ = heff_get(heff_dup(v_hd_244), LBL_bind);
  args[0] = v_t_2410;
  args[1] = heff_clo(g_heff_2ecommands_2epublishCmd_24s976_24s1102_24s1212_24s1280_lam2, 1, 3, (V[]){v_hd_244, v_k_245, v_v_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eevalDiags_24s1027_24s1116_24s1286_lam1(V self, V *args);
V g_heff_2ecommands_2eevalDiags_24s1027_24s1116_24s1286_lam0(V self, V *args);
Clo g_heff_2ecommands_2eevalDiags_24s1027_24s1116_24s1286_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eevalDiags_24s1027_24s1116_24s1286_entry, 4, 0};

V g_heff_2ecommands_2eevalDiags_24s1027_24s1116_24s1286(V v_badL_240, V v_cs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecommands_2eputFileDiags_24s894_24s1249(heff_dup(v_cs_241), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2eevalDiags_24s1027_24s1116_24s1286_lam0, 1, 4, (V[]){v_cs_241, v_hd_242, v_k_243, heff_dup(v_badL_240)})));
}
V g_heff_2ecommands_2eevalDiags_24s1027_24s1116_24s1286_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eevalDiags_24s1027_24s1116_24s1286(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eevalDiags_24s1027_24s1116_24s1286_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_badL_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2414);
  switch (heff_tag_of(v_badL_240)) {
  case TAG_True: {
    heff_drop(v_cs_241);
    V v_t_2415 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2418}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2419, v_k_243});
  }
  case TAG_False: {
    V v_t_2420 = ({ V a_0 = v_cs_241; V r_ = (g_prelude_2eany_24s798(a_0)); heff_drop(v_cs_241); r_; });
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      V v_t_2421 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2424}));
      return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2425, v_k_243});
    }
    case TAG_False: {
      heff_drop(v_hd_242);
      V f_ = v_k_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  default: return heff_nomatch(v_badL_240);
  }
}
V g_heff_2ecommands_2eevalDiags_24s1027_24s1116_24s1286_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_badL_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_244);
  V v_t_245 = (g_heff_2edriver_2elastChecked(v_cs_241));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_cs_241);
    heff_drop(v_badL_240);
    V v_t_246 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2410, v_k_243});
  }
  case TAG_Just: {
    V v_c_2411 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_2412 = (g_heff_2edriver_2eevaluate(v_c_2411));
    V v_c_2413 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintEvals_24s1028_clo), 1, (V[]){v_t_2412}));
    return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2eevalDiags_24s1027_24s1116_24s1286_lam1, 1, 4, (V[]){v_badL_240, v_hd_242, v_k_243, v_cs_241})});
  }
  default: return heff_nomatch(v_t_245);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_lam2(V self, V *args);
V g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_lam1(V self, V *args);
V g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_lam0(V self, V *args);
Clo g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_entry, 3, 0};

V g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285(V v_file_240, V v_hd_241, V v_k_242) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2eload_24s860_24s1032_24s1125(v_file_240, heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_lam0, 1, 2, (V[]){v_hd_241, v_k_242}));
}
V g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V b_0 = heff_intLt(MK_INT(0LL), v_x_244); V a_1 = v_x_246; V a_2 = v_hd_241; V a_3 = v_k_242; V r_ = (g_heff_2ecommands_2eevalDiags_24s1027_24s1116_24s1286(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
V g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(v_x_243));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_lam2, 1, 3, (V[]){v_x_244, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_str0), heff_get(heff_dup(v_x_243), LBL_errors), MK_INT(0LL), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eevalCmd_24s1026_24s1115_24s1244_24s1285_lam1, 1, 3, (V[]){v_x_243, v_hd_241, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {32, 116, 101, 115, 116, 115, 32, 104, 111, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_str5 = {{0x80000000u, K_STR, 0}, 18, 18, {32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 104, 111, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam1(V self, V *args);
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam2(V self, V *args);
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam0(V self, V *args);
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam3(V self, V *args); static Clo g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam3, 1, 0};
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam6(V self, V *args);
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam5(V self, V *args);
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam4(V self, V *args);
Clo g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_entry, 6, 0};

V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325(V v_tk_240, V v_seed_241, V v_x3_242, V v_acc_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seed_241);
    V v_t_246 = heff_tag(TAG_End, 2, (V[]){v_tk_240, NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_p_244), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})}));
    return heff_tail(heff_get(heff_dup(v_p_244), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam0, 1, 3, (V[]){v_acc_243, v_p_244, v_p_245})});
  }
  case TAG_Cons: {
    V v_f_2443 = heff_field(v_x3_242, 0);
    V v_rest_2444 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2446 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(v_tk_240), heff_dup(v_f_2443), MK_INT(0LL), ((V)&g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam3_clo)})});
    V v_t_2447 = heff_tr(heff_apply(heff_get(heff_dup(v_p_244), LBL_malg), 1, (V[]){v_t_2446}));
    return heff_tail(heff_get(heff_dup(v_p_244), LBL_bind), 2, (V[]){v_t_2447, heff_clo(g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam4, 1, 7, (V[]){v_seed_241, v_f_2443, v_p_244, v_acc_243, v_tk_240, v_rest_2444, v_p_245})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k2_2417 = args[1];
  V v_str_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2415, ((V)&g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_str6)), NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2416), LBL_malg), 1, (V[]){v_t_2421}));
  V f_ = heff_get(v_hd_2416, LBL_bind);
  args[0] = v_t_2422;
  args[1] = v_k2_2417;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2424);
  V v_t_2425 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_acc_243), LBL_failed));
  switch (heff_tag_of(v_t_2425)) {
  case TAG_True: {
    heff_drop(v_acc_243);
    V v_t_2426 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_p_244), LBL_malg), 1, (V[]){v_t_2429}));
    return heff_tail(heff_get(v_p_244, LBL_bind), 2, (V[]){v_t_2430, v_p_245});
  }
  case TAG_False: {
    V v_t_2431 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_acc_243), LBL_testsFailed));
    switch (heff_tag_of(v_t_2431)) {
    case TAG_True: {
      heff_drop(v_acc_243);
      V v_t_2432 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_p_244), LBL_malg), 1, (V[]){v_t_2435}));
      return heff_tail(heff_get(v_p_244, LBL_bind), 2, (V[]){v_t_2436, v_p_245});
    }
    case TAG_False: {
      V v_t_2437 = heff_get(v_acc_243, LBL_ok);
      switch (heff_tag_of(v_t_2437)) {
      case TAG_True: {
        heff_drop(v_p_244);
        V f_ = v_p_245;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_False: {
        V v_t_2438 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2439 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2438})});
        V v_t_2440 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})});
        V v_t_2441 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})});
        V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_p_244), LBL_malg), 1, (V[]){v_t_2441}));
        return heff_tail(heff_get(v_p_244, LBL_bind), 2, (V[]){v_t_2442, v_p_245});
      }
      default: return heff_nomatch(v_t_2437);
      }
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  default: return heff_nomatch(v_t_2425);
  }
}
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_248);
  V v_t_249 = heff_intSub(heff_get(heff_dup(v_acc_243), LBL_total), heff_get(heff_dup(v_acc_243), LBL_failed));
  V v_t_2410 = heff_intShow(heff_get(heff_dup(v_acc_243), LBL_total));
  V v_tests_2411 = heff_get(heff_dup(v_acc_243), LBL_tests);
  V v_t_2412 = heff_intEq(heff_dup(v_tests_2411), MK_INT(0LL));
  V v_t_2414;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_tests_2411);
    v_t_2414 = ((V)&g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_str0);
    break;
  }
  case TAG_False: {
    V v_t_2413 = heff_intSub(heff_dup(v_tests_2411), heff_get(heff_dup(v_acc_243), LBL_testsFailed));
    v_t_2414 = heff_strAppend(((V)&g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_str1), heff_strAppend(heff_intShow(v_t_2413), heff_strAppend(((V)&g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_str2), heff_strAppend(heff_intShow(v_tests_2411), ((V)&g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_str3)))));
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_str_2415 = heff_strAppend(heff_intShow(v_t_249), heff_strAppend(((V)&g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_str4), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_str5), v_t_2414))));
  V v_c_2423 = heff_clo(g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam1, 2, 1, (V[]){v_str_2415});
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_p_244), heff_clo(g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam2, 1, 3, (V[]){v_acc_243, v_p_244, v_p_245})});
}
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam3(V self, V *args) {
  V v_t_2445 = args[0];
  return v_t_2445;
}
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam6(V self, V *args) {
  V v_x_2452 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_x_2449 = heff_env(self)[1];
  V v_tk_240 = heff_env(self)[2];
  V v_seed_241 = heff_env(self)[3];
  V v_rest_2444 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2452);
  V v_t_2453 = heff_intAdd(heff_get(heff_dup(v_acc_243), LBL_total), heff_get(heff_dup(v_x_2449), LBL_total));
  V v_t_2454 = heff_intAdd(heff_get(heff_dup(v_acc_243), LBL_failed), heff_get(heff_dup(v_x_2449), LBL_failed));
  V v_t_2455 = heff_get(heff_dup(v_acc_243), LBL_ok);
  V v_t_2456;
  switch (heff_tag_of(v_t_2455)) {
  case TAG_True: {
    v_t_2456 = heff_get(heff_dup(v_x_2449), LBL_ok);
    break;
  }
  case TAG_False: {
    v_t_2456 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2455);
  }
  V v_t_2457 = heff_intAdd(heff_get(heff_dup(v_acc_243), LBL_tests), heff_get(heff_dup(v_x_2449), LBL_tests));
  V v_t_2458 = heff_intAdd(heff_get(v_acc_243, LBL_testsFailed), heff_get(v_x_2449, LBL_testsFailed));
  return (g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325(v_tk_240, v_seed_241, v_rest_2444, heff_rec(5, shape_345_96_212_335_336, (V[]){v_t_2453, v_t_2454, v_t_2456, v_t_2457, v_t_2458}), v_p_244, v_p_245));
}
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam5(V self, V *args) {
  V v_x_2449 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_tk_240 = heff_env(self)[3];
  V v_seed_241 = heff_env(self)[4];
  V v_rest_2444 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2450 = heff_tag(TAG_End, 2, (V[]){v_x_2448, NTAG(TAG_MkUnit)});
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_p_244), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2450})}));
  return heff_tail(heff_get(heff_dup(v_p_244), LBL_bind), 2, (V[]){v_t_2451, heff_clo(g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam6, 1, 7, (V[]){v_acc_243, v_x_2449, v_tk_240, v_seed_241, v_rest_2444, v_p_244, v_p_245})});
}
V g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam4(V self, V *args) {
  V v_x_2448 = args[0];
  V v_seed_241 = heff_env(self)[0];
  V v_f_2443 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_tk_240 = heff_env(self)[4];
  V v_rest_2444 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ecommands_2etestOneF_24s907_24s1049_24s1156_24s1254(heff_dup(v_seed_241), v_f_2443, heff_dup(v_p_244), heff_clo(g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325_lam5, 1, 7, (V[]){v_x_2448, v_p_244, v_acc_243, v_tk_240, v_seed_241, v_rest_2444, v_p_245})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {116, 101, 115, 116, 105, 110, 103}};
V g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_lam1(V self, V *args); static Clo g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_lam1, 1, 0};
V g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_lam0(V self, V *args);
V g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_lam3(V self, V *args);
V g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_lam2(V self, V *args);
Clo g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_entry, 2, 0};

V g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324(V v_seed_240, V v_files_241) {
top: ;
  V v_total_242 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_files_241));
  V v_c_248 = heff_clo(g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_lam0, 2, 1, (V[]){v_total_242});
  return heff_clo(g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_lam2, 2, 3, (V[]){v_c_248, v_seed_240, v_files_241});
}
V g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324(a[0], a[1]);
}
V g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_lam1(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k2_244 = args[1];
  V v_total_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_str0), v_total_242, ((V)&g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_lam1_clo)})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_246}));
  V f_ = heff_get(v_hd_243, LBL_bind);
  args[0] = v_t_247;
  args[1] = v_k2_244;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_seed_240 = heff_env(self)[0];
  V v_files_241 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_rec(5, shape_345_96_212_335_336, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(0LL), MK_INT(0LL)});
  return (g_heff_2ecommands_2etestCmd_24s906_24s1048_24s1155_24s1253_24s1325(v_x_2411, v_seed_240, v_files_241, v_t_2412, v_hd_249, v_k_2410));
}
V g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_lam2(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_files_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo(g_heff_2ecommands_2etestsCmd_24s905_24s1047_24s1154_24s1252_24s1324_lam3, 1, 4, (V[]){v_seed_240, v_files_241, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 97, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str1 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 101, 116, 99, 104, 105, 110, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str3 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {45, 45, 98, 114, 97, 110, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str7 = {{0x80000000u, K_STR, 0}, 7, 7, {45, 45, 113, 117, 105, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {45, 45, 100, 101, 112, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str9 = {{0x80000000u, K_STR, 0}, 25, 25, {97, 100, 118, 105, 99, 101, 46, 100, 101, 116, 97, 99, 104, 101, 100, 72, 101, 97, 100, 61, 102, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str10 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 108, 111, 110, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str12 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str13 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str14 = {{0x80000000u, K_STR, 0}, 13, 13, {99, 97, 110, 110, 111, 116, 32, 102, 101, 116, 99, 104, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 40, 116, 97, 103, 32, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str17 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str18 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str19 = {{0x80000000u, K_STR, 0}, 11, 11, {72, 69, 65, 68, 94, 123, 116, 114, 101, 101, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str20 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 101, 118, 45, 112, 97, 114, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str21 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str22 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 67}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str23 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str24 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 114, 101, 101, 58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str25 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 97, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str27 = {{0x80000000u, K_STR, 0}, 18, 18, {104, 101, 102, 102, 32, 103, 101, 116, 58, 32, 102, 101, 116, 99, 104, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str30 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 97, 110, 110, 111, 116, 32, 107, 101, 101, 112, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str32 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 105, 110, 32}};
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam0(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam3(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam3, 1, 0};
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam5(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam5, 1, 0};
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam8(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam8, 1, 0};
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam7(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam10(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam10, 1, 0};
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam13(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam13, 1, 0};
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam12(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam16(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam16, 1, 0};
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam17(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam18(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam18, 1, 0};
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam21(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam21, 1, 0};
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam20(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam23(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam23, 1, 0};
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam25(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam27(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam27, 1, 0};
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam29(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam28(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam26(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam24(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam22(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam19(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam15(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam14(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam11(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam9(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam6(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam4(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam2(V self, V *args);
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam1(V self, V *args);
Clo g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_entry, 3, 0};

V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_x_243 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_241), heff_dup(v_v_242)));
  V v_c_246 = heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam0, 2, 1, (V[]){v_x_243});
  return heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam1, 2, 4, (V[]){v_c_246, v_ps_240, v_path_241, v_v_242});
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_x_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam3(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam5(V self, V *args) {
  V v_ok_2416 = args[0];
  return v_ok_2416;
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam8(V self, V *args) {
  V v_ok_2431 = args[0];
  return v_ok_2431;
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam7(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k2_2430 = args[1];
  V v_path_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_2428, ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam8_clo)})});
  V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2429), LBL_malg), 1, (V[]){v_t_2434}));
  V f_ = heff_get(v_hd_2429, LBL_bind);
  args[0] = v_t_2435;
  args[1] = v_k2_2430;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam10(V self, V *args) {
  V v_t_2439 = args[0];
  return v_t_2439;
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam13(V self, V *args) {
  V v_r_2452 = args[0];
  return v_r_2452;
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam12(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k2_2451 = args[1];
  V v_as_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2453 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str12), v_as_2449, ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam13_clo)})});
  V v_t_2454 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2450), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2455})}));
  V f_ = heff_get(v_hd_2450, LBL_bind);
  args[0] = v_t_2456;
  args[1] = v_k2_2451;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam16(V self, V *args) {
  V v_ok_2464 = args[0];
  return v_ok_2464;
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam17(V self, V *args) {
  V v_x_2469 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_x_2458 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2469);
  V v_t_2470 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str13), (g_heff_2eproject_2erepoOf(heff_dup(v_path_241))));
  V v_s_2471 = heff_get(v_x_2458, LBL_err);
  V v_t_2472 = (g_prelude_2eskipSpaces(heff_dup(v_s_2471), MK_INT(0LL), MK_INT(1LL)));
  V v_t_2473 = heff_intSub(heff_strLength(heff_dup(v_s_2471)), MK_INT(1LL));
  V v_t_2474 = (g_prelude_2eskipSpaces(heff_dup(v_s_2471), v_t_2473, MK_INT(-1LL)));
  V v_t_2475 = heff_strSlice(v_s_2471, v_t_2472, heff_intAdd(v_t_2474, MK_INT(1LL)));
  V v_t_2476 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str14), heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str15), heff_strAppend(heff_dup(v_v_242), heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str16), heff_strAppend(v_v_242, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str17), heff_strAppend(v_t_2470, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str18), v_t_2475)))))))));
  V v_x_2477 = heff_tag(TAG_Left, 1, (V[]){v_t_2476});
  V f_ = v_k_248;
  args[0] = v_x_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam18(V self, V *args) {
  V v_r_2480 = args[0];
  return v_r_2480;
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam21(V self, V *args) {
  V v_ok_2496 = args[0];
  return v_ok_2496;
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam20(V self, V *args) {
  V v_hd_2494 = args[0];
  V v_k2_2495 = args[1];
  V v_path_2493 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2497 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){v_path_2493, ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam21_clo)})});
  V v_t_2498 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2494), LBL_malg), 1, (V[]){v_t_2499}));
  V f_ = heff_get(v_hd_2494, LBL_bind);
  args[0] = v_t_24100;
  args[1] = v_k2_2495;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam23(V self, V *args) {
  V v_ok_24103 = args[0];
  return v_ok_24103;
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam25(V self, V *args) {
  V v_hd_24115 = args[0];
  V v_k_24116 = args[1];
  V v_x_24114 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24115);
  V f_ = v_k_24116;
  args[0] = v_x_24114;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam27(V self, V *args) {
  V v_ok_24119 = args[0];
  return v_ok_24119;
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam29(V self, V *args) {
  V v_x_24133 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_24118 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24133);
  V f_ = v_k_248;
  args[0] = heff_tag(TAG_Right, 1, (V[]){v_x_24118});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam28(V self, V *args) {
  V v_x_24124 = args[0];
  V v_x_2486 = heff_env(self)[0];
  V v_x_24108 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_x_24118 = heff_env(self)[6];
  V v_x_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_24125 = heff_intEq(heff_get(v_x_2486, LBL_status), MK_INT(0LL));
  V v_t_24126;
  switch (heff_tag_of(v_t_24125)) {
  case TAG_True: {
    switch (heff_tag_of(v_x_24108)) {
    case TAG_True: {
      v_t_24126 = v_x_24124;
      break;
    }
    case TAG_False: {
      heff_drop(v_x_24124);
      v_t_24126 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_24108);
    }
    break;
  }
  case TAG_False: {
    heff_drop(v_x_24124);
    heff_drop(v_x_24108);
    v_t_24126 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_24125);
  }
  switch (heff_tag_of(v_t_24126)) {
  case TAG_True: {
    heff_drop(v_x_249);
    V v_t_24127 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str27), heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str28), v_v_242)));
    V v_t_24128 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_24127, ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str29)), NTAG(TAG_MkUnit)});
    V v_t_24129 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24128})});
    V v_t_24130 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24129})});
    V v_t_24131 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24130})});
    V v_t_24132 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_24131}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_24132, heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam29, 1, 2, (V[]){v_k_248, v_x_24118})});
  }
  case TAG_False: {
    heff_drop(v_hd_247);
    heff_drop(v_x_24118);
    V v_t_24134 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str30), heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str31), heff_strAppend(v_v_242, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str32), v_x_249)))));
    V f_ = v_k_248;
    args[0] = heff_tag(TAG_Left, 1, (V[]){v_t_24134});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_24126);
  }
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam26(V self, V *args) {
  V v_x_24118 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_x_2486 = heff_env(self)[2];
  V v_x_24108 = heff_env(self)[3];
  V v_path_241 = heff_env(self)[4];
  V v_v_242 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_24120 = heff_tag(TAG_WriteFile, 3, (V[]){heff_strAppend(heff_dup(v_x_249), ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str25)), heff_strAppend(heff_dup(v_x_24118), ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str26)), ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam27_clo)});
  V v_t_24121 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24120})});
  V v_t_24122 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24121})});
  V v_t_24123 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24122})}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_24123, heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam28, 1, 8, (V[]){v_x_2486, v_x_24108, v_path_241, v_v_242, v_hd_247, v_k_248, v_x_24118, v_x_249})});
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam24(V self, V *args) {
  V v_x_24108 = args[0];
  V v_x_2486 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_s_24109 = heff_get(heff_dup(v_x_2486), LBL_out);
  V v_t_24110 = (g_prelude_2eskipSpaces(heff_dup(v_s_24109), MK_INT(0LL), MK_INT(1LL)));
  V v_t_24111 = heff_intSub(heff_strLength(heff_dup(v_s_24109)), MK_INT(1LL));
  V v_t_24112 = (g_prelude_2eskipSpaces(heff_dup(v_s_24109), v_t_24111, MK_INT(-1LL)));
  V v_t_24113 = heff_strSlice(v_s_24109, v_t_24110, heff_intAdd(v_t_24112, MK_INT(1LL)));
  V v_x_24114 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str24), v_t_24113);
  V v_c_24117 = heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam25, 2, 1, (V[]){v_x_24114});
  return heff_tail(v_c_24117, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam26, 1, 7, (V[]){v_x_249, v_hd_247, v_x_2486, v_x_24108, v_path_241, v_v_242, v_k_248})});
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam22(V self, V *args) {
  V v_x_24102 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_x_2486 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24102);
  V v_t_24104 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadOnly, 2, (V[]){heff_dup(v_x_249), ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam23_clo)})});
  V v_t_24105 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_24106}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_24107, heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam24, 1, 6, (V[]){v_x_2486, v_hd_247, v_x_249, v_path_241, v_v_242, v_k_248})});
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam19(V self, V *args) {
  V v_x_2486 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2487 = heff_get(v_ps_240, LBL_style);
  V v_t_2488 = (g_std_2epath_2eparse(v_st_2487, heff_dup(v_x_249)));
  V v_t_2489 = (g_std_2epath_2eparse(v_st_2487, ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str23)));
  V v_p_2490 = (g_std_2epath_2ejoin_2eonto_240(v_t_2488, v_t_2489));
  V v_t_2491 = ({ V a_0 = heff_get(heff_dup(v_p_2490), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2490), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2492 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2490), LBL_drive), heff_get(v_p_2490, LBL_absolute), v_t_2491});
  V v_path_2493 = ({ V a_0 = v_st_2487; V a_1 = v_t_2492; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2487); r_; });
  V v_c_24101 = heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam20, 2, 1, (V[]){v_path_2493});
  return heff_tail(v_c_24101, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam22, 1, 6, (V[]){v_x_249, v_hd_247, v_x_2486, v_path_241, v_v_242, v_k_248})});
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam15(V self, V *args) {
  V v_x_2461 = args[0];
  V v_x_2458 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_ps_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2461);
  V v_t_2462 = heff_intEq(heff_get(heff_dup(v_x_2458), LBL_status), MK_INT(0LL));
  V v_t_2463;
  switch (heff_tag_of(v_t_2462)) {
  case TAG_True: {
    v_t_2463 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2463 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2462);
  }
  switch (heff_tag_of(v_t_2463)) {
  case TAG_True: {
    heff_drop(v_ps_240);
    V v_t_2465 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){v_x_249, ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam16_clo)})});
    V v_t_2466 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2467}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2468, heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam17, 1, 4, (V[]){v_path_241, v_x_2458, v_v_242, v_k_248})});
  }
  case TAG_False: {
    heff_drop(v_x_2458);
    V v_t_2478 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str19), NTAG(TAG_Nil)});
    V v_t_2479 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_249), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str20), v_t_2478})});
    V v_t_2481 = heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str21), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str22), v_t_2479}), ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam18_clo)});
    V v_t_2482 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2484}));
    return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2485, heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam19, 1, 6, (V[]){v_ps_240, v_x_249, v_hd_247, v_path_241, v_v_242, v_k_248})});
  }
  default: return heff_nomatch(v_t_2463);
  }
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam14(V self, V *args) {
  V v_x_2458 = args[0];
  V v_x_2442 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_ps_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2459 = heff_tag(TAG_End, 2, (V[]){v_x_2442, NTAG(TAG_MkUnit)});
  V v_t_2460 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2459})}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2460, heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam15, 1, 7, (V[]){v_x_2458, v_x_249, v_hd_247, v_path_241, v_v_242, v_k_248, v_ps_240})});
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam11(V self, V *args) {
  V v_x_2442 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2443 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str3), (g_heff_2eproject_2erepoOf(heff_dup(v_path_241))));
  V v_t_2444 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_249), NTAG(TAG_Nil)});
  V v_t_2445 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str4), heff_dup(v_v_242)), heff_tag(TAG_Cons, 2, (V[]){v_t_2443, v_t_2444})});
  V v_t_2446 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str6), v_t_2445})});
  V v_t_2447 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str8), v_t_2446})});
  V v_t_2448 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str10), v_t_2447})});
  V v_as_2449 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str11), v_t_2448});
  V v_c_2457 = heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam12, 2, 1, (V[]){v_as_2449});
  return heff_tail(v_c_2457, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam14, 1, 7, (V[]){v_x_2442, v_hd_247, v_x_249, v_path_241, v_v_242, v_k_248, v_ps_240})});
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str1), heff_strAppend(heff_dup(v_path_241), heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str2), heff_dup(v_v_242))));
  V v_t_2440 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2438, MK_INT(0LL), ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam10_clo)})});
  V v_t_2441 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2440}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2441, heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam11, 1, 6, (V[]){v_path_241, v_x_249, v_v_242, v_hd_247, v_k_248, v_ps_240})});
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2421);
  V v_st_2422 = heff_get(heff_dup(v_ps_240), LBL_style);
  V v_p_2423 = (g_std_2epath_2eparse(v_st_2422, heff_dup(v_x_249)));
  V v_t_2424 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2423), LBL_segments)));
  V v_xs_2425 = (g_prelude_2edrop(MK_INT(1LL), v_t_2424));
  V v_t_2426 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2425));
  V v_t_2427 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2423), LBL_drive), heff_get(v_p_2423, LBL_absolute), v_t_2426});
  V v_path_2428 = ({ V a_0 = v_st_2422; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); r_; });
  V v_c_2436 = heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam7, 2, 1, (V[]){v_path_2428});
  return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam9, 1, 6, (V[]){v_path_241, v_v_242, v_hd_247, v_x_249, v_k_248, v_ps_240})});
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){heff_dup(v_x_249), ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam5_clo)})});
    V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2419}));
    return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2420, heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam6, 1, 6, (V[]){v_ps_240, v_x_249, v_hd_247, v_path_241, v_v_242, v_k_248})});
  }
  case TAG_Just: {
    V v_h_24135 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Just = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    heff_drop(v_x_249);
    heff_drop(v_hd_247);
    heff_drop(v_ps_240);
    heff_drop(v_path_241);
    heff_drop(v_v_242);
    V v_t_24136 = (g_prelude_2eskipSpaces(heff_dup(v_h_24135), MK_INT(0LL), MK_INT(1LL)));
    V v_t_24137 = heff_intSub(heff_strLength(heff_dup(v_h_24135)), MK_INT(1LL));
    V v_t_24138 = (g_prelude_2eskipSpaces(heff_dup(v_h_24135), v_t_24137, MK_INT(-1LL)));
    V v_t_24139 = heff_strSlice(v_h_24135, v_t_24136, heff_intAdd(v_t_24138, MK_INT(1LL)));
    V v_x_24140 = heff_tag_at(v_ru_24x_2415_24Just, TAG_Right, 1, (V[]){v_t_24139});
    V f_ = v_k_248;
    args[0] = v_x_24140;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag(TAG_ReadFile, 2, (V[]){heff_strAppend(heff_dup(v_x_249), ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_str0)), ((V)&g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam3_clo)});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2413})}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam4, 1, 6, (V[]){v_x_249, v_hd_247, v_ps_240, v_path_241, v_v_242, v_k_248})});
}
V g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330_lam2, 1, 5, (V[]){v_hd_247, v_ps_240, v_path_241, v_v_242, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 114, 101, 113, 117, 105, 114, 101, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 105, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_str5 = {{0x80000000u, K_STR, 0}, 20, 20, {44, 32, 97, 110, 100, 32, 104, 101, 102, 102, 46, 115, 117, 109, 32, 115, 97, 121, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_str6 = {{0x80000000u, K_STR, 0}, 24, 24, {58, 32, 105, 116, 115, 32, 116, 97, 103, 32, 104, 97, 115, 32, 98, 101, 101, 110, 32, 109, 111, 118, 101, 100}};
V g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam0(V self, V *args);
V g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam1(V self, V *args);
V g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam4(V self, V *args);
V g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam3(V self, V *args);
V g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam2(V self, V *args);
Clo g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_entry, 6, 0};

V g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_t_247 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam0, 1, 1, (V[]){heff_dup(v_path_244)}), heff_get(heff_dup(v_root_241), LBL_require)));
  V v_t_2414;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nil: {
    heff_drop(v_root_241);
    v_t_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 2);
    V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam1, 1, 1, (V[]){v_r_248}), heff_get(v_root_241, LBL_replace)));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nil: {
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 2);
      v_t_2414 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_p_2412, LBL_dir)});
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    V v_c_2415 = (g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    return heff_clo(g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam2, 2, 6, (V[]){v_c_2415, v_by_243, v_path_244, v_v_245, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2435 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_st_2436 = heff_get(heff_dup(v_ps_240), LBL_style);
    V v_t_2437 = (g_std_2epath_2eparse(v_st_2436, heff_get(heff_dup(v_ps_240), LBL_root)));
    V v_t_2438 = (g_std_2epath_2eparse(v_st_2436, v_d_2435));
    V v_p_2439 = (g_std_2epath_2ejoin_2eonto_240(v_t_2437, v_t_2438));
    V v_t_2440 = ({ V a_0 = heff_get(heff_dup(v_p_2439), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2439), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2441 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2439), LBL_drive), heff_get(v_p_2439, LBL_absolute), v_t_2440});
    V v_t_2442 = ({ V a_0 = v_st_2436; V a_1 = v_t_2441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2436); r_; });
    return (g_heff_2eload_2ereadPkgAt_24s875_24s1136(v_ps_240, v_t_2442, v_path_244));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam0(V self, V *args) {
  V v_r_246 = args[0];
  V v_path_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_r_246, LBL_path), v_path_244);
}
V g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam1(V self, V *args) {
  V v_p_2410 = args[0];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_p_2410, LBL_name), heff_get(v_r_248, LBL_name));
}
V g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam4(V self, V *args) {
  V v_s_2422 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_v_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_strEq(heff_get(heff_dup(v_s_2422), LBL_path), v_path_244);
  switch (heff_tag_of(v_t_2423)) {
  case TAG_True: {
    return heff_strEq(heff_get(v_s_2422, LBL_version), v_v_245);
  }
  case TAG_False: {
    heff_drop(v_s_2422);
    heff_drop(v_v_245);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2423);
  }
}
V g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_by_243 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_v_245 = heff_env(self)[2];
  V v_k_2417 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2416 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_why_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_ps_240);
    heff_drop(v_hd_2416);
    V v_t_2420 = heff_strAppend(v_by_243, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_str0), heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_str1), heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_str2), v_why_2419))))));
    V f_ = v_k_2417;
    args[0] = heff_tag(TAG_Left, 1, (V[]){v_t_2420});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_h_2421 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    heff_drop(v_by_243);
    V v_t_2424 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam4, 1, 2, (V[]){heff_dup(v_path_244), heff_dup(v_v_245)}), v_sums_242));
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x_2418_24Right, 1);
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_s_2425 = heff_field(v_t_2424, 0);
      heff_take_n(v_t_2424, 1ULL, 2);
      v_t_2427 = heff_tag_at(v_ru_24x_2418_24Right, TAG_Just, 1, (V[]){heff_get(v_s_2425, LBL_hash)});
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nothing: {
      heff_drop(v_h_2421);
      V v_t_2428 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
      V v_t_2429 = (g_heff_2eload_2ereadPkgAt_24s875_24s1136(v_ps_240, v_t_2428, v_path_244));
      return heff_tail(v_t_2429, 2, (V[]){v_hd_2416, v_k_2417});
    }
    case TAG_Just: {
      V v_want_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      V v_t_2431 = heff_strEq(heff_dup(v_h_2421), heff_dup(v_want_2430));
      switch (heff_tag_of(v_t_2431)) {
      case TAG_True: {
        heff_drop(v_h_2421);
        heff_drop(v_want_2430);
        V v_t_2432 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2433 = (g_heff_2eload_2ereadPkgAt_24s875_24s1136(v_ps_240, v_t_2432, v_path_244));
        return heff_tail(v_t_2433, 2, (V[]){v_hd_2416, v_k_2417});
      }
      case TAG_False: {
        heff_drop(v_ps_240);
        heff_drop(v_hd_2416);
        V v_t_2434 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_str3), heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_str4), heff_strAppend(v_h_2421, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_str5), heff_strAppend(v_want_2430, ((V)&g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_str6))))))));
        V f_ = v_k_2417;
        args[0] = heff_tag(TAG_Left, 1, (V[]){v_t_2434});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_t_2431);
      }
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_by_243 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_v_245 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo(g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329_lam3, 1, 7, (V[]){v_by_243, v_path_244, v_v_245, v_k_2417, v_sums_242, v_ps_240, v_hd_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str1 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[51]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str3 = {{0x80000000u, K_STR, 0}, 51, 51, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 114, 101, 97, 100, 58, 32, 103, 101, 116, 32, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str5 = {{0x80000000u, K_STR, 0}, 11, 11, {116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str9 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 46, 115, 117, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str10 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 32, 103, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str11 = {{0x80000000u, K_STR, 0}, 21, 21, {99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32, 104, 101, 102, 102, 46, 115, 117, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str12 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str13 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 32, 103, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str14 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 32, 103, 101, 116, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str15 = {{0x80000000u, K_STR, 0}, 27, 27, {32, 112, 97, 99, 107, 97, 103, 101, 115, 44, 32, 104, 101, 102, 102, 46, 115, 117, 109, 32, 119, 114, 105, 116, 116, 101, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam2(V self, V *args); static Clo g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam2, 1, 0};
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam5(V self, V *args);
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam6(V self, V *args);
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam9(V self, V *args); static Clo g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam9, 2, 0};
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam11(V self, V *args); static Clo g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam11, 1, 0};
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam10(V self, V *args);
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam16(V self, V *args);
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam15(V self, V *args);
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam14(V self, V *args);
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam13(V self, V *args);
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam12(V self, V *args);
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam8(V self, V *args);
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam7(V self, V *args);
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam4(V self, V *args);
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam3(V self, V *args);
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam1(V self, V *args);
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam0(V self, V *args);
Clo g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_entry, 2, 0};

V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ecommands_2ehostNow_24s861_24s1033(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328(a[0], a[1]);
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam2(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam5(V self, V *args) {
  V v_r_2422 = args[0];
  V v_by_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_rec(3, shape_34_239_370, (V[]){v_by_2421, heff_get(heff_dup(v_r_2422), LBL_path), heff_get(v_r_2422, LBL_version)});
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam6(V self, V *args) {
  V v_by_2424 = args[0];
  V v_path_2425 = args[1];
  V v_v_2426 = args[2];
  V v_x_244 = heff_env(self)[0];
  V v_root_2415 = heff_env(self)[1];
  V v_sums_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2efetchedPkg_24s943_24s1076_24s1185_24s1329(v_x_244, v_root_2415, v_sums_2419, v_by_2424, v_path_2425, v_v_2426));
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam9(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam11(V self, V *args) {
  V v_ok_2449 = args[0];
  return v_ok_2449;
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam10(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k2_2448 = args[1];
  V v_str_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str9), v_str_2446, ((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam11_clo)})});
  V v_t_2451 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2447), LBL_malg), 1, (V[]){v_t_2452}));
  V f_ = heff_get(v_hd_2447, LBL_bind);
  args[0] = v_t_2453;
  args[1] = v_k2_2448;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam16(V self, V *args) {
  V v_x_2480 = args[0];
  V v_seen_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2480; V a_1 = v_seen_2478; V r_ = (g_prelude_2efoldl_24s723(a_0, a_1)); heff_drop(v_seen_2478); r_; });
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam15(V self, V *args) {
  V v_x_2469 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2470 = heff_intLt(MK_INT(0LL), v_x_2469);
  switch (heff_tag_of(v_t_2470)) {
  case TAG_True: {
    heff_drop(v_x_2428);
    V v_t_2471 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2472 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2474}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2475, v_k_241});
  }
  case TAG_False: {
    V v_seen_2478;
    switch (heff_tag_of(v_x_2428)) {
    case TAG_MkPair: {
      V v_x_2476 = heff_field(v_x_2428, 0);
      heff_take_n(v_x_2428, 1ULL, 2);
      v_seen_2478 = v_x_2476;
      break;
    }
    default: heff_nomatch(v_x_2428);
    }
    V v_t_2479 = (g_prelude_2efoldl_24s724(NTAG(TAG_Nil), heff_dup(v_seen_2478)));
    V v_xs_2481 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam16, 1, 1, (V[]){v_seen_2478}), v_t_2479));
    V v_t_2482 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2481; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2481); r_; });
    V v_str_2483 = heff_strAppend(((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str14), heff_strAppend(heff_intShow(v_t_2482), ((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str15)));
    V v_t_2484 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2483, ((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str16)), NTAG(TAG_MkUnit)});
    V v_t_2485 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2487}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2488, v_k_241});
  }
  default: return heff_nomatch(v_t_2470);
  }
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam14(V self, V *args) {
  V v_x_2468 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str13), heff_get(v_x_2468, LBL_errors), MK_INT(0LL), heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam15, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2428})));
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam13(V self, V *args) {
  V v_x_2460 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2455 = heff_env(self)[2];
  V v_x_2428 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2461 = heff_intLt(MK_INT(0LL), v_x_2460);
  switch (heff_tag_of(v_t_2461)) {
  case TAG_True: {
    heff_drop(v_x_2455);
    heff_drop(v_x_2428);
    V v_t_2462 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2463 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2465}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2466, v_k_241});
  }
  case TAG_False: {
    V v_t_2467;
    switch (heff_tag_of(v_x_2455)) {
    case TAG_True: {
      v_t_2467 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2467 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_2455);
    }
    switch (heff_tag_of(v_t_2467)) {
    case TAG_True: {
      heff_drop(v_x_2428);
      return (g_heff_2ecommands_2egetFails_24s941_24s1074(((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str11), v_hd_240, v_k_241));
    }
    case TAG_False: {
      return (g_heff_2ecommands_2eload_24s860_24s1032_24s1125(((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str12), heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam14, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2428})));
    }
    default: return heff_nomatch(v_t_2467);
    }
  }
  default: return heff_nomatch(v_t_2461);
  }
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam12(V self, V *args) {
  V v_x_2455 = args[0];
  V v_x_2428 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2458;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkPair: {
    V v_y_2457 = heff_dup(heff_field(v_x_2428, 1));
    v_t_2458 = v_y_2457;
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  V v_c_2459 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintErrs_24s887_clo), 3, (V[]){((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str10), v_t_2458, MK_INT(0LL)}));
  return heff_tail(v_c_2459, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam13, 1, 4, (V[]){v_hd_240, v_k_241, v_x_2455, v_x_2428})});
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam8(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2434 = (g_prelude_2esortBy_24s713(heff_dup(v_x_2433)));
  V v_x2_2435 = (g_prelude_2emap_24s712(v_t_2434));
  V v_t_2438;
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_Nil: {
    v_t_2438 = ((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_xs_2437 = heff_field(v_x2_2435, 1);
    heff_take_n(v_x2_2435, 3ULL, 2);
    v_t_2438 = ({ V a_0 = v_x_2436; V a_1 = v_xs_2437; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2437); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2435);
  }
  V v_t_2439 = heff_strEq(v_t_2438, ((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str7));
  V v_c_2454;
  switch (heff_tag_of(v_t_2439)) {
  case TAG_True: {
    heff_drop(v_x_2433);
    v_c_2454 = ((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam9_clo);
    break;
  }
  case TAG_False: {
    V v_t_2442 = (g_prelude_2esortBy_24s713(v_x_2433));
    V v_x2_2443 = (g_prelude_2emap_24s712(v_t_2442));
    V v_str_2446;
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_Nil: {
      v_str_2446 = ((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2444 = heff_field(v_x2_2443, 0);
      V v_xs_2445 = heff_field(v_x2_2443, 1);
      heff_take_n(v_x2_2443, 3ULL, 2);
      v_str_2446 = ({ V a_0 = v_x_2444; V a_1 = v_xs_2445; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2445); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2443);
    }
    v_c_2454 = heff_clo(g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam10, 2, 1, (V[]){v_str_2446});
    break;
  }
  default: heff_nomatch(v_t_2439);
  }
  return heff_tail(v_c_2454, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam12, 1, 3, (V[]){v_x_2428, v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam7(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_root_2415 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2431;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_dup(heff_field(v_x_2428, 0));
    v_t_2431 = v_x_2429;
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  V v_c_2432 = (g_heff_2ecommands_2esumsOf_24s945_24s1187(v_x_244, v_root_2415, v_t_2431));
  return heff_tail(v_c_2432, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam8, 1, 3, (V[]){v_hd_240, v_x_2428, v_k_241})});
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_root_2415 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_why_2418 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    heff_drop(v_root_2415);
    heff_drop(v_x_244);
    return (g_heff_2ecommands_2egetFails_24s941_24s1074(v_why_2418, v_hd_240, v_k_241));
  }
  case TAG_Right: {
    V v_sums_2419 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    V v_t_2420 = heff_strEq(heff_get(heff_dup(v_root_2415), LBL_module), ((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str4));
    V v_by_2421;
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      v_by_2421 = ((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str5);
      break;
    }
    case TAG_False: {
      v_by_2421 = heff_get(heff_dup(v_root_2415), LBL_module);
      break;
    }
    default: heff_nomatch(v_t_2420);
    }
    V v_t_2423 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam5, 1, 1, (V[]){v_by_2421}), heff_get(heff_dup(v_root_2415), LBL_require)));
    V v_c_2427 = (g_heff_2eload_2eversionsGo_24s877(heff_clo(g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam6, 3, 3, (V[]){heff_dup(v_x_244), heff_dup(v_root_2415), v_sums_2419}), heff_get(heff_dup(v_root_2415), LBL_module), v_t_2423, NTAG(TAG_Nil), NTAG(TAG_Nil)));
    return heff_tail(v_c_2427, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam7, 1, 4, (V[]){v_x_244, v_root_2415, v_hd_240, v_k_241})});
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    v_t_2412 = ((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2413 = (g_heff_2eproject_2ereadPackage(v_t_2412));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Left: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_244);
    return (g_heff_2ecommands_2egetFails_24s941_24s1074(((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str3), v_hd_240, v_k_241));
  }
  case TAG_Right: {
    V v_root_2415 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    V v_c_2416 = (g_heff_2eload_2ereadSumAt_24s873_24s1134(heff_dup(v_x_244)));
    return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam4, 1, 4, (V[]){v_hd_240, v_k_241, v_root_2415, v_x_244})});
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str1), ((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam2_clo)})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam3, 1, 3, (V[]){v_hd_240, v_k_241, v_x_244})});
}
V g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_243 = (g_heff_2eload_2epathsFor_24s867_24s1128(v_x_242, ((V)&g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_str0)));
  return heff_tail(v_c_243, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str0 = {{0x80000000u, K_STR, 0}, 30, 30, {102, 105, 110, 100, 105, 110, 103, 32, 116, 104, 101, 32, 110, 101, 119, 101, 115, 116, 32, 118, 101, 114, 115, 105, 111, 110, 32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {45, 45, 116, 97, 103, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {45, 45, 114, 101, 102, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {108, 115, 45, 114, 101, 109, 111, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str7 = {{0x80000000u, K_STR, 0}, 24, 24, {99, 97, 110, 110, 111, 116, 32, 108, 105, 115, 116, 32, 116, 104, 101, 32, 116, 97, 103, 115, 32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str10 = {{0x80000000u, K_STR, 0}, 11, 11, {114, 101, 102, 115, 47, 116, 97, 103, 115, 47, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str11 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str15 = {{0x80000000u, K_STR, 0}, 9, 9, {116, 104, 97, 116, 32, 111, 102, 32, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str16 = {{0x80000000u, K_STR, 0}, 6, 6, {48, 32, 111, 114, 32, 49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str17 = {{0x80000000u, K_STR, 0}, 6, 6, {48, 32, 111, 114, 32, 49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str18 = {{0x80000000u, K_STR, 0}, 6, 6, {48, 32, 111, 114, 32, 49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str19 = {{0x80000000u, K_STR, 0}, 10, 10, {110, 111, 32, 116, 97, 103, 32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str20 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 105, 115, 32, 97, 32, 118, 101, 114, 115, 105, 111, 110, 32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str21 = {{0x80000000u, K_STR, 0}, 20, 20, {32, 40, 118, 65, 46, 66, 46, 67, 44, 32, 105, 116, 115, 32, 109, 97, 106, 111, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam0(V self, V *args); static Clo g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam0, 1, 0};
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam3(V self, V *args); static Clo g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam3, 1, 0};
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam2(V self, V *args);
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam6(V self, V *args);
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam5(V self, V *args);
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam4(V self, V *args);
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam1(V self, V *args);
Clo g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_entry, 3, 0};

V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331(V v_path_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str0), heff_dup(v_path_240)), MK_INT(0LL), ((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam0_clo)});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam1, 1, 3, (V[]){v_path_240, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam0(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam3(V self, V *args) {
  V v_r_2413 = args[0];
  return v_r_2413;
}
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k2_2412 = args[1];
  V v_as_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str5), v_as_2410, ((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam3_clo)})});
  V v_t_2415 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2416})}));
  V f_ = heff_get(v_hd_2411, LBL_bind);
  args[0] = v_t_2417;
  args[1] = v_k2_2412;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam6(V self, V *args) {
  V v_best_2433 = args[0];
  V v_line_2434 = args[1];
  V v_path_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_it_2435 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str10), v_line_2434, MK_INT(0LL), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_2435)) {
  case TAG_Nil: {
    heff_drop(v_path_240);
    return v_best_2433;
  }
  case TAG_Cons: {
    V v_it2_2437 = heff_field(v_it_2435, 1);
    heff_take_n(v_it_2435, 2ULL, 2);
    switch (heff_tag_of(v_it2_2437)) {
    case TAG_Nil: {
      heff_drop(v_path_240);
      return v_best_2433;
    }
    case TAG_Cons: {
      V v_v_2438 = heff_field(v_it2_2437, 0);
      V v_it22_2439 = heff_field(v_it2_2437, 1);
      heff_take_n(v_it2_2437, 3ULL, 2);
      switch (heff_tag_of(v_it22_2439)) {
      case TAG_Nil: {
        V v_t_2440 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), MK_INT(0LL), MK_INT(1LL)));
        V v_t_2441 = heff_intSub(heff_strLength(heff_dup(v_v_2438)), MK_INT(1LL));
        V v_t_2442 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), v_t_2441, MK_INT(-1LL)));
        V v_t_2443 = heff_strSlice(heff_dup(v_v_2438), v_t_2440, heff_intAdd(v_t_2442, MK_INT(1LL)));
        V v_t_2444 = (g_heff_2eproject_2eversion(v_t_2443));
        switch (heff_tag_of(v_t_2444)) {
        case TAG_Nothing: {
          heff_drop(v_path_240);
          heff_drop(v_v_2438);
          return v_best_2433;
        }
        case TAG_Just: {
          V v_ru_24t_2444_24Just = heff_take_reuse_n(v_t_2444, 0ULL, 1);
          V v_t_2446 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), MK_INT(0LL), MK_INT(1LL)));
          V v_t_2447 = heff_intSub(heff_strLength(heff_dup(v_v_2438)), MK_INT(1LL));
          V v_t_2448 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), v_t_2447, MK_INT(-1LL)));
          V v_t_2449 = heff_strSlice(heff_dup(v_v_2438), v_t_2446, heff_intAdd(v_t_2448, MK_INT(1LL)));
          V v_t_2450 = (g_heff_2eproject_2emajorMismatch(v_path_240, v_t_2449));
          switch (heff_tag_of(v_t_2450)) {
          case TAG_Nothing: {
            switch (heff_tag_of(v_best_2433)) {
            case TAG_Nothing: {
              V v_t_2451 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), MK_INT(0LL), MK_INT(1LL)));
              V v_t_2452 = heff_intSub(heff_strLength(heff_dup(v_v_2438)), MK_INT(1LL));
              V v_t_2453 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), v_t_2452, MK_INT(-1LL)));
              V v_t_2454 = heff_strSlice(v_v_2438, v_t_2451, heff_intAdd(v_t_2453, MK_INT(1LL)));
              return heff_tag_at(v_ru_24t_2444_24Just, TAG_Just, 1, (V[]){v_t_2454});
            }
            case TAG_Just: {
              V v_b_2455 = heff_dup(heff_field(v_best_2433, 0));
              V v_t_2456 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), MK_INT(0LL), MK_INT(1LL)));
              V v_t_2457 = heff_intSub(heff_strLength(heff_dup(v_v_2438)), MK_INT(1LL));
              V v_t_2458 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), v_t_2457, MK_INT(-1LL)));
              V v_a_2459 = heff_strSlice(heff_dup(v_v_2438), v_t_2456, heff_intAdd(v_t_2458, MK_INT(1LL)));
              V v_x2_2460 = (g_heff_2eproject_2eversion(v_a_2459));
              V v_t_2462;
              switch (heff_tag_of(v_x2_2460)) {
              case TAG_Nothing: {
                v_t_2462 = NTAG(TAG_Nil);
                break;
              }
              case TAG_Just: {
                V v_x_2461 = heff_field(v_x2_2460, 0);
                heff_take_n(v_x2_2460, 1ULL, 1);
                v_t_2462 = v_x_2461;
                break;
              }
              default: heff_nomatch(v_x2_2460);
              }
              V v_x2_2463 = (g_heff_2eproject_2eversion(v_b_2455));
              V v_t_2465;
              switch (heff_tag_of(v_x2_2463)) {
              case TAG_Nothing: {
                v_t_2465 = NTAG(TAG_Nil);
                break;
              }
              case TAG_Just: {
                V v_x_2464 = heff_field(v_x2_2463, 0);
                heff_take_n(v_x2_2463, 1ULL, 1);
                v_t_2465 = v_x_2464;
                break;
              }
              default: heff_nomatch(v_x2_2463);
              }
              V v_t_2466 = ({ V a_0 = v_t_2462; V a_1 = v_t_2465; V r_ = (g_heff_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_2462); heff_drop(v_t_2465); r_; });
              switch (heff_tag_of(v_t_2466)) {
              case TAG_True: {
                heff_drop_tag(v_best_2433, 1);
                V v_t_2467 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), MK_INT(0LL), MK_INT(1LL)));
                V v_t_2468 = heff_intSub(heff_strLength(heff_dup(v_v_2438)), MK_INT(1LL));
                V v_t_2469 = (g_prelude_2eskipSpaces(heff_dup(v_v_2438), v_t_2468, MK_INT(-1LL)));
                V v_t_2470 = heff_strSlice(v_v_2438, v_t_2467, heff_intAdd(v_t_2469, MK_INT(1LL)));
                return heff_tag_at(v_ru_24t_2444_24Just, TAG_Just, 1, (V[]){v_t_2470});
              }
              case TAG_False: {
                heff_drop(v_v_2438);
                heff_drop_cell(v_ru_24t_2444_24Just, 1);
                return v_best_2433;
              }
              default: return heff_nomatch(v_t_2466);
              }
            }
            default: return heff_nomatch(v_best_2433);
            }
          }
          case TAG_Just: {
            heff_take_n(v_t_2450, 0ULL, 1);
            heff_drop(v_v_2438);
            heff_drop_cell(v_ru_24t_2444_24Just, 1);
            return v_best_2433;
          }
          default: return heff_nomatch(v_t_2450);
          }
        }
        default: return heff_nomatch(v_t_2444);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it22_2439, 0ULL, 2);
        heff_drop(v_path_240);
        heff_drop(v_v_2438);
        return v_best_2433;
      }
      default: return heff_nomatch(v_it22_2439);
      }
    }
    default: return heff_nomatch(v_it2_2437);
    }
  }
  default: return heff_nomatch(v_it_2435);
  }
}
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_intEq(heff_get(heff_dup(v_x_2419), LBL_status), MK_INT(0LL));
  V v_t_2424;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_True: {
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2424 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_x_2493;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_True: {
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str6), (g_heff_2eproject_2erepoOf(v_path_240)));
    V v_s_2426 = heff_get(v_x_2419, LBL_err);
    V v_t_2427 = (g_prelude_2eskipSpaces(heff_dup(v_s_2426), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2428 = heff_intSub(heff_strLength(heff_dup(v_s_2426)), MK_INT(1LL));
    V v_t_2429 = (g_prelude_2eskipSpaces(heff_dup(v_s_2426), v_t_2428, MK_INT(-1LL)));
    V v_t_2430 = heff_strSlice(v_s_2426, v_t_2427, heff_intAdd(v_t_2429, MK_INT(1LL)));
    V v_t_2431 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str7), heff_strAppend(v_t_2425, heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str8), v_t_2430)));
    v_x_2493 = heff_tag(TAG_Left, 1, (V[]){v_t_2431});
    break;
  }
  case TAG_False: {
    V v_t_2432 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str9), heff_get(v_x_2419, LBL_out), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2474 = ({ V a_0 = heff_clo(g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam6, 2, 1, (V[]){heff_dup(v_path_240)}); V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2432; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2432); r_; });
    switch (heff_tag_of(v_t_2474)) {
    case TAG_Nothing: {
      V v_t_2475 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str11), (g_heff_2eproject_2erepoOf(heff_dup(v_path_240))));
      V v_xs_2476 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str12), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2477 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2476));
      V v_x_2480;
      switch (heff_tag_of(v_t_2477)) {
      case TAG_Nil: {
        v_x_2480 = heff_dup(v_path_240);
        break;
      }
      case TAG_Cons: {
        V v_x_2478 = heff_field(v_t_2477, 0);
        heff_take_n(v_t_2477, 1ULL, 2);
        v_x_2480 = v_x_2478;
        break;
      }
      default: heff_nomatch(v_t_2477);
      }
      V v_t_2481 = heff_intLe(MK_INT(2LL), heff_strLength(heff_dup(v_x_2480)));
      V v_t_2490;
      switch (heff_tag_of(v_t_2481)) {
      case TAG_True: {
        V v_t_2482 = heff_strEq(heff_strSlice(heff_dup(v_x_2480), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str13));
        switch (heff_tag_of(v_t_2482)) {
        case TAG_True: {
          V v_t_2483 = heff_strSlice(heff_dup(v_x_2480), MK_INT(1LL), heff_strLength(v_x_2480));
          V v_t_2484 = (g_heff_2eproject_2eisNumber(v_t_2483));
          switch (heff_tag_of(v_t_2484)) {
          case TAG_True: {
            V v_xs_2485 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str14), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
            V v_t_2486 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2485));
            V v_t_2489;
            switch (heff_tag_of(v_t_2486)) {
            case TAG_Nil: {
              v_t_2489 = heff_dup(v_path_240);
              break;
            }
            case TAG_Cons: {
              V v_x_2487 = heff_field(v_t_2486, 0);
              heff_take_n(v_t_2486, 1ULL, 2);
              v_t_2489 = v_x_2487;
              break;
            }
            default: heff_nomatch(v_t_2486);
            }
            v_t_2490 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str15), v_t_2489);
            break;
          }
          case TAG_False: {
            v_t_2490 = ((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str16);
            break;
          }
          default: heff_nomatch(v_t_2484);
          }
          break;
        }
        case TAG_False: {
          heff_drop(v_x_2480);
          v_t_2490 = ((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str17);
          break;
        }
        default: heff_nomatch(v_t_2482);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_x_2480);
        v_t_2490 = ((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str18);
        break;
      }
      default: heff_nomatch(v_t_2481);
      }
      V v_t_2491 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str19), heff_strAppend(v_t_2475, heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str20), heff_strAppend(v_path_240, heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str21), heff_strAppend(v_t_2490, ((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str22)))))));
      v_x_2493 = heff_tag(TAG_Left, 1, (V[]){v_t_2491});
      break;
    }
    case TAG_Just: {
      V v_v_2492 = heff_field(v_t_2474, 0);
      V v_ru_24t_2474_24Just = heff_take_reuse_n(v_t_2474, 1ULL, 1);
      heff_drop(v_path_240);
      v_x_2493 = heff_tag_at(v_ru_24t_2474_24Just, TAG_Right, 1, (V[]){v_v_2492});
      break;
    }
    default: heff_nomatch(v_t_2474);
    }
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  V f_ = v_k_242;
  args[0] = v_x_2493;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_path_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2420 = heff_tag(TAG_End, 2, (V[]){v_x_246, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2421, heff_clo(g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam5, 1, 3, (V[]){v_x_2419, v_path_240, v_k_242})});
}
V g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str1), (g_heff_2eproject_2erepoOf(heff_dup(v_path_240))));
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str2), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str3), v_t_248})});
  V v_as_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_str4), v_t_249});
  V v_c_2418 = heff_clo(g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam2, 2, 1, (V[]){v_as_2410});
  return heff_tail(v_c_2418, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_lam4, 1, 4, (V[]){v_x_246, v_hd_241, v_path_240, v_k_242})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str2 = {{0x80000000u, K_STR, 0}, 27, 27, {96, 32, 105, 115, 32, 114, 101, 113, 117, 105, 114, 101, 100, 32, 97, 108, 114, 101, 97, 100, 121, 58, 32, 97, 100, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str3 = {{0x80000000u, K_STR, 0}, 30, 30, {32, 116, 111, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 98, 121, 32, 97, 110, 111, 116, 104, 101, 114, 32, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str4 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str6 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str7 = {{0x80000000u, K_STR, 0}, 30, 30, {104, 101, 102, 102, 32, 103, 101, 116, 58, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 114, 101, 113, 117, 105, 114, 101, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str10 = {{0x80000000u, K_STR, 0}, 23, 23, {99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam2(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam4(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam5(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam6(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam7(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam9(V self, V *args); static Clo g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam9, 1, 0};
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam8(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam11(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam12(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam10(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam3(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam1(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam0(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam14(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam13(V self, V *args);
Clo g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_entry, 5, 0};

V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332(V v_ps_240, V v_text_241, V v_pk_242, V v_path_243, V v_v_244) {
top: ;
  V v_t_245 = (g_heff_2eproject_2emajorMismatch(heff_dup(v_path_243), heff_dup(v_v_244)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_c_246 = (g_heff_2ecommands_2efetched_24s944_24s1077_24s1186_24s1330(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
    return heff_clo(g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam0, 2, 6, (V[]){v_c_246, v_ps_240, v_path_243, v_v_244, v_pk_242, v_text_241});
  }
  case TAG_Just: {
    V v_why_2456 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    heff_drop(v_ps_240);
    heff_drop(v_text_241);
    heff_drop(v_pk_242);
    heff_drop(v_v_244);
    return heff_clo(g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam13, 2, 2, (V[]){v_path_243, v_why_2456});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2411);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2424);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam5(V self, V *args) {
  V v_r_2426 = args[0];
  V v_path_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_r_2426, LBL_path), v_path_243);
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam6(V self, V *args) {
  V v_r_2428 = args[0];
  V v_name_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_r_2428, LBL_name), v_name_2425);
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam7(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2431);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam9(V self, V *args) {
  V v_ok_2441 = args[0];
  return v_ok_2441;
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam8(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k2_2440 = args[1];
  V v_str_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){((V)&g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str6), v_str_2438, ((V)&g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam9_clo)})});
  V v_t_2443 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2439), LBL_malg), 1, (V[]){v_t_2444}));
  V f_ = heff_get(v_hd_2439, LBL_bind);
  args[0] = v_t_2445;
  args[1] = v_k2_2440;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam11(V self, V *args) {
  V v_x_2454 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2454);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam12(V self, V *args) {
  V v_x_2455 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2455);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam10(V self, V *args) {
  V v_x_2447 = args[0];
  V v_path_243 = heff_env(self)[0];
  V v_v_244 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2447)) {
  case TAG_True: {
    V v_t_2448 = heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str7), heff_strAppend(v_path_243, heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str8), v_v_244)));
    V v_t_2449 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2448, ((V)&g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str9)), NTAG(TAG_MkUnit)});
    V v_t_2450 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2452}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2453, heff_clo(g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam11, 1, 1, (V[]){v_k_248})});
  }
  case TAG_False: {
    heff_drop(v_path_243);
    heff_drop(v_v_244);
    return (g_heff_2ecommands_2egetFails_24s941_24s1074(((V)&g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str10), v_hd_247, heff_clo(g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam12, 1, 1, (V[]){v_k_248})));
  }
  default: return heff_nomatch(v_x_2447);
  }
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  V v_pk_242 = heff_env(self)[3];
  V v_v_244 = heff_env(self)[4];
  V v_text_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    V v_why_2423 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    heff_drop(v_path_243);
    heff_drop(v_pk_242);
    heff_drop(v_v_244);
    heff_drop(v_text_241);
    return (g_heff_2ecommands_2egetFails_24s941_24s1074(v_why_2423, v_hd_247, heff_clo(g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam4, 1, 1, (V[]){v_k_248})));
  }
  case TAG_Right: {
    V v_name_2425 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    V v_x1_2427 = ({ V a_0 = heff_clo(g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam5, 1, 1, (V[]){heff_dup(v_path_243)}); V b_1 = heff_get(heff_dup(v_pk_242), LBL_require); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2429;
    switch (heff_tag_of(v_x1_2427)) {
    case TAG_True: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2429 = ({ V a_0 = heff_clo(g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam6, 1, 1, (V[]){heff_dup(v_name_2425)}); V b_1 = heff_get(heff_dup(v_pk_242), LBL_require); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2427);
    }
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      heff_drop(v_pk_242);
      heff_drop(v_v_244);
      heff_drop(v_text_241);
      V v_t_2430 = heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str1), heff_strAppend(v_name_2425, heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str2), heff_strAppend(v_path_243, ((V)&g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str3)))));
      return (g_heff_2ecommands_2egetFails_24s941_24s1074(v_t_2430, v_hd_247, heff_clo(g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam7, 1, 1, (V[]){v_k_248})));
    }
    case TAG_False: {
      V v_t_2432 = (g_heff_2ecommands_2erequiring(v_pk_242, v_name_2425, heff_dup(v_path_243), heff_dup(v_v_244)));
      V v_text_2433 = (g_heff_2eproject_2ewithPackage(v_text_241, v_t_2432));
      V v_t_2434 = heff_strEq(heff_strSlice(((V)&g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str4), MK_INT(7LL), MK_INT(10LL)), ((V)&g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str5));
      V v_str_2438;
      switch (heff_tag_of(v_t_2434)) {
      case TAG_True: {
        V v_t_2435 = (g_heff_2eformat_2eformat(heff_dup(v_text_2433)));
        switch (heff_tag_of(v_t_2435)) {
        case TAG_Left: {
          heff_take_n(v_t_2435, 0ULL, 1);
          v_str_2438 = v_text_2433;
          break;
        }
        case TAG_Right: {
          V v_out_2437 = heff_field(v_t_2435, 0);
          heff_take_n(v_t_2435, 1ULL, 1);
          heff_drop(v_text_2433);
          v_str_2438 = v_out_2437;
          break;
        }
        default: heff_nomatch(v_t_2435);
        }
        break;
      }
      case TAG_False: {
        v_str_2438 = v_text_2433;
        break;
      }
      default: heff_nomatch(v_t_2434);
      }
      V v_c_2446 = heff_clo(g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam8, 2, 1, (V[]){v_str_2438});
      return heff_tail(v_c_2446, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam10, 1, 4, (V[]){v_path_243, v_v_244, v_hd_247, v_k_248})});
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_path_243 = heff_env(self)[3];
  V v_v_244 = heff_env(self)[4];
  V v_pk_242 = heff_env(self)[5];
  V v_text_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    V v_why_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_ps_240);
    heff_drop(v_path_243);
    heff_drop(v_v_244);
    heff_drop(v_pk_242);
    heff_drop(v_text_241);
    return (g_heff_2ecommands_2egetFails_24s941_24s1074(v_why_2410, v_hd_247, heff_clo(g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam2, 1, 1, (V[]){v_k_248})));
  }
  case TAG_Right: {
    heff_take_n(v_x_249, 0ULL, 1);
    V v_st_2413 = heff_get(heff_dup(v_ps_240), LBL_style);
    V v_a_2414 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
    V v_t_2415 = (g_std_2epath_2eparse(v_st_2413, v_a_2414));
    V v_t_2416 = (g_std_2epath_2eparse(v_st_2413, ((V)&g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str0)));
    V v_p_2417 = (g_std_2epath_2ejoin_2eonto_240(v_t_2415, v_t_2416));
    V v_t_2418 = ({ V a_0 = heff_get(heff_dup(v_p_2417), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2417), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2419 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2417), LBL_drive), heff_get(v_p_2417, LBL_absolute), v_t_2418});
    V v_t_2420 = ({ V a_0 = v_st_2413; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2413); r_; });
    V v_c_2421 = heff_tr(heff_apply(((V)&g_heff_2eload_2eownDir_24s880_24s1139_clo), 2, (V[]){v_ps_240, v_t_2420}));
    return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam3, 1, 6, (V[]){v_hd_247, v_k_248, v_path_243, v_pk_242, v_v_244, v_text_241})});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  V v_v_244 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  V v_text_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo(g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam1, 1, 7, (V[]){v_hd_247, v_k_248, v_ps_240, v_path_243, v_v_244, v_pk_242, v_text_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam14(V self, V *args) {
  V v_x_2460 = args[0];
  V v_k_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2460);
  V f_ = v_k_2458;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam13(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  V v_path_243 = heff_env(self)[0];
  V v_why_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = heff_strAppend(v_path_243, heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_str11), v_why_2456));
  return (g_heff_2ecommands_2egetFails_24s941_24s1074(v_t_2459, v_hd_2457, heff_clo(g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332_lam14, 1, 1, (V[]){v_k_2458})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str1 = {{0x80000000u, K_STR, 0}, 45, 45, {110, 111, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 104, 101, 114, 101, 58, 32, 103, 101, 116, 32, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str2 = {{0x80000000u, K_STR, 0}, 24, 24, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 114, 101, 97, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str3 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {64}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {64}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str7 = {{0x80000000u, K_STR, 0}, 22, 22, {96, 32, 105, 115, 32, 110, 111, 32, 118, 101, 114, 115, 105, 111, 110, 58, 32, 97, 46, 98, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {64}};
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam0(V self, V *args); static Clo g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam0, 1, 0};
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam4(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam6(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam5(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam3(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam2(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam1(V self, V *args);
Clo g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_entry, 3, 0};

V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327(V v_spec_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str0), ((V)&g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam0_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_spec_240})});
}
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam0(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam4(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_v_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = heff_tag(TAG_Right, 1, (V[]){v_v_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam6(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2461)) {
  case TAG_True: {
    return (g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328(v_hd_241, v_k_242));
  }
  case TAG_False: {
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2461);
  }
}
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam5(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_s_2413 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_t_249 = heff_env(self)[4];
  V v_pk_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2443)) {
  case TAG_Left: {
    V v_why_2444 = heff_field(v_x_2443, 0);
    heff_take_n(v_x_2443, 1ULL, 1);
    heff_drop(v_s_2413);
    heff_drop(v_x_2416);
    heff_drop(v_t_249);
    heff_drop(v_pk_2412);
    return (g_heff_2ecommands_2egetFails_24s941_24s1074(v_why_2444, v_hd_241, v_k_242));
  }
  case TAG_Right: {
    V v_ver_2445 = heff_field(v_x_2443, 0);
    V v_ru_24x_2443_24Right = heff_take_reuse_n(v_x_2443, 1ULL, 1);
    V v_t_2446 = (g_heff_2eproject_2eversion(heff_dup(v_ver_2445)));
    switch (heff_tag_of(v_t_2446)) {
    case TAG_Nothing: {
      heff_drop(v_s_2413);
      heff_drop(v_x_2416);
      heff_drop(v_t_249);
      heff_drop(v_pk_2412);
      heff_drop_cell(v_ru_24x_2443_24Right, 1);
      V v_t_2447 = heff_strAppend(((V)&g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str6), heff_strAppend(v_ver_2445, ((V)&g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str7)));
      return (g_heff_2ecommands_2egetFails_24s941_24s1074(v_t_2447, v_hd_241, v_k_242));
    }
    case TAG_Just: {
      heff_take_n(v_t_2446, 0ULL, 1);
      V v_it_2449 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str8), heff_dup(v_s_2413), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_x1_2456;
      switch (heff_tag_of(v_it_2449)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x_2443_24Right, 1);
        v_x1_2456 = heff_tag(TAG_MkPair, 2, (V[]){v_s_2413, NTAG(TAG_Nothing)});
        break;
      }
      case TAG_Cons: {
        V v_path_2450 = heff_field(v_it_2449, 0);
        V v_it2_2451 = heff_field(v_it_2449, 1);
        V v_ru_24it_2449_24Cons = heff_take_reuse_n(v_it_2449, 3ULL, 2);
        switch (heff_tag_of(v_it2_2451)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x_2443_24Right, 1);
          heff_drop(v_path_2450);
          v_x1_2456 = heff_tag_at(v_ru_24it_2449_24Cons, TAG_MkPair, 2, (V[]){v_s_2413, NTAG(TAG_Nothing)});
          break;
        }
        case TAG_Cons: {
          V v_v_2452 = heff_field(v_it2_2451, 0);
          V v_it22_2453 = heff_field(v_it2_2451, 1);
          heff_take_n(v_it2_2451, 3ULL, 2);
          switch (heff_tag_of(v_it22_2453)) {
          case TAG_Nil: {
            heff_drop(v_s_2413);
            v_x1_2456 = heff_tag_at(v_ru_24it_2449_24Cons, TAG_MkPair, 2, (V[]){v_path_2450, heff_tag_at(v_ru_24x_2443_24Right, TAG_Just, 1, (V[]){v_v_2452})});
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_it22_2453, 0ULL, 2);
            heff_drop_cell(v_ru_24x_2443_24Right, 1);
            heff_drop(v_path_2450);
            heff_drop(v_v_2452);
            v_x1_2456 = heff_tag_at(v_ru_24it_2449_24Cons, TAG_MkPair, 2, (V[]){v_s_2413, NTAG(TAG_Nothing)});
            break;
          }
          default: heff_nomatch(v_it22_2453);
          }
          break;
        }
        default: heff_nomatch(v_it2_2451);
        }
        break;
      }
      default: heff_nomatch(v_it_2449);
      }
      V v_t_2459;
      switch (heff_tag_of(v_x1_2456)) {
      case TAG_MkPair: {
        V v_x_2457 = heff_field(v_x1_2456, 0);
        heff_take_n(v_x1_2456, 1ULL, 2);
        v_t_2459 = v_x_2457;
        break;
      }
      default: heff_nomatch(v_x1_2456);
      }
      V v_c_2460 = (g_heff_2ecommands_2egetRequire_24s947_24s1079_24s1188_24s1332(v_x_2416, v_t_249, v_pk_2412, v_t_2459, v_ver_2445));
      return heff_tail(v_c_2460, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam6, 1, 2, (V[]){v_hd_241, v_k_242})});
    }
    default: return heff_nomatch(v_t_2446);
    }
  }
  default: return heff_nomatch(v_x_2443);
  }
}
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_s_2413 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_249 = heff_env(self)[3];
  V v_pk_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_it_2417 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str4), heff_dup(v_s_2413), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_x1_2424;
  switch (heff_tag_of(v_it_2417)) {
  case TAG_Nil: {
    v_x1_2424 = heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_s_2413), NTAG(TAG_Nothing)});
    break;
  }
  case TAG_Cons: {
    V v_path_2418 = heff_field(v_it_2417, 0);
    V v_it2_2419 = heff_field(v_it_2417, 1);
    V v_ru_24it_2417_24Cons = heff_take_reuse_n(v_it_2417, 3ULL, 2);
    switch (heff_tag_of(v_it2_2419)) {
    case TAG_Nil: {
      heff_drop(v_path_2418);
      v_x1_2424 = heff_tag_at(v_ru_24it_2417_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2413), NTAG(TAG_Nothing)});
      break;
    }
    case TAG_Cons: {
      V v_v_2420 = heff_field(v_it2_2419, 0);
      V v_it22_2421 = heff_field(v_it2_2419, 1);
      heff_take_n(v_it2_2419, 3ULL, 2);
      switch (heff_tag_of(v_it22_2421)) {
      case TAG_Nil: {
        v_x1_2424 = heff_tag_at(v_ru_24it_2417_24Cons, TAG_MkPair, 2, (V[]){v_path_2418, heff_tag(TAG_Just, 1, (V[]){v_v_2420})});
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_it22_2421, 0ULL, 2);
        heff_drop(v_path_2418);
        heff_drop(v_v_2420);
        v_x1_2424 = heff_tag_at(v_ru_24it_2417_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2413), NTAG(TAG_Nothing)});
        break;
      }
      default: heff_nomatch(v_it22_2421);
      }
      break;
    }
    default: heff_nomatch(v_it2_2419);
    }
    break;
  }
  default: heff_nomatch(v_it_2417);
  }
  V v_t_2427;
  switch (heff_tag_of(v_x1_2424)) {
  case TAG_MkPair: {
    V v_y_2426 = heff_field(v_x1_2424, 1);
    heff_take_n(v_x1_2424, 2ULL, 2);
    v_t_2427 = v_y_2426;
    break;
  }
  default: heff_nomatch(v_x1_2424);
  }
  V v_c_2442;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_Nothing: {
    V v_it_2428 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str5), heff_dup(v_s_2413), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x1_2435;
    switch (heff_tag_of(v_it_2428)) {
    case TAG_Nil: {
      v_x1_2435 = heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_s_2413), NTAG(TAG_Nothing)});
      break;
    }
    case TAG_Cons: {
      V v_path_2429 = heff_field(v_it_2428, 0);
      V v_it2_2430 = heff_field(v_it_2428, 1);
      V v_ru_24it_2428_24Cons = heff_take_reuse_n(v_it_2428, 3ULL, 2);
      switch (heff_tag_of(v_it2_2430)) {
      case TAG_Nil: {
        heff_drop(v_path_2429);
        v_x1_2435 = heff_tag_at(v_ru_24it_2428_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2413), NTAG(TAG_Nothing)});
        break;
      }
      case TAG_Cons: {
        V v_v_2431 = heff_field(v_it2_2430, 0);
        V v_it22_2432 = heff_field(v_it2_2430, 1);
        heff_take_n(v_it2_2430, 3ULL, 2);
        switch (heff_tag_of(v_it22_2432)) {
        case TAG_Nil: {
          v_x1_2435 = heff_tag_at(v_ru_24it_2428_24Cons, TAG_MkPair, 2, (V[]){v_path_2429, heff_tag(TAG_Just, 1, (V[]){v_v_2431})});
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2432, 0ULL, 2);
          heff_drop(v_path_2429);
          heff_drop(v_v_2431);
          v_x1_2435 = heff_tag_at(v_ru_24it_2428_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2413), NTAG(TAG_Nothing)});
          break;
        }
        default: heff_nomatch(v_it22_2432);
        }
        break;
      }
      default: heff_nomatch(v_it2_2430);
      }
      break;
    }
    default: heff_nomatch(v_it_2428);
    }
    V v_t_2438;
    switch (heff_tag_of(v_x1_2435)) {
    case TAG_MkPair: {
      V v_x_2436 = heff_field(v_x1_2435, 0);
      heff_take_n(v_x1_2435, 1ULL, 2);
      v_t_2438 = v_x_2436;
      break;
    }
    default: heff_nomatch(v_x1_2435);
    }
    v_c_2442 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2enewestTag_24s946_24s1078_24s1331_clo), 1, (V[]){v_t_2438}));
    break;
  }
  case TAG_Just: {
    V v_v_2439 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_c_2442 = heff_clo(g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam4, 2, 1, (V[]){v_v_2439});
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  return heff_tail(v_c_2442, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam5, 1, 6, (V[]){v_hd_241, v_k_242, v_s_2413, v_x_2416, v_t_249, v_pk_2412})});
}
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_s_2413 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_249 = heff_env(self)[3];
  V v_pk_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2415 = (g_heff_2eload_2epathsFor_24s867_24s1128(v_x_2414, ((V)&g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str3)));
  return heff_tail(v_c_2415, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam3, 1, 5, (V[]){v_s_2413, v_hd_241, v_k_242, v_t_249, v_pk_2412})});
}
V g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_spec_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    heff_drop(v_spec_240);
    return (g_heff_2ecommands_2egetFails_24s941_24s1074(((V)&g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str1), v_hd_241, v_k_242));
  }
  case TAG_Just: {
    V v_t_249 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    V v_t_2410 = (g_heff_2eproject_2ereadPackage(heff_dup(v_t_249)));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Left: {
      heff_take_n(v_t_2410, 0ULL, 1);
      heff_drop(v_spec_240);
      heff_drop(v_t_249);
      return (g_heff_2ecommands_2egetFails_24s941_24s1074(((V)&g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_str2), v_hd_241, v_k_242));
    }
    case TAG_Right: {
      V v_pk_2412 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      switch (heff_tag_of(v_spec_240)) {
      case TAG_Nothing: {
        heff_drop(v_t_249);
        heff_drop(v_pk_2412);
        return (g_heff_2ecommands_2egetAll_24s942_24s1075_24s1184_24s1328(v_hd_241, v_k_242));
      }
      case TAG_Just: {
        V v_s_2413 = heff_field(v_spec_240, 0);
        heff_take_n(v_spec_240, 1ULL, 1);
        return (g_heff_2ecommands_2ehostNow_24s861_24s1033(heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetCmd_24s940_24s1073_24s1183_24s1327_lam2, 1, 5, (V[]){v_hd_241, v_s_2413, v_k_242, v_t_249, v_pk_2412})));
      }
      default: return heff_nomatch(v_spec_240);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x_248);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {98, 117, 105, 108, 100, 46, 104, 102}};
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam0(V self, V *args);
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam2(V self, V *args); static Clo g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam2, 1, 0};
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam1(V self, V *args);
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam6(V self, V *args);
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam5(V self, V *args);
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam4(V self, V *args);
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam3(V self, V *args);
Clo g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_entry, 5, 0};

V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335(V v_st_240, V v_t_241, V v_rd_242, V v_acc_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    heff_drop(v_rd_242);
    V v_t_245 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_243), LBL_apps)));
    V v_x_246 = heff_rec(2, shape_11_19, (V[]){v_t_245, heff_get(v_acc_243, LBL_bad)});
    return heff_clo(g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam0, 2, 1, (V[]){v_x_246});
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x5_244, 0);
    V v_rest_2410 = heff_field(v_x5_244, 1);
    heff_take_n(v_x5_244, 3ULL, 2);
    V v_path_2411 = (g_heff_2ecommands_2eappFile(v_st_240, heff_dup(v_t_241), heff_dup(v_x_249), ((V)&g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_str0)));
    V v_c_2419 = heff_clo(g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam1, 2, 1, (V[]){v_path_2411});
    return heff_clo(g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam3, 2, 7, (V[]){v_c_2419, heff_dup(v_st_240), v_t_241, v_acc_243, v_x_249, v_rd_242, v_rest_2410});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_x_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_path_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam2_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2417}));
  V f_ = heff_get(v_hd_2412, LBL_bind);
  args[0] = v_t_2418;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_rd_242 = heff_env(self)[2];
  V v_x_2424 = heff_env(self)[3];
  V v_rest_2410 = heff_env(self)[4];
  V v_hd_2420 = heff_env(self)[5];
  V v_k_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2427);
  V v_t_2428 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_rd_242; V a_3 = v_x_2424; V a_4 = v_rest_2410; V r_ = (g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_240); r_; });
  return heff_tail(v_t_2428, 2, (V[]){v_hd_2420, v_k_2421});
}
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_rd_242 = heff_env(self)[0];
  V v_hd_2420 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_rest_2410 = heff_env(self)[4];
  V v_k_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2425 = heff_tag(TAG_Complete, 2, (V[]){heff_dup(v_rd_242), NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2420), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})}));
  return heff_tail(heff_get(heff_dup(v_hd_2420), LBL_bind), 2, (V[]){v_t_2426, heff_clo(g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam6, 1, 7, (V[]){v_st_240, v_t_241, v_rd_242, v_x_2424, v_rest_2410, v_hd_2420, v_k_2421})});
}
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_hd_2420 = heff_env(self)[4];
  V v_rd_242 = heff_env(self)[5];
  V v_rest_2410 = heff_env(self)[6];
  V v_k_2421 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2423 = (g_heff_2ecommands_2eappRead_24s955_24s1193(v_st_240, heff_dup(v_t_241), v_acc_243, v_x_249, v_x_2422));
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_hd_2420), heff_clo(g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam5, 1, 6, (V[]){v_rd_242, v_hd_2420, v_st_240, v_t_241, v_rest_2410, v_k_2421})});
}
V g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_x_249 = heff_env(self)[4];
  V v_rd_242 = heff_env(self)[5];
  V v_rest_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo(g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335_lam4, 1, 8, (V[]){v_st_240, v_t_241, v_acc_243, v_x_249, v_hd_2420, v_rd_242, v_rest_2410, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eended_24s963_24s1340_lam0(V self, V *args);
Clo g_heff_2ecommands_2eended_24s963_24s1340_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eended_24s963_24s1340_entry, 4, 0};

V g_heff_2ecommands_2eended_24s963_24s1340(V v_task_240, V v_next_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag(TAG_End, 2, (V[]){v_task_240, NTAG(TAG_MkUnit)});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2ecommands_2eended_24s963_24s1340_lam0, 1, 3, (V[]){v_next_241, v_hd_242, v_k_243})});
}
V g_heff_2ecommands_2eended_24s963_24s1340_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eended_24s963_24s1340(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2eended_24s963_24s1340_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_next_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_246);
  return heff_tail(v_next_241, 2, (V[]){v_hd_242, v_k_243});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 110, 101, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 111, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_str4 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 97, 110, 110, 111, 116, 32, 99, 111, 112, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 116, 111, 32}};
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam0(V self, V *args); static Clo g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam0, 1, 0};
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam2(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam4(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam6(V self, V *args); static Clo g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam6, 1, 0};
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam8(V self, V *args); static Clo g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam8, 1, 0};
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam11(V self, V *args); static Clo g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam11, 1, 0};
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam10(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam14(V self, V *args); static Clo g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam14, 1, 0};
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam13(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam17(V self, V *args); static Clo g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam17, 1, 0};
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam16(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam18(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam15(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam19(V self, V *args); static Clo g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam19, 1, 0};
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam20(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam12(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam9(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam7(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam5(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam3(V self, V *args);
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam1(V self, V *args);
Clo g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_entry, 8, 0};

V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339(V v_st_240, V v_t_241, V v_home_242, V v_sh_243, V v_next_244, V v_n_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){v_sh_243, heff_dup(v_n_245), MK_INT(0LL), ((V)&g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam0_clo)})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_249}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam1, 1, 7, (V[]){heff_dup(v_st_240), v_home_242, v_n_245, v_hd_246, v_t_241, v_next_244, v_k_247})});
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_x_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam4(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_x_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = v_x_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam6(V self, V *args) {
  V v_ok_2434 = args[0];
  return v_ok_2434;
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam8(V self, V *args) {
  V v_ok_2440 = args[0];
  return v_ok_2440;
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam11(V self, V *args) {
  V v_ok_2454 = args[0];
  return v_ok_2454;
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam10(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k2_2453 = args[1];
  V v_path_2451 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2455 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Copy, 3, (V[]){v_path_2451, v_x_2422, ((V)&g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam11_clo)})});
  V v_t_2456 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2452), LBL_malg), 1, (V[]){v_t_2457}));
  V f_ = heff_get(v_hd_2452, LBL_bind);
  args[0] = v_t_2458;
  args[1] = v_k2_2453;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam14(V self, V *args) {
  V v_ok_2469 = args[0];
  return v_ok_2469;
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam13(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k2_2468 = args[1];
  V v_path_2466 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2470 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Move, 3, (V[]){v_path_2466, v_x_2433, ((V)&g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam14_clo)})});
  V v_t_2471 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2467), LBL_malg), 1, (V[]){v_t_2472}));
  V f_ = heff_get(v_hd_2467, LBL_bind);
  args[0] = v_t_2473;
  args[1] = v_k2_2468;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam17(V self, V *args) {
  V v_ok_2484 = args[0];
  return v_ok_2484;
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam16(V self, V *args) {
  V v_hd_2482 = args[0];
  V v_k2_2483 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_to_2481 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2485 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Move, 3, (V[]){v_x_2422, v_to_2481, ((V)&g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam17_clo)})});
  V v_t_2486 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2482), LBL_malg), 1, (V[]){v_t_2487}));
  V f_ = heff_get(v_hd_2482, LBL_bind);
  args[0] = v_t_2488;
  args[1] = v_k2_2483;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam18(V self, V *args) {
  V v_x_2490 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_next_244 = heff_env(self)[4];
  V v_t_241 = heff_env(self)[5];
  V v_x_2422 = heff_env(self)[6];
  V v_x_2433 = heff_env(self)[7];
  V v_hd_246 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2491 = (g_std_2epath_2eparse(v_st_240, v_home_242));
  V v_t_2492 = (g_std_2epath_2eparse(v_st_240, v_n_245));
  V v_p_2493 = (g_std_2epath_2ejoin_2eonto_240(v_t_2491, v_t_2492));
  V v_t_2494 = ({ V a_0 = heff_get(heff_dup(v_p_2493), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2493), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2495 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2493), LBL_drive), heff_get(v_p_2493, LBL_absolute), v_t_2494});
  V v_t_2496 = ({ V a_0 = v_st_240; V a_1 = v_t_2495; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  V v_t_2497 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eended_24s963_24s1340_clo), 2, (V[]){v_x_2411, v_next_244}));
  return ({ V a_0 = v_t_241; V a_1 = v_x_2422; V a_2 = v_x_2433; V a_3 = v_t_2496; V a_4 = v_t_2497; V a_5 = v_x_2490; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2ecommands_2eshipMoved_24s964_24s1090_24s1200(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2490); r_; });
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam15(V self, V *args) {
  V v_x_2475 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  V v_t_241 = heff_env(self)[7];
  V v_x_2433 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2475);
  V v_t_2476 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
  V v_t_2477 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
  V v_p_2478 = (g_std_2epath_2ejoin_2eonto_240(v_t_2476, v_t_2477));
  V v_t_2479 = ({ V a_0 = heff_get(heff_dup(v_p_2478), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2478), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2480 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2478), LBL_drive), heff_get(v_p_2478, LBL_absolute), v_t_2479});
  V v_to_2481 = (g_std_2epath_2erender(v_st_240, v_t_2480));
  V v_c_2489 = heff_clo(g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam16, 2, 2, (V[]){heff_dup(v_x_2422), v_to_2481});
  return heff_tail(v_c_2489, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam18, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_x_2411, v_next_244, v_t_241, v_x_2422, v_x_2433, v_hd_246, v_k_247})});
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam19(V self, V *args) {
  V v_ok_2498 = args[0];
  return v_ok_2498;
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam20(V self, V *args) {
  V v_x_24103 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24103);
  V v_t_24104 = (g_std_2epath_2eparse(v_st_240, heff_get(v_t_241, LBL_root)));
  V v_t_24105 = (g_std_2epath_2eparse(v_st_240, v_n_245));
  V v_p_24106 = (g_std_2epath_2ejoin_2eonto_240(v_t_24104, v_t_24105));
  V v_t_24107 = ({ V a_0 = heff_get(heff_dup(v_p_24106), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_24106), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24108 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_24106), LBL_drive), heff_get(v_p_24106, LBL_absolute), v_t_24107});
  V v_t_24109 = ({ V a_0 = v_st_240; V a_1 = v_t_24108; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  V v_t_24110 = heff_strAppend(((V)&g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_str4), heff_strAppend(v_t_24109, heff_strAppend(((V)&g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_str5), v_x_2422)));
  return (g_heff_2ecommands_2eshipFails_24s965_24s1091(v_t_24110, v_hd_246, v_k_247));
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam12(V self, V *args) {
  V v_x_2460 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2433 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_x_2422 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  V v_next_244 = heff_env(self)[7];
  V v_t_241 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2460)) {
  case TAG_True: {
    V v_t_2461 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
    V v_t_2462 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
    V v_p_2463 = (g_std_2epath_2ejoin_2eonto_240(v_t_2461, v_t_2462));
    V v_t_2464 = ({ V a_0 = heff_get(heff_dup(v_p_2463), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2463), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2465 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2463), LBL_drive), heff_get(v_p_2463, LBL_absolute), v_t_2464});
    V v_path_2466 = (g_std_2epath_2erender(v_st_240, v_t_2465));
    V v_c_2474 = heff_clo(g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam13, 2, 2, (V[]){v_path_2466, heff_dup(v_x_2433)});
    return heff_tail(v_c_2474, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam15, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_x_2422, v_hd_246, v_x_2411, v_next_244, v_t_241, v_x_2433, v_k_247})});
  }
  case TAG_False: {
    heff_drop(v_home_242);
    heff_drop(v_x_2433);
    heff_drop(v_x_2411);
    heff_drop(v_next_244);
    V v_t_2499 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){heff_dup(v_x_2422), ((V)&g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam19_clo)})});
    V v_t_24100 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2499})});
    V v_t_24101 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24100})});
    V v_t_24102 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_24101}));
    return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_24102, heff_clo(g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam20, 1, 6, (V[]){v_st_240, v_t_241, v_n_245, v_x_2422, v_hd_246, v_k_247})});
  }
  default: return heff_nomatch(v_x_2460);
  }
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam9(V self, V *args) {
  V v_x_2445 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_home_242 = heff_env(self)[5];
  V v_x_2433 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2445);
  V v_t_2446 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_root)));
  V v_t_2447 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
  V v_p_2448 = (g_std_2epath_2ejoin_2eonto_240(v_t_2446, v_t_2447));
  V v_t_2449 = ({ V a_0 = heff_get(heff_dup(v_p_2448), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2448), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2450 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2448), LBL_drive), heff_get(v_p_2448, LBL_absolute), v_t_2449});
  V v_path_2451 = (g_std_2epath_2erender(v_st_240, v_t_2450));
  V v_c_2459 = heff_clo(g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam10, 2, 2, (V[]){v_path_2451, heff_dup(v_x_2422)});
  return heff_tail(v_c_2459, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam12, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_x_2433, v_hd_246, v_x_2422, v_x_2411, v_next_244, v_t_241, v_k_247})});
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_x_2422 = heff_env(self)[5];
  V v_home_242 = heff_env(self)[6];
  V v_x_2411 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2439);
  V v_t_2441 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){heff_dup(v_x_2433), ((V)&g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam8_clo)})});
  V v_t_2442 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2443}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2444, heff_clo(g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam9, 1, 10, (V[]){v_st_240, v_t_241, v_n_245, v_x_2422, v_hd_246, v_home_242, v_x_2433, v_x_2411, v_next_244, v_k_247})});
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2422 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_home_242 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  V v_next_244 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){heff_dup(v_x_2422), ((V)&g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam6_clo)})});
  V v_t_2436 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2437}));
  return heff_tail(heff_get(heff_dup(v_hd_246), LBL_bind), 2, (V[]){v_t_2438, heff_clo(g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam7, 1, 10, (V[]){v_x_2433, v_hd_246, v_st_240, v_t_241, v_n_245, v_x_2422, v_home_242, v_x_2411, v_next_244, v_k_247})});
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2423 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
  V v_t_2424 = heff_strAppend(((V)&g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_str2), heff_strAppend(heff_dup(v_n_245), ((V)&g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_str3)));
  V v_t_2425 = (g_std_2epath_2eparse(v_st_240, v_t_2424));
  V v_p_2426 = (g_std_2epath_2ejoin_2eonto_240(v_t_2423, v_t_2425));
  V v_t_2427 = ({ V a_0 = heff_get(heff_dup(v_p_2426), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2426), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2428 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2426), LBL_drive), heff_get(v_p_2426, LBL_absolute), v_t_2427});
  V v_x_2429 = (g_std_2epath_2erender(v_st_240, v_t_2428));
  V v_c_2432 = heff_clo(g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam4, 2, 1, (V[]){v_x_2429});
  return heff_tail(v_c_2432, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam5, 1, 9, (V[]){v_x_2422, v_hd_246, v_st_240, v_t_241, v_n_245, v_home_242, v_x_2411, v_next_244, v_k_247})});
}
V g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_str0), heff_strAppend(heff_dup(v_n_245), ((V)&g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_str1)));
  V v_t_2414 = (g_std_2epath_2eparse(v_st_240, v_t_2413));
  V v_p_2415 = (g_std_2epath_2ejoin_2eonto_240(v_t_2412, v_t_2414));
  V v_t_2416 = ({ V a_0 = heff_get(heff_dup(v_p_2415), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2415), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2417 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2415), LBL_drive), heff_get(v_p_2415, LBL_absolute), v_t_2416});
  V v_x_2418 = (g_std_2epath_2erender(v_st_240, v_t_2417));
  V v_c_2421 = heff_clo(g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam2, 2, 1, (V[]){v_x_2418});
  return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_hd_246), heff_clo(g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_lam3, 1, 8, (V[]){v_st_240, v_home_242, v_n_245, v_hd_246, v_t_241, v_x_2411, v_next_244, v_k_247})});
}
Clo g_heff_2ecommands_2eshipAll_24s961_24s1088_24s1198_24s1338_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipAll_24s961_24s1088_24s1198_24s1338_entry, 6, 0};

V g_heff_2ecommands_2eshipAll_24s961_24s1088_24s1198_24s1338(V v_st_240, V v_t_241, V v_home_242, V v_sh_243, V v_next_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_home_242);
    heff_drop(v_sh_243);
    return v_next_244;
  }
  case TAG_Cons: {
    V v_n_246 = heff_field(v_x6_245, 0);
    V v_rest_247 = heff_field(v_x6_245, 1);
    V v_t_248 = heff_tr(g_heff_2ecommands_2eshipAll_24s961_24s1088_24s1198_24s1338(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_home_242), heff_dup(v_sh_243), v_next_244, v_rest_247));
    return heff_tail(((V)&g_heff_2ecommands_2eshipOne_24s962_24s1089_24s1199_24s1339_clo), 6, (V[]){v_st_240, v_t_241, v_home_242, v_sh_243, v_t_248, heff_dup(v_n_246)});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecommands_2eshipAll_24s961_24s1088_24s1198_24s1338_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eshipAll_24s961_24s1088_24s1198_24s1338(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[5]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_str0 = {{0x80000000u, K_STR, 0}, 14, 14, {105, 110, 115, 116, 97, 108, 108, 105, 110, 103, 32, 105, 110, 32}};
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam0(V self, V *args); static Clo g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam0, 2, 0};
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam2(V self, V *args); static Clo g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam2, 1, 0};
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam1(V self, V *args);
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam6(V self, V *args);
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam5(V self, V *args);
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam4(V self, V *args);
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam3(V self, V *args);
Clo g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_entry, 4, 0};

V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337(V v_st_240, V v_t_241, V v_progs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nothing: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_progs_242);
    return ((V)&g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam0_clo);
  }
  case TAG_Just: {
    V v_home_246 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_247 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_progs_242)));
    V v_xs_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_prelude_2efoldl_24s803(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_xs_249 = (g_heff_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_248));
    V v_total_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_249; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_249); r_; });
    V v_c_2416 = heff_clo(g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam1, 2, 2, (V[]){heff_dup(v_home_246), v_total_2410});
    return heff_clo(g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam3, 2, 5, (V[]){v_c_2416, v_progs_242, v_st_240, v_t_241, v_home_246});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k2_2412 = args[1];
  V v_home_246 = heff_env(self)[0];
  V v_total_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_str0), v_home_246), v_total_2410, ((V)&g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam2_clo)});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})}));
  V f_ = heff_get(v_hd_2411, LBL_bind);
  args[0] = v_t_2415;
  args[1] = v_k2_2412;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2427);
  V f_ = v_k_2424;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam5(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tag(TAG_End, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2423), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})}));
  V f_ = heff_get(v_hd_2423, LBL_bind);
  args[0] = v_t_2426;
  args[1] = heff_clo(g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam6, 1, 1, (V[]){v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_progs_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_home_246 = heff_env(self)[3];
  V v_hd_2417 = heff_env(self)[4];
  V v_k_2418 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_progs_242));
  V v_xs_2421 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2420; V r_ = (g_prelude_2efoldl_24s803(a_0, a_1)); heff_drop(v_t_2420); r_; });
  V v_t_2422 = (g_heff_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2421));
  V v_t_2428 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_home_246; V a_3 = heff_dup(v_x_2419); V a_4 = heff_clo(g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam5, 2, 1, (V[]){v_x_2419}); V a_5 = v_t_2422; V r_ = heff_tr(g_heff_2ecommands_2eshipAll_24s961_24s1088_24s1198_24s1338(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2422); r_; });
  return heff_tail(v_t_2428, 2, (V[]){v_hd_2417, v_k_2418});
}
V g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam3(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_progs_242 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_home_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo(g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337_lam4, 1, 6, (V[]){v_progs_242, v_st_240, v_t_241, v_home_246, v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {122, 105, 103, 32, 99, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {99, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {45, 79, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {45, 108, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {122, 105, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str9 = {{0x80000000u, K_STR, 0}, 37, 37, {104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 58, 32, 96, 122, 105, 103, 32, 99, 99, 96, 32, 99, 111, 117, 108, 100, 32, 110, 111, 116, 32, 98, 117, 105, 108, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam1(V self, V *args); static Clo g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam1, 1, 0};
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam0(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam4(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam5(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam8(V self, V *args); static Clo g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam8, 1, 0};
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam7(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam11(V self, V *args); static Clo g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam11, 1, 0};
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam10(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam14(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam16(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam17(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam15(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam13(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam12(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam9(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam6(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam3(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam2(V self, V *args);
Clo g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_entry, 5, 0};

V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343(V v_st_240, V v_t_241, V v_p_242, V v_x_243, V v_next_244) {
top: ;
  V v_path_245 = (g_heff_2ecommands_2epartsDir(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243)));
  V v_c_2413 = heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam0, 2, 1, (V[]){v_path_245});
  return heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam2, 2, 6, (V[]){v_c_2413, heff_dup(v_st_240), v_t_241, v_x_243, v_p_242, v_next_244});
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam1(V self, V *args) {
  V v_ns_248 = args[0];
  return v_ns_248;
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k2_247 = args[1];
  V v_path_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){v_path_245, ((V)&g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam1_clo)})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2411}));
  V f_ = heff_get(v_hd_246, LBL_bind);
  args[0] = v_t_2412;
  args[1] = v_k2_247;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam4(V self, V *args) {
  V v_n_2420 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2421 = (g_heff_2ecommands_2epartsDir(v_st_240, v_t_241, v_x_243));
  V v_t_2422 = (g_std_2epath_2eparse(v_st_240, v_a_2421));
  V v_t_2423 = (g_std_2epath_2eparse(v_st_240, v_n_2420));
  V v_p_2424 = (g_std_2epath_2ejoin_2eonto_240(v_t_2422, v_t_2423));
  V v_t_2425 = ({ V a_0 = heff_get(heff_dup(v_p_2424), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2424), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2426 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2424), LBL_drive), heff_get(v_p_2424, LBL_absolute), v_t_2425});
  return ({ V a_0 = v_st_240; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam5(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_x_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam8(V self, V *args) {
  V v_t_2436 = args[0];
  return v_t_2436;
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam7(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k2_2435 = args[1];
  V v_p_242 = heff_env(self)[0];
  V v_total_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){v_p_242, ((V)&g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str0), v_total_2433, ((V)&g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam8_clo)})});
  V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2434), LBL_malg), 1, (V[]){v_t_2437}));
  V f_ = heff_get(v_hd_2434, LBL_bind);
  args[0] = v_t_2438;
  args[1] = v_k2_2435;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam11(V self, V *args) {
  V v_r_2455 = args[0];
  return v_r_2455;
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam10(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k2_2454 = args[1];
  V v_x_2440 = heff_env(self)[0];
  V v_as_2452 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2456 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_RunUnder, 4, (V[]){v_x_2440, ((V)&g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str6), v_as_2452, ((V)&g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam11_clo)})});
  V v_t_2457 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2453), LBL_malg), 1, (V[]){v_t_2456}));
  V f_ = heff_get(v_hd_2453, LBL_bind);
  args[0] = v_t_2457;
  args[1] = v_k2_2454;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam14(V self, V *args) {
  V v_x_2476 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2476);
  return heff_tail(v_next_244, 2, (V[]){v_hd_2414, v_k_2415});
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam16(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k2_2490 = args[1];
  V v_str_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2491 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2488, ((V)&g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str10)), NTAG(TAG_MkUnit)});
  V v_t_2492 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2489), LBL_malg), 1, (V[]){v_t_2494}));
  V f_ = heff_get(v_hd_2489, LBL_bind);
  args[0] = v_t_2495;
  args[1] = v_k2_2490;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam17(V self, V *args) {
  V v_x_2497 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2497);
  V v_t_2498 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2499 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_24101}));
  return heff_tail(heff_get(v_hd_2414, LBL_bind), 2, (V[]){v_t_24102, v_k_2415});
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam15(V self, V *args) {
  V v_x_2482 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_hd_2414 = heff_env(self)[3];
  V v_k_2415 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2482);
  V v_t_2483 = (g_std_2epath_2eparse(v_st_240, heff_get(v_t_241, LBL_bin)));
  V v_t_2484 = (g_std_2epath_2eparse(v_st_240, v_x_243));
  V v_p_2485 = (g_std_2epath_2ejoin_2eonto_240(v_t_2483, v_t_2484));
  V v_t_2486 = ({ V a_0 = heff_get(heff_dup(v_p_2485), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2485), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2487 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2485), LBL_drive), heff_get(v_p_2485, LBL_absolute), v_t_2486});
  V v_str_2488 = heff_strAppend(((V)&g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str9), ({ V a_0 = v_st_240; V a_1 = v_t_2487; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; }));
  V v_c_2496 = heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam16, 2, 1, (V[]){v_str_2488});
  return heff_tail(v_c_2496, 2, (V[]){heff_dup(v_hd_2414), heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam17, 1, 2, (V[]){v_hd_2414, v_k_2415})});
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam13(V self, V *args) {
  V v_x_2462 = args[0];
  V v_x_2459 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_hd_2414 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2462);
  V v_t_2463 = heff_intEq(heff_get(heff_dup(v_x_2459), LBL_status), MK_INT(0LL));
  switch (heff_tag_of(v_t_2463)) {
  case TAG_True: {
    heff_drop(v_x_2459);
    V v_t_2464 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_bin)));
    V v_t_2465 = (g_std_2epath_2eparse(v_st_240, v_x_243));
    V v_p_2466 = (g_std_2epath_2ejoin_2eonto_240(v_t_2464, v_t_2465));
    V v_t_2467 = ({ V a_0 = heff_get(heff_dup(v_p_2466), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2466), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2468 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2466), LBL_drive), heff_get(v_p_2466, LBL_absolute), v_t_2467});
    V v_path_2469 = ({ V a_0 = v_st_240; V a_1 = v_t_2468; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
    V v_t_2470 = heff_strAppend(heff_get(v_t_241, LBL_said), heff_strAppend(((V)&g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str7), v_path_2469));
    V v_t_2471 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2470, ((V)&g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str8)), NTAG(TAG_MkUnit)});
    V v_t_2472 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2474}));
    return heff_tail(heff_get(heff_dup(v_hd_2414), LBL_bind), 2, (V[]){v_t_2475, heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam14, 1, 3, (V[]){v_next_244, v_hd_2414, v_k_2415})});
  }
  case TAG_False: {
    heff_drop(v_next_244);
    V v_t_2477 = heff_tag(TAG_WriteErr, 2, (V[]){heff_get(v_x_2459, LBL_err), NTAG(TAG_MkUnit)});
    V v_t_2478 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2480}));
    return heff_tail(heff_get(heff_dup(v_hd_2414), LBL_bind), 2, (V[]){v_t_2481, heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam15, 1, 5, (V[]){v_st_240, v_t_241, v_x_243, v_hd_2414, v_k_2415})});
  }
  default: return heff_nomatch(v_t_2463);
  }
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam12(V self, V *args) {
  V v_x_2459 = args[0];
  V v_x_2440 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2460 = heff_tag(TAG_End, 2, (V[]){v_x_2440, NTAG(TAG_MkUnit)});
  V v_t_2461 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2460})}));
  return heff_tail(heff_get(heff_dup(v_hd_2414), LBL_bind), 2, (V[]){v_t_2461, heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam13, 1, 7, (V[]){v_x_2459, v_st_240, v_t_241, v_x_243, v_hd_2414, v_next_244, v_k_2415})});
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam9(V self, V *args) {
  V v_x_2440 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2431 = heff_env(self)[3];
  V v_hd_2414 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2441 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str1), NTAG(TAG_Nil)});
  V v_t_2442 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str2), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str3), v_t_2441})});
  V v_t_2443 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_bin)));
  V v_t_2444 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_243)));
  V v_p_2445 = (g_std_2epath_2ejoin_2eonto_240(v_t_2443, v_t_2444));
  V v_t_2446 = ({ V a_0 = heff_get(heff_dup(v_p_2445), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2445), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2447 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2445), LBL_drive), heff_get(v_p_2445, LBL_absolute), v_t_2446});
  V v_t_2448 = (g_std_2epath_2erender(v_st_240, v_t_2447));
  V v_t_2449 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str4), NTAG(TAG_Nil)});
  V v_t_2450 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_str5), heff_tag(TAG_Cons, 2, (V[]){v_t_2448, v_t_2449})});
  V v_t_2451 = (g_prelude_2econcatList(v_x_2431, v_t_2450));
  V v_as_2452 = (g_prelude_2econcatList(v_t_2442, v_t_2451));
  V v_c_2458 = heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam10, 2, 2, (V[]){heff_dup(v_x_2440), v_as_2452});
  return heff_tail(v_c_2458, 2, (V[]){heff_dup(v_hd_2414), heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam12, 1, 7, (V[]){v_x_2440, v_hd_2414, v_st_240, v_t_241, v_x_243, v_next_244, v_k_2415})});
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2432 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_x_2431));
  V v_total_2433 = heff_intAdd(v_t_2432, MK_INT(1LL));
  V v_c_2439 = heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam7, 2, 2, (V[]){v_p_242, v_total_2433});
  return heff_tail(v_c_2439, 2, (V[]){heff_dup(v_hd_2414), heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam9, 1, 7, (V[]){v_st_240, v_t_241, v_x_243, v_x_2431, v_hd_2414, v_next_244, v_k_2415})});
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_hd_2414 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2418;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2417 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    v_t_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V v_t_2419 = (g_prelude_2efilter_24s802(v_t_2418));
  V v_x_2427 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam4, 1, 3, (V[]){heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_x_243)}), v_t_2419));
  V v_c_2430 = heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam5, 2, 1, (V[]){v_x_2427});
  return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_hd_2414), heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam6, 1, 7, (V[]){v_p_242, v_hd_2414, v_st_240, v_t_241, v_x_243, v_next_244, v_k_2415})});
}
V g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo(g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343_lam3, 1, 7, (V[]){v_st_240, v_t_241, v_x_243, v_hd_2414, v_p_242, v_next_244, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str1 = {{0x80000000u, K_STR, 0}, 14, 14, {99, 111, 109, 112, 105, 108, 105, 110, 103, 32, 116, 111, 32, 67}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 97, 105, 110, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str5 = {{0x80000000u, K_STR, 0}, 21, 21, {99, 111, 109, 112, 105, 108, 105, 110, 103, 32, 102, 111, 114, 32, 78, 111, 100, 101, 46, 106, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str6 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 97, 105, 110, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str8 = {{0x80000000u, K_STR, 0}, 20, 20, {99, 111, 109, 112, 105, 108, 105, 110, 103, 32, 102, 111, 114, 32, 97, 32, 112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 106, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str10 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 97, 105, 110, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 106, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str14 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str15 = {{0x80000000u, K_STR, 0}, 12, 12, {112, 97, 115, 115, 101, 100, 32, 111, 118, 101, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str16 = {{0x80000000u, K_STR, 0}, 32, 32, {58, 32, 97, 32, 112, 97, 103, 101, 39, 115, 32, 115, 99, 114, 105, 112, 116, 44, 32, 110, 111, 116, 32, 97, 32, 112, 114, 111, 103, 114, 97, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam0(V self, V *args); static Clo g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam0, 1, 0};
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam2(V self, V *args); static Clo g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam2, 1, 0};
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam3(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam1(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam4(V self, V *args); static Clo g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam4, 1, 0};
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam6(V self, V *args); static Clo g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam6, 1, 0};
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam7(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam5(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam8(V self, V *args); static Clo g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam8, 1, 0};
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam10(V self, V *args); static Clo g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam10, 1, 0};
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam13(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam12(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam11(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam9(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam15(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam14(V self, V *args);
Clo g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_entry, 8, 0};

V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342(V v_st_240, V v_t_241, V v_bp_242, V v_x_243, V v_a_244, V v_next_245, V v_p_246, V v_p_247) {
top: ;
  V v_t_248 = heff_strEq(heff_get(heff_dup(v_a_244), LBL_backend), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str0));
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(2LL), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam0_clo)})});
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2410}));
    return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam1, 1, 7, (V[]){v_p_246, v_a_244, heff_dup(v_st_240), v_t_241, v_x_243, v_next_245, v_p_247})});
  }
  case TAG_False: {
    V v_t_2423 = heff_strEq(heff_get(heff_dup(v_a_244), LBL_backend), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str4));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(1LL), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam4_clo)})});
      V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2425}));
      return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2426, heff_clo(g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam5, 1, 7, (V[]){v_p_246, v_a_244, heff_dup(v_st_240), v_t_241, v_x_243, v_next_245, v_p_247})});
    }
    case TAG_False: {
      V v_t_2443 = heff_get(heff_dup(v_t_241), LBL_pages);
      switch (heff_tag_of(v_t_2443)) {
      case TAG_True: {
        V v_t_2445 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(1LL), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam8_clo)})});
        V v_t_2446 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2445}));
        return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2446, heff_clo(g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam9, 1, 7, (V[]){v_p_246, v_a_244, heff_dup(v_st_240), v_t_241, v_x_243, v_next_245, v_p_247})});
      }
      case TAG_False: {
        heff_drop(v_t_241);
        heff_drop(v_a_244);
        V v_t_2476 = heff_strAppend(((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str15), heff_strAppend(v_x_243, ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str16)));
        V v_t_2477 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2476, ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str17)), NTAG(TAG_MkUnit)});
        V v_t_2478 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2477})});
        V v_t_2479 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2478})});
        V v_t_2480 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2479})});
        V v_t_2481 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2480}));
        return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2481, heff_clo(g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam14, 1, 4, (V[]){v_bp_242, v_p_246, v_next_245, v_p_247})});
      }
      default: return heff_nomatch(v_t_2443);
      }
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam0(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_246 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2417 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_a_244, LBL_run)});
  V v_t_2418 = (g_heff_2ecommands_2epartsDir(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243)));
  V v_t_2419 = (g_heff_2ecommands_2eappFile(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str2)));
  V v_t_2420 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eended_24s963_24s1340_clo), 2, (V[]){heff_dup(v_x_2412), v_next_245}));
  V v_t_2421 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_2412; V a_3 = v_x_243; V a_4 = v_t_2420; V r_ = (g_heff_2ecommands_2ezigCc_24s968_24s1094_24s1203_24s1343(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_240); r_; });
  V v_t_2422 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eended_24s963_24s1340_clo), 2, (V[]){v_x_2416, v_t_2421}));
  return (g_heff_2ecommands_2ecThen_24s920_24s1058_24s1204_24s1273(v_t_2417, heff_strAppend(v_t_2418, ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str3)), v_t_2419, v_t_2422, v_p_246, v_p_247));
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(v_x_2412), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str1), MK_INT(0LL), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam2_clo)})});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2415, heff_clo(g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam3, 1, 8, (V[]){v_a_244, v_st_240, v_t_241, v_x_243, v_x_2412, v_next_245, v_p_246, v_p_247})});
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam4(V self, V *args) {
  V v_t_2424 = args[0];
  return v_t_2424;
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam6(V self, V *args) {
  V v_t_2428 = args[0];
  return v_t_2428;
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam7(V self, V *args) {
  V v_x_2431 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2427 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_246 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2432 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_a_244, LBL_run)});
  V v_t_2433 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_bin)));
  V v_t_2434 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_243)));
  V v_p_2435 = (g_std_2epath_2ejoin_2eonto_240(v_t_2433, v_t_2434));
  V v_t_2436 = ({ V a_0 = heff_get(heff_dup(v_p_2435), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2435), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2437 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2435), LBL_drive), heff_get(v_p_2435, LBL_absolute), v_t_2436});
  V v_t_2438 = (g_std_2epath_2erender(v_st_240, v_t_2437));
  V v_t_2439 = (g_heff_2ecommands_2eappFile(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str6)));
  V v_t_2440 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eended_24s963_24s1340_clo), 2, (V[]){v_x_2427, v_next_245}));
  V v_t_2441 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_243; V a_3 = v_t_2440; V r_ = (g_heff_2ecommands_2enodeDone_24s969_24s1095(a_0, a_1, a_2, a_3)); heff_drop(v_st_240); r_; });
  V v_t_2442 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eended_24s963_24s1340_clo), 2, (V[]){v_x_2431, v_t_2441}));
  return (g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274(((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str7), v_t_2432, v_t_2438, v_t_2439, v_t_2442, v_p_246, v_p_247));
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2429 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(v_x_2427), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str5), MK_INT(0LL), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam6_clo)})});
  V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2429}));
  return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2430, heff_clo(g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam7, 1, 8, (V[]){v_a_244, v_st_240, v_t_241, v_x_243, v_x_2427, v_next_245, v_p_246, v_p_247})});
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam8(V self, V *args) {
  V v_t_2444 = args[0];
  return v_t_2444;
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam10(V self, V *args) {
  V v_t_2448 = args[0];
  return v_t_2448;
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam13(V self, V *args) {
  V v_x_2474 = args[0];
  V v_x_2447 = heff_env(self)[0];
  V v_next_245 = heff_env(self)[1];
  V v_hd_2466 = heff_env(self)[2];
  V v_k_2467 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2474);
  return (g_heff_2ecommands_2eended_24s963_24s1340(v_x_2447, v_next_245, v_hd_2466, v_k_2467));
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam12(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_t_241 = heff_env(self)[0];
  V v_path_2465 = heff_env(self)[1];
  V v_x_2447 = heff_env(self)[2];
  V v_next_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2468 = heff_strAppend(heff_get(v_t_241, LBL_said), heff_strAppend(((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str12), v_path_2465));
  V v_t_2469 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2468, ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str13)), NTAG(TAG_MkUnit)});
  V v_t_2470 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2466), LBL_malg), 1, (V[]){v_t_2472}));
  V f_ = heff_get(heff_dup(v_hd_2466), LBL_bind);
  args[0] = v_t_2473;
  args[1] = heff_clo(g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam13, 1, 4, (V[]){v_x_2447, v_next_245, v_hd_2466, v_k_2467});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam11(V self, V *args) {
  V v_x_2451 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2447 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_246 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2452 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_a_244, LBL_run)});
  V v_t_2453 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_bin)));
  V v_t_2454 = (g_std_2epath_2eparse(v_st_240, heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str9))));
  V v_p_2455 = (g_std_2epath_2ejoin_2eonto_240(v_t_2453, v_t_2454));
  V v_t_2456 = ({ V a_0 = heff_get(heff_dup(v_p_2455), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2455), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2457 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2455), LBL_drive), heff_get(v_p_2455, LBL_absolute), v_t_2456});
  V v_t_2458 = (g_std_2epath_2erender(v_st_240, v_t_2457));
  V v_t_2459 = (g_heff_2ecommands_2eappFile(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str10)));
  V v_t_2460 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_bin)));
  V v_t_2461 = (g_std_2epath_2eparse(v_st_240, heff_strAppend(v_x_243, ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str11))));
  V v_p_2462 = (g_std_2epath_2ejoin_2eonto_240(v_t_2460, v_t_2461));
  V v_t_2463 = ({ V a_0 = heff_get(heff_dup(v_p_2462), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2462), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2464 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2462), LBL_drive), heff_get(v_p_2462, LBL_absolute), v_t_2463});
  V v_path_2465 = ({ V a_0 = v_st_240; V a_1 = v_t_2464; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  V v_t_2475 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eended_24s963_24s1340_clo), 2, (V[]){v_x_2451, heff_clo(g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam12, 2, 4, (V[]){v_t_241, v_path_2465, v_x_2447, v_next_245})}));
  return (g_heff_2ecommands_2ecompileThen_24s928_24s1053_24s1205_24s1274(((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str14), v_t_2452, v_t_2458, v_t_2459, v_t_2475, v_p_246, v_p_247));
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam9(V self, V *args) {
  V v_x_2447 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2449 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(v_x_2447), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_str8), MK_INT(0LL), ((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam10_clo)})});
  V v_t_2450 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){v_t_2449}));
  return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2450, heff_clo(g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam11, 1, 8, (V[]){v_a_244, v_st_240, v_t_241, v_x_243, v_x_2447, v_next_245, v_p_246, v_p_247})});
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam15(V self, V *args) {
  V v_x_2485 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2485);
  return heff_tail(v_next_245, 2, (V[]){v_p_246, v_p_247});
}
V g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam14(V self, V *args) {
  V v_x_2482 = args[0];
  V v_bp_242 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2482);
  V v_t_2483 = heff_tag(TAG_Complete, 2, (V[]){v_bp_242, NTAG(TAG_MkUnit)});
  V v_t_2484 = heff_tr(heff_apply(heff_get(heff_dup(v_p_246), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2483})}));
  return heff_tail(heff_get(heff_dup(v_p_246), LBL_bind), 2, (V[]){v_t_2484, heff_clo(g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_lam15, 1, 3, (V[]){v_next_245, v_p_246, v_p_247})});
}
Clo g_heff_2ecommands_2ebuildEach_24s966_24s1092_24s1201_24s1271_24s1341_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildEach_24s966_24s1092_24s1201_24s1271_24s1341_entry, 5, 0};

V g_heff_2ecommands_2ebuildEach_24s966_24s1092_24s1201_24s1271_24s1341(V v_st_240, V v_t_241, V v_bp_242, V v_done_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_bp_242);
    return v_done_243;
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(g_heff_2ecommands_2ebuildEach_24s966_24s1092_24s1201_24s1271_24s1341(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_bp_242), v_done_243, v_rest_246));
    return heff_tail(((V)&g_heff_2ecommands_2ebuildApp_24s967_24s1093_24s1202_24s1272_24s1342_clo), 6, (V[]){v_st_240, v_t_241, v_bp_242, heff_get(heff_dup(v_a_245), LBL_name), heff_get(heff_dup(v_a_245), LBL_build), v_t_247});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecommands_2ebuildEach_24s966_24s1092_24s1201_24s1271_24s1341_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ebuildEach_24s966_24s1092_24s1201_24s1271_24s1341(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[4]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_str2 = {{0x80000000u, K_STR, 0}, 17, 17, {98, 117, 105, 108, 100, 105, 110, 103, 32, 112, 114, 111, 103, 114, 97, 109, 115}};
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam0(V self, V *args); static Clo g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam0, 1, 0};
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam3(V self, V *args); static Clo g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam3, 1, 0};
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam2(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam6(V self, V *args); static Clo g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam6, 1, 0};
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam5(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam7(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam4(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam1(V self, V *args);
Clo g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_entry, 5, 0};

V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336(V v_st_240, V v_t_241, V v_progs_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag(TAG_MkDir, 2, (V[]){heff_get(heff_dup(v_t_241), LBL_bin), ((V)&g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam0_clo)});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_248})}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam1, 1, 5, (V[]){v_st_240, v_t_241, v_hd_243, v_progs_242, v_k_244})});
}
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam0(V self, V *args) {
  V v_ok_245 = args[0];
  return v_ok_245;
}
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam3(V self, V *args) {
  V v_ok_2425 = args[0];
  return v_ok_2425;
}
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam2(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_path_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_2422, ((V)&g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam3_clo)})});
  V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2423), LBL_malg), 1, (V[]){v_t_2428}));
  V f_ = heff_get(v_hd_2423, LBL_bind);
  args[0] = v_t_2429;
  args[1] = v_k2_2424;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam6(V self, V *args) {
  V v_t_2435 = args[0];
  return v_t_2435;
}
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam5(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k2_2434 = args[1];
  V v_total_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_str2), v_total_2432, ((V)&g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam6_clo)})});
  V v_t_2437 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2433), LBL_malg), 1, (V[]){v_t_2436}));
  V f_ = heff_get(v_hd_2433, LBL_bind);
  args[0] = v_t_2437;
  args[1] = v_k2_2434;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_progs_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2440 = (g_heff_2ecommands_2eshipIn_24s809_24s960_24s1087_24s1197_24s1337(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_progs_242), heff_get(heff_dup(v_t_241), LBL_shipTo)));
  V v_t_2441 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eended_24s963_24s1340_clo), 2, (V[]){heff_dup(v_x_2439), v_t_2440}));
  V v_t_2442 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_2439; V a_3 = v_t_2441; V a_4 = v_progs_242; V r_ = heff_tr(g_heff_2ecommands_2ebuildEach_24s966_24s1092_24s1201_24s1271_24s1341(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_progs_242); r_; });
  return heff_tail(v_t_2442, 2, (V[]){v_hd_243, v_k_244});
}
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_progs_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2431);
  V v_total_2432 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_progs_242));
  V v_c_2438 = heff_clo(g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam5, 2, 1, (V[]){v_total_2432});
  return heff_tail(v_c_2438, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam7, 1, 5, (V[]){v_st_240, v_t_241, v_progs_242, v_hd_243, v_k_244})});
}
V g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_progs_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_str0)));
  V v_t_2412 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_str1)));
  V v_p_2413 = (g_std_2epath_2ejoin_2eonto_240(v_t_2411, v_t_2412));
  V v_t_2414 = ({ V a_0 = heff_get(heff_dup(v_p_2413), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2413), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2415 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2413), LBL_drive), heff_get(v_p_2413, LBL_absolute), v_t_2414});
  V v_p_2416 = (g_std_2epath_2erender(v_st_240, v_t_2415));
  V v_t_2417 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_root)));
  V v_t_2418 = (g_std_2epath_2eparse(v_st_240, v_p_2416));
  V v_p_2419 = (g_std_2epath_2ejoin_2eonto_240(v_t_2417, v_t_2418));
  V v_t_2420 = ({ V a_0 = heff_get(heff_dup(v_p_2419), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2419), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2421 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2419), LBL_drive), heff_get(v_p_2419, LBL_absolute), v_t_2420});
  V v_path_2422 = (g_std_2epath_2erender(v_st_240, v_t_2421));
  V v_c_2430 = heff_clo(g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam2, 2, 1, (V[]){v_path_2422});
  return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336_lam4, 1, 5, (V[]){v_progs_242, v_hd_243, v_st_240, v_t_241, v_k_244})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam2(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam4(V self, V *args); static Clo g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam4, 1, 0};
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam3(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam9(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam10(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam13(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam12(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam11(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam8(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam7(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam6(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam5(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam1(V self, V *args);
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam0(V self, V *args);
Clo g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_entry, 5, 0};

V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345(V v_chk_240, V v_acc_241, V v_f_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ecommands_2ehostNow_24s861_24s1033(heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam0, 1, 5, (V[]){v_f_242, v_hd_243, v_acc_241, v_chk_240, v_k_244})));
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2412);
  V f_ = v_k_244;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam4(V self, V *args) {
  V v_t_2416 = args[0];
  return v_t_2416;
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k2_2415 = args[1];
  V v_chk_240 = heff_env(self)[0];
  V v_name_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){v_chk_240, v_name_2413, MK_INT(0LL), ((V)&g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam4_clo)})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2417}));
  V f_ = heff_get(v_hd_2414, LBL_bind);
  args[0] = v_t_2418;
  args[1] = v_k2_2415;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam9(V self, V *args) {
  V v_c_2425 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_d_2426 = heff_get(heff_get(heff_dup(v_x_2421), LBL_paths), LBL_src);
  V v_t_2427 = heff_strEq(heff_dup(v_d_2426), ((V)&g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_str1));
  switch (heff_tag_of(v_t_2427)) {
  case TAG_True: {
    heff_drop(v_x_2421);
    heff_drop(v_x_247);
    heff_drop(v_f_242);
    heff_drop(v_d_2426);
    V v_x1_2428 = ({ V a_0 = heff_get(v_c_2425, LBL_module); V b_1 = heff_get(v_acc_241, LBL_seen); V r_ = (g_heff_2ecommands_2eelemStrM(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2428)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2428);
    }
  }
  case TAG_False: {
    V v_t_2429 = heff_get(heff_get(v_x_2421, LBL_paths), LBL_style);
    V v_t_2430 = ({ V a_0 = v_t_2429; V a_1 = v_d_2426; V a_2 = heff_get(heff_dup(v_c_2425), LBL_path); V r_ = (g_std_2epath_2eisUnder(a_0, a_1, a_2)); heff_drop(v_t_2429); r_; });
    switch (heff_tag_of(v_t_2430)) {
    case TAG_True: {
      heff_drop(v_x_247);
      heff_drop(v_f_242);
      V v_x1_2431 = ({ V a_0 = heff_get(v_c_2425, LBL_module); V b_1 = heff_get(v_acc_241, LBL_seen); V r_ = (g_heff_2ecommands_2eelemStrM(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_x1_2431)) {
      case TAG_True: {
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_2431);
      }
    }
    case TAG_False: {
      V v_t_2432 = (g_heff_2eload_2emoduleOf(v_x_247, v_f_242));
      V v_t_2433 = heff_strEq(heff_get(heff_dup(v_c_2425), LBL_module), v_t_2432);
      switch (heff_tag_of(v_t_2433)) {
      case TAG_True: {
        V v_x1_2434 = ({ V a_0 = heff_get(v_c_2425, LBL_module); V b_1 = heff_get(v_acc_241, LBL_seen); V r_ = (g_heff_2ecommands_2eelemStrM(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_x1_2434)) {
        case TAG_True: {
          return NTAG(TAG_False);
        }
        case TAG_False: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_x1_2434);
        }
      }
      case TAG_False: {
        heff_drop(v_c_2425);
        heff_drop(v_acc_241);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2433);
      }
    }
    default: return heff_nomatch(v_t_2430);
    }
  }
  default: return heff_nomatch(v_t_2427);
  }
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam10(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_x_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = v_x_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam13(V self, V *args) {
  V v_x_2443 = args[0];
  V v_x_2439 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2443);
  V v_t_2444 = (g_prelude_2emap_24s475(heff_dup(v_x_2439)));
  V v_t_2445 = (g_prelude_2econcatList(v_t_2444, heff_get(heff_dup(v_acc_241), LBL_seen)));
  V v_t_2446 = heff_intAdd(heff_get(v_acc_241, LBL_errors), v_x_2422);
  V v_t_2447 = ({ V a_0 = MK_INT(0LL); V a_1 = v_x_2439; V r_ = (g_prelude_2efoldl_24s805(a_0, a_1)); heff_drop(v_x_2439); r_; });
  V v_x_2448 = heff_rec(2, shape_292_89, (V[]){v_t_2445, heff_intAdd(v_t_2446, v_t_2447)});
  V f_ = v_k_244;
  args[0] = v_x_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam12(V self, V *args) {
  V v_x_2440 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_2439 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_x_2422 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2440);
  V v_t_2441 = heff_tag(TAG_End, 2, (V[]){v_x_2420, NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})}));
  return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2442, heff_clo(g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam13, 1, 4, (V[]){v_x_2439, v_acc_241, v_x_2422, v_k_244})});
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam11(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecommands_2eputFileDiags_24s894_24s1249(heff_dup(v_x_2439), heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam12, 1, 6, (V[]){v_x_2420, v_hd_243, v_x_2439, v_acc_241, v_x_2422, v_k_244})));
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam8(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_x_2420 = heff_env(self)[5];
  V v_x_2422 = heff_env(self)[6];
  V v_k_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2435 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam9, 1, 4, (V[]){v_x_2421, heff_dup(v_acc_241), v_x_247, v_f_242}), v_x_2424));
  V v_c_2438 = heff_clo(g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam10, 2, 1, (V[]){v_x_2435});
  return heff_tail(v_c_2438, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam11, 1, 5, (V[]){v_hd_243, v_x_2420, v_acc_241, v_x_2422, v_k_244})});
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam7(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_x_2420 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2423 = (g_heff_2esession_2ecachedProgram_24s888_24s1120(heff_dup(v_x_2421)));
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam8, 1, 8, (V[]){v_x_2421, v_acc_241, v_x_247, v_f_242, v_hd_243, v_x_2420, v_x_2422, v_k_244})});
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_x_2420 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_str0), heff_get(heff_dup(v_x_2421), LBL_errors), MK_INT(0LL), heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam7, 1, 7, (V[]){v_x_2421, v_hd_243, v_acc_241, v_x_247, v_f_242, v_x_2420, v_k_244})));
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ecommands_2eload_24s860_24s1032_24s1125(heff_dup(v_f_242), heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam6, 1, 6, (V[]){v_hd_243, v_acc_241, v_x_247, v_f_242, v_x_2420, v_k_244})));
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_chk_240 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = (g_heff_2eload_2emoduleOf(heff_dup(v_x_247), heff_dup(v_f_242)));
  V v_t_249 = ({ V a_0 = v_t_248; V b_1 = heff_get(heff_dup(v_acc_241), LBL_seen); V r_ = (g_heff_2ecommands_2eelemStrM(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    heff_drop(v_x_247);
    heff_drop(v_f_242);
    V v_t_2410 = heff_tag(TAG_Complete, 2, (V[]){v_chk_240, NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam2, 1, 2, (V[]){v_k_244, v_acc_241})});
  }
  case TAG_False: {
    V v_name_2413 = (g_heff_2eload_2emoduleOf(heff_dup(v_x_247), heff_dup(v_f_242)));
    V v_c_2419 = heff_clo(g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam3, 2, 2, (V[]){v_chk_240, v_name_2413});
    return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam5, 1, 5, (V[]){v_f_242, v_hd_243, v_acc_241, v_x_247, v_k_244})});
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_chk_240 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_246 = (g_heff_2eload_2epathsFor_24s867_24s1128(v_x_245, heff_dup(v_f_242)));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345_lam1, 1, 5, (V[]){v_f_242, v_acc_241, v_chk_240, v_hd_243, v_k_244})});
}
V g_heff_2ecommands_2echeckModules_24s951_24s1083_24s1206_24s1275_24s1344_lam0(V self, V *args);
Clo g_heff_2ecommands_2echeckModules_24s951_24s1083_24s1206_24s1275_24s1344_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2echeckModules_24s951_24s1083_24s1206_24s1275_24s1344_entry, 5, 0};

V g_heff_2ecommands_2echeckModules_24s951_24s1083_24s1206_24s1275_24s1344(V v_chk_240, V v_acc_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_chk_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    HEFF_LAST return g_heff_2ecommands_2echeckModule_24s952_24s1084_24s1207_24s1276_24s1345(heff_dup(v_chk_240), v_acc_241, heff_dup(v_f_245), heff_dup(v_p_243), heff_clo(g_heff_2ecommands_2echeckModules_24s951_24s1083_24s1206_24s1275_24s1344_lam0, 1, 4, (V[]){v_chk_240, heff_dup(v_rest_246), v_p_243, v_p_244}));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2echeckModules_24s951_24s1083_24s1206_24s1275_24s1344_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2echeckModules_24s951_24s1083_24s1206_24s1275_24s1344(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2ecommands_2echeckModules_24s951_24s1083_24s1206_24s1275_24s1344_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_chk_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_chk_240; V a_1 = v_x_247; V a_2 = v_rest_246; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ecommands_2echeckModules_24s951_24s1083_24s1206_24s1275_24s1344(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_246); r_; });
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {99, 104, 101, 99, 107, 105, 110, 103, 32, 109, 111, 100, 117, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {49, 32, 101, 114, 114, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 101, 114, 114, 111, 114, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str4 = {{0x80000000u, K_STR, 0}, 25, 25, {32, 105, 110, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 109, 111, 100, 117, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {49, 32, 109, 111, 100, 117, 108, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 109, 111, 100, 117, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {104, 101, 102, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str9 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 99, 104, 101, 99, 107, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str12 = {{0x80000000u, K_STR, 0}, 30, 30, {114, 101, 97, 100, 105, 110, 103, 32, 116, 104, 101, 32, 112, 114, 111, 103, 114, 97, 109, 115, 39, 32, 98, 117, 105, 108, 100, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str13 = {{0x80000000u, K_STR, 0}, 7, 7, {49, 32, 101, 114, 114, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str14 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 101, 114, 114, 111, 114, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str15 = {{0x80000000u, K_STR, 0}, 26, 26, {32, 105, 110, 32, 116, 104, 101, 32, 112, 114, 111, 103, 114, 97, 109, 115, 39, 32, 98, 117, 105, 108, 100, 46, 104, 102}};
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam3(V self, V *args); static Clo g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam3, 1, 0};
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam2(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam7(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam10(V self, V *args); static Clo g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam10, 1, 0};
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam9(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam13(V self, V *args); static Clo g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam13, 1, 0};
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam12(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam16(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam15(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam14(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam11(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam8(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam6(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam5(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam4(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam1(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam0(V self, V *args);
Clo g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_entry, 3, 0};

V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334(V v_st_240, V v_cmd_241, V v_t_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_242), LBL_root)));
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str0)));
  V v_p_245 = (g_std_2epath_2ejoin_2eonto_240(v_t_243, v_t_244));
  V v_t_246 = ({ V a_0 = heff_get(heff_dup(v_p_245), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_245), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_245), LBL_drive), heff_get(v_p_245, LBL_absolute), v_t_246});
  V v_t_248 = (g_std_2epath_2erender(v_st_240, v_t_247));
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_c_2410 = (g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191(v_t_249, NTAG(TAG_Nil)));
  return heff_clo(g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam0, 2, 4, (V[]){v_c_2410, v_cmd_241, v_st_240, v_t_242});
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam3(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_total_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str1), v_total_2414, ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam3_clo)})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2415), LBL_malg), 1, (V[]){v_t_2418}));
  V f_ = heff_get(v_hd_2415, LBL_bind);
  args[0] = v_t_2419;
  args[1] = v_k2_2416;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam7(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k2_2436 = args[1];
  V v_str_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2437 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2434, ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str10)), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2435), LBL_malg), 1, (V[]){v_t_2440}));
  V f_ = heff_get(v_hd_2435, LBL_bind);
  args[0] = v_t_2441;
  args[1] = v_k2_2436;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam10(V self, V *args) {
  V v_ns_2452 = args[0];
  return v_ns_2452;
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam9(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k2_2451 = args[1];
  V v_path_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2453 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){v_path_2449, ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam10_clo)})});
  V v_t_2454 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2450), LBL_malg), 1, (V[]){v_t_2455}));
  V f_ = heff_get(v_hd_2450, LBL_bind);
  args[0] = v_t_2456;
  args[1] = v_k2_2451;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam13(V self, V *args) {
  V v_t_2464 = args[0];
  return v_t_2464;
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam12(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k2_2463 = args[1];
  V v_total_2461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str12), v_total_2461, ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam13_clo)})});
  V v_t_2466 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2462), LBL_malg), 1, (V[]){v_t_2465}));
  V f_ = heff_get(v_hd_2462, LBL_bind);
  args[0] = v_t_2466;
  args[1] = v_k2_2463;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam16(V self, V *args) {
  V v_x_2476 = args[0];
  V v_x_2473 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2476);
  V v_t_2477 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_x_2473), LBL_bad));
  switch (heff_tag_of(v_t_2477)) {
  case TAG_True: {
    heff_drop(v_st_240);
    heff_drop(v_t_242);
    V v_n_2478 = heff_get(v_x_2473, LBL_bad);
    V v_t_2479 = heff_intEq(heff_dup(v_n_2478), MK_INT(1LL));
    V v_t_2480;
    switch (heff_tag_of(v_t_2479)) {
    case TAG_True: {
      heff_drop(v_n_2478);
      v_t_2480 = ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str13);
      break;
    }
    case TAG_False: {
      v_t_2480 = heff_strAppend(heff_intShow(v_n_2478), ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str14));
      break;
    }
    default: heff_nomatch(v_t_2479);
    }
    return (g_heff_2ecommands_2enothingBuilt_24s953_24s1085(v_cmd_241, heff_strAppend(v_t_2480, ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str15)), v_hd_2411, v_k_2412));
  }
  case TAG_False: {
    heff_drop(v_cmd_241);
    V v_t_2481 = heff_get(heff_dup(v_x_2473), LBL_apps);
    switch (heff_tag_of(v_t_2481)) {
    case TAG_Nil: {
      heff_drop(v_x_2473);
      heff_drop(v_hd_2411);
      heff_drop(v_st_240);
      heff_drop(v_t_242);
      V f_ = v_k_2412;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      heff_take_n(v_t_2481, 0ULL, 2);
      return (g_heff_2ecommands_2ebuildPrograms_24s808_24s959_24s1086_24s1196_24s1270_24s1336(v_st_240, v_t_242, heff_get(v_x_2473, LBL_apps), v_hd_2411, v_k_2412));
    }
    default: return heff_nomatch(v_t_2481);
    }
  }
  default: return heff_nomatch(v_t_2477);
  }
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam15(V self, V *args) {
  V v_x_2473 = args[0];
  V v_x_2468 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2474 = heff_tag(TAG_End, 2, (V[]){v_x_2468, NTAG(TAG_MkUnit)});
  V v_t_2475 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2474})}));
  return heff_tail(heff_get(heff_dup(v_hd_2411), LBL_bind), 2, (V[]){v_t_2475, heff_clo(g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam16, 1, 6, (V[]){v_x_2473, v_cmd_241, v_hd_2411, v_k_2412, v_st_240, v_t_242})});
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam14(V self, V *args) {
  V v_x_2468 = args[0];
  V v_x_2458 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_cmd_241 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2469 = heff_rec(2, shape_11_19, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2471;
  switch (heff_tag_of(v_x_2458)) {
  case TAG_Nothing: {
    v_t_2471 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2470 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    v_t_2471 = v_x_2470;
    break;
  }
  default: heff_nomatch(v_x_2458);
  }
  V v_c_2472 = (g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335(v_st_240, heff_dup(v_t_242), heff_dup(v_x_2468), v_t_2469, v_t_2471));
  return heff_tail(v_c_2472, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam15, 1, 6, (V[]){v_x_2468, v_hd_2411, v_cmd_241, v_k_2412, v_st_240, v_t_242})});
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam11(V self, V *args) {
  V v_x_2458 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_xs_2460;
  switch (heff_tag_of(v_x_2458)) {
  case TAG_Nothing: {
    v_xs_2460 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2459 = heff_dup(heff_field(v_x_2458, 0));
    v_xs_2460 = v_x_2459;
    break;
  }
  default: heff_nomatch(v_x_2458);
  }
  V v_total_2461 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2460; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2460); r_; });
  V v_c_2467 = heff_clo(g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam12, 2, 1, (V[]){v_total_2461});
  return heff_tail(v_c_2467, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam14, 1, 6, (V[]){v_x_2458, v_st_240, v_t_242, v_hd_2411, v_cmd_241, v_k_2412})});
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam8(V self, V *args) {
  V v_x_2443 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2443);
  V v_t_2444 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_242), LBL_root)));
  V v_t_2445 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str11)));
  V v_p_2446 = (g_std_2epath_2ejoin_2eonto_240(v_t_2444, v_t_2445));
  V v_t_2447 = ({ V a_0 = heff_get(heff_dup(v_p_2446), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2446), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2448 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2446), LBL_drive), heff_get(v_p_2446, LBL_absolute), v_t_2447});
  V v_path_2449 = (g_std_2epath_2erender(v_st_240, v_t_2448));
  V v_c_2457 = heff_clo(g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam9, 2, 1, (V[]){v_path_2449});
  return heff_tail(v_c_2457, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam11, 1, 5, (V[]){v_hd_2411, v_st_240, v_t_242, v_cmd_241, v_k_2412})});
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_x_2423), LBL_errors));
  switch (heff_tag_of(v_t_2427)) {
  case TAG_True: {
    heff_drop(v_st_240);
    heff_drop(v_t_242);
    V v_n_2428 = heff_get(v_x_2423, LBL_errors);
    V v_t_2429 = heff_intEq(heff_dup(v_n_2428), MK_INT(1LL));
    V v_t_2430;
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      heff_drop(v_n_2428);
      v_t_2430 = ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str2);
      break;
    }
    case TAG_False: {
      v_t_2430 = heff_strAppend(heff_intShow(v_n_2428), ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str3));
      break;
    }
    default: heff_nomatch(v_t_2429);
    }
    return (g_heff_2ecommands_2enothingBuilt_24s953_24s1085(v_cmd_241, heff_strAppend(v_t_2430, ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str4)), v_hd_2411, v_k_2412));
  }
  case TAG_False: {
    V v_n_2431 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_get(v_x_2423, LBL_seen); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2432 = heff_intEq(heff_dup(v_n_2431), MK_INT(1LL));
    V v_t_2433;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_True: {
      heff_drop(v_n_2431);
      v_t_2433 = ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str5);
      break;
    }
    case TAG_False: {
      v_t_2433 = heff_strAppend(heff_intShow(v_n_2431), ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str6));
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    V v_str_2434 = heff_strAppend(((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str7), heff_strAppend(heff_dup(v_cmd_241), heff_strAppend(((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str8), heff_strAppend(v_t_2433, ((V)&g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_str9)))));
    V v_c_2442 = heff_clo(g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam7, 2, 1, (V[]){v_str_2434});
    return heff_tail(v_c_2442, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam8, 1, 5, (V[]){v_st_240, v_t_242, v_hd_2411, v_cmd_241, v_k_2412})});
  }
  default: return heff_nomatch(v_t_2427);
  }
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2424 = heff_tag(TAG_End, 2, (V[]){v_x_2421, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})}));
  return heff_tail(heff_get(heff_dup(v_hd_2411), LBL_bind), 2, (V[]){v_t_2425, heff_clo(g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam6, 1, 6, (V[]){v_x_2423, v_cmd_241, v_hd_2411, v_k_2412, v_st_240, v_t_242})});
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = heff_rec(2, shape_292_89, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  return ({ V a_0 = heff_dup(v_x_2421); V a_1 = v_t_2422; V a_2 = v_x_2413; V a_3 = heff_dup(v_hd_2411); V a_4 = heff_clo(g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam5, 1, 6, (V[]){v_x_2421, v_hd_2411, v_cmd_241, v_k_2412, v_st_240, v_t_242}); V r_ = (g_heff_2ecommands_2echeckModules_24s951_24s1083_24s1206_24s1275_24s1344(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2413); r_; });
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_total_2414 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_x_2413));
  V v_c_2420 = heff_clo(g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam2, 2, 1, (V[]){v_total_2414});
  return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_hd_2411), heff_clo(g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam4, 1, 6, (V[]){v_x_2413, v_hd_2411, v_cmd_241, v_k_2412, v_st_240, v_t_242})});
}
V g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo(g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334_lam1, 1, 5, (V[]){v_hd_2411, v_cmd_241, v_k_2412, v_st_240, v_t_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[60]; } g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_str1 = {{0x80000000u, K_STR, 0}, 60, 60, {104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 58, 32, 110, 111, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 104, 101, 114, 101, 58, 32, 98, 117, 105, 108, 100, 32, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
V g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_lam0(V self, V *args); static Clo g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_lam0, 1, 0};
V g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_lam3(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_lam2(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_lam1(V self, V *args);
Clo g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_entry, 2, 0};

V g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_str0), ((V)&g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333(a[0], a[1]);
}
V g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_lam0(V self, V *args) {
  V v_t_242 = args[0];
  return v_t_242;
}
V g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2419, v_k_241});
}
V g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    heff_drop(v_x_248);
    V v_t_249 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_str1), NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2412}));
    return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_lam3, 1, 2, (V[]){v_hd_240, v_k_241})});
  }
  case TAG_Just: {
    heff_take_n(v_x_247, 0ULL, 1);
    V v_t_2421 = (g_heff_2ecommands_2ebuildTarget(v_x_248, ((V)&g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_str2)));
    V v_t_2422 = (g_heff_2ecommands_2ebuildProject_24s806_24s807_24s949_24s1081_24s1190_24s1269_24s1334(v_x_248, ((V)&g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_str3), v_t_2421));
    return heff_tail(v_t_2422, 2, (V[]){v_hd_240, v_k_241});
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecommands_2estyleNow_24s863_24s1035(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ebuildCmd_24s948_24s1080_24s1189_24s1268_24s1333_lam2, 1, 3, (V[]){v_x_247, v_hd_240, v_k_241})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_str0 = {{0x80000000u, K_STR, 0}, 14, 14, {105, 110, 115, 116, 97, 108, 108, 105, 110, 103, 32, 105, 110, 32}};
V g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_lam1(V self, V *args); static Clo g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_lam1, 1, 0};
V g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_lam0(V self, V *args);
V g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_lam3(V self, V *args);
V g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_lam2(V self, V *args);
Clo g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_entry, 5, 0};

V g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349(V v_st_240, V v_t_241, V v_done_242, V v_progs_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_progs_243);
    return v_done_242;
  }
  case TAG_Just: {
    V v_home_245 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V v_t_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_progs_243)));
    V v_xs_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_prelude_2efoldl_24s803(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_xs_248 = (g_heff_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_247));
    V v_total_249 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_248); r_; });
    V v_c_2415 = heff_clo(g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_lam0, 2, 2, (V[]){heff_dup(v_home_245), v_total_249});
    return heff_clo(g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_lam2, 2, 6, (V[]){v_c_2415, v_done_242, v_progs_243, v_st_240, v_t_241, v_home_245});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_lam1(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k2_2411 = args[1];
  V v_home_245 = heff_env(self)[0];
  V v_total_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_str0), v_home_245), v_total_249, ((V)&g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_lam1_clo)});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2410), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})}));
  V f_ = heff_get(v_hd_2410, LBL_bind);
  args[0] = v_t_2414;
  args[1] = v_k2_2411;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_done_242 = heff_env(self)[0];
  V v_progs_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_home_245 = heff_env(self)[4];
  V v_hd_2416 = heff_env(self)[5];
  V v_k_2417 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2419 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eended_24s963_24s1340_clo), 2, (V[]){heff_dup(v_x_2418), v_done_242}));
  V v_t_2420 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_progs_243));
  V v_xs_2421 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2420; V r_ = (g_prelude_2efoldl_24s803(a_0, a_1)); heff_drop(v_t_2420); r_; });
  V v_t_2422 = (g_heff_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2421));
  V v_t_2423 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_home_245; V a_3 = v_x_2418; V a_4 = v_t_2419; V a_5 = v_t_2422; V r_ = heff_tr(g_heff_2ecommands_2eshipAll_24s961_24s1088_24s1198_24s1338(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2422); r_; });
  return heff_tail(v_t_2423, 2, (V[]){v_hd_2416, v_k_2417});
}
V g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_done_242 = heff_env(self)[1];
  V v_progs_243 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_home_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo(g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349_lam3, 1, 7, (V[]){v_done_242, v_progs_243, v_st_240, v_t_241, v_home_245, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_str2 = {{0x80000000u, K_STR, 0}, 17, 17, {98, 117, 105, 108, 100, 105, 110, 103, 32, 112, 114, 111, 103, 114, 97, 109, 115}};
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam0(V self, V *args); static Clo g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam0, 1, 0};
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam3(V self, V *args); static Clo g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam3, 1, 0};
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam2(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam6(V self, V *args); static Clo g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam6, 1, 0};
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam5(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam7(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam4(V self, V *args);
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam1(V self, V *args);
Clo g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_entry, 6, 0};

V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348(V v_st_240, V v_t_241, V v_done_242, V v_progs_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_MkDir, 2, (V[]){heff_get(heff_dup(v_t_241), LBL_bin), ((V)&g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam0_clo)});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_249})}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam1, 1, 6, (V[]){v_st_240, v_t_241, v_hd_244, v_progs_243, v_done_242, v_k_245})});
}
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam0(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam3(V self, V *args) {
  V v_ok_2426 = args[0];
  return v_ok_2426;
}
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_path_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_2423, ((V)&g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam3_clo)})});
  V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2424), LBL_malg), 1, (V[]){v_t_2429}));
  V f_ = heff_get(v_hd_2424, LBL_bind);
  args[0] = v_t_2430;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam6(V self, V *args) {
  V v_t_2436 = args[0];
  return v_t_2436;
}
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam5(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k2_2435 = args[1];
  V v_total_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2437 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_str2), v_total_2433, ((V)&g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam6_clo)})});
  V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2434), LBL_malg), 1, (V[]){v_t_2437}));
  V f_ = heff_get(v_hd_2434, LBL_bind);
  args[0] = v_t_2438;
  args[1] = v_k2_2435;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2441 = (g_heff_2ecommands_2eshipIn_24s975_24s1101_24s1211_24s1349(heff_dup(v_st_240), heff_dup(v_t_241), v_done_242, heff_dup(v_progs_243), heff_get(heff_dup(v_t_241), LBL_shipTo)));
  V v_t_2442 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eended_24s963_24s1340_clo), 2, (V[]){heff_dup(v_x_2440), v_t_2441}));
  V v_t_2443 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_2440; V a_3 = v_t_2442; V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ecommands_2ebuildEach_24s966_24s1092_24s1201_24s1271_24s1341(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_progs_243); r_; });
  return heff_tail(v_t_2443, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2432);
  V v_total_2433 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_progs_243));
  V v_c_2439 = heff_clo(g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam5, 2, 1, (V[]){v_total_2433});
  return heff_tail(v_c_2439, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam7, 1, 6, (V[]){v_st_240, v_t_241, v_done_242, v_progs_243, v_hd_244, v_k_245})});
}
V g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2411);
  V v_t_2412 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_str0)));
  V v_t_2413 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_str1)));
  V v_p_2414 = (g_std_2epath_2ejoin_2eonto_240(v_t_2412, v_t_2413));
  V v_t_2415 = ({ V a_0 = heff_get(heff_dup(v_p_2414), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2414), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2416 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2414), LBL_drive), heff_get(v_p_2414, LBL_absolute), v_t_2415});
  V v_p_2417 = (g_std_2epath_2erender(v_st_240, v_t_2416));
  V v_t_2418 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_241), LBL_root)));
  V v_t_2419 = (g_std_2epath_2eparse(v_st_240, v_p_2417));
  V v_p_2420 = (g_std_2epath_2ejoin_2eonto_240(v_t_2418, v_t_2419));
  V v_t_2421 = ({ V a_0 = heff_get(heff_dup(v_p_2420), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2420), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2422 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2420), LBL_drive), heff_get(v_p_2420, LBL_absolute), v_t_2421});
  V v_path_2423 = (g_std_2epath_2erender(v_st_240, v_t_2422));
  V v_c_2431 = heff_clo(g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam2, 2, 1, (V[]){v_path_2423});
  return heff_tail(v_c_2431, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348_lam4, 1, 6, (V[]){v_progs_243, v_hd_244, v_st_240, v_t_241, v_done_242, v_k_245})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {99, 104, 101, 99, 107, 105, 110, 103, 32, 109, 111, 100, 117, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {49, 32, 101, 114, 114, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 101, 114, 114, 111, 114, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str4 = {{0x80000000u, K_STR, 0}, 25, 25, {32, 105, 110, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 109, 111, 100, 117, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {49, 32, 109, 111, 100, 117, 108, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 109, 111, 100, 117, 108, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {104, 101, 102, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str9 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 99, 104, 101, 99, 107, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str12 = {{0x80000000u, K_STR, 0}, 30, 30, {114, 101, 97, 100, 105, 110, 103, 32, 116, 104, 101, 32, 112, 114, 111, 103, 114, 97, 109, 115, 39, 32, 98, 117, 105, 108, 100, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str13 = {{0x80000000u, K_STR, 0}, 7, 7, {49, 32, 101, 114, 114, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str14 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 101, 114, 114, 111, 114, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str15 = {{0x80000000u, K_STR, 0}, 26, 26, {32, 105, 110, 32, 116, 104, 101, 32, 112, 114, 111, 103, 114, 97, 109, 115, 39, 32, 98, 117, 105, 108, 100, 46, 104, 102}};
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam3(V self, V *args); static Clo g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam3, 1, 0};
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam2(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam7(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam10(V self, V *args); static Clo g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam10, 1, 0};
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam9(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam13(V self, V *args); static Clo g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam13, 1, 0};
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam12(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam16(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam15(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam14(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam11(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam8(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam6(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam5(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam4(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam1(V self, V *args);
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam0(V self, V *args);
Clo g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_entry, 5, 0};

V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347(V v_st_240, V v_cmd_241, V v_t_242, V v_none_243, V v_done_244) {
top: ;
  V v_t_245 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_242), LBL_root)));
  V v_t_246 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str0)));
  V v_p_247 = (g_std_2epath_2ejoin_2eonto_240(v_t_245, v_t_246));
  V v_t_248 = ({ V a_0 = heff_get(heff_dup(v_p_247), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_247), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_249 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_247), LBL_drive), heff_get(v_p_247, LBL_absolute), v_t_248});
  V v_t_2410 = (g_std_2epath_2erender(v_st_240, v_t_249));
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_c_2412 = (g_heff_2ecommands_2ehfFilesGo_24s950_24s1082_24s1191(v_t_2411, NTAG(TAG_Nil)));
  return heff_clo(g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam0, 2, 6, (V[]){v_c_2412, v_cmd_241, v_st_240, v_t_242, v_none_243, v_done_244});
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam3(V self, V *args) {
  V v_t_2419 = args[0];
  return v_t_2419;
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_total_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str1), v_total_2416, ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam3_clo)})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_2420}));
  V f_ = heff_get(v_hd_2417, LBL_bind);
  args[0] = v_t_2421;
  args[1] = v_k2_2418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam7(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k2_2438 = args[1];
  V v_str_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2439 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2436, ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str10)), NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2437), LBL_malg), 1, (V[]){v_t_2442}));
  V f_ = heff_get(v_hd_2437, LBL_bind);
  args[0] = v_t_2443;
  args[1] = v_k2_2438;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam10(V self, V *args) {
  V v_ns_2454 = args[0];
  return v_ns_2454;
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam9(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k2_2453 = args[1];
  V v_path_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2455 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){v_path_2451, ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam10_clo)})});
  V v_t_2456 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2452), LBL_malg), 1, (V[]){v_t_2457}));
  V f_ = heff_get(v_hd_2452, LBL_bind);
  args[0] = v_t_2458;
  args[1] = v_k2_2453;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam13(V self, V *args) {
  V v_t_2466 = args[0];
  return v_t_2466;
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam12(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k2_2465 = args[1];
  V v_total_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2467 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str12), v_total_2463, ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam13_clo)})});
  V v_t_2468 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2464), LBL_malg), 1, (V[]){v_t_2467}));
  V f_ = heff_get(v_hd_2464, LBL_bind);
  args[0] = v_t_2468;
  args[1] = v_k2_2465;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam16(V self, V *args) {
  V v_x_2478 = args[0];
  V v_x_2475 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  V v_none_243 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2478);
  V v_t_2479 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_x_2475), LBL_bad));
  switch (heff_tag_of(v_t_2479)) {
  case TAG_True: {
    heff_drop(v_none_243);
    heff_drop(v_st_240);
    heff_drop(v_t_242);
    heff_drop(v_done_244);
    V v_n_2480 = heff_get(v_x_2475, LBL_bad);
    V v_t_2481 = heff_intEq(heff_dup(v_n_2480), MK_INT(1LL));
    V v_t_2482;
    switch (heff_tag_of(v_t_2481)) {
    case TAG_True: {
      heff_drop(v_n_2480);
      v_t_2482 = ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str13);
      break;
    }
    case TAG_False: {
      v_t_2482 = heff_strAppend(heff_intShow(v_n_2480), ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str14));
      break;
    }
    default: heff_nomatch(v_t_2481);
    }
    return (g_heff_2ecommands_2enothingBuilt_24s953_24s1085(v_cmd_241, heff_strAppend(v_t_2482, ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str15)), v_hd_2413, v_k_2414));
  }
  case TAG_False: {
    heff_drop(v_cmd_241);
    V v_t_2483 = heff_get(heff_dup(v_x_2475), LBL_apps);
    switch (heff_tag_of(v_t_2483)) {
    case TAG_Nil: {
      heff_drop(v_x_2475);
      heff_drop(v_st_240);
      heff_drop(v_t_242);
      heff_drop(v_done_244);
      return heff_tail(v_none_243, 2, (V[]){v_hd_2413, v_k_2414});
    }
    case TAG_Cons: {
      heff_take_n(v_t_2483, 0ULL, 2);
      heff_drop(v_none_243);
      return (g_heff_2ecommands_2ebuildPrograms_24s974_24s1100_24s1210_24s1279_24s1348(v_st_240, v_t_242, v_done_244, heff_get(v_x_2475, LBL_apps), v_hd_2413, v_k_2414));
    }
    default: return heff_nomatch(v_t_2483);
    }
  }
  default: return heff_nomatch(v_t_2479);
  }
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam15(V self, V *args) {
  V v_x_2475 = args[0];
  V v_x_2470 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  V v_none_243 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2476 = heff_tag(TAG_End, 2, (V[]){v_x_2470, NTAG(TAG_MkUnit)});
  V v_t_2477 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2476})}));
  return heff_tail(heff_get(heff_dup(v_hd_2413), LBL_bind), 2, (V[]){v_t_2477, heff_clo(g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam16, 1, 8, (V[]){v_x_2475, v_cmd_241, v_hd_2413, v_k_2414, v_none_243, v_st_240, v_t_242, v_done_244})});
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam14(V self, V *args) {
  V v_x_2470 = args[0];
  V v_x_2460 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_cmd_241 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2471 = heff_rec(2, shape_11_19, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2473;
  switch (heff_tag_of(v_x_2460)) {
  case TAG_Nothing: {
    v_t_2473 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2472 = heff_field(v_x_2460, 0);
    heff_take_n(v_x_2460, 1ULL, 1);
    v_t_2473 = v_x_2472;
    break;
  }
  default: heff_nomatch(v_x_2460);
  }
  V v_c_2474 = (g_heff_2ecommands_2eappsIn_24s954_24s1192_24s1335(v_st_240, heff_dup(v_t_242), heff_dup(v_x_2470), v_t_2471, v_t_2473));
  return heff_tail(v_c_2474, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam15, 1, 8, (V[]){v_x_2470, v_hd_2413, v_cmd_241, v_k_2414, v_none_243, v_st_240, v_t_242, v_done_244})});
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam11(V self, V *args) {
  V v_x_2460 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_xs_2462;
  switch (heff_tag_of(v_x_2460)) {
  case TAG_Nothing: {
    v_xs_2462 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2461 = heff_dup(heff_field(v_x_2460, 0));
    v_xs_2462 = v_x_2461;
    break;
  }
  default: heff_nomatch(v_x_2460);
  }
  V v_total_2463 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2462; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2462); r_; });
  V v_c_2469 = heff_clo(g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam12, 2, 1, (V[]){v_total_2463});
  return heff_tail(v_c_2469, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam14, 1, 8, (V[]){v_x_2460, v_st_240, v_t_242, v_hd_2413, v_cmd_241, v_k_2414, v_none_243, v_done_244})});
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam8(V self, V *args) {
  V v_x_2445 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2445);
  V v_t_2446 = (g_std_2epath_2eparse(v_st_240, heff_get(heff_dup(v_t_242), LBL_root)));
  V v_t_2447 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str11)));
  V v_p_2448 = (g_std_2epath_2ejoin_2eonto_240(v_t_2446, v_t_2447));
  V v_t_2449 = ({ V a_0 = heff_get(heff_dup(v_p_2448), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2448), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2450 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2448), LBL_drive), heff_get(v_p_2448, LBL_absolute), v_t_2449});
  V v_path_2451 = (g_std_2epath_2erender(v_st_240, v_t_2450));
  V v_c_2459 = heff_clo(g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam9, 2, 1, (V[]){v_path_2451});
  return heff_tail(v_c_2459, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam11, 1, 7, (V[]){v_hd_2413, v_st_240, v_t_242, v_cmd_241, v_k_2414, v_none_243, v_done_244})});
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_x_2425), LBL_errors));
  switch (heff_tag_of(v_t_2429)) {
  case TAG_True: {
    heff_drop(v_st_240);
    heff_drop(v_t_242);
    heff_drop(v_none_243);
    heff_drop(v_done_244);
    V v_n_2430 = heff_get(v_x_2425, LBL_errors);
    V v_t_2431 = heff_intEq(heff_dup(v_n_2430), MK_INT(1LL));
    V v_t_2432;
    switch (heff_tag_of(v_t_2431)) {
    case TAG_True: {
      heff_drop(v_n_2430);
      v_t_2432 = ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str2);
      break;
    }
    case TAG_False: {
      v_t_2432 = heff_strAppend(heff_intShow(v_n_2430), ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str3));
      break;
    }
    default: heff_nomatch(v_t_2431);
    }
    return (g_heff_2ecommands_2enothingBuilt_24s953_24s1085(v_cmd_241, heff_strAppend(v_t_2432, ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str4)), v_hd_2413, v_k_2414));
  }
  case TAG_False: {
    V v_n_2433 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_get(v_x_2425, LBL_seen); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2434 = heff_intEq(heff_dup(v_n_2433), MK_INT(1LL));
    V v_t_2435;
    switch (heff_tag_of(v_t_2434)) {
    case TAG_True: {
      heff_drop(v_n_2433);
      v_t_2435 = ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str5);
      break;
    }
    case TAG_False: {
      v_t_2435 = heff_strAppend(heff_intShow(v_n_2433), ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str6));
      break;
    }
    default: heff_nomatch(v_t_2434);
    }
    V v_str_2436 = heff_strAppend(((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str7), heff_strAppend(heff_dup(v_cmd_241), heff_strAppend(((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str8), heff_strAppend(v_t_2435, ((V)&g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_str9)))));
    V v_c_2444 = heff_clo(g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam7, 2, 1, (V[]){v_str_2436});
    return heff_tail(v_c_2444, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam8, 1, 7, (V[]){v_st_240, v_t_242, v_hd_2413, v_cmd_241, v_k_2414, v_none_243, v_done_244})});
  }
  default: return heff_nomatch(v_t_2429);
  }
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2426 = heff_tag(TAG_End, 2, (V[]){v_x_2423, NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})}));
  return heff_tail(heff_get(heff_dup(v_hd_2413), LBL_bind), 2, (V[]){v_t_2427, heff_clo(g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam6, 1, 8, (V[]){v_x_2425, v_cmd_241, v_hd_2413, v_k_2414, v_st_240, v_t_242, v_none_243, v_done_244})});
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2424 = heff_rec(2, shape_292_89, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  return ({ V a_0 = heff_dup(v_x_2423); V a_1 = v_t_2424; V a_2 = v_x_2415; V a_3 = heff_dup(v_hd_2413); V a_4 = heff_clo(g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam5, 1, 8, (V[]){v_x_2423, v_hd_2413, v_cmd_241, v_k_2414, v_st_240, v_t_242, v_none_243, v_done_244}); V r_ = (g_heff_2ecommands_2echeckModules_24s951_24s1083_24s1206_24s1275_24s1344(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2415); r_; });
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_total_2416 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_x_2415));
  V v_c_2422 = heff_clo(g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam2, 2, 1, (V[]){v_total_2416});
  return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam4, 1, 8, (V[]){v_x_2415, v_hd_2413, v_cmd_241, v_k_2414, v_st_240, v_t_242, v_none_243, v_done_244})});
}
V g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_none_243 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo(g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347_lam1, 1, 7, (V[]){v_hd_2413, v_cmd_241, v_k_2414, v_st_240, v_t_242, v_none_243, v_done_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {105, 110, 115, 116, 97, 108, 108, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str3 = {{0x80000000u, K_STR, 0}, 31, 31, {104, 101, 102, 102, 32, 105, 110, 115, 116, 97, 108, 108, 58, 32, 110, 111, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 105, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str5 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 110, 115, 116, 97, 108, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str6 = {{0x80000000u, K_STR, 0}, 29, 29, {104, 101, 102, 102, 32, 105, 110, 115, 116, 97, 108, 108, 58, 32, 110, 111, 32, 112, 114, 111, 103, 114, 97, 109, 115, 32, 105, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str7 = {{0x80000000u, K_STR, 0}, 41, 41, {58, 32, 97, 112, 112, 47, 88, 47, 32, 119, 105, 116, 104, 32, 97, 32, 98, 117, 105, 108, 100, 46, 104, 102, 32, 105, 115, 32, 116, 104, 101, 32, 112, 114, 111, 103, 114, 97, 109, 32, 88}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam3(V self, V *args); static Clo g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam3, 1, 0};
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam2(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam5(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam7(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam9(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam8(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam6(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam4(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam1(V self, V *args);
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam0(V self, V *args);
Clo g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_entry, 3, 0};

V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecommands_2estyleNow_24s863_24s1035(heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam0, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242})));
}
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam3(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k2_2412 = args[1];
  V v_path_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2410, ((V)&g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam3_clo)})});
  V v_t_2415 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){v_t_2416}));
  V f_ = heff_get(v_hd_2411, LBL_bind);
  args[0] = v_t_2417;
  args[1] = v_k2_2412;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam5(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_x_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2441}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2442, v_k_242});
}
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam9(V self, V *args) {
  V v_x_2453 = args[0];
  V v_hd_2445 = heff_env(self)[0];
  V v_k_2446 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2453);
  V v_t_2454 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2455 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2445), LBL_malg), 1, (V[]){v_t_2457}));
  return heff_tail(heff_get(v_hd_2445, LBL_bind), 2, (V[]){v_t_2458, v_k_2446});
}
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam8(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_dir_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2447 = heff_strAppend(((V)&g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str6), heff_strAppend(v_dir_240, ((V)&g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str7)));
  V v_t_2448 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2447, ((V)&g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str8)), NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2445), LBL_malg), 1, (V[]){v_t_2451}));
  V f_ = heff_get(heff_dup(v_hd_2445), LBL_bind);
  args[0] = v_t_2452;
  args[1] = heff_clo(g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam9, 1, 2, (V[]){v_hd_2445, v_k_2446});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nothing: {
    heff_drop(v_x_2430);
    heff_drop(v_x_243);
    V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str3), v_dir_240), ((V)&g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str4));
    V v_t_2432 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2431, NTAG(TAG_MkUnit)});
    V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2435}));
    return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2436, heff_clo(g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam7, 1, 2, (V[]){v_hd_241, v_k_242})});
  }
  case TAG_Just: {
    heff_take_n(v_x_2419, 0ULL, 1);
    V v_t_2444 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eonPathHint_24s972_24s1098_clo), 2, (V[]){heff_dup(v_x_243), heff_get(heff_dup(v_x_2430), LBL_bin)}));
    V v_t_2459 = (g_heff_2ecommands_2ebuildProject_24s973_24s1099_24s1209_24s1278_24s1347(v_x_243, ((V)&g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str5), v_x_2430, heff_clo(g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam8, 2, 1, (V[]){v_dir_240}), v_t_2444));
    return heff_tail(v_t_2459, 2, (V[]){v_hd_241, v_k_242});
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2420 = (g_std_2epath_2eparse(v_x_243, heff_dup(v_x_244)));
  V v_t_2421 = (g_std_2epath_2eparse(v_x_243, ((V)&g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str1)));
  V v_p_2422 = (g_std_2epath_2ejoin_2eonto_240(v_t_2420, v_t_2421));
  V v_t_2423 = ({ V a_0 = heff_get(heff_dup(v_p_2422), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2422), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2424 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_2422), LBL_drive), heff_get(v_p_2422, LBL_absolute), v_t_2423});
  V v_t_2425 = (g_std_2epath_2erender(v_x_243, v_t_2424));
  V v_x_2426 = heff_rec(5, shape_283_22_287_231_301, (V[]){heff_dup(v_dir_240), v_t_2425, ((V)&g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str2), NTAG(TAG_False), heff_tag(TAG_Just, 1, (V[]){v_x_244})});
  V v_c_2429 = heff_clo(g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam5, 2, 1, (V[]){v_x_2426});
  return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam6, 1, 5, (V[]){v_x_2419, v_dir_240, v_hd_241, v_k_242, v_x_243})});
}
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_245 = (g_std_2epath_2eparse(v_x_243, heff_dup(v_dir_240)));
  V v_t_246 = (g_std_2epath_2eparse(v_x_243, ((V)&g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_str0)));
  V v_p_247 = (g_std_2epath_2ejoin_2eonto_240(v_t_245, v_t_246));
  V v_t_248 = ({ V a_0 = heff_get(heff_dup(v_p_247), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_247), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_249 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_247), LBL_drive), heff_get(v_p_247, LBL_absolute), v_t_248});
  V v_path_2410 = (g_std_2epath_2erender(v_x_243, v_t_249));
  V v_c_2418 = heff_clo(g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam2, 2, 1, (V[]){v_path_2410});
  return heff_tail(v_c_2418, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam4, 1, 5, (V[]){v_x_243, v_x_244, v_dir_240, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecommands_2eheffHome_24s971_24s1097(heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einstallCmd_24s970_24s1096_24s1208_24s1277_24s1346_lam1, 1, 4, (V[]){v_x_243, v_dir_240, v_hd_241, v_k_242})));
}