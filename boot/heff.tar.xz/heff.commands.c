// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2eheffVersions_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {48, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2eheffVersions_str1 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 40, 116, 104, 101, 32, 115, 97, 109, 101, 32, 48, 46, 120, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eheffVersions_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2eheffVersions_str3 = {{0x80000000u, K_STR, 0}, 13, 13, {32, 105, 115, 32, 102, 111, 114, 32, 104, 101, 102, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2ecommands_2eheffVersions_str4 = {{0x80000000u, K_STR, 0}, 19, 19, {44, 32, 97, 110, 100, 32, 116, 104, 105, 115, 32, 104, 101, 102, 102, 32, 105, 115, 32}};
Clo g_heff_2ecommands_2eheffVersions_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffVersions_entry, 5, 0};

V g_heff_2ecommands_2eheffVersions(V v_who_240, V v_wanted_241, V v_running_242, V v_x4_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_who_240);
    heff_drop(v_wanted_241);
    heff_drop(v_running_242);
    heff_drop(v_x4_243);
    heff_drop(v_x5_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_w_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse(v_x4_243, 1ULL);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nothing: {
      heff_drop(v_who_240);
      heff_drop(v_wanted_241);
      heff_drop(v_running_242);
      heff_drop(v_x5_244);
      heff_drop(v_w_245);
      heff_drop(v_ru_24x4_243_24Just);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_r_246 = heff_field(v_x5_244, 0);
      heff_take(v_x5_244, 1ULL);
      V v_t_247 = ({ V a_0 = v_w_245; V a_1 = v_r_246; V r_ = (g_heff_2eproject_2ecompatible(a_0, a_1)); heff_drop(v_w_245); heff_drop(v_r_246); r_; });
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_who_240);
        heff_drop(v_wanted_241);
        heff_drop(v_running_242);
        heff_drop(v_ru_24x4_243_24Just);
        heff_drop(v_t_247);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        heff_drop(v_t_247);
        V v_t_248 = heff_strEq(heff_strSlice(heff_dup(v_wanted_241), MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2ecommands_2eheffVersions_str0));
        V v_t_249;
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          heff_drop(v_t_248);
          v_t_249 = ((V)&g_heff_2ecommands_2eheffVersions_str1);
          break;
        }
        case TAG_False: {
          heff_drop(v_t_248);
          v_t_249 = ((V)&g_heff_2ecommands_2eheffVersions_str2);
          break;
        }
        default: heff_nomatch(v_t_248);
        }
        V v_t_2410 = heff_strAppend(v_who_240, heff_strAppend(((V)&g_heff_2ecommands_2eheffVersions_str3), heff_strAppend(v_wanted_241, heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecommands_2eheffVersions_str4), v_running_242)))));
        return heff_tag_at(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){v_t_2410});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecommands_2eheffVersions_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eheffVersions(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eheffErrors_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eheffErrors_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2ecommands_2eheffErrors_str2 = {{0x80000000u, K_STR, 0}, 23, 23, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 58, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2eheffErrors_str3 = {{0x80000000u, K_STR, 0}, 12, 12, {116, 104, 101, 32, 112, 97, 99, 107, 97, 103, 101, 32}};
V g_heff_2ecommands_2eheffErrors_lam0(V self, V *args);
Clo g_heff_2ecommands_2eheffErrors_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eheffErrors_entry, 2, 0};

V g_heff_2ecommands_2eheffErrors(V v_running_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_project_242 = heff_field(v_x2_241, 0);
    V v_deps_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse(v_x2_241, 3ULL);
    V v_t_244 = heff_strEq(heff_get(heff_dup(v_project_242), LBL_heff), ((V)&g_heff_2ecommands_2eheffErrors_str0));
    V v_xs_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_project_242);
      heff_drop(v_ru_24x2_241_24Cons);
      heff_drop(v_t_244);
      v_xs_245 = v_deps_243;
      break;
    }
    case TAG_False: {
      heff_drop(v_t_244);
      v_xs_245 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_project_242, v_deps_243});
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_t_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_245));
    return ({ V a_0 = heff_clo(g_heff_2ecommands_2eheffErrors_lam0, 2, 1, (V[]){heff_dup(v_running_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eheffErrors_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eheffErrors(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eheffErrors_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_running_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_249 = heff_strEq(heff_get(heff_dup(v_x_248), LBL_own), ((V)&g_heff_2ecommands_2eheffErrors_str1));
  V v_who_2410;
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    heff_drop(v_t_249);
    v_who_2410 = ((V)&g_heff_2ecommands_2eheffErrors_str2);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_249);
    v_who_2410 = heff_strAppend(((V)&g_heff_2ecommands_2eheffErrors_str3), heff_get(heff_dup(v_x_248), LBL_path));
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_wanted_2411 = heff_get(v_x_248, LBL_heff);
  V v_t_2417;
  switch (heff_tag_of(v_running_240)) {
  case TAG_Nothing: {
    heff_drop(v_running_240);
    heff_drop(v_who_2410);
    heff_drop(v_wanted_2411);
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_running_2412 = heff_field(v_running_240, 0);
    heff_take(v_running_240, 1ULL);
    V v_t_2413 = (g_heff_2eproject_2eversion(heff_dup(v_wanted_2411)));
    V v_t_2414 = (g_heff_2eproject_2eversion(heff_dup(v_running_2412)));
    V v_t_2415 = (g_heff_2ecommands_2eheffVersions(v_who_2410, v_wanted_2411, v_running_2412, v_t_2413, v_t_2414));
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      heff_drop(v_t_2415);
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_why_2416 = heff_field(v_t_2415, 0);
      heff_take(v_t_2415, 1ULL);
      v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){v_why_2416, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    break;
  }
  default: heff_nomatch(v_running_240);
  }
  return (g_prelude_2econcatList(v_t_2417, v_acc_247));
}
Clo g_heff_2ecommands_2eelemStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eelemStrM_entry, 2, 0};

V g_heff_2ecommands_2eelemStrM(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_strEq(heff_dup(v_x_240), heff_dup(v_y_242));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      heff_drop(v_t_244);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eelemStrM_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eelemStrM(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecommands_2enubStrGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enubStrGo_entry, 2, 0};

V g_heff_2ecommands_2enubStrGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse(v_x2_241, 3ULL);
    V v_t_244 = (g_heff_2ecommands_2eelemStrM(heff_dup(v_x_242), v_seen_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_242);
      heff_drop(v_ru_24x2_241_24Cons);
      heff_drop(v_t_244);
      V t_0 = v_seen_240;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_t_244);
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), (g_heff_2ecommands_2enubStrGo(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_rest_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2enubStrGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2enubStrGo(a[0], a[1]);
}
Clo g_heff_2ecommands_2epathOfModule_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epathOfModule_entry, 2, 0};

V g_heff_2ecommands_2epathOfModule(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_m_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_strEq(heff_get(heff_dup(v_s_242), LBL_module), heff_dup(v_m_241));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_m_241);
      heff_drop(v_t_244);
      return heff_tag(TAG_Just, 1, (V[]){heff_get(heff_dup(v_s_242), LBL_path)});
    }
    case TAG_False: {
      heff_drop(v_t_244);
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2epathOfModule_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2epathOfModule(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeaf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeaf_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeaf_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeaf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2ecommands_2eprovidesLeaf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprovidesLeaf_entry, 2, 0};

V g_heff_2ecommands_2eprovidesLeaf(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeaf_str0), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x2_245 = (g_heff_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      heff_drop(v_x2_245);
      v_t_248 = ((V)&g_heff_2ecommands_2eprovidesLeaf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take(v_x2_245, 3ULL);
      v_t_248 = ({ V a_0 = v_x_246; V a_1 = v_xs_247; V r_ = (g_prelude_2efoldl_24s13(a_0, a_1)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_strEq(heff_get(heff_dup(v_p_242), LBL_module), v_t_248);
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_t_249);
      V v_t_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeaf_str2), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeaf_str3), heff_get(heff_dup(v_p_242), LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2413 = (g_prelude_2emap_24s635(v_t_2412));
      V v_t_2414 = (g_heff_2eemit_2ecatMaybesL(v_t_2413));
      V v_t_2415 = (g_prelude_2efilter_24s634(v_t_2414));
      V v_t_2416 = ({ V a_0 = v_t_2411; V a_1 = v_t_2415; V r_ = (g_heff_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2415); r_; });
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        heff_drop(v_k_241);
        heff_drop(v_t_2416);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        heff_drop(v_t_2416);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    case TAG_False: {
      heff_drop(v_t_249);
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprovidesLeaf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprovidesLeaf(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2erunDir_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {46, 104, 101, 102, 102, 47, 114, 117, 110}};
Clo g_heff_2ecommands_2erunDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erunDir_entry, 1, 0};

V g_heff_2ecommands_2erunDir(V v_paths_240) {
top: ;
  V v_st_241 = heff_get(heff_dup(v_paths_240), LBL_style);
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_get(v_paths_240, LBL_root)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ecommands_2erunDir_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = ({ V a_0 = heff_get(heff_dup(v_p_244), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_244), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_246 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_244), LBL_drive), heff_get(v_p_244, LBL_absolute), v_t_245});
  return ({ V a_0 = v_st_241; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); r_; });
}
V g_heff_2ecommands_2erunDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2erunDir(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2erunPath_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunPath_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 109, 106, 115}};
Clo g_heff_2ecommands_2erunPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erunPath_entry, 2, 0};

V g_heff_2ecommands_2erunPath(V v_paths_240, V v_file_241) {
top: ;
  V v_t_242 = (g_heff_2ecommands_2erunDir(heff_dup(v_paths_240)));
  V v_p_243 = ({ V b_0 = heff_get(heff_dup(v_paths_240), LBL_style); V a_1 = v_file_241; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_244 = ({ V a_0 = heff_get(heff_dup(v_p_243), LBL_absolute); V b_1 = heff_get(v_p_243, LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_x2_244);
    v_t_247 = ((V)&g_heff_2ecommands_2erunPath_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take(v_x2_244, 3ULL);
    v_t_247 = ({ V a_0 = v_x_245; V a_1 = v_xs_246; V r_ = (g_prelude_2efoldl_24s88(a_0, a_1)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  return (g_heff_2eload_2eunder(v_paths_240, v_t_242, heff_strAppend(v_t_247, ((V)&g_heff_2ecommands_2erunPath_str1))));
}
V g_heff_2ecommands_2erunPath_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2erunPath(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeafC_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeafC_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeafC_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprovidesLeafC_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2ecommands_2eprovidesLeafC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprovidesLeafC_entry, 2, 0};

V g_heff_2ecommands_2eprovidesLeafC(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeafC_str0), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x2_245 = (g_heff_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      heff_drop(v_x2_245);
      v_t_248 = ((V)&g_heff_2ecommands_2eprovidesLeafC_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take(v_x2_245, 3ULL);
      v_t_248 = ({ V a_0 = v_x_246; V a_1 = v_xs_247; V r_ = (g_prelude_2efoldl_24s13(a_0, a_1)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_strEq(heff_get(heff_dup(v_p_242), LBL_module), v_t_248);
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_t_249);
      V v_t_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeafC_str2), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2eprovidesLeafC_str3), heff_get(heff_dup(v_p_242), LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2413 = (g_prelude_2emap_24s702(v_t_2412));
      V v_t_2414 = (g_heff_2eemitc_2ecatMaybesC(v_t_2413));
      V v_t_2415 = ({ V a_0 = v_t_2411; V a_1 = v_t_2414; V r_ = (g_heff_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2414); r_; });
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop(v_k_241);
        heff_drop(v_t_2415);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        heff_drop(v_t_2415);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    case TAG_False: {
      heff_drop(v_t_249);
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprovidesLeafC_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprovidesLeafC(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efailLine_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efailLine_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efailLine_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efailLine_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 65, 73, 76, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efailLine_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2efailLine_str5 = {{0x80000000u, K_STR, 0}, 12, 12, {10, 32, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2efailLine_str6 = {{0x80000000u, K_STR, 0}, 12, 12, {10, 32, 32, 98, 117, 116, 32, 103, 111, 116, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2efailLine_str7 = {{0x80000000u, K_STR, 0}, 12, 12, {10, 32, 32, 100, 105, 102, 102, 32, 32, 32, 32, 32}};
Clo g_heff_2ecommands_2efailLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efailLine_entry, 3, 0};

V g_heff_2ecommands_2efailLine(V v_f_240, V v_r_241, V v_m_242) {
top: ;
  V v_t_243 = heff_get(heff_dup(v_r_241), LBL_owner);
  V v_t_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_t_243);
    v_t_245 = ((V)&g_heff_2ecommands_2efailLine_str0);
    break;
  }
  case TAG_Just: {
    V v_n_244 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    v_t_245 = heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str1), heff_strAppend(v_n_244, ((V)&g_heff_2ecommands_2efailLine_str2)));
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_246 = heff_get(heff_get(v_r_241, LBL_watch), LBL_expr);
  return heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str3), heff_strAppend(v_f_240, heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str4), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str5), heff_strAppend(heff_get(heff_dup(v_m_242), LBL_expected), heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str6), heff_strAppend(heff_get(heff_dup(v_m_242), LBL_got), heff_strAppend(((V)&g_heff_2ecommands_2efailLine_str7), heff_get(v_m_242, LBL_diff)))))))))));
}
V g_heff_2ecommands_2efailLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2efailLine(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2estatistic_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2estatistic_str1 = {{0x80000000u, K_STR, 0}, 12, 12, {32, 103, 105, 118, 101, 110, 32, 117, 112, 32, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2estatistic_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2estatistic_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {37}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2estatistic_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2estatistic_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2estatistic_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2estatistic_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 114, 117, 110, 115}};
V g_heff_2ecommands_2estatistic_lam0(V self, V *args);
Clo g_heff_2ecommands_2estatistic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2estatistic_entry, 1, 0};

V g_heff_2ecommands_2estatistic(V v_o_240) {
top: ;
  V v_t_241 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_runs));
  V v_t_242 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_o_240), LBL_discarded));
  V v_t_244;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_t_242);
    V v_t_243 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_discarded));
    v_t_244 = heff_strAppend(((V)&g_heff_2ecommands_2estatistic_str0), heff_strAppend(v_t_243, ((V)&g_heff_2ecommands_2estatistic_str1)));
    break;
  }
  case TAG_False: {
    heff_drop(v_t_242);
    v_t_244 = ((V)&g_heff_2ecommands_2estatistic_str2);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_x2_2416 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2estatistic_lam0, 1, 1, (V[]){heff_dup(v_o_240)}), heff_get(v_o_240, LBL_labels)));
  V v_t_2419;
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nil: {
    heff_drop(v_x2_2416);
    v_t_2419 = ((V)&g_heff_2ecommands_2estatistic_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_xs_2418 = heff_field(v_x2_2416, 1);
    heff_take(v_x2_2416, 3ULL);
    v_t_2419 = ({ V a_0 = v_x_2417; V a_1 = v_xs_2418; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2418); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2416);
  }
  return heff_strAppend(v_t_241, heff_strAppend(((V)&g_heff_2ecommands_2estatistic_str7), heff_strAppend(v_t_244, v_t_2419)));
}
V g_heff_2ecommands_2estatistic_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2estatistic(a[0]);
}
V g_heff_2ecommands_2estatistic_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_o_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_n_248;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_y_247 = heff_dup(heff_field(v_p_245, 1));
    v_n_248 = v_y_247;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_total_249 = heff_get(v_o_240, LBL_runs);
  V v_t_2410 = heff_intEq(heff_dup(v_total_249), MK_INT(0LL));
  V v_t_2411;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_n_248);
    heff_drop(v_total_249);
    heff_drop(v_t_2410);
    v_t_2411 = MK_INT(0LL);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2410);
    v_t_2411 = heff_intDiv(heff_intMul(v_n_248, MK_INT(100LL)), v_total_249);
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_t_2412 = heff_strAppend(heff_intShow(v_t_2411), ((V)&g_heff_2ecommands_2estatistic_str3));
  V v_t_2415;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_p_245, 0);
    heff_take(v_p_245, 1ULL);
    v_t_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  return heff_strAppend(((V)&g_heff_2ecommands_2estatistic_str4), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ecommands_2estatistic_str5), v_t_2415)));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eoutcomeLine_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 111, 107, 32, 32, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eoutcomeLine_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eoutcomeLine_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eoutcomeLine_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eoutcomeLine_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2eoutcomeLine_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2eoutcomeLine_str6 = {{0x80000000u, K_STR, 0}, 12, 12, {32, 103, 105, 118, 101, 110, 32, 117, 112, 32, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eoutcomeLine_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eoutcomeLine_str8 = {{0x80000000u, K_STR, 0}, 10, 10, {110, 111, 116, 32, 115, 104, 114, 117, 110, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2eoutcomeLine_str9 = {{0x80000000u, K_STR, 0}, 11, 11, {115, 104, 114, 117, 110, 107, 32, 111, 110, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2eoutcomeLine_str10 = {{0x80000000u, K_STR, 0}, 7, 7, {115, 104, 114, 117, 110, 107, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2eoutcomeLine_str11 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 116, 105, 109, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2eoutcomeLine_str12 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 32, 40, 102, 97, 105, 108, 101, 100, 32, 97, 102, 116, 101, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eoutcomeLine_str13 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 114, 117, 110, 115, 32, 104, 101, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2eoutcomeLine_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {59, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2eoutcomeLine_str15 = {{0x80000000u, K_STR, 0}, 16, 16, {59, 32, 97, 103, 97, 105, 110, 58, 32, 45, 45, 115, 101, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eoutcomeLine_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2ecommands_2eoutcomeLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eoutcomeLine_entry, 1, 0};

V g_heff_2ecommands_2eoutcomeLine(V v_o_240) {
top: ;
  V v_t_241 = heff_get(heff_dup(v_o_240), LBL_ok);
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_t_241);
    v_t_242 = ((V)&g_heff_2ecommands_2eoutcomeLine_str0);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_241);
    v_t_242 = ((V)&g_heff_2ecommands_2eoutcomeLine_str1);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_243 = heff_get(heff_dup(v_o_240), LBL_property);
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_t_243);
    v_t_244 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_243);
    v_t_244 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_2416;
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    v_t_2416 = ((V)&g_heff_2ecommands_2eoutcomeLine_str2);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_244);
    V v_t_245 = heff_get(heff_dup(v_o_240), LBL_ok);
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2ecommands_2estatistic(heff_dup(v_o_240)));
      v_t_2416 = heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str3), heff_strAppend(v_t_246, ((V)&g_heff_2ecommands_2eoutcomeLine_str4)));
      break;
    }
    case TAG_False: {
      heff_drop(v_t_245);
      V v_t_247 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_runs));
      V v_t_248 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_o_240), LBL_discarded));
      V v_t_2410;
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        heff_drop(v_t_248);
        V v_t_249 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_discarded));
        v_t_2410 = heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str5), heff_strAppend(v_t_249, ((V)&g_heff_2ecommands_2eoutcomeLine_str6)));
        break;
      }
      case TAG_False: {
        heff_drop(v_t_248);
        v_t_2410 = ((V)&g_heff_2ecommands_2eoutcomeLine_str7);
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V v_n_2411 = heff_get(heff_dup(v_o_240), LBL_shrinks);
      V v_t_2412 = heff_intEq(heff_dup(v_n_2411), MK_INT(0LL));
      V v_t_2414;
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_n_2411);
        heff_drop(v_t_2412);
        v_t_2414 = ((V)&g_heff_2ecommands_2eoutcomeLine_str8);
        break;
      }
      case TAG_False: {
        heff_drop(v_t_2412);
        V v_t_2413 = heff_intEq(heff_dup(v_n_2411), MK_INT(1LL));
        switch (heff_tag_of(v_t_2413)) {
        case TAG_True: {
          heff_drop(v_n_2411);
          heff_drop(v_t_2413);
          v_t_2414 = ((V)&g_heff_2ecommands_2eoutcomeLine_str9);
          break;
        }
        case TAG_False: {
          heff_drop(v_t_2413);
          v_t_2414 = heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str10), heff_strAppend(heff_intShow(v_n_2411), ((V)&g_heff_2ecommands_2eoutcomeLine_str11)));
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      V v_t_2415 = heff_intShow(heff_get(heff_dup(v_o_240), LBL_seed));
      v_t_2416 = heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str12), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str13), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str14), heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecommands_2eoutcomeLine_str15), heff_strAppend(v_t_2415, ((V)&g_heff_2ecommands_2eoutcomeLine_str16)))))))));
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  return heff_strAppend(v_t_242, heff_strAppend(heff_get(v_o_240, LBL_name), v_t_2416));
}
V g_heff_2ecommands_2eoutcomeLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eoutcomeLine(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2efailLines_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 32, 32, 32, 32, 32, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2efailLines_str1 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 32, 32, 32, 32, 32, 32, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2efailLines_str2 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 32, 32, 32, 32, 32, 32, 32, 98, 117, 116, 32, 103, 111, 116, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2efailLines_str3 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 32, 32, 32, 32, 32, 32, 32, 100, 105, 102, 102, 32, 32, 32, 32, 32}};
Clo g_heff_2ecommands_2efailLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efailLines_entry, 2, 0};

V g_heff_2ecommands_2efailLines(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_FailBecause: {
    V v_why_242 = heff_field(v_x2_241, 0);
    heff_take(v_x2_241, 1ULL);
    return heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2efailLines_str0), v_why_242), NTAG(TAG_Nil)});
  }
  case TAG_FailDiffer: {
    V v_expected_243 = heff_field(v_x2_241, 0);
    V v_got_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24FailDiffer = heff_take_reuse(v_x2_241, 3ULL);
    V v_m_245 = (g_heff_2ereport_2emismatch(v_color_240, v_expected_243, v_got_244));
    V v_t_246 = heff_strAppend(((V)&g_heff_2ecommands_2efailLines_str1), heff_get(heff_dup(v_m_245), LBL_expected));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ecommands_2efailLines_str2), heff_get(heff_dup(v_m_245), LBL_got));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecommands_2efailLines_str3), heff_get(v_m_245, LBL_diff));
    V v_t_249 = heff_tag_at(v_ru_24x2_241_24FailDiffer, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_246, heff_tag(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2efailLines_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2efailLines(a[0], a[1]); heff_drop(a[0]); return r;
}

static V g_heff_2ecommands_2edefaultSeed_val;
static int g_heff_2ecommands_2edefaultSeed_st;
static V g_heff_2ecommands_2edefaultSeed_init(void) {
  return MK_INT(2026LL);
}
V g_heff_2ecommands_2edefaultSeed_get(void) {
  if (g_heff_2ecommands_2edefaultSeed_st == 2) return g_heff_2ecommands_2edefaultSeed_val;
  if (g_heff_2ecommands_2edefaultSeed_st == 1) heff_fail("defined by itself");
  g_heff_2ecommands_2edefaultSeed_st = 1;
  g_heff_2ecommands_2edefaultSeed_val = heff_tr(g_heff_2ecommands_2edefaultSeed_init());
  g_heff_2ecommands_2edefaultSeed_st = 2;
  return g_heff_2ecommands_2edefaultSeed_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectName_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectName_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectName_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectName_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2ecommands_2eprojectName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprojectName_entry, 3, 0};

V g_heff_2ecommands_2eprojectName(V v_st_240, V v_dir_241, V v_x3_242) {
top: ;
  V v_t_243 = heff_strEq(heff_dup(v_dir_241), ((V)&g_heff_2ecommands_2eprojectName_str0));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_t_243);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      heff_drop(v_x3_242);
      V v_t_244 = (g_std_2epath_2eparse(v_st_240, v_dir_241));
      V v_xs_245 = heff_get(v_t_244, LBL_segments);
      V v_x1_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_245));
      V v_x2_249;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nil: {
        heff_drop(v_x1_246);
        v_x2_249 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x1_246, 0);
        heff_take(v_x1_246, 1ULL);
        v_x2_249 = heff_tag(TAG_Just, 1, (V[]){v_x_247});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        heff_drop(v_x2_249);
        return ((V)&g_heff_2ecommands_2eprojectName_str1);
      }
      case TAG_Just: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        heff_take(v_x2_249, 1ULL);
        return v_x_2410;
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    case TAG_Just: {
      V v_pwd_2411 = heff_field(v_x3_242, 0);
      V v_ru_24x3_242_24Just = heff_take_reuse(v_x3_242, 1ULL);
      heff_drop(v_dir_241);
      V v_t_2412 = (g_std_2epath_2eparse(v_st_240, v_pwd_2411));
      V v_xs_2413 = heff_get(v_t_2412, LBL_segments);
      V v_x1_2414 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2413));
      V v_x2_2417;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Nil: {
        heff_drop(v_ru_24x3_242_24Just);
        heff_drop(v_x1_2414);
        v_x2_2417 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x1_2414, 0);
        heff_take(v_x1_2414, 1ULL);
        v_x2_2417 = heff_tag_at(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_x_2415});
        break;
      }
      default: heff_nomatch(v_x1_2414);
      }
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_Nothing: {
        heff_drop(v_x2_2417);
        return ((V)&g_heff_2ecommands_2eprojectName_str2);
      }
      case TAG_Just: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        heff_take(v_x2_2417, 1ULL);
        return v_x_2418;
      }
      default: return heff_nomatch(v_x2_2417);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_False: {
    heff_drop(v_x3_242);
    heff_drop(v_t_243);
    V v_t_2419 = (g_std_2epath_2eparse(v_st_240, v_dir_241));
    V v_xs_2420 = heff_get(v_t_2419, LBL_segments);
    V v_x1_2421 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2420));
    V v_x2_2424;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_Nil: {
      heff_drop(v_x1_2421);
      v_x2_2424 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x1_2421, 0);
      heff_take(v_x1_2421, 1ULL);
      v_x2_2424 = heff_tag(TAG_Just, 1, (V[]){v_x_2422});
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nothing: {
      heff_drop(v_x2_2424);
      return ((V)&g_heff_2ecommands_2eprojectName_str3);
    }
    case TAG_Just: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      heff_take(v_x2_2424, 1ULL);
      return v_x_2425;
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecommands_2eprojectName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprojectName(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2eprojectFiles_str0 = {{0x80000000u, K_STR, 0}, 14, 14, {32, 32, 123, 32, 109, 111, 100, 117, 108, 101, 32, 61, 32, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2eprojectFiles_str2 = {{0x80000000u, K_STR, 0}, 12, 12, {32, 32, 44, 32, 104, 101, 102, 102, 32, 61, 32, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2eprojectFiles_str5 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 32, 44, 32, 114, 101, 112, 108, 97, 99, 101, 32, 61, 32, 91, 93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eprojectFiles_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2eprojectFiles_str7 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 32, 44, 32, 114, 101, 113, 117, 105, 114, 101, 32, 61, 32, 91, 93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2eprojectFiles_str8 = {{0x80000000u, K_STR, 0}, 9, 9, {112, 97, 99, 107, 97, 103, 101, 32, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2eprojectFiles_str10 = {{0x80000000u, K_STR, 0}, 17, 17, {112, 97, 99, 107, 97, 103, 101, 32, 58, 32, 80, 97, 99, 107, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eprojectFiles_str11 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2eprojectFiles_str12 = {{0x80000000u, K_STR, 0}, 15, 15, {105, 109, 112, 111, 114, 116, 32, 109, 97, 110, 105, 102, 101, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eprojectFiles_str14 = {{0x80000000u, K_STR, 0}, 10, 10, {46, 103, 105, 116, 105, 103, 110, 111, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2eprojectFiles_str15 = {{0x80000000u, K_STR, 0}, 6, 6, {46, 104, 101, 102, 102, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eprojectFiles_str16 = {{0x80000000u, K_STR, 0}, 4, 4, {98, 105, 110, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eprojectFiles_str17 = {{0x80000000u, K_STR, 0}, 4, 4, {115, 114, 99, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eprojectFiles_str18 = {{0x80000000u, K_STR, 0}, 8, 8, {47, 109, 97, 105, 110, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2eprojectFiles_str19 = {{0x80000000u, K_STR, 0}, 18, 18, {45, 45, 32, 96, 104, 101, 102, 102, 32, 116, 101, 115, 116, 32, 115, 114, 99, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[44]; } g_heff_2ecommands_2eprojectFiles_str20 = {{0x80000000u, K_STR, 0}, 44, 44, {47, 109, 97, 105, 110, 46, 104, 102, 96, 32, 99, 104, 101, 99, 107, 115, 32, 116, 104, 101, 32, 119, 97, 116, 99, 104, 101, 115, 59, 32, 96, 104, 101, 102, 102, 32, 114, 117, 110, 32, 115, 114, 99, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2eprojectFiles_str21 = {{0x80000000u, K_STR, 0}, 22, 22, {47, 109, 97, 105, 110, 46, 104, 102, 96, 32, 114, 117, 110, 115, 32, 96, 109, 97, 105, 110, 96, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecommands_2eprojectFiles_str23 = {{0x80000000u, K_STR, 0}, 20, 20, {109, 97, 105, 110, 32, 58, 32, 67, 111, 32, 115, 116, 100, 105, 111, 32, 85, 110, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[33]; } g_heff_2ecommands_2eprojectFiles_str24 = {{0x80000000u, K_STR, 0}, 33, 33, {109, 97, 105, 110, 32, 61, 32, 112, 114, 111, 103, 114, 97, 109, 32, 40, 105, 111, 32, 58, 61, 32, 104, 101, 114, 101, 32, 115, 116, 100, 105, 111, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2ecommands_2eprojectFiles_str25 = {{0x80000000u, K_STR, 0}, 34, 34, {112, 114, 111, 103, 114, 97, 109, 32, 61, 32, 112, 114, 105, 110, 116, 32, 40, 103, 114, 101, 101, 116, 105, 110, 103, 32, 34, 119, 111, 114, 108, 100, 34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str26 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str27 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[50]; } g_heff_2ecommands_2eprojectFiles_str28 = {{0x80000000u, K_STR, 0}, 50, 50, {112, 114, 111, 103, 114, 97, 109, 32, 58, 32, 123, 123, 105, 111, 32, 58, 32, 115, 116, 100, 105, 111, 32, 60, 58, 32, 115, 116, 100, 105, 111, 125, 125, 32, 45, 62, 32, 67, 111, 32, 115, 116, 100, 105, 111, 32, 85, 110, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2eprojectFiles_str29 = {{0x80000000u, K_STR, 0}, 22, 22, {45, 45, 32, 62, 62, 62, 32, 103, 114, 101, 101, 116, 105, 110, 103, 32, 34, 104, 101, 102, 102, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2eprojectFiles_str30 = {{0x80000000u, K_STR, 0}, 17, 17, {45, 45, 32, 34, 72, 101, 108, 108, 111, 44, 32, 104, 101, 102, 102, 33, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[40]; } g_heff_2ecommands_2eprojectFiles_str31 = {{0x80000000u, K_STR, 0}, 40, 40, {103, 114, 101, 101, 116, 105, 110, 103, 32, 110, 97, 109, 101, 32, 61, 32, 34, 72, 101, 108, 108, 111, 44, 32, 34, 32, 43, 43, 32, 110, 97, 109, 101, 32, 43, 43, 32, 34, 33, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str32 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str33 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2eprojectFiles_str34 = {{0x80000000u, K_STR, 0}, 27, 27, {103, 114, 101, 101, 116, 105, 110, 103, 32, 58, 32, 83, 116, 114, 105, 110, 103, 32, 45, 62, 32, 83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2eprojectFiles_str35 = {{0x80000000u, K_STR, 0}, 14, 14, {105, 109, 112, 111, 114, 116, 32, 112, 114, 101, 108, 117, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2eprojectFiles_str36 = {{0x80000000u, K_STR, 0}, 13, 13, {105, 109, 112, 111, 114, 116, 32, 115, 116, 100, 46, 105, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprojectFiles_str37 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2eprojectFiles_str38 = {{0x80000000u, K_STR, 0}, 9, 9, {105, 109, 112, 111, 114, 116, 32, 99, 111}};
Clo g_heff_2ecommands_2eprojectFiles_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprojectFiles_entry, 2, 0};

V g_heff_2ecommands_2eprojectFiles(V v_name_240, V v_v_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str0), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ecommands_2eprojectFiles_str1)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str2), heff_strAppend(v_v_241, ((V)&g_heff_2ecommands_2eprojectFiles_str3)));
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str4), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str6), v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_243, heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str7), v_t_245})});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str8), heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str10), v_t_247})});
  V v_t_249 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str11), ({ V a_0 = ((V)&g_heff_2ecommands_2eprojectFiles_str12); V a_1 = v_t_248; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_t_248); r_; })});
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str13), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str14), ({ V a_0 = ((V)&g_heff_2ecommands_2eprojectFiles_str15); V b_1 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str16), v_t_2410}); V r_ = (g_prelude_2efoldl_24s3(a_0, b_1)); heff_drop(b_1); r_; })});
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str17), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ecommands_2eprojectFiles_str18)));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str19), heff_strAppend(heff_dup(v_name_240), heff_strAppend(((V)&g_heff_2ecommands_2eprojectFiles_str20), heff_strAppend(v_name_240, ((V)&g_heff_2ecommands_2eprojectFiles_str21)))));
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str22), NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str23), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str24), v_t_2414})});
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str25), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str26), v_t_2415})});
  V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str27), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str28), v_t_2416})});
  V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str29), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str30), v_t_2417})});
  V v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str31), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str32), v_t_2418})});
  V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str33), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str34), v_t_2419})});
  V v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str35), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str36), v_t_2420})});
  V v_t_2422 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str37), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2eprojectFiles_str38), v_t_2421})});
  V v_t_2423 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2412, ({ V a_0 = v_t_2413; V a_1 = v_t_2422; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_t_2422); r_; })});
  V v_t_2424 = heff_tag(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_249, heff_tag(TAG_Cons, 2, (V[]){v_t_2411, v_t_2424})});
}
V g_heff_2ecommands_2eprojectFiles_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eprojectFiles(a[0], a[1]);
}
V g_heff_2ecommands_2erequiring_lam0(V self, V *args);
V g_heff_2ecommands_2erequiring_lam1(V self, V *args);
Clo g_heff_2ecommands_2erequiring_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erequiring_entry, 4, 0};

V g_heff_2ecommands_2erequiring(V v_pk_240, V v_name_241, V v_path_242, V v_v_243) {
top: ;
  V v_t_245 = ({ V a_0 = heff_clo(g_heff_2ecommands_2erequiring_lam0, 1, 1, (V[]){heff_dup(v_path_242)}); V b_1 = heff_get(heff_dup(v_pk_240), LBL_require); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_249;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_name_241);
    heff_drop(v_t_245);
    v_t_249 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2erequiring_lam1, 1, 2, (V[]){v_path_242, v_v_243}), heff_get(heff_dup(v_pk_240), LBL_require)));
    break;
  }
  case TAG_False: {
    heff_drop(v_t_245);
    V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(3, shape_190_228_355, (V[]){v_name_241, v_path_242, v_v_243}), NTAG(TAG_Nil)});
    v_t_249 = (g_prelude_2econcatList(heff_get(heff_dup(v_pk_240), LBL_require), v_t_248));
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_rec(4, shape_184_118_264_263, (V[]){heff_get(heff_dup(v_pk_240), LBL_module), heff_get(heff_dup(v_pk_240), LBL_heff), v_t_249, heff_get(v_pk_240, LBL_replace)});
}
V g_heff_2ecommands_2erequiring_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2erequiring(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2erequiring_lam0(V self, V *args) {
  V v_r_244 = args[0];
  V v_path_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_r_244, LBL_path), v_path_242);
}
V g_heff_2ecommands_2erequiring_lam1(V self, V *args) {
  V v_r_246 = args[0];
  V v_path_242 = heff_dup(heff_env(self)[0]);
  V v_v_243 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_247 = heff_strEq(heff_get(heff_dup(v_r_246), LBL_path), heff_dup(v_path_242));
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_t_247);
    return heff_rec(3, shape_190_228_355, (V[]){heff_get(v_r_246, LBL_name), v_path_242, v_v_243});
  }
  case TAG_False: {
    heff_drop(v_path_242);
    heff_drop(v_v_243);
    heff_drop(v_t_247);
    return v_r_246;
  }
  default: return heff_nomatch(v_t_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2eprintErrs_24s887_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintErrs_24s887_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintErrs_24s887_lam0(V self, V *args);
Clo g_heff_2ecommands_2eprintErrs_24s887_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintErrs_24s887_entry, 5, 0};

V g_heff_2ecommands_2eprintErrs_24s887(V v_m_240, V v_x2_241, V v_n_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    heff_drop(v_x2_241);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_n_242});
  }
  case TAG_Cons: {
    V v_l_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse(v_x2_241, 3ULL);
    V v_t_247 = heff_strAppend(heff_dup(v_m_240), heff_strAppend(((V)&g_heff_2ecommands_2eprintErrs_24s887_str0), v_l_245));
    V v_t_248 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2ecommands_2eprintErrs_24s887_str1)), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2410}));
    return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2ecommands_2eprintErrs_24s887_lam0, 1, 5, (V[]){v_m_240, v_rest_246, v_n_242, v_p_243, v_p_244})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eprintErrs_24s887_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eprintErrs_24s887(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2eprintErrs_24s887_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_m_240 = heff_dup(heff_env(self)[0]);
  V v_rest_246 = heff_dup(heff_env(self)[1]);
  V v_n_242 = heff_dup(heff_env(self)[2]);
  V v_p_243 = heff_dup(heff_env(self)[3]);
  V v_p_244 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_2412);
  return (g_heff_2ecommands_2eprintErrs_24s887(v_m_240, v_rest_246, heff_intAdd(v_n_242, MK_INT(1LL)), v_p_243, v_p_244));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eputFileDiags_24s894_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2ecommands_2eputFileDiags_24s894_lam0(V self, V *args); static Clo g_heff_2ecommands_2eputFileDiags_24s894_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eputFileDiags_24s894_lam0, 2, 0};
V g_heff_2ecommands_2eputFileDiags_24s894_lam1(V self, V *args); static Clo g_heff_2ecommands_2eputFileDiags_24s894_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eputFileDiags_24s894_lam1, 2, 0};
V g_heff_2ecommands_2eputFileDiags_24s894_lam2(V self, V *args);
V g_heff_2ecommands_2eputFileDiags_24s894_lam3(V self, V *args);
V g_heff_2ecommands_2eputFileDiags_24s894_lam5(V self, V *args);
V g_heff_2ecommands_2eputFileDiags_24s894_lam4(V self, V *args);
Clo g_heff_2ecommands_2eputFileDiags_24s894_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eputFileDiags_24s894_entry, 1, 0};

V g_heff_2ecommands_2eputFileDiags_24s894(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    return ((V)&g_heff_2ecommands_2eputFileDiags_24s894_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    heff_take(v_x1_240, 3ULL);
    V v_t_245 = heff_get(heff_dup(v_c_243), LBL_diags);
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nil: {
      heff_drop(v_t_245);
      v_t_248 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      heff_take(v_t_245, 0ULL);
      v_t_248 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_c_2422;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_c_243);
      heff_drop(v_t_248);
      v_c_2422 = ((V)&g_heff_2ecommands_2eputFileDiags_24s894_lam1_clo);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_248);
      V v_x2_2412 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2eputFileDiags_24s894_lam2, 1, 1, (V[]){heff_dup(v_c_243)}), heff_get(v_c_243, LBL_diags)));
      V v_str_2415;
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nil: {
        heff_drop(v_x2_2412);
        v_str_2415 = ((V)&g_heff_2ecommands_2eputFileDiags_24s894_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        V v_xs_2414 = heff_field(v_x2_2412, 1);
        heff_take(v_x2_2412, 3ULL);
        v_str_2415 = ({ V a_0 = v_x_2413; V a_1 = v_xs_2414; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2414); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2412);
      }
      v_c_2422 = heff_clo(g_heff_2ecommands_2eputFileDiags_24s894_lam3, 2, 1, (V[]){v_str_2415});
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    return heff_clo(g_heff_2ecommands_2eputFileDiags_24s894_lam4, 2, 2, (V[]){v_c_2422, v_rest_244});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eputFileDiags_24s894_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eputFileDiags_24s894(a[0]);
}
V g_heff_2ecommands_2eputFileDiags_24s894_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(self);
  heff_drop(v_hd_241);
  return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2ecommands_2eputFileDiags_24s894_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  heff_drop(self);
  heff_drop(v_hd_249);
  return heff_tail(v_k_2410, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2ecommands_2eputFileDiags_24s894_lam2(V self, V *args) {
  V v_d_2411 = args[0];
  V v_c_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2erender_2efileDiag(heff_get(heff_dup(v_c_243), LBL_path), heff_get(v_c_243, LBL_source), v_d_2411));
}
V g_heff_2ecommands_2eputFileDiags_24s894_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k2_2417 = args[1];
  V v_str_2415 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2418 = heff_tag(TAG_WriteErr, 2, (V[]){v_str_2415, NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2416), LBL_malg), 1, (V[]){v_t_2420}));
  return heff_tail(heff_get(v_hd_2416, LBL_bind), 2, (V[]){v_t_2421, v_k2_2417});
}
V g_heff_2ecommands_2eputFileDiags_24s894_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_rest_244 = heff_dup(heff_env(self)[0]);
  V v_hd_2423 = heff_dup(heff_env(self)[1]);
  V v_k_2424 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_x_2425);
  V v_t_2426 = (g_heff_2ecommands_2eputFileDiags_24s894(v_rest_244));
  return heff_tail(v_t_2426, 2, (V[]){v_hd_2423, v_k_2424});
}
V g_heff_2ecommands_2eputFileDiags_24s894_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_dup(heff_env(self)[0]);
  V v_rest_244 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_hd_2423), heff_clo(g_heff_2ecommands_2eputFileDiags_24s894_lam5, 1, 3, (V[]){v_rest_244, v_hd_2423, v_k_2424})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecommands_2eemitErrs_24s902_str0 = {{0x80000000u, K_STR, 0}, 20, 20, {104, 101, 102, 102, 58, 32, 110, 111, 116, 32, 99, 111, 109, 112, 105, 108, 101, 100, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eemitErrs_24s902_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eemitErrs_24s902_lam0(V self, V *args);
Clo g_heff_2ecommands_2eemitErrs_24s902_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eemitErrs_24s902_entry, 3, 0};

V g_heff_2ecommands_2eemitErrs_24s902(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2eemitErrs_24s902_str0), v_e_243), ((V)&g_heff_2ecommands_2eemitErrs_24s902_str1));
    V v_t_246 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_WriteErr, 2, (V[]){v_t_245, NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_248}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2eemitErrs_24s902_lam0, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eemitErrs_24s902_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eemitErrs_24s902(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eemitErrs_24s902_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_rest_244 = heff_dup(heff_env(self)[0]);
  V v_p_241 = heff_dup(heff_env(self)[1]);
  V v_p_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_x_2410);
  return (g_heff_2ecommands_2eemitErrs_24s902(v_rest_244, v_p_241, v_p_242));
}
V g_heff_2ecommands_2ediagCount_24s907_lam0(V self, V *args); static Clo g_heff_2ecommands_2ediagCount_24s907_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ediagCount_24s907_lam0, 2, 0};
V g_heff_2ecommands_2ediagCount_24s907_lam3(V self, V *args);
V g_heff_2ecommands_2ediagCount_24s907_lam2(V self, V *args);
V g_heff_2ecommands_2ediagCount_24s907_lam1(V self, V *args);
Clo g_heff_2ecommands_2ediagCount_24s907_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ediagCount_24s907_entry, 1, 0};

V g_heff_2ecommands_2ediagCount_24s907(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecommands_2ediagCount_24s907_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_t_245 = (g_prelude_2emap_24s509(heff_get(heff_dup(v_c_243), LBL_diags)));
    V v_c_246 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintErrs_24s887_clo), 3, (V[]){heff_get(heff_dup(v_c_243), LBL_module), v_t_245, MK_INT(0LL)}));
    return heff_clo(g_heff_2ecommands_2ediagCount_24s907_lam1, 2, 2, (V[]){v_c_246, heff_dup(v_rest_244)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2ediagCount_24s907_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ediagCount_24s907(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ediagCount_24s907_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(self);
  heff_drop(v_hd_241);
  return heff_tail(v_k_242, 1, (V[]){MK_INT(0LL)});
}
V g_heff_2ecommands_2ediagCount_24s907_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_dup(heff_env(self)[0]);
  V v_x_249 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_k_248, 1, (V[]){heff_intAdd(v_x_249, v_x_2411)});
}
V g_heff_2ecommands_2ediagCount_24s907_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_rest_244 = heff_dup(heff_env(self)[0]);
  V v_hd_247 = heff_dup(heff_env(self)[1]);
  V v_k_248 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_c_2410 = ({ V a_0 = v_rest_244; V r_ = (g_heff_2ecommands_2ediagCount_24s907(a_0)); heff_drop(v_rest_244); r_; });
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2ecommands_2ediagCount_24s907_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2ecommands_2ediagCount_24s907_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_dup(heff_env(self)[0]);
  V v_rest_244 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2ediagCount_24s907_lam2, 1, 3, (V[]){v_rest_244, v_hd_247, v_k_248})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintFails_24s909_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintFails_24s909_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintFails_24s909_lam0(V self, V *args); static Clo g_heff_2ecommands_2eprintFails_24s909_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintFails_24s909_lam0, 2, 0};
V g_heff_2ecommands_2eprintFails_24s909_lam1(V self, V *args);
V g_heff_2ecommands_2eprintFails_24s909_lam3(V self, V *args);
V g_heff_2ecommands_2eprintFails_24s909_lam2(V self, V *args);
Clo g_heff_2ecommands_2eprintFails_24s909_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintFails_24s909_entry, 3, 0};

V g_heff_2ecommands_2eprintFails_24s909(V v_f_240, V v_color_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_x3_242);
    return ((V)&g_heff_2ecommands_2eprintFails_24s909_lam0_clo);
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take(v_x3_242, 3ULL);
    V v_t_247 = heff_get(heff_get(heff_dup(v_r_245), LBL_watch), LBL_expected);
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop(v_t_247);
      v_t_249 = ((V)&g_heff_2ecommands_2eprintFails_24s909_str0);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_t_247, 0);
      heff_take(v_t_247, 1ULL);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2410 = heff_get(heff_get(heff_dup(v_r_245), LBL_watch), LBL_value);
    V v_t_2411 = (g_heff_2ereport_2emismatch(v_color_241, v_t_249, v_t_2410));
    V v_str_2412 = (g_heff_2ecommands_2efailLine(heff_dup(v_f_240), v_r_245, v_t_2411));
    V v_c_2419 = heff_clo(g_heff_2ecommands_2eprintFails_24s909_lam1, 2, 1, (V[]){v_str_2412});
    return heff_clo(g_heff_2ecommands_2eprintFails_24s909_lam2, 2, 4, (V[]){v_c_2419, v_f_240, heff_dup(v_color_241), v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2eprintFails_24s909_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprintFails_24s909(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2eprintFails_24s909_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(self);
  heff_drop(v_hd_243);
  return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2ecommands_2eprintFails_24s909_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_str_2412 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2415 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2412, ((V)&g_heff_2ecommands_2eprintFails_24s909_str1)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get(v_hd_2413, LBL_bind), 2, (V[]){v_t_2418, v_k2_2414});
}
V g_heff_2ecommands_2eprintFails_24s909_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_f_240 = heff_dup(heff_env(self)[0]);
  V v_color_241 = heff_dup(heff_env(self)[1]);
  V v_rest_246 = heff_dup(heff_env(self)[2]);
  V v_hd_2420 = heff_dup(heff_env(self)[3]);
  V v_k_2421 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_2422);
  V v_t_2423 = ({ V a_0 = v_f_240; V a_1 = v_color_241; V a_2 = v_rest_246; V r_ = (g_heff_2ecommands_2eprintFails_24s909(a_0, a_1, a_2)); heff_drop(v_color_241); r_; });
  return heff_tail(v_t_2423, 2, (V[]){v_hd_2420, v_k_2421});
}
V g_heff_2ecommands_2eprintFails_24s909_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_dup(heff_env(self)[0]);
  V v_f_240 = heff_dup(heff_env(self)[1]);
  V v_color_241 = heff_dup(heff_env(self)[2]);
  V v_rest_246 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_hd_2420), heff_clo(g_heff_2ecommands_2eprintFails_24s909_lam3, 1, 5, (V[]){v_f_240, v_color_241, v_rest_246, v_hd_2420, v_k_2421})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintOutcomes_24s910_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintOutcomes_24s910_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintOutcomes_24s910_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintOutcomes_24s910_lam0(V self, V *args); static Clo g_heff_2ecommands_2eprintOutcomes_24s910_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintOutcomes_24s910_lam0, 2, 0};
V g_heff_2ecommands_2eprintOutcomes_24s910_lam1(V self, V *args);
V g_heff_2ecommands_2eprintOutcomes_24s910_lam4(V self, V *args); static Clo g_heff_2ecommands_2eprintOutcomes_24s910_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintOutcomes_24s910_lam4, 2, 0};
V g_heff_2ecommands_2eprintOutcomes_24s910_lam5(V self, V *args);
V g_heff_2ecommands_2eprintOutcomes_24s910_lam6(V self, V *args);
V g_heff_2ecommands_2eprintOutcomes_24s910_lam3(V self, V *args);
V g_heff_2ecommands_2eprintOutcomes_24s910_lam2(V self, V *args);
Clo g_heff_2ecommands_2eprintOutcomes_24s910_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintOutcomes_24s910_entry, 2, 0};

V g_heff_2ecommands_2eprintOutcomes_24s910(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return ((V)&g_heff_2ecommands_2eprintOutcomes_24s910_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take(v_x2_241, 3ULL);
    V v_str_246 = (g_heff_2ecommands_2eoutcomeLine(heff_dup(v_o_244)));
    V v_c_2413 = heff_clo(g_heff_2ecommands_2eprintOutcomes_24s910_lam1, 2, 1, (V[]){v_str_246});
    return heff_clo(g_heff_2ecommands_2eprintOutcomes_24s910_lam2, 2, 4, (V[]){v_c_2413, v_o_244, heff_dup(v_color_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eprintOutcomes_24s910_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprintOutcomes_24s910(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eprintOutcomes_24s910_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(self);
  heff_drop(v_hd_242);
  return heff_tail(v_k_243, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2ecommands_2eprintOutcomes_24s910_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_str_246 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_249 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_246, ((V)&g_heff_2ecommands_2eprintOutcomes_24s910_str0)), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2412, v_k2_248});
}
V g_heff_2ecommands_2eprintOutcomes_24s910_lam4(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  heff_drop(self);
  heff_drop(v_hd_2418);
  return heff_tail(v_k_2419, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2ecommands_2eprintOutcomes_24s910_lam5(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k2_2429 = args[1];
  V v_str_2427 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2430 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2427, ((V)&g_heff_2ecommands_2eprintOutcomes_24s910_str2)), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2428), LBL_malg), 1, (V[]){v_t_2432}));
  return heff_tail(heff_get(v_hd_2428, LBL_bind), 2, (V[]){v_t_2433, v_k2_2429});
}
V g_heff_2ecommands_2eprintOutcomes_24s910_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_color_240 = heff_dup(heff_env(self)[0]);
  V v_rest_245 = heff_dup(heff_env(self)[1]);
  V v_hd_2414 = heff_dup(heff_env(self)[2]);
  V v_k_2415 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_x_2435);
  V v_t_2436 = ({ V a_0 = v_color_240; V a_1 = v_rest_245; V r_ = (g_heff_2ecommands_2eprintOutcomes_24s910(a_0, a_1)); heff_drop(v_color_240); r_; });
  return heff_tail(v_t_2436, 2, (V[]){v_hd_2414, v_k_2415});
}
V g_heff_2ecommands_2eprintOutcomes_24s910_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_o_244 = heff_dup(heff_env(self)[0]);
  V v_color_240 = heff_dup(heff_env(self)[1]);
  V v_hd_2414 = heff_dup(heff_env(self)[2]);
  V v_rest_245 = heff_dup(heff_env(self)[3]);
  V v_k_2415 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_get(heff_dup(v_o_244), LBL_ok);
  V v_c_2434;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    heff_drop(v_o_244);
    heff_drop(v_t_2417);
    v_c_2434 = ((V)&g_heff_2ecommands_2eprintOutcomes_24s910_lam4_clo);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2417);
    V v_t_2420 = (g_prelude_2emap_24s825(heff_get(heff_dup(v_o_244), LBL_notes)));
    V v_t_2421 = heff_get(v_o_244, LBL_failure);
    V v_t_2423;
    switch (heff_tag_of(v_t_2421)) {
    case TAG_Nothing: {
      heff_drop(v_t_2421);
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_f_2422 = heff_field(v_t_2421, 0);
      heff_take(v_t_2421, 1ULL);
      v_t_2423 = (g_heff_2ecommands_2efailLines(v_color_240, v_f_2422));
      break;
    }
    default: heff_nomatch(v_t_2421);
    }
    V v_x2_2424 = (g_prelude_2econcatList(v_t_2420, v_t_2423));
    V v_str_2427;
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nil: {
      heff_drop(v_x2_2424);
      v_str_2427 = ((V)&g_heff_2ecommands_2eprintOutcomes_24s910_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_xs_2426 = heff_field(v_x2_2424, 1);
      heff_take(v_x2_2424, 3ULL);
      v_str_2427 = ({ V a_0 = v_x_2425; V a_1 = v_xs_2426; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2426); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2424);
    }
    v_c_2434 = heff_clo(g_heff_2ecommands_2eprintOutcomes_24s910_lam5, 2, 1, (V[]){v_str_2427});
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  return heff_tail(v_c_2434, 2, (V[]){heff_dup(v_hd_2414), heff_clo(g_heff_2ecommands_2eprintOutcomes_24s910_lam6, 1, 4, (V[]){v_color_240, v_rest_245, v_hd_2414, v_k_2415})});
}
V g_heff_2ecommands_2eprintOutcomes_24s910_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_dup(heff_env(self)[0]);
  V v_o_244 = heff_dup(heff_env(self)[1]);
  V v_color_240 = heff_dup(heff_env(self)[2]);
  V v_rest_245 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_hd_2414), heff_clo(g_heff_2ecommands_2eprintOutcomes_24s910_lam3, 1, 5, (V[]){v_o_244, v_color_240, v_hd_2414, v_rest_245, v_k_2415})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintLines_24s928_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintLines_24s928_lam0(V self, V *args);
Clo g_heff_2ecommands_2eprintLines_24s928_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintLines_24s928_entry, 3, 0};

V g_heff_2ecommands_2eprintLines_24s928(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_245 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_243, ((V)&g_heff_2ecommands_2eprintLines_24s928_str0)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_247}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2eprintLines_24s928_lam0, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprintLines_24s928_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eprintLines_24s928(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eprintLines_24s928_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_rest_244 = heff_dup(heff_env(self)[0]);
  V v_p_241 = heff_dup(heff_env(self)[1]);
  V v_p_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_x_249);
  return (g_heff_2ecommands_2eprintLines_24s928(v_rest_244, v_p_241, v_p_242));
}
V g_heff_2ecommands_2eprintDefs_24s1000_lam0(V self, V *args); static Clo g_heff_2ecommands_2eprintDefs_24s1000_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintDefs_24s1000_lam0, 2, 0};
V g_heff_2ecommands_2eprintDefs_24s1000_lam2(V self, V *args);
V g_heff_2ecommands_2eprintDefs_24s1000_lam1(V self, V *args);
Clo g_heff_2ecommands_2eprintDefs_24s1000_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintDefs_24s1000_entry, 2, 0};

V g_heff_2ecommands_2eprintDefs_24s1000(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    return ((V)&g_heff_2ecommands_2eprintDefs_24s1000_lam0_clo);
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2edriver_2edumpLines(heff_dup(v_c_240), heff_dup(v_k_244)));
    V v_c_247 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintLines_24s928_clo), 1, (V[]){v_t_246}));
    return heff_clo(g_heff_2ecommands_2eprintDefs_24s1000_lam1, 2, 3, (V[]){v_c_247, v_c_240, heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eprintDefs_24s1000_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprintDefs_24s1000(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2eprintDefs_24s1000_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(self);
  heff_drop(v_hd_242);
  return heff_tail(v_k_243, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2ecommands_2eprintDefs_24s1000_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_240 = heff_dup(heff_env(self)[0]);
  V v_rest_245 = heff_dup(heff_env(self)[1]);
  V v_hd_248 = heff_dup(heff_env(self)[2]);
  V v_k_249 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_x_2410);
  V v_t_2411 = ({ V a_0 = v_c_240; V a_1 = v_rest_245; V r_ = (g_heff_2ecommands_2eprintDefs_24s1000(a_0, a_1)); heff_drop(v_rest_245); r_; });
  return heff_tail(v_t_2411, 2, (V[]){v_hd_248, v_k_249});
}
V g_heff_2ecommands_2eprintDefs_24s1000_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_dup(heff_env(self)[0]);
  V v_c_240 = heff_dup(heff_env(self)[1]);
  V v_rest_245 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_248), heff_clo(g_heff_2ecommands_2eprintDefs_24s1000_lam2, 1, 4, (V[]){v_c_240, v_rest_245, v_hd_248, v_k_249})});
}
V g_heff_2ecommands_2eprintAll_24s999_lam0(V self, V *args);
V g_heff_2ecommands_2eprintAll_24s999_lam3(V self, V *args);
V g_heff_2ecommands_2eprintAll_24s999_lam2(V self, V *args);
V g_heff_2ecommands_2eprintAll_24s999_lam1(V self, V *args);
Clo g_heff_2ecommands_2eprintAll_24s999_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintAll_24s999_entry, 2, 0};

V g_heff_2ecommands_2eprintAll_24s999(V v_x1_240, V v_bad_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_clo(g_heff_2ecommands_2eprintAll_24s999_lam0, 2, 1, (V[]){v_bad_241});
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_t_246 = (g_prelude_2emap_24s508(heff_get(heff_dup(v_c_244), LBL_own)));
    V v_c_247 = ({ V a_0 = heff_dup(v_c_244); V a_1 = v_t_246; V r_ = (g_heff_2ecommands_2eprintDefs_24s1000(a_0, a_1)); heff_drop(v_t_246); r_; });
    return heff_clo(g_heff_2ecommands_2eprintAll_24s999_lam1, 2, 4, (V[]){v_c_247, heff_dup(v_c_244), heff_dup(v_rest_245), v_bad_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprintAll_24s999_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprintAll_24s999(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eprintAll_24s999_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_bad_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_242);
  return heff_tail(v_k_243, 1, (V[]){v_bad_241});
}
V g_heff_2ecommands_2eprintAll_24s999_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_rest_245 = heff_dup(heff_env(self)[0]);
  V v_bad_241 = heff_dup(heff_env(self)[1]);
  V v_hd_248 = heff_dup(heff_env(self)[2]);
  V v_k_249 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2414 = ({ V a_0 = v_rest_245; V a_1 = heff_intAdd(v_bad_241, v_x_2413); V r_ = (g_heff_2ecommands_2eprintAll_24s999(a_0, a_1)); heff_drop(v_rest_245); r_; });
  return heff_tail(v_t_2414, 2, (V[]){v_hd_248, v_k_249});
}
V g_heff_2ecommands_2eprintAll_24s999_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_244 = heff_dup(heff_env(self)[0]);
  V v_hd_248 = heff_dup(heff_env(self)[1]);
  V v_rest_245 = heff_dup(heff_env(self)[2]);
  V v_bad_241 = heff_dup(heff_env(self)[3]);
  V v_k_249 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_2410);
  V v_t_2411 = (g_prelude_2emap_24s509(heff_get(heff_dup(v_c_244), LBL_diags)));
  V v_c_2412 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintErrs_24s887_clo), 3, (V[]){heff_get(v_c_244, LBL_module), v_t_2411, MK_INT(0LL)}));
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_248), heff_clo(g_heff_2ecommands_2eprintAll_24s999_lam3, 1, 4, (V[]){v_rest_245, v_bad_241, v_hd_248, v_k_249})});
}
V g_heff_2ecommands_2eprintAll_24s999_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_dup(heff_env(self)[0]);
  V v_c_244 = heff_dup(heff_env(self)[1]);
  V v_rest_245 = heff_dup(heff_env(self)[2]);
  V v_bad_241 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_248), heff_clo(g_heff_2ecommands_2eprintAll_24s999_lam2, 1, 5, (V[]){v_c_244, v_hd_248, v_rest_245, v_bad_241, v_k_249})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eprintEvals_24s1003_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2eprintEvals_24s1003_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2eprintEvals_24s1003_lam0(V self, V *args);
Clo g_heff_2ecommands_2eprintEvals_24s1003_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprintEvals_24s1003_entry, 3, 0};

V g_heff_2ecommands_2eprintEvals_24s1003(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_245 = heff_strAppend(heff_get(heff_dup(v_d_243), LBL_name), heff_strAppend(((V)&g_heff_2ecommands_2eprintEvals_24s1003_str0), heff_get(v_d_243, LBL_value)));
    V v_t_246 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ecommands_2eprintEvals_24s1003_str1)), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_248}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2eprintEvals_24s1003_lam0, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2eprintEvals_24s1003_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eprintEvals_24s1003(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eprintEvals_24s1003_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_rest_244 = heff_dup(heff_env(self)[0]);
  V v_p_241 = heff_dup(heff_env(self)[1]);
  V v_p_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_x_2410);
  return (g_heff_2ecommands_2eprintEvals_24s1003(v_rest_244, v_p_241, v_p_242));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2estyleNow_24s864_24s1010_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 105, 110, 51, 50}};
V g_heff_2ecommands_2estyleNow_24s864_24s1010_lam0(V self, V *args); static Clo g_heff_2ecommands_2estyleNow_24s864_24s1010_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2estyleNow_24s864_24s1010_lam0, 1, 0};
V g_heff_2ecommands_2estyleNow_24s864_24s1010_lam1(V self, V *args);
Clo g_heff_2ecommands_2estyleNow_24s864_24s1010_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2estyleNow_24s864_24s1010_entry, 2, 0};

V g_heff_2ecommands_2estyleNow_24s864_24s1010(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Platform, 1, (V[]){((V)&g_heff_2ecommands_2estyleNow_24s864_24s1010_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2ecommands_2estyleNow_24s864_24s1010_lam1, 1, 1, (V[]){v_k_241})});
}
V g_heff_2ecommands_2estyleNow_24s864_24s1010_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2estyleNow_24s864_24s1010(a[0], a[1]);
}
V g_heff_2ecommands_2estyleNow_24s864_24s1010_lam0(V self, V *args) {
  V v_s_242 = args[0];
  heff_drop(self);
  return v_s_242;
}
V g_heff_2ecommands_2estyleNow_24s864_24s1010_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_247 = heff_strEq(v_x_246, ((V)&g_heff_2ecommands_2estyleNow_24s864_24s1010_str0));
  V v_x_248;
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_t_247);
    v_x_248 = NTAG(TAG_Windows);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_247);
    v_x_248 = NTAG(TAG_Posix);
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  return heff_tail(v_k_241, 1, (V[]){v_x_248});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2elibDir_24s863_24s1009_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {72, 69, 70, 70, 95, 76, 73, 66}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2elibDir_24s863_24s1009_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 105, 98}};
V g_heff_2ecommands_2elibDir_24s863_24s1009_lam0(V self, V *args); static Clo g_heff_2ecommands_2elibDir_24s863_24s1009_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2elibDir_24s863_24s1009_lam0, 1, 0};
V g_heff_2ecommands_2elibDir_24s863_24s1009_lam3(V self, V *args); static Clo g_heff_2ecommands_2elibDir_24s863_24s1009_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2elibDir_24s863_24s1009_lam3, 1, 0};
V g_heff_2ecommands_2elibDir_24s863_24s1009_lam4(V self, V *args);
V g_heff_2ecommands_2elibDir_24s863_24s1009_lam2(V self, V *args);
V g_heff_2ecommands_2elibDir_24s863_24s1009_lam1(V self, V *args);
Clo g_heff_2ecommands_2elibDir_24s863_24s1009_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2elibDir_24s863_24s1009_entry, 2, 0};

V g_heff_2ecommands_2elibDir_24s863_24s1009(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2elibDir_24s863_24s1009_str0), ((V)&g_heff_2ecommands_2elibDir_24s863_24s1009_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2ecommands_2elibDir_24s863_24s1009_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2elibDir_24s863_24s1009_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2elibDir_24s863_24s1009(a[0], a[1]);
}
V g_heff_2ecommands_2elibDir_24s863_24s1009_lam0(V self, V *args) {
  V v_v_242 = args[0];
  heff_drop(self);
  return v_v_242;
}
V g_heff_2ecommands_2elibDir_24s863_24s1009_lam3(V self, V *args) {
  V v_s_248 = args[0];
  heff_drop(self);
  return v_s_248;
}
V g_heff_2ecommands_2elibDir_24s863_24s1009_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_247 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_p_2413 = (g_std_2epath_2eparse(v_x_247, v_x_2412));
  V v_t_2414 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2413), LBL_segments)));
  V v_xs_2415 = (g_prelude_2edrop(MK_INT(1LL), v_t_2414));
  V v_t_2416 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2415));
  V v_t_2417 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2413), LBL_drive), heff_get(v_p_2413, LBL_absolute), v_t_2416});
  V v_s_2418 = (g_std_2epath_2erender(v_x_247, v_t_2417));
  V v_p_2419 = (g_std_2epath_2eparse(v_x_247, v_s_2418));
  V v_t_2420 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2419), LBL_segments)));
  V v_xs_2421 = (g_prelude_2edrop(MK_INT(1LL), v_t_2420));
  V v_t_2422 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2421));
  V v_t_2423 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2419), LBL_drive), heff_get(v_p_2419, LBL_absolute), v_t_2422});
  V v_a_2424 = (g_std_2epath_2erender(v_x_247, v_t_2423));
  V v_t_2425 = (g_std_2epath_2eparse(v_x_247, v_a_2424));
  V v_t_2426 = (g_std_2epath_2eparse(v_x_247, ((V)&g_heff_2ecommands_2elibDir_24s863_24s1009_str1)));
  V v_p_2427 = (g_std_2epath_2ejoin_2eonto_240(v_t_2425, v_t_2426));
  V v_t_2428 = ({ V a_0 = heff_get(heff_dup(v_p_2427), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2427), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2429 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2427), LBL_drive), heff_get(v_p_2427, LBL_absolute), v_t_2428});
  V v_x_2430 = ({ V a_0 = v_x_247; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_247); r_; });
  return heff_tail(v_k_241, 1, (V[]){v_x_2430});
}
V g_heff_2ecommands_2elibDir_24s863_24s1009_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ecommands_2elibDir_24s863_24s1009_lam3_clo)})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2411, heff_clo(g_heff_2ecommands_2elibDir_24s863_24s1009_lam4, 1, 2, (V[]){v_x_247, v_k_241})});
}
V g_heff_2ecommands_2elibDir_24s863_24s1009_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop(v_x_246);
    return (g_heff_2ecommands_2estyleNow_24s864_24s1010(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2elibDir_24s863_24s1009_lam2, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    V v_lib_2431 = heff_field(v_x_246, 0);
    heff_take(v_x_246, 1ULL);
    heff_drop(v_hd_240);
    return heff_tail(v_k_241, 1, (V[]){v_lib_2431});
  }
  default: return heff_nomatch(v_x_246);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2emodDir_24s865_24s1011_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {72, 69, 70, 70, 95, 77, 79, 68, 67, 65, 67, 72, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2emodDir_24s865_24s1011_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {72, 79, 77, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2emodDir_24s865_24s1011_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {85, 83, 69, 82, 80, 82, 79, 70, 73, 76, 69}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2emodDir_24s865_24s1011_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2emodDir_24s865_24s1011_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {46, 99, 97, 99, 104, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2emodDir_24s865_24s1011_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2emodDir_24s865_24s1011_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {109, 111, 100}};
V g_heff_2ecommands_2emodDir_24s865_24s1011_lam0(V self, V *args); static Clo g_heff_2ecommands_2emodDir_24s865_24s1011_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emodDir_24s865_24s1011_lam0, 1, 0};
V g_heff_2ecommands_2emodDir_24s865_24s1011_lam2(V self, V *args); static Clo g_heff_2ecommands_2emodDir_24s865_24s1011_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emodDir_24s865_24s1011_lam2, 1, 0};
V g_heff_2ecommands_2emodDir_24s865_24s1011_lam4(V self, V *args); static Clo g_heff_2ecommands_2emodDir_24s865_24s1011_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emodDir_24s865_24s1011_lam4, 1, 0};
V g_heff_2ecommands_2emodDir_24s865_24s1011_lam6(V self, V *args);
V g_heff_2ecommands_2emodDir_24s865_24s1011_lam5(V self, V *args);
V g_heff_2ecommands_2emodDir_24s865_24s1011_lam3(V self, V *args);
V g_heff_2ecommands_2emodDir_24s865_24s1011_lam1(V self, V *args);
Clo g_heff_2ecommands_2emodDir_24s865_24s1011_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2emodDir_24s865_24s1011_entry, 2, 0};

V g_heff_2ecommands_2emodDir_24s865_24s1011(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2emodDir_24s865_24s1011_str0), ((V)&g_heff_2ecommands_2emodDir_24s865_24s1011_lam0_clo)})});
  V v_t_244 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_245, heff_clo(g_heff_2ecommands_2emodDir_24s865_24s1011_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2emodDir_24s865_24s1011_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2emodDir_24s865_24s1011(a[0], a[1]);
}
V g_heff_2ecommands_2emodDir_24s865_24s1011_lam0(V self, V *args) {
  V v_v_242 = args[0];
  heff_drop(self);
  return v_v_242;
}
V g_heff_2ecommands_2emodDir_24s865_24s1011_lam2(V self, V *args) {
  V v_v_247 = args[0];
  heff_drop(self);
  return v_v_247;
}
V g_heff_2ecommands_2emodDir_24s865_24s1011_lam4(V self, V *args) {
  V v_v_2412 = args[0];
  heff_drop(self);
  return v_v_2412;
}
V g_heff_2ecommands_2emodDir_24s865_24s1011_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_246 = heff_dup(heff_env(self)[0]);
  V v_x_2416 = heff_dup(heff_env(self)[1]);
  V v_x_2411 = heff_dup(heff_env(self)[2]);
  V v_k_241 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_x_2440;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop(v_x_246);
    V v_d_2419;
    switch (heff_tag_of(v_x_2416)) {
    case TAG_Nothing: {
      heff_drop(v_x_2416);
      v_d_2419 = ((V)&g_heff_2ecommands_2emodDir_24s865_24s1011_str3);
      break;
    }
    case TAG_Just: {
      V v_x_2418 = heff_field(v_x_2416, 0);
      heff_take(v_x_2416, 1ULL);
      v_d_2419 = v_x_2418;
      break;
    }
    default: heff_nomatch(v_x_2416);
    }
    V v_a_2421;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Nothing: {
      heff_drop(v_x_2411);
      v_a_2421 = v_d_2419;
      break;
    }
    case TAG_Just: {
      V v_x_2420 = heff_field(v_x_2411, 0);
      heff_take(v_x_2411, 1ULL);
      heff_drop(v_d_2419);
      v_a_2421 = v_x_2420;
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_t_2422 = (g_std_2epath_2eparse(v_x_2417, v_a_2421));
    V v_t_2423 = (g_std_2epath_2eparse(v_x_2417, ((V)&g_heff_2ecommands_2emodDir_24s865_24s1011_str4)));
    V v_p_2424 = (g_std_2epath_2ejoin_2eonto_240(v_t_2422, v_t_2423));
    V v_t_2425 = ({ V a_0 = heff_get(heff_dup(v_p_2424), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2424), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2426 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2424), LBL_drive), heff_get(v_p_2424, LBL_absolute), v_t_2425});
    V v_a_2427 = (g_std_2epath_2erender(v_x_2417, v_t_2426));
    V v_t_2428 = (g_std_2epath_2eparse(v_x_2417, ((V)&g_heff_2ecommands_2emodDir_24s865_24s1011_str5)));
    V v_t_2429 = (g_std_2epath_2eparse(v_x_2417, ((V)&g_heff_2ecommands_2emodDir_24s865_24s1011_str6)));
    V v_p_2430 = (g_std_2epath_2ejoin_2eonto_240(v_t_2428, v_t_2429));
    V v_t_2431 = ({ V a_0 = heff_get(heff_dup(v_p_2430), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2430), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2432 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2430), LBL_drive), heff_get(v_p_2430, LBL_absolute), v_t_2431});
    V v_b_2433 = (g_std_2epath_2erender(v_x_2417, v_t_2432));
    V v_t_2434 = (g_std_2epath_2eparse(v_x_2417, v_a_2427));
    V v_t_2435 = (g_std_2epath_2eparse(v_x_2417, v_b_2433));
    V v_p_2436 = (g_std_2epath_2ejoin_2eonto_240(v_t_2434, v_t_2435));
    V v_t_2437 = ({ V a_0 = heff_get(heff_dup(v_p_2436), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2436), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2438 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2436), LBL_drive), heff_get(v_p_2436, LBL_absolute), v_t_2437});
    v_x_2440 = ({ V a_0 = v_x_2417; V a_1 = v_t_2438; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2417); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2439 = heff_field(v_x_246, 0);
    heff_take(v_x_246, 1ULL);
    heff_drop(v_x_2417);
    heff_drop(v_x_2416);
    heff_drop(v_x_2411);
    v_x_2440 = v_d_2439;
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  return heff_tail(v_k_241, 1, (V[]){v_x_2440});
}
V g_heff_2ecommands_2emodDir_24s865_24s1011_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_x_246 = heff_dup(heff_env(self)[1]);
  V v_x_2411 = heff_dup(heff_env(self)[2]);
  V v_k_241 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return (g_heff_2ecommands_2estyleNow_24s864_24s1010(v_hd_240, heff_clo(g_heff_2ecommands_2emodDir_24s865_24s1011_lam6, 1, 4, (V[]){v_x_246, v_x_2416, v_x_2411, v_k_241})));
}
V g_heff_2ecommands_2emodDir_24s865_24s1011_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_x_246 = heff_dup(heff_env(self)[1]);
  V v_k_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2413 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2emodDir_24s865_24s1011_str2), ((V)&g_heff_2ecommands_2emodDir_24s865_24s1011_lam4_clo)})});
  V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2415, heff_clo(g_heff_2ecommands_2emodDir_24s865_24s1011_lam5, 1, 4, (V[]){v_hd_240, v_x_246, v_x_2411, v_k_241})});
}
V g_heff_2ecommands_2emodDir_24s865_24s1011_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2emodDir_24s865_24s1011_str1), ((V)&g_heff_2ecommands_2emodDir_24s865_24s1011_lam2_clo)})});
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2ecommands_2emodDir_24s865_24s1011_lam3, 1, 3, (V[]){v_hd_240, v_x_246, v_k_241})});
}
V g_heff_2ecommands_2ehostNow_24s862_24s1008_lam2(V self, V *args);
V g_heff_2ecommands_2ehostNow_24s862_24s1008_lam1(V self, V *args);
V g_heff_2ecommands_2ehostNow_24s862_24s1008_lam0(V self, V *args);
Clo g_heff_2ecommands_2ehostNow_24s862_24s1008_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ehostNow_24s862_24s1008_entry, 2, 0};

V g_heff_2ecommands_2ehostNow_24s862_24s1008(V v_hd_240, V v_k_241) {
top: ;
  return (g_heff_2ecommands_2elibDir_24s863_24s1009(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ehostNow_24s862_24s1008_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ecommands_2ehostNow_24s862_24s1008_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ehostNow_24s862_24s1008(a[0], a[1]);
}
V g_heff_2ecommands_2ehostNow_24s862_24s1008_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_241 = heff_dup(heff_env(self)[0]);
  V v_x_242 = heff_dup(heff_env(self)[1]);
  V v_x_243 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_k_241, 1, (V[]){heff_rec(3, shape_166_183_312, (V[]){v_x_242, v_x_243, v_x_244})});
}
V g_heff_2ecommands_2ehostNow_24s862_24s1008_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  V v_x_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return (g_heff_2ecommands_2estyleNow_24s864_24s1010(v_hd_240, heff_clo(g_heff_2ecommands_2ehostNow_24s862_24s1008_lam2, 1, 3, (V[]){v_k_241, v_x_242, v_x_243})));
}
V g_heff_2ecommands_2ehostNow_24s862_24s1008_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return (g_heff_2ecommands_2emodDir_24s865_24s1011(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ehostNow_24s862_24s1008_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
}
V g_heff_2ecommands_2echeckLast_24s893_24s1013_lam2(V self, V *args);
V g_heff_2ecommands_2echeckLast_24s893_24s1013_lam3(V self, V *args);
V g_heff_2ecommands_2echeckLast_24s893_24s1013_lam1(V self, V *args);
V g_heff_2ecommands_2echeckLast_24s893_24s1013_lam0(V self, V *args);
Clo g_heff_2ecommands_2echeckLast_24s893_24s1013_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2echeckLast_24s893_24s1013_entry, 2, 0};

V g_heff_2ecommands_2echeckLast_24s893_24s1013(V v_badLoad_240, V v_cs_241) {
top: ;
  V v_c_242 = (g_heff_2ecommands_2eputFileDiags_24s894(heff_dup(v_cs_241)));
  return heff_clo(g_heff_2ecommands_2echeckLast_24s893_24s1013_lam0, 2, 3, (V[]){v_c_242, v_cs_241, heff_dup(v_badLoad_240)});
}
V g_heff_2ecommands_2echeckLast_24s893_24s1013_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2echeckLast_24s893_24s1013(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2echeckLast_24s893_24s1013_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_str_2412 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2415 = heff_tag(TAG_Write, 2, (V[]){v_str_2412, NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get(v_hd_2413, LBL_bind), 2, (V[]){v_t_2418, v_k2_2414});
}
V g_heff_2ecommands_2echeckLast_24s893_24s1013_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_badLoad_240 = heff_dup(heff_env(self)[0]);
  V v_hd_243 = heff_dup(heff_env(self)[1]);
  V v_k_244 = heff_dup(heff_env(self)[2]);
  V v_cs_241 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_x_2420);
  switch (heff_tag_of(v_badLoad_240)) {
  case TAG_True: {
    heff_drop(v_badLoad_240);
    heff_drop(v_cs_241);
    V v_t_2421 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2423}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2424, v_k_244});
  }
  case TAG_False: {
    heff_drop(v_badLoad_240);
    V v_t_2425 = ({ V a_0 = v_cs_241; V r_ = (g_prelude_2eany_24s820(a_0)); heff_drop(v_cs_241); r_; });
    switch (heff_tag_of(v_t_2425)) {
    case TAG_True: {
      heff_drop(v_t_2425);
      V v_t_2426 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2428}));
      return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2429, v_k_244});
    }
    case TAG_False: {
      heff_drop(v_hd_243);
      heff_drop(v_t_2425);
      return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  default: return heff_nomatch(v_badLoad_240);
  }
}
V g_heff_2ecommands_2echeckLast_24s893_24s1013_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_hd_243 = heff_dup(heff_env(self)[1]);
  V v_k_244 = heff_dup(heff_env(self)[2]);
  V v_badLoad_240 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_x_245);
  V v_t_246 = (g_heff_2edriver_2elastChecked(v_cs_241));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_cs_241);
    heff_drop(v_badLoad_240);
    heff_drop(v_t_246);
    V v_t_247 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2410, v_k_244});
  }
  case TAG_Just: {
    V v_c_2411 = heff_field(v_t_246, 0);
    heff_take(v_t_246, 1ULL);
    V v_str_2412 = (g_heff_2edriver_2einterface(v_c_2411));
    V v_c_2419 = heff_clo(g_heff_2ecommands_2echeckLast_24s893_24s1013_lam2, 2, 1, (V[]){v_str_2412});
    return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2echeckLast_24s893_24s1013_lam3, 1, 4, (V[]){v_badLoad_240, v_hd_243, v_k_244, v_cs_241})});
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ecommands_2echeckLast_24s893_24s1013_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_dup(heff_env(self)[0]);
  V v_cs_241 = heff_dup(heff_env(self)[1]);
  V v_badLoad_240 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_242, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2echeckLast_24s893_24s1013_lam1, 1, 4, (V[]){v_cs_241, v_hd_243, v_k_244, v_badLoad_240})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetFails_24s938_24s1045_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 32, 103, 101, 116, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetFails_24s938_24s1045_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2egetFails_24s938_24s1045_lam0(V self, V *args);
Clo g_heff_2ecommands_2egetFails_24s938_24s1045_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetFails_24s938_24s1045_entry, 3, 0};

V g_heff_2ecommands_2egetFails_24s938_24s1045(V v_why_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2egetFails_24s938_24s1045_str0), v_why_240), ((V)&g_heff_2ecommands_2egetFails_24s938_24s1045_str1));
  V v_t_244 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_243, NTAG(TAG_MkUnit)});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2egetFails_24s938_24s1045_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2egetFails_24s938_24s1045_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2egetFails_24s938_24s1045(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2egetFails_24s938_24s1045_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_248);
  V v_t_249 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2412, v_k_242});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {45, 45, 116, 97, 103, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {45, 45, 114, 101, 102, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {108, 115, 45, 114, 101, 109, 111, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str6 = {{0x80000000u, K_STR, 0}, 24, 24, {99, 97, 110, 110, 111, 116, 32, 108, 105, 115, 116, 32, 116, 104, 101, 32, 116, 97, 103, 115, 32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str9 = {{0x80000000u, K_STR, 0}, 11, 11, {114, 101, 102, 115, 47, 116, 97, 103, 115, 47, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str10 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str14 = {{0x80000000u, K_STR, 0}, 9, 9, {116, 104, 97, 116, 32, 111, 102, 32, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str15 = {{0x80000000u, K_STR, 0}, 6, 6, {48, 32, 111, 114, 32, 49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str16 = {{0x80000000u, K_STR, 0}, 6, 6, {48, 32, 111, 114, 32, 49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str17 = {{0x80000000u, K_STR, 0}, 6, 6, {48, 32, 111, 114, 32, 49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str18 = {{0x80000000u, K_STR, 0}, 10, 10, {110, 111, 32, 116, 97, 103, 32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str19 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 105, 115, 32, 97, 32, 118, 101, 114, 115, 105, 111, 110, 32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str20 = {{0x80000000u, K_STR, 0}, 20, 20, {32, 40, 118, 65, 46, 66, 46, 67, 44, 32, 105, 116, 115, 32, 109, 97, 106, 111, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enewestTag_24s943_24s1049_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
V g_heff_2ecommands_2enewestTag_24s943_24s1049_lam1(V self, V *args); static Clo g_heff_2ecommands_2enewestTag_24s943_24s1049_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enewestTag_24s943_24s1049_lam1, 1, 0};
V g_heff_2ecommands_2enewestTag_24s943_24s1049_lam0(V self, V *args);
V g_heff_2ecommands_2enewestTag_24s943_24s1049_lam4(V self, V *args);
V g_heff_2ecommands_2enewestTag_24s943_24s1049_lam3(V self, V *args);
V g_heff_2ecommands_2enewestTag_24s943_24s1049_lam2(V self, V *args);
Clo g_heff_2ecommands_2enewestTag_24s943_24s1049_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enewestTag_24s943_24s1049_entry, 1, 0};

V g_heff_2ecommands_2enewestTag_24s943_24s1049(V v_path_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str0), (g_heff_2eproject_2erepoOf(heff_dup(v_path_240))));
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){v_t_241, NTAG(TAG_Nil)});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str2), v_t_242})});
  V v_as_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str3), v_t_243});
  V v_c_2411 = heff_clo(g_heff_2ecommands_2enewestTag_24s943_24s1049_lam0, 2, 1, (V[]){v_as_244});
  return heff_clo(g_heff_2ecommands_2enewestTag_24s943_24s1049_lam2, 2, 2, (V[]){v_c_2411, v_path_240});
}
V g_heff_2ecommands_2enewestTag_24s943_24s1049_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2enewestTag_24s943_24s1049(a[0]);
}
V g_heff_2ecommands_2enewestTag_24s943_24s1049_lam1(V self, V *args) {
  V v_r_247 = args[0];
  heff_drop(self);
  return v_r_247;
}
V g_heff_2ecommands_2enewestTag_24s943_24s1049_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k2_246 = args[1];
  V v_as_244 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_248 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str4), v_as_244, ((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_lam1_clo)})});
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})}));
  return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2410, v_k2_246});
}
V g_heff_2ecommands_2enewestTag_24s943_24s1049_lam4(V self, V *args) {
  V v_best_2425 = args[0];
  V v_line_2426 = args[1];
  V v_path_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_it_2427 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str9), v_line_2426, MK_INT(0LL), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_2427)) {
  case TAG_Nil: {
    heff_drop(v_path_240);
    heff_drop(v_it_2427);
    return v_best_2425;
  }
  case TAG_Cons: {
    V v_it2_2429 = heff_field(v_it_2427, 1);
    heff_take(v_it_2427, 2ULL);
    switch (heff_tag_of(v_it2_2429)) {
    case TAG_Nil: {
      heff_drop(v_path_240);
      heff_drop(v_it2_2429);
      return v_best_2425;
    }
    case TAG_Cons: {
      V v_v_2430 = heff_field(v_it2_2429, 0);
      V v_it22_2431 = heff_field(v_it2_2429, 1);
      heff_take(v_it2_2429, 3ULL);
      switch (heff_tag_of(v_it22_2431)) {
      case TAG_Nil: {
        heff_drop(v_it22_2431);
        V v_t_2432 = (g_prelude_2eskipSpaces(heff_dup(v_v_2430), MK_INT(0LL), MK_INT(1LL)));
        V v_t_2433 = heff_intSub(heff_strLength(heff_dup(v_v_2430)), MK_INT(1LL));
        V v_t_2434 = (g_prelude_2eskipSpaces(heff_dup(v_v_2430), v_t_2433, MK_INT(-1LL)));
        V v_t_2435 = heff_strSlice(heff_dup(v_v_2430), v_t_2432, heff_intAdd(v_t_2434, MK_INT(1LL)));
        V v_t_2436 = (g_heff_2eproject_2eversion(v_t_2435));
        switch (heff_tag_of(v_t_2436)) {
        case TAG_Nothing: {
          heff_drop(v_path_240);
          heff_drop(v_v_2430);
          heff_drop(v_t_2436);
          return v_best_2425;
        }
        case TAG_Just: {
          V v_ru_24t_2436_24Just = heff_take_reuse(v_t_2436, 0ULL);
          V v_t_2438 = (g_prelude_2eskipSpaces(heff_dup(v_v_2430), MK_INT(0LL), MK_INT(1LL)));
          V v_t_2439 = heff_intSub(heff_strLength(heff_dup(v_v_2430)), MK_INT(1LL));
          V v_t_2440 = (g_prelude_2eskipSpaces(heff_dup(v_v_2430), v_t_2439, MK_INT(-1LL)));
          V v_t_2441 = heff_strSlice(heff_dup(v_v_2430), v_t_2438, heff_intAdd(v_t_2440, MK_INT(1LL)));
          V v_t_2442 = (g_heff_2eproject_2emajorMismatch(v_path_240, v_t_2441));
          switch (heff_tag_of(v_t_2442)) {
          case TAG_Nothing: {
            heff_drop(v_t_2442);
            switch (heff_tag_of(v_best_2425)) {
            case TAG_Nothing: {
              heff_drop(v_best_2425);
              V v_t_2443 = (g_prelude_2eskipSpaces(heff_dup(v_v_2430), MK_INT(0LL), MK_INT(1LL)));
              V v_t_2444 = heff_intSub(heff_strLength(heff_dup(v_v_2430)), MK_INT(1LL));
              V v_t_2445 = (g_prelude_2eskipSpaces(heff_dup(v_v_2430), v_t_2444, MK_INT(-1LL)));
              V v_t_2446 = heff_strSlice(v_v_2430, v_t_2443, heff_intAdd(v_t_2445, MK_INT(1LL)));
              return heff_tag_at(v_ru_24t_2436_24Just, TAG_Just, 1, (V[]){v_t_2446});
            }
            case TAG_Just: {
              V v_b_2447 = heff_dup(heff_field(v_best_2425, 0));
              V v_t_2448 = (g_prelude_2eskipSpaces(heff_dup(v_v_2430), MK_INT(0LL), MK_INT(1LL)));
              V v_t_2449 = heff_intSub(heff_strLength(heff_dup(v_v_2430)), MK_INT(1LL));
              V v_t_2450 = (g_prelude_2eskipSpaces(heff_dup(v_v_2430), v_t_2449, MK_INT(-1LL)));
              V v_a_2451 = heff_strSlice(heff_dup(v_v_2430), v_t_2448, heff_intAdd(v_t_2450, MK_INT(1LL)));
              V v_x2_2452 = (g_heff_2eproject_2eversion(v_a_2451));
              V v_t_2454;
              switch (heff_tag_of(v_x2_2452)) {
              case TAG_Nothing: {
                heff_drop(v_x2_2452);
                v_t_2454 = NTAG(TAG_Nil);
                break;
              }
              case TAG_Just: {
                V v_x_2453 = heff_field(v_x2_2452, 0);
                heff_take(v_x2_2452, 1ULL);
                v_t_2454 = v_x_2453;
                break;
              }
              default: heff_nomatch(v_x2_2452);
              }
              V v_x2_2455 = (g_heff_2eproject_2eversion(v_b_2447));
              V v_t_2457;
              switch (heff_tag_of(v_x2_2455)) {
              case TAG_Nothing: {
                heff_drop(v_x2_2455);
                v_t_2457 = NTAG(TAG_Nil);
                break;
              }
              case TAG_Just: {
                V v_x_2456 = heff_field(v_x2_2455, 0);
                heff_take(v_x2_2455, 1ULL);
                v_t_2457 = v_x_2456;
                break;
              }
              default: heff_nomatch(v_x2_2455);
              }
              V v_t_2458 = ({ V a_0 = v_t_2454; V a_1 = v_t_2457; V r_ = (g_heff_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_2454); heff_drop(v_t_2457); r_; });
              switch (heff_tag_of(v_t_2458)) {
              case TAG_True: {
                heff_drop(v_best_2425);
                heff_drop(v_t_2458);
                V v_t_2459 = (g_prelude_2eskipSpaces(heff_dup(v_v_2430), MK_INT(0LL), MK_INT(1LL)));
                V v_t_2460 = heff_intSub(heff_strLength(heff_dup(v_v_2430)), MK_INT(1LL));
                V v_t_2461 = (g_prelude_2eskipSpaces(heff_dup(v_v_2430), v_t_2460, MK_INT(-1LL)));
                V v_t_2462 = heff_strSlice(v_v_2430, v_t_2459, heff_intAdd(v_t_2461, MK_INT(1LL)));
                return heff_tag_at(v_ru_24t_2436_24Just, TAG_Just, 1, (V[]){v_t_2462});
              }
              case TAG_False: {
                heff_drop(v_v_2430);
                heff_drop(v_ru_24t_2436_24Just);
                heff_drop(v_t_2458);
                return v_best_2425;
              }
              default: return heff_nomatch(v_t_2458);
              }
            }
            default: return heff_nomatch(v_best_2425);
            }
          }
          case TAG_Just: {
            heff_take(v_t_2442, 0ULL);
            heff_drop(v_v_2430);
            heff_drop(v_ru_24t_2436_24Just);
            return v_best_2425;
          }
          default: return heff_nomatch(v_t_2442);
          }
        }
        default: return heff_nomatch(v_t_2436);
        }
      }
      case TAG_Cons: {
        heff_take(v_it22_2431, 0ULL);
        heff_drop(v_path_240);
        heff_drop(v_v_2430);
        return v_best_2425;
      }
      default: return heff_nomatch(v_it22_2431);
      }
    }
    default: return heff_nomatch(v_it2_2429);
    }
  }
  default: return heff_nomatch(v_it_2427);
  }
}
V g_heff_2ecommands_2enewestTag_24s943_24s1049_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_path_240 = heff_dup(heff_env(self)[0]);
  V v_k_2413 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2415 = heff_intEq(heff_get(heff_dup(v_x_2414), LBL_status), MK_INT(0LL));
  V v_t_2416;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    heff_drop(v_t_2415);
    v_t_2416 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2415);
    v_t_2416 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_x_2485;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    heff_drop(v_t_2416);
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str5), (g_heff_2eproject_2erepoOf(v_path_240)));
    V v_s_2418 = heff_get(v_x_2414, LBL_err);
    V v_t_2419 = (g_prelude_2eskipSpaces(heff_dup(v_s_2418), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2420 = heff_intSub(heff_strLength(heff_dup(v_s_2418)), MK_INT(1LL));
    V v_t_2421 = (g_prelude_2eskipSpaces(heff_dup(v_s_2418), v_t_2420, MK_INT(-1LL)));
    V v_t_2422 = heff_strSlice(v_s_2418, v_t_2419, heff_intAdd(v_t_2421, MK_INT(1LL)));
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str6), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str7), v_t_2422)));
    v_x_2485 = heff_tag(TAG_Left, 1, (V[]){v_t_2423});
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2416);
    V v_t_2424 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str8), heff_get(v_x_2414, LBL_out), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2466 = ({ V a_0 = heff_clo(g_heff_2ecommands_2enewestTag_24s943_24s1049_lam4, 2, 1, (V[]){heff_dup(v_path_240)}); V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2424; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
    switch (heff_tag_of(v_t_2466)) {
    case TAG_Nothing: {
      heff_drop(v_t_2466);
      V v_t_2467 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str10), (g_heff_2eproject_2erepoOf(heff_dup(v_path_240))));
      V v_xs_2468 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str11), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2469 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2468));
      V v_x_2472;
      switch (heff_tag_of(v_t_2469)) {
      case TAG_Nil: {
        heff_drop(v_t_2469);
        v_x_2472 = heff_dup(v_path_240);
        break;
      }
      case TAG_Cons: {
        V v_x_2470 = heff_field(v_t_2469, 0);
        heff_take(v_t_2469, 1ULL);
        v_x_2472 = v_x_2470;
        break;
      }
      default: heff_nomatch(v_t_2469);
      }
      V v_t_2473 = heff_intLe(MK_INT(2LL), heff_strLength(heff_dup(v_x_2472)));
      V v_t_2482;
      switch (heff_tag_of(v_t_2473)) {
      case TAG_True: {
        heff_drop(v_t_2473);
        V v_t_2474 = heff_strEq(heff_strSlice(heff_dup(v_x_2472), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str12));
        switch (heff_tag_of(v_t_2474)) {
        case TAG_True: {
          heff_drop(v_t_2474);
          V v_t_2475 = heff_strSlice(heff_dup(v_x_2472), MK_INT(1LL), heff_strLength(v_x_2472));
          V v_t_2476 = (g_heff_2eproject_2eisNumber(v_t_2475));
          switch (heff_tag_of(v_t_2476)) {
          case TAG_True: {
            heff_drop(v_t_2476);
            V v_xs_2477 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str13), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
            V v_t_2478 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2477));
            V v_t_2481;
            switch (heff_tag_of(v_t_2478)) {
            case TAG_Nil: {
              heff_drop(v_t_2478);
              v_t_2481 = heff_dup(v_path_240);
              break;
            }
            case TAG_Cons: {
              V v_x_2479 = heff_field(v_t_2478, 0);
              heff_take(v_t_2478, 1ULL);
              v_t_2481 = v_x_2479;
              break;
            }
            default: heff_nomatch(v_t_2478);
            }
            v_t_2482 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str14), v_t_2481);
            break;
          }
          case TAG_False: {
            heff_drop(v_t_2476);
            v_t_2482 = ((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str15);
            break;
          }
          default: heff_nomatch(v_t_2476);
          }
          break;
        }
        case TAG_False: {
          heff_drop(v_x_2472);
          heff_drop(v_t_2474);
          v_t_2482 = ((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str16);
          break;
        }
        default: heff_nomatch(v_t_2474);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_x_2472);
        heff_drop(v_t_2473);
        v_t_2482 = ((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str17);
        break;
      }
      default: heff_nomatch(v_t_2473);
      }
      V v_t_2483 = heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str18), heff_strAppend(v_t_2467, heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str19), heff_strAppend(v_path_240, heff_strAppend(((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str20), heff_strAppend(v_t_2482, ((V)&g_heff_2ecommands_2enewestTag_24s943_24s1049_str21)))))));
      v_x_2485 = heff_tag(TAG_Left, 1, (V[]){v_t_2483});
      break;
    }
    case TAG_Just: {
      V v_v_2484 = heff_field(v_t_2466, 0);
      V v_ru_24t_2466_24Just = heff_take_reuse(v_t_2466, 1ULL);
      heff_drop(v_path_240);
      v_x_2485 = heff_tag_at(v_ru_24t_2466_24Just, TAG_Right, 1, (V[]){v_v_2484});
      break;
    }
    default: heff_nomatch(v_t_2466);
    }
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  return heff_tail(v_k_2413, 1, (V[]){v_x_2485});
}
V g_heff_2ecommands_2enewestTag_24s943_24s1049_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_dup(heff_env(self)[0]);
  V v_path_240 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2411, 2, (V[]){v_hd_2412, heff_clo(g_heff_2ecommands_2enewestTag_24s943_24s1049_lam3, 1, 2, (V[]){v_path_240, v_k_2413})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2enodeDone_24s950_24s1055_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2enodeDone_24s950_24s1055_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {43, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2enodeDone_24s950_24s1055_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 104, 109, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2enodeDone_24s950_24s1055_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2enodeDone_24s950_24s1055_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {119, 114, 111, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2enodeDone_24s950_24s1055_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2enodeDone_24s950_24s1055_lam1(V self, V *args); static Clo g_heff_2ecommands_2enodeDone_24s950_24s1055_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enodeDone_24s950_24s1055_lam1, 1, 0};
V g_heff_2ecommands_2enodeDone_24s950_24s1055_lam0(V self, V *args);
V g_heff_2ecommands_2enodeDone_24s950_24s1055_lam4(V self, V *args);
V g_heff_2ecommands_2enodeDone_24s950_24s1055_lam3(V self, V *args);
V g_heff_2ecommands_2enodeDone_24s950_24s1055_lam2(V self, V *args);
Clo g_heff_2ecommands_2enodeDone_24s950_24s1055_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2enodeDone_24s950_24s1055_entry, 3, 0};

V g_heff_2ecommands_2enodeDone_24s950_24s1055(V v_st_240, V v_x_241, V v_next_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2enodeDone_24s950_24s1055_str0)));
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_241)));
  V v_p_245 = (g_std_2epath_2ejoin_2eonto_240(v_t_243, v_t_244));
  V v_t_246 = ({ V a_0 = heff_get(heff_dup(v_p_245), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_245), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_245), LBL_drive), heff_get(v_p_245, LBL_absolute), v_t_246});
  V v_t_248 = (g_std_2epath_2erender(v_st_240, v_t_247));
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_as_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2enodeDone_24s950_24s1055_str1), v_t_249});
  V v_c_2417 = heff_clo(g_heff_2ecommands_2enodeDone_24s950_24s1055_lam0, 2, 1, (V[]){v_as_2410});
  return heff_clo(g_heff_2ecommands_2enodeDone_24s950_24s1055_lam2, 2, 4, (V[]){v_c_2417, heff_dup(v_st_240), v_x_241, v_next_242});
}
V g_heff_2ecommands_2enodeDone_24s950_24s1055_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2enodeDone_24s950_24s1055(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2enodeDone_24s950_24s1055_lam1(V self, V *args) {
  V v_r_2413 = args[0];
  heff_drop(self);
  return v_r_2413;
}
V g_heff_2ecommands_2enodeDone_24s950_24s1055_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k2_2412 = args[1];
  V v_as_2410 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2414 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2enodeDone_24s950_24s1055_str2), v_as_2410, ((V)&g_heff_2ecommands_2enodeDone_24s950_24s1055_lam1_clo)})});
  V v_t_2415 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})}));
  return heff_tail(heff_get(v_hd_2411, LBL_bind), 2, (V[]){v_t_2416, v_k2_2412});
}
V g_heff_2ecommands_2enodeDone_24s950_24s1055_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_next_242 = heff_dup(heff_env(self)[0]);
  V v_hd_2418 = heff_dup(heff_env(self)[1]);
  V v_k_2419 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_x_2432);
  return heff_tail(v_next_242, 2, (V[]){v_hd_2418, v_k_2419});
}
V g_heff_2ecommands_2enodeDone_24s950_24s1055_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_x_241 = heff_dup(heff_env(self)[1]);
  V v_hd_2418 = heff_dup(heff_env(self)[2]);
  V v_next_242 = heff_dup(heff_env(self)[3]);
  V v_k_2419 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_2420);
  V v_t_2421 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2enodeDone_24s950_24s1055_str3)));
  V v_t_2422 = (g_std_2epath_2eparse(v_st_240, v_x_241));
  V v_p_2423 = (g_std_2epath_2ejoin_2eonto_240(v_t_2421, v_t_2422));
  V v_t_2424 = ({ V a_0 = heff_get(heff_dup(v_p_2423), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2423), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2425 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2423), LBL_drive), heff_get(v_p_2423, LBL_absolute), v_t_2424});
  V v_path_2426 = ({ V a_0 = v_st_240; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2enodeDone_24s950_24s1055_str4), v_path_2426), ((V)&g_heff_2ecommands_2enodeDone_24s950_24s1055_str5));
  V v_t_2428 = heff_tag(TAG_Write, 2, (V[]){v_t_2427, NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2418), LBL_malg), 1, (V[]){v_t_2430}));
  return heff_tail(heff_get(heff_dup(v_hd_2418), LBL_bind), 2, (V[]){v_t_2431, heff_clo(g_heff_2ecommands_2enodeDone_24s950_24s1055_lam4, 1, 3, (V[]){v_next_242, v_hd_2418, v_k_2419})});
}
V g_heff_2ecommands_2enodeDone_24s950_24s1055_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_x_241 = heff_dup(heff_env(self)[2]);
  V v_next_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_hd_2418), heff_clo(g_heff_2ecommands_2enodeDone_24s950_24s1055_lam3, 1, 5, (V[]){v_st_240, v_x_241, v_hd_2418, v_next_242, v_k_2419})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2epublishFails_24s952_24s1057_str0 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 32, 112, 117, 98, 108, 105, 115, 104, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishFails_24s952_24s1057_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2epublishFails_24s952_24s1057_lam0(V self, V *args);
Clo g_heff_2ecommands_2epublishFails_24s952_24s1057_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishFails_24s952_24s1057_entry, 3, 0};

V g_heff_2ecommands_2epublishFails_24s952_24s1057(V v_why_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2epublishFails_24s952_24s1057_str0), v_why_240), ((V)&g_heff_2ecommands_2epublishFails_24s952_24s1057_str1));
  V v_t_244 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_243, NTAG(TAG_MkUnit)});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2epublishFails_24s952_24s1057_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2epublishFails_24s952_24s1057_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishFails_24s952_24s1057(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2epublishFails_24s952_24s1057_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_248);
  V v_t_249 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2412, v_k_242});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2epublishFails_24s952_24s1058_str0 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 32, 112, 117, 98, 108, 105, 115, 104, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishFails_24s952_24s1058_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2epublishFails_24s952_24s1058_lam0(V self, V *args);
Clo g_heff_2ecommands_2epublishFails_24s952_24s1058_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishFails_24s952_24s1058_entry, 3, 0};

V g_heff_2ecommands_2epublishFails_24s952_24s1058(V v_why_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2epublishFails_24s952_24s1058_str0), v_why_240), ((V)&g_heff_2ecommands_2epublishFails_24s952_24s1058_str1));
  V v_t_244 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_243, NTAG(TAG_MkUnit)});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2epublishFails_24s952_24s1058_lam0, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2epublishFails_24s952_24s1058_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishFails_24s952_24s1058(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2epublishFails_24s952_24s1058_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_248);
  V v_t_249 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2412, v_k_242});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2egitOk_24s959_24s1065_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egitOk_24s959_24s1065_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2egitOk_24s959_24s1065_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {58, 32, 103, 105, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2egitOk_24s959_24s1065_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
V g_heff_2ecommands_2egitOk_24s959_24s1065_lam0(V self, V *args); static Clo g_heff_2ecommands_2egitOk_24s959_24s1065_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egitOk_24s959_24s1065_lam0, 1, 0};
V g_heff_2ecommands_2egitOk_24s959_24s1065_lam1(V self, V *args);
Clo g_heff_2ecommands_2egitOk_24s959_24s1065_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egitOk_24s959_24s1065_entry, 4, 0};

V g_heff_2ecommands_2egitOk_24s959_24s1065(V v_what_240, V v_as_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2egitOk_24s959_24s1065_str0), heff_dup(v_as_241), ((V)&g_heff_2ecommands_2egitOk_24s959_24s1065_lam0_clo)})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})}));
  return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2egitOk_24s959_24s1065_lam1, 1, 3, (V[]){v_as_241, v_what_240, v_k_243})});
}
V g_heff_2ecommands_2egitOk_24s959_24s1065_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2egitOk_24s959_24s1065(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2egitOk_24s959_24s1065_lam0(V self, V *args) {
  V v_r_244 = args[0];
  heff_drop(self);
  return v_r_244;
}
V g_heff_2ecommands_2egitOk_24s959_24s1065_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_as_241 = heff_dup(heff_env(self)[0]);
  V v_what_240 = heff_dup(heff_env(self)[1]);
  V v_k_243 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_249 = heff_intEq(heff_get(heff_dup(v_x_248), LBL_status), MK_INT(0LL));
  V v_x_2419;
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    heff_drop(v_x_248);
    heff_drop(v_as_241);
    heff_drop(v_what_240);
    heff_drop(v_t_249);
    v_x_2419 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_249);
    V v_t_2412;
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      heff_drop(v_as_241);
      v_t_2412 = ((V)&g_heff_2ecommands_2egitOk_24s959_24s1065_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2410 = heff_field(v_as_241, 0);
      V v_xs_2411 = heff_field(v_as_241, 1);
      heff_take(v_as_241, 3ULL);
      v_t_2412 = ({ V a_0 = v_x_2410; V a_1 = v_xs_2411; V r_ = (g_prelude_2efoldl_24s4(a_0, a_1)); heff_drop(v_xs_2411); r_; });
      break;
    }
    default: heff_nomatch(v_as_241);
    }
    V v_s_2413 = heff_get(v_x_248, LBL_err);
    V v_t_2414 = (g_prelude_2eskipSpaces(heff_dup(v_s_2413), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2415 = heff_intSub(heff_strLength(heff_dup(v_s_2413)), MK_INT(1LL));
    V v_t_2416 = (g_prelude_2eskipSpaces(heff_dup(v_s_2413), v_t_2415, MK_INT(-1LL)));
    V v_t_2417 = heff_strSlice(v_s_2413, v_t_2414, heff_intAdd(v_t_2416, MK_INT(1LL)));
    V v_t_2418 = heff_strAppend(v_what_240, heff_strAppend(((V)&g_heff_2ecommands_2egitOk_24s959_24s1065_str2), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ecommands_2egitOk_24s959_24s1065_str3), v_t_2417))));
    v_x_2419 = heff_tag(TAG_Just, 1, (V[]){v_t_2418});
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  return heff_tail(v_k_243, 1, (V[]){v_x_2419});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s958_24s1064_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s958_24s1064_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2epublishTag_24s958_24s1064_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishTag_24s958_24s1064_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {116, 97, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2epublishTag_24s958_24s1064_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2epublishTag_24s958_24s1064_str5 = {{0x80000000u, K_STR, 0}, 10, 10, {110, 111, 116, 32, 116, 97, 103, 103, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s958_24s1064_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTag_24s958_24s1064_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 117, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2epublishTag_24s958_24s1064_str8 = {{0x80000000u, K_STR, 0}, 6, 6, {111, 114, 105, 103, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2epublishTag_24s958_24s1064_str9 = {{0x80000000u, K_STR, 0}, 18, 18, {116, 97, 103, 103, 101, 100, 44, 32, 110, 111, 116, 32, 112, 117, 115, 104, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2ecommands_2epublishTag_24s958_24s1064_str10 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 102, 102, 32, 112, 117, 98, 108, 105, 115, 104, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s958_24s1064_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2epublishTag_24s958_24s1064_str12 = {{0x80000000u, K_STR, 0}, 7, 7, {44, 32, 116, 97, 103, 32, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishTag_24s958_24s1064_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2epublishTag_24s958_24s1064_lam1(V self, V *args);
V g_heff_2ecommands_2epublishTag_24s958_24s1064_lam0(V self, V *args);
Clo g_heff_2ecommands_2epublishTag_24s958_24s1064_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishTag_24s958_24s1064_entry, 4, 0};

V g_heff_2ecommands_2epublishTag_24s958_24s1064(V v_v_240, V v_pk_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_str0), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_str1), heff_dup(v_v_240)), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_str2), v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_str4), v_t_245})});
  return (g_heff_2ecommands_2egitOk_24s959_24s1065(((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_str5), v_t_246, heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2epublishTag_24s958_24s1064_lam0, 1, 4, (V[]){v_v_240, v_hd_242, v_pk_241, v_k_243})));
}
V g_heff_2ecommands_2epublishTag_24s958_24s1064_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishTag_24s958_24s1064(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2epublishTag_24s958_24s1064_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_pk_241 = heff_dup(heff_env(self)[0]);
  V v_v_240 = heff_dup(heff_env(self)[1]);
  V v_hd_242 = heff_dup(heff_env(self)[2]);
  V v_k_243 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_drop(v_x_2410);
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_str10), heff_strAppend(heff_get(v_pk_241, LBL_module), heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_str11), heff_strAppend(heff_dup(v_v_240), heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_str12), v_v_240)))));
    V v_t_2412 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_str13)), NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2414}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2415, v_k_243});
  }
  case TAG_Just: {
    V v_why_2416 = heff_field(v_x_2410, 0);
    heff_take(v_x_2410, 1ULL);
    heff_drop(v_pk_241);
    heff_drop(v_v_240);
    return (g_heff_2ecommands_2epublishFails_24s952_24s1058(v_why_2416, v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ecommands_2epublishTag_24s958_24s1064_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_v_240 = heff_dup(heff_env(self)[0]);
  V v_hd_242 = heff_dup(heff_env(self)[1]);
  V v_pk_241 = heff_dup(heff_env(self)[2]);
  V v_k_243 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    heff_drop(v_x_247);
    V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_str6), heff_dup(v_v_240)), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_str8), v_t_248})});
    return (g_heff_2ecommands_2egitOk_24s959_24s1065(((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_str9), v_t_249, heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2epublishTag_24s958_24s1064_lam1, 1, 4, (V[]){v_pk_241, v_v_240, v_hd_242, v_k_243})));
  }
  case TAG_Just: {
    V v_why_2417 = heff_field(v_x_247, 0);
    heff_take(v_x_247, 1ULL);
    heff_drop(v_v_240);
    heff_drop(v_pk_241);
    return (g_heff_2ecommands_2epublishFails_24s952_24s1058(v_why_2417, v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_x_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s957_24s1063_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2epublishTested_24s957_24s1063_str1 = {{0x80000000u, K_STR, 0}, 27, 27, {32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 100, 111, 32, 110, 111, 116, 32, 104, 111, 108, 100, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s957_24s1063_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2epublishTested_24s957_24s1063_str3 = {{0x80000000u, K_STR, 0}, 37, 37, {32, 116, 101, 115, 116, 115, 32, 102, 97, 105, 108, 44, 32, 111, 114, 32, 97, 32, 102, 105, 108, 101, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 99, 104, 101, 99, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s957_24s1063_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2epublishTested_24s957_24s1063_str5 = {{0x80000000u, K_STR, 0}, 27, 27, {32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 100, 111, 32, 110, 111, 116, 32, 104, 111, 108, 100, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s957_24s1063_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2epublishTested_24s957_24s1063_str7 = {{0x80000000u, K_STR, 0}, 37, 37, {32, 116, 101, 115, 116, 115, 32, 102, 97, 105, 108, 44, 32, 111, 114, 32, 97, 32, 102, 105, 108, 101, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 99, 104, 101, 99, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s957_24s1063_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2epublishTested_24s957_24s1063_str9 = {{0x80000000u, K_STR, 0}, 27, 27, {32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 100, 111, 32, 110, 111, 116, 32, 104, 111, 108, 100, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishTested_24s957_24s1063_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2epublishTested_24s957_24s1063_str11 = {{0x80000000u, K_STR, 0}, 37, 37, {32, 116, 101, 115, 116, 115, 32, 102, 97, 105, 108, 44, 32, 111, 114, 32, 97, 32, 102, 105, 108, 101, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 99, 104, 101, 99, 107}};
Clo g_heff_2ecommands_2epublishTested_24s957_24s1063_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishTested_24s957_24s1063_entry, 3, 0};

V g_heff_2ecommands_2epublishTested_24s957_24s1063(V v_v_240, V v_pk_241, V v_r_242) {
top: ;
  V v_t_243 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_r_242), LBL_failed));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_v_240);
    heff_drop(v_pk_241);
    heff_drop(v_t_243);
    V v_t_244 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_failed));
    V v_t_245 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_total));
    V v_t_246 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_testsFailed));
    V v_t_247 = heff_intShow(heff_get(v_r_242, LBL_tests));
    V v_t_248 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s957_24s1063_str0), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s957_24s1063_str1), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s957_24s1063_str2), heff_strAppend(v_t_247, ((V)&g_heff_2ecommands_2epublishTested_24s957_24s1063_str3))))))));
    return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s952_24s1057_clo), 1, (V[]){v_t_248});
  }
  case TAG_False: {
    heff_drop(v_t_243);
    V v_t_249 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_r_242), LBL_testsFailed));
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_v_240);
      heff_drop(v_pk_241);
      heff_drop(v_t_249);
      V v_t_2410 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_failed));
      V v_t_2411 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_total));
      V v_t_2412 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_testsFailed));
      V v_t_2413 = heff_intShow(heff_get(v_r_242, LBL_tests));
      V v_t_2414 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s957_24s1063_str4), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s957_24s1063_str5), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s957_24s1063_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2ecommands_2epublishTested_24s957_24s1063_str7))))))));
      return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s952_24s1057_clo), 1, (V[]){v_t_2414});
    }
    case TAG_False: {
      heff_drop(v_t_249);
      V v_t_2415 = heff_get(heff_dup(v_r_242), LBL_ok);
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop(v_r_242);
        heff_drop(v_t_2415);
        return heff_tail(((V)&g_heff_2ecommands_2epublishTag_24s958_24s1064_clo), 2, (V[]){v_v_240, v_pk_241});
      }
      case TAG_False: {
        heff_drop(v_v_240);
        heff_drop(v_pk_241);
        heff_drop(v_t_2415);
        V v_t_2416 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_failed));
        V v_t_2417 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_total));
        V v_t_2418 = heff_intShow(heff_get(heff_dup(v_r_242), LBL_testsFailed));
        V v_t_2419 = heff_intShow(heff_get(v_r_242, LBL_tests));
        V v_t_2420 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s957_24s1063_str8), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s957_24s1063_str9), heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2ecommands_2epublishTested_24s957_24s1063_str10), heff_strAppend(v_t_2419, ((V)&g_heff_2ecommands_2epublishTested_24s957_24s1063_str11))))))));
        return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s952_24s1057_clo), 1, (V[]){v_t_2420});
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecommands_2epublishTested_24s957_24s1063_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishTested_24s957_24s1063(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eevalDiags_24s1002_24s1070_lam2(V self, V *args);
V g_heff_2ecommands_2eevalDiags_24s1002_24s1070_lam1(V self, V *args);
V g_heff_2ecommands_2eevalDiags_24s1002_24s1070_lam0(V self, V *args);
Clo g_heff_2ecommands_2eevalDiags_24s1002_24s1070_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eevalDiags_24s1002_24s1070_entry, 2, 0};

V g_heff_2ecommands_2eevalDiags_24s1002_24s1070(V v_badL_240, V v_cs_241) {
top: ;
  V v_c_242 = (g_heff_2ecommands_2eputFileDiags_24s894(heff_dup(v_cs_241)));
  return heff_clo(g_heff_2ecommands_2eevalDiags_24s1002_24s1070_lam0, 2, 3, (V[]){v_c_242, v_cs_241, heff_dup(v_badL_240)});
}
V g_heff_2ecommands_2eevalDiags_24s1002_24s1070_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eevalDiags_24s1002_24s1070(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eevalDiags_24s1002_24s1070_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_badL_240 = heff_dup(heff_env(self)[0]);
  V v_hd_243 = heff_dup(heff_env(self)[1]);
  V v_k_244 = heff_dup(heff_env(self)[2]);
  V v_cs_241 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_x_2414);
  switch (heff_tag_of(v_badL_240)) {
  case TAG_True: {
    heff_drop(v_badL_240);
    heff_drop(v_cs_241);
    V v_t_2415 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2417}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2418, v_k_244});
  }
  case TAG_False: {
    heff_drop(v_badL_240);
    V v_t_2419 = ({ V a_0 = v_cs_241; V r_ = (g_prelude_2eany_24s820(a_0)); heff_drop(v_cs_241); r_; });
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      heff_drop(v_t_2419);
      V v_t_2420 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2421 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2422}));
      return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2423, v_k_244});
    }
    case TAG_False: {
      heff_drop(v_hd_243);
      heff_drop(v_t_2419);
      return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  default: return heff_nomatch(v_badL_240);
  }
}
V g_heff_2ecommands_2eevalDiags_24s1002_24s1070_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_cs_241 = heff_dup(heff_env(self)[0]);
  V v_hd_243 = heff_dup(heff_env(self)[1]);
  V v_k_244 = heff_dup(heff_env(self)[2]);
  V v_badL_240 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_x_245);
  V v_t_246 = (g_heff_2edriver_2elastChecked(v_cs_241));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_cs_241);
    heff_drop(v_badL_240);
    heff_drop(v_t_246);
    V v_t_247 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_249}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2410, v_k_244});
  }
  case TAG_Just: {
    V v_c_2411 = heff_field(v_t_246, 0);
    heff_take(v_t_246, 1ULL);
    V v_t_2412 = (g_heff_2edriver_2eevaluate(v_c_2411));
    V v_c_2413 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintEvals_24s1003_clo), 1, (V[]){v_t_2412}));
    return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2eevalDiags_24s1002_24s1070_lam2, 1, 4, (V[]){v_badL_240, v_hd_243, v_k_244, v_cs_241})});
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ecommands_2eevalDiags_24s1002_24s1070_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_dup(heff_env(self)[0]);
  V v_cs_241 = heff_dup(heff_env(self)[1]);
  V v_badL_240 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_242, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2eevalDiags_24s1002_24s1070_lam1, 1, 4, (V[]){v_cs_241, v_hd_243, v_k_244, v_badL_240})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam1(V self, V *args); static Clo g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam1, 1, 0};
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam4(V self, V *args); static Clo g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam4, 1, 0};
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam3(V self, V *args);
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam5(V self, V *args);
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam2(V self, V *args);
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam0(V self, V *args);
Clo g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_entry, 2, 0};

V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098(V v_hd_240, V v_k_241) {
top: ;
  return (g_heff_2ecommands_2estyleNow_24s864_24s1010(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098(a[0], a[1]);
}
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam1(V self, V *args) {
  V v_s_243 = args[0];
  heff_drop(self);
  return v_s_243;
}
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam4(V self, V *args) {
  V v_t_2428 = args[0];
  heff_drop(self);
  return v_t_2428;
}
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam3(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k2_2427 = args[1];
  V v_path_2425 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2429 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2425, ((V)&g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam4_clo)})});
  V v_t_2430 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2426), LBL_malg), 1, (V[]){v_t_2430}));
  return heff_tail(heff_get(v_hd_2426, LBL_bind), 2, (V[]){v_t_2431, v_k2_2427});
}
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x_2438;
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Nothing: {
    heff_drop(v_x_2433);
    v_x_2438 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2434 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Just = heff_take_reuse(v_x_2433, 1ULL);
    V v_t_2435 = (g_heff_2eproject_2ereadPackage(v_src_2434));
    switch (heff_tag_of(v_t_2435)) {
    case TAG_Left: {
      heff_take(v_t_2435, 0ULL);
      heff_drop(v_ru_24x_2433_24Just);
      v_x_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2437 = heff_field(v_t_2435, 0);
      heff_take(v_t_2435, 1ULL);
      v_x_2438 = heff_tag_at(v_ru_24x_2433_24Just, TAG_Just, 1, (V[]){heff_get(v_p_2437, LBL_heff)});
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    break;
  }
  default: heff_nomatch(v_x_2433);
  }
  return heff_tail(v_k_241, 1, (V[]){v_x_2438});
}
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_242 = heff_dup(heff_env(self)[0]);
  V v_hd_240 = heff_dup(heff_env(self)[1]);
  V v_k_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_p_248 = (g_std_2epath_2eparse(v_x_242, v_x_247));
  V v_t_249 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_248), LBL_segments)));
  V v_xs_2410 = (g_prelude_2edrop(MK_INT(1LL), v_t_249));
  V v_t_2411 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2410));
  V v_t_2412 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_248), LBL_drive), heff_get(v_p_248, LBL_absolute), v_t_2411});
  V v_s_2413 = (g_std_2epath_2erender(v_x_242, v_t_2412));
  V v_p_2414 = (g_std_2epath_2eparse(v_x_242, v_s_2413));
  V v_t_2415 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2414), LBL_segments)));
  V v_xs_2416 = (g_prelude_2edrop(MK_INT(1LL), v_t_2415));
  V v_t_2417 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2416));
  V v_t_2418 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2414), LBL_drive), heff_get(v_p_2414, LBL_absolute), v_t_2417});
  V v_a_2419 = (g_std_2epath_2erender(v_x_242, v_t_2418));
  V v_t_2420 = (g_std_2epath_2eparse(v_x_242, v_a_2419));
  V v_t_2421 = (g_std_2epath_2eparse(v_x_242, ((V)&g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_str0)));
  V v_p_2422 = (g_std_2epath_2ejoin_2eonto_240(v_t_2420, v_t_2421));
  V v_t_2423 = ({ V a_0 = heff_get(heff_dup(v_p_2422), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2422), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2424 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2422), LBL_drive), heff_get(v_p_2422, LBL_absolute), v_t_2423});
  V v_path_2425 = ({ V a_0 = v_x_242; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_242); r_; });
  V v_c_2432 = heff_clo(g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam3, 2, 1, (V[]){v_path_2425});
  return heff_tail(v_c_2432, 2, (V[]){v_hd_240, heff_clo(g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam5, 1, 1, (V[]){v_k_241})});
}
V g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam1_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098_lam2, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2eload_24s861_24s1007_24s1079_lam2(V self, V *args);
V g_heff_2ecommands_2eload_24s861_24s1007_24s1079_lam1(V self, V *args);
V g_heff_2ecommands_2eload_24s861_24s1007_24s1079_lam0(V self, V *args);
Clo g_heff_2ecommands_2eload_24s861_24s1007_24s1079_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eload_24s861_24s1007_24s1079_entry, 3, 0};

V g_heff_2ecommands_2eload_24s861_24s1007_24s1079(V v_file_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecommands_2ehostNow_24s862_24s1008(heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eload_24s861_24s1007_24s1079_lam0, 1, 3, (V[]){v_file_240, v_hd_241, v_k_242})));
}
V g_heff_2ecommands_2eload_24s861_24s1007_24s1079_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eload_24s861_24s1007_24s1079(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eload_24s861_24s1007_24s1079_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_247 = ({ V a_0 = v_x_246; V a_1 = heff_get(heff_dup(v_x_245), LBL_packages); V r_ = (g_heff_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_246); r_; });
  V v_x_248 = (g_prelude_2efoldl_24s819(v_x_245, v_t_247));
  return heff_tail(v_k_242, 1, (V[]){v_x_248});
}
V g_heff_2ecommands_2eload_24s861_24s1007_24s1079_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return (g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098(v_hd_241, heff_clo(g_heff_2ecommands_2eload_24s861_24s1007_24s1079_lam2, 1, 2, (V[]){v_x_245, v_k_242})));
}
V g_heff_2ecommands_2eload_24s861_24s1007_24s1079_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_file_240 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_c_244 = heff_tr(heff_apply(heff_dup(g_heff_2eload_2eloadProgram_24s866_24s1080_get()), 2, (V[]){v_x_243, v_file_240}));
  return heff_tail(v_c_244, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eload_24s861_24s1007_24s1079_lam1, 1, 2, (V[]){v_hd_241, v_k_242})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_lam2(V self, V *args);
V g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_lam1(V self, V *args);
V g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_lam0(V self, V *args);
Clo g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_entry, 3, 0};

V g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073(V v_file_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecommands_2eload_24s861_24s1007_24s1079(v_file_240, heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_lam0, 1, 2, (V[]){v_hd_241, v_k_242})));
}
V g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_244 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_247 = ({ V b_0 = heff_intLt(MK_INT(0LL), v_x_244); V a_1 = v_x_246; V r_ = (g_heff_2ecommands_2echeckLast_24s893_24s1013(b_0, a_1)); heff_drop(b_0); r_; });
  return heff_tail(v_t_247, 2, (V[]){v_hd_241, v_k_242});
}
V g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_x_243 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_c_245 = (g_heff_2esession_2ecachedProgram_24s888_24s1074(v_x_243));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_lam2, 1, 3, (V[]){v_x_244, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_str0), heff_get(heff_dup(v_x_243), LBL_errors), MK_INT(0LL), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2echeckCmd_24s860_24s1006_24s1073_lam1, 1, 3, (V[]){v_x_243, v_hd_241, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_str1 = {{0x80000000u, K_STR, 0}, 12, 12, {46, 112, 114, 111, 118, 105, 100, 101, 114, 46, 106, 115}};
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam0, 2, 0};
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam2(V self, V *args); static Clo g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam2, 1, 0};
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam1(V self, V *args);
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam4(V self, V *args);
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam3(V self, V *args);
Clo g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_entry, 2, 0};

V g_heff_2ecommands_2ereadProviderAt_24s899_24s1103(V v_sources_240, V v_m_241) {
top: ;
  V v_t_242 = (g_heff_2ecommands_2epathOfModule(v_sources_240, heff_dup(v_m_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    heff_drop(v_t_242);
    return ((V)&g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam0_clo);
  }
  case TAG_Just: {
    V v_path_245 = heff_field(v_t_242, 0);
    heff_take(v_t_242, 1ULL);
    V v_t_246 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
    V v_t_247 = heff_strSlice(heff_dup(v_path_245), v_t_246, heff_strLength(heff_dup(v_path_245)));
    V v_t_248 = heff_strEq(v_t_247, ((V)&g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_str0));
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_t_248);
      V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
      v_t_2410 = heff_strSlice(v_path_245, MK_INT(0LL), v_t_249);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_248);
      v_t_2410 = v_path_245;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_path_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_str1));
    V v_c_2418 = heff_clo(g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam1, 2, 1, (V[]){v_path_2411});
    return heff_clo(g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam3, 2, 2, (V[]){v_c_2418, v_m_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ereadProviderAt_24s899_24s1103(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(self);
  heff_drop(v_hd_243);
  return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_Nothing)});
}
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  heff_drop(self);
  return v_t_2414;
}
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_path_2411 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam2_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get(v_hd_2412, LBL_bind), 2, (V[]){v_t_2417, v_k2_2413});
}
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_m_241 = heff_dup(heff_env(self)[0]);
  V v_k_2420 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_x_2423;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    heff_drop(v_x_2421);
    heff_drop(v_m_241);
    v_x_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2422 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Just = heff_take_reuse(v_x_2421, 1ULL);
    v_x_2423 = heff_tag_at(v_ru_24x_2421_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_184_321, (V[]){v_m_241, v_t_2422})});
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  return heff_tail(v_k_2420, 1, (V[]){v_x_2423});
}
V g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2418, 2, (V[]){v_hd_2419, heff_clo(g_heff_2ecommands_2ereadProviderAt_24s899_24s1103_lam4, 1, 2, (V[]){v_m_241, v_k_2420})});
}
V g_heff_2ecommands_2ereadProviders_24s898_24s1102_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadProviders_24s898_24s1102_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviders_24s898_24s1102_lam0, 2, 0};
V g_heff_2ecommands_2ereadProviders_24s898_24s1102_lam3(V self, V *args);
V g_heff_2ecommands_2ereadProviders_24s898_24s1102_lam2(V self, V *args);
V g_heff_2ecommands_2ereadProviders_24s898_24s1102_lam1(V self, V *args);
Clo g_heff_2ecommands_2ereadProviders_24s898_24s1102_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviders_24s898_24s1102_entry, 2, 0};

V g_heff_2ecommands_2ereadProviders_24s898_24s1102(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return ((V)&g_heff_2ecommands_2ereadProviders_24s898_24s1102_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take(v_x2_241, 3ULL);
    V v_c_246 = (g_heff_2ecommands_2ereadProviderAt_24s899_24s1103(v_sources_240, v_m_244));
    return heff_clo(g_heff_2ecommands_2ereadProviders_24s898_24s1102_lam1, 2, 3, (V[]){v_c_246, heff_dup(v_sources_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2ereadProviders_24s898_24s1102_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ereadProviders_24s898_24s1102(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ereadProviders_24s898_24s1102_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(self);
  heff_drop(v_hd_242);
  return heff_tail(v_k_243, 1, (V[]){NTAG(TAG_Nil)});
}
V g_heff_2ecommands_2ereadProviders_24s898_24s1102_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_dup(heff_env(self)[0]);
  V v_k_248 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_x_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop(v_x_249);
    v_x_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take(v_x_249, 1ULL);
    v_x_2413 = heff_tag(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  return heff_tail(v_k_248, 1, (V[]){v_x_2413});
}
V g_heff_2ecommands_2ereadProviders_24s898_24s1102_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_dup(heff_env(self)[0]);
  V v_rest_245 = heff_dup(heff_env(self)[1]);
  V v_hd_247 = heff_dup(heff_env(self)[2]);
  V v_k_248 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_c_2410 = ({ V a_0 = v_sources_240; V a_1 = v_rest_245; V r_ = (g_heff_2ecommands_2ereadProviders_24s898_24s1102(a_0, a_1)); heff_drop(v_sources_240); r_; });
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2ecommands_2ereadProviders_24s898_24s1102_lam3, 1, 2, (V[]){v_x_249, v_k_248})});
}
V g_heff_2ecommands_2ereadProviders_24s898_24s1102_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_dup(heff_env(self)[0]);
  V v_sources_240 = heff_dup(heff_env(self)[1]);
  V v_rest_245 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2ereadProviders_24s898_24s1102_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_lam1(V self, V *args); static Clo g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_lam1, 1, 0};
V g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_lam3(V self, V *args);
V g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_lam2(V self, V *args);
V g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_lam0(V self, V *args);
Clo g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_entry, 5, 0};

V g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105(V v_outPath_240, V v_done_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ecommands_2eemitErrs_24s902(heff_get(heff_dup(v_o_242), LBL_errors), heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_lam0, 1, 5, (V[]){v_o_242, v_outPath_240, v_hd_243, v_done_241, v_k_244})));
}
V g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_lam1(V self, V *args) {
  V v_ok_2410 = args[0];
  heff_drop(self);
  return v_ok_2410;
}
V g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_243 = heff_dup(heff_env(self)[0]);
  V v_k_244 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2420);
  V v_t_2421 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2423}));
  return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2424, v_k_244});
}
V g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_done_241 = heff_dup(heff_env(self)[0]);
  V v_hd_243 = heff_dup(heff_env(self)[1]);
  V v_k_244 = heff_dup(heff_env(self)[2]);
  V v_outPath_240 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_True: {
    heff_drop(v_x_2414);
    heff_drop(v_outPath_240);
    return heff_tail(v_done_241, 2, (V[]){v_hd_243, v_k_244});
  }
  case TAG_False: {
    heff_drop(v_x_2414);
    heff_drop(v_done_241);
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_str0), v_outPath_240), ((V)&g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_str1));
    V v_t_2416 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2415, NTAG(TAG_MkUnit)});
    V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2418}));
    return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2419, heff_clo(g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_lam3, 1, 2, (V[]){v_hd_243, v_k_244})});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_o_242 = heff_dup(heff_env(self)[0]);
  V v_outPath_240 = heff_dup(heff_env(self)[1]);
  V v_hd_243 = heff_dup(heff_env(self)[2]);
  V v_done_241 = heff_dup(heff_env(self)[3]);
  V v_k_244 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_245);
  V v_t_246 = heff_get(heff_dup(v_o_242), LBL_errors);
  V v_t_249;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    heff_drop(v_t_246);
    v_t_249 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take(v_t_246, 0ULL);
    v_t_249 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    heff_drop(v_t_249);
    V v_t_2411 = heff_tag(TAG_WriteFile, 3, (V[]){heff_dup(v_outPath_240), heff_get(v_o_242, LBL_source), ((V)&g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_lam1_clo)});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})}));
    return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_lam2, 1, 4, (V[]){v_done_241, v_hd_243, v_k_244, v_outPath_240})});
  }
  case TAG_False: {
    heff_drop(v_o_242);
    heff_drop(v_outPath_240);
    heff_drop(v_done_241);
    heff_drop(v_t_249);
    V v_t_2425 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2427}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2428, v_k_244});
  }
  default: return heff_nomatch(v_t_249);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_lam0(V self, V *args);
V g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_lam1(V self, V *args);
Clo g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_entry, 7, 0};

V g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104(V v_host_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_c_245, V v_available_246) {
top: ;
  V v_t_247 = (g_heff_2edriver_2ecandidatesOf(heff_dup(v_c_245)));
  V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_heff_2edriver_2enubStrD(v_t_248));
  V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_lam0, 1, 1, (V[]){heff_dup(v_available_246)}), v_t_249));
  V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = heff_dup(v_c_245); V a_2 = v_name_242; V r_ = (g_heff_2edriver_2efindRunnable(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Left: {
    V v_why_2413 = heff_field(v_t_2412, 0);
    heff_take(v_t_2412, 1ULL);
    heff_drop(v_host_240);
    heff_drop(v_outPath_243);
    heff_drop(v_done_244);
    heff_drop(v_c_245);
    return heff_clo(g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_lam1, 2, 2, (V[]){v_file_241, v_why_2413});
  }
  case TAG_Right: {
    V v_r_2426 = heff_field(v_t_2412, 0);
    heff_take(v_t_2412, 1ULL);
    heff_drop(v_file_241);
    V v_t_2427 = heff_get(heff_get(v_c_245, LBL_top), LBL_globals);
    V v_t_2428 = (g_heff_2eemit_2ecompileProgram(v_host_240, v_available_246, v_t_2427, heff_get(heff_dup(v_r_2426), LBL_key), heff_get(v_r_2426, LBL_effect)));
    return heff_tail(((V)&g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_clo), 3, (V[]){v_outPath_243, v_done_244, v_t_2428});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[6]); return r;
}
V g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_lam0(V self, V *args) {
  V v_k_2410 = args[0];
  V v_available_246 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V a_0 = v_available_246; V a_1 = v_k_2410; V r_ = (g_heff_2ecommands_2eprovidesLeaf(a_0, a_1)); heff_drop(v_available_246); r_; });
}
V g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2414 = heff_dup(heff_env(self)[0]);
  V v_k_2415 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2424}));
  return heff_tail(heff_get(v_hd_2414, LBL_bind), 2, (V[]){v_t_2425, v_k_2415});
}
V g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_file_241 = heff_dup(heff_env(self)[0]);
  V v_why_2413 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_str0), heff_strAppend(v_file_241, heff_strAppend(((V)&g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_str1), v_why_2413)));
  V v_t_2417 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2416, ((V)&g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_str2)), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get(heff_dup(v_hd_2414), LBL_bind), 2, (V[]){v_t_2420, heff_clo(g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104_lam2, 1, 2, (V[]){v_hd_2414, v_k_2415})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_str0 = {{0x80000000u, K_STR, 0}, 15, 15, {110, 111, 32, 102, 105, 108, 101, 115, 32, 103, 105, 118, 101, 110, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam0(V self, V *args); static Clo g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam0, 2, 0};
V g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam4(V self, V *args);
V g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam3(V self, V *args);
V g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam2(V self, V *args);
Clo g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_entry, 7, 0};

V g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101(V v_sources_240, V v_host_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_cs_246) {
top: ;
  V v_t_247 = (g_heff_2edriver_2elastChecked(v_cs_246));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_host_241);
    heff_drop(v_file_242);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    heff_drop(v_t_247);
    return ((V)&g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam0_clo);
  }
  case TAG_Just: {
    V v_c_2419 = heff_field(v_t_247, 0);
    heff_take(v_t_247, 1ULL);
    V v_t_2420 = (g_heff_2edriver_2ecandidatesOf(heff_dup(v_c_2419)));
    V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2420); r_; });
    V v_t_2422 = (g_heff_2edriver_2enubStrD(v_t_2421));
    V v_xs_2423 = (g_prelude_2emap_24s639(v_t_2422));
    V v_t_2424 = (g_heff_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2423));
    V v_c_2425 = (g_heff_2ecommands_2ereadProviders_24s898_24s1102(v_sources_240, v_t_2424));
    return heff_clo(g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam2, 2, 7, (V[]){v_c_2425, v_host_241, v_file_242, v_name_243, v_outPath_244, v_done_245, v_c_2419});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[0]); heff_drop(a[6]); return r;
}
V g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_248 = heff_dup(heff_env(self)[0]);
  V v_k_249 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get(v_hd_248, LBL_bind), 2, (V[]){v_t_2418, v_k_249});
}
V g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  heff_drop(self);
  V v_t_2410 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_str0), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2412}));
  return heff_tail(heff_get(heff_dup(v_hd_248), LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam1, 1, 2, (V[]){v_hd_248, v_k_249})});
}
V g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam4(V self, V *args) {
  V v_p_2429 = args[0];
  V v_host_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2430 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_str1), heff_get(v_p_2429, LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2431 = (g_prelude_2emap_24s636(v_t_2430));
  V v_x1_2432 = (g_heff_2eemit_2ecatMaybesL(v_t_2431));
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_Nil: {
    heff_drop(v_host_241);
    heff_drop(v_x1_2432);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_2433 = heff_field(v_x1_2432, 0);
    heff_take(v_x1_2432, 1ULL);
    return heff_strEq(v_x_2433, v_host_241);
  }
  default: return heff_nomatch(v_x1_2432);
  }
}
V g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_host_241 = heff_dup(heff_env(self)[0]);
  V v_file_242 = heff_dup(heff_env(self)[1]);
  V v_name_243 = heff_dup(heff_env(self)[2]);
  V v_outPath_244 = heff_dup(heff_env(self)[3]);
  V v_done_245 = heff_dup(heff_env(self)[4]);
  V v_c_2419 = heff_dup(heff_env(self)[5]);
  V v_hd_2426 = heff_dup(heff_env(self)[6]);
  V v_k_2427 = heff_dup(heff_env(self)[7]);
  heff_drop(self);
  V v_t_2435 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam4, 1, 1, (V[]){heff_dup(v_host_241)}), v_x_2428));
  V v_t_2436 = ({ V a_0 = v_host_241; V a_1 = v_file_242; V a_2 = v_name_243; V a_3 = v_outPath_244; V a_4 = v_done_245; V a_5 = v_c_2419; V a_6 = v_t_2435; V r_ = heff_tr(g_heff_2ecommands_2ecompileFound_24s900_24s1017_24s1104(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2435); r_; });
  return heff_tail(v_t_2436, 2, (V[]){v_hd_2426, v_k_2427});
}
V g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam2(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_dup(heff_env(self)[0]);
  V v_host_241 = heff_dup(heff_env(self)[1]);
  V v_file_242 = heff_dup(heff_env(self)[2]);
  V v_name_243 = heff_dup(heff_env(self)[3]);
  V v_outPath_244 = heff_dup(heff_env(self)[4]);
  V v_done_245 = heff_dup(heff_env(self)[5]);
  V v_c_2419 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_hd_2426), heff_clo(g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101_lam3, 1, 8, (V[]){v_host_241, v_file_242, v_name_243, v_outPath_244, v_done_245, v_c_2419, v_hd_2426, v_k_2427})});
}
V g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100_entry, 8, 0};

V g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100(V v_sources_240, V v_host_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_badL_246, V v_cs_247) {
top: ;
  V v_c_248 = (g_heff_2ecommands_2eputFileDiags_24s894(heff_dup(v_cs_247)));
  return heff_clo(g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100_lam0, 2, 9, (V[]){v_c_248, heff_dup(v_badL_246), v_cs_247, heff_dup(v_sources_240), v_host_241, v_file_242, v_name_243, v_outPath_244, v_done_245});
}
V g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[0]); heff_drop(a[6]); return r;
}
V g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_badL_246 = heff_dup(heff_env(self)[0]);
  V v_hd_249 = heff_dup(heff_env(self)[1]);
  V v_k_2410 = heff_dup(heff_env(self)[2]);
  V v_cs_247 = heff_dup(heff_env(self)[3]);
  V v_sources_240 = heff_dup(heff_env(self)[4]);
  V v_host_241 = heff_dup(heff_env(self)[5]);
  V v_file_242 = heff_dup(heff_env(self)[6]);
  V v_name_243 = heff_dup(heff_env(self)[7]);
  V v_outPath_244 = heff_dup(heff_env(self)[8]);
  V v_done_245 = heff_dup(heff_env(self)[9]);
  heff_drop(self);
  heff_drop(v_x_2411);
  switch (heff_tag_of(v_badL_246)) {
  case TAG_True: {
    heff_drop(v_badL_246);
    heff_drop(v_cs_247);
    heff_drop(v_sources_240);
    heff_drop(v_host_241);
    heff_drop(v_file_242);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    V v_t_2412 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2414}));
    return heff_tail(heff_get(v_hd_249, LBL_bind), 2, (V[]){v_t_2415, v_k_2410});
  }
  case TAG_False: {
    heff_drop(v_badL_246);
    V v_t_2416 = (g_prelude_2eany_24s820(v_cs_247));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      heff_drop(v_cs_247);
      heff_drop(v_sources_240);
      heff_drop(v_host_241);
      heff_drop(v_file_242);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      heff_drop(v_t_2416);
      V v_t_2417 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2419}));
      return heff_tail(heff_get(v_hd_249, LBL_bind), 2, (V[]){v_t_2420, v_k_2410});
    }
    case TAG_False: {
      heff_drop(v_t_2416);
      V v_t_2421 = ({ V a_0 = v_sources_240; V a_1 = v_host_241; V a_2 = v_file_242; V a_3 = v_name_243; V a_4 = v_outPath_244; V a_5 = v_done_245; V a_6 = v_cs_247; V r_ = (g_heff_2ecommands_2ecompileLast_24s897_24s1016_24s1101(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sources_240); heff_drop(v_cs_247); r_; });
      return heff_tail(v_t_2421, 2, (V[]){v_hd_249, v_k_2410});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_badL_246);
  }
}
V g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_dup(heff_env(self)[0]);
  V v_badL_246 = heff_dup(heff_env(self)[1]);
  V v_cs_247 = heff_dup(heff_env(self)[2]);
  V v_sources_240 = heff_dup(heff_env(self)[3]);
  V v_host_241 = heff_dup(heff_env(self)[4]);
  V v_file_242 = heff_dup(heff_env(self)[5]);
  V v_name_243 = heff_dup(heff_env(self)[6]);
  V v_outPath_244 = heff_dup(heff_env(self)[7]);
  V v_done_245 = heff_dup(heff_env(self)[8]);
  heff_drop(self);
  return heff_tail(v_c_248, 2, (V[]){heff_dup(v_hd_249), heff_clo(g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100_lam1, 1, 10, (V[]){v_badL_246, v_hd_249, v_k_2410, v_cs_247, v_sources_240, v_host_241, v_file_242, v_name_243, v_outPath_244, v_done_245})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {109, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam4(V self, V *args); static Clo g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam4, 1, 0};
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam3(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam6(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam5(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam2(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam1(V self, V *args);
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam0(V self, V *args);
Clo g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_entry, 4, 0};

V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099(V v_file_240, V v_progArgs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecommands_2eload_24s861_24s1007_24s1079(heff_dup(v_file_240), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam0, 1, 4, (V[]){v_hd_242, v_file_240, v_progArgs_241, v_k_243})));
}
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam4(V self, V *args) {
  V v_ok_2411 = args[0];
  heff_drop(self);
  return v_ok_2411;
}
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam3(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_path_248 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_248, ((V)&g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam4_clo)})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(v_hd_249, LBL_bind), 2, (V[]){v_t_2414, v_k2_2410});
}
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam6(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k2_2421 = args[1];
  V v_as_2419 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2422 = heff_tag(TAG_Exec, 3, (V[]){((V)&g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_str3), v_as_2419, NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2420), LBL_malg), 1, (V[]){v_t_2424}));
  return heff_tail(heff_get(v_hd_2420, LBL_bind), 2, (V[]){v_t_2425, v_k2_2421});
}
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_244 = heff_dup(heff_env(self)[0]);
  V v_file_240 = heff_dup(heff_env(self)[1]);
  V v_progArgs_241 = heff_dup(heff_env(self)[2]);
  V v_x_245 = heff_dup(heff_env(self)[3]);
  V v_x_247 = heff_dup(heff_env(self)[4]);
  V v_hd_242 = heff_dup(heff_env(self)[5]);
  V v_k_243 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  heff_drop(v_x_2416);
  V v_t_2417 = (g_heff_2ecommands_2erunPath(heff_get(heff_dup(v_x_244), LBL_paths), heff_dup(v_file_240)));
  V v_t_2418 = (g_heff_2ecommands_2erunPath(heff_get(heff_dup(v_x_244), LBL_paths), heff_dup(v_file_240)));
  V v_as_2419 = heff_tag(TAG_Cons, 2, (V[]){v_t_2418, v_progArgs_241});
  V v_t_2426 = ({ V b_0 = heff_get(v_x_244, LBL_sources); V a_1 = ((V)&g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_str1); V a_2 = v_file_240; V a_3 = heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_str2)}); V a_4 = v_t_2417; V a_5 = heff_clo(g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam6, 2, 1, (V[]){v_as_2419}); V b_6 = heff_intLt(MK_INT(0LL), v_x_245); V a_7 = v_x_247; V r_ = (g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100(b_0, a_1, a_2, a_3, a_4, a_5, b_6, a_7)); heff_drop(b_0); heff_drop(b_6); r_; });
  return heff_tail(v_t_2426, 2, (V[]){v_hd_242, v_k_243});
}
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_244 = heff_dup(heff_env(self)[0]);
  V v_hd_242 = heff_dup(heff_env(self)[1]);
  V v_file_240 = heff_dup(heff_env(self)[2]);
  V v_progArgs_241 = heff_dup(heff_env(self)[3]);
  V v_x_245 = heff_dup(heff_env(self)[4]);
  V v_k_243 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_path_248 = (g_heff_2ecommands_2erunDir(heff_get(heff_dup(v_x_244), LBL_paths)));
  V v_c_2415 = heff_clo(g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam3, 2, 1, (V[]){v_path_248});
  return heff_tail(v_c_2415, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam5, 1, 7, (V[]){v_x_244, v_file_240, v_progArgs_241, v_x_245, v_x_247, v_hd_242, v_k_243})});
}
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_dup(heff_env(self)[0]);
  V v_hd_242 = heff_dup(heff_env(self)[1]);
  V v_file_240 = heff_dup(heff_env(self)[2]);
  V v_progArgs_241 = heff_dup(heff_env(self)[3]);
  V v_k_243 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_c_246 = (g_heff_2esession_2ecachedProgram_24s888_24s1074(heff_dup(v_x_244)));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam2, 1, 6, (V[]){v_x_244, v_hd_242, v_file_240, v_progArgs_241, v_x_245, v_k_243})});
}
V g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_dup(heff_env(self)[0]);
  V v_file_240 = heff_dup(heff_env(self)[1]);
  V v_progArgs_241 = heff_dup(heff_env(self)[2]);
  V v_k_243 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_str0), heff_get(heff_dup(v_x_244), LBL_errors), MK_INT(0LL), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2erunCmd_24s895_24s1014_24s1099_lam1, 1, 5, (V[]){v_x_244, v_hd_242, v_file_240, v_progArgs_241, v_k_243})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam0(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam2(V self, V *args); static Clo g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam2, 1, 0};
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam5(V self, V *args); static Clo g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam5, 2, 0};
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam7(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam6(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam4(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam3(V self, V *args);
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam1(V self, V *args);
Clo g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_entry, 2, 0};

V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    V v_x_242 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
    return heff_clo(g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take(v_x1_240, 3ULL);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_MkPair: {
      V v_top_247 = heff_field(v_x11_245, 0);
      V v_p_248 = heff_field(v_x11_245, 1);
      heff_take(v_x11_245, 3ULL);
      return heff_clo(g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam1, 2, 4, (V[]){v_p_248, v_rest_246, v_acc_241, v_top_247});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106(a[0], a[1]);
}
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_243);
  return heff_tail(v_k_244, 1, (V[]){v_x_242});
}
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam2(V self, V *args) {
  V v_ns_2411 = args[0];
  heff_drop(self);
  return v_ns_2411;
}
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam5(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  heff_drop(self);
  heff_drop(v_hd_2423);
  return heff_tail(v_k_2424, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam7(V self, V *args) {
  V v_n_2429 = args[0];
  V v_x_2416 = heff_dup(heff_env(self)[0]);
  V v_p_248 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2430 = (g_std_2epath_2eparse(v_x_2416, v_p_248));
  V v_t_2431 = (g_std_2epath_2eparse(v_x_2416, v_n_2429));
  V v_p_2432 = (g_std_2epath_2ejoin_2eonto_240(v_t_2430, v_t_2431));
  V v_t_2433 = ({ V a_0 = heff_get(heff_dup(v_p_2432), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2432), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2434 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2432), LBL_drive), heff_get(v_p_2432, LBL_absolute), v_t_2433});
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_False), ({ V a_0 = v_x_2416; V a_1 = v_t_2434; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2416); r_; })});
}
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_rest_246 = heff_dup(heff_env(self)[0]);
  V v_acc_241 = heff_dup(heff_env(self)[1]);
  V v_hd_249 = heff_dup(heff_env(self)[2]);
  V v_k_2410 = heff_dup(heff_env(self)[3]);
  V v_ns_2422 = heff_dup(heff_env(self)[4]);
  V v_x_2416 = heff_dup(heff_env(self)[5]);
  V v_p_248 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2426)) {
  case TAG_True: {
    heff_drop(v_x_2426);
    heff_drop(v_ns_2422);
    heff_drop(v_x_2416);
    heff_drop(v_p_248);
    V v_t_2427 = (g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106(v_rest_246, v_acc_241));
    return heff_tail(v_t_2427, 2, (V[]){v_hd_249, v_k_2410});
  }
  case TAG_False: {
    heff_drop(v_x_2426);
    V v_t_2428 = (g_prelude_2efilter_24s827(v_ns_2422));
    V v_t_2435 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam7, 1, 2, (V[]){v_x_2416, v_p_248}), v_t_2428));
    V v_t_2436 = (g_prelude_2econcatList(v_t_2435, v_rest_246));
    V v_t_2437 = (g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106(v_t_2436, v_acc_241));
    return heff_tail(v_t_2437, 2, (V[]){v_hd_249, v_k_2410});
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2415 = heff_dup(heff_env(self)[0]);
  V v_p_248 = heff_dup(heff_env(self)[1]);
  V v_rest_246 = heff_dup(heff_env(self)[2]);
  V v_acc_241 = heff_dup(heff_env(self)[3]);
  V v_hd_249 = heff_dup(heff_env(self)[4]);
  V v_k_2410 = heff_dup(heff_env(self)[5]);
  V v_top_247 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    heff_drop(v_x_2416);
    heff_drop(v_x_2415);
    heff_drop(v_top_247);
    V v_t_2417 = heff_intSub(heff_strLength(heff_dup(v_p_248)), MK_INT(3LL));
    V v_t_2418 = heff_strSlice(heff_dup(v_p_248), v_t_2417, heff_strLength(heff_dup(v_p_248)));
    V v_t_2419 = heff_strEq(v_t_2418, ((V)&g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_str0));
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      heff_drop(v_t_2419);
      V v_t_2420 = (g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106(v_rest_246, heff_tag(TAG_Cons, 2, (V[]){v_p_248, v_acc_241})));
      return heff_tail(v_t_2420, 2, (V[]){v_hd_249, v_k_2410});
    }
    case TAG_False: {
      heff_drop(v_p_248);
      heff_drop(v_t_2419);
      V v_t_2421 = (g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106(v_rest_246, v_acc_241));
      return heff_tail(v_t_2421, 2, (V[]){v_hd_249, v_k_2410});
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  case TAG_Just: {
    V v_ns_2422 = heff_field(v_x_2415, 0);
    heff_take(v_x_2415, 1ULL);
    V v_c_2425;
    switch (heff_tag_of(v_top_247)) {
    case TAG_True: {
      heff_drop(v_top_247);
      v_c_2425 = ((V)&g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam5_clo);
      break;
    }
    case TAG_False: {
      heff_drop(v_top_247);
      v_c_2425 = (g_heff_2eload_2eisRoot_24s870_24s1084(v_x_2416, heff_dup(v_p_248)));
      break;
    }
    default: heff_nomatch(v_top_247);
    }
    return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_hd_249), heff_clo(g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam6, 1, 7, (V[]){v_rest_246, v_acc_241, v_hd_249, v_k_2410, v_ns_2422, v_x_2416, v_p_248})});
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_249 = heff_dup(heff_env(self)[0]);
  V v_p_248 = heff_dup(heff_env(self)[1]);
  V v_rest_246 = heff_dup(heff_env(self)[2]);
  V v_acc_241 = heff_dup(heff_env(self)[3]);
  V v_k_2410 = heff_dup(heff_env(self)[4]);
  V v_top_247 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  return (g_heff_2ecommands_2estyleNow_24s864_24s1010(heff_dup(v_hd_249), heff_clo(g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam4, 1, 7, (V[]){v_x_2415, v_p_248, v_rest_246, v_acc_241, v_hd_249, v_k_2410, v_top_247})));
}
V g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_p_248 = heff_dup(heff_env(self)[0]);
  V v_rest_246 = heff_dup(heff_env(self)[1]);
  V v_acc_241 = heff_dup(heff_env(self)[2]);
  V v_top_247 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){heff_dup(v_p_248), ((V)&g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam2_clo)})});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get(heff_dup(v_hd_249), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecommands_2etestFilesGo_24s903_24s1019_24s1106_lam3, 1, 6, (V[]){v_hd_249, v_p_248, v_rest_246, v_acc_241, v_k_2410, v_top_247})});
}
V g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam3(V self, V *args); static Clo g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam3, 1, 0};
V g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam2(V self, V *args);
V g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam4(V self, V *args);
V g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam1(V self, V *args);
V g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam0(V self, V *args);
Clo g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_entry, 3, 0};

V g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110(V v_file_240, V v_badL_241, V v_cs_242) {
top: ;
  V v_c_243 = (g_heff_2ecommands_2eputFileDiags_24s894(heff_dup(v_cs_242)));
  return heff_clo(g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam0, 2, 4, (V[]){v_c_243, v_cs_242, heff_dup(v_badL_241), v_file_240});
}
V g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam3(V self, V *args) {
  V v_ok_2424 = args[0];
  heff_drop(self);
  return v_ok_2424;
}
V g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k2_2423 = args[1];
  V v_file_240 = heff_dup(heff_env(self)[0]);
  V v_str_2421 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2425 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){v_file_240, v_str_2421, ((V)&g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam3_clo)})});
  V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2422), LBL_malg), 1, (V[]){v_t_2426}));
  return heff_tail(heff_get(v_hd_2422, LBL_bind), 2, (V[]){v_t_2427, v_k2_2423});
}
V g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_245 = heff_dup(heff_env(self)[0]);
  V v_hd_244 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2429)) {
  case TAG_True: {
    heff_drop(v_x_2429);
    heff_drop(v_hd_244);
    return heff_tail(v_k_245, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_False: {
    heff_drop(v_x_2429);
    V v_t_2430 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2432}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2433, v_k_245});
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_cs_242 = heff_dup(heff_env(self)[0]);
  V v_hd_244 = heff_dup(heff_env(self)[1]);
  V v_k_245 = heff_dup(heff_env(self)[2]);
  V v_badL_241 = heff_dup(heff_env(self)[3]);
  V v_file_240 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_246);
  V v_t_247 = (g_heff_2edriver_2elastChecked(v_cs_242));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_cs_242);
    heff_drop(v_badL_241);
    heff_drop(v_file_240);
    heff_drop(v_t_247);
    V v_t_248 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2410}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2411, v_k_245});
  }
  case TAG_Just: {
    V v_c_2412 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24Just = heff_take_reuse(v_t_247, 1ULL);
    V v_t_2413;
    switch (heff_tag_of(v_badL_241)) {
    case TAG_True: {
      heff_drop(v_cs_242);
      heff_drop(v_badL_241);
      v_t_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      heff_drop(v_badL_241);
      v_t_2413 = ({ V a_0 = v_cs_242; V r_ = (g_prelude_2eany_24s820(a_0)); heff_drop(v_cs_242); r_; });
      break;
    }
    default: heff_nomatch(v_badL_241);
    }
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      heff_drop(v_file_240);
      heff_drop(v_c_2412);
      heff_drop(v_t_2413);
      V v_t_2414 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2415 = heff_tag_at(v_ru_24t_247_24Just, TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2416}));
      return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2417, v_k_245});
    }
    case TAG_False: {
      heff_drop(v_ru_24t_247_24Just);
      heff_drop(v_t_2413);
      V v_t_2418 = heff_get(heff_get(heff_dup(v_c_2412), LBL_top), LBL_watches);
      V v_xs_2419 = (g_heff_2edriver_2ewatchesGo(heff_dup(v_c_2412), MK_INT(0LL), v_t_2418));
      V v_t_2420 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2419));
      V v_str_2421 = ({ V a_0 = heff_get(v_c_2412, LBL_source); V a_1 = v_t_2420; V r_ = (g_prelude_2efoldl_24s514(a_0, a_1)); heff_drop(v_t_2420); r_; });
      V v_c_2428 = heff_clo(g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam2, 2, 2, (V[]){v_file_240, v_str_2421});
      return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam4, 1, 2, (V[]){v_k_245, v_hd_244})});
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_dup(heff_env(self)[0]);
  V v_cs_242 = heff_dup(heff_env(self)[1]);
  V v_badL_241 = heff_dup(heff_env(self)[2]);
  V v_file_240 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_243, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110_lam1, 1, 5, (V[]){v_cs_242, v_hd_244, v_k_245, v_badL_241, v_file_240})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_lam2(V self, V *args);
V g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_lam1(V self, V *args);
V g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_lam0(V self, V *args);
Clo g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_entry, 3, 0};

V g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109(V v_file_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecommands_2eload_24s861_24s1007_24s1079(heff_dup(v_file_240), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_lam0, 1, 3, (V[]){v_hd_241, v_file_240, v_k_242})));
}
V g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_file_240 = heff_dup(heff_env(self)[0]);
  V v_x_244 = heff_dup(heff_env(self)[1]);
  V v_hd_241 = heff_dup(heff_env(self)[2]);
  V v_k_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_247 = ({ V a_0 = v_file_240; V b_1 = heff_intLt(MK_INT(0LL), v_x_244); V a_2 = v_x_246; V r_ = (g_heff_2ecommands_2epromoteDiags_24s912_24s1023_24s1110(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return heff_tail(v_t_247, 2, (V[]){v_hd_241, v_k_242});
}
V g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_x_243 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_file_240 = heff_dup(heff_env(self)[2]);
  V v_k_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_c_245 = (g_heff_2esession_2ecachedProgram_24s888_24s1074(v_x_243));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_lam2, 1, 4, (V[]){v_file_240, v_x_244, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_file_240 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_str0), heff_get(heff_dup(v_x_243), LBL_errors), MK_INT(0LL), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2epromoteCmd_24s911_24s1022_24s1109_lam1, 1, 4, (V[]){v_x_243, v_hd_241, v_file_240, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_entry, 7, 0};

V g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112(V v_host_240, V v_name_241, V v_outPath_242, V v_file_243, V v_done_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2ecommands_2eload_24s861_24s1007_24s1079(heff_dup(v_file_243), heff_dup(v_hd_245), heff_clo(g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_lam0, 1, 7, (V[]){v_hd_245, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_246})));
}
V g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_247 = heff_dup(heff_env(self)[0]);
  V v_host_240 = heff_dup(heff_env(self)[1]);
  V v_file_243 = heff_dup(heff_env(self)[2]);
  V v_name_241 = heff_dup(heff_env(self)[3]);
  V v_outPath_242 = heff_dup(heff_env(self)[4]);
  V v_done_244 = heff_dup(heff_env(self)[5]);
  V v_x_248 = heff_dup(heff_env(self)[6]);
  V v_hd_245 = heff_dup(heff_env(self)[7]);
  V v_k_246 = heff_dup(heff_env(self)[8]);
  heff_drop(self);
  V v_t_2411 = ({ V b_0 = heff_get(v_x_247, LBL_sources); V a_1 = v_host_240; V a_2 = v_file_243; V a_3 = v_name_241; V a_4 = v_outPath_242; V a_5 = v_done_244; V b_6 = heff_intLt(MK_INT(0LL), v_x_248); V a_7 = v_x_2410; V r_ = (g_heff_2ecommands_2ecompileDiags_24s896_24s1015_24s1100(b_0, a_1, a_2, a_3, a_4, a_5, b_6, a_7)); heff_drop(b_0); heff_drop(b_6); r_; });
  return heff_tail(v_t_2411, 2, (V[]){v_hd_245, v_k_246});
}
V g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_dup(heff_env(self)[0]);
  V v_hd_245 = heff_dup(heff_env(self)[1]);
  V v_host_240 = heff_dup(heff_env(self)[2]);
  V v_file_243 = heff_dup(heff_env(self)[3]);
  V v_name_241 = heff_dup(heff_env(self)[4]);
  V v_outPath_242 = heff_dup(heff_env(self)[5]);
  V v_done_244 = heff_dup(heff_env(self)[6]);
  V v_k_246 = heff_dup(heff_env(self)[7]);
  heff_drop(self);
  V v_c_249 = (g_heff_2esession_2ecachedProgram_24s888_24s1074(heff_dup(v_x_247)));
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_hd_245), heff_clo(g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_lam2, 1, 9, (V[]){v_x_247, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_x_248, v_hd_245, v_k_246})});
}
V g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_245 = heff_dup(heff_env(self)[0]);
  V v_host_240 = heff_dup(heff_env(self)[1]);
  V v_file_243 = heff_dup(heff_env(self)[2]);
  V v_name_241 = heff_dup(heff_env(self)[3]);
  V v_outPath_242 = heff_dup(heff_env(self)[4]);
  V v_done_244 = heff_dup(heff_env(self)[5]);
  V v_k_246 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_str0), heff_get(heff_dup(v_x_247), LBL_errors), MK_INT(0LL), heff_dup(v_hd_245), heff_clo(g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_lam1, 1, 8, (V[]){v_x_247, v_hd_245, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_246})));
}
V g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_lam0(V self, V *args); static Clo g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_lam0, 1, 0};
V g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_lam1(V self, V *args);
Clo g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_entry, 5, 0};

V g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115(V v_outPath_240, V v_bad_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag(TAG_WriteFile, 3, (V[]){v_outPath_240, heff_get(heff_dup(v_o_242), LBL_source), ((V)&g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_lam0_clo)});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_lam1, 1, 4, (V[]){v_o_242, v_hd_243, heff_dup(v_bad_241), v_k_244})});
}
V g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_lam0(V self, V *args) {
  V v_ok_245 = args[0];
  heff_drop(self);
  return v_ok_245;
}
V g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_dup(heff_env(self)[0]);
  V v_bad_241 = heff_dup(heff_env(self)[1]);
  V v_hd_243 = heff_dup(heff_env(self)[2]);
  V v_k_244 = heff_dup(heff_env(self)[3]);
  V v_o_242 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_2410);
  switch (heff_tag_of(v_x_249)) {
  case TAG_True: {
    heff_drop(v_x_249);
    switch (heff_tag_of(v_bad_241)) {
    case TAG_True: {
      heff_drop(v_bad_241);
      heff_drop(v_o_242);
      V v_t_2411 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2413}));
      return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2414, v_k_244});
    }
    case TAG_False: {
      heff_drop(v_bad_241);
      V v_t_2415 = heff_get(v_o_242, LBL_errors);
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nil: {
        heff_drop(v_hd_243);
        heff_drop(v_t_2415);
        return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_Cons: {
        V v_ru_24t_2415_24Cons = heff_take_reuse(v_t_2415, 0ULL);
        V v_t_2418 = heff_tag_at(v_ru_24t_2415_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2418})});
        V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
        V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2420}));
        return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2421, v_k_244});
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    default: return heff_nomatch(v_bad_241);
    }
  }
  case TAG_False: {
    heff_drop(v_x_249);
    heff_drop(v_bad_241);
    heff_drop(v_o_242);
    V v_t_2422 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2424}));
    return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_2425, v_k_244});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_o_242 = heff_dup(heff_env(self)[0]);
  V v_hd_243 = heff_dup(heff_env(self)[1]);
  V v_bad_241 = heff_dup(heff_env(self)[2]);
  V v_k_244 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return (g_heff_2ecommands_2eemitErrs_24s902(heff_get(heff_dup(v_o_242), LBL_errors), heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115_lam2, 1, 5, (V[]){v_x_249, v_bad_241, v_hd_243, v_k_244, v_o_242})));
}
V g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114_entry, 4, 0};

V g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114(V v_file_240, V v_outPath_241, V v_badL_242, V v_cs_243) {
top: ;
  V v_c_244 = (g_heff_2ecommands_2eputFileDiags_24s894(heff_dup(v_cs_243)));
  return heff_clo(g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114_lam0, 2, 4, (V[]){v_c_244, v_cs_243, heff_dup(v_badL_242), v_outPath_241});
}
V g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[2]); return r;
}
V g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_cs_243 = heff_dup(heff_env(self)[0]);
  V v_hd_245 = heff_dup(heff_env(self)[1]);
  V v_k_246 = heff_dup(heff_env(self)[2]);
  V v_badL_242 = heff_dup(heff_env(self)[3]);
  V v_outPath_241 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_247);
  V v_t_248 = (g_heff_2edriver_2elastChecked(v_cs_243));
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop(v_cs_243);
    heff_drop(v_badL_242);
    heff_drop(v_outPath_241);
    heff_drop(v_t_248);
    V v_t_249 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2411}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2412, v_k_246});
  }
  case TAG_Just: {
    V v_c_2413 = heff_field(v_t_248, 0);
    heff_take(v_t_248, 1ULL);
    V v_t_2414;
    switch (heff_tag_of(v_badL_242)) {
    case TAG_True: {
      heff_drop(v_cs_243);
      heff_drop(v_badL_242);
      v_t_2414 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      heff_drop(v_badL_242);
      v_t_2414 = ({ V a_0 = v_cs_243; V r_ = (g_prelude_2eany_24s820(a_0)); heff_drop(v_cs_243); r_; });
      break;
    }
    default: heff_nomatch(v_badL_242);
    }
    V v_t_2415 = heff_get(heff_get(heff_dup(v_c_2413), LBL_top), LBL_globals);
    V v_t_2416 = (g_prelude_2emap_24s821(heff_get(v_c_2413, LBL_own)));
    V v_t_2417 = (g_heff_2eemit_2ecompileJs(v_t_2415, v_t_2416));
    return ({ V a_0 = v_outPath_241; V a_1 = v_t_2414; V a_2 = v_t_2417; V a_3 = v_hd_245; V a_4 = v_k_246; V r_ = (g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2414); r_; });
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_dup(heff_env(self)[0]);
  V v_cs_243 = heff_dup(heff_env(self)[1]);
  V v_badL_242 = heff_dup(heff_env(self)[2]);
  V v_outPath_241 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_244, 2, (V[]){heff_dup(v_hd_245), heff_clo(g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114_lam1, 1, 5, (V[]){v_cs_243, v_hd_245, v_k_246, v_badL_242, v_outPath_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_entry, 4, 0};

V g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113(V v_file_240, V v_outPath_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecommands_2eload_24s861_24s1007_24s1079(heff_dup(v_file_240), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_lam0, 1, 4, (V[]){v_hd_242, v_file_240, v_outPath_241, v_k_243})));
}
V g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_file_240 = heff_dup(heff_env(self)[0]);
  V v_outPath_241 = heff_dup(heff_env(self)[1]);
  V v_x_245 = heff_dup(heff_env(self)[2]);
  V v_hd_242 = heff_dup(heff_env(self)[3]);
  V v_k_243 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_248 = ({ V a_0 = v_file_240; V a_1 = v_outPath_241; V b_2 = heff_intLt(MK_INT(0LL), v_x_245); V a_3 = v_x_247; V r_ = (g_heff_2ecommands_2ecompileJsDiags_24s915_24s1027_24s1114(a_0, a_1, b_2, a_3)); heff_drop(v_file_240); heff_drop(b_2); r_; });
  return heff_tail(v_t_248, 2, (V[]){v_hd_242, v_k_243});
}
V g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_dup(heff_env(self)[0]);
  V v_hd_242 = heff_dup(heff_env(self)[1]);
  V v_file_240 = heff_dup(heff_env(self)[2]);
  V v_outPath_241 = heff_dup(heff_env(self)[3]);
  V v_k_243 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_c_246 = (g_heff_2esession_2ecachedProgram_24s888_24s1074(v_x_244));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_lam2, 1, 5, (V[]){v_file_240, v_outPath_241, v_x_245, v_hd_242, v_k_243})});
}
V g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_dup(heff_env(self)[0]);
  V v_file_240 = heff_dup(heff_env(self)[1]);
  V v_outPath_241 = heff_dup(heff_env(self)[2]);
  V v_k_243 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_str0), heff_get(heff_dup(v_x_244), LBL_errors), MK_INT(0LL), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_lam1, 1, 5, (V[]){v_x_244, v_hd_242, v_file_240, v_outPath_241, v_k_243})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ereadProviderC_24s921_24s1120_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2ereadProviderC_24s921_24s1120_str1 = {{0x80000000u, K_STR, 0}, 11, 11, {46, 112, 114, 111, 118, 105, 100, 101, 114, 46, 99}};
V g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam0, 2, 0};
V g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam2(V self, V *args); static Clo g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam2, 1, 0};
V g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam1(V self, V *args);
V g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam4(V self, V *args);
V g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam3(V self, V *args);
Clo g_heff_2ecommands_2ereadProviderC_24s921_24s1120_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProviderC_24s921_24s1120_entry, 2, 0};

V g_heff_2ecommands_2ereadProviderC_24s921_24s1120(V v_sources_240, V v_m_241) {
top: ;
  V v_t_242 = (g_heff_2ecommands_2epathOfModule(v_sources_240, heff_dup(v_m_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    heff_drop(v_t_242);
    return ((V)&g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam0_clo);
  }
  case TAG_Just: {
    V v_path_245 = heff_field(v_t_242, 0);
    heff_take(v_t_242, 1ULL);
    V v_t_246 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
    V v_t_247 = heff_strSlice(heff_dup(v_path_245), v_t_246, heff_strLength(heff_dup(v_path_245)));
    V v_t_248 = heff_strEq(v_t_247, ((V)&g_heff_2ecommands_2ereadProviderC_24s921_24s1120_str0));
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_t_248);
      V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
      v_t_2410 = heff_strSlice(v_path_245, MK_INT(0LL), v_t_249);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_248);
      v_t_2410 = v_path_245;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_path_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2ecommands_2ereadProviderC_24s921_24s1120_str1));
    V v_c_2418 = heff_clo(g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam1, 2, 1, (V[]){v_path_2411});
    return heff_clo(g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam3, 2, 2, (V[]){v_c_2418, v_m_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecommands_2ereadProviderC_24s921_24s1120_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ereadProviderC_24s921_24s1120(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(self);
  heff_drop(v_hd_243);
  return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_Nothing)});
}
V g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  heff_drop(self);
  return v_t_2414;
}
V g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_path_2411 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2415 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam2_clo)})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get(v_hd_2412, LBL_bind), 2, (V[]){v_t_2417, v_k2_2413});
}
V g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_m_241 = heff_dup(heff_env(self)[0]);
  V v_k_2420 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_x_2423;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    heff_drop(v_x_2421);
    heff_drop(v_m_241);
    v_x_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2422 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Just = heff_take_reuse(v_x_2421, 1ULL);
    v_x_2423 = heff_tag_at(v_ru_24x_2421_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_184_321, (V[]){v_m_241, v_t_2422})});
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  return heff_tail(v_k_2420, 1, (V[]){v_x_2423});
}
V g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_dup(heff_env(self)[0]);
  V v_m_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2418, 2, (V[]){v_hd_2419, heff_clo(g_heff_2ecommands_2ereadProviderC_24s921_24s1120_lam4, 1, 2, (V[]){v_m_241, v_k_2420})});
}
V g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_lam0, 2, 0};
V g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_lam3(V self, V *args);
V g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_lam2(V self, V *args);
V g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_lam1(V self, V *args);
Clo g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_entry, 2, 0};

V g_heff_2ecommands_2ereadProvidersC_24s920_24s1119(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return ((V)&g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take(v_x2_241, 3ULL);
    V v_c_246 = (g_heff_2ecommands_2ereadProviderC_24s921_24s1120(v_sources_240, v_m_244));
    return heff_clo(g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_lam1, 2, 3, (V[]){v_c_246, heff_dup(v_sources_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ereadProvidersC_24s920_24s1119(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(self);
  heff_drop(v_hd_242);
  return heff_tail(v_k_243, 1, (V[]){NTAG(TAG_Nil)});
}
V g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_dup(heff_env(self)[0]);
  V v_k_248 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_x_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop(v_x_249);
    v_x_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take(v_x_249, 1ULL);
    v_x_2413 = heff_tag(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  return heff_tail(v_k_248, 1, (V[]){v_x_2413});
}
V g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_dup(heff_env(self)[0]);
  V v_rest_245 = heff_dup(heff_env(self)[1]);
  V v_hd_247 = heff_dup(heff_env(self)[2]);
  V v_k_248 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_c_2410 = ({ V a_0 = v_sources_240; V a_1 = v_rest_245; V r_ = (g_heff_2ecommands_2ereadProvidersC_24s920_24s1119(a_0, a_1)); heff_drop(v_sources_240); r_; });
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo(g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_lam3, 1, 2, (V[]){v_x_249, v_k_248})});
}
V g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_dup(heff_env(self)[0]);
  V v_sources_240 = heff_dup(heff_env(self)[1]);
  V v_rest_245 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2ereadProvidersC_24s920_24s1119_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248})});
}
V g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_lam2(V self, V *args); static Clo g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_lam2, 1, 0};
V g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_lam1(V self, V *args);
V g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_lam3(V self, V *args);
V g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_lam0(V self, V *args);
Clo g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_entry, 4, 0};

V g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_name_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      return (g_heff_2ecommands_2estyleNow_24s864_24s1010(heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_lam0, 1, 6, (V[]){v_dir_240, heff_dup(v_name_246), heff_dup(v_text_247), v_p_242, heff_dup(v_rest_245), v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_lam2(V self, V *args) {
  V v_ok_2417 = args[0];
  heff_drop(self);
  return v_ok_2417;
}
V g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_path_2414 = heff_dup(heff_env(self)[0]);
  V v_text_247 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){v_path_2414, v_text_247, ((V)&g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_lam2_clo)})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2415), LBL_malg), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get(v_hd_2415, LBL_bind), 2, (V[]){v_t_2420, v_k2_2416});
}
V g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_dir_240 = heff_dup(heff_env(self)[0]);
  V v_rest_245 = heff_dup(heff_env(self)[1]);
  V v_p_242 = heff_dup(heff_env(self)[2]);
  V v_p_243 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2422)) {
  case TAG_True: {
    heff_drop(v_x_2422);
    return ({ V a_0 = v_dir_240; V a_1 = v_rest_245; V a_2 = v_p_242; V a_3 = v_p_243; V r_ = (g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
  }
  case TAG_False: {
    heff_drop(v_x_2422);
    heff_drop(v_dir_240);
    heff_drop(v_rest_245);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_False)});
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_dir_240 = heff_dup(heff_env(self)[0]);
  V v_name_246 = heff_dup(heff_env(self)[1]);
  V v_text_247 = heff_dup(heff_env(self)[2]);
  V v_p_242 = heff_dup(heff_env(self)[3]);
  V v_rest_245 = heff_dup(heff_env(self)[4]);
  V v_p_243 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_t_249 = (g_std_2epath_2eparse(v_x_248, heff_dup(v_dir_240)));
  V v_t_2410 = (g_std_2epath_2eparse(v_x_248, v_name_246));
  V v_p_2411 = (g_std_2epath_2ejoin_2eonto_240(v_t_249, v_t_2410));
  V v_t_2412 = ({ V a_0 = heff_get(heff_dup(v_p_2411), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2411), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2413 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2411), LBL_drive), heff_get(v_p_2411, LBL_absolute), v_t_2412});
  V v_path_2414 = ({ V a_0 = v_x_248; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_248); r_; });
  V v_c_2421 = heff_clo(g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_lam1, 2, 2, (V[]){v_path_2414, v_text_247});
  return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123_lam3, 1, 4, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam1(V self, V *args); static Clo g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam1, 1, 0};
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam3(V self, V *args); static Clo g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam3, 1, 0};
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam6(V self, V *args);
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam5(V self, V *args);
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam4(V self, V *args);
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam2(V self, V *args);
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam0(V self, V *args);
Clo g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_entry, 5, 0};

V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122(V v_dir_240, V v_done_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_parts_245 = heff_field(v_x3_242, 0);
    V v_errors_246 = heff_field(v_x3_242, 1);
    heff_take(v_x3_242, 3ULL);
    return (g_heff_2ecommands_2eemitErrs_24s902(heff_dup(v_errors_246), heff_dup(v_p_243), heff_clo(g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam0, 1, 6, (V[]){v_errors_246, v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam1(V self, V *args) {
  V v_ok_2411 = args[0];
  heff_drop(self);
  return v_ok_2411;
}
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam3(V self, V *args) {
  V v_ok_2416 = args[0];
  heff_drop(self);
  return v_ok_2416;
}
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_p_243 = heff_dup(heff_env(self)[0]);
  V v_p_244 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2430}));
  return heff_tail(heff_get(v_p_243, LBL_bind), 2, (V[]){v_t_2431, v_p_244});
}
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_done_241 = heff_dup(heff_env(self)[0]);
  V v_p_243 = heff_dup(heff_env(self)[1]);
  V v_p_244 = heff_dup(heff_env(self)[2]);
  V v_dir_240 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2421)) {
  case TAG_True: {
    heff_drop(v_x_2421);
    heff_drop(v_dir_240);
    return heff_tail(v_done_241, 2, (V[]){v_p_243, v_p_244});
  }
  case TAG_False: {
    heff_drop(v_x_2421);
    heff_drop(v_done_241);
    V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_str0), v_dir_240), ((V)&g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_str1));
    V v_t_2423 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2422, NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2425}));
    return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2426, heff_clo(g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam6, 1, 2, (V[]){v_p_243, v_p_244})});
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_dir_240 = heff_dup(heff_env(self)[0]);
  V v_parts_245 = heff_dup(heff_env(self)[1]);
  V v_p_243 = heff_dup(heff_env(self)[2]);
  V v_done_241 = heff_dup(heff_env(self)[3]);
  V v_p_244 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_2420);
  return ({ V a_0 = heff_dup(v_dir_240); V a_1 = v_parts_245; V a_2 = heff_dup(v_p_243); V a_3 = heff_clo(g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam5, 1, 4, (V[]){v_done_241, v_p_243, v_p_244, v_dir_240}); V r_ = (g_heff_2ecommands_2ewritePartsGo_24s925_24s1035_24s1123(a_0, a_1, a_2, a_3)); heff_drop(v_parts_245); r_; });
}
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_dir_240 = heff_dup(heff_env(self)[0]);
  V v_p_243 = heff_dup(heff_env(self)[1]);
  V v_parts_245 = heff_dup(heff_env(self)[2]);
  V v_done_241 = heff_dup(heff_env(self)[3]);
  V v_p_244 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_2415);
  V v_t_2417 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){heff_dup(v_dir_240), ((V)&g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam3_clo)})});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2419, heff_clo(g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam4, 1, 5, (V[]){v_dir_240, v_parts_245, v_p_243, v_done_241, v_p_244})});
}
V g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_errors_246 = heff_dup(heff_env(self)[0]);
  V v_dir_240 = heff_dup(heff_env(self)[1]);
  V v_p_243 = heff_dup(heff_env(self)[2]);
  V v_parts_245 = heff_dup(heff_env(self)[3]);
  V v_done_241 = heff_dup(heff_env(self)[4]);
  V v_p_244 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  heff_drop(v_x_247);
  V v_t_2410;
  switch (heff_tag_of(v_errors_246)) {
  case TAG_Nil: {
    heff_drop(v_errors_246);
    v_t_2410 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take(v_errors_246, 0ULL);
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_errors_246);
  }
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_t_2410);
    V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){heff_dup(v_dir_240), ((V)&g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam1_clo)})});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2413}));
    return heff_tail(heff_get(heff_dup(v_p_243), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_lam2, 1, 5, (V[]){v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})});
  }
  case TAG_False: {
    heff_drop(v_dir_240);
    heff_drop(v_parts_245);
    heff_drop(v_done_241);
    heff_drop(v_t_2410);
    V v_t_2432 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tr(heff_apply(heff_get(heff_dup(v_p_243), LBL_malg), 1, (V[]){v_t_2434}));
    return heff_tail(heff_get(v_p_243, LBL_bind), 2, (V[]){v_t_2435, v_p_244});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
V g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_lam0(V self, V *args);
V g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_lam2(V self, V *args);
V g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_lam1(V self, V *args);
Clo g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_entry, 7, 0};

V g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121(V v_file_240, V v_name_241, V v_outPath_242, V v_runtime_243, V v_done_244, V v_c_245, V v_available_246) {
top: ;
  V v_t_247 = (g_heff_2edriver_2ecandidatesOf(heff_dup(v_c_245)));
  V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_heff_2edriver_2enubStrD(v_t_248));
  V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_lam0, 1, 1, (V[]){heff_dup(v_available_246)}), v_t_249));
  V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = heff_dup(v_c_245); V a_2 = v_name_241; V r_ = (g_heff_2edriver_2efindRunnable(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Left: {
    V v_why_2413 = heff_field(v_t_2412, 0);
    heff_take(v_t_2412, 1ULL);
    heff_drop(v_outPath_242);
    heff_drop(v_runtime_243);
    heff_drop(v_done_244);
    heff_drop(v_c_245);
    heff_drop(v_available_246);
    return heff_clo(g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_lam1, 2, 2, (V[]){v_file_240, v_why_2413});
  }
  case TAG_Right: {
    V v_r_2426 = heff_field(v_t_2412, 0);
    heff_take(v_t_2412, 1ULL);
    heff_drop(v_file_240);
    V v_t_2427 = heff_intSub(heff_strLength(heff_dup(v_outPath_242)), MK_INT(1LL));
    V v_t_2428 = heff_strSlice(heff_dup(v_outPath_242), v_t_2427, heff_strLength(heff_dup(v_outPath_242)));
    V v_t_2429 = heff_strEq(v_t_2428, ((V)&g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_str3));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      heff_drop(v_t_2429);
      V v_t_2430 = heff_intSub(heff_strLength(heff_dup(v_outPath_242)), MK_INT(1LL));
      V v_t_2431 = heff_get(heff_get(v_c_245, LBL_top), LBL_globals);
      V v_l_2432 = (g_heff_2elower_2elowerProgramAnf(v_t_2431, heff_get(heff_dup(v_r_2426), LBL_key)));
      V v_t_2433 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2erunEnd_clo), 1, (V[]){heff_get(v_r_2426, LBL_effect)}));
      V v_t_2434 = heff_rec(2, shape_242_78, (V[]){NTAG(TAG_Nil), v_t_2433});
      V v_t_2435 = (g_heff_2eemitc_2eprogramParts(v_runtime_243, v_available_246, v_t_2434, heff_get(heff_dup(v_l_2432), LBL_defs)));
      V v_t_2436 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2435, heff_get(v_l_2432, LBL_errors)});
      return heff_tail(((V)&g_heff_2ecommands_2ewriteParts_24s924_24s1034_24s1122_clo), 3, (V[]){heff_strSlice(v_outPath_242, MK_INT(0LL), v_t_2430), v_done_244, v_t_2436});
    }
    case TAG_False: {
      heff_drop(v_t_2429);
      V v_t_2437 = heff_tr(heff_apply(((V)&g_heff_2eemitc_2erunEnd_clo), 1, (V[]){heff_get(heff_dup(v_r_2426), LBL_effect)}));
      V v_t_2438 = heff_rec(2, shape_242_78, (V[]){NTAG(TAG_Nil), v_t_2437});
      V v_t_2439 = heff_get(heff_get(v_c_245, LBL_top), LBL_globals);
      V v_t_2440 = (g_heff_2elower_2elowerProgramAnf(v_t_2439, heff_get(v_r_2426, LBL_key)));
      V v_t_2441 = (g_heff_2eemitc_2eoutputOf(v_runtime_243, v_available_246, v_t_2438, v_t_2440));
      return heff_tail(((V)&g_heff_2ecommands_2ewriteOut_24s901_24s1018_24s1105_clo), 3, (V[]){v_outPath_242, v_done_244, v_t_2441});
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_lam0(V self, V *args) {
  V v_k_2410 = args[0];
  V v_available_246 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V a_0 = v_available_246; V a_1 = v_k_2410; V r_ = (g_heff_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_246); r_; });
}
V g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2414 = heff_dup(heff_env(self)[0]);
  V v_k_2415 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2424}));
  return heff_tail(heff_get(v_hd_2414, LBL_bind), 2, (V[]){v_t_2425, v_k_2415});
}
V g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_file_240 = heff_dup(heff_env(self)[0]);
  V v_why_2413 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_str0), heff_strAppend(v_file_240, heff_strAppend(((V)&g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_str1), v_why_2413)));
  V v_t_2417 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2416, ((V)&g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_str2)), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2414), LBL_malg), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get(heff_dup(v_hd_2414), LBL_bind), 2, (V[]){v_t_2420, heff_clo(g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121_lam2, 1, 2, (V[]){v_hd_2414, v_k_2415})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_str1 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 117, 110, 116, 105, 109, 101, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 117, 110, 116, 105, 109, 101, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_str4 = {{0x80000000u, K_STR, 0}, 22, 22, {104, 101, 102, 102, 58, 32, 110, 111, 32, 67, 32, 114, 117, 110, 116, 105, 109, 101, 32, 97, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam3(V self, V *args); static Clo g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam3, 1, 0};
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam2(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam5(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam7(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam6(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam4(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam1(V self, V *args);
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam0(V self, V *args);
Clo g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_entry, 2, 0};

V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124(V v_hd_240, V v_k_241) {
top: ;
  return (g_heff_2ecommands_2elibDir_24s863_24s1009(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124(a[0], a[1]);
}
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam3(V self, V *args) {
  V v_t_2418 = args[0];
  heff_drop(self);
  return v_t_2418;
}
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k2_2417 = args[1];
  V v_path_2415 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2419 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2415, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam3_clo)})});
  V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2416), LBL_malg), 1, (V[]){v_t_2420}));
  return heff_tail(heff_get(v_hd_2416, LBL_bind), 2, (V[]){v_t_2421, v_k2_2417});
}
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam5(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k2_2438 = args[1];
  V v_str_2436 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2439 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2436, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_str5)), NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2437), LBL_malg), 1, (V[]){v_t_2441}));
  return heff_tail(heff_get(v_hd_2437, LBL_bind), 2, (V[]){v_t_2442, v_k2_2438});
}
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2449);
  return heff_tail(v_k_241, 1, (V[]){((V)&g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_str6)});
}
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam6(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2444);
  V v_t_2445 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2447}));
  return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2448, heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam7, 1, 1, (V[]){v_k_241})});
}
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_243 = heff_dup(heff_env(self)[0]);
  V v_x_242 = heff_dup(heff_env(self)[1]);
  V v_hd_240 = heff_dup(heff_env(self)[2]);
  V v_k_241 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Nothing: {
    heff_drop(v_x_2423);
    V v_t_2424 = (g_std_2epath_2eparse(v_x_243, v_x_242));
    V v_t_2425 = (g_std_2epath_2eparse(v_x_243, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_str2)));
    V v_p_2426 = (g_std_2epath_2ejoin_2eonto_240(v_t_2424, v_t_2425));
    V v_t_2427 = ({ V a_0 = heff_get(heff_dup(v_p_2426), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2426), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2428 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2426), LBL_drive), heff_get(v_p_2426, LBL_absolute), v_t_2427});
    V v_a_2429 = (g_std_2epath_2erender(v_x_243, v_t_2428));
    V v_t_2430 = (g_std_2epath_2eparse(v_x_243, v_a_2429));
    V v_t_2431 = (g_std_2epath_2eparse(v_x_243, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_str3)));
    V v_p_2432 = (g_std_2epath_2ejoin_2eonto_240(v_t_2430, v_t_2431));
    V v_t_2433 = ({ V a_0 = heff_get(heff_dup(v_p_2432), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2432), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2434 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2432), LBL_drive), heff_get(v_p_2432, LBL_absolute), v_t_2433});
    V v_t_2435 = ({ V a_0 = v_x_243; V a_1 = v_t_2434; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_243); r_; });
    V v_str_2436 = heff_strAppend(((V)&g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_str4), v_t_2435);
    V v_c_2443 = heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam5, 2, 1, (V[]){v_str_2436});
    return heff_tail(v_c_2443, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam6, 1, 2, (V[]){v_hd_240, v_k_241})});
  }
  case TAG_Just: {
    V v_text_2450 = heff_field(v_x_2423, 0);
    heff_take(v_x_2423, 1ULL);
    heff_drop(v_x_243);
    heff_drop(v_x_242);
    heff_drop(v_hd_240);
    return heff_tail(v_k_241, 1, (V[]){v_text_2450});
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_x_242 = heff_dup(heff_env(self)[0]);
  V v_hd_240 = heff_dup(heff_env(self)[1]);
  V v_k_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_244 = (g_std_2epath_2eparse(v_x_243, heff_dup(v_x_242)));
  V v_t_245 = (g_std_2epath_2eparse(v_x_243, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_str0)));
  V v_p_246 = (g_std_2epath_2ejoin_2eonto_240(v_t_244, v_t_245));
  V v_t_247 = ({ V a_0 = heff_get(heff_dup(v_p_246), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_246), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_248 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_246), LBL_drive), heff_get(v_p_246, LBL_absolute), v_t_247});
  V v_a_249 = (g_std_2epath_2erender(v_x_243, v_t_248));
  V v_t_2410 = (g_std_2epath_2eparse(v_x_243, v_a_249));
  V v_t_2411 = (g_std_2epath_2eparse(v_x_243, ((V)&g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_str1)));
  V v_p_2412 = (g_std_2epath_2ejoin_2eonto_240(v_t_2410, v_t_2411));
  V v_t_2413 = ({ V a_0 = heff_get(heff_dup(v_p_2412), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2412), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2414 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2412), LBL_drive), heff_get(v_p_2412, LBL_absolute), v_t_2413});
  V v_path_2415 = (g_std_2epath_2erender(v_x_243, v_t_2414));
  V v_c_2422 = heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam2, 2, 1, (V[]){v_path_2415});
  return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam4, 1, 4, (V[]){v_x_243, v_x_242, v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return (g_heff_2ecommands_2estyleNow_24s864_24s1010(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124_lam1, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_str0 = {{0x80000000u, K_STR, 0}, 15, 15, {110, 111, 32, 102, 105, 108, 101, 115, 32, 103, 105, 118, 101, 110, 10}};
V g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam0(V self, V *args); static Clo g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam0, 2, 0};
V g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam4(V self, V *args);
V g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam3(V self, V *args);
V g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam2(V self, V *args);
Clo g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_entry, 6, 0};

V g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118(V v_sources_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_cs_245) {
top: ;
  V v_t_246 = (g_heff_2edriver_2elastChecked(v_cs_245));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_file_241);
    heff_drop(v_name_242);
    heff_drop(v_outPath_243);
    heff_drop(v_done_244);
    heff_drop(v_t_246);
    return ((V)&g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam0_clo);
  }
  case TAG_Just: {
    V v_c_2418 = heff_field(v_t_246, 0);
    heff_take(v_t_246, 1ULL);
    V v_t_2419 = (g_heff_2edriver_2ecandidatesOf(heff_dup(v_c_2418)));
    V v_t_2420 = ({ V a_0 = v_t_2419; V r_ = (g_heff_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2419); r_; });
    V v_t_2421 = (g_heff_2edriver_2enubStrD(v_t_2420));
    V v_xs_2422 = (g_prelude_2emap_24s639(v_t_2421));
    V v_t_2423 = (g_heff_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2422));
    V v_c_2424 = (g_heff_2ecommands_2ereadProvidersC_24s920_24s1119(v_sources_240, v_t_2423));
    return heff_clo(g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam2, 2, 6, (V[]){v_c_2424, v_name_242, v_c_2418, v_outPath_243, v_file_241, v_done_244});
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); heff_drop(a[5]); return r;
}
V g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_247 = heff_dup(heff_env(self)[0]);
  V v_k_248 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2413);
  V v_t_2414 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2417, v_k_248});
}
V g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(self);
  V v_t_249 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_str0), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam1, 1, 2, (V[]){v_hd_247, v_k_248})});
}
V g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_name_242 = heff_dup(heff_env(self)[0]);
  V v_c_2418 = heff_dup(heff_env(self)[1]);
  V v_outPath_243 = heff_dup(heff_env(self)[2]);
  V v_hd_2425 = heff_dup(heff_env(self)[3]);
  V v_k_2426 = heff_dup(heff_env(self)[4]);
  V v_file_241 = heff_dup(heff_env(self)[5]);
  V v_done_244 = heff_dup(heff_env(self)[6]);
  V v_x_2427 = heff_dup(heff_env(self)[7]);
  heff_drop(self);
  switch (heff_tag_of(v_name_242)) {
  case TAG_Nothing: {
    heff_drop(v_name_242);
    heff_drop(v_file_241);
    heff_drop(v_done_244);
    heff_drop(v_x_2427);
    V v_exports_2429 = (g_prelude_2emap_24s822(heff_get(heff_dup(v_c_2418), LBL_own)));
    V v_roots_2430 = (g_prelude_2emap_24s539(heff_dup(v_exports_2429)));
    V v_t_2431 = heff_get(heff_get(v_c_2418, LBL_top), LBL_globals);
    V v_t_2432 = (g_heff_2eerase_2eeraseProgram(v_t_2431));
    V v_t_2433 = (g_heff_2elower_2eanfLowered(v_roots_2430, v_t_2432));
    V v_t_2434 = (g_heff_2eemitc_2echeckOut(v_x_2428, v_exports_2429, v_t_2433));
    return ({ V a_0 = v_outPath_243; V b_1 = NTAG(TAG_False); V a_2 = v_t_2434; V a_3 = v_hd_2425; V a_4 = v_k_2426; V r_ = (g_heff_2ecommands_2ecompileJsOut_24s916_24s1028_24s1115(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  }
  case TAG_Just: {
    V v_t_2436 = heff_tr(g_heff_2ecommands_2ecompileFoundC_24s923_24s1033_24s1121(v_file_241, v_name_242, v_outPath_243, v_x_2428, v_done_244, v_c_2418, v_x_2427));
    return heff_tail(v_t_2436, 2, (V[]){v_hd_2425, v_k_2426});
  }
  default: return heff_nomatch(v_name_242);
  }
}
V g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_2425 = heff_dup(heff_env(self)[0]);
  V v_name_242 = heff_dup(heff_env(self)[1]);
  V v_c_2418 = heff_dup(heff_env(self)[2]);
  V v_outPath_243 = heff_dup(heff_env(self)[3]);
  V v_k_2426 = heff_dup(heff_env(self)[4]);
  V v_file_241 = heff_dup(heff_env(self)[5]);
  V v_done_244 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  return (g_heff_2ecommands_2ereadRuntimeC_24s922_24s1032_24s1124(heff_dup(v_hd_2425), heff_clo(g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam4, 1, 8, (V[]){v_name_242, v_c_2418, v_outPath_243, v_hd_2425, v_k_2426, v_file_241, v_done_244, v_x_2427})));
}
V g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam2(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_dup(heff_env(self)[0]);
  V v_name_242 = heff_dup(heff_env(self)[1]);
  V v_c_2418 = heff_dup(heff_env(self)[2]);
  V v_outPath_243 = heff_dup(heff_env(self)[3]);
  V v_file_241 = heff_dup(heff_env(self)[4]);
  V v_done_244 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  return heff_tail(v_c_2424, 2, (V[]){heff_dup(v_hd_2425), heff_clo(g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118_lam3, 1, 7, (V[]){v_hd_2425, v_name_242, v_c_2418, v_outPath_243, v_k_2426, v_file_241, v_done_244})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_lam3(V self, V *args);
V g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_lam2(V self, V *args);
V g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_lam1(V self, V *args);
V g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_entry, 6, 0};

V g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117(V v_name_240, V v_outPath_241, V v_file_242, V v_done_243, V v_hd_244, V v_k_245) {
top: ;
  return (g_heff_2ecommands_2eload_24s861_24s1007_24s1079(heff_dup(v_file_242), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_lam0, 1, 6, (V[]){v_hd_244, v_k_245, v_file_242, v_name_240, v_outPath_241, v_done_243})));
}
V g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_247 = heff_dup(heff_env(self)[0]);
  V v_hd_244 = heff_dup(heff_env(self)[1]);
  V v_k_245 = heff_dup(heff_env(self)[2]);
  V v_x_249 = heff_dup(heff_env(self)[3]);
  V v_x_246 = heff_dup(heff_env(self)[4]);
  V v_file_242 = heff_dup(heff_env(self)[5]);
  V v_name_240 = heff_dup(heff_env(self)[6]);
  V v_outPath_241 = heff_dup(heff_env(self)[7]);
  V v_done_243 = heff_dup(heff_env(self)[8]);
  heff_drop(self);
  heff_drop(v_x_2411);
  V v_t_2412 = heff_intLt(MK_INT(0LL), v_x_247);
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_x_249);
    heff_drop(v_x_246);
    heff_drop(v_file_242);
    heff_drop(v_name_240);
    heff_drop(v_outPath_241);
    heff_drop(v_done_243);
    heff_drop(v_t_2412);
    V v_t_2413 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2415}));
    return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2416, v_k_245});
  }
  case TAG_False: {
    heff_drop(v_t_2412);
    V v_t_2417 = (g_prelude_2eany_24s820(v_x_249));
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      heff_drop(v_x_249);
      heff_drop(v_x_246);
      heff_drop(v_file_242);
      heff_drop(v_name_240);
      heff_drop(v_outPath_241);
      heff_drop(v_done_243);
      heff_drop(v_t_2417);
      V v_t_2418 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_2420}));
      return heff_tail(heff_get(v_hd_244, LBL_bind), 2, (V[]){v_t_2421, v_k_245});
    }
    case TAG_False: {
      heff_drop(v_t_2417);
      V v_t_2422 = ({ V b_0 = heff_get(v_x_246, LBL_sources); V a_1 = v_file_242; V a_2 = v_name_240; V a_3 = v_outPath_241; V a_4 = v_done_243; V a_5 = v_x_249; V r_ = (g_heff_2ecommands_2ecompileLastC_24s919_24s1031_24s1118(b_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(b_0); heff_drop(v_x_249); r_; });
      return heff_tail(v_t_2422, 2, (V[]){v_hd_244, v_k_245});
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_244 = heff_dup(heff_env(self)[0]);
  V v_x_247 = heff_dup(heff_env(self)[1]);
  V v_k_245 = heff_dup(heff_env(self)[2]);
  V v_x_246 = heff_dup(heff_env(self)[3]);
  V v_file_242 = heff_dup(heff_env(self)[4]);
  V v_name_240 = heff_dup(heff_env(self)[5]);
  V v_outPath_241 = heff_dup(heff_env(self)[6]);
  V v_done_243 = heff_dup(heff_env(self)[7]);
  heff_drop(self);
  V v_c_2410 = (g_heff_2ecommands_2eputFileDiags_24s894(heff_dup(v_x_249)));
  return heff_tail(v_c_2410, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_lam3, 1, 9, (V[]){v_x_247, v_hd_244, v_k_245, v_x_249, v_x_246, v_file_242, v_name_240, v_outPath_241, v_done_243})});
}
V g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_dup(heff_env(self)[0]);
  V v_hd_244 = heff_dup(heff_env(self)[1]);
  V v_k_245 = heff_dup(heff_env(self)[2]);
  V v_file_242 = heff_dup(heff_env(self)[3]);
  V v_name_240 = heff_dup(heff_env(self)[4]);
  V v_outPath_241 = heff_dup(heff_env(self)[5]);
  V v_done_243 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  V v_c_248 = (g_heff_2esession_2ecachedProgram_24s888_24s1074(heff_dup(v_x_246)));
  return heff_tail(v_c_248, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_lam2, 1, 8, (V[]){v_hd_244, v_x_247, v_k_245, v_x_246, v_file_242, v_name_240, v_outPath_241, v_done_243})});
}
V g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_dup(heff_env(self)[0]);
  V v_k_245 = heff_dup(heff_env(self)[1]);
  V v_file_242 = heff_dup(heff_env(self)[2]);
  V v_name_240 = heff_dup(heff_env(self)[3]);
  V v_outPath_241 = heff_dup(heff_env(self)[4]);
  V v_done_243 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_str0), heff_get(heff_dup(v_x_246), LBL_errors), MK_INT(0LL), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_lam1, 1, 7, (V[]){v_x_246, v_hd_244, v_k_245, v_file_242, v_name_240, v_outPath_241, v_done_243})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {42, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {119, 114, 111, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[28]; } g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_str3 = {{0x80000000u, K_STR, 0}, 28, 28, {58, 32, 98, 117, 105, 108, 100, 32, 105, 116, 32, 119, 105, 116, 104, 32, 96, 122, 105, 103, 32, 99, 99, 32, 45, 79, 50, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_str4 = {{0x80000000u, K_STR, 0}, 12, 12, {32, 45, 111, 32, 80, 82, 79, 71, 82, 65, 77, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_lam0(V self, V *args);
Clo g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_entry, 3, 0};

V g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116(V v_name_240, V v_outPath_241, V v_file_242) {
top: ;
  V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_outPath_241)), MK_INT(1LL));
  V v_t_244 = heff_strSlice(heff_dup(v_outPath_241), v_t_243, heff_strLength(heff_dup(v_outPath_241)));
  V v_t_245 = heff_strEq(v_t_244, ((V)&g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_str0));
  V v_t_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_t_245);
    v_t_246 = heff_strAppend(heff_dup(v_outPath_241), ((V)&g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_str1));
    break;
  }
  case TAG_False: {
    heff_drop(v_t_245);
    v_t_246 = heff_dup(v_outPath_241);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_str_247 = heff_strAppend(((V)&g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_str2), heff_strAppend(heff_dup(v_outPath_241), heff_strAppend(((V)&g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_str3), heff_strAppend(v_t_246, ((V)&g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_str4)))));
  return heff_tail(((V)&g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_clo), 4, (V[]){v_name_240, v_outPath_241, v_file_242, heff_clo(g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_lam0, 2, 1, (V[]){v_str_247})});
}
V g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k2_249 = args[1];
  V v_str_247 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2410 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_247, ((V)&g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116_str5)), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_248), LBL_malg), 1, (V[]){v_t_2412}));
  return heff_tail(heff_get(v_hd_248, LBL_bind), 2, (V[]){v_t_2413, v_k2_249});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {119, 114, 111, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str4 = {{0x80000000u, K_STR, 0}, 18, 18, {114, 117, 110, 32, 105, 116, 32, 119, 105, 116, 104, 32, 96, 110, 111, 100, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str5 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 65, 82, 71, 83, 46, 46, 46, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str9 = {{0x80000000u, K_STR, 0}, 6, 6, {119, 114, 111, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[91]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str10 = {{0x80000000u, K_STR, 0}, 91, 91, {58, 32, 108, 111, 97, 100, 32, 105, 116, 32, 105, 110, 32, 97, 32, 112, 97, 103, 101, 32, 119, 105, 116, 104, 32, 60, 115, 99, 114, 105, 112, 116, 32, 115, 114, 99, 61, 34, 46, 46, 46, 34, 62, 32, 40, 105, 116, 32, 105, 109, 112, 111, 114, 116, 115, 32, 110, 111, 116, 104, 105, 110, 103, 58, 32, 105, 116, 32, 111, 112, 101, 110, 115, 32, 102, 114, 111, 109, 32, 102, 105, 108, 101, 58, 47, 47, 32, 116, 111, 111, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str12 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 115, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[70]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str13 = {{0x80000000u, K_STR, 0}, 70, 70, {104, 101, 102, 102, 32, 99, 111, 109, 112, 105, 108, 101, 58, 32, 97, 110, 32, 69, 83, 32, 109, 111, 100, 117, 108, 101, 32, 114, 117, 110, 115, 32, 110, 111, 116, 104, 105, 110, 103, 58, 32, 110, 111, 32, 45, 45, 110, 97, 109, 101, 32, 119, 105, 116, 104, 32, 45, 45, 98, 97, 99, 107, 101, 110, 100, 61, 101, 115, 109, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str15 = {{0x80000000u, K_STR, 0}, 25, 25, {104, 101, 102, 102, 32, 99, 111, 109, 112, 105, 108, 101, 58, 32, 110, 111, 32, 98, 97, 99, 107, 101, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str16 = {{0x80000000u, K_STR, 0}, 22, 22, {58, 32, 101, 115, 109, 44, 32, 112, 97, 103, 101, 44, 32, 110, 111, 100, 101, 32, 111, 114, 32, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam0(V self, V *args);
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam1(V self, V *args);
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam3(V self, V *args);
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam2(V self, V *args); static Clo g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam2, 2, 0};
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam5(V self, V *args);
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam4(V self, V *args);
Clo g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_entry, 1, 0};

V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111(V v_o_240) {
top: ;
  V v_t_241 = heff_strEq(heff_get(heff_dup(v_o_240), LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_t_241);
    V v_outPath_242 = heff_get(heff_dup(v_o_240), LBL_outPath);
    return heff_tail(((V)&g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_clo), 5, (V[]){((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str1), heff_get(heff_dup(v_o_240), LBL_name), heff_dup(v_outPath_242), heff_get(v_o_240, LBL_file), heff_clo(g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam0, 2, 1, (V[]){v_outPath_242})});
  }
  case TAG_False: {
    heff_drop(v_t_241);
    V v_t_2410 = heff_strEq(heff_get(heff_dup(v_o_240), LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str7));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      heff_drop(v_t_2410);
      V v_outPath_2411 = heff_get(heff_dup(v_o_240), LBL_outPath);
      return heff_tail(((V)&g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_clo), 5, (V[]){((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str8), heff_get(heff_dup(v_o_240), LBL_name), heff_dup(v_outPath_2411), heff_get(v_o_240, LBL_file), heff_clo(g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam1, 2, 1, (V[]){v_outPath_2411})});
    }
    case TAG_False: {
      heff_drop(v_t_2410);
      V v_t_2419 = heff_strEq(heff_get(heff_dup(v_o_240), LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str12));
      switch (heff_tag_of(v_t_2419)) {
      case TAG_True: {
        heff_drop(v_t_2419);
        V v_t_2420 = heff_get(heff_dup(v_o_240), LBL_name);
        switch (heff_tag_of(v_t_2420)) {
        case TAG_Nothing: {
          heff_drop(v_t_2420);
          return heff_tail(((V)&g_heff_2ecommands_2ecompileJsCmd_24s914_24s1026_24s1113_clo), 2, (V[]){heff_get(heff_dup(v_o_240), LBL_file), heff_get(v_o_240, LBL_outPath)});
        }
        case TAG_Just: {
          heff_take(v_t_2420, 0ULL);
          heff_drop(v_o_240);
          return ((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam2_clo);
        }
        default: return heff_nomatch(v_t_2420);
        }
      }
      case TAG_False: {
        heff_drop(v_t_2419);
        V v_t_2433 = heff_strEq(heff_get(heff_dup(v_o_240), LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str14));
        switch (heff_tag_of(v_t_2433)) {
        case TAG_True: {
          heff_drop(v_t_2433);
          return (g_heff_2ecommands_2ecCmd_24s917_24s1029_24s1116(heff_get(heff_dup(v_o_240), LBL_name), heff_get(heff_dup(v_o_240), LBL_outPath), heff_get(v_o_240, LBL_file)));
        }
        case TAG_False: {
          heff_drop(v_t_2433);
          return heff_clo(g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam4, 2, 1, (V[]){v_o_240});
        }
        default: return heff_nomatch(v_t_2433);
        }
      }
      default: return heff_nomatch(v_t_2419);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111(a[0]);
}
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k2_244 = args[1];
  V v_outPath_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_245 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str2), heff_strAppend(heff_dup(v_outPath_242), heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str3), heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str4), heff_strAppend(v_outPath_242, ((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str5))))));
  V v_t_246 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str6)), NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_249, v_k2_244});
}
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_outPath_2411 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str9), heff_strAppend(v_outPath_2411, ((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str10)));
  V v_t_2415 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2414, ((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str11)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2412), LBL_malg), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get(v_hd_2412, LBL_bind), 2, (V[]){v_t_2418, v_k2_2413});
}
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_2422 = heff_dup(heff_env(self)[0]);
  V v_k_2423 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2422), LBL_malg), 1, (V[]){v_t_2431}));
  return heff_tail(heff_get(v_hd_2422, LBL_bind), 2, (V[]){v_t_2432, v_k_2423});
}
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(self);
  V v_t_2424 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str13), NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2422), LBL_malg), 1, (V[]){v_t_2426}));
  return heff_tail(heff_get(heff_dup(v_hd_2422), LBL_bind), 2, (V[]){v_t_2427, heff_clo(g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam3, 1, 2, (V[]){v_hd_2422, v_k_2423})});
}
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam5(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_2434 = heff_dup(heff_env(self)[0]);
  V v_k_2435 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2434), LBL_malg), 1, (V[]){v_t_2444}));
  return heff_tail(heff_get(v_hd_2434, LBL_bind), 2, (V[]){v_t_2445, v_k_2435});
}
V g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam4(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_o_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2436 = heff_strAppend(((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str15), heff_strAppend(heff_get(v_o_240, LBL_backend), ((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str16)));
  V v_t_2437 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_str17)), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2434), LBL_malg), 1, (V[]){v_t_2439}));
  return heff_tail(heff_get(heff_dup(v_hd_2434), LBL_bind), 2, (V[]){v_t_2440, heff_clo(g_heff_2ecommands_2ecompileTo_24s913_24s1024_24s1111_lam5, 1, 2, (V[]){v_hd_2434, v_k_2435})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_lam3(V self, V *args);
V g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_lam2(V self, V *args);
V g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_lam1(V self, V *args);
V g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_lam0(V self, V *args);
Clo g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_entry, 3, 0};

V g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125(V v_file_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecommands_2eload_24s861_24s1007_24s1079(v_file_240, heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_lam0, 1, 2, (V[]){v_hd_241, v_k_242})));
}
V g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_246 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_x_248);
  V v_t_249 = ({ V a_0 = v_x_246; V r_ = (g_heff_2edriver_2elastChecked(a_0)); heff_drop(v_x_246); r_; });
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    heff_drop(v_t_249);
    V v_t_2410 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2412}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2413, v_k_242});
  }
  case TAG_Just: {
    V v_c_2414 = heff_field(v_t_249, 0);
    heff_take(v_t_249, 1ULL);
    V v_t_2415 = (g_heff_2equery_2eexplain(v_c_2414));
    return (g_heff_2ecommands_2eprintLines_24s928(v_t_2415, v_hd_241, v_k_242));
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_c_247 = (g_heff_2ecommands_2eputFileDiags_24s894(heff_dup(v_x_246)));
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_lam3, 1, 3, (V[]){v_x_246, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_x_243 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_x_244);
  V v_c_245 = (g_heff_2esession_2ecachedProgram_24s888_24s1074(v_x_243));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_lam2, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_str0), heff_get(heff_dup(v_x_243), LBL_errors), MK_INT(0LL), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eexplainCmd_24s927_24s1036_24s1125_lam1, 1, 3, (V[]){v_x_243, v_hd_241, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_str1 = {{0x80000000u, K_STR, 0}, 13, 13, {110, 111, 116, 104, 105, 110, 103, 32, 116, 104, 101, 114, 101}};
V g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam4(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam3(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam2(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam1(V self, V *args);
V g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam0(V self, V *args);
Clo g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_entry, 4, 0};

V g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126(V v_file_240, V v_offs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecommands_2eload_24s861_24s1007_24s1079(v_file_240, heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam0, 1, 3, (V[]){v_hd_242, v_k_243, v_offs_241})));
}
V g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam4(V self, V *args) {
  V v_off_2416 = args[0];
  V v_c_2415 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2417 = (g_prelude_2eparseInt(v_off_2416));
  V v_x2_2419;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nothing: {
    heff_drop(v_c_2415);
    heff_drop(v_t_2417);
    v_x2_2419 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_o_2418 = heff_field(v_t_2417, 0);
    heff_take(v_t_2417, 1ULL);
    v_x2_2419 = (g_heff_2equery_2etypeAt(v_c_2415, v_o_2418));
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Nothing: {
    heff_drop(v_x2_2419);
    return ((V)&g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_str1);
  }
  case TAG_Just: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    heff_take(v_x2_2419, 1ULL);
    return v_x_2420;
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_247 = heff_dup(heff_env(self)[0]);
  V v_hd_242 = heff_dup(heff_env(self)[1]);
  V v_k_243 = heff_dup(heff_env(self)[2]);
  V v_offs_241 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_x_249);
  V v_t_2410 = ({ V a_0 = v_x_247; V r_ = (g_heff_2edriver_2elastChecked(a_0)); heff_drop(v_x_247); r_; });
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    heff_drop(v_offs_241);
    heff_drop(v_t_2410);
    V v_t_2411 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2413}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2414, v_k_243});
  }
  case TAG_Just: {
    V v_c_2415 = heff_field(v_t_2410, 0);
    heff_take(v_t_2410, 1ULL);
    V v_t_2421 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam4, 1, 1, (V[]){v_c_2415}), v_offs_241));
    return (g_heff_2ecommands_2eprintLines_24s928(v_t_2421, v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_dup(heff_env(self)[0]);
  V v_k_243 = heff_dup(heff_env(self)[1]);
  V v_offs_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_c_248 = (g_heff_2ecommands_2eputFileDiags_24s894(heff_dup(v_x_247)));
  return heff_tail(v_c_248, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam3, 1, 4, (V[]){v_x_247, v_hd_242, v_k_243, v_offs_241})});
}
V g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_dup(heff_env(self)[0]);
  V v_hd_242 = heff_dup(heff_env(self)[1]);
  V v_k_243 = heff_dup(heff_env(self)[2]);
  V v_offs_241 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_x_245);
  V v_c_246 = (g_heff_2esession_2ecachedProgram_24s888_24s1074(v_x_244));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam2, 1, 3, (V[]){v_hd_242, v_k_243, v_offs_241})});
}
V g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_dup(heff_env(self)[0]);
  V v_k_243 = heff_dup(heff_env(self)[1]);
  V v_offs_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_str0), heff_get(heff_dup(v_x_244), LBL_errors), MK_INT(0LL), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2etypeAtCmd_24s929_24s1037_24s1126_lam1, 1, 4, (V[]){v_x_244, v_hd_242, v_k_243, v_offs_241})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2efmtSrc_24s933_24s1130_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ecommands_2efmtSrc_24s933_24s1130_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 110, 111, 116, 32, 102, 111, 114, 109, 97, 116, 116, 101, 100, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efmtSrc_24s933_24s1130_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efmtSrc_24s933_24s1130_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam1(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam0(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam2(V self, V *args); static Clo g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam2, 2, 0};
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam4(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam3(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam6(V self, V *args); static Clo g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam6, 1, 0};
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam7(V self, V *args);
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam5(V self, V *args);
Clo g_heff_2ecommands_2efmtSrc_24s933_24s1130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtSrc_24s933_24s1130_entry, 4, 0};

V g_heff_2ecommands_2efmtSrc_24s933_24s1130(V v_checkOnly_240, V v_f_241, V v_src_242, V v_fix_243) {
top: ;
  V v_t_244 = (g_heff_2efmt_2elayout_2eformatUncheckedIn(v_fix_243, heff_dup(v_src_242)));
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Left: {
    V v_why_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Left = heff_take_reuse(v_t_244, 1ULL);
    v_t_247 = heff_tag_at(v_ru_24t_244_24Left, TAG_Left, 1, (V[]){v_why_245});
    break;
  }
  case TAG_Right: {
    V v_out_246 = heff_field(v_t_244, 0);
    heff_take(v_t_244, 1ULL);
    v_t_247 = (g_heff_2eformat_2echeck(heff_dup(v_src_242), v_out_246));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_Left: {
    V v_why_248 = heff_field(v_t_247, 0);
    heff_take(v_t_247, 1ULL);
    heff_drop(v_src_242);
    return heff_clo(g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam0, 2, 2, (V[]){v_f_241, v_why_248});
  }
  case TAG_Right: {
    V v_out_2417 = heff_field(v_t_247, 0);
    heff_take(v_t_247, 1ULL);
    V v_t_2418 = heff_strEq(heff_dup(v_out_2417), v_src_242);
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      heff_drop(v_f_241);
      heff_drop(v_out_2417);
      heff_drop(v_t_2418);
      return ((V)&g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam2_clo);
    }
    case TAG_False: {
      heff_drop(v_t_2418);
      switch (heff_tag_of(v_checkOnly_240)) {
      case TAG_True: {
        heff_drop(v_out_2417);
        return heff_clo(g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam3, 2, 1, (V[]){v_f_241});
      }
      case TAG_False: {
        return heff_clo(g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam5, 2, 2, (V[]){v_f_241, v_out_2417});
      }
      default: return heff_nomatch(v_checkOnly_240);
      }
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2efmtSrc_24s933_24s1130(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2410 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2416);
  return heff_tail(v_k_2410, 1, (V[]){MK_INT(1LL)});
}
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_f_241 = heff_dup(heff_env(self)[0]);
  V v_why_248 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecommands_2efmtSrc_24s933_24s1130_str0), heff_strAppend(v_f_241, heff_strAppend(((V)&g_heff_2ecommands_2efmtSrc_24s933_24s1130_str1), v_why_248)));
  V v_t_2412 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ecommands_2efmtSrc_24s933_24s1130_str2)), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_249), LBL_malg), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get(v_hd_249, LBL_bind), 2, (V[]){v_t_2415, heff_clo(g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam1, 1, 1, (V[]){v_k_2410})});
}
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(self);
  heff_drop(v_hd_2419);
  return heff_tail(v_k_2420, 1, (V[]){MK_INT(0LL)});
}
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2422 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2427);
  return heff_tail(v_k_2422, 1, (V[]){MK_INT(1LL)});
}
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_f_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2423 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_f_241, ((V)&g_heff_2ecommands_2efmtSrc_24s933_24s1130_str3)), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2421), LBL_malg), 1, (V[]){v_t_2425}));
  return heff_tail(heff_get(v_hd_2421, LBL_bind), 2, (V[]){v_t_2426, heff_clo(g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam4, 1, 1, (V[]){v_k_2422})});
}
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam6(V self, V *args) {
  V v_ok_2430 = args[0];
  heff_drop(self);
  return v_ok_2430;
}
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_2429 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2434);
  return heff_tail(v_k_2429, 1, (V[]){MK_INT(0LL)});
}
V g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam5(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_f_241 = heff_dup(heff_env(self)[0]);
  V v_out_2417 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2431 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){v_f_241, v_out_2417, ((V)&g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam6_clo)})});
  V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2428), LBL_malg), 1, (V[]){v_t_2432}));
  return heff_tail(heff_get(v_hd_2428, LBL_bind), 2, (V[]){v_t_2433, heff_clo(g_heff_2ecommands_2efmtSrc_24s933_24s1130_lam7, 1, 1, (V[]){v_k_2429})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_str0 = {{0x80000000u, K_STR, 0}, 18, 18, {104, 101, 102, 102, 58, 32, 99, 97, 110, 110, 111, 116, 32, 114, 101, 97, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_lam0(V self, V *args); static Clo g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_lam0, 1, 0};
V g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_lam2(V self, V *args);
V g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_lam3(V self, V *args);
V g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_lam1(V self, V *args);
Clo g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_entry, 4, 0};

V g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129(V v_checkOnly_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){heff_dup(v_f_241), ((V)&g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_lam0_clo)})});
  V v_t_246 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_246}));
  return heff_tail(heff_get(heff_dup(v_hd_242), LBL_bind), 2, (V[]){v_t_247, heff_clo(g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_lam1, 1, 4, (V[]){v_f_241, v_hd_242, v_k_243, heff_dup(v_checkOnly_240)})});
}
V g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_lam0(V self, V *args) {
  V v_t_244 = args[0];
  heff_drop(self);
  return v_t_244;
}
V g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2414);
  return heff_tail(v_k_243, 1, (V[]){MK_INT(1LL)});
}
V g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_checkOnly_240 = heff_dup(heff_env(self)[0]);
  V v_f_241 = heff_dup(heff_env(self)[1]);
  V v_src_2415 = heff_dup(heff_env(self)[2]);
  V v_hd_242 = heff_dup(heff_env(self)[3]);
  V v_k_243 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2417 = (g_heff_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get(v_x_2416, LBL_sources)));
  V v_t_2418 = ({ V a_0 = v_checkOnly_240; V a_1 = v_f_241; V a_2 = v_src_2415; V a_3 = v_t_2417; V r_ = (g_heff_2ecommands_2efmtSrc_24s933_24s1130(a_0, a_1, a_2, a_3)); heff_drop(v_checkOnly_240); r_; });
  return heff_tail(v_t_2418, 2, (V[]){v_hd_242, v_k_243});
}
V g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_241 = heff_dup(heff_env(self)[0]);
  V v_hd_242 = heff_dup(heff_env(self)[1]);
  V v_k_243 = heff_dup(heff_env(self)[2]);
  V v_checkOnly_240 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    heff_drop(v_x_248);
    heff_drop(v_checkOnly_240);
    V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_str0), v_f_241), ((V)&g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_str1));
    V v_t_2410 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_249, NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_2412}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_lam2, 1, 1, (V[]){v_k_243})});
  }
  case TAG_Just: {
    V v_src_2415 = heff_field(v_x_248, 0);
    heff_take(v_x_248, 1ULL);
    return (g_heff_2ecommands_2eload_24s861_24s1007_24s1079(heff_dup(v_f_241), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129_lam3, 1, 5, (V[]){v_checkOnly_240, v_f_241, v_src_2415, v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2ecommands_2efmtAll_24s931_24s1039_24s1128_lam0(V self, V *args);
Clo g_heff_2ecommands_2efmtAll_24s931_24s1039_24s1128_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtAll_24s931_24s1039_24s1128_entry, 5, 0};

V g_heff_2ecommands_2efmtAll_24s931_24s1039_24s1128(V v_checkOnly_240, V v_x2_241, V v_bad_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_bad_242});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    return (g_heff_2ecommands_2efmtOne_24s932_24s1040_24s1129(v_checkOnly_240, heff_dup(v_f_245), heff_dup(v_p_243), heff_clo(g_heff_2ecommands_2efmtAll_24s931_24s1039_24s1128_lam0, 1, 5, (V[]){heff_dup(v_checkOnly_240), heff_dup(v_rest_246), v_bad_242, v_p_243, v_p_244})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2efmtAll_24s931_24s1039_24s1128_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2efmtAll_24s931_24s1039_24s1128(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2efmtAll_24s931_24s1039_24s1128_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_checkOnly_240 = heff_dup(heff_env(self)[0]);
  V v_rest_246 = heff_dup(heff_env(self)[1]);
  V v_bad_242 = heff_dup(heff_env(self)[2]);
  V v_p_243 = heff_dup(heff_env(self)[3]);
  V v_p_244 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  return ({ V a_0 = v_checkOnly_240; V a_1 = v_rest_246; V a_2 = heff_intAdd(v_bad_242, v_x_247); V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ecommands_2efmtAll_24s931_24s1039_24s1128(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_checkOnly_240); heff_drop(v_rest_246); r_; });
}
V g_heff_2ecommands_2efmtCmd_24s930_24s1038_24s1127_lam0(V self, V *args);
Clo g_heff_2ecommands_2efmtCmd_24s930_24s1038_24s1127_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efmtCmd_24s930_24s1038_24s1127_entry, 4, 0};

V g_heff_2ecommands_2efmtCmd_24s930_24s1038_24s1127(V v_check_240, V v_files_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecommands_2efmtAll_24s931_24s1039_24s1128(v_check_240, v_files_241, MK_INT(0LL), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2efmtCmd_24s930_24s1038_24s1127_lam0, 1, 2, (V[]){v_hd_242, v_k_243})));
}
V g_heff_2ecommands_2efmtCmd_24s930_24s1038_24s1127_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2efmtCmd_24s930_24s1038_24s1127(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2efmtCmd_24s930_24s1038_24s1127_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_dup(heff_env(self)[0]);
  V v_k_243 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_245 = heff_intLt(MK_INT(0LL), v_x_244);
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_t_245);
    V v_t_246 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_242), LBL_malg), 1, (V[]){v_t_248}));
    return heff_tail(heff_get(v_hd_242, LBL_bind), 2, (V[]){v_t_249, v_k_243});
  }
  case TAG_False: {
    heff_drop(v_hd_242);
    heff_drop(v_t_245);
    return heff_tail(v_k_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_t_245);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_str1 = {{0x80000000u, K_STR, 0}, 19, 19, {104, 101, 102, 102, 58, 32, 99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam2(V self, V *args); static Clo g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam2, 1, 0};
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam1(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam5(V self, V *args); static Clo g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam5, 1, 0};
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam4(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam7(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam8(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam6(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam3(V self, V *args);
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam0(V self, V *args);
Clo g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_entry, 4, 0};

V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_x2_241);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take(v_x2_241, 3ULL);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take(v_x21_244, 3ULL);
      return (g_heff_2ecommands_2estyleNow_24s864_24s1010(heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam0, 1, 6, (V[]){v_dir_240, v_f_246, v_p_242, v_text_247, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam2(V self, V *args) {
  V v_ok_2423 = args[0];
  heff_drop(self);
  return v_ok_2423;
}
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam1(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_path_2420 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2424 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_2420, ((V)&g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam2_clo)})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2421), LBL_malg), 1, (V[]){v_t_2425}));
  return heff_tail(heff_get(v_hd_2421, LBL_bind), 2, (V[]){v_t_2426, v_k2_2422});
}
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam5(V self, V *args) {
  V v_ok_2444 = args[0];
  heff_drop(self);
  return v_ok_2444;
}
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam4(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k2_2443 = args[1];
  V v_path_2434 = heff_dup(heff_env(self)[0]);
  V v_str_2441 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2445 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){v_path_2434, v_str_2441, ((V)&g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam5_clo)})});
  V v_t_2446 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2442), LBL_malg), 1, (V[]){v_t_2446}));
  return heff_tail(heff_get(v_hd_2442, LBL_bind), 2, (V[]){v_t_2447, v_k2_2443});
}
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam7(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k2_2458 = args[1];
  V v_str_2456 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2459 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2456, ((V)&g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_str2)), NTAG(TAG_MkUnit)});
  V v_t_2460 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2457), LBL_malg), 1, (V[]){v_t_2461}));
  return heff_tail(heff_get(v_hd_2457, LBL_bind), 2, (V[]){v_t_2462, v_k2_2458});
}
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam8(V self, V *args) {
  V v_x_2464 = args[0];
  V v_p_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2464);
  return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam6(V self, V *args) {
  V v_x_2449 = args[0];
  V v_x_2428 = heff_dup(heff_env(self)[0]);
  V v_dir_240 = heff_dup(heff_env(self)[1]);
  V v_rest_245 = heff_dup(heff_env(self)[2]);
  V v_p_242 = heff_dup(heff_env(self)[3]);
  V v_p_243 = heff_dup(heff_env(self)[4]);
  V v_x_248 = heff_dup(heff_env(self)[5]);
  V v_f_246 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  V v_t_2450;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_True: {
    heff_drop(v_x_2428);
    v_t_2450 = v_x_2449;
    break;
  }
  case TAG_False: {
    heff_drop(v_x_2449);
    heff_drop(v_x_2428);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  switch (heff_tag_of(v_t_2450)) {
  case TAG_True: {
    heff_drop(v_x_248);
    heff_drop(v_f_246);
    heff_drop(v_t_2450);
    return (g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132(v_dir_240, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_False: {
    heff_drop(v_rest_245);
    heff_drop(v_t_2450);
    V v_t_2451 = (g_std_2epath_2eparse(v_x_248, v_dir_240));
    V v_t_2452 = (g_std_2epath_2eparse(v_x_248, v_f_246));
    V v_p_2453 = (g_std_2epath_2ejoin_2eonto_240(v_t_2451, v_t_2452));
    V v_t_2454 = ({ V a_0 = heff_get(heff_dup(v_p_2453), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2453), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2455 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2453), LBL_drive), heff_get(v_p_2453, LBL_absolute), v_t_2454});
    V v_str_2456 = heff_strAppend(((V)&g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_str1), ({ V a_0 = v_x_248; V a_1 = v_t_2455; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_248); r_; }));
    V v_c_2463 = heff_clo(g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam7, 2, 1, (V[]){v_str_2456});
    return heff_tail(v_c_2463, 2, (V[]){v_p_242, heff_clo(g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam8, 1, 1, (V[]){v_p_243})});
  }
  default: return heff_nomatch(v_t_2450);
  }
}
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_248 = heff_dup(heff_env(self)[0]);
  V v_dir_240 = heff_dup(heff_env(self)[1]);
  V v_f_246 = heff_dup(heff_env(self)[2]);
  V v_text_247 = heff_dup(heff_env(self)[3]);
  V v_p_242 = heff_dup(heff_env(self)[4]);
  V v_rest_245 = heff_dup(heff_env(self)[5]);
  V v_p_243 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  V v_t_2429 = (g_std_2epath_2eparse(v_x_248, heff_dup(v_dir_240)));
  V v_t_2430 = (g_std_2epath_2eparse(v_x_248, heff_dup(v_f_246)));
  V v_p_2431 = (g_std_2epath_2ejoin_2eonto_240(v_t_2429, v_t_2430));
  V v_t_2432 = ({ V a_0 = heff_get(heff_dup(v_p_2431), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2431), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2433 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2431), LBL_drive), heff_get(v_p_2431, LBL_absolute), v_t_2432});
  V v_path_2434 = (g_std_2epath_2erender(v_x_248, v_t_2433));
  V v_t_2435 = heff_intSub(heff_strLength(heff_dup(v_f_246)), MK_INT(3LL));
  V v_t_2436 = heff_strSlice(heff_dup(v_f_246), v_t_2435, heff_strLength(heff_dup(v_f_246)));
  V v_t_2437 = heff_strEq(v_t_2436, ((V)&g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_str0));
  V v_str_2441;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_True: {
    heff_drop(v_t_2437);
    V v_t_2438 = (g_heff_2eformat_2eformat(heff_dup(v_text_247)));
    switch (heff_tag_of(v_t_2438)) {
    case TAG_Left: {
      heff_take(v_t_2438, 0ULL);
      v_str_2441 = v_text_247;
      break;
    }
    case TAG_Right: {
      V v_out_2440 = heff_field(v_t_2438, 0);
      heff_take(v_t_2438, 1ULL);
      heff_drop(v_text_247);
      v_str_2441 = v_out_2440;
      break;
    }
    default: heff_nomatch(v_t_2438);
    }
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2437);
    v_str_2441 = v_text_247;
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V v_c_2448 = heff_clo(g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam4, 2, 2, (V[]){v_path_2434, v_str_2441});
  return heff_tail(v_c_2448, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam6, 1, 7, (V[]){v_x_2428, v_dir_240, v_rest_245, v_p_242, v_p_243, v_x_248, v_f_246})});
}
V g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_dir_240 = heff_dup(heff_env(self)[0]);
  V v_f_246 = heff_dup(heff_env(self)[1]);
  V v_p_242 = heff_dup(heff_env(self)[2]);
  V v_text_247 = heff_dup(heff_env(self)[3]);
  V v_rest_245 = heff_dup(heff_env(self)[4]);
  V v_p_243 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_t_249 = (g_std_2epath_2eparse(v_x_248, heff_dup(v_dir_240)));
  V v_t_2410 = (g_std_2epath_2eparse(v_x_248, heff_dup(v_f_246)));
  V v_p_2411 = (g_std_2epath_2ejoin_2eonto_240(v_t_249, v_t_2410));
  V v_t_2412 = ({ V a_0 = heff_get(heff_dup(v_p_2411), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2411), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2413 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2411), LBL_drive), heff_get(v_p_2411, LBL_absolute), v_t_2412});
  V v_s_2414 = (g_std_2epath_2erender(v_x_248, v_t_2413));
  V v_p_2415 = (g_std_2epath_2eparse(v_x_248, v_s_2414));
  V v_t_2416 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2415), LBL_segments)));
  V v_xs_2417 = (g_prelude_2edrop(MK_INT(1LL), v_t_2416));
  V v_t_2418 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2417));
  V v_t_2419 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2415), LBL_drive), heff_get(v_p_2415, LBL_absolute), v_t_2418});
  V v_path_2420 = (g_std_2epath_2erender(v_x_248, v_t_2419));
  V v_c_2427 = heff_clo(g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam1, 2, 1, (V[]){v_path_2420});
  return heff_tail(v_c_2427, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132_lam3, 1, 7, (V[]){v_x_248, v_dir_240, v_f_246, v_text_247, v_p_242, v_rest_245, v_p_243})});
}
V g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam2(V self, V *args); static Clo g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam2, 1, 0};
V g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam1(V self, V *args);
V g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam4(V self, V *args);
V g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam3(V self, V *args);
V g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam0(V self, V *args);
Clo g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_entry, 4, 0};

V g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_x2_241);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take(v_x2_241, 3ULL);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      heff_take(v_x21_244, 1ULL);
      return (g_heff_2ecommands_2estyleNow_24s864_24s1010(heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam0, 1, 5, (V[]){v_dir_240, v_f_246, v_p_242, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam2(V self, V *args) {
  V v_t_2417 = args[0];
  heff_drop(self);
  return v_t_2417;
}
V g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_path_2414 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2414, ((V)&g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam2_clo)})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2415), LBL_malg), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get(v_hd_2415, LBL_bind), 2, (V[]){v_t_2420, v_k2_2416});
}
V g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2422 = heff_dup(heff_env(self)[0]);
  V v_p_243 = heff_dup(heff_env(self)[1]);
  V v_f_246 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    heff_drop(v_x_2422);
    heff_drop(v_f_246);
    return heff_tail(v_p_243, 1, (V[]){v_x_2423});
  }
  case TAG_Just: {
    heff_take(v_x_2422, 0ULL);
    return heff_tail(v_p_243, 1, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_f_246, v_x_2423})});
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_dir_240 = heff_dup(heff_env(self)[0]);
  V v_rest_245 = heff_dup(heff_env(self)[1]);
  V v_p_242 = heff_dup(heff_env(self)[2]);
  V v_p_243 = heff_dup(heff_env(self)[3]);
  V v_f_246 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  return (g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133(v_dir_240, v_rest_245, v_p_242, heff_clo(g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam4, 1, 3, (V[]){v_x_2422, v_p_243, v_f_246})));
}
V g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_dir_240 = heff_dup(heff_env(self)[0]);
  V v_f_246 = heff_dup(heff_env(self)[1]);
  V v_p_242 = heff_dup(heff_env(self)[2]);
  V v_rest_245 = heff_dup(heff_env(self)[3]);
  V v_p_243 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_249 = (g_std_2epath_2eparse(v_x_248, heff_dup(v_dir_240)));
  V v_t_2410 = (g_std_2epath_2eparse(v_x_248, heff_dup(v_f_246)));
  V v_p_2411 = (g_std_2epath_2ejoin_2eonto_240(v_t_249, v_t_2410));
  V v_t_2412 = ({ V a_0 = heff_get(heff_dup(v_p_2411), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2411), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2413 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2411), LBL_drive), heff_get(v_p_2411, LBL_absolute), v_t_2412});
  V v_path_2414 = ({ V a_0 = v_x_248; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_248); r_; });
  V v_c_2421 = heff_clo(g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam1, 2, 1, (V[]){v_path_2414});
  return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133_lam3, 1, 5, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243, v_f_246})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {80, 87, 68}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {48, 46, 49, 46, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {104, 101, 102, 102, 58, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[73]; } g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str3 = {{0x80000000u, K_STR, 0}, 73, 73, {96, 32, 99, 97, 110, 110, 111, 116, 32, 110, 97, 109, 101, 32, 97, 32, 112, 97, 99, 107, 97, 103, 101, 58, 32, 97, 32, 108, 111, 119, 101, 114, 99, 97, 115, 101, 32, 108, 101, 116, 116, 101, 114, 44, 32, 116, 104, 101, 110, 32, 108, 101, 116, 116, 101, 114, 115, 44, 32, 100, 105, 103, 105, 116, 115, 32, 97, 110, 100, 32, 96, 95, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str5 = {{0x80000000u, K_STR, 0}, 23, 23, {104, 101, 102, 102, 58, 32, 97, 32, 110, 101, 119, 32, 112, 114, 111, 106, 101, 99, 116, 32, 105, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str6 = {{0x80000000u, K_STR, 0}, 17, 17, {59, 32, 96, 104, 101, 102, 102, 32, 116, 101, 115, 116, 32, 115, 114, 99, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str7 = {{0x80000000u, K_STR, 0}, 19, 19, {47, 109, 97, 105, 110, 46, 104, 102, 96, 32, 99, 104, 101, 99, 107, 115, 32, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str10 = {{0x80000000u, K_STR, 0}, 6, 6, {104, 101, 102, 102, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str11 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 104, 97, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str12 = {{0x80000000u, K_STR, 0}, 25, 25, {32, 97, 108, 114, 101, 97, 100, 121, 59, 32, 110, 111, 116, 104, 105, 110, 103, 32, 119, 114, 105, 116, 116, 101, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam0(V self, V *args); static Clo g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam0, 1, 0};
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam4(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam6(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam9(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam10(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam11(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam12(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam8(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam7(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam5(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam3(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam2(V self, V *args);
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam1(V self, V *args);
Clo g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_entry, 3, 0};

V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str0), ((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam0_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_245})}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam1, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242})});
}
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam0(V self, V *args) {
  V v_v_243 = args[0];
  heff_drop(self);
  return v_v_243;
}
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam4(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_x_2410 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_2411);
  return heff_tail(v_k_2412, 1, (V[]){v_x_2410});
}
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam6(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_2417 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_2418);
  return heff_tail(v_k_2419, 1, (V[]){v_x_2417});
}
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam9(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2433}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2434, v_k_242});
}
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam10(V self, V *args) {
  V v_x_2435 = args[0];
  V v_dir_240 = heff_dup(heff_env(self)[0]);
  V v_x_2414 = heff_dup(heff_env(self)[1]);
  V v_hd_241 = heff_dup(heff_env(self)[2]);
  V v_k_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2435)) {
  case TAG_True: {
    heff_drop(v_x_2435);
    V v_t_2436 = heff_strAppend(((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str5), heff_strAppend(v_dir_240, heff_strAppend(((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str6), heff_strAppend(v_x_2414, ((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str7)))));
    V v_t_2437 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str8)), NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2439}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2440, v_k_242});
  }
  case TAG_False: {
    heff_drop(v_x_2435);
    heff_drop(v_dir_240);
    heff_drop(v_x_2414);
    V v_t_2441 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2442 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2443}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2444, v_k_242});
  }
  default: return heff_nomatch(v_x_2435);
  }
}
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam11(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k2_2452 = args[1];
  V v_str_2450 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2453 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2450, ((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str13)), NTAG(TAG_MkUnit)});
  V v_t_2454 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2451), LBL_malg), 1, (V[]){v_t_2455}));
  return heff_tail(heff_get(v_hd_2451, LBL_bind), 2, (V[]){v_t_2456, v_k2_2452});
}
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam12(V self, V *args) {
  V v_x_2458 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2458);
  V v_t_2459 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2460 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2461}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2462, v_k_242});
}
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam8(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2414 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  V v_dir_240 = heff_dup(heff_env(self)[3]);
  V v_x_2421 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_x1_2423 = (g_heff_2eproject_2eisName(heff_dup(v_x_2414)));
  V v_t_2424;
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_True: {
    heff_drop(v_x1_2423);
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    heff_drop(v_x1_2423);
    v_t_2424 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_2423);
  }
  switch (heff_tag_of(v_t_2424)) {
  case TAG_True: {
    heff_drop(v_x_2422);
    heff_drop(v_dir_240);
    heff_drop(v_x_2421);
    heff_drop(v_t_2424);
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str2), heff_strAppend(v_x_2414, ((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str3)));
    V v_t_2426 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2425, ((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str4)), NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2428}));
    return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2429, heff_clo(g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam9, 1, 2, (V[]){v_hd_241, v_k_242})});
  }
  case TAG_False: {
    heff_drop(v_t_2424);
    switch (heff_tag_of(v_x_2422)) {
    case TAG_Nil: {
      heff_drop(v_x_2422);
      return (g_heff_2ecommands_2ewriteAll_24s936_24s1043_24s1132(heff_dup(v_dir_240), v_x_2421, heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam10, 1, 4, (V[]){v_dir_240, v_x_2414, v_hd_241, v_k_242})));
    }
    case TAG_Cons: {
      heff_drop(v_x_2414);
      heff_drop(v_x_2421);
      V v_t_2449;
      switch (heff_tag_of(v_x_2422)) {
      case TAG_Nil: {
        heff_drop(v_x_2422);
        v_t_2449 = ((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str9);
        break;
      }
      case TAG_Cons: {
        V v_x_2447 = heff_field(v_x_2422, 0);
        V v_xs_2448 = heff_field(v_x_2422, 1);
        heff_take(v_x_2422, 3ULL);
        v_t_2449 = ({ V a_0 = v_x_2447; V a_1 = v_xs_2448; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2448); r_; });
        break;
      }
      default: heff_nomatch(v_x_2422);
      }
      V v_str_2450 = heff_strAppend(((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str10), heff_strAppend(v_dir_240, heff_strAppend(((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str11), heff_strAppend(v_t_2449, ((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str12)))));
      V v_c_2457 = heff_clo(g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam11, 2, 1, (V[]){v_str_2450});
      return heff_tail(v_c_2457, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam12, 1, 2, (V[]){v_hd_241, v_k_242})});
    }
    default: return heff_nomatch(v_x_2422);
    }
  }
  default: return heff_nomatch(v_t_2424);
  }
}
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_dir_240 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_x_2414 = heff_dup(heff_env(self)[2]);
  V v_k_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return (g_heff_2ecommands_2eexisting_24s935_24s1042_24s1133(heff_dup(v_dir_240), heff_dup(v_x_2421), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam8, 1, 5, (V[]){v_x_2414, v_hd_241, v_k_242, v_dir_240, v_x_2421})));
}
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_248 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_dir_240 = heff_dup(heff_env(self)[2]);
  V v_k_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2416;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    heff_drop(v_x_248);
    v_t_2416 = ((V)&g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x_248, 0);
    heff_take(v_x_248, 1ULL);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_x_2417 = (g_heff_2ecommands_2eprojectFiles(heff_dup(v_x_2414), v_t_2416));
  V v_c_2420 = heff_clo(g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam6, 2, 1, (V[]){v_x_2417});
  return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam7, 1, 4, (V[]){v_dir_240, v_hd_241, v_x_2414, v_k_242})});
}
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_dir_240 = heff_dup(heff_env(self)[0]);
  V v_x_247 = heff_dup(heff_env(self)[1]);
  V v_hd_241 = heff_dup(heff_env(self)[2]);
  V v_x_248 = heff_dup(heff_env(self)[3]);
  V v_k_242 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_x_2410 = ({ V a_0 = v_x_249; V a_1 = heff_dup(v_dir_240); V a_2 = v_x_247; V r_ = (g_heff_2ecommands_2eprojectName(a_0, a_1, a_2)); heff_drop(v_x_249); r_; });
  V v_c_2413 = heff_clo(g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam4, 2, 1, (V[]){v_x_2410});
  return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam5, 1, 4, (V[]){v_x_248, v_hd_241, v_dir_240, v_k_242})});
}
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_dir_240 = heff_dup(heff_env(self)[1]);
  V v_x_247 = heff_dup(heff_env(self)[2]);
  V v_k_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return (g_heff_2ecommands_2estyleNow_24s864_24s1010(heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam3, 1, 5, (V[]){v_dir_240, v_x_247, v_hd_241, v_x_248, v_k_242})));
}
V g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_dir_240 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return (g_heff_2ecommands_2eownVersion_24s886_24s1012_24s1098(heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2einitCmd_24s934_24s1041_24s1131_lam2, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_247, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 97, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {49}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str4 = {{0x80000000u, K_STR, 0}, 8, 8, {45, 45, 98, 114, 97, 110, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str5 = {{0x80000000u, K_STR, 0}, 7, 7, {45, 45, 113, 117, 105, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str6 = {{0x80000000u, K_STR, 0}, 7, 7, {45, 45, 100, 101, 112, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str7 = {{0x80000000u, K_STR, 0}, 25, 25, {97, 100, 118, 105, 99, 101, 46, 100, 101, 116, 97, 99, 104, 101, 100, 72, 101, 97, 100, 61, 102, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 108, 111, 110, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str10 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str11 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 116, 116, 112, 115, 58, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str12 = {{0x80000000u, K_STR, 0}, 13, 13, {99, 97, 110, 110, 111, 116, 32, 102, 101, 116, 99, 104, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str14 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 40, 116, 97, 103, 32, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str15 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str16 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str17 = {{0x80000000u, K_STR, 0}, 11, 11, {72, 69, 65, 68, 94, 123, 116, 114, 101, 101, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str18 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 101, 118, 45, 112, 97, 114, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str19 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str20 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 67}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str21 = {{0x80000000u, K_STR, 0}, 4, 4, {46, 103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str22 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 114, 101, 101, 58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str23 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 97, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str25 = {{0x80000000u, K_STR, 0}, 18, 18, {104, 101, 102, 102, 32, 103, 101, 116, 58, 32, 102, 101, 116, 99, 104, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str28 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 97, 110, 110, 111, 116, 32, 107, 101, 101, 112, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str30 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 105, 110, 32}};
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam0(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam3(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam3, 1, 0};
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam5(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam5, 1, 0};
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam8(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam8, 1, 0};
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam7(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam11(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam11, 1, 0};
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam10(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam13(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam13, 1, 0};
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam14(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam15(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam15, 1, 0};
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam18(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam18, 1, 0};
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam17(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam20(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam20, 1, 0};
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam22(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam24(V self, V *args); static Clo g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam24, 1, 0};
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam26(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam25(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam23(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam21(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam19(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam16(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam12(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam9(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam6(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam4(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam2(V self, V *args);
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam1(V self, V *args);
Clo g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_entry, 3, 0};

V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_x_243 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_241), heff_dup(v_v_242)));
  V v_c_246 = heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam0, 2, 1, (V[]){v_x_243});
  return heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam1, 2, 4, (V[]){v_c_246, v_ps_240, v_path_241, v_v_242});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2efetched_24s941_24s1048_24s1137(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_244);
  return heff_tail(v_k_245, 1, (V[]){v_x_243});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam3(V self, V *args) {
  V v_t_2410 = args[0];
  heff_drop(self);
  return v_t_2410;
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam5(V self, V *args) {
  V v_ok_2415 = args[0];
  heff_drop(self);
  return v_ok_2415;
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam8(V self, V *args) {
  V v_ok_2429 = args[0];
  heff_drop(self);
  return v_ok_2429;
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam7(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k2_2428 = args[1];
  V v_path_2426 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2430 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_2426, ((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam8_clo)})});
  V v_t_2431 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2427), LBL_malg), 1, (V[]){v_t_2431}));
  return heff_tail(heff_get(v_hd_2427, LBL_bind), 2, (V[]){v_t_2432, v_k2_2428});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam11(V self, V *args) {
  V v_r_2444 = args[0];
  heff_drop(self);
  return v_r_2444;
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam10(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k2_2443 = args[1];
  V v_as_2441 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2445 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str10), v_as_2441, ((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam11_clo)})});
  V v_t_2446 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2442), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2446})}));
  return heff_tail(heff_get(v_hd_2442, LBL_bind), 2, (V[]){v_t_2447, v_k2_2443});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam13(V self, V *args) {
  V v_ok_2452 = args[0];
  heff_drop(self);
  return v_ok_2452;
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam14(V self, V *args) {
  V v_x_2456 = args[0];
  V v_path_241 = heff_dup(heff_env(self)[0]);
  V v_x_2449 = heff_dup(heff_env(self)[1]);
  V v_v_242 = heff_dup(heff_env(self)[2]);
  V v_k_248 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_x_2456);
  V v_t_2457 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str11), (g_heff_2eproject_2erepoOf(heff_dup(v_path_241))));
  V v_s_2458 = heff_get(v_x_2449, LBL_err);
  V v_t_2459 = (g_prelude_2eskipSpaces(heff_dup(v_s_2458), MK_INT(0LL), MK_INT(1LL)));
  V v_t_2460 = heff_intSub(heff_strLength(heff_dup(v_s_2458)), MK_INT(1LL));
  V v_t_2461 = (g_prelude_2eskipSpaces(heff_dup(v_s_2458), v_t_2460, MK_INT(-1LL)));
  V v_t_2462 = heff_strSlice(v_s_2458, v_t_2459, heff_intAdd(v_t_2461, MK_INT(1LL)));
  V v_t_2463 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str12), heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str13), heff_strAppend(heff_dup(v_v_242), heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str14), heff_strAppend(v_v_242, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str15), heff_strAppend(v_t_2457, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str16), v_t_2462)))))))));
  V v_x_2464 = heff_tag(TAG_Left, 1, (V[]){v_t_2463});
  return heff_tail(v_k_248, 1, (V[]){v_x_2464});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam15(V self, V *args) {
  V v_r_2467 = args[0];
  heff_drop(self);
  return v_r_2467;
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam18(V self, V *args) {
  V v_ok_2482 = args[0];
  heff_drop(self);
  return v_ok_2482;
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam17(V self, V *args) {
  V v_hd_2480 = args[0];
  V v_k2_2481 = args[1];
  V v_path_2479 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2483 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){v_path_2479, ((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam18_clo)})});
  V v_t_2484 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2480), LBL_malg), 1, (V[]){v_t_2484}));
  return heff_tail(heff_get(v_hd_2480, LBL_bind), 2, (V[]){v_t_2485, v_k2_2481});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam20(V self, V *args) {
  V v_ok_2488 = args[0];
  heff_drop(self);
  return v_ok_2488;
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam22(V self, V *args) {
  V v_hd_2499 = args[0];
  V v_k_24100 = args[1];
  V v_x_2498 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_2499);
  return heff_tail(v_k_24100, 1, (V[]){v_x_2498});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam24(V self, V *args) {
  V v_ok_24103 = args[0];
  heff_drop(self);
  return v_ok_24103;
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam26(V self, V *args) {
  V v_x_24115 = args[0];
  V v_k_248 = heff_dup(heff_env(self)[0]);
  V v_x_24102 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_24115);
  return heff_tail(v_k_248, 1, (V[]){heff_tag(TAG_Right, 1, (V[]){v_x_24102})});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam25(V self, V *args) {
  V v_x_24107 = args[0];
  V v_x_2472 = heff_dup(heff_env(self)[0]);
  V v_x_2492 = heff_dup(heff_env(self)[1]);
  V v_path_241 = heff_dup(heff_env(self)[2]);
  V v_v_242 = heff_dup(heff_env(self)[3]);
  V v_hd_247 = heff_dup(heff_env(self)[4]);
  V v_k_248 = heff_dup(heff_env(self)[5]);
  V v_x_24102 = heff_dup(heff_env(self)[6]);
  V v_x_249 = heff_dup(heff_env(self)[7]);
  heff_drop(self);
  V v_t_24108 = heff_intEq(heff_get(v_x_2472, LBL_status), MK_INT(0LL));
  V v_t_24109;
  switch (heff_tag_of(v_t_24108)) {
  case TAG_True: {
    heff_drop(v_t_24108);
    switch (heff_tag_of(v_x_2492)) {
    case TAG_True: {
      heff_drop(v_x_2492);
      v_t_24109 = v_x_24107;
      break;
    }
    case TAG_False: {
      heff_drop(v_x_24107);
      heff_drop(v_x_2492);
      v_t_24109 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2492);
    }
    break;
  }
  case TAG_False: {
    heff_drop(v_x_24107);
    heff_drop(v_x_2492);
    heff_drop(v_t_24108);
    v_t_24109 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_24108);
  }
  switch (heff_tag_of(v_t_24109)) {
  case TAG_True: {
    heff_drop(v_x_249);
    heff_drop(v_t_24109);
    V v_t_24110 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str25), heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str26), v_v_242)));
    V v_t_24111 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_24110, ((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str27)), NTAG(TAG_MkUnit)});
    V v_t_24112 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24111})});
    V v_t_24113 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24112})});
    V v_t_24114 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_24113}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_24114, heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam26, 1, 2, (V[]){v_k_248, v_x_24102})});
  }
  case TAG_False: {
    heff_drop(v_hd_247);
    heff_drop(v_x_24102);
    heff_drop(v_t_24109);
    V v_t_24116 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str28), heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str29), heff_strAppend(v_v_242, heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str30), v_x_249)))));
    return heff_tail(v_k_248, 1, (V[]){heff_tag(TAG_Left, 1, (V[]){v_t_24116})});
  }
  default: return heff_nomatch(v_t_24109);
  }
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam23(V self, V *args) {
  V v_x_24102 = args[0];
  V v_x_249 = heff_dup(heff_env(self)[0]);
  V v_hd_247 = heff_dup(heff_env(self)[1]);
  V v_x_2472 = heff_dup(heff_env(self)[2]);
  V v_x_2492 = heff_dup(heff_env(self)[3]);
  V v_path_241 = heff_dup(heff_env(self)[4]);
  V v_v_242 = heff_dup(heff_env(self)[5]);
  V v_k_248 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  V v_t_24104 = heff_tag(TAG_WriteFile, 3, (V[]){heff_strAppend(heff_dup(v_x_249), ((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str23)), heff_strAppend(heff_dup(v_x_24102), ((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str24)), ((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam24_clo)});
  V v_t_24105 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24105})}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_24106, heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam25, 1, 8, (V[]){v_x_2472, v_x_2492, v_path_241, v_v_242, v_hd_247, v_k_248, v_x_24102, v_x_249})});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam21(V self, V *args) {
  V v_x_2492 = args[0];
  V v_x_2472 = heff_dup(heff_env(self)[0]);
  V v_hd_247 = heff_dup(heff_env(self)[1]);
  V v_x_249 = heff_dup(heff_env(self)[2]);
  V v_path_241 = heff_dup(heff_env(self)[3]);
  V v_v_242 = heff_dup(heff_env(self)[4]);
  V v_k_248 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_s_2493 = heff_get(heff_dup(v_x_2472), LBL_out);
  V v_t_2494 = (g_prelude_2eskipSpaces(heff_dup(v_s_2493), MK_INT(0LL), MK_INT(1LL)));
  V v_t_2495 = heff_intSub(heff_strLength(heff_dup(v_s_2493)), MK_INT(1LL));
  V v_t_2496 = (g_prelude_2eskipSpaces(heff_dup(v_s_2493), v_t_2495, MK_INT(-1LL)));
  V v_t_2497 = heff_strSlice(v_s_2493, v_t_2494, heff_intAdd(v_t_2496, MK_INT(1LL)));
  V v_x_2498 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str22), v_t_2497);
  V v_c_24101 = heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam22, 2, 1, (V[]){v_x_2498});
  return heff_tail(v_c_24101, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam23, 1, 7, (V[]){v_x_249, v_hd_247, v_x_2472, v_x_2492, v_path_241, v_v_242, v_k_248})});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam19(V self, V *args) {
  V v_x_2487 = args[0];
  V v_x_249 = heff_dup(heff_env(self)[0]);
  V v_hd_247 = heff_dup(heff_env(self)[1]);
  V v_x_2472 = heff_dup(heff_env(self)[2]);
  V v_path_241 = heff_dup(heff_env(self)[3]);
  V v_v_242 = heff_dup(heff_env(self)[4]);
  V v_k_248 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  heff_drop(v_x_2487);
  V v_t_2489 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadOnly, 2, (V[]){heff_dup(v_x_249), ((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam20_clo)})});
  V v_t_2490 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2490}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2491, heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam21, 1, 6, (V[]){v_x_2472, v_hd_247, v_x_249, v_path_241, v_v_242, v_k_248})});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam16(V self, V *args) {
  V v_x_2472 = args[0];
  V v_ps_240 = heff_dup(heff_env(self)[0]);
  V v_x_249 = heff_dup(heff_env(self)[1]);
  V v_hd_247 = heff_dup(heff_env(self)[2]);
  V v_path_241 = heff_dup(heff_env(self)[3]);
  V v_v_242 = heff_dup(heff_env(self)[4]);
  V v_k_248 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_st_2473 = heff_get(v_ps_240, LBL_style);
  V v_t_2474 = (g_std_2epath_2eparse(v_st_2473, heff_dup(v_x_249)));
  V v_t_2475 = (g_std_2epath_2eparse(v_st_2473, ((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str21)));
  V v_p_2476 = (g_std_2epath_2ejoin_2eonto_240(v_t_2474, v_t_2475));
  V v_t_2477 = ({ V a_0 = heff_get(heff_dup(v_p_2476), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2476), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2478 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2476), LBL_drive), heff_get(v_p_2476, LBL_absolute), v_t_2477});
  V v_path_2479 = ({ V a_0 = v_st_2473; V a_1 = v_t_2478; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2473); r_; });
  V v_c_2486 = heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam17, 2, 1, (V[]){v_path_2479});
  return heff_tail(v_c_2486, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam19, 1, 6, (V[]){v_x_249, v_hd_247, v_x_2472, v_path_241, v_v_242, v_k_248})});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam12(V self, V *args) {
  V v_x_2449 = args[0];
  V v_x_249 = heff_dup(heff_env(self)[0]);
  V v_hd_247 = heff_dup(heff_env(self)[1]);
  V v_path_241 = heff_dup(heff_env(self)[2]);
  V v_v_242 = heff_dup(heff_env(self)[3]);
  V v_k_248 = heff_dup(heff_env(self)[4]);
  V v_ps_240 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_t_2450 = heff_intEq(heff_get(heff_dup(v_x_2449), LBL_status), MK_INT(0LL));
  V v_t_2451;
  switch (heff_tag_of(v_t_2450)) {
  case TAG_True: {
    heff_drop(v_t_2450);
    v_t_2451 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2450);
    v_t_2451 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2450);
  }
  switch (heff_tag_of(v_t_2451)) {
  case TAG_True: {
    heff_drop(v_ps_240);
    heff_drop(v_t_2451);
    V v_t_2453 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){v_x_249, ((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam13_clo)})});
    V v_t_2454 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2454}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2455, heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam14, 1, 4, (V[]){v_path_241, v_x_2449, v_v_242, v_k_248})});
  }
  case TAG_False: {
    heff_drop(v_x_2449);
    heff_drop(v_t_2451);
    V v_t_2465 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str17), NTAG(TAG_Nil)});
    V v_t_2466 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_249), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str18), v_t_2465})});
    V v_t_2468 = heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str19), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str20), v_t_2466}), ((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam15_clo)});
    V v_t_2469 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2470}));
    return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2471, heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam16, 1, 6, (V[]){v_ps_240, v_x_249, v_hd_247, v_path_241, v_v_242, v_k_248})});
  }
  default: return heff_nomatch(v_t_2451);
  }
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam9(V self, V *args) {
  V v_x_2434 = args[0];
  V v_path_241 = heff_dup(heff_env(self)[0]);
  V v_x_249 = heff_dup(heff_env(self)[1]);
  V v_v_242 = heff_dup(heff_env(self)[2]);
  V v_hd_247 = heff_dup(heff_env(self)[3]);
  V v_k_248 = heff_dup(heff_env(self)[4]);
  V v_ps_240 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str1), (g_heff_2eproject_2erepoOf(heff_dup(v_path_241))));
  V v_t_2436 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_249), NTAG(TAG_Nil)});
  V v_t_2437 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str2), heff_dup(v_v_242)), heff_tag(TAG_Cons, 2, (V[]){v_t_2435, v_t_2436})});
  V v_t_2438 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str4), v_t_2437})});
  V v_t_2439 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str6), v_t_2438})});
  V v_t_2440 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str8), v_t_2439})});
  V v_as_2441 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str9), v_t_2440});
  V v_c_2448 = heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam10, 2, 1, (V[]){v_as_2441});
  return heff_tail(v_c_2448, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam12, 1, 6, (V[]){v_x_249, v_hd_247, v_path_241, v_v_242, v_k_248, v_ps_240})});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ps_240 = heff_dup(heff_env(self)[0]);
  V v_x_249 = heff_dup(heff_env(self)[1]);
  V v_hd_247 = heff_dup(heff_env(self)[2]);
  V v_path_241 = heff_dup(heff_env(self)[3]);
  V v_v_242 = heff_dup(heff_env(self)[4]);
  V v_k_248 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  heff_drop(v_x_2419);
  V v_st_2420 = heff_get(heff_dup(v_ps_240), LBL_style);
  V v_p_2421 = (g_std_2epath_2eparse(v_st_2420, heff_dup(v_x_249)));
  V v_t_2422 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_p_2421), LBL_segments)));
  V v_xs_2423 = (g_prelude_2edrop(MK_INT(1LL), v_t_2422));
  V v_t_2424 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2423));
  V v_t_2425 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2421), LBL_drive), heff_get(v_p_2421, LBL_absolute), v_t_2424});
  V v_path_2426 = ({ V a_0 = v_st_2420; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2420); r_; });
  V v_c_2433 = heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam7, 2, 1, (V[]){v_path_2426});
  return heff_tail(v_c_2433, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam9, 1, 6, (V[]){v_path_241, v_x_249, v_v_242, v_hd_247, v_k_248, v_ps_240})});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_249 = heff_dup(heff_env(self)[0]);
  V v_hd_247 = heff_dup(heff_env(self)[1]);
  V v_ps_240 = heff_dup(heff_env(self)[2]);
  V v_path_241 = heff_dup(heff_env(self)[3]);
  V v_v_242 = heff_dup(heff_env(self)[4]);
  V v_k_248 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    heff_drop(v_x_2414);
    V v_t_2416 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Remove, 2, (V[]){heff_dup(v_x_249), ((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam5_clo)})});
    V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2417}));
    return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2418, heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam6, 1, 6, (V[]){v_ps_240, v_x_249, v_hd_247, v_path_241, v_v_242, v_k_248})});
  }
  case TAG_Just: {
    V v_h_24117 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Just = heff_take_reuse(v_x_2414, 1ULL);
    heff_drop(v_x_249);
    heff_drop(v_hd_247);
    heff_drop(v_ps_240);
    heff_drop(v_path_241);
    heff_drop(v_v_242);
    V v_t_24118 = (g_prelude_2eskipSpaces(heff_dup(v_h_24117), MK_INT(0LL), MK_INT(1LL)));
    V v_t_24119 = heff_intSub(heff_strLength(heff_dup(v_h_24117)), MK_INT(1LL));
    V v_t_24120 = (g_prelude_2eskipSpaces(heff_dup(v_h_24117), v_t_24119, MK_INT(-1LL)));
    V v_t_24121 = heff_strSlice(v_h_24117, v_t_24118, heff_intAdd(v_t_24120, MK_INT(1LL)));
    V v_x_24122 = heff_tag_at(v_ru_24x_2414_24Just, TAG_Right, 1, (V[]){v_t_24121});
    return heff_tail(v_k_248, 1, (V[]){v_x_24122});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_dup(heff_env(self)[0]);
  V v_ps_240 = heff_dup(heff_env(self)[1]);
  V v_path_241 = heff_dup(heff_env(self)[2]);
  V v_v_242 = heff_dup(heff_env(self)[3]);
  V v_k_248 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2411 = heff_tag(TAG_ReadFile, 2, (V[]){heff_strAppend(heff_dup(v_x_249), ((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_str0)), ((V)&g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam3_clo)});
  V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam4, 1, 6, (V[]){v_x_249, v_hd_247, v_ps_240, v_path_241, v_v_242, v_k_248})});
}
V g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_dup(heff_env(self)[0]);
  V v_ps_240 = heff_dup(heff_env(self)[1]);
  V v_path_241 = heff_dup(heff_env(self)[2]);
  V v_v_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2efetched_24s941_24s1048_24s1137_lam2, 1, 5, (V[]){v_hd_247, v_ps_240, v_path_241, v_v_242, v_k_248})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 114, 101, 113, 117, 105, 114, 101, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 105, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_str5 = {{0x80000000u, K_STR, 0}, 20, 20, {44, 32, 97, 110, 100, 32, 104, 101, 102, 102, 46, 115, 117, 109, 32, 115, 97, 121, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_str6 = {{0x80000000u, K_STR, 0}, 24, 24, {58, 32, 105, 116, 115, 32, 116, 97, 103, 32, 104, 97, 115, 32, 98, 101, 101, 110, 32, 109, 111, 118, 101, 100}};
V g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam0(V self, V *args);
V g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam1(V self, V *args);
V g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam4(V self, V *args);
V g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam3(V self, V *args);
V g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam2(V self, V *args);
Clo g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_entry, 6, 0};

V g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_t_247 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam0, 1, 1, (V[]){heff_dup(v_path_244)}), heff_get(heff_dup(v_root_241), LBL_require)));
  V v_t_2414;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nil: {
    heff_drop(v_root_241);
    heff_drop(v_t_247);
    v_t_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_248 = heff_field(v_t_247, 0);
    heff_take(v_t_247, 1ULL);
    V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam1, 1, 1, (V[]){v_r_248}), heff_get(v_root_241, LBL_replace)));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nil: {
      heff_drop(v_t_2411);
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2412 = heff_field(v_t_2411, 0);
      heff_take(v_t_2411, 1ULL);
      v_t_2414 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_p_2412, LBL_dir)});
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    heff_drop(v_t_2414);
    V v_c_2415 = (g_heff_2ecommands_2efetched_24s941_24s1048_24s1137(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    return heff_clo(g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam2, 2, 6, (V[]){v_c_2415, v_by_243, v_path_244, v_v_245, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2435 = heff_field(v_t_2414, 0);
    heff_take(v_t_2414, 1ULL);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_st_2436 = heff_get(heff_dup(v_ps_240), LBL_style);
    V v_t_2437 = (g_std_2epath_2eparse(v_st_2436, heff_get(heff_dup(v_ps_240), LBL_root)));
    V v_t_2438 = (g_std_2epath_2eparse(v_st_2436, v_d_2435));
    V v_p_2439 = (g_std_2epath_2ejoin_2eonto_240(v_t_2437, v_t_2438));
    V v_t_2440 = ({ V a_0 = heff_get(heff_dup(v_p_2439), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2439), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2441 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2439), LBL_drive), heff_get(v_p_2439, LBL_absolute), v_t_2440});
    V v_t_2442 = ({ V a_0 = v_st_2436; V a_1 = v_t_2441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2436); r_; });
    return (g_heff_2eload_2ereadPkgAt_24s876_24s1090(v_ps_240, v_t_2442, v_path_244));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam0(V self, V *args) {
  V v_r_246 = args[0];
  V v_path_244 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_r_246, LBL_path), v_path_244);
}
V g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam1(V self, V *args) {
  V v_p_2410 = args[0];
  V v_r_248 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_p_2410, LBL_name), heff_get(v_r_248, LBL_name));
}
V g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam4(V self, V *args) {
  V v_s_2422 = args[0];
  V v_path_244 = heff_dup(heff_env(self)[0]);
  V v_v_245 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2423 = heff_strEq(heff_get(heff_dup(v_s_2422), LBL_path), v_path_244);
  switch (heff_tag_of(v_t_2423)) {
  case TAG_True: {
    heff_drop(v_t_2423);
    return heff_strEq(heff_get(v_s_2422, LBL_version), v_v_245);
  }
  case TAG_False: {
    heff_drop(v_s_2422);
    heff_drop(v_v_245);
    heff_drop(v_t_2423);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2423);
  }
}
V g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_by_243 = heff_dup(heff_env(self)[0]);
  V v_path_244 = heff_dup(heff_env(self)[1]);
  V v_v_245 = heff_dup(heff_env(self)[2]);
  V v_k_2417 = heff_dup(heff_env(self)[3]);
  V v_sums_242 = heff_dup(heff_env(self)[4]);
  V v_ps_240 = heff_dup(heff_env(self)[5]);
  V v_hd_2416 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_why_2419 = heff_field(v_x_2418, 0);
    heff_take(v_x_2418, 1ULL);
    heff_drop(v_sums_242);
    heff_drop(v_ps_240);
    heff_drop(v_hd_2416);
    V v_t_2420 = heff_strAppend(v_by_243, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_str0), heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_str1), heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_str2), v_why_2419))))));
    return heff_tail(v_k_2417, 1, (V[]){heff_tag(TAG_Left, 1, (V[]){v_t_2420})});
  }
  case TAG_Right: {
    V v_h_2421 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse(v_x_2418, 1ULL);
    heff_drop(v_by_243);
    V v_t_2424 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam4, 1, 2, (V[]){heff_dup(v_path_244), heff_dup(v_v_245)}), v_sums_242));
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      heff_drop(v_ru_24x_2418_24Right);
      heff_drop(v_t_2424);
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_s_2425 = heff_field(v_t_2424, 0);
      heff_take(v_t_2424, 1ULL);
      v_t_2427 = heff_tag_at(v_ru_24x_2418_24Right, TAG_Just, 1, (V[]){heff_get(v_s_2425, LBL_hash)});
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nothing: {
      heff_drop(v_h_2421);
      heff_drop(v_t_2427);
      V v_t_2428 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
      V v_t_2429 = (g_heff_2eload_2ereadPkgAt_24s876_24s1090(v_ps_240, v_t_2428, v_path_244));
      return heff_tail(v_t_2429, 2, (V[]){v_hd_2416, v_k_2417});
    }
    case TAG_Just: {
      V v_want_2430 = heff_field(v_t_2427, 0);
      heff_take(v_t_2427, 1ULL);
      V v_t_2431 = heff_strEq(heff_dup(v_h_2421), heff_dup(v_want_2430));
      switch (heff_tag_of(v_t_2431)) {
      case TAG_True: {
        heff_drop(v_h_2421);
        heff_drop(v_want_2430);
        heff_drop(v_t_2431);
        V v_t_2432 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2433 = (g_heff_2eload_2ereadPkgAt_24s876_24s1090(v_ps_240, v_t_2432, v_path_244));
        return heff_tail(v_t_2433, 2, (V[]){v_hd_2416, v_k_2417});
      }
      case TAG_False: {
        heff_drop(v_ps_240);
        heff_drop(v_hd_2416);
        heff_drop(v_t_2431);
        V v_t_2434 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_str3), heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_str4), heff_strAppend(v_h_2421, heff_strAppend(((V)&g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_str5), heff_strAppend(v_want_2430, ((V)&g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_str6))))))));
        return heff_tail(v_k_2417, 1, (V[]){heff_tag(TAG_Left, 1, (V[]){v_t_2434})});
      }
      default: return heff_nomatch(v_t_2431);
      }
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_dup(heff_env(self)[0]);
  V v_by_243 = heff_dup(heff_env(self)[1]);
  V v_path_244 = heff_dup(heff_env(self)[2]);
  V v_v_245 = heff_dup(heff_env(self)[3]);
  V v_sums_242 = heff_dup(heff_env(self)[4]);
  V v_ps_240 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  return heff_tail(v_c_2415, 2, (V[]){heff_dup(v_hd_2416), heff_clo(g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136_lam3, 1, 7, (V[]){v_by_243, v_path_244, v_v_245, v_k_2417, v_sums_242, v_ps_240, v_hd_2416})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2esumsOf_24s942_24s1138_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 97, 115, 104}};
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam0(V self, V *args); static Clo g_heff_2ecommands_2esumsOf_24s942_24s1138_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2esumsOf_24s942_24s1138_lam0, 2, 0};
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam4(V self, V *args); static Clo g_heff_2ecommands_2esumsOf_24s942_24s1138_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2esumsOf_24s942_24s1138_lam4, 1, 0};
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam3(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam6(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam7(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam5(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam2(V self, V *args);
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam1(V self, V *args);
Clo g_heff_2ecommands_2esumsOf_24s942_24s1138_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2esumsOf_24s942_24s1138_entry, 3, 0};

V g_heff_2ecommands_2esumsOf_24s942_24s1138(V v_ps_240, V v_root_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_root_241);
    heff_drop(v_x3_242);
    return ((V)&g_heff_2ecommands_2esumsOf_24s942_24s1138_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take(v_x3_242, 3ULL);
    V v_c_247 = (g_heff_2ecommands_2esumsOf_24s942_24s1138(heff_dup(v_ps_240), heff_dup(v_root_241), v_rest_246));
    return heff_clo(g_heff_2ecommands_2esumsOf_24s942_24s1138_lam1, 2, 4, (V[]){v_c_247, v_ps_240, v_x_245, v_root_241});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecommands_2esumsOf_24s942_24s1138_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2esumsOf_24s942_24s1138(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(self);
  heff_drop(v_hd_243);
  return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_Nil)});
}
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam4(V self, V *args) {
  V v_t_2415 = args[0];
  heff_drop(self);
  return v_t_2415;
}
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam3(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_path_2412 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2416 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2412, ((V)&g_heff_2ecommands_2esumsOf_24s942_24s1138_lam4_clo)})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2413), LBL_malg), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get(v_hd_2413, LBL_bind), 2, (V[]){v_t_2418, v_k2_2414});
}
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam6(V self, V *args) {
  V v_r_2421 = args[0];
  V v_x_245 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_r_2421, LBL_path), heff_get(v_x_245, LBL_path));
}
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam7(V self, V *args) {
  V v_p_2431 = args[0];
  V v_r_2429 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_p_2431, LBL_name), heff_get(v_r_2429, LBL_name));
}
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_245 = heff_dup(heff_env(self)[0]);
  V v_root_241 = heff_dup(heff_env(self)[1]);
  V v_x_2410 = heff_dup(heff_env(self)[2]);
  V v_k_249 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2422 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2esumsOf_24s942_24s1138_lam6, 1, 1, (V[]){heff_dup(v_x_245)}), heff_get(heff_dup(v_root_241), LBL_require)));
  V v_x_2441;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Nil: {
    heff_drop(v_root_241);
    heff_drop(v_t_2422);
    switch (heff_tag_of(v_x_2420)) {
    case TAG_Nothing: {
      heff_drop(v_x_2420);
      heff_drop(v_x_245);
      v_x_2441 = v_x_2410;
      break;
    }
    case TAG_Just: {
      V v_t_2423 = heff_field(v_x_2420, 0);
      heff_take(v_x_2420, 1ULL);
      V v_t_2424 = (g_prelude_2eskipSpaces(heff_dup(v_t_2423), MK_INT(0LL), MK_INT(1LL)));
      V v_t_2425 = heff_intSub(heff_strLength(heff_dup(v_t_2423)), MK_INT(1LL));
      V v_t_2426 = (g_prelude_2eskipSpaces(heff_dup(v_t_2423), v_t_2425, MK_INT(-1LL)));
      V v_t_2427 = heff_strSlice(v_t_2423, v_t_2424, heff_intAdd(v_t_2426, MK_INT(1LL)));
      V v_t_2428 = heff_rec(3, shape_228_355_115, (V[]){heff_get(heff_dup(v_x_245), LBL_path), heff_get(v_x_245, LBL_version), v_t_2427});
      v_x_2441 = heff_tag(TAG_Cons, 2, (V[]){v_t_2428, v_x_2410});
      break;
    }
    default: heff_nomatch(v_x_2420);
    }
    break;
  }
  case TAG_Cons: {
    V v_r_2429 = heff_field(v_t_2422, 0);
    V v_ru_24t_2422_24Cons = heff_take_reuse(v_t_2422, 1ULL);
    V v_t_2432 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2esumsOf_24s942_24s1138_lam7, 1, 1, (V[]){v_r_2429}), heff_get(v_root_241, LBL_replace)));
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nil: {
      heff_drop(v_t_2432);
      switch (heff_tag_of(v_x_2420)) {
      case TAG_Nothing: {
        heff_drop(v_x_2420);
        heff_drop(v_x_245);
        heff_drop(v_ru_24t_2422_24Cons);
        v_x_2441 = v_x_2410;
        break;
      }
      case TAG_Just: {
        V v_t_2433 = heff_field(v_x_2420, 0);
        heff_take(v_x_2420, 1ULL);
        V v_t_2434 = (g_prelude_2eskipSpaces(heff_dup(v_t_2433), MK_INT(0LL), MK_INT(1LL)));
        V v_t_2435 = heff_intSub(heff_strLength(heff_dup(v_t_2433)), MK_INT(1LL));
        V v_t_2436 = (g_prelude_2eskipSpaces(heff_dup(v_t_2433), v_t_2435, MK_INT(-1LL)));
        V v_t_2437 = heff_strSlice(v_t_2433, v_t_2434, heff_intAdd(v_t_2436, MK_INT(1LL)));
        V v_t_2438 = heff_rec(3, shape_228_355_115, (V[]){heff_get(heff_dup(v_x_245), LBL_path), heff_get(v_x_245, LBL_version), v_t_2437});
        v_x_2441 = heff_tag_at(v_ru_24t_2422_24Cons, TAG_Cons, 2, (V[]){v_t_2438, v_x_2410});
        break;
      }
      default: heff_nomatch(v_x_2420);
      }
      break;
    }
    case TAG_Cons: {
      heff_take(v_t_2432, 0ULL);
      heff_drop(v_x_2420);
      heff_drop(v_x_245);
      heff_drop(v_ru_24t_2422_24Cons);
      v_x_2441 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  return heff_tail(v_k_249, 1, (V[]){v_x_2441});
}
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_dup(heff_env(self)[0]);
  V v_x_245 = heff_dup(heff_env(self)[1]);
  V v_hd_248 = heff_dup(heff_env(self)[2]);
  V v_root_241 = heff_dup(heff_env(self)[3]);
  V v_k_249 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2411 = (g_heff_2eload_2ecachedDir(v_ps_240, heff_get(heff_dup(v_x_245), LBL_path), heff_get(heff_dup(v_x_245), LBL_version)));
  V v_path_2412 = heff_strAppend(v_t_2411, ((V)&g_heff_2ecommands_2esumsOf_24s942_24s1138_str0));
  V v_c_2419 = heff_clo(g_heff_2ecommands_2esumsOf_24s942_24s1138_lam3, 2, 1, (V[]){v_path_2412});
  return heff_tail(v_c_2419, 2, (V[]){v_hd_248, heff_clo(g_heff_2ecommands_2esumsOf_24s942_24s1138_lam5, 1, 4, (V[]){v_x_245, v_root_241, v_x_2410, v_k_249})});
}
V g_heff_2ecommands_2esumsOf_24s942_24s1138_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_dup(heff_env(self)[0]);
  V v_ps_240 = heff_dup(heff_env(self)[1]);
  V v_x_245 = heff_dup(heff_env(self)[2]);
  V v_root_241 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_hd_248), heff_clo(g_heff_2ecommands_2esumsOf_24s942_24s1138_lam2, 1, 5, (V[]){v_ps_240, v_x_245, v_hd_248, v_root_241, v_k_249})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str1 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[51]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str3 = {{0x80000000u, K_STR, 0}, 51, 51, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 114, 101, 97, 100, 58, 32, 103, 101, 116, 32, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str5 = {{0x80000000u, K_STR, 0}, 11, 11, {116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str9 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 46, 115, 117, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str10 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 32, 103, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str11 = {{0x80000000u, K_STR, 0}, 21, 21, {99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32, 104, 101, 102, 102, 46, 115, 117, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str12 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str13 = {{0x80000000u, K_STR, 0}, 8, 8, {104, 101, 102, 102, 32, 103, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str14 = {{0x80000000u, K_STR, 0}, 10, 10, {104, 101, 102, 102, 32, 103, 101, 116, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str15 = {{0x80000000u, K_STR, 0}, 27, 27, {32, 112, 97, 99, 107, 97, 103, 101, 115, 44, 32, 104, 101, 102, 102, 46, 115, 117, 109, 32, 119, 114, 105, 116, 116, 101, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam2(V self, V *args); static Clo g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam2, 1, 0};
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam5(V self, V *args);
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam6(V self, V *args);
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam9(V self, V *args); static Clo g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam9, 2, 0};
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam11(V self, V *args); static Clo g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam11, 1, 0};
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam10(V self, V *args);
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam16(V self, V *args);
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam15(V self, V *args);
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam14(V self, V *args);
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam13(V self, V *args);
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam12(V self, V *args);
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam8(V self, V *args);
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam7(V self, V *args);
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam4(V self, V *args);
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam3(V self, V *args);
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam1(V self, V *args);
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam0(V self, V *args);
Clo g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_entry, 2, 0};

V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135(V v_hd_240, V v_k_241) {
top: ;
  return (g_heff_2ecommands_2ehostNow_24s862_24s1008(heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135(a[0], a[1]);
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam2(V self, V *args) {
  V v_t_245 = args[0];
  heff_drop(self);
  return v_t_245;
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam5(V self, V *args) {
  V v_r_2421 = args[0];
  V v_by_2420 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_rec(3, shape_31_228_355, (V[]){v_by_2420, heff_get(heff_dup(v_r_2421), LBL_path), heff_get(v_r_2421, LBL_version)});
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam6(V self, V *args) {
  V v_by_2423 = args[0];
  V v_path_2424 = args[1];
  V v_v_2425 = args[2];
  V v_x_244 = heff_dup(heff_env(self)[0]);
  V v_root_2414 = heff_dup(heff_env(self)[1]);
  V v_sums_2418 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return (g_heff_2ecommands_2efetchedPkg_24s940_24s1047_24s1136(v_x_244, v_root_2414, v_sums_2418, v_by_2423, v_path_2424, v_v_2425));
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam9(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  heff_drop(self);
  heff_drop(v_hd_2439);
  return heff_tail(v_k_2440, 1, (V[]){NTAG(TAG_True)});
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam11(V self, V *args) {
  V v_ok_2448 = args[0];
  heff_drop(self);
  return v_ok_2448;
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam10(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k2_2447 = args[1];
  V v_str_2445 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2449 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str9), v_str_2445, ((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam11_clo)})});
  V v_t_2450 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2446), LBL_malg), 1, (V[]){v_t_2450}));
  return heff_tail(heff_get(v_hd_2446, LBL_bind), 2, (V[]){v_t_2451, v_k2_2447});
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam16(V self, V *args) {
  V v_x_2476 = args[0];
  V v_seen_2474 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return ({ V a_0 = v_x_2476; V a_1 = v_seen_2474; V r_ = (g_prelude_2efoldl_24s746(a_0, a_1)); heff_drop(v_seen_2474); r_; });
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam15(V self, V *args) {
  V v_x_2466 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  V v_x_2427 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2467 = heff_intLt(MK_INT(0LL), v_x_2466);
  switch (heff_tag_of(v_t_2467)) {
  case TAG_True: {
    heff_drop(v_x_2427);
    heff_drop(v_t_2467);
    V v_t_2468 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2469 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2470}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2471, v_k_241});
  }
  case TAG_False: {
    heff_drop(v_t_2467);
    V v_seen_2474;
    switch (heff_tag_of(v_x_2427)) {
    case TAG_MkPair: {
      V v_x_2472 = heff_field(v_x_2427, 0);
      heff_take(v_x_2427, 1ULL);
      v_seen_2474 = v_x_2472;
      break;
    }
    default: heff_nomatch(v_x_2427);
    }
    V v_t_2475 = (g_prelude_2efoldl_24s747(NTAG(TAG_Nil), heff_dup(v_seen_2474)));
    V v_xs_2477 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam16, 1, 1, (V[]){v_seen_2474}), v_t_2475));
    V v_t_2478 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2477; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2477); r_; });
    V v_str_2479 = heff_strAppend(((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str14), heff_strAppend(heff_intShow(v_t_2478), ((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str15)));
    V v_t_2480 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2479, ((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str16)), NTAG(TAG_MkUnit)});
    V v_t_2481 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2482}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2483, v_k_241});
  }
  default: return heff_nomatch(v_t_2467);
  }
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam14(V self, V *args) {
  V v_x_2465 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  V v_x_2427 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str13), heff_get(v_x_2465, LBL_errors), MK_INT(0LL), heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam15, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2427})));
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam13(V self, V *args) {
  V v_x_2458 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  V v_x_2453 = heff_dup(heff_env(self)[2]);
  V v_x_2427 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2459 = heff_intLt(MK_INT(0LL), v_x_2458);
  switch (heff_tag_of(v_t_2459)) {
  case TAG_True: {
    heff_drop(v_x_2453);
    heff_drop(v_x_2427);
    heff_drop(v_t_2459);
    V v_t_2460 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2461 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_2462}));
    return heff_tail(heff_get(v_hd_240, LBL_bind), 2, (V[]){v_t_2463, v_k_241});
  }
  case TAG_False: {
    heff_drop(v_t_2459);
    V v_t_2464;
    switch (heff_tag_of(v_x_2453)) {
    case TAG_True: {
      heff_drop(v_x_2453);
      v_t_2464 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      heff_drop(v_x_2453);
      v_t_2464 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_2453);
    }
    switch (heff_tag_of(v_t_2464)) {
    case TAG_True: {
      heff_drop(v_x_2427);
      heff_drop(v_t_2464);
      return (g_heff_2ecommands_2egetFails_24s938_24s1045(((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str11), v_hd_240, v_k_241));
    }
    case TAG_False: {
      heff_drop(v_t_2464);
      return (g_heff_2ecommands_2eload_24s861_24s1007_24s1079(((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str12), heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam14, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2427})));
    }
    default: return heff_nomatch(v_t_2464);
    }
  }
  default: return heff_nomatch(v_t_2459);
  }
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam12(V self, V *args) {
  V v_x_2453 = args[0];
  V v_x_2427 = heff_dup(heff_env(self)[0]);
  V v_hd_240 = heff_dup(heff_env(self)[1]);
  V v_k_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2456;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_MkPair: {
    V v_y_2455 = heff_dup(heff_field(v_x_2427, 1));
    v_t_2456 = v_y_2455;
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V v_c_2457 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2eprintErrs_24s887_clo), 3, (V[]){((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str10), v_t_2456, MK_INT(0LL)}));
  return heff_tail(v_c_2457, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam13, 1, 4, (V[]){v_hd_240, v_k_241, v_x_2453, v_x_2427})});
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam8(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_x_2427 = heff_dup(heff_env(self)[1]);
  V v_k_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2433 = (g_prelude_2esortBy_24s736(heff_dup(v_x_2432)));
  V v_x2_2434 = (g_prelude_2emap_24s735(v_t_2433));
  V v_t_2437;
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_Nil: {
    heff_drop(v_x2_2434);
    v_t_2437 = ((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    V v_xs_2436 = heff_field(v_x2_2434, 1);
    heff_take(v_x2_2434, 3ULL);
    v_t_2437 = ({ V a_0 = v_x_2435; V a_1 = v_xs_2436; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2436); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2434);
  }
  V v_t_2438 = heff_strEq(v_t_2437, ((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str7));
  V v_c_2452;
  switch (heff_tag_of(v_t_2438)) {
  case TAG_True: {
    heff_drop(v_x_2432);
    heff_drop(v_t_2438);
    v_c_2452 = ((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam9_clo);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2438);
    V v_t_2441 = (g_prelude_2esortBy_24s736(v_x_2432));
    V v_x2_2442 = (g_prelude_2emap_24s735(v_t_2441));
    V v_str_2445;
    switch (heff_tag_of(v_x2_2442)) {
    case TAG_Nil: {
      heff_drop(v_x2_2442);
      v_str_2445 = ((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2443 = heff_field(v_x2_2442, 0);
      V v_xs_2444 = heff_field(v_x2_2442, 1);
      heff_take(v_x2_2442, 3ULL);
      v_str_2445 = ({ V a_0 = v_x_2443; V a_1 = v_xs_2444; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2444); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2442);
    }
    v_c_2452 = heff_clo(g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam10, 2, 1, (V[]){v_str_2445});
    break;
  }
  default: heff_nomatch(v_t_2438);
  }
  return heff_tail(v_c_2452, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam12, 1, 3, (V[]){v_x_2427, v_hd_240, v_k_241})});
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam7(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_244 = heff_dup(heff_env(self)[0]);
  V v_root_2414 = heff_dup(heff_env(self)[1]);
  V v_hd_240 = heff_dup(heff_env(self)[2]);
  V v_k_241 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2430;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_dup(heff_field(v_x_2427, 0));
    v_t_2430 = v_x_2428;
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V v_c_2431 = (g_heff_2ecommands_2esumsOf_24s942_24s1138(v_x_244, v_root_2414, v_t_2430));
  return heff_tail(v_c_2431, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam8, 1, 3, (V[]){v_hd_240, v_x_2427, v_k_241})});
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  V v_root_2414 = heff_dup(heff_env(self)[2]);
  V v_x_244 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_why_2417 = heff_field(v_x_2416, 0);
    heff_take(v_x_2416, 1ULL);
    heff_drop(v_root_2414);
    heff_drop(v_x_244);
    return (g_heff_2ecommands_2egetFails_24s938_24s1045(v_why_2417, v_hd_240, v_k_241));
  }
  case TAG_Right: {
    V v_sums_2418 = heff_field(v_x_2416, 0);
    heff_take(v_x_2416, 1ULL);
    V v_t_2419 = heff_strEq(heff_get(heff_dup(v_root_2414), LBL_module), ((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str4));
    V v_by_2420;
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      heff_drop(v_t_2419);
      v_by_2420 = ((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str5);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_2419);
      v_by_2420 = heff_get(heff_dup(v_root_2414), LBL_module);
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    V v_t_2422 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam5, 1, 1, (V[]){v_by_2420}), heff_get(heff_dup(v_root_2414), LBL_require)));
    V v_c_2426 = (g_heff_2eload_2eversionsGo_24s878(heff_clo(g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam6, 3, 3, (V[]){heff_dup(v_x_244), heff_dup(v_root_2414), v_sums_2418}), heff_get(heff_dup(v_root_2414), LBL_module), v_t_2422, NTAG(TAG_Nil), NTAG(TAG_Nil)));
    return heff_tail(v_c_2426, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam7, 1, 4, (V[]){v_x_244, v_root_2414, v_hd_240, v_k_241})});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  V v_x_244 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2411;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop(v_x_249);
    v_t_2411 = ((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2410 = heff_field(v_x_249, 0);
    heff_take(v_x_249, 1ULL);
    v_t_2411 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_t_2412 = (g_heff_2eproject_2ereadPackage(v_t_2411));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Left: {
    heff_take(v_t_2412, 0ULL);
    heff_drop(v_x_244);
    return (g_heff_2ecommands_2egetFails_24s938_24s1045(((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str3), v_hd_240, v_k_241));
  }
  case TAG_Right: {
    V v_root_2414 = heff_field(v_t_2412, 0);
    heff_take(v_t_2412, 1ULL);
    V v_c_2415 = (g_heff_2eload_2ereadSumAt_24s874_24s1088(heff_dup(v_x_244)));
    return heff_tail(v_c_2415, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam4, 1, 4, (V[]){v_hd_240, v_k_241, v_root_2414, v_x_244})});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str1), ((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam2_clo)})});
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_240), LBL_malg), 1, (V[]){v_t_247}));
  return heff_tail(heff_get(heff_dup(v_hd_240), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam3, 1, 3, (V[]){v_hd_240, v_k_241, v_x_244})});
}
V g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_dup(heff_env(self)[0]);
  V v_k_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_c_243 = (g_heff_2eload_2epathsFor_24s868_24s1082(v_x_242, ((V)&g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_str0)));
  return heff_tail(v_c_243, 2, (V[]){heff_dup(v_hd_240), heff_clo(g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str2 = {{0x80000000u, K_STR, 0}, 27, 27, {96, 32, 105, 115, 32, 114, 101, 113, 117, 105, 114, 101, 100, 32, 97, 108, 114, 101, 97, 100, 121, 58, 32, 97, 100, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str3 = {{0x80000000u, K_STR, 0}, 30, 30, {32, 116, 111, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 98, 121, 32, 97, 110, 111, 116, 104, 101, 114, 32, 110, 97, 109, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str4 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str6 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str7 = {{0x80000000u, K_STR, 0}, 30, 30, {104, 101, 102, 102, 32, 103, 101, 116, 58, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 114, 101, 113, 117, 105, 114, 101, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str10 = {{0x80000000u, K_STR, 0}, 23, 23, {99, 97, 110, 110, 111, 116, 32, 119, 114, 105, 116, 101, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam2(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam4(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam5(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam6(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam7(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam9(V self, V *args); static Clo g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam9, 1, 0};
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam8(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam11(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam12(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam10(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam3(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam1(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam0(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam14(V self, V *args);
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam13(V self, V *args);
Clo g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_entry, 5, 0};

V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139(V v_ps_240, V v_text_241, V v_pk_242, V v_path_243, V v_v_244) {
top: ;
  V v_t_245 = (g_heff_2eproject_2emajorMismatch(heff_dup(v_path_243), heff_dup(v_v_244)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_t_245);
    V v_c_246 = (g_heff_2ecommands_2efetched_24s941_24s1048_24s1137(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
    return heff_clo(g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam0, 2, 6, (V[]){v_c_246, v_ps_240, v_path_243, v_v_244, v_pk_242, v_text_241});
  }
  case TAG_Just: {
    V v_why_2454 = heff_field(v_t_245, 0);
    heff_take(v_t_245, 1ULL);
    heff_drop(v_ps_240);
    heff_drop(v_text_241);
    heff_drop(v_pk_242);
    heff_drop(v_v_244);
    return heff_clo(g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam13, 2, 2, (V[]){v_path_243, v_why_2454});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2411);
  return heff_tail(v_k_248, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_248 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2424);
  return heff_tail(v_k_248, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam5(V self, V *args) {
  V v_r_2426 = args[0];
  V v_path_243 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_r_2426, LBL_path), v_path_243);
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam6(V self, V *args) {
  V v_r_2428 = args[0];
  V v_name_2425 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(heff_get(v_r_2428, LBL_name), v_name_2425);
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam7(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_248 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2431);
  return heff_tail(v_k_248, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam9(V self, V *args) {
  V v_ok_2441 = args[0];
  heff_drop(self);
  return v_ok_2441;
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam8(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k2_2440 = args[1];
  V v_str_2438 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2442 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){((V)&g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str6), v_str_2438, ((V)&g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam9_clo)})});
  V v_t_2443 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2439), LBL_malg), 1, (V[]){v_t_2443}));
  return heff_tail(heff_get(v_hd_2439, LBL_bind), 2, (V[]){v_t_2444, v_k2_2440});
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam11(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_248 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2452);
  return heff_tail(v_k_248, 1, (V[]){NTAG(TAG_True)});
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam12(V self, V *args) {
  V v_x_2453 = args[0];
  V v_k_248 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2453);
  return heff_tail(v_k_248, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam10(V self, V *args) {
  V v_x_2446 = args[0];
  V v_path_243 = heff_dup(heff_env(self)[0]);
  V v_v_244 = heff_dup(heff_env(self)[1]);
  V v_hd_247 = heff_dup(heff_env(self)[2]);
  V v_k_248 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2446)) {
  case TAG_True: {
    heff_drop(v_x_2446);
    V v_t_2447 = heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str7), heff_strAppend(v_path_243, heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str8), v_v_244)));
    V v_t_2448 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_2447, ((V)&g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str9)), NTAG(TAG_MkUnit)});
    V v_t_2449 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2450}));
    return heff_tail(heff_get(v_hd_247, LBL_bind), 2, (V[]){v_t_2451, heff_clo(g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam11, 1, 1, (V[]){v_k_248})});
  }
  case TAG_False: {
    heff_drop(v_x_2446);
    heff_drop(v_path_243);
    heff_drop(v_v_244);
    return (g_heff_2ecommands_2egetFails_24s938_24s1045(((V)&g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str10), v_hd_247, heff_clo(g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam12, 1, 1, (V[]){v_k_248})));
  }
  default: return heff_nomatch(v_x_2446);
  }
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_247 = heff_dup(heff_env(self)[0]);
  V v_k_248 = heff_dup(heff_env(self)[1]);
  V v_path_243 = heff_dup(heff_env(self)[2]);
  V v_pk_242 = heff_dup(heff_env(self)[3]);
  V v_v_244 = heff_dup(heff_env(self)[4]);
  V v_text_241 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    V v_why_2423 = heff_field(v_x_2422, 0);
    heff_take(v_x_2422, 1ULL);
    heff_drop(v_path_243);
    heff_drop(v_pk_242);
    heff_drop(v_v_244);
    heff_drop(v_text_241);
    return (g_heff_2ecommands_2egetFails_24s938_24s1045(v_why_2423, v_hd_247, heff_clo(g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam4, 1, 1, (V[]){v_k_248})));
  }
  case TAG_Right: {
    V v_name_2425 = heff_field(v_x_2422, 0);
    heff_take(v_x_2422, 1ULL);
    V v_x1_2427 = ({ V a_0 = heff_clo(g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam5, 1, 1, (V[]){heff_dup(v_path_243)}); V b_1 = heff_get(heff_dup(v_pk_242), LBL_require); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2429;
    switch (heff_tag_of(v_x1_2427)) {
    case TAG_True: {
      heff_drop(v_x1_2427);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      heff_drop(v_x1_2427);
      v_t_2429 = ({ V a_0 = heff_clo(g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam6, 1, 1, (V[]){heff_dup(v_name_2425)}); V b_1 = heff_get(heff_dup(v_pk_242), LBL_require); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2427);
    }
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      heff_drop(v_pk_242);
      heff_drop(v_v_244);
      heff_drop(v_text_241);
      heff_drop(v_t_2429);
      V v_t_2430 = heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str1), heff_strAppend(v_name_2425, heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str2), heff_strAppend(v_path_243, ((V)&g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str3)))));
      return (g_heff_2ecommands_2egetFails_24s938_24s1045(v_t_2430, v_hd_247, heff_clo(g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam7, 1, 1, (V[]){v_k_248})));
    }
    case TAG_False: {
      heff_drop(v_t_2429);
      V v_t_2432 = (g_heff_2ecommands_2erequiring(v_pk_242, v_name_2425, heff_dup(v_path_243), heff_dup(v_v_244)));
      V v_text_2433 = (g_heff_2eproject_2ewithPackage(v_text_241, v_t_2432));
      V v_t_2434 = heff_strEq(heff_strSlice(((V)&g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str4), MK_INT(7LL), MK_INT(10LL)), ((V)&g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str5));
      V v_str_2438;
      switch (heff_tag_of(v_t_2434)) {
      case TAG_True: {
        heff_drop(v_t_2434);
        V v_t_2435 = (g_heff_2eformat_2eformat(heff_dup(v_text_2433)));
        switch (heff_tag_of(v_t_2435)) {
        case TAG_Left: {
          heff_take(v_t_2435, 0ULL);
          v_str_2438 = v_text_2433;
          break;
        }
        case TAG_Right: {
          V v_out_2437 = heff_field(v_t_2435, 0);
          heff_take(v_t_2435, 1ULL);
          heff_drop(v_text_2433);
          v_str_2438 = v_out_2437;
          break;
        }
        default: heff_nomatch(v_t_2435);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_t_2434);
        v_str_2438 = v_text_2433;
        break;
      }
      default: heff_nomatch(v_t_2434);
      }
      V v_c_2445 = heff_clo(g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam8, 2, 1, (V[]){v_str_2438});
      return heff_tail(v_c_2445, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam10, 1, 4, (V[]){v_path_243, v_v_244, v_hd_247, v_k_248})});
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_dup(heff_env(self)[0]);
  V v_k_248 = heff_dup(heff_env(self)[1]);
  V v_ps_240 = heff_dup(heff_env(self)[2]);
  V v_path_243 = heff_dup(heff_env(self)[3]);
  V v_v_244 = heff_dup(heff_env(self)[4]);
  V v_pk_242 = heff_dup(heff_env(self)[5]);
  V v_text_241 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    V v_why_2410 = heff_field(v_x_249, 0);
    heff_take(v_x_249, 1ULL);
    heff_drop(v_ps_240);
    heff_drop(v_path_243);
    heff_drop(v_v_244);
    heff_drop(v_pk_242);
    heff_drop(v_text_241);
    return (g_heff_2ecommands_2egetFails_24s938_24s1045(v_why_2410, v_hd_247, heff_clo(g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam2, 1, 1, (V[]){v_k_248})));
  }
  case TAG_Right: {
    heff_take(v_x_249, 0ULL);
    V v_st_2413 = heff_get(heff_dup(v_ps_240), LBL_style);
    V v_a_2414 = (g_heff_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
    V v_t_2415 = (g_std_2epath_2eparse(v_st_2413, v_a_2414));
    V v_t_2416 = (g_std_2epath_2eparse(v_st_2413, ((V)&g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str0)));
    V v_p_2417 = (g_std_2epath_2ejoin_2eonto_240(v_t_2415, v_t_2416));
    V v_t_2418 = ({ V a_0 = heff_get(heff_dup(v_p_2417), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2417), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2419 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2417), LBL_drive), heff_get(v_p_2417, LBL_absolute), v_t_2418});
    V v_t_2420 = ({ V a_0 = v_st_2413; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2413); r_; });
    V v_c_2421 = heff_tr(heff_apply(((V)&g_heff_2eload_2eownDir_24s881_24s1093_clo), 2, (V[]){v_ps_240, v_t_2420}));
    return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam3, 1, 6, (V[]){v_hd_247, v_k_248, v_path_243, v_pk_242, v_v_244, v_text_241})});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_dup(heff_env(self)[0]);
  V v_ps_240 = heff_dup(heff_env(self)[1]);
  V v_path_243 = heff_dup(heff_env(self)[2]);
  V v_v_244 = heff_dup(heff_env(self)[3]);
  V v_pk_242 = heff_dup(heff_env(self)[4]);
  V v_text_241 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam1, 1, 7, (V[]){v_hd_247, v_k_248, v_ps_240, v_path_243, v_v_244, v_pk_242, v_text_241})});
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam14(V self, V *args) {
  V v_x_2458 = args[0];
  V v_k_2456 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2458);
  return heff_tail(v_k_2456, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam13(V self, V *args) {
  V v_hd_2455 = args[0];
  V v_k_2456 = args[1];
  V v_path_243 = heff_dup(heff_env(self)[0]);
  V v_why_2454 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2457 = heff_strAppend(v_path_243, heff_strAppend(((V)&g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_str11), v_why_2454));
  return (g_heff_2ecommands_2egetFails_24s938_24s1045(v_t_2457, v_hd_2455, heff_clo(g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139_lam14, 1, 1, (V[]){v_k_2456})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str1 = {{0x80000000u, K_STR, 0}, 45, 45, {110, 111, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 104, 101, 114, 101, 58, 32, 103, 101, 116, 32, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str2 = {{0x80000000u, K_STR, 0}, 24, 24, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 114, 101, 97, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str3 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {64}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {64}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str7 = {{0x80000000u, K_STR, 0}, 22, 22, {96, 32, 105, 115, 32, 110, 111, 32, 118, 101, 114, 115, 105, 111, 110, 58, 32, 97, 46, 98, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {64}};
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam0(V self, V *args); static Clo g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam0, 1, 0};
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam4(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam6(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam5(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam3(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam2(V self, V *args);
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam1(V self, V *args);
Clo g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_entry, 3, 0};

V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134(V v_spec_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str0), ((V)&g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam0_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_spec_240})});
}
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam0(V self, V *args) {
  V v_t_243 = args[0];
  heff_drop(self);
  return v_t_243;
}
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam4(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_v_2438 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_2439);
  return heff_tail(v_k_2440, 1, (V[]){heff_tag(TAG_Right, 1, (V[]){v_v_2438})});
}
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam6(V self, V *args) {
  V v_x_2460 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2460)) {
  case TAG_True: {
    heff_drop(v_x_2460);
    return (g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135(v_hd_241, v_k_242));
  }
  case TAG_False: {
    heff_drop(v_x_2460);
    heff_drop(v_hd_241);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_x_2460);
  }
}
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam5(V self, V *args) {
  V v_x_2442 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  V v_s_2412 = heff_dup(heff_env(self)[2]);
  V v_x_2415 = heff_dup(heff_env(self)[3]);
  V v_t_248 = heff_dup(heff_env(self)[4]);
  V v_pk_2411 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Left: {
    V v_why_2443 = heff_field(v_x_2442, 0);
    heff_take(v_x_2442, 1ULL);
    heff_drop(v_s_2412);
    heff_drop(v_x_2415);
    heff_drop(v_t_248);
    heff_drop(v_pk_2411);
    return (g_heff_2ecommands_2egetFails_24s938_24s1045(v_why_2443, v_hd_241, v_k_242));
  }
  case TAG_Right: {
    V v_ver_2444 = heff_field(v_x_2442, 0);
    V v_ru_24x_2442_24Right = heff_take_reuse(v_x_2442, 1ULL);
    V v_t_2445 = (g_heff_2eproject_2eversion(heff_dup(v_ver_2444)));
    switch (heff_tag_of(v_t_2445)) {
    case TAG_Nothing: {
      heff_drop(v_s_2412);
      heff_drop(v_x_2415);
      heff_drop(v_t_248);
      heff_drop(v_pk_2411);
      heff_drop(v_ru_24x_2442_24Right);
      heff_drop(v_t_2445);
      V v_t_2446 = heff_strAppend(((V)&g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str6), heff_strAppend(v_ver_2444, ((V)&g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str7)));
      return (g_heff_2ecommands_2egetFails_24s938_24s1045(v_t_2446, v_hd_241, v_k_242));
    }
    case TAG_Just: {
      heff_take(v_t_2445, 0ULL);
      V v_it_2448 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str8), heff_dup(v_s_2412), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_x1_2455;
      switch (heff_tag_of(v_it_2448)) {
      case TAG_Nil: {
        heff_drop(v_ru_24x_2442_24Right);
        heff_drop(v_it_2448);
        v_x1_2455 = heff_tag(TAG_MkPair, 2, (V[]){v_s_2412, NTAG(TAG_Nothing)});
        break;
      }
      case TAG_Cons: {
        V v_path_2449 = heff_field(v_it_2448, 0);
        V v_it2_2450 = heff_field(v_it_2448, 1);
        V v_ru_24it_2448_24Cons = heff_take_reuse(v_it_2448, 3ULL);
        switch (heff_tag_of(v_it2_2450)) {
        case TAG_Nil: {
          heff_drop(v_ru_24x_2442_24Right);
          heff_drop(v_path_2449);
          heff_drop(v_it2_2450);
          v_x1_2455 = heff_tag_at(v_ru_24it_2448_24Cons, TAG_MkPair, 2, (V[]){v_s_2412, NTAG(TAG_Nothing)});
          break;
        }
        case TAG_Cons: {
          V v_v_2451 = heff_field(v_it2_2450, 0);
          V v_it22_2452 = heff_field(v_it2_2450, 1);
          heff_take(v_it2_2450, 3ULL);
          switch (heff_tag_of(v_it22_2452)) {
          case TAG_Nil: {
            heff_drop(v_s_2412);
            heff_drop(v_it22_2452);
            v_x1_2455 = heff_tag_at(v_ru_24it_2448_24Cons, TAG_MkPair, 2, (V[]){v_path_2449, heff_tag_at(v_ru_24x_2442_24Right, TAG_Just, 1, (V[]){v_v_2451})});
            break;
          }
          case TAG_Cons: {
            heff_take(v_it22_2452, 0ULL);
            heff_drop(v_ru_24x_2442_24Right);
            heff_drop(v_path_2449);
            heff_drop(v_v_2451);
            v_x1_2455 = heff_tag_at(v_ru_24it_2448_24Cons, TAG_MkPair, 2, (V[]){v_s_2412, NTAG(TAG_Nothing)});
            break;
          }
          default: heff_nomatch(v_it22_2452);
          }
          break;
        }
        default: heff_nomatch(v_it2_2450);
        }
        break;
      }
      default: heff_nomatch(v_it_2448);
      }
      V v_t_2458;
      switch (heff_tag_of(v_x1_2455)) {
      case TAG_MkPair: {
        V v_x_2456 = heff_field(v_x1_2455, 0);
        heff_take(v_x1_2455, 1ULL);
        v_t_2458 = v_x_2456;
        break;
      }
      default: heff_nomatch(v_x1_2455);
      }
      V v_c_2459 = (g_heff_2ecommands_2egetRequire_24s944_24s1050_24s1139(v_x_2415, v_t_248, v_pk_2411, v_t_2458, v_ver_2444));
      return heff_tail(v_c_2459, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam6, 1, 2, (V[]){v_hd_241, v_k_242})});
    }
    default: return heff_nomatch(v_t_2445);
    }
  }
  default: return heff_nomatch(v_x_2442);
  }
}
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_s_2412 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  V v_t_248 = heff_dup(heff_env(self)[3]);
  V v_pk_2411 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_it_2416 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str4), heff_dup(v_s_2412), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_x1_2423;
  switch (heff_tag_of(v_it_2416)) {
  case TAG_Nil: {
    heff_drop(v_it_2416);
    v_x1_2423 = heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_s_2412), NTAG(TAG_Nothing)});
    break;
  }
  case TAG_Cons: {
    V v_path_2417 = heff_field(v_it_2416, 0);
    V v_it2_2418 = heff_field(v_it_2416, 1);
    V v_ru_24it_2416_24Cons = heff_take_reuse(v_it_2416, 3ULL);
    switch (heff_tag_of(v_it2_2418)) {
    case TAG_Nil: {
      heff_drop(v_path_2417);
      heff_drop(v_it2_2418);
      v_x1_2423 = heff_tag_at(v_ru_24it_2416_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2412), NTAG(TAG_Nothing)});
      break;
    }
    case TAG_Cons: {
      V v_v_2419 = heff_field(v_it2_2418, 0);
      V v_it22_2420 = heff_field(v_it2_2418, 1);
      heff_take(v_it2_2418, 3ULL);
      switch (heff_tag_of(v_it22_2420)) {
      case TAG_Nil: {
        heff_drop(v_it22_2420);
        v_x1_2423 = heff_tag_at(v_ru_24it_2416_24Cons, TAG_MkPair, 2, (V[]){v_path_2417, heff_tag(TAG_Just, 1, (V[]){v_v_2419})});
        break;
      }
      case TAG_Cons: {
        heff_take(v_it22_2420, 0ULL);
        heff_drop(v_path_2417);
        heff_drop(v_v_2419);
        v_x1_2423 = heff_tag_at(v_ru_24it_2416_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2412), NTAG(TAG_Nothing)});
        break;
      }
      default: heff_nomatch(v_it22_2420);
      }
      break;
    }
    default: heff_nomatch(v_it2_2418);
    }
    break;
  }
  default: heff_nomatch(v_it_2416);
  }
  V v_t_2426;
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_MkPair: {
    V v_y_2425 = heff_field(v_x1_2423, 1);
    heff_take(v_x1_2423, 2ULL);
    v_t_2426 = v_y_2425;
    break;
  }
  default: heff_nomatch(v_x1_2423);
  }
  V v_c_2441;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Nothing: {
    heff_drop(v_t_2426);
    V v_it_2427 = (g_prelude_2esplitFrom(((V)&g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str5), heff_dup(v_s_2412), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x1_2434;
    switch (heff_tag_of(v_it_2427)) {
    case TAG_Nil: {
      heff_drop(v_it_2427);
      v_x1_2434 = heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_s_2412), NTAG(TAG_Nothing)});
      break;
    }
    case TAG_Cons: {
      V v_path_2428 = heff_field(v_it_2427, 0);
      V v_it2_2429 = heff_field(v_it_2427, 1);
      V v_ru_24it_2427_24Cons = heff_take_reuse(v_it_2427, 3ULL);
      switch (heff_tag_of(v_it2_2429)) {
      case TAG_Nil: {
        heff_drop(v_path_2428);
        heff_drop(v_it2_2429);
        v_x1_2434 = heff_tag_at(v_ru_24it_2427_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2412), NTAG(TAG_Nothing)});
        break;
      }
      case TAG_Cons: {
        V v_v_2430 = heff_field(v_it2_2429, 0);
        V v_it22_2431 = heff_field(v_it2_2429, 1);
        heff_take(v_it2_2429, 3ULL);
        switch (heff_tag_of(v_it22_2431)) {
        case TAG_Nil: {
          heff_drop(v_it22_2431);
          v_x1_2434 = heff_tag_at(v_ru_24it_2427_24Cons, TAG_MkPair, 2, (V[]){v_path_2428, heff_tag(TAG_Just, 1, (V[]){v_v_2430})});
          break;
        }
        case TAG_Cons: {
          heff_take(v_it22_2431, 0ULL);
          heff_drop(v_path_2428);
          heff_drop(v_v_2430);
          v_x1_2434 = heff_tag_at(v_ru_24it_2427_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2412), NTAG(TAG_Nothing)});
          break;
        }
        default: heff_nomatch(v_it22_2431);
        }
        break;
      }
      default: heff_nomatch(v_it2_2429);
      }
      break;
    }
    default: heff_nomatch(v_it_2427);
    }
    V v_t_2437;
    switch (heff_tag_of(v_x1_2434)) {
    case TAG_MkPair: {
      V v_x_2435 = heff_field(v_x1_2434, 0);
      heff_take(v_x1_2434, 1ULL);
      v_t_2437 = v_x_2435;
      break;
    }
    default: heff_nomatch(v_x1_2434);
    }
    v_c_2441 = (g_heff_2ecommands_2enewestTag_24s943_24s1049(v_t_2437));
    break;
  }
  case TAG_Just: {
    V v_v_2438 = heff_field(v_t_2426, 0);
    heff_take(v_t_2426, 1ULL);
    v_c_2441 = heff_clo(g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam4, 2, 1, (V[]){v_v_2438});
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  return heff_tail(v_c_2441, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam5, 1, 6, (V[]){v_hd_241, v_k_242, v_s_2412, v_x_2415, v_t_248, v_pk_2411})});
}
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_s_2412 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  V v_t_248 = heff_dup(heff_env(self)[3]);
  V v_pk_2411 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_c_2414 = (g_heff_2eload_2epathsFor_24s868_24s1082(v_x_2413, ((V)&g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str3)));
  return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam3, 1, 5, (V[]){v_s_2412, v_hd_241, v_k_242, v_t_248, v_pk_2411})});
}
V g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  V v_spec_240 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    heff_drop(v_x_247);
    heff_drop(v_spec_240);
    return (g_heff_2ecommands_2egetFails_24s938_24s1045(((V)&g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str1), v_hd_241, v_k_242));
  }
  case TAG_Just: {
    V v_t_248 = heff_field(v_x_247, 0);
    heff_take(v_x_247, 1ULL);
    V v_t_249 = (g_heff_2eproject_2ereadPackage(heff_dup(v_t_248)));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Left: {
      heff_take(v_t_249, 0ULL);
      heff_drop(v_spec_240);
      heff_drop(v_t_248);
      return (g_heff_2ecommands_2egetFails_24s938_24s1045(((V)&g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_str2), v_hd_241, v_k_242));
    }
    case TAG_Right: {
      V v_pk_2411 = heff_field(v_t_249, 0);
      heff_take(v_t_249, 1ULL);
      switch (heff_tag_of(v_spec_240)) {
      case TAG_Nothing: {
        heff_drop(v_spec_240);
        heff_drop(v_t_248);
        heff_drop(v_pk_2411);
        return (g_heff_2ecommands_2egetAll_24s939_24s1046_24s1135(v_hd_241, v_k_242));
      }
      case TAG_Just: {
        V v_s_2412 = heff_field(v_spec_240, 0);
        heff_take(v_spec_240, 1ULL);
        return (g_heff_2ecommands_2ehostNow_24s862_24s1008(heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2egetCmd_24s937_24s1044_24s1134_lam2, 1, 5, (V[]){v_hd_241, v_s_2412, v_k_242, v_t_248, v_pk_2411})));
      }
      default: return heff_nomatch(v_spec_240);
      }
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x_247);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2eprogramsIn_24s946_24s1141_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2eprogramsIn_24s946_24s1141_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {98, 117, 105, 108, 100, 46, 104, 102}};
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam0(V self, V *args); static Clo g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam0, 2, 0};
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam2(V self, V *args); static Clo g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam2, 1, 0};
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam1(V self, V *args);
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam5(V self, V *args);
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam4(V self, V *args);
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam3(V self, V *args);
Clo g_heff_2ecommands_2eprogramsIn_24s946_24s1141_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eprogramsIn_24s946_24s1141_entry, 2, 0};

V g_heff_2ecommands_2eprogramsIn_24s946_24s1141(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return ((V)&g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take(v_x2_241, 3ULL);
    V v_t_246 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2eprogramsIn_24s946_24s1141_str0)));
    V v_t_247 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_244)));
    V v_p_248 = (g_std_2epath_2ejoin_2eonto_240(v_t_246, v_t_247));
    V v_t_249 = ({ V a_0 = heff_get(heff_dup(v_p_248), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_248), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2410 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_248), LBL_drive), heff_get(v_p_248, LBL_absolute), v_t_249});
    V v_a_2411 = (g_std_2epath_2erender(v_st_240, v_t_2410));
    V v_t_2412 = (g_std_2epath_2eparse(v_st_240, v_a_2411));
    V v_t_2413 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2eprogramsIn_24s946_24s1141_str1)));
    V v_p_2414 = (g_std_2epath_2ejoin_2eonto_240(v_t_2412, v_t_2413));
    V v_t_2415 = ({ V a_0 = heff_get(heff_dup(v_p_2414), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2414), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2416 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2414), LBL_drive), heff_get(v_p_2414, LBL_absolute), v_t_2415});
    V v_path_2417 = (g_std_2epath_2erender(v_st_240, v_t_2416));
    V v_c_2424 = heff_clo(g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam1, 2, 1, (V[]){v_path_2417});
    return heff_clo(g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam3, 2, 4, (V[]){v_c_2424, heff_dup(v_st_240), v_rest_245, v_x_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2eprogramsIn_24s946_24s1141(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(self);
  heff_drop(v_hd_242);
  return heff_tail(v_k_243, 1, (V[]){NTAG(TAG_Nil)});
}
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam2(V self, V *args) {
  V v_t_2420 = args[0];
  heff_drop(self);
  return v_t_2420;
}
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k2_2419 = args[1];
  V v_path_2417 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2417, ((V)&g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam2_clo)})});
  V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2418), LBL_malg), 1, (V[]){v_t_2422}));
  return heff_tail(heff_get(v_hd_2418, LBL_bind), 2, (V[]){v_t_2423, v_k2_2419});
}
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2427 = heff_dup(heff_env(self)[0]);
  V v_x_244 = heff_dup(heff_env(self)[1]);
  V v_k_2426 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_x_2431;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Nothing: {
    heff_drop(v_x_2427);
    heff_drop(v_x_244);
    v_x_2431 = v_x_2429;
    break;
  }
  case TAG_Just: {
    heff_take(v_x_2427, 0ULL);
    v_x_2431 = heff_tag(TAG_Cons, 2, (V[]){v_x_244, v_x_2429});
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  return heff_tail(v_k_2426, 1, (V[]){v_x_2431});
}
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_rest_245 = heff_dup(heff_env(self)[1]);
  V v_hd_2425 = heff_dup(heff_env(self)[2]);
  V v_x_244 = heff_dup(heff_env(self)[3]);
  V v_k_2426 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_c_2428 = ({ V a_0 = v_st_240; V a_1 = v_rest_245; V r_ = (g_heff_2ecommands_2eprogramsIn_24s946_24s1141(a_0, a_1)); heff_drop(v_st_240); r_; });
  return heff_tail(v_c_2428, 2, (V[]){v_hd_2425, heff_clo(g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam5, 1, 3, (V[]){v_x_2427, v_x_244, v_k_2426})});
}
V g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_rest_245 = heff_dup(heff_env(self)[2]);
  V v_x_244 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_2424, 2, (V[]){heff_dup(v_hd_2425), heff_clo(g_heff_2ecommands_2eprogramsIn_24s946_24s1141_lam4, 1, 5, (V[]){v_st_240, v_rest_245, v_hd_2425, v_x_244, v_k_2426})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {99, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {45, 79, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {45, 108, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str10 = {{0x80000000u, K_STR, 0}, 3, 3, {122, 105, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str12 = {{0x80000000u, K_STR, 0}, 6, 6, {119, 114, 111, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str14 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[37]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str15 = {{0x80000000u, K_STR, 0}, 37, 37, {104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 58, 32, 96, 122, 105, 103, 32, 99, 99, 96, 32, 99, 111, 117, 108, 100, 32, 110, 111, 116, 32, 98, 117, 105, 108, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam1(V self, V *args); static Clo g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam1, 1, 0};
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam0(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam4(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam6(V self, V *args); static Clo g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam6, 1, 0};
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam5(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam8(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam9(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam11(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam12(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam10(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam7(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam3(V self, V *args);
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam2(V self, V *args);
Clo g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_entry, 3, 0};

V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144(V v_st_240, V v_x_241, V v_next_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str0)));
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str1)));
  V v_p_245 = (g_std_2epath_2ejoin_2eonto_240(v_t_243, v_t_244));
  V v_t_246 = ({ V a_0 = heff_get(heff_dup(v_p_245), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_245), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_245), LBL_drive), heff_get(v_p_245, LBL_absolute), v_t_246});
  V v_a_248 = (g_std_2epath_2erender(v_st_240, v_t_247));
  V v_t_249 = (g_std_2epath_2eparse(v_st_240, v_a_248));
  V v_t_2410 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_241)));
  V v_p_2411 = (g_std_2epath_2ejoin_2eonto_240(v_t_249, v_t_2410));
  V v_t_2412 = ({ V a_0 = heff_get(heff_dup(v_p_2411), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2411), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2413 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2411), LBL_drive), heff_get(v_p_2411, LBL_absolute), v_t_2412});
  V v_path_2414 = (g_std_2epath_2erender(v_st_240, v_t_2413));
  V v_c_2421 = heff_clo(g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam0, 2, 1, (V[]){v_path_2414});
  return heff_clo(g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam2, 2, 4, (V[]){v_c_2421, heff_dup(v_st_240), v_x_241, v_next_242});
}
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam1(V self, V *args) {
  V v_ns_2417 = args[0];
  heff_drop(self);
  return v_ns_2417;
}
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_path_2414 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2418 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){v_path_2414, ((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam1_clo)})});
  V v_t_2419 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2415), LBL_malg), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get(v_hd_2415, LBL_bind), 2, (V[]){v_t_2420, v_k2_2416});
}
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam4(V self, V *args) {
  V v_n_2430 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_x_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2431 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str5)));
  V v_t_2432 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str6)));
  V v_p_2433 = (g_std_2epath_2ejoin_2eonto_240(v_t_2431, v_t_2432));
  V v_t_2434 = ({ V a_0 = heff_get(heff_dup(v_p_2433), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2433), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2435 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2433), LBL_drive), heff_get(v_p_2433, LBL_absolute), v_t_2434});
  V v_a_2436 = (g_std_2epath_2erender(v_st_240, v_t_2435));
  V v_t_2437 = (g_std_2epath_2eparse(v_st_240, v_a_2436));
  V v_t_2438 = (g_std_2epath_2eparse(v_st_240, v_x_241));
  V v_p_2439 = (g_std_2epath_2ejoin_2eonto_240(v_t_2437, v_t_2438));
  V v_t_2440 = ({ V a_0 = heff_get(heff_dup(v_p_2439), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2439), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2441 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2439), LBL_drive), heff_get(v_p_2439, LBL_absolute), v_t_2440});
  V v_a_2442 = (g_std_2epath_2erender(v_st_240, v_t_2441));
  V v_t_2443 = (g_std_2epath_2eparse(v_st_240, v_a_2442));
  V v_t_2444 = (g_std_2epath_2eparse(v_st_240, v_n_2430));
  V v_p_2445 = (g_std_2epath_2ejoin_2eonto_240(v_t_2443, v_t_2444));
  V v_t_2446 = ({ V a_0 = heff_get(heff_dup(v_p_2445), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2445), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2447 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2445), LBL_drive), heff_get(v_p_2445, LBL_absolute), v_t_2446});
  return ({ V a_0 = v_st_240; V a_1 = v_t_2447; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
}
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam6(V self, V *args) {
  V v_r_2461 = args[0];
  heff_drop(self);
  return v_r_2461;
}
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam5(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k2_2460 = args[1];
  V v_as_2458 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2462 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str10), v_as_2458, ((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam6_clo)})});
  V v_t_2463 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2459), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2463})}));
  return heff_tail(heff_get(v_hd_2459, LBL_bind), 2, (V[]){v_t_2464, v_k2_2460});
}
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam8(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k2_2475 = args[1];
  V v_str_2473 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2476 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2473, ((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str13)), NTAG(TAG_MkUnit)});
  V v_t_2477 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2474), LBL_malg), 1, (V[]){v_t_2478}));
  return heff_tail(heff_get(v_hd_2474, LBL_bind), 2, (V[]){v_t_2479, v_k2_2475});
}
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam9(V self, V *args) {
  V v_x_2481 = args[0];
  V v_next_242 = heff_dup(heff_env(self)[0]);
  V v_hd_2422 = heff_dup(heff_env(self)[1]);
  V v_k_2423 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_x_2481);
  return heff_tail(v_next_242, 2, (V[]){v_hd_2422, v_k_2423});
}
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam11(V self, V *args) {
  V v_hd_2493 = args[0];
  V v_k2_2494 = args[1];
  V v_str_2492 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2495 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2492, ((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str16)), NTAG(TAG_MkUnit)});
  V v_t_2496 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2493), LBL_malg), 1, (V[]){v_t_2497}));
  return heff_tail(heff_get(v_hd_2493, LBL_bind), 2, (V[]){v_t_2498, v_k2_2494});
}
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam12(V self, V *args) {
  V v_x_24100 = args[0];
  V v_hd_2422 = heff_dup(heff_env(self)[0]);
  V v_k_2423 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_24100);
  V v_t_24101 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24102 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_24101})});
  V v_t_24103 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2422), LBL_malg), 1, (V[]){v_t_24103}));
  return heff_tail(heff_get(v_hd_2422, LBL_bind), 2, (V[]){v_t_24104, v_k_2423});
}
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam10(V self, V *args) {
  V v_x_2486 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_x_241 = heff_dup(heff_env(self)[1]);
  V v_hd_2422 = heff_dup(heff_env(self)[2]);
  V v_k_2423 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_x_2486);
  V v_t_2487 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str14)));
  V v_t_2488 = (g_std_2epath_2eparse(v_st_240, v_x_241));
  V v_p_2489 = (g_std_2epath_2ejoin_2eonto_240(v_t_2487, v_t_2488));
  V v_t_2490 = ({ V a_0 = heff_get(heff_dup(v_p_2489), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2489), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2491 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2489), LBL_drive), heff_get(v_p_2489, LBL_absolute), v_t_2490});
  V v_str_2492 = heff_strAppend(((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str15), ({ V a_0 = v_st_240; V a_1 = v_t_2491; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; }));
  V v_c_2499 = heff_clo(g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam11, 2, 1, (V[]){v_str_2492});
  return heff_tail(v_c_2499, 2, (V[]){heff_dup(v_hd_2422), heff_clo(g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam12, 1, 2, (V[]){v_hd_2422, v_k_2423})});
}
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam7(V self, V *args) {
  V v_x_2466 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_x_241 = heff_dup(heff_env(self)[1]);
  V v_hd_2422 = heff_dup(heff_env(self)[2]);
  V v_next_242 = heff_dup(heff_env(self)[3]);
  V v_k_2423 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2467 = heff_intEq(heff_get(heff_dup(v_x_2466), LBL_status), MK_INT(0LL));
  switch (heff_tag_of(v_t_2467)) {
  case TAG_True: {
    heff_drop(v_x_2466);
    heff_drop(v_t_2467);
    V v_t_2468 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str11)));
    V v_t_2469 = (g_std_2epath_2eparse(v_st_240, v_x_241));
    V v_p_2470 = (g_std_2epath_2ejoin_2eonto_240(v_t_2468, v_t_2469));
    V v_t_2471 = ({ V a_0 = heff_get(heff_dup(v_p_2470), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2470), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2472 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2470), LBL_drive), heff_get(v_p_2470, LBL_absolute), v_t_2471});
    V v_str_2473 = heff_strAppend(((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str12), ({ V a_0 = v_st_240; V a_1 = v_t_2472; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; }));
    V v_c_2480 = heff_clo(g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam8, 2, 1, (V[]){v_str_2473});
    return heff_tail(v_c_2480, 2, (V[]){heff_dup(v_hd_2422), heff_clo(g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam9, 1, 3, (V[]){v_next_242, v_hd_2422, v_k_2423})});
  }
  case TAG_False: {
    heff_drop(v_next_242);
    heff_drop(v_t_2467);
    V v_t_2482 = heff_tag(TAG_WriteErr, 2, (V[]){heff_get(v_x_2466, LBL_err), NTAG(TAG_MkUnit)});
    V v_t_2483 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2422), LBL_malg), 1, (V[]){v_t_2484}));
    return heff_tail(heff_get(heff_dup(v_hd_2422), LBL_bind), 2, (V[]){v_t_2485, heff_clo(g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam10, 1, 4, (V[]){v_st_240, v_x_241, v_hd_2422, v_k_2423})});
  }
  default: return heff_nomatch(v_t_2467);
  }
}
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_x_241 = heff_dup(heff_env(self)[1]);
  V v_hd_2422 = heff_dup(heff_env(self)[2]);
  V v_next_242 = heff_dup(heff_env(self)[3]);
  V v_k_2423 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2425 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str2), NTAG(TAG_Nil)});
  V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str4), v_t_2425})});
  V v_t_2428;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Nothing: {
    heff_drop(v_x_2424);
    v_t_2428 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2427 = heff_field(v_x_2424, 0);
    heff_take(v_x_2424, 1ULL);
    v_t_2428 = v_x_2427;
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  V v_t_2429 = (g_prelude_2efilter_24s823(v_t_2428));
  V v_t_2448 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam4, 1, 2, (V[]){heff_dup(v_st_240), heff_dup(v_x_241)}), v_t_2429));
  V v_t_2449 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str7)));
  V v_t_2450 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_241)));
  V v_p_2451 = (g_std_2epath_2ejoin_2eonto_240(v_t_2449, v_t_2450));
  V v_t_2452 = ({ V a_0 = heff_get(heff_dup(v_p_2451), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2451), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2453 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2451), LBL_drive), heff_get(v_p_2451, LBL_absolute), v_t_2452});
  V v_t_2454 = (g_std_2epath_2erender(v_st_240, v_t_2453));
  V v_t_2455 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str8), NTAG(TAG_Nil)});
  V v_t_2456 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_str9), heff_tag(TAG_Cons, 2, (V[]){v_t_2454, v_t_2455})});
  V v_t_2457 = (g_prelude_2econcatList(v_t_2448, v_t_2456));
  V v_as_2458 = (g_prelude_2econcatList(v_t_2426, v_t_2457));
  V v_c_2465 = heff_clo(g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam5, 2, 1, (V[]){v_as_2458});
  return heff_tail(v_c_2465, 2, (V[]){heff_dup(v_hd_2422), heff_clo(g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam7, 1, 5, (V[]){v_st_240, v_x_241, v_hd_2422, v_next_242, v_k_2423})});
}
V g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_x_241 = heff_dup(heff_env(self)[2]);
  V v_next_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_hd_2422), heff_clo(g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144_lam3, 1, 5, (V[]){v_st_240, v_x_241, v_hd_2422, v_next_242, v_k_2423})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str4 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 97, 105, 110, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str7 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str9 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 97, 105, 110, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str12 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 106, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str13 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str14 = {{0x80000000u, K_STR, 0}, 7, 7, {109, 97, 105, 110, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str15 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str16 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 106, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str17 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str18 = {{0x80000000u, K_STR, 0}, 6, 6, {119, 114, 111, 116, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_lam1(V self, V *args);
V g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_lam0(V self, V *args);
Clo g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_entry, 4, 0};

V g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143(V v_st_240, V v_x_241, V v_a_242, V v_next_243) {
top: ;
  V v_t_244 = heff_strEq(heff_get(heff_dup(v_a_242), LBL_backend), ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    V v_t_245 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_a_242, LBL_run)});
    V v_t_246 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str1)));
    V v_t_247 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str2)));
    V v_p_248 = (g_std_2epath_2ejoin_2eonto_240(v_t_246, v_t_247));
    V v_t_249 = ({ V a_0 = heff_get(heff_dup(v_p_248), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_248), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2410 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_248), LBL_drive), heff_get(v_p_248, LBL_absolute), v_t_249});
    V v_a_2411 = (g_std_2epath_2erender(v_st_240, v_t_2410));
    V v_t_2412 = (g_std_2epath_2eparse(v_st_240, v_a_2411));
    V v_t_2413 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_241)));
    V v_p_2414 = (g_std_2epath_2ejoin_2eonto_240(v_t_2412, v_t_2413));
    V v_t_2415 = ({ V a_0 = heff_get(heff_dup(v_p_2414), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2414), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2416 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2414), LBL_drive), heff_get(v_p_2414, LBL_absolute), v_t_2415});
    V v_t_2417 = (g_std_2epath_2erender(v_st_240, v_t_2416));
    V v_t_2418 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str3)));
    V v_t_2419 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_241)));
    V v_p_2420 = (g_std_2epath_2ejoin_2eonto_240(v_t_2418, v_t_2419));
    V v_t_2421 = ({ V a_0 = heff_get(heff_dup(v_p_2420), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2420), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2422 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2420), LBL_drive), heff_get(v_p_2420, LBL_absolute), v_t_2421});
    V v_a_2423 = (g_std_2epath_2erender(v_st_240, v_t_2422));
    V v_t_2424 = (g_std_2epath_2eparse(v_st_240, v_a_2423));
    V v_t_2425 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str4)));
    V v_p_2426 = (g_std_2epath_2ejoin_2eonto_240(v_t_2424, v_t_2425));
    V v_t_2427 = ({ V a_0 = heff_get(heff_dup(v_p_2426), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2426), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2428 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2426), LBL_drive), heff_get(v_p_2426, LBL_absolute), v_t_2427});
    V v_t_2429 = (g_std_2epath_2erender(v_st_240, v_t_2428));
    V v_t_2430 = (g_heff_2ecommands_2ezigCc_24s949_24s1054_24s1144(v_st_240, v_x_241, v_next_243));
    return heff_tail(((V)&g_heff_2ecommands_2ecThen_24s918_24s1030_24s1117_clo), 4, (V[]){v_t_245, heff_strAppend(v_t_2417, ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str5)), v_t_2429, v_t_2430});
  }
  case TAG_False: {
    heff_drop(v_t_244);
    V v_t_2431 = heff_strEq(heff_get(heff_dup(v_a_242), LBL_backend), ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str6));
    switch (heff_tag_of(v_t_2431)) {
    case TAG_True: {
      heff_drop(v_t_2431);
      V v_t_2432 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_a_242, LBL_run)});
      V v_t_2433 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str7)));
      V v_t_2434 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_241)));
      V v_p_2435 = (g_std_2epath_2ejoin_2eonto_240(v_t_2433, v_t_2434));
      V v_t_2436 = ({ V a_0 = heff_get(heff_dup(v_p_2435), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2435), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2437 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2435), LBL_drive), heff_get(v_p_2435, LBL_absolute), v_t_2436});
      V v_t_2438 = (g_std_2epath_2erender(v_st_240, v_t_2437));
      V v_t_2439 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str8)));
      V v_t_2440 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_241)));
      V v_p_2441 = (g_std_2epath_2ejoin_2eonto_240(v_t_2439, v_t_2440));
      V v_t_2442 = ({ V a_0 = heff_get(heff_dup(v_p_2441), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2441), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2443 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2441), LBL_drive), heff_get(v_p_2441, LBL_absolute), v_t_2442});
      V v_a_2444 = (g_std_2epath_2erender(v_st_240, v_t_2443));
      V v_t_2445 = (g_std_2epath_2eparse(v_st_240, v_a_2444));
      V v_t_2446 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str9)));
      V v_p_2447 = (g_std_2epath_2ejoin_2eonto_240(v_t_2445, v_t_2446));
      V v_t_2448 = ({ V a_0 = heff_get(heff_dup(v_p_2447), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2447), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2449 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2447), LBL_drive), heff_get(v_p_2447, LBL_absolute), v_t_2448});
      V v_t_2450 = (g_std_2epath_2erender(v_st_240, v_t_2449));
      V v_t_2451 = (g_heff_2ecommands_2enodeDone_24s950_24s1055(v_st_240, v_x_241, v_next_243));
      return heff_tail(((V)&g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_clo), 5, (V[]){((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str10), v_t_2432, v_t_2438, v_t_2450, v_t_2451});
    }
    case TAG_False: {
      heff_drop(v_t_2431);
      V v_t_2452 = heff_tag(TAG_Just, 1, (V[]){heff_get(v_a_242, LBL_run)});
      V v_t_2453 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str11)));
      V v_t_2454 = (g_std_2epath_2eparse(v_st_240, heff_strAppend(heff_dup(v_x_241), ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str12))));
      V v_p_2455 = (g_std_2epath_2ejoin_2eonto_240(v_t_2453, v_t_2454));
      V v_t_2456 = ({ V a_0 = heff_get(heff_dup(v_p_2455), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2455), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2457 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2455), LBL_drive), heff_get(v_p_2455, LBL_absolute), v_t_2456});
      V v_t_2458 = (g_std_2epath_2erender(v_st_240, v_t_2457));
      V v_t_2459 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str13)));
      V v_t_2460 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_241)));
      V v_p_2461 = (g_std_2epath_2ejoin_2eonto_240(v_t_2459, v_t_2460));
      V v_t_2462 = ({ V a_0 = heff_get(heff_dup(v_p_2461), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2461), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2463 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2461), LBL_drive), heff_get(v_p_2461, LBL_absolute), v_t_2462});
      V v_a_2464 = (g_std_2epath_2erender(v_st_240, v_t_2463));
      V v_t_2465 = (g_std_2epath_2eparse(v_st_240, v_a_2464));
      V v_t_2466 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str14)));
      V v_p_2467 = (g_std_2epath_2ejoin_2eonto_240(v_t_2465, v_t_2466));
      V v_t_2468 = ({ V a_0 = heff_get(heff_dup(v_p_2467), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2467), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2469 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2467), LBL_drive), heff_get(v_p_2467, LBL_absolute), v_t_2468});
      V v_t_2470 = (g_std_2epath_2erender(v_st_240, v_t_2469));
      V v_t_2471 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str15)));
      V v_t_2472 = (g_std_2epath_2eparse(v_st_240, heff_strAppend(v_x_241, ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str16))));
      V v_p_2473 = (g_std_2epath_2ejoin_2eonto_240(v_t_2471, v_t_2472));
      V v_t_2474 = ({ V a_0 = heff_get(heff_dup(v_p_2473), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2473), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2475 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2473), LBL_drive), heff_get(v_p_2473, LBL_absolute), v_t_2474});
      V v_path_2476 = (g_std_2epath_2erender(v_st_240, v_t_2475));
      return heff_tail(((V)&g_heff_2ecommands_2ecompileThen_24s926_24s1025_24s1112_clo), 5, (V[]){((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str17), v_t_2452, v_t_2458, v_t_2470, heff_clo(g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_lam0, 2, 2, (V[]){v_path_2476, v_next_243})});
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_lam1(V self, V *args) {
  V v_x_2484 = args[0];
  V v_next_243 = heff_dup(heff_env(self)[0]);
  V v_hd_2477 = heff_dup(heff_env(self)[1]);
  V v_k_2478 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_x_2484);
  return heff_tail(v_next_243, 2, (V[]){v_hd_2477, v_k_2478});
}
V g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_lam0(V self, V *args) {
  V v_hd_2477 = args[0];
  V v_k_2478 = args[1];
  V v_path_2476 = heff_dup(heff_env(self)[0]);
  V v_next_243 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2479 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str18), v_path_2476), ((V)&g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_str19));
  V v_t_2480 = heff_tag(TAG_Write, 2, (V[]){v_t_2479, NTAG(TAG_MkUnit)});
  V v_t_2481 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2477), LBL_malg), 1, (V[]){v_t_2482}));
  return heff_tail(heff_get(heff_dup(v_hd_2477), LBL_bind), 2, (V[]){v_t_2483, heff_clo(g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143_lam1, 1, 3, (V[]){v_next_243, v_hd_2477, v_k_2478})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {98, 117, 105, 108, 100, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_str4 = {{0x80000000u, K_STR, 0}, 8, 8, {98, 117, 105, 108, 100, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam0(V self, V *args); static Clo g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam0, 2, 0};
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam2(V self, V *args); static Clo g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam2, 1, 0};
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam1(V self, V *args);
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam5(V self, V *args);
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam6(V self, V *args);
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam4(V self, V *args);
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam3(V self, V *args);
Clo g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_entry, 2, 0};

V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return ((V)&g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take(v_x2_241, 3ULL);
    V v_t_246 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_str0)));
    V v_t_247 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_x_244)));
    V v_p_248 = (g_std_2epath_2ejoin_2eonto_240(v_t_246, v_t_247));
    V v_t_249 = ({ V a_0 = heff_get(heff_dup(v_p_248), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_248), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2410 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_248), LBL_drive), heff_get(v_p_248, LBL_absolute), v_t_249});
    V v_a_2411 = (g_std_2epath_2erender(v_st_240, v_t_2410));
    V v_t_2412 = (g_std_2epath_2eparse(v_st_240, v_a_2411));
    V v_t_2413 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_str1)));
    V v_p_2414 = (g_std_2epath_2ejoin_2eonto_240(v_t_2412, v_t_2413));
    V v_t_2415 = ({ V a_0 = heff_get(heff_dup(v_p_2414), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2414), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2416 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2414), LBL_drive), heff_get(v_p_2414, LBL_absolute), v_t_2415});
    V v_path_2417 = (g_std_2epath_2erender(v_st_240, v_t_2416));
    V v_c_2424 = heff_clo(g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam1, 2, 1, (V[]){v_path_2417});
    return heff_clo(g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam3, 2, 4, (V[]){v_c_2424, heff_dup(v_st_240), v_x_244, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(self);
  heff_drop(v_hd_242);
  return heff_tail(v_k_243, 1, (V[]){NTAG(TAG_MkUnit)});
}
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam2(V self, V *args) {
  V v_t_2420 = args[0];
  heff_drop(self);
  return v_t_2420;
}
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k2_2419 = args[1];
  V v_path_2417 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2421 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_2417, ((V)&g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam2_clo)})});
  V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2418), LBL_malg), 1, (V[]){v_t_2422}));
  return heff_tail(heff_get(v_hd_2418, LBL_bind), 2, (V[]){v_t_2423, v_k2_2419});
}
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam5(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k2_2448 = args[1];
  V v_str_2446 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2449 = heff_tag(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2446, ((V)&g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_str6)), NTAG(TAG_MkUnit)});
  V v_t_2450 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2447), LBL_malg), 1, (V[]){v_t_2451}));
  return heff_tail(heff_get(v_hd_2447, LBL_bind), 2, (V[]){v_t_2452, v_k2_2448});
}
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam6(V self, V *args) {
  V v_x_2454 = args[0];
  V v_hd_2425 = heff_dup(heff_env(self)[0]);
  V v_k_2426 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2454);
  V v_t_2455 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2425), LBL_malg), 1, (V[]){v_t_2457}));
  return heff_tail(heff_get(v_hd_2425, LBL_bind), 2, (V[]){v_t_2458, v_k_2426});
}
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_st_240 = heff_dup(heff_env(self)[0]);
  V v_x_244 = heff_dup(heff_env(self)[1]);
  V v_hd_2425 = heff_dup(heff_env(self)[2]);
  V v_k_2426 = heff_dup(heff_env(self)[3]);
  V v_rest_245 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2429;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Nothing: {
    v_t_2429 = ((V)&g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2428 = heff_dup(heff_field(v_x_2427, 0));
    v_t_2429 = v_x_2428;
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V v_t_2430 = (g_heff_2eproject_2ereadBuild(v_t_2429));
  switch (heff_tag_of(v_t_2430)) {
  case TAG_Left: {
    V v_p_2431 = heff_field(v_t_2430, 0);
    heff_take(v_t_2430, 1ULL);
    heff_drop(v_rest_245);
    V v_t_2432 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_str3)));
    V v_t_2433 = (g_std_2epath_2eparse(v_st_240, v_x_244));
    V v_p_2434 = (g_std_2epath_2ejoin_2eonto_240(v_t_2432, v_t_2433));
    V v_t_2435 = ({ V a_0 = heff_get(heff_dup(v_p_2434), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2434), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2436 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2434), LBL_drive), heff_get(v_p_2434, LBL_absolute), v_t_2435});
    V v_a_2437 = (g_std_2epath_2erender(v_st_240, v_t_2436));
    V v_t_2438 = (g_std_2epath_2eparse(v_st_240, v_a_2437));
    V v_t_2439 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_str4)));
    V v_p_2440 = (g_std_2epath_2ejoin_2eonto_240(v_t_2438, v_t_2439));
    V v_t_2441 = ({ V a_0 = heff_get(heff_dup(v_p_2440), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2440), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2442 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2440), LBL_drive), heff_get(v_p_2440, LBL_absolute), v_t_2441});
    V v_t_2443 = ({ V a_0 = v_st_240; V a_1 = v_t_2442; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
    V v_t_2445;
    switch (heff_tag_of(v_x_2427)) {
    case TAG_Nothing: {
      heff_drop(v_x_2427);
      v_t_2445 = ((V)&g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_str5);
      break;
    }
    case TAG_Just: {
      V v_x_2444 = heff_field(v_x_2427, 0);
      heff_take(v_x_2427, 1ULL);
      v_t_2445 = v_x_2444;
      break;
    }
    default: heff_nomatch(v_x_2427);
    }
    V v_str_2446 = (g_heff_2eload_2eproblemMsg(v_t_2443, v_t_2445, v_p_2431));
    V v_c_2453 = heff_clo(g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam5, 2, 1, (V[]){v_str_2446});
    return heff_tail(v_c_2453, 2, (V[]){heff_dup(v_hd_2425), heff_clo(g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam6, 1, 2, (V[]){v_hd_2425, v_k_2426})});
  }
  case TAG_Right: {
    V v_a_2459 = heff_field(v_t_2430, 0);
    heff_take(v_t_2430, 1ULL);
    heff_drop(v_x_2427);
    V v_t_2460 = (g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142(v_st_240, v_rest_245));
    V v_t_2461 = ({ V a_0 = v_st_240; V a_1 = v_x_244; V a_2 = v_a_2459; V a_3 = v_t_2460; V r_ = heff_tr(g_heff_2ecommands_2ebuildApp_24s948_24s1053_24s1143(a_0, a_1, a_2, a_3)); heff_drop(v_st_240); r_; });
    return heff_tail(v_t_2461, 2, (V[]){v_hd_2425, v_k_2426});
  }
  default: return heff_nomatch(v_t_2430);
  }
}
V g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_dup(heff_env(self)[0]);
  V v_st_240 = heff_dup(heff_env(self)[1]);
  V v_x_244 = heff_dup(heff_env(self)[2]);
  V v_rest_245 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_2424, 2, (V[]){heff_dup(v_hd_2425), heff_clo(g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142_lam4, 1, 5, (V[]){v_st_240, v_x_244, v_hd_2425, v_k_2426, v_rest_245})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str0 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[60]; } g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str1 = {{0x80000000u, K_STR, 0}, 60, 60, {104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 58, 32, 110, 111, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 104, 101, 114, 101, 58, 32, 98, 117, 105, 108, 100, 32, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 112, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[65]; } g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str3 = {{0x80000000u, K_STR, 0}, 65, 65, {104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 58, 32, 110, 111, 32, 112, 114, 111, 103, 114, 97, 109, 115, 58, 32, 97, 112, 112, 47, 88, 47, 32, 119, 105, 116, 104, 32, 97, 32, 98, 117, 105, 108, 100, 46, 104, 102, 32, 105, 115, 32, 116, 104, 101, 32, 112, 114, 111, 103, 114, 97, 109, 32, 88, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 117, 105, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str7 = {{0x80000000u, K_STR, 0}, 23, 23, {104, 101, 102, 102, 32, 98, 117, 105, 108, 100, 58, 32, 110, 111, 32, 112, 114, 111, 103, 114, 97, 109, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str8 = {{0x80000000u, K_STR, 0}, 9, 9, {58, 32, 110, 111, 32, 97, 112, 112, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str9 = {{0x80000000u, K_STR, 0}, 9, 9, {47, 98, 117, 105, 108, 100, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam0(V self, V *args); static Clo g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam0, 1, 0};
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam3(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam4(V self, V *args); static Clo g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam4, 1, 0};
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam8(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam7(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam9(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam10(V self, V *args); static Clo g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam10, 1, 0};
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam13(V self, V *args); static Clo g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam13, 1, 0};
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam12(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam14(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam11(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam15(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam6(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam5(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam2(V self, V *args);
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam1(V self, V *args);
Clo g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_entry, 3, 0};

V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140(V v_names_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str0), ((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam0_clo)})});
  V v_t_245 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_245}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_246, heff_clo(g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_names_240})});
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam0(V self, V *args) {
  V v_t_243 = args[0];
  heff_drop(self);
  return v_t_243;
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2413);
  V v_t_2414 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2417, v_k_242});
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam4(V self, V *args) {
  V v_ns_2419 = args[0];
  heff_drop(self);
  return v_ns_2419;
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam8(V self, V *args) {
  V v_p_2429 = args[0];
  V v_n_2428 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return heff_strEq(v_p_2429, v_n_2428);
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam7(V self, V *args) {
  V v_n_2428 = args[0];
  V v_x_2427 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_x1_2430 = ({ V a_0 = heff_clo(g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam8, 1, 1, (V[]){v_n_2428}); V a_1 = v_x_2427; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_x_2427); r_; });
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_True: {
    heff_drop(v_x1_2430);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_x1_2430);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2430);
  }
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam9(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2439);
  V v_t_2440 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2442}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2443, v_k_242});
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam10(V self, V *args) {
  V v_ok_2446 = args[0];
  heff_drop(self);
  return v_ok_2446;
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam13(V self, V *args) {
  V v_ok_2459 = args[0];
  heff_drop(self);
  return v_ok_2459;
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam12(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k2_2458 = args[1];
  V v_path_2456 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2460 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_2456, ((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam13_clo)})});
  V v_t_2461 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2457), LBL_malg), 1, (V[]){v_t_2461}));
  return heff_tail(heff_get(v_hd_2457, LBL_bind), 2, (V[]){v_t_2462, v_k2_2458});
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam14(V self, V *args) {
  V v_x_2464 = args[0];
  V v_names_240 = heff_dup(heff_env(self)[0]);
  V v_x_2427 = heff_dup(heff_env(self)[1]);
  V v_x_248 = heff_dup(heff_env(self)[2]);
  V v_hd_241 = heff_dup(heff_env(self)[3]);
  V v_k_242 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_2464);
  V v_t_2467;
  switch (heff_tag_of(v_names_240)) {
  case TAG_Nil: {
    heff_drop(v_names_240);
    v_t_2467 = v_x_2427;
    break;
  }
  case TAG_Cons: {
    heff_drop(v_x_2427);
    v_t_2467 = v_names_240;
    break;
  }
  default: heff_nomatch(v_names_240);
  }
  V v_t_2468 = ({ V a_0 = v_x_248; V a_1 = v_t_2467; V r_ = (g_heff_2ecommands_2ebuildEach_24s947_24s1052_24s1142(a_0, a_1)); heff_drop(v_x_248); r_; });
  return heff_tail(v_t_2468, 2, (V[]){v_hd_241, v_k_242});
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam11(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_248 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_names_240 = heff_dup(heff_env(self)[2]);
  V v_x_2427 = heff_dup(heff_env(self)[3]);
  V v_k_242 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  heff_drop(v_x_2450);
  V v_t_2451 = (g_std_2epath_2eparse(v_x_248, ((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str5)));
  V v_t_2452 = (g_std_2epath_2eparse(v_x_248, ((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str6)));
  V v_p_2453 = (g_std_2epath_2ejoin_2eonto_240(v_t_2451, v_t_2452));
  V v_t_2454 = ({ V a_0 = heff_get(heff_dup(v_p_2453), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2453), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2455 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2453), LBL_drive), heff_get(v_p_2453, LBL_absolute), v_t_2454});
  V v_path_2456 = (g_std_2epath_2erender(v_x_248, v_t_2455));
  V v_c_2463 = heff_clo(g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam12, 2, 1, (V[]){v_path_2456});
  return heff_tail(v_c_2463, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam14, 1, 5, (V[]){v_names_240, v_x_2427, v_x_248, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam15(V self, V *args) {
  V v_x_2476 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2476);
  V v_t_2477 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2478 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2479}));
  return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2480, v_k_242});
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_names_240 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  V v_x_248 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2431 = (g_prelude_2efilter(heff_clo(g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam7, 1, 1, (V[]){heff_dup(v_x_2427)}), heff_dup(v_names_240)));
  switch (heff_tag_of(v_t_2431)) {
  case TAG_Nil: {
    heff_drop(v_t_2431);
    V v_t_2434;
    switch (heff_tag_of(v_names_240)) {
    case TAG_Nil: {
      v_t_2434 = heff_dup(v_x_2427);
      break;
    }
    case TAG_Cons: {
      v_t_2434 = heff_dup(v_names_240);
      break;
    }
    default: heff_nomatch(v_names_240);
    }
    switch (heff_tag_of(v_t_2434)) {
    case TAG_Nil: {
      heff_drop(v_x_2427);
      heff_drop(v_names_240);
      heff_drop(v_x_248);
      heff_drop(v_t_2434);
      V v_t_2435 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str3), NTAG(TAG_MkUnit)});
      V v_t_2436 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2437}));
      return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2438, heff_clo(g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam9, 1, 2, (V[]){v_hd_241, v_k_242})});
    }
    case TAG_Cons: {
      V v_ru_24t_2434_24Cons = heff_take_reuse(v_t_2434, 0ULL);
      V v_t_2447 = heff_tag(TAG_InR, 1, (V[]){heff_tag_at(v_ru_24t_2434_24Cons, TAG_MkDir, 2, (V[]){((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str4), ((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam10_clo)})});
      V v_t_2448 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2447})});
      V v_t_2449 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2448}));
      return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2449, heff_clo(g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam11, 1, 5, (V[]){v_x_248, v_hd_241, v_names_240, v_x_2427, v_k_242})});
    }
    default: return heff_nomatch(v_t_2434);
    }
  }
  case TAG_Cons: {
    V v_n_2469 = heff_field(v_t_2431, 0);
    V v_ru_24t_2431_24Cons = heff_take_reuse(v_t_2431, 1ULL);
    heff_drop(v_x_2427);
    heff_drop(v_names_240);
    heff_drop(v_x_248);
    V v_t_2471 = heff_strAppend(((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str7), heff_strAppend(heff_dup(v_n_2469), heff_strAppend(((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str8), heff_strAppend(v_n_2469, ((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str9)))));
    V v_t_2472 = heff_tag_at(v_ru_24t_2431_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2471, ((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str10)), NTAG(TAG_MkUnit)});
    V v_t_2473 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2474}));
    return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2475, heff_clo(g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam15, 1, 2, (V[]){v_hd_241, v_k_242})});
  }
  default: return heff_nomatch(v_t_2431);
  }
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_248 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_names_240 = heff_dup(heff_env(self)[2]);
  V v_k_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2425;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Nothing: {
    heff_drop(v_x_2423);
    v_t_2425 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2424 = heff_field(v_x_2423, 0);
    heff_take(v_x_2423, 1ULL);
    v_t_2425 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V v_c_2426 = (g_heff_2ecommands_2eprogramsIn_24s946_24s1141(v_x_248, v_t_2425));
  return heff_tail(v_c_2426, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam6, 1, 4, (V[]){v_names_240, v_hd_241, v_k_242, v_x_248})});
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  V v_names_240 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    heff_drop(v_x_248);
    heff_drop(v_x_247);
    heff_drop(v_names_240);
    V v_t_249 = heff_tag(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str1), NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2411}));
    return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam3, 1, 2, (V[]){v_hd_241, v_k_242})});
  }
  case TAG_Just: {
    V v_ru_24x_247_24Just = heff_take_reuse(v_x_247, 0ULL);
    V v_t_2420 = heff_tag_at(v_ru_24x_247_24Just, TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_str2), ((V)&g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam4_clo)})});
    V v_t_2421 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2421}));
    return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_2422, heff_clo(g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam5, 1, 4, (V[]){v_x_248, v_hd_241, v_names_240, v_k_242})});
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  V v_names_240 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return (g_heff_2ecommands_2estyleNow_24s864_24s1010(heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2ebuildCmd_24s945_24s1051_24s1140_lam2, 1, 4, (V[]){v_x_247, v_hd_241, v_k_242, v_names_240})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 102}};
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam0(V self, V *args);
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam2(V self, V *args); static Clo g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam2, 1, 0};
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam5(V self, V *args);
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam4(V self, V *args);
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam3(V self, V *args);
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam1(V self, V *args);
Clo g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_entry, 2, 0};

V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    V v_x_242 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
    return heff_clo(g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take(v_x1_240, 3ULL);
    return heff_clo(g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam1, 2, 3, (V[]){v_p_245, v_rest_246, v_acc_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148(a[0], a[1]);
}
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_hd_243);
  return heff_tail(v_k_244, 1, (V[]){v_x_242});
}
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam2(V self, V *args) {
  V v_ns_249 = args[0];
  heff_drop(self);
  return v_ns_249;
}
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam5(V self, V *args) {
  V v_n_2422 = args[0];
  V v_x_2420 = heff_dup(heff_env(self)[0]);
  V v_p_245 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2423 = (g_std_2epath_2eparse(v_x_2420, v_p_245));
  V v_t_2424 = (g_std_2epath_2eparse(v_x_2420, v_n_2422));
  V v_p_2425 = (g_std_2epath_2ejoin_2eonto_240(v_t_2423, v_t_2424));
  V v_t_2426 = ({ V a_0 = heff_get(heff_dup(v_p_2425), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2425), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2427 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2425), LBL_drive), heff_get(v_p_2425, LBL_absolute), v_t_2426});
  return ({ V a_0 = v_x_2420; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2420); r_; });
}
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_ns_2419 = heff_dup(heff_env(self)[0]);
  V v_p_245 = heff_dup(heff_env(self)[1]);
  V v_rest_246 = heff_dup(heff_env(self)[2]);
  V v_acc_241 = heff_dup(heff_env(self)[3]);
  V v_hd_247 = heff_dup(heff_env(self)[4]);
  V v_k_248 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_t_2421 = (g_prelude_2efilter_24s827(v_ns_2419));
  V v_t_2428 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam5, 1, 2, (V[]){v_x_2420, v_p_245}), v_t_2421));
  V v_t_2429 = (g_prelude_2econcatList(v_t_2428, v_rest_246));
  V v_t_2430 = (g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148(v_t_2429, v_acc_241));
  return heff_tail(v_t_2430, 2, (V[]){v_hd_247, v_k_248});
}
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_p_245 = heff_dup(heff_env(self)[0]);
  V v_rest_246 = heff_dup(heff_env(self)[1]);
  V v_acc_241 = heff_dup(heff_env(self)[2]);
  V v_hd_247 = heff_dup(heff_env(self)[3]);
  V v_k_248 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    heff_drop(v_x_2413);
    V v_t_2414 = heff_intSub(heff_strLength(heff_dup(v_p_245)), MK_INT(3LL));
    V v_t_2415 = heff_strSlice(heff_dup(v_p_245), v_t_2414, heff_strLength(heff_dup(v_p_245)));
    V v_t_2416 = heff_strEq(v_t_2415, ((V)&g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_str0));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      heff_drop(v_t_2416);
      V v_t_2417 = (g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148(v_rest_246, heff_tag(TAG_Cons, 2, (V[]){v_p_245, v_acc_241})));
      return heff_tail(v_t_2417, 2, (V[]){v_hd_247, v_k_248});
    }
    case TAG_False: {
      heff_drop(v_p_245);
      heff_drop(v_t_2416);
      V v_t_2418 = (g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148(v_rest_246, v_acc_241));
      return heff_tail(v_t_2418, 2, (V[]){v_hd_247, v_k_248});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  case TAG_Just: {
    V v_ns_2419 = heff_field(v_x_2413, 0);
    heff_take(v_x_2413, 1ULL);
    return (g_heff_2ecommands_2estyleNow_24s864_24s1010(heff_dup(v_hd_247), heff_clo(g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam4, 1, 6, (V[]){v_ns_2419, v_p_245, v_rest_246, v_acc_241, v_hd_247, v_k_248})));
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_p_245 = heff_dup(heff_env(self)[0]);
  V v_rest_246 = heff_dup(heff_env(self)[1]);
  V v_acc_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadDir, 2, (V[]){heff_dup(v_p_245), ((V)&g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam2_clo)})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get(heff_dup(v_hd_247), LBL_bind), 2, (V[]){v_t_2412, heff_clo(g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148_lam3, 1, 5, (V[]){v_p_245, v_rest_246, v_acc_241, v_hd_247, v_k_248})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_str0 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 97, 110, 110, 111, 116, 32, 114, 101, 97, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 105, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam0(V self, V *args); static Clo g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam0, 1, 0};
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam3(V self, V *args);
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam2(V self, V *args);
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam5(V self, V *args);
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam4(V self, V *args);
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam1(V self, V *args);
Clo g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_entry, 3, 0};

V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x1_240);
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_path_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_246 = heff_tag(TAG_InR, 1, (V[]){heff_tag_at(v_ru_24x1_240_24Cons, TAG_ReadFile, 2, (V[]){heff_dup(v_path_243), ((V)&g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam0_clo)})});
    V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_247}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam1, 1, 4, (V[]){v_path_243, v_p_241, v_p_242, v_rest_244})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam0(V self, V *args) {
  V v_t_245 = args[0];
  heff_drop(self);
  return v_t_245;
}
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_p_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2420);
  return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nil)});
}
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_p_241 = heff_dup(heff_env(self)[0]);
  V v_p_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get(v_p_241, LBL_bind), 2, (V[]){v_t_2419, heff_clo(g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam3, 1, 1, (V[]){v_p_242})});
}
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2422 = heff_dup(heff_env(self)[0]);
  V v_path_243 = heff_dup(heff_env(self)[1]);
  V v_src_2421 = heff_dup(heff_env(self)[2]);
  V v_p_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2425 = (g_heff_2eload_2emoduleOf(heff_rec(5, shape_272_302_166_183_312, (V[]){((V)&g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_str2), ((V)&g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_str3), ((V)&g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_str4), ((V)&g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_str5), v_x_2422}), heff_dup(v_path_243)));
  V v_t_2426 = heff_rec(4, shape_184_228_296_261, (V[]){v_t_2425, v_path_243, v_src_2421, NTAG(TAG_Nil)});
  V v_x_2427 = heff_tag(TAG_Cons, 2, (V[]){v_t_2426, v_x_2424});
  return heff_tail(v_p_242, 1, (V[]){v_x_2427});
}
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_rest_244 = heff_dup(heff_env(self)[0]);
  V v_p_241 = heff_dup(heff_env(self)[1]);
  V v_path_243 = heff_dup(heff_env(self)[2]);
  V v_src_2421 = heff_dup(heff_env(self)[3]);
  V v_p_242 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_c_2423 = heff_tr(heff_apply(((V)&g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_clo), 1, (V[]){v_rest_244}));
  return heff_tail(v_c_2423, 2, (V[]){v_p_241, heff_clo(g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam5, 1, 4, (V[]){v_x_2422, v_path_243, v_src_2421, v_p_242})});
}
V g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_path_243 = heff_dup(heff_env(self)[0]);
  V v_p_241 = heff_dup(heff_env(self)[1]);
  V v_p_242 = heff_dup(heff_env(self)[2]);
  V v_rest_244 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop(v_x_249);
    heff_drop(v_rest_244);
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_str0), v_path_243), ((V)&g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_str1));
    V v_t_2411 = heff_tag(TAG_WriteErr, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_apply(heff_get(heff_dup(v_p_241), LBL_malg), 1, (V[]){v_t_2413}));
    return heff_tail(heff_get(heff_dup(v_p_241), LBL_bind), 2, (V[]){v_t_2414, heff_clo(g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam2, 1, 2, (V[]){v_p_241, v_p_242})});
  }
  case TAG_Just: {
    V v_src_2421 = heff_field(v_x_249, 0);
    heff_take(v_x_249, 1ULL);
    return (g_heff_2ecommands_2estyleNow_24s864_24s1010(heff_dup(v_p_241), heff_clo(g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176_lam4, 1, 5, (V[]){v_rest_244, v_p_241, v_path_243, v_src_2421, v_p_242})));
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175_lam1(V self, V *args);
V g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175_lam0(V self, V *args);
Clo g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175_entry, 3, 0};

V g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175(V v_paths_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecommands_2ereadAll_24s998_24s1068_24s1176(v_paths_240, heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175_lam0, 1, 2, (V[]){v_hd_241, v_k_242})));
}
V g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_242 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_247 = heff_intEq(v_x_246, MK_INT(0LL));
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_hd_241);
    heff_drop(v_t_247);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_False: {
    heff_drop(v_t_247);
    V v_t_248 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_2410}));
    return heff_tail(heff_get(v_hd_241, LBL_bind), 2, (V[]){v_t_2411, v_k_242});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_244 = (g_prelude_2efoldl_24s505(NTAG(TAG_Nil), v_x_243));
  V v_c_245 = ({ V a_0 = v_t_244; V a_1 = MK_INT(0LL); V r_ = (g_heff_2ecommands_2eprintAll_24s999(a_0, a_1)); heff_drop(v_t_244); r_; });
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eselfcheck_24s997_24s1067_24s1175_lam1, 1, 2, (V[]){v_k_242, v_hd_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_lam2(V self, V *args);
V g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_lam1(V self, V *args);
V g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_lam0(V self, V *args);
Clo g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_entry, 3, 0};

V g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177(V v_file_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ecommands_2eload_24s861_24s1007_24s1079(v_file_240, heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_lam0, 1, 2, (V[]){v_hd_241, v_k_242})));
}
V g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_244 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_247 = ({ V b_0 = heff_intLt(MK_INT(0LL), v_x_244); V a_1 = v_x_246; V r_ = (g_heff_2ecommands_2eevalDiags_24s1002_24s1070(b_0, a_1)); heff_drop(b_0); r_; });
  return heff_tail(v_t_247, 2, (V[]){v_hd_241, v_k_242});
}
V g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_x_243 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_c_245 = (g_heff_2esession_2ecachedProgram_24s888_24s1074(v_x_243));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_lam2, 1, 3, (V[]){v_x_244, v_hd_241, v_k_242})});
}
V g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_dup(heff_env(self)[0]);
  V v_k_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_str0), heff_get(heff_dup(v_x_243), LBL_errors), MK_INT(0LL), heff_dup(v_hd_241), heff_clo(g_heff_2ecommands_2eevalCmd_24s1001_24s1069_24s1177_lam1, 1, 3, (V[]){v_x_243, v_hd_241, v_k_242})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestReport_24s908_24s1183_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {111, 107, 32, 32, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestReport_24s908_24s1183_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestReport_24s908_24s1183_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestReport_24s908_24s1183_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestReport_24s908_24s1183_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2etestReport_24s908_24s1183_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {44, 32, 116, 101, 115, 116, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestReport_24s908_24s1183_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2etestReport_24s908_24s1183_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestReport_24s908_24s1183_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestReport_24s908_24s1183_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2etestReport_24s908_24s1183_lam0(V self, V *args); static Clo g_heff_2ecommands_2etestReport_24s908_24s1183_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestReport_24s908_24s1183_lam0, 1, 0};
V g_heff_2ecommands_2etestReport_24s908_24s1183_lam4(V self, V *args);
V g_heff_2ecommands_2etestReport_24s908_24s1183_lam5(V self, V *args);
V g_heff_2ecommands_2etestReport_24s908_24s1183_lam3(V self, V *args);
V g_heff_2ecommands_2etestReport_24s908_24s1183_lam2(V self, V *args);
V g_heff_2ecommands_2etestReport_24s908_24s1183_lam1(V self, V *args);
Clo g_heff_2ecommands_2etestReport_24s908_24s1183_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestReport_24s908_24s1183_entry, 6, 0};

V g_heff_2ecommands_2etestReport_24s908_24s1183(V v_f_240, V v_bad_241, V v_ts_242, V v_os_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_UseColor, 1, (V[]){((V)&g_heff_2ecommands_2etestReport_24s908_24s1183_lam0_clo)})});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_248, heff_clo(g_heff_2ecommands_2etestReport_24s908_24s1183_lam1, 1, 6, (V[]){v_ts_242, v_f_240, v_hd_244, v_os_243, v_bad_241, v_k_245})});
}
V g_heff_2ecommands_2etestReport_24s908_24s1183_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestReport_24s908_24s1183(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecommands_2etestReport_24s908_24s1183_lam0(V self, V *args) {
  V v_b_246 = args[0];
  heff_drop(self);
  return v_b_246;
}
V g_heff_2ecommands_2etestReport_24s908_24s1183_lam4(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k2_2438 = args[1];
  V v_str_2436 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2439 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_2436, ((V)&g_heff_2ecommands_2etestReport_24s908_24s1183_str9)), NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2437), LBL_malg), 1, (V[]){v_t_2441}));
  return heff_tail(heff_get(v_hd_2437, LBL_bind), 2, (V[]){v_t_2442, v_k2_2438});
}
V g_heff_2ecommands_2etestReport_24s908_24s1183_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_ts_242 = heff_dup(heff_env(self)[0]);
  V v_os_243 = heff_dup(heff_env(self)[1]);
  V v_bad_241 = heff_dup(heff_env(self)[2]);
  V v_k_245 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  heff_drop(v_x_2444);
  V v_t_2445 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_ts_242));
  V v_xs_2446 = (g_prelude_2efilter_24s824(v_ts_242));
  V v_t_2447 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2446; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2446); r_; });
  V v_t_2448 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_os_243));
  V v_xs_2449 = (g_prelude_2efilter_24s826(v_os_243));
  V v_t_2450 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2449; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2449); r_; });
  V v_x_2451 = heff_rec(5, shape_330_91_203_319_320, (V[]){v_t_2445, v_t_2447, heff_intEq(v_bad_241, MK_INT(0LL)), v_t_2448, v_t_2450});
  return heff_tail(v_k_245, 1, (V[]){v_x_2451});
}
V g_heff_2ecommands_2etestReport_24s908_24s1183_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ts_242 = heff_dup(heff_env(self)[0]);
  V v_os_243 = heff_dup(heff_env(self)[1]);
  V v_bad_241 = heff_dup(heff_env(self)[2]);
  V v_f_240 = heff_dup(heff_env(self)[3]);
  V v_hd_244 = heff_dup(heff_env(self)[4]);
  V v_k_245 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  heff_drop(v_x_2414);
  V v_x1_2415 = (g_prelude_2efilter_24s824(heff_dup(v_ts_242)));
  V v_t_2422;
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nil: {
    heff_drop(v_x1_2415);
    V v_x1_2416 = (g_prelude_2efilter_24s826(heff_dup(v_os_243)));
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_Nil: {
      heff_drop(v_x1_2416);
      V v_t_2417 = heff_intEq(heff_dup(v_bad_241), MK_INT(0LL));
      switch (heff_tag_of(v_t_2417)) {
      case TAG_True: {
        heff_drop(v_t_2417);
        v_t_2422 = ((V)&g_heff_2ecommands_2etestReport_24s908_24s1183_str0);
        break;
      }
      case TAG_False: {
        heff_drop(v_t_2417);
        v_t_2422 = ((V)&g_heff_2ecommands_2etestReport_24s908_24s1183_str1);
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      break;
    }
    case TAG_Cons: {
      heff_take(v_x1_2416, 0ULL);
      v_t_2422 = ((V)&g_heff_2ecommands_2etestReport_24s908_24s1183_str2);
      break;
    }
    default: heff_nomatch(v_x1_2416);
    }
    break;
  }
  case TAG_Cons: {
    heff_take(v_x1_2415, 0ULL);
    v_t_2422 = ((V)&g_heff_2ecommands_2etestReport_24s908_24s1183_str3);
    break;
  }
  default: heff_nomatch(v_x1_2415);
  }
  V v_t_2423 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_ts_242));
  V v_xs_2424 = (g_prelude_2efilter_24s824(heff_dup(v_ts_242)));
  V v_t_2425 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2424; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2424); r_; });
  V v_t_2426 = heff_intShow(heff_intSub(v_t_2423, v_t_2425));
  V v_t_2427 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_ts_242));
  V v_t_2435;
  switch (heff_tag_of(v_os_243)) {
  case TAG_Nil: {
    v_t_2435 = ((V)&g_heff_2ecommands_2etestReport_24s908_24s1183_str4);
    break;
  }
  case TAG_Cons: {
    V v_t_2430 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_os_243));
    V v_xs_2431 = (g_prelude_2efilter_24s826(heff_dup(v_os_243)));
    V v_t_2432 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2431; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2431); r_; });
    V v_t_2433 = heff_intShow(heff_intSub(v_t_2430, v_t_2432));
    V v_t_2434 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_os_243));
    v_t_2435 = heff_strAppend(((V)&g_heff_2ecommands_2etestReport_24s908_24s1183_str5), heff_strAppend(v_t_2433, heff_strAppend(((V)&g_heff_2ecommands_2etestReport_24s908_24s1183_str6), heff_intShow(v_t_2434))));
    break;
  }
  default: heff_nomatch(v_os_243);
  }
  V v_str_2436 = heff_strAppend(v_t_2422, heff_strAppend(v_f_240, heff_strAppend(((V)&g_heff_2ecommands_2etestReport_24s908_24s1183_str7), heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ecommands_2etestReport_24s908_24s1183_str8), heff_strAppend(heff_intShow(v_t_2427), v_t_2435))))));
  V v_c_2443 = heff_clo(g_heff_2ecommands_2etestReport_24s908_24s1183_lam4, 2, 1, (V[]){v_str_2436});
  return heff_tail(v_c_2443, 2, (V[]){v_hd_244, heff_clo(g_heff_2ecommands_2etestReport_24s908_24s1183_lam5, 1, 4, (V[]){v_ts_242, v_os_243, v_bad_241, v_k_245})});
}
V g_heff_2ecommands_2etestReport_24s908_24s1183_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_249 = heff_dup(heff_env(self)[0]);
  V v_os_243 = heff_dup(heff_env(self)[1]);
  V v_hd_244 = heff_dup(heff_env(self)[2]);
  V v_ts_242 = heff_dup(heff_env(self)[3]);
  V v_bad_241 = heff_dup(heff_env(self)[4]);
  V v_f_240 = heff_dup(heff_env(self)[5]);
  V v_k_245 = heff_dup(heff_env(self)[6]);
  heff_drop(self);
  heff_drop(v_x_2412);
  V v_c_2413 = ({ V a_0 = v_x_249; V a_1 = heff_dup(v_os_243); V r_ = (g_heff_2ecommands_2eprintOutcomes_24s910(a_0, a_1)); heff_drop(v_x_249); r_; });
  return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2etestReport_24s908_24s1183_lam3, 1, 6, (V[]){v_ts_242, v_os_243, v_bad_241, v_f_240, v_hd_244, v_k_245})});
}
V g_heff_2ecommands_2etestReport_24s908_24s1183_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_ts_242 = heff_dup(heff_env(self)[0]);
  V v_f_240 = heff_dup(heff_env(self)[1]);
  V v_hd_244 = heff_dup(heff_env(self)[2]);
  V v_os_243 = heff_dup(heff_env(self)[3]);
  V v_bad_241 = heff_dup(heff_env(self)[4]);
  V v_k_245 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_t_2410 = (g_prelude_2efilter_24s824(heff_dup(v_ts_242)));
  V v_c_2411 = (g_heff_2ecommands_2eprintFails_24s909(heff_dup(v_f_240), v_x_249, v_t_2410));
  return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2etestReport_24s908_24s1183_lam2, 1, 7, (V[]){v_x_249, v_os_243, v_hd_244, v_ts_242, v_bad_241, v_f_240, v_k_245})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2etestOneC_24s906_24s1182_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {70, 65, 73, 76, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ecommands_2etestOneC_24s906_24s1182_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 32, 48, 47, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestOneC_24s906_24s1182_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2etestOneC_24s906_24s1182_lam2(V self, V *args);
V g_heff_2ecommands_2etestOneC_24s906_24s1182_lam3(V self, V *args);
V g_heff_2ecommands_2etestOneC_24s906_24s1182_lam1(V self, V *args);
V g_heff_2ecommands_2etestOneC_24s906_24s1182_lam0(V self, V *args);
Clo g_heff_2ecommands_2etestOneC_24s906_24s1182_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestOneC_24s906_24s1182_entry, 4, 0};

V g_heff_2ecommands_2etestOneC_24s906_24s1182(V v_seed_240, V v_f_241, V v_bad0_242, V v_cs_243) {
top: ;
  V v_c_244 = (g_heff_2ecommands_2ediagCount_24s907(v_cs_243));
  return heff_clo(g_heff_2ecommands_2etestOneC_24s906_24s1182_lam0, 2, 5, (V[]){v_c_244, heff_dup(v_cs_243), v_f_241, v_bad0_242, v_seed_240});
}
V g_heff_2ecommands_2etestOneC_24s906_24s1182_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2etestOneC_24s906_24s1182(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2ecommands_2etestOneC_24s906_24s1182_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_246 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_rec(5, shape_330_91_203_319_320, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL)});
  return heff_tail(v_k_246, 1, (V[]){v_t_2415});
}
V g_heff_2ecommands_2etestOneC_24s906_24s1182_lam3(V self, V *args) {
  V v_w_2419 = args[0];
  V v_c_2416 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2420 = heff_get(heff_dup(v_w_2419), LBL_expected);
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Nothing: {
    heff_drop(v_w_2419);
    heff_drop(v_c_2416);
    heff_drop(v_t_2420);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_ru_24t_2420_24Just = heff_take_reuse(v_t_2420, 0ULL);
    V v_t_2422 = (g_heff_2edriver_2eownerOf(v_c_2416, heff_get(heff_dup(v_w_2419), LBL_from)));
    return heff_tag_at(v_ru_24t_2420_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_218_358, (V[]){v_t_2422, v_w_2419})});
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2ecommands_2etestOneC_24s906_24s1182_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_cs_243 = heff_dup(heff_env(self)[0]);
  V v_f_241 = heff_dup(heff_env(self)[1]);
  V v_hd_245 = heff_dup(heff_env(self)[2]);
  V v_k_246 = heff_dup(heff_env(self)[3]);
  V v_bad0_242 = heff_dup(heff_env(self)[4]);
  V v_seed_240 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_t_248 = ({ V a_0 = v_cs_243; V r_ = (g_heff_2edriver_2elastChecked(a_0)); heff_drop(v_cs_243); r_; });
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop(v_x_247);
    heff_drop(v_bad0_242);
    heff_drop(v_seed_240);
    heff_drop(v_t_248);
    V v_t_249 = heff_strAppend(((V)&g_heff_2ecommands_2etestOneC_24s906_24s1182_str0), heff_strAppend(v_f_241, ((V)&g_heff_2ecommands_2etestOneC_24s906_24s1182_str1)));
    V v_t_2410 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2ecommands_2etestOneC_24s906_24s1182_str2)), NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){v_t_2412}));
    return heff_tail(heff_get(v_hd_245, LBL_bind), 2, (V[]){v_t_2413, heff_clo(g_heff_2ecommands_2etestOneC_24s906_24s1182_lam2, 1, 1, (V[]){v_k_246})});
  }
  case TAG_Just: {
    V v_c_2416 = heff_field(v_t_248, 0);
    heff_take(v_t_248, 1ULL);
    V v_t_2417 = heff_get(heff_get(heff_dup(v_c_2416), LBL_top), LBL_watches);
    V v_t_2418 = (g_heff_2edriver_2ewatchesGo(heff_dup(v_c_2416), MK_INT(0LL), v_t_2417));
    V v_t_2423 = (g_prelude_2emap(heff_clo(g_heff_2ecommands_2etestOneC_24s906_24s1182_lam3, 1, 1, (V[]){heff_dup(v_c_2416)}), v_t_2418));
    V v_t_2424 = (g_heff_2edriver_2ecatMaybesD(v_t_2423));
    V v_t_2425 = heff_intLt(MK_INT(0LL), heff_intAdd(heff_dup(v_bad0_242), heff_dup(v_x_247)));
    V v_t_2426;
    switch (heff_tag_of(v_t_2425)) {
    case TAG_True: {
      heff_drop(v_seed_240);
      heff_drop(v_c_2416);
      heff_drop(v_t_2425);
      v_t_2426 = NTAG(TAG_Nil);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_2425);
      v_t_2426 = (g_heff_2edriver_2erunTests(v_seed_240, v_c_2416));
      break;
    }
    default: heff_nomatch(v_t_2425);
    }
    return (g_heff_2ecommands_2etestReport_24s908_24s1183(v_f_241, heff_intAdd(v_bad0_242, v_x_247), v_t_2424, v_t_2426, v_hd_245, v_k_246));
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ecommands_2etestOneC_24s906_24s1182_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_dup(heff_env(self)[0]);
  V v_cs_243 = heff_dup(heff_env(self)[1]);
  V v_f_241 = heff_dup(heff_env(self)[2]);
  V v_bad0_242 = heff_dup(heff_env(self)[3]);
  V v_seed_240 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  return heff_tail(v_c_244, 2, (V[]){heff_dup(v_hd_245), heff_clo(g_heff_2ecommands_2etestOneC_24s906_24s1182_lam1, 1, 6, (V[]){v_cs_243, v_f_241, v_hd_245, v_k_246, v_bad0_242, v_seed_240})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_lam2(V self, V *args);
V g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_lam1(V self, V *args);
V g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_lam0(V self, V *args);
Clo g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_entry, 4, 0};

V g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181(V v_seed_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ecommands_2eload_24s861_24s1007_24s1079(heff_dup(v_f_241), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_lam0, 1, 4, (V[]){v_hd_242, v_seed_240, v_f_241, v_k_243})));
}
V g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_seed_240 = heff_dup(heff_env(self)[0]);
  V v_f_241 = heff_dup(heff_env(self)[1]);
  V v_x_245 = heff_dup(heff_env(self)[2]);
  V v_hd_242 = heff_dup(heff_env(self)[3]);
  V v_k_243 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_248 = ({ V a_0 = v_seed_240; V a_1 = v_f_241; V a_2 = v_x_245; V a_3 = v_x_247; V r_ = (g_heff_2ecommands_2etestOneC_24s906_24s1182(a_0, a_1, a_2, a_3)); heff_drop(v_x_247); r_; });
  return heff_tail(v_t_248, 2, (V[]){v_hd_242, v_k_243});
}
V g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_dup(heff_env(self)[0]);
  V v_hd_242 = heff_dup(heff_env(self)[1]);
  V v_seed_240 = heff_dup(heff_env(self)[2]);
  V v_f_241 = heff_dup(heff_env(self)[3]);
  V v_k_243 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_c_246 = (g_heff_2esession_2ecachedProgram_24s888_24s1074(v_x_244));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_lam2, 1, 5, (V[]){v_seed_240, v_f_241, v_x_245, v_hd_242, v_k_243})});
}
V g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_dup(heff_env(self)[0]);
  V v_seed_240 = heff_dup(heff_env(self)[1]);
  V v_f_241 = heff_dup(heff_env(self)[2]);
  V v_k_243 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_str0), heff_get(heff_dup(v_x_244), LBL_errors), MK_INT(0LL), heff_dup(v_hd_242), heff_clo(g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181_lam1, 1, 5, (V[]){v_x_244, v_hd_242, v_seed_240, v_f_241, v_k_243})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {32, 116, 101, 115, 116, 115, 32, 104, 111, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_str5 = {{0x80000000u, K_STR, 0}, 18, 18, {32, 101, 120, 112, 101, 99, 116, 97, 116, 105, 111, 110, 115, 32, 104, 111, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam0(V self, V *args);
V g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam2(V self, V *args);
V g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam1(V self, V *args);
V g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam4(V self, V *args);
V g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam3(V self, V *args);
Clo g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_entry, 3, 0};

V g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180(V v_seed_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seed_240);
    V v_t_243 = heff_intSub(heff_get(heff_dup(v_acc_242), LBL_total), heff_get(heff_dup(v_acc_242), LBL_failed));
    V v_t_244 = heff_intShow(heff_get(heff_dup(v_acc_242), LBL_total));
    V v_tests_245 = heff_get(heff_dup(v_acc_242), LBL_tests);
    V v_t_246 = heff_intEq(heff_dup(v_tests_245), MK_INT(0LL));
    V v_t_248;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_tests_245);
      heff_drop(v_t_246);
      v_t_248 = ((V)&g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_str0);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_246);
      V v_t_247 = heff_intSub(heff_dup(v_tests_245), heff_get(heff_dup(v_acc_242), LBL_testsFailed));
      v_t_248 = heff_strAppend(((V)&g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_str1), heff_strAppend(heff_intShow(v_t_247), heff_strAppend(((V)&g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_str2), heff_strAppend(heff_intShow(v_tests_245), ((V)&g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_str3)))));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_str_249 = heff_strAppend(heff_intShow(v_t_243), heff_strAppend(((V)&g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_str4), heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_str5), v_t_248))));
    V v_c_2416 = heff_clo(g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam0, 2, 1, (V[]){v_str_249});
    return heff_clo(g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam1, 2, 2, (V[]){v_c_2416, v_acc_242});
  }
  case TAG_Cons: {
    V v_f_2435 = heff_field(v_x2_241, 0);
    V v_rest_2436 = heff_field(v_x2_241, 1);
    return heff_clo(g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam3, 2, 4, (V[]){v_seed_240, heff_dup(v_f_2435), v_acc_242, heff_dup(v_rest_2436)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k2_2411 = args[1];
  V v_str_249 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2412 = heff_tag(TAG_Write, 2, (V[]){heff_strAppend(v_str_249, ((V)&g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_str6)), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2410), LBL_malg), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get(v_hd_2410, LBL_bind), 2, (V[]){v_t_2415, v_k2_2411});
}
V g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_acc_242 = heff_dup(heff_env(self)[0]);
  V v_hd_2417 = heff_dup(heff_env(self)[1]);
  V v_k_2418 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  heff_drop(v_x_2419);
  V v_t_2420 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_acc_242), LBL_failed));
  switch (heff_tag_of(v_t_2420)) {
  case TAG_True: {
    heff_drop(v_acc_242);
    heff_drop(v_t_2420);
    V v_t_2421 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_2423}));
    return heff_tail(heff_get(v_hd_2417, LBL_bind), 2, (V[]){v_t_2424, v_k_2418});
  }
  case TAG_False: {
    heff_drop(v_t_2420);
    V v_t_2425 = heff_intLt(MK_INT(0LL), heff_get(heff_dup(v_acc_242), LBL_testsFailed));
    switch (heff_tag_of(v_t_2425)) {
    case TAG_True: {
      heff_drop(v_acc_242);
      heff_drop(v_t_2425);
      V v_t_2426 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2427 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_2428}));
      return heff_tail(heff_get(v_hd_2417, LBL_bind), 2, (V[]){v_t_2429, v_k_2418});
    }
    case TAG_False: {
      heff_drop(v_t_2425);
      V v_t_2430 = heff_get(v_acc_242, LBL_ok);
      switch (heff_tag_of(v_t_2430)) {
      case TAG_True: {
        heff_drop(v_hd_2417);
        heff_drop(v_t_2430);
        return heff_tail(v_k_2418, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_False: {
        heff_drop(v_t_2430);
        V v_t_2431 = heff_tag(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2432 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2431})});
        V v_t_2433 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2432})});
        V v_t_2434 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2417), LBL_malg), 1, (V[]){v_t_2433}));
        return heff_tail(heff_get(v_hd_2417, LBL_bind), 2, (V[]){v_t_2434, v_k_2418});
      }
      default: return heff_nomatch(v_t_2430);
      }
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_dup(heff_env(self)[0]);
  V v_acc_242 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_2417), heff_clo(g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam2, 1, 3, (V[]){v_acc_242, v_hd_2417, v_k_2418})});
}
V g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam4(V self, V *args) {
  V v_x_2439 = args[0];
  V v_acc_242 = heff_dup(heff_env(self)[0]);
  V v_seed_240 = heff_dup(heff_env(self)[1]);
  V v_rest_2436 = heff_dup(heff_env(self)[2]);
  V v_hd_2437 = heff_dup(heff_env(self)[3]);
  V v_k_2438 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2440 = heff_intAdd(heff_get(heff_dup(v_acc_242), LBL_total), heff_get(heff_dup(v_x_2439), LBL_total));
  V v_t_2441 = heff_intAdd(heff_get(heff_dup(v_acc_242), LBL_failed), heff_get(heff_dup(v_x_2439), LBL_failed));
  V v_t_2442 = heff_get(heff_dup(v_acc_242), LBL_ok);
  V v_t_2443;
  switch (heff_tag_of(v_t_2442)) {
  case TAG_True: {
    heff_drop(v_t_2442);
    v_t_2443 = heff_get(heff_dup(v_x_2439), LBL_ok);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2442);
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2442);
  }
  V v_t_2444 = heff_intAdd(heff_get(heff_dup(v_acc_242), LBL_tests), heff_get(heff_dup(v_x_2439), LBL_tests));
  V v_t_2445 = heff_intAdd(heff_get(v_acc_242, LBL_testsFailed), heff_get(v_x_2439, LBL_testsFailed));
  V v_t_2446 = ({ V a_0 = v_seed_240; V a_1 = v_rest_2436; V a_2 = heff_rec(5, shape_330_91_203_319_320, (V[]){v_t_2440, v_t_2441, v_t_2443, v_t_2444, v_t_2445}); V r_ = (g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180(a_0, a_1, a_2)); heff_drop(v_rest_2436); r_; });
  return heff_tail(v_t_2446, 2, (V[]){v_hd_2437, v_k_2438});
}
V g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam3(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_seed_240 = heff_dup(heff_env(self)[0]);
  V v_f_2435 = heff_dup(heff_env(self)[1]);
  V v_acc_242 = heff_dup(heff_env(self)[2]);
  V v_rest_2436 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return (g_heff_2ecommands_2etestOneF_24s905_24s1021_24s1108_24s1181(heff_dup(v_seed_240), v_f_2435, heff_dup(v_hd_2437), heff_clo(g_heff_2ecommands_2etestCmd_24s904_24s1020_24s1107_24s1180_lam4, 1, 5, (V[]){v_acc_242, v_seed_240, v_rest_2436, v_hd_2437, v_k_2438})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
V g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_lam3(V self, V *args);
V g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_lam2(V self, V *args);
V g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_lam1(V self, V *args);
V g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_lam0(V self, V *args);
Clo g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_entry, 4, 0};

V g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187(V v_x1_240, V v_acc_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    return (g_heff_2ecommands_2eload_24s861_24s1007_24s1079(heff_dup(v_f_244), heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_lam0, 1, 5, (V[]){v_p_242, heff_dup(v_f_244), v_acc_241, heff_dup(v_rest_245), v_p_243})));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_acc_241 = heff_dup(heff_env(self)[0]);
  V v_rest_245 = heff_dup(heff_env(self)[1]);
  V v_p_242 = heff_dup(heff_env(self)[2]);
  V v_p_243 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2412 = heff_intAdd(heff_get(heff_dup(v_acc_241), LBL_total), heff_get(heff_dup(v_x_2411), LBL_total));
  V v_t_2413 = heff_intAdd(heff_get(heff_dup(v_acc_241), LBL_failed), heff_get(heff_dup(v_x_2411), LBL_failed));
  V v_t_2414 = heff_get(heff_dup(v_acc_241), LBL_ok);
  V v_t_2415;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    heff_drop(v_t_2414);
    v_t_2415 = heff_get(heff_dup(v_x_2411), LBL_ok);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2414);
    v_t_2415 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_t_2416 = heff_intAdd(heff_get(heff_dup(v_acc_241), LBL_tests), heff_get(heff_dup(v_x_2411), LBL_tests));
  V v_t_2417 = heff_intAdd(heff_get(v_acc_241, LBL_testsFailed), heff_get(v_x_2411, LBL_testsFailed));
  return ({ V a_0 = v_rest_245; V a_1 = heff_rec(5, shape_330_91_203_319_320, (V[]){v_t_2412, v_t_2413, v_t_2415, v_t_2416, v_t_2417}); V a_2 = v_p_242; V a_3 = v_p_243; V r_ = (g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
}
V g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_244 = heff_dup(heff_env(self)[0]);
  V v_x_247 = heff_dup(heff_env(self)[1]);
  V v_p_242 = heff_dup(heff_env(self)[2]);
  V v_acc_241 = heff_dup(heff_env(self)[3]);
  V v_rest_245 = heff_dup(heff_env(self)[4]);
  V v_p_243 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_t_2410 = ({ V a_0 = heff_dup(g_heff_2ecommands_2edefaultSeed_get()); V a_1 = v_f_244; V a_2 = v_x_247; V a_3 = v_x_249; V r_ = (g_heff_2ecommands_2etestOneC_24s906_24s1182(a_0, a_1, a_2, a_3)); heff_drop(v_x_249); r_; });
  return heff_tail(v_t_2410, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_lam3, 1, 4, (V[]){v_acc_241, v_rest_245, v_p_242, v_p_243})});
}
V g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_dup(heff_env(self)[0]);
  V v_p_242 = heff_dup(heff_env(self)[1]);
  V v_f_244 = heff_dup(heff_env(self)[2]);
  V v_acc_241 = heff_dup(heff_env(self)[3]);
  V v_rest_245 = heff_dup(heff_env(self)[4]);
  V v_p_243 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_c_248 = (g_heff_2esession_2ecachedProgram_24s888_24s1074(v_x_246));
  return heff_tail(v_c_248, 2, (V[]){heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_lam2, 1, 6, (V[]){v_f_244, v_x_247, v_p_242, v_acc_241, v_rest_245, v_p_243})});
}
V g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_p_242 = heff_dup(heff_env(self)[0]);
  V v_f_244 = heff_dup(heff_env(self)[1]);
  V v_acc_241 = heff_dup(heff_env(self)[2]);
  V v_rest_245 = heff_dup(heff_env(self)[3]);
  V v_p_243 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_str0), heff_get(heff_dup(v_x_246), LBL_errors), MK_INT(0LL), heff_dup(v_p_242), heff_clo(g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187_lam1, 1, 6, (V[]){v_x_246, v_p_242, v_f_244, v_acc_241, v_rest_245, v_p_243})));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str0 = {{0x80000000u, K_STR, 0}, 11, 11, {45, 45, 112, 111, 114, 99, 101, 108, 97, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 116, 97, 116, 117, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {114, 101, 102, 115, 47, 116, 97, 103, 115, 47, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {45, 45, 118, 101, 114, 105, 102, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {103, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str7 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 101, 118, 45, 112, 97, 114, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str8 = {{0x80000000u, K_STR, 0}, 25, 25, {110, 111, 116, 32, 105, 110, 32, 97, 32, 103, 105, 116, 32, 114, 101, 112, 111, 115, 105, 116, 111, 114, 121, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[52]; } g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str10 = {{0x80000000u, K_STR, 0}, 52, 52, {119, 104, 97, 116, 32, 105, 115, 32, 112, 117, 98, 108, 105, 115, 104, 101, 100, 32, 105, 115, 32, 119, 104, 97, 116, 32, 105, 115, 32, 99, 111, 109, 109, 105, 116, 116, 101, 100, 58, 32, 99, 111, 109, 109, 105, 116, 32, 102, 105, 114, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str12 = {{0x80000000u, K_STR, 0}, 18, 18, {32, 105, 115, 32, 116, 97, 103, 103, 101, 100, 32, 97, 108, 114, 101, 97, 100, 121}};
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam0(V self, V *args); static Clo g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam0, 1, 0};
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam2(V self, V *args); static Clo g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam2, 1, 0};
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam5(V self, V *args);
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam4(V self, V *args);
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam3(V self, V *args);
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam1(V self, V *args);
Clo g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_entry, 5, 0};

V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186(V v_v_240, V v_pk_241, V v_src_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str0), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str2), v_t_245}), ((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam0_clo)});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_249}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2410, heff_clo(g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam1, 1, 5, (V[]){v_v_240, v_hd_243, v_k_244, v_src_242, v_pk_241})});
}
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam0(V self, V *args) {
  V v_r_246 = args[0];
  heff_drop(self);
  return v_r_246;
}
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam2(V self, V *args) {
  V v_r_2414 = args[0];
  heff_drop(self);
  return v_r_2414;
}
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam5(V self, V *args) {
  V v_x_2440 = args[0];
  V v_v_240 = heff_dup(heff_env(self)[0]);
  V v_pk_241 = heff_dup(heff_env(self)[1]);
  V v_hd_243 = heff_dup(heff_env(self)[2]);
  V v_k_244 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2441 = heff_tr(g_heff_2ecommands_2epublishTested_24s957_24s1063(v_v_240, v_pk_241, v_x_2440));
  return heff_tail(v_t_2441, 2, (V[]){v_hd_243, v_k_244});
}
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam4(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_243 = heff_dup(heff_env(self)[0]);
  V v_v_240 = heff_dup(heff_env(self)[1]);
  V v_pk_241 = heff_dup(heff_env(self)[2]);
  V v_k_244 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_t_2439 = heff_rec(5, shape_330_91_203_319_320, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(0LL), MK_INT(0LL)});
  return ({ V a_0 = v_x_2438; V a_1 = v_t_2439; V a_2 = heff_dup(v_hd_243); V a_3 = heff_clo(g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam5, 1, 4, (V[]){v_v_240, v_pk_241, v_hd_243, v_k_244}); V r_ = (g_heff_2ecommands_2etestAll_24s956_24s1062_24s1149_24s1187(a_0, a_1, a_2, a_3)); heff_drop(v_x_2438); r_; });
}
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2411 = heff_dup(heff_env(self)[0]);
  V v_hd_243 = heff_dup(heff_env(self)[1]);
  V v_k_244 = heff_dup(heff_env(self)[2]);
  V v_v_240 = heff_dup(heff_env(self)[3]);
  V v_src_242 = heff_dup(heff_env(self)[4]);
  V v_pk_241 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  V v_t_2420 = heff_intEq(heff_get(heff_dup(v_x_2411), LBL_status), MK_INT(0LL));
  V v_t_2421;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_True: {
    heff_drop(v_t_2420);
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    heff_drop(v_t_2420);
    v_t_2421 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  switch (heff_tag_of(v_t_2421)) {
  case TAG_True: {
    heff_drop(v_x_2419);
    heff_drop(v_v_240);
    heff_drop(v_src_242);
    heff_drop(v_pk_241);
    heff_drop(v_t_2421);
    V v_s_2422 = heff_get(v_x_2411, LBL_err);
    V v_t_2423 = (g_prelude_2eskipSpaces(heff_dup(v_s_2422), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2424 = heff_intSub(heff_strLength(heff_dup(v_s_2422)), MK_INT(1LL));
    V v_t_2425 = (g_prelude_2eskipSpaces(heff_dup(v_s_2422), v_t_2424, MK_INT(-1LL)));
    V v_t_2426 = heff_strSlice(v_s_2422, v_t_2423, heff_intAdd(v_t_2425, MK_INT(1LL)));
    return (g_heff_2ecommands_2epublishFails_24s952_24s1058(heff_strAppend(((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str8), v_t_2426), v_hd_243, v_k_244));
  }
  case TAG_False: {
    heff_drop(v_t_2421);
    V v_s_2427 = heff_get(v_x_2411, LBL_out);
    V v_t_2428 = (g_prelude_2eskipSpaces(heff_dup(v_s_2427), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2429 = heff_intSub(heff_strLength(heff_dup(v_s_2427)), MK_INT(1LL));
    V v_t_2430 = (g_prelude_2eskipSpaces(heff_dup(v_s_2427), v_t_2429, MK_INT(-1LL)));
    V v_t_2431 = heff_strSlice(v_s_2427, v_t_2428, heff_intAdd(v_t_2430, MK_INT(1LL)));
    V v_x1_2432 = heff_strEq(v_t_2431, ((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str9));
    V v_t_2433;
    switch (heff_tag_of(v_x1_2432)) {
    case TAG_True: {
      heff_drop(v_x1_2432);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      heff_drop(v_x1_2432);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_2432);
    }
    switch (heff_tag_of(v_t_2433)) {
    case TAG_True: {
      heff_drop(v_x_2419);
      heff_drop(v_v_240);
      heff_drop(v_src_242);
      heff_drop(v_pk_241);
      heff_drop(v_t_2433);
      return (g_heff_2ecommands_2epublishFails_24s952_24s1058(((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str10), v_hd_243, v_k_244));
    }
    case TAG_False: {
      heff_drop(v_t_2433);
      V v_t_2434 = heff_intEq(heff_get(v_x_2419, LBL_status), MK_INT(0LL));
      switch (heff_tag_of(v_t_2434)) {
      case TAG_True: {
        heff_drop(v_src_242);
        heff_drop(v_pk_241);
        heff_drop(v_t_2434);
        V v_t_2435 = heff_strAppend(((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str11), heff_strAppend(v_v_240, ((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str12)));
        return (g_heff_2ecommands_2epublishFails_24s952_24s1058(v_t_2435, v_hd_243, v_k_244));
      }
      case TAG_False: {
        heff_drop(v_t_2434);
        V v_t_2436 = heff_tag(TAG_Cons, 2, (V[]){v_src_242, NTAG(TAG_Nil)});
        V v_c_2437 = (g_heff_2ecommands_2ehfFilesGo_24s955_24s1061_24s1148(v_t_2436, NTAG(TAG_Nil)));
        return heff_tail(v_c_2437, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam4, 1, 4, (V[]){v_hd_243, v_v_240, v_pk_241, v_k_244})});
      }
      default: return heff_nomatch(v_t_2434);
      }
    }
    default: return heff_nomatch(v_t_2433);
    }
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_v_240 = heff_dup(heff_env(self)[0]);
  V v_hd_243 = heff_dup(heff_env(self)[1]);
  V v_k_244 = heff_dup(heff_env(self)[2]);
  V v_src_242 = heff_dup(heff_env(self)[3]);
  V v_pk_241 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str3), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str4), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str5), v_t_2412})});
  V v_t_2415 = heff_tag(TAG_Run, 3, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str6), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_str7), v_t_2413}), ((V)&g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam2_clo)});
  V v_t_2416 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get(heff_dup(v_hd_243), LBL_bind), 2, (V[]){v_t_2418, heff_clo(g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186_lam3, 1, 6, (V[]){v_x_2411, v_hd_243, v_k_244, v_v_240, v_src_242, v_pk_241})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {115, 114, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
V g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_lam1(V self, V *args);
V g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_lam0(V self, V *args);
Clo g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_entry, 3, 0};

V g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185(V v_v_240, V v_l_241, V v_pk_242) {
top: ;
  V v_t_243 = (g_heff_2eproject_2emajorMismatch(heff_get(heff_dup(v_pk_242), LBL_module), heff_dup(v_v_240)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop(v_t_243);
    V v_st_244 = heff_get(heff_get(heff_dup(v_l_241), LBL_paths), LBL_style);
    V v_t_245 = heff_get(heff_get(heff_dup(v_l_241), LBL_paths), LBL_root);
    V v_t_246 = (g_std_2epath_2eparse(v_st_244, v_t_245));
    V v_t_247 = (g_std_2epath_2eparse(v_st_244, ((V)&g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_str0)));
    V v_p_248 = (g_std_2epath_2ejoin_2eonto_240(v_t_246, v_t_247));
    V v_t_249 = ({ V a_0 = heff_get(heff_dup(v_p_248), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_248), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2410 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_248), LBL_drive), heff_get(v_p_248, LBL_absolute), v_t_249});
    V v_t_2411 = ({ V a_0 = v_st_244; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); r_; });
    V v_c_2412 = heff_tr(heff_apply(((V)&g_heff_2eload_2eownDir_24s881_24s1093_clo), 2, (V[]){heff_get(heff_dup(v_l_241), LBL_paths), v_t_2411}));
    return heff_clo(g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_lam0, 2, 4, (V[]){v_c_2412, v_l_241, v_v_240, v_pk_242});
  }
  case TAG_Just: {
    V v_why_2426 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    heff_drop(v_v_240);
    heff_drop(v_l_241);
    V v_t_2427 = heff_strAppend(heff_get(v_pk_242, LBL_module), heff_strAppend(((V)&g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_str2), v_why_2426));
    return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s952_24s1057_clo), 1, (V[]){v_t_2427});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185(a[0], a[1], a[2]);
}
V g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_2413 = heff_dup(heff_env(self)[0]);
  V v_k_2414 = heff_dup(heff_env(self)[1]);
  V v_l_241 = heff_dup(heff_env(self)[2]);
  V v_v_240 = heff_dup(heff_env(self)[3]);
  V v_pk_242 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_why_2416 = heff_field(v_x_2415, 0);
    heff_take(v_x_2415, 1ULL);
    heff_drop(v_l_241);
    heff_drop(v_v_240);
    heff_drop(v_pk_242);
    return (g_heff_2ecommands_2epublishFails_24s952_24s1058(v_why_2416, v_hd_2413, v_k_2414));
  }
  case TAG_Right: {
    heff_take(v_x_2415, 0ULL);
    V v_st_2418 = heff_get(heff_get(heff_dup(v_l_241), LBL_paths), LBL_style);
    V v_t_2419 = heff_get(heff_get(v_l_241, LBL_paths), LBL_root);
    V v_t_2420 = (g_std_2epath_2eparse(v_st_2418, v_t_2419));
    V v_t_2421 = (g_std_2epath_2eparse(v_st_2418, ((V)&g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_str1)));
    V v_p_2422 = (g_std_2epath_2ejoin_2eonto_240(v_t_2420, v_t_2421));
    V v_t_2423 = ({ V a_0 = heff_get(heff_dup(v_p_2422), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_2422), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2424 = heff_rec(3, shape_68_1_280, (V[]){heff_get(heff_dup(v_p_2422), LBL_drive), heff_get(v_p_2422, LBL_absolute), v_t_2423});
    V v_t_2425 = ({ V a_0 = v_st_2418; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); r_; });
    return (g_heff_2ecommands_2epublishGit_24s954_24s1060_24s1147_24s1186(v_v_240, v_pk_242, v_t_2425, v_hd_2413, v_k_2414));
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_dup(heff_env(self)[0]);
  V v_l_241 = heff_dup(heff_env(self)[1]);
  V v_v_240 = heff_dup(heff_env(self)[2]);
  V v_pk_242 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_2413), heff_clo(g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185_lam1, 1, 5, (V[]){v_hd_2413, v_k_2414, v_l_241, v_v_240, v_pk_242})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str1 = {{0x80000000u, K_STR, 0}, 22, 22, {96, 32, 105, 115, 32, 110, 111, 32, 118, 101, 114, 115, 105, 111, 110, 58, 32, 97, 46, 98, 46, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str2 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[49]; } g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str3 = {{0x80000000u, K_STR, 0}, 49, 49, {110, 111, 32, 112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 104, 101, 114, 101, 58, 32, 112, 117, 98, 108, 105, 115, 104, 32, 97, 116, 32, 116, 104, 101, 32, 112, 114, 111, 106, 101, 99, 116, 39, 115, 32, 114, 111, 111, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str4 = {{0x80000000u, K_STR, 0}, 10, 10, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 102, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str6 = {{0x80000000u, K_STR, 0}, 24, 24, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 114, 101, 97, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str7 = {{0x80000000u, K_STR, 0}, 42, 42, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 105, 115, 32, 110, 111, 32, 80, 97, 99, 107, 97, 103, 101, 32, 40, 108, 105, 98, 47, 109, 97, 110, 105, 102, 101, 115, 116, 46, 104, 102, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str8 = {{0x80000000u, K_STR, 0}, 42, 42, {112, 97, 99, 107, 97, 103, 101, 46, 104, 102, 32, 105, 115, 32, 110, 111, 32, 80, 97, 99, 107, 97, 103, 101, 32, 40, 108, 105, 98, 47, 109, 97, 110, 105, 102, 101, 115, 116, 46, 104, 102, 41}};
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam1(V self, V *args); static Clo g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam1, 1, 0};
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam6(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam5(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam4(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam3(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam2(V self, V *args);
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam0(V self, V *args);
Clo g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_entry, 1, 0};

V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184(V v_v_240) {
top: ;
  V v_t_241 = (g_heff_2eproject_2eversion(heff_dup(v_v_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    V v_t_242 = heff_strAppend(((V)&g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str0), heff_strAppend(v_v_240, ((V)&g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str1)));
    return heff_tail(((V)&g_heff_2ecommands_2epublishFails_24s952_24s1057_clo), 1, (V[]){v_t_242});
  }
  case TAG_Just: {
    heff_take(v_t_241, 0ULL);
    return heff_clo(g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam0, 2, 1, (V[]){v_v_240});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184(a[0]);
}
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam1(V self, V *args) {
  V v_t_246 = args[0];
  heff_drop(self);
  return v_t_246;
}
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2412 = heff_dup(heff_env(self)[0]);
  V v_hd_244 = heff_dup(heff_env(self)[1]);
  V v_k_245 = heff_dup(heff_env(self)[2]);
  V v_x_2413 = heff_dup(heff_env(self)[3]);
  V v_x_2415 = heff_dup(heff_env(self)[4]);
  V v_v_240 = heff_dup(heff_env(self)[5]);
  heff_drop(self);
  heff_drop(v_x_2417);
  V v_t_2418 = heff_get(heff_dup(v_x_2412), LBL_package);
  switch (heff_tag_of(v_t_2418)) {
  case TAG_Nothing: {
    heff_drop(v_x_2412);
    heff_drop(v_x_2413);
    heff_drop(v_x_2415);
    heff_drop(v_v_240);
    heff_drop(v_t_2418);
    return (g_heff_2ecommands_2epublishFails_24s952_24s1058(((V)&g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str6), v_hd_244, v_k_245));
  }
  case TAG_Just: {
    V v_pk_2419 = heff_field(v_t_2418, 0);
    heff_take(v_t_2418, 1ULL);
    V v_t_2420 = heff_intLt(MK_INT(0LL), v_x_2413);
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      heff_drop(v_x_2412);
      heff_drop(v_x_2415);
      heff_drop(v_v_240);
      heff_drop(v_pk_2419);
      heff_drop(v_t_2420);
      return (g_heff_2ecommands_2epublishFails_24s952_24s1058(((V)&g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str7), v_hd_244, v_k_245));
    }
    case TAG_False: {
      heff_drop(v_t_2420);
      V v_t_2421 = ({ V a_0 = v_x_2415; V r_ = (g_prelude_2eany_24s820(a_0)); heff_drop(v_x_2415); r_; });
      switch (heff_tag_of(v_t_2421)) {
      case TAG_True: {
        heff_drop(v_x_2412);
        heff_drop(v_v_240);
        heff_drop(v_pk_2419);
        heff_drop(v_t_2421);
        return (g_heff_2ecommands_2epublishFails_24s952_24s1058(((V)&g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str8), v_hd_244, v_k_245));
      }
      case TAG_False: {
        heff_drop(v_t_2421);
        V v_t_2422 = heff_tr(g_heff_2ecommands_2epublishChecked_24s953_24s1059_24s1146_24s1185(v_v_240, v_x_2412, v_pk_2419));
        return heff_tail(v_t_2422, 2, (V[]){v_hd_244, v_k_245});
      }
      default: return heff_nomatch(v_t_2421);
      }
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_244 = heff_dup(heff_env(self)[0]);
  V v_x_2412 = heff_dup(heff_env(self)[1]);
  V v_k_245 = heff_dup(heff_env(self)[2]);
  V v_x_2413 = heff_dup(heff_env(self)[3]);
  V v_v_240 = heff_dup(heff_env(self)[4]);
  heff_drop(self);
  V v_c_2416 = (g_heff_2ecommands_2eputFileDiags_24s894(heff_dup(v_x_2415)));
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam6, 1, 6, (V[]){v_x_2412, v_hd_244, v_k_245, v_x_2413, v_x_2415, v_v_240})});
}
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2412 = heff_dup(heff_env(self)[0]);
  V v_hd_244 = heff_dup(heff_env(self)[1]);
  V v_k_245 = heff_dup(heff_env(self)[2]);
  V v_v_240 = heff_dup(heff_env(self)[3]);
  heff_drop(self);
  V v_c_2414 = (g_heff_2esession_2ecachedProgram_24s888_24s1074(heff_dup(v_x_2412)));
  return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam5, 1, 5, (V[]){v_hd_244, v_x_2412, v_k_245, v_x_2413, v_v_240})});
}
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_244 = heff_dup(heff_env(self)[0]);
  V v_k_245 = heff_dup(heff_env(self)[1]);
  V v_v_240 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return (g_heff_2ecommands_2eprintErrs_24s887(((V)&g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str5), heff_get(heff_dup(v_x_2412), LBL_errors), MK_INT(0LL), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam4, 1, 4, (V[]){v_x_2412, v_hd_244, v_k_245, v_v_240})));
}
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_244 = heff_dup(heff_env(self)[0]);
  V v_k_245 = heff_dup(heff_env(self)[1]);
  V v_v_240 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_drop(v_x_2410);
    heff_drop(v_v_240);
    return (g_heff_2ecommands_2epublishFails_24s952_24s1058(((V)&g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str3), v_hd_244, v_k_245));
  }
  case TAG_Just: {
    heff_take(v_x_2410, 0ULL);
    return (g_heff_2ecommands_2eload_24s861_24s1007_24s1079(((V)&g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str4), heff_dup(v_hd_244), heff_clo(g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam3, 1, 3, (V[]){v_hd_244, v_k_245, v_v_240})));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_v_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_247 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_str2), ((V)&g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam1_clo)})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_244), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_244), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_heff_2ecommands_2epublishCmd_24s951_24s1056_24s1145_24s1184_lam2, 1, 3, (V[]){v_hd_244, v_k_245, v_v_240})});
}