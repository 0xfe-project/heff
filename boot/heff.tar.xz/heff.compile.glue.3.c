// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CBool 61457
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_DoneOrErrno 39355
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_Left 13886
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_args 9498020
#define LBL_byName 571997869
#define LBL_fun 311289
#define LBL_result 1012715336
#define LBL_tag 324116
#define LBL_values 1123329101
static uint32_t shape_tag__fun__args__result[] = {LBL_tag, LBL_fun, LBL_args, LBL_result};
V g_heff_2ecompile_2eglue_2eappendF(V, V);
V g_heff_2ecompile_2eglue_2eappendF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eappendF_clo;
V g_heff_2ecompile_2eglue_2ebindingOf(V, V);
V g_heff_2ecompile_2eglue_2ebindingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ebindingOf_clo;
HeffT2 g_heff_2ecompile_2eglue_2ebindingsOf_24cpr(V, V, V);
V g_heff_2ecompile_2eglue_2ecResultOf(V);
V g_heff_2ecompile_2eglue_2ecResultOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ecResultOf_clo;
HeffT2 g_heff_2ecompile_2eglue_2ecTypeOf_24cpr(V);
V g_heff_2ecompile_2eglue_2edescribedIn(V, V);
V g_heff_2ecompile_2eglue_2edescribedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2edescribedIn_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeachOf_24s1262413731x290637868_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2efieldOf_24cpr(V, V);
V g_heff_2ecompile_2eglue_2efits(V, V);
V g_heff_2ecompile_2eglue_2efits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2efits_clo;
HeffT2 g_heff_2ecompile_2eglue_2elistOf_24cpr(V);
V g_heff_2ecompile_2eglue_2eofType(V, V, V);
V g_heff_2ecompile_2eglue_2eofType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eofType_clo;
HeffT2 g_heff_2ecompile_2eglue_2eoperationsOf_24cpr(V, V);
HeffT2 g_heff_2ecompile_2eglue_2ereadDescribed_24cpr(V);
V g_heff_2ecompile_2eglue_2ereadOp(V);
V g_heff_2ecompile_2eglue_2ereadOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ereadOp_clo;
V g_heff_2ecompile_2eglue_2eresultBad(V, V, V);
V g_heff_2ecompile_2eglue_2eresultBad_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eresultBad_clo;
HeffT2 g_heff_2ecompile_2eglue_2erightOf_24cpr(V);
V g_heff_2ecompile_2eglue_2etyOf(V);
V g_heff_2ecompile_2eglue_2etyOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2etyOf_clo;
V g_heff_2ecompile_2einterp_2eevalReachedIn(V, V, V);
V g_heff_2ecompile_2einterp_2eevalReachedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalReachedIn_clo;
V g_heff_2ecompile_2einterp_2ereachGlobals(V, V, V);
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str0, 8, "CInteger");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str1, 7, "CDouble");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str2, 5, "CBool");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str3, 7, "CString");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str4, 5, "CText");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str5, 12, "COwnedString");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str6, 8, "CPointer");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str7, 5, "CVoid");

HeffT2 g_heff_2ecompile_2eglue_2ecTypeOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VTag: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_x12_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24VTag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str0), 2)) {
      heff_drop(v_x11_243);
      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nil: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_x121_246 = heff_field(v_x12_244, 0);
        V v_x122_247 = heff_field(v_x12_244, 1);
        heff_take_n(v_x12_244, 3ULL, 2);
        switch (heff_tag_of(v_x121_246)) {
        case TAG_VFun: {
          heff_take_n(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VCons: {
          heff_take_n(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VTag: {
          heff_take_n(v_x121_246, 0ULL, 2);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VInt: {
          heff_take_n(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VFloat: {
          heff_take_na(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VFloat32: {
          heff_take_n(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VStr: {
          V v_t_2415 = heff_field(v_x121_246, 0);
          V v_ru_24x121_246_24VStr = heff_take_reuse_n(v_x121_246, 1ULL, 1);
          switch (heff_tag_of(v_x122_247)) {
          case TAG_Nil: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x121_246_24VStr, TAG_CInteger, 1, (V[]){v_t_2415})}});
          }
          case TAG_Cons: {
            heff_take_n(v_x122_247, 0ULL, 2);
            heff_drop(v_t_2415);
            heff_drop_cell(v_ru_24x121_246_24VStr, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x122_247)}});
          }
        }
        case TAG_VRune: {
          heff_take_n(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VArr: {
          heff_take_n(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VBytes: {
          heff_take_n(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VBits: {
          heff_take_n(v_x121_246, 0ULL, 2);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VErased: {
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x121_246)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
      }
    } else {
      if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str1), 2)) {
        heff_drop(v_x11_243);
        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
        switch (heff_tag_of(v_x12_244)) {
        case TAG_Nil: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CDouble)}});
        }
        case TAG_Cons: {
          heff_take_n(v_x12_244, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
        }
      } else {
        if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str2), 2)) {
          heff_drop(v_x11_243);
          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
          switch (heff_tag_of(v_x12_244)) {
          case TAG_Nil: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CBool)}});
          }
          case TAG_Cons: {
            heff_take_n(v_x12_244, 0ULL, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
          }
        } else {
          if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str3), 2)) {
            heff_drop(v_x11_243);
            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
            switch (heff_tag_of(v_x12_244)) {
            case TAG_Nil: {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CString)}});
            }
            case TAG_Cons: {
              heff_take_n(v_x12_244, 0ULL, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
            }
          } else {
            if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str4), 2)) {
              heff_drop(v_x11_243);
              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
              switch (heff_tag_of(v_x12_244)) {
              case TAG_Nil: {
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CText)}});
              }
              case TAG_Cons: {
                heff_take_n(v_x12_244, 0ULL, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
              }
            } else {
              if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str5), 2)) {
                heff_drop(v_x11_243);
                heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                switch (heff_tag_of(v_x12_244)) {
                case TAG_Nil: {
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_COwnedString)}});
                }
                case TAG_Cons: {
                  heff_take_n(v_x12_244, 0ULL, 2);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
                }
              } else {
                if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str6), 2)) {
                  heff_drop(v_x11_243);
                  switch (heff_tag_of(v_x12_244)) {
                  case TAG_Nil: {
                    heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Cons: {
                    V v_x121_2439 = heff_field(v_x12_244, 0);
                    V v_x122_2440 = heff_field(v_x12_244, 1);
                    heff_take_n(v_x12_244, 3ULL, 2);
                    switch (heff_tag_of(v_x121_2439)) {
                    case TAG_VFun: {
                      heff_take_n(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VCons: {
                      heff_take_n(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VTag: {
                      heff_take_n(v_x121_2439, 0ULL, 2);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VInt: {
                      heff_take_n(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VFloat: {
                      heff_take_na(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VFloat32: {
                      heff_take_n(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VStr: {
                      V v_t_2448 = heff_field(v_x121_2439, 0);
                      heff_take_n(v_x121_2439, 1ULL, 1);
                      switch (heff_tag_of(v_x122_2440)) {
                      case TAG_Nil: {
                        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                        heff_drop(v_t_2448);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Cons: {
                        V v_x1221_2449 = heff_field(v_x122_2440, 0);
                        V v_x1222_2450 = heff_field(v_x122_2440, 1);
                        heff_take_n(v_x122_2440, 3ULL, 2);
                        switch (heff_tag_of(v_x1221_2449)) {
                        case TAG_VFun: {
                          heff_take_n(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VCons: {
                          heff_take_n(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VTag: {
                          heff_take_n(v_x1221_2449, 0ULL, 2);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VInt: {
                          heff_take_n(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VFloat: {
                          heff_take_na(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VFloat32: {
                          heff_take_n(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VStr: {
                          V v_r_2458 = heff_field(v_x1221_2449, 0);
                          heff_take_n(v_x1221_2449, 1ULL, 1);
                          switch (heff_tag_of(v_x1222_2450)) {
                          case TAG_Nil: {
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24VTag, TAG_CPointer, 2, (V[]){v_t_2448, v_r_2458})}});
                          }
                          case TAG_Cons: {
                            heff_take_n(v_x1222_2450, 0ULL, 2);
                            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                            heff_drop(v_t_2448);
                            heff_drop(v_r_2458);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x1222_2450)}});
                          }
                        }
                        case TAG_VRune: {
                          heff_take_n(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VArr: {
                          heff_take_n(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VBytes: {
                          heff_take_n(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VBits: {
                          heff_take_n(v_x1221_2449, 0ULL, 2);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VErased: {
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x1221_2449)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x122_2440)}});
                      }
                    }
                    case TAG_VRune: {
                      heff_take_n(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VArr: {
                      heff_take_n(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VBytes: {
                      heff_take_n(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VBits: {
                      heff_take_n(v_x121_2439, 0ULL, 2);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VErased: {
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x121_2439)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
                  }
                } else {
                  heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                  if (heff_strEq_c(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str7))) {
                    switch (heff_tag_of(v_x12_244)) {
                    case TAG_Nil: {
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CVoid)}});
                    }
                    case TAG_Cons: {
                      heff_take_n(v_x12_244, 0ULL, 2);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
                    }
                  } else {
                    heff_drop(v_x12_244);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBits: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VErased: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str0, 2, "op");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str1, 3, "fun");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str2, 4, "name");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str3, 3, "fun");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str4, 4, "args");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str5, 3, "fun");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str6, 6, "result");
V g_heff_2ecompile_2eglue_2ereadOp_lam0(V self, V *args);
V g_heff_2ecompile_2eglue_2ereadOp_lam1(V self, V *args);
V g_heff_2ecompile_2eglue_2ereadOp_lam2(V self, V *args);
V g_heff_2ecompile_2eglue_2ereadOp_lam3(V self, V *args);
V g_heff_2ecompile_2eglue_2ereadOp_lam4(V self, V *args); static Clo g_heff_2ecompile_2eglue_2ereadOp_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2ereadOp_lam4, 4, 0};
Clo g_heff_2ecompile_2eglue_2ereadOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2ereadOp_entry, 1, 0};

V g_heff_2ecompile_2eglue_2ereadOp(V v_v_240) {
top: ;
  HeffT2 v_t_241 = ({ V a_0 = heff_dup(v_v_240); V b_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str0); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
  {
    V v_field_243 = v_t_241.f[1];
    V v_tag_242 = heff_box_i64(((int64_t)v_t_241.f[0]));
    HeffT2 v_t_244 = ({ V a_0 = heff_dup(v_v_240); V b_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str1); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_x2_2427;
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_246;
        HeffT2 v_t_249 = ({ V a_0 = v_x_248; V b_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str2); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2413 = v_field_2411;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VFun: {
              heff_take_n(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VCons: {
              heff_take_n(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VTag: {
              heff_take_n(v_x_2413, 0ULL, 2);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VInt: {
              heff_take_n(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VFloat: {
              heff_take_na(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VFloat32: {
              heff_take_n(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VStr: {
              V v_s_2421 = heff_field(v_x_2413, 0);
              V v_ru_24x_2413_24VStr = heff_take_reuse_n(v_x_2413, 1ULL, 1);
              v_x2_2427 = heff_tag_at_n(v_ru_24x_2413_24VStr, TAG_Just, 1, (V[]){v_s_2421});
              break;
            }
            case TAG_VRune: {
              heff_take_n(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VArr: {
              heff_take_n(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VBytes: {
              heff_take_n(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VBits: {
              heff_take_n(v_x_2413, 0ULL, 2);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VErased: {
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
          } else {
            heff_drop(v_field_2411);
            v_x2_2427 = NTAG(TAG_Nothing);
          }
        }
      } else {
        heff_drop(v_field_246);
        v_x2_2427 = NTAG(TAG_Nothing);
      }
      HeffT2 v_t_2428 = ({ V a_0 = heff_dup(v_v_240); V b_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str3); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_2430 = v_t_2428.f[1];
        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
        V v_t_24122;
        if ((v_tag_2429 == ((int64_t)0ULL))) {
          V v_x_2432 = v_field_2430;
          HeffT2 v_t_2433 = ({ V a_0 = v_x_2432; V b_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str4); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
          {
            V v_field_2435 = v_t_2433.f[1];
            int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
            if ((v_tag_2434 == ((int64_t)0ULL))) {
              V v_x_2437 = v_field_2435;
              HeffT2 v_t_2438 = (g_heff_2ecompile_2eglue_2elistOf_24cpr(v_x_2437));
              {
                V v_field_2440 = v_t_2438.f[1];
                int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                if ((v_tag_2439 == ((int64_t)0ULL))) {
                  V v_x_2442 = v_field_2440;
                  HeffT2 v_t_2443 = (g_heff_2ecompile_2eglue_2eeachOf_24s1262413731x290637868_24cpr(v_x_2442));
                  {
                    V v_field_2445 = v_t_2443.f[1];
                    V v_tag_2444 = heff_box_i64(((int64_t)v_t_2443.f[0]));
                    v_t_24122 = heff_clo_n(g_heff_2ecompile_2eglue_2ereadOp_lam0, 2, 5, (V[]){v_tag_242, v_field_243, v_x2_2427, v_tag_2444, v_field_2445});
                  }
                } else {
                  heff_drop(v_field_2440);
                  v_t_24122 = heff_clo_n(g_heff_2ecompile_2eglue_2ereadOp_lam1, 2, 3, (V[]){v_tag_242, v_field_243, v_x2_2427});
                }
              }
            } else {
              heff_drop(v_field_2435);
              v_t_24122 = heff_clo_n(g_heff_2ecompile_2eglue_2ereadOp_lam2, 2, 3, (V[]){v_tag_242, v_field_243, v_x2_2427});
            }
          }
        } else {
          heff_drop(v_field_2430);
          v_t_24122 = heff_clo_n(g_heff_2ecompile_2eglue_2ereadOp_lam3, 2, 3, (V[]){v_tag_242, v_field_243, v_x2_2427});
        }
        HeffT2 v_t_24123 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str5); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_24133;
        {
          V v_field_24125 = v_t_24123.f[1];
          int64_t v_tag_24124 = ((int64_t)v_t_24123.f[0]);
          if ((v_tag_24124 == ((int64_t)0ULL))) {
            V v_x_24127 = v_field_24125;
            HeffT2 v_t_24128 = ({ V a_0 = v_x_24127; V b_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str6); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
            {
              V v_field_24130 = v_t_24128.f[1];
              int64_t v_tag_24129 = ((int64_t)v_t_24128.f[0]);
              if ((v_tag_24129 == ((int64_t)0ULL))) {
                V v_x_24132 = v_field_24130;
                v_t_24133 = ({ V a_0 = v_x_24132; V r_ = (g_heff_2ecompile_2eglue_2ecResultOf(a_0)); heff_drop(v_x_24132); r_; });
              } else {
                heff_drop(v_field_24130);
                v_t_24133 = NTAG(TAG_Nothing);
              }
            }
          } else {
            heff_drop(v_field_24125);
            v_t_24133 = NTAG(TAG_Nothing);
          }
        }
        return heff_tail(v_t_24122, 2, (V[]){v_t_24133, ((V)&g_heff_2ecompile_2eglue_2ereadOp_lam4_clo)});
      }
    }
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2ereadOp(a[0]);
}
V g_heff_2ecompile_2eglue_2ereadOp_lam0(V self, V *args) {
  V v_x4_2446 = args[0];
  V v_f_2447 = args[1];
  V v_tag_242 = heff_env(self)[0];
  V v_field_243 = heff_env(self)[1];
  V v_x2_2427 = heff_env(self)[2];
  V v_tag_2444 = heff_env(self)[3];
  V v_field_2445 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_unbox_i64(v_tag_242) == ((int64_t)0ULL))) {
    V v_x_2449 = v_field_243;
    switch (heff_tag_of(v_x_2449)) {
    case TAG_VFun: {
      heff_take_n(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VTag: {
      heff_take_n(v_x_2449, 0ULL, 2);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VInt: {
      heff_take_n(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat: {
      heff_take_na(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VStr: {
      V v_s_2457 = heff_field(v_x_2449, 0);
      V v_ru_24x_2449_24VStr = heff_take_reuse_n(v_x_2449, 1ULL, 1);
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nothing: {
        heff_drop(v_x4_2446);
        heff_drop(v_f_2447);
        heff_drop(v_tag_2444);
        heff_drop(v_field_2445);
        heff_drop(v_s_2457);
        heff_drop_cell(v_ru_24x_2449_24VStr, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_b_2458 = heff_field(v_x2_2427, 0);
        heff_take_n(v_x2_2427, 1ULL, 1);
        if ((heff_unbox_i64(v_tag_2444) == ((int64_t)0ULL))) {
          V v_c_2460 = v_field_2445;
          switch (heff_tag_of(v_x4_2446)) {
          case TAG_Nothing: {
            heff_drop(v_f_2447);
            heff_drop(v_s_2457);
            heff_drop_cell(v_ru_24x_2449_24VStr, 1);
            heff_drop(v_b_2458);
            heff_drop(v_c_2460);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_d_2461 = heff_field(v_x4_2446, 0);
            heff_take_n(v_x4_2446, 1ULL, 1);
            V v_t_2462 = heff_tr(heff_call(v_f_2447, 4, (V[]){v_s_2457, v_b_2458, v_c_2460, v_d_2461}));
            return heff_tag_at_n(v_ru_24x_2449_24VStr, TAG_Just, 1, (V[]){v_t_2462});
          }
          default: return heff_nomatch(v_x4_2446);
          }
        } else {
          heff_drop(v_x4_2446);
          heff_drop(v_f_2447);
          heff_drop(v_field_2445);
          heff_drop(v_s_2457);
          heff_drop_cell(v_ru_24x_2449_24VStr, 1);
          heff_drop(v_b_2458);
          return NTAG(TAG_Nothing);
        }
      }
      default: return heff_nomatch(v_x2_2427);
      }
    }
    case TAG_VRune: {
      heff_take_n(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VArr: {
      heff_take_n(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBytes: {
      heff_take_n(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBits: {
      heff_take_n(v_x_2449, 0ULL, 2);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VErased: {
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x_2449);
    }
  } else {
    heff_drop(v_x4_2446);
    heff_drop(v_f_2447);
    heff_drop(v_field_243);
    heff_drop(v_x2_2427);
    heff_drop(v_tag_2444);
    heff_drop(v_field_2445);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_lam1(V self, V *args) {
  V v_x4_2468 = args[0];
  V v_f_2469 = args[1];
  V v_tag_242 = heff_env(self)[0];
  V v_field_243 = heff_env(self)[1];
  V v_x2_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x4_2468);
  heff_drop(v_f_2469);
  if ((heff_unbox_i64(v_tag_242) == ((int64_t)0ULL))) {
    V v_x_2471 = v_field_243;
    switch (heff_tag_of(v_x_2471)) {
    case TAG_VFun: {
      heff_take_n(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VTag: {
      heff_take_n(v_x_2471, 0ULL, 2);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VInt: {
      heff_take_n(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat: {
      heff_take_na(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VStr: {
      heff_take_n(v_x_2471, 0ULL, 1);
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        heff_take_n(v_x2_2427, 0ULL, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x2_2427);
      }
    }
    case TAG_VRune: {
      heff_take_n(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VArr: {
      heff_take_n(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBytes: {
      heff_take_n(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBits: {
      heff_take_n(v_x_2471, 0ULL, 2);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VErased: {
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x_2471);
    }
  } else {
    heff_drop(v_field_243);
    heff_drop(v_x2_2427);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_lam2(V self, V *args) {
  V v_x4_2486 = args[0];
  V v_f_2487 = args[1];
  V v_tag_242 = heff_env(self)[0];
  V v_field_243 = heff_env(self)[1];
  V v_x2_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x4_2486);
  heff_drop(v_f_2487);
  if ((heff_unbox_i64(v_tag_242) == ((int64_t)0ULL))) {
    V v_x_2489 = v_field_243;
    switch (heff_tag_of(v_x_2489)) {
    case TAG_VFun: {
      heff_take_n(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VTag: {
      heff_take_n(v_x_2489, 0ULL, 2);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VInt: {
      heff_take_n(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat: {
      heff_take_na(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VStr: {
      heff_take_n(v_x_2489, 0ULL, 1);
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        heff_take_n(v_x2_2427, 0ULL, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x2_2427);
      }
    }
    case TAG_VRune: {
      heff_take_n(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VArr: {
      heff_take_n(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBytes: {
      heff_take_n(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBits: {
      heff_take_n(v_x_2489, 0ULL, 2);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VErased: {
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x_2489);
    }
  } else {
    heff_drop(v_field_243);
    heff_drop(v_x2_2427);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_lam3(V self, V *args) {
  V v_x4_24104 = args[0];
  V v_f_24105 = args[1];
  V v_tag_242 = heff_env(self)[0];
  V v_field_243 = heff_env(self)[1];
  V v_x2_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x4_24104);
  heff_drop(v_f_24105);
  if ((heff_unbox_i64(v_tag_242) == ((int64_t)0ULL))) {
    V v_x_24107 = v_field_243;
    switch (heff_tag_of(v_x_24107)) {
    case TAG_VFun: {
      heff_take_n(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VTag: {
      heff_take_n(v_x_24107, 0ULL, 2);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VInt: {
      heff_take_n(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat: {
      heff_take_na(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VStr: {
      heff_take_n(v_x_24107, 0ULL, 1);
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        heff_take_n(v_x2_2427, 0ULL, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x2_2427);
      }
    }
    case TAG_VRune: {
      heff_take_n(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VArr: {
      heff_take_n(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBytes: {
      heff_take_n(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBits: {
      heff_take_n(v_x_24107, 0ULL, 2);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VErased: {
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x_24107);
    }
  } else {
    heff_drop(v_field_243);
    heff_drop(v_x2_2427);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_lam4(V self, V *args) {
  V v_tag_24134 = args[0];
  V v_fun_24135 = args[1];
  V v_args_24136 = args[2];
  V v_result_24137 = args[3];
  return heff_rec_n(4, shape_tag__fun__args__result, (V[]){v_tag_24134, v_fun_24135, v_args_24136, v_result_24137});
}
Clo g_heff_2ecompile_2eglue_2etyOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2etyOf_entry, 1, 0};

V g_heff_2ecompile_2eglue_2etyOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SU: {
    return v_x1_240;
  }
  case TAG_SDecode: {
    V v_x11_242 = heff_dup(heff_field(v_x1_240, 0));
    switch (heff_tag_of(v_x11_242)) {
    case TAG_SLocal: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SGlobal: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SCode: {
      V v_t_245 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_tag(v_x1_240, 1);
      V t_0 = v_t_245;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_SApp: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SLam: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SCons: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SProj: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_STag: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SMatch: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SSpecialize: {
      heff_take_n(v_x11_242, 0ULL, 3);
      return v_x1_240;
    }
    case TAG_SIs: {
      V v_e_2420 = heff_field(v_x11_242, 0);
      V v_ru_24x11_242_24SIs = heff_take_reuse_n(v_x11_242, 1ULL, 1);
      heff_drop_tag(v_x1_240, 1);
      V t_0 = heff_tag_at_n(v_ru_24x11_242_24SIs, TAG_SDecode, 1, (V[]){v_e_2420});
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_SOpaque: {
      return v_x1_240;
    }
    case TAG_SAbandon: {
      return v_x1_240;
    }
    case TAG_SRec: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SFix: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SImplicit: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SPrim: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SMetaApp: {
      heff_take_n(v_x11_242, 0ULL, 3);
      return v_x1_240;
    }
    case TAG_SLitInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitFixed: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_SFunction: {
    return v_x1_240;
  }
  case TAG_SRecord: {
    return v_x1_240;
  }
  case TAG_SSum: {
    return v_x1_240;
  }
  case TAG_SIsTy: {
    V v_t_2447 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_t_2447;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SPrimInt: {
    return v_x1_240;
  }
  case TAG_SPrimFloat: {
    return v_x1_240;
  }
  case TAG_SPrimString: {
    return v_x1_240;
  }
  case TAG_SPrimRune: {
    return v_x1_240;
  }
  case TAG_SPrimArray: {
    return v_x1_240;
  }
  case TAG_SFixed: {
    return v_x1_240;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eglue_2etyOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2etyOf(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str0, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str2, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str3, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str4, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str5, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str6, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str7, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str8, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str9, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str10, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str11, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str12, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str13, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str14, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str15, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str16, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str17, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str18, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str19, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str20, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str21, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str22, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str23, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str24, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str25, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str26, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str27, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str28, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str29, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str30, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str31, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str32, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str33, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str34, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str35, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str36, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str37, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str38, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str39, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str40, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str41, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str42, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str43, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str44, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str45, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str46, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str47, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str48, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str49, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str50, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str51, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str52, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str53, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str54, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str55, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str56, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str57, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str58, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str59, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str60, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str61, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str62, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str63, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str64, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str65, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str66, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str67, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str68, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str69, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str70, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str71, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str72, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str73, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str74, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str75, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str76, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str77, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str78, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str79, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str80, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str81, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str82, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str83, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str84, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str85, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str86, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str87, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str88, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str89, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str90, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str91, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str92, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str93, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str94, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str95, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str96, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str97, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str98, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str99, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str100, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str101, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str102, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str103, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str104, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str105, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str106, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str107, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str108, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str109, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str110, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str111, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str112, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str113, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str114, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str115, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str116, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str117, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str118, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str119, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str120, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str121, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str122, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str123, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str124, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str125, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str126, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str127, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str128, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str129, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str130, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str131, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str132, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str133, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str134, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str135, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str136, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str137, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str138, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str139, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str140, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str141, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str142, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str143, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str144, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str145, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str146, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str147, 32, "`'s answer cannot be made of a `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str148, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str149, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str150, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str151, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str152, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str153, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str154, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str155, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str156, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str157, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str158, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str159, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str160, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str161, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str162, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str163, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str164, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str165, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str166, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str167, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str168, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str169, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str170, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str171, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str172, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str173, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str174, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str175, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str176, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str177, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str178, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str179, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str180, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str181, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str182, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str183, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str184, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str185, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str186, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str187, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str188, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str189, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str190, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str191, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str192, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str193, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str194, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str195, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str196, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str197, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str198, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str199, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str200, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str201, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str202, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str203, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str204, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str205, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str206, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str207, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str208, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str209, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str210, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str211, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str212, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str213, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str214, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str215, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str216, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str217, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str218, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str219, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str220, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str221, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str222, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str223, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str224, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str225, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str226, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str227, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str228, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str229, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str230, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str231, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str232, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str233, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str234, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str235, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str236, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str237, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str238, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str239, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str240, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str241, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str242, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str243, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str244, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str245, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str246, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str247, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str248, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str249, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str250, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str251, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str252, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str253, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str254, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str255, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str256, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str257, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str258, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str259, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str260, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str261, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str262, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str263, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str264, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str265, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str266, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str267, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str268, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str269, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str270, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str271, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str272, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str273, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str274, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str275, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str276, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str277, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str278, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str279, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str280, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str281, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str282, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str283, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str284, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str285, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str286, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str287, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str288, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str289, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str290, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str291, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str292, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str293, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str294, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str295, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str296, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str297, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str298, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str299, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str300, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str301, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str302, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str303, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str304, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str305, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str306, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str307, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str308, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str309, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str310, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str311, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str312, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str313, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str314, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str315, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str316, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str317, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str318, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str319, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str320, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str321, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str322, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str323, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str324, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str325, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str326, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str327, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str328, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str329, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str330, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str331, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str332, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str333, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str334, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str335, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str336, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str337, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str338, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str339, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str340, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str341, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str342, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str343, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str344, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str345, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str346, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str347, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str348, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str349, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str350, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str351, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str352, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str353, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str354, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str355, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str356, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str357, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str358, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str359, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str360, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str361, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str362, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str363, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str364, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str365, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str366, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str367, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str368, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str369, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str370, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str371, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str372, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str373, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str374, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str375, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str376, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str377, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str378, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str379, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str380, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str381, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str382, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str383, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str384, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str385, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str386, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str387, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str388, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str389, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str390, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str391, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str392, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str393, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str394, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str395, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str396, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str397, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str398, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str399, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str400, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str401, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str402, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str403, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str404, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str405, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str406, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str407, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str408, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str409, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str410, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str411, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str412, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str413, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str414, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str415, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str416, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str417, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str418, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str419, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str420, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str421, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str422, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str423, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str424, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str425, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str426, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str427, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str428, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str429, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str430, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str431, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str432, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str433, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str434, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str435, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str436, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str437, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str438, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str439, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str440, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str441, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str442, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str443, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str444, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str445, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str446, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str447, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str448, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str449, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str450, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str451, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str452, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str453, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str454, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str455, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str456, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str457, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str458, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str459, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str460, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str461, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str462, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str463, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str464, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str465, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str466, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str467, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str468, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str469, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str470, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str471, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str472, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str473, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str474, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str475, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str476, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str477, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str478, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str479, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str480, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str481, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str482, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str483, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str484, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str485, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str486, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str487, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str488, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str489, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str490, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str491, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str492, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str493, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str494, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str495, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str496, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str497, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str498, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str499, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str500, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str501, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str502, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str503, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str504, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str505, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str506, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str507, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str508, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str509, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str510, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str511, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str512, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str513, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str514, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str515, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str516, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str517, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str518, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str519, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str520, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str521, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str522, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str523, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str524, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str525, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str526, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str527, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str528, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str529, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str530, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str531, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str532, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str533, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str534, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str535, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str536, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str537, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str538, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str539, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str540, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str541, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str542, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str543, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str544, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str545, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str546, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str547, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str548, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str549, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str550, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str551, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str552, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str553, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str554, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str555, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str556, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str557, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str558, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str559, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str560, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str561, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str562, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str563, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str564, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str565, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str566, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str567, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str568, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str569, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str570, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str571, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str572, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str573, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str574, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str575, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str576, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str577, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str578, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str579, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str580, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str581, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str582, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str583, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str584, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str585, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str586, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str587, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str588, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str589, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str590, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str591, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str592, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str593, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str594, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str595, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str596, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str597, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str598, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str599, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str600, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str601, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str602, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str603, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str604, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str605, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str606, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str607, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str608, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str609, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str610, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str611, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str612, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str613, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str614, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str615, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str616, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str617, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str618, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str619, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str620, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str621, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str622, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str623, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str624, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str625, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str626, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str627, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str628, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str629, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str630, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str631, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str632, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str633, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str634, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str635, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str636, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str637, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str638, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str639, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str640, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str641, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str642, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str643, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str644, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str645, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str646, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str647, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str648, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str649, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str650, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str651, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str652, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str653, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str654, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str655, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str656, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str657, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str658, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str659, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str660, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str661, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str662, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str663, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str664, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str665, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str666, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str667, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str668, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str669, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str670, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str671, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str672, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str673, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str674, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str675, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str676, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str677, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str678, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str679, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str680, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str681, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str682, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str683, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str684, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str685, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str686, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str687, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str688, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str689, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str690, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str691, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str692, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str693, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str694, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str695, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str696, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str697, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str698, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str699, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str700, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str701, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str702, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str703, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str704, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str705, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str706, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str707, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str708, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str709, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str710, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str711, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str712, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str713, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str714, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str715, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str716, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str717, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str718, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str719, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str720, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str721, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str722, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str723, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str724, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str725, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str726, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str727, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str728, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str729, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str730, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str731, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str732, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str733, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str734, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str735, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str736, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str737, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str738, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str739, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str740, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str741, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str742, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str743, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str744, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str745, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str746, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str747, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str748, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str749, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str750, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str751, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str752, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str753, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str754, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str755, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str756, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str757, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str758, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str759, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str760, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str761, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str762, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str763, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str764, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str765, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str766, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str767, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str768, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str769, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str770, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str771, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str772, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str773, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str774, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str775, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str776, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str777, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str778, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str779, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str780, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str781, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str782, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str783, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str784, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str785, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str786, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str787, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str788, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str789, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str790, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str791, 13, "`'s result, `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str792, 32, "`, cannot fail as `-1` or `NULL`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str793, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str794, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str795, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str796, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str797, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str798, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str799, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str800, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str801, 33, "`'s `Right` cannot be made of a `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str802, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str803, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str804, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str805, 65, "`'s answer is not an `Either Errno a`, as its result is described");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str806, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str807, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str808, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str809, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str810, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str811, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str812, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str813, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str814, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str815, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str816, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str817, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str818, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str819, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str820, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str821, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str822, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str823, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str824, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str825, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str826, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str827, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str828, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str829, 68, "`'s answer is not an `Either Errno Unit`, as its result is described");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str830, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str831, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str832, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str833, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str834, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str835, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str836, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str837, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str838, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str839, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str840, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str841, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str842, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str843, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str844, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str845, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str846, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str847, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
Clo g_heff_2ecompile_2eglue_2eresultBad_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2eresultBad_entry, 3, 0};

V g_heff_2ecompile_2eglue_2eresultBad(V v_tag_240, V v_x2_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Gives: {
    V v_c_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Gives = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_SU: {
      heff_take_n(v_t_242, 0ULL, 1);
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_249;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_246 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_249 = v_t_246;
          break;
        }
        case TAG_CDouble: {
          v_t_249 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str0);
          break;
        }
        case TAG_CBool: {
          v_t_249 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1);
          break;
        }
        case TAG_CString: {
          v_t_249 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str2);
          break;
        }
        case TAG_CText: {
          v_t_249 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str3);
          break;
        }
        case TAG_COwnedString: {
          v_t_249 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str4);
          break;
        }
        case TAG_CPointer: {
          V v_t_247 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_249 = heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str5));
          break;
        }
        case TAG_CVoid: {
          v_t_249 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str6);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str7), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str8)));
        V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str9), heff_strAppend(v_tag_240, v_t_2410));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2411});
      }
      case TAG_CDouble: {
        V v_t_2415;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2412 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2415 = v_t_2412;
          break;
        }
        case TAG_CDouble: {
          v_t_2415 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str10);
          break;
        }
        case TAG_CBool: {
          v_t_2415 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str11);
          break;
        }
        case TAG_CString: {
          v_t_2415 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str12);
          break;
        }
        case TAG_CText: {
          v_t_2415 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str13);
          break;
        }
        case TAG_COwnedString: {
          v_t_2415 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str14);
          break;
        }
        case TAG_CPointer: {
          V v_t_2413 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2415 = heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str15));
          break;
        }
        case TAG_CVoid: {
          v_t_2415 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str16);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str17), heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str18)));
        V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str19), heff_strAppend(v_tag_240, v_t_2416));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2417});
      }
      case TAG_CBool: {
        V v_t_2421;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2418 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2421 = v_t_2418;
          break;
        }
        case TAG_CDouble: {
          v_t_2421 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str20);
          break;
        }
        case TAG_CBool: {
          v_t_2421 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str21);
          break;
        }
        case TAG_CString: {
          v_t_2421 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str22);
          break;
        }
        case TAG_CText: {
          v_t_2421 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str23);
          break;
        }
        case TAG_COwnedString: {
          v_t_2421 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str24);
          break;
        }
        case TAG_CPointer: {
          V v_t_2419 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2421 = heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str25));
          break;
        }
        case TAG_CVoid: {
          v_t_2421 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str26);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str27), heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str28)));
        V v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str29), heff_strAppend(v_tag_240, v_t_2422));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2423});
      }
      case TAG_CString: {
        V v_t_2427;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2424 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2427 = v_t_2424;
          break;
        }
        case TAG_CDouble: {
          v_t_2427 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str30);
          break;
        }
        case TAG_CBool: {
          v_t_2427 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str31);
          break;
        }
        case TAG_CString: {
          v_t_2427 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str32);
          break;
        }
        case TAG_CText: {
          v_t_2427 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str33);
          break;
        }
        case TAG_COwnedString: {
          v_t_2427 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str34);
          break;
        }
        case TAG_CPointer: {
          V v_t_2425 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2427 = heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str35));
          break;
        }
        case TAG_CVoid: {
          v_t_2427 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str36);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str37), heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str38)));
        V v_t_2429 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str39), heff_strAppend(v_tag_240, v_t_2428));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2429});
      }
      case TAG_CText: {
        V v_t_2433;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2430 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2433 = v_t_2430;
          break;
        }
        case TAG_CDouble: {
          v_t_2433 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str40);
          break;
        }
        case TAG_CBool: {
          v_t_2433 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str41);
          break;
        }
        case TAG_CString: {
          v_t_2433 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str42);
          break;
        }
        case TAG_CText: {
          v_t_2433 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str43);
          break;
        }
        case TAG_COwnedString: {
          v_t_2433 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str44);
          break;
        }
        case TAG_CPointer: {
          V v_t_2431 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2433 = heff_strAppend(v_t_2431, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str45));
          break;
        }
        case TAG_CVoid: {
          v_t_2433 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str46);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str47), heff_strAppend(v_t_2433, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str48)));
        V v_t_2435 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str49), heff_strAppend(v_tag_240, v_t_2434));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2435});
      }
      case TAG_COwnedString: {
        V v_t_2439;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2436 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2439 = v_t_2436;
          break;
        }
        case TAG_CDouble: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str50);
          break;
        }
        case TAG_CBool: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str51);
          break;
        }
        case TAG_CString: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str52);
          break;
        }
        case TAG_CText: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str53);
          break;
        }
        case TAG_COwnedString: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str54);
          break;
        }
        case TAG_CPointer: {
          V v_t_2437 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2439 = heff_strAppend(v_t_2437, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str55));
          break;
        }
        case TAG_CVoid: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str56);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2440 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str57), heff_strAppend(v_t_2439, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str58)));
        V v_t_2441 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str59), heff_strAppend(v_tag_240, v_t_2440));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2441});
      }
      case TAG_CPointer: {
        V v_t_2447;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2444 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2447 = v_t_2444;
          break;
        }
        case TAG_CDouble: {
          v_t_2447 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str60);
          break;
        }
        case TAG_CBool: {
          v_t_2447 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str61);
          break;
        }
        case TAG_CString: {
          v_t_2447 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str62);
          break;
        }
        case TAG_CText: {
          v_t_2447 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str63);
          break;
        }
        case TAG_COwnedString: {
          v_t_2447 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str64);
          break;
        }
        case TAG_CPointer: {
          V v_t_2445 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2447 = heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str65));
          break;
        }
        case TAG_CVoid: {
          v_t_2447 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str66);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2448 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str67), heff_strAppend(v_t_2447, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str68)));
        V v_t_2449 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str69), heff_strAppend(v_tag_240, v_t_2448));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2449});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SDecode: {
      heff_take_n(v_t_242, 0ULL, 1);
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_2455;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2452 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2455 = v_t_2452;
          break;
        }
        case TAG_CDouble: {
          v_t_2455 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str70);
          break;
        }
        case TAG_CBool: {
          v_t_2455 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str71);
          break;
        }
        case TAG_CString: {
          v_t_2455 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str72);
          break;
        }
        case TAG_CText: {
          v_t_2455 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str73);
          break;
        }
        case TAG_COwnedString: {
          v_t_2455 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str74);
          break;
        }
        case TAG_CPointer: {
          V v_t_2453 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2455 = heff_strAppend(v_t_2453, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str75));
          break;
        }
        case TAG_CVoid: {
          v_t_2455 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str76);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2456 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str77), heff_strAppend(v_t_2455, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str78)));
        V v_t_2457 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str79), heff_strAppend(v_tag_240, v_t_2456));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2457});
      }
      case TAG_CDouble: {
        V v_t_2461;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2458 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2461 = v_t_2458;
          break;
        }
        case TAG_CDouble: {
          v_t_2461 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str80);
          break;
        }
        case TAG_CBool: {
          v_t_2461 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str81);
          break;
        }
        case TAG_CString: {
          v_t_2461 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str82);
          break;
        }
        case TAG_CText: {
          v_t_2461 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str83);
          break;
        }
        case TAG_COwnedString: {
          v_t_2461 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str84);
          break;
        }
        case TAG_CPointer: {
          V v_t_2459 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2461 = heff_strAppend(v_t_2459, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str85));
          break;
        }
        case TAG_CVoid: {
          v_t_2461 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str86);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2462 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str87), heff_strAppend(v_t_2461, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str88)));
        V v_t_2463 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str89), heff_strAppend(v_tag_240, v_t_2462));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2463});
      }
      case TAG_CBool: {
        V v_t_2467;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2464 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2467 = v_t_2464;
          break;
        }
        case TAG_CDouble: {
          v_t_2467 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str90);
          break;
        }
        case TAG_CBool: {
          v_t_2467 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str91);
          break;
        }
        case TAG_CString: {
          v_t_2467 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str92);
          break;
        }
        case TAG_CText: {
          v_t_2467 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str93);
          break;
        }
        case TAG_COwnedString: {
          v_t_2467 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str94);
          break;
        }
        case TAG_CPointer: {
          V v_t_2465 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2467 = heff_strAppend(v_t_2465, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str95));
          break;
        }
        case TAG_CVoid: {
          v_t_2467 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str96);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2468 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str97), heff_strAppend(v_t_2467, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str98)));
        V v_t_2469 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str99), heff_strAppend(v_tag_240, v_t_2468));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2469});
      }
      case TAG_CString: {
        V v_t_2473;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2470 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2473 = v_t_2470;
          break;
        }
        case TAG_CDouble: {
          v_t_2473 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str100);
          break;
        }
        case TAG_CBool: {
          v_t_2473 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str101);
          break;
        }
        case TAG_CString: {
          v_t_2473 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str102);
          break;
        }
        case TAG_CText: {
          v_t_2473 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str103);
          break;
        }
        case TAG_COwnedString: {
          v_t_2473 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str104);
          break;
        }
        case TAG_CPointer: {
          V v_t_2471 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2473 = heff_strAppend(v_t_2471, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str105));
          break;
        }
        case TAG_CVoid: {
          v_t_2473 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str106);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2474 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str107), heff_strAppend(v_t_2473, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str108)));
        V v_t_2475 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str109), heff_strAppend(v_tag_240, v_t_2474));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2475});
      }
      case TAG_CText: {
        V v_t_2479;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2476 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2479 = v_t_2476;
          break;
        }
        case TAG_CDouble: {
          v_t_2479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str110);
          break;
        }
        case TAG_CBool: {
          v_t_2479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str111);
          break;
        }
        case TAG_CString: {
          v_t_2479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str112);
          break;
        }
        case TAG_CText: {
          v_t_2479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str113);
          break;
        }
        case TAG_COwnedString: {
          v_t_2479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str114);
          break;
        }
        case TAG_CPointer: {
          V v_t_2477 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2479 = heff_strAppend(v_t_2477, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str115));
          break;
        }
        case TAG_CVoid: {
          v_t_2479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str116);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2480 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str117), heff_strAppend(v_t_2479, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str118)));
        V v_t_2481 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str119), heff_strAppend(v_tag_240, v_t_2480));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2481});
      }
      case TAG_COwnedString: {
        V v_t_2485;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2482 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2485 = v_t_2482;
          break;
        }
        case TAG_CDouble: {
          v_t_2485 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str120);
          break;
        }
        case TAG_CBool: {
          v_t_2485 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str121);
          break;
        }
        case TAG_CString: {
          v_t_2485 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str122);
          break;
        }
        case TAG_CText: {
          v_t_2485 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str123);
          break;
        }
        case TAG_COwnedString: {
          v_t_2485 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str124);
          break;
        }
        case TAG_CPointer: {
          V v_t_2483 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2485 = heff_strAppend(v_t_2483, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str125));
          break;
        }
        case TAG_CVoid: {
          v_t_2485 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str126);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2486 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str127), heff_strAppend(v_t_2485, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str128)));
        V v_t_2487 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str129), heff_strAppend(v_tag_240, v_t_2486));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2487});
      }
      case TAG_CPointer: {
        V v_t_2493;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2490 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2493 = v_t_2490;
          break;
        }
        case TAG_CDouble: {
          v_t_2493 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str130);
          break;
        }
        case TAG_CBool: {
          v_t_2493 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str131);
          break;
        }
        case TAG_CString: {
          v_t_2493 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str132);
          break;
        }
        case TAG_CText: {
          v_t_2493 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str133);
          break;
        }
        case TAG_COwnedString: {
          v_t_2493 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str134);
          break;
        }
        case TAG_CPointer: {
          V v_t_2491 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2493 = heff_strAppend(v_t_2491, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str135));
          break;
        }
        case TAG_CVoid: {
          v_t_2493 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str136);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2494 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str137), heff_strAppend(v_t_2493, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str138)));
        V v_t_2495 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str139), heff_strAppend(v_tag_240, v_t_2494));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2495});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SFunction: {
      V v_dom_2497 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 5);
      V v_t_24101 = (g_heff_2ecompile_2eglue_2efits(heff_dup(v_c_243), v_dom_2497));
      if ((heff_dup(v_t_24101) == NTAG(TAG_True))) {
        heff_drop(v_tag_240);
        heff_drop(v_c_243);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        heff_drop(v_t_24101);
        return NTAG(TAG_Nothing);
      } else {
        heff_drop(v_t_24101);
        V v_t_24105;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24102 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24105 = v_t_24102;
          break;
        }
        case TAG_CDouble: {
          v_t_24105 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str140);
          break;
        }
        case TAG_CBool: {
          v_t_24105 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str141);
          break;
        }
        case TAG_CString: {
          v_t_24105 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str142);
          break;
        }
        case TAG_CText: {
          v_t_24105 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str143);
          break;
        }
        case TAG_COwnedString: {
          v_t_24105 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str144);
          break;
        }
        case TAG_CPointer: {
          V v_t_24103 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24105 = heff_strAppend(v_t_24103, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str145));
          break;
        }
        case TAG_CVoid: {
          v_t_24105 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str146);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24106 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str147), heff_strAppend(v_t_24105, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str148)));
        V v_t_24107 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str149), heff_strAppend(v_tag_240, v_t_24106));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24107});
      }
    }
    case TAG_SRecord: {
      heff_take_n(v_t_242, 0ULL, 3);
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24115;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24112 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24115 = v_t_24112;
          break;
        }
        case TAG_CDouble: {
          v_t_24115 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str150);
          break;
        }
        case TAG_CBool: {
          v_t_24115 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str151);
          break;
        }
        case TAG_CString: {
          v_t_24115 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str152);
          break;
        }
        case TAG_CText: {
          v_t_24115 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str153);
          break;
        }
        case TAG_COwnedString: {
          v_t_24115 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str154);
          break;
        }
        case TAG_CPointer: {
          V v_t_24113 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24115 = heff_strAppend(v_t_24113, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str155));
          break;
        }
        case TAG_CVoid: {
          v_t_24115 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str156);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24116 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str157), heff_strAppend(v_t_24115, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str158)));
        V v_t_24117 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str159), heff_strAppend(v_tag_240, v_t_24116));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24117});
      }
      case TAG_CDouble: {
        V v_t_24121;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24118 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24121 = v_t_24118;
          break;
        }
        case TAG_CDouble: {
          v_t_24121 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str160);
          break;
        }
        case TAG_CBool: {
          v_t_24121 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str161);
          break;
        }
        case TAG_CString: {
          v_t_24121 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str162);
          break;
        }
        case TAG_CText: {
          v_t_24121 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str163);
          break;
        }
        case TAG_COwnedString: {
          v_t_24121 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str164);
          break;
        }
        case TAG_CPointer: {
          V v_t_24119 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24121 = heff_strAppend(v_t_24119, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str165));
          break;
        }
        case TAG_CVoid: {
          v_t_24121 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str166);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24122 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str167), heff_strAppend(v_t_24121, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str168)));
        V v_t_24123 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str169), heff_strAppend(v_tag_240, v_t_24122));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24123});
      }
      case TAG_CBool: {
        V v_t_24127;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24124 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24127 = v_t_24124;
          break;
        }
        case TAG_CDouble: {
          v_t_24127 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str170);
          break;
        }
        case TAG_CBool: {
          v_t_24127 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str171);
          break;
        }
        case TAG_CString: {
          v_t_24127 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str172);
          break;
        }
        case TAG_CText: {
          v_t_24127 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str173);
          break;
        }
        case TAG_COwnedString: {
          v_t_24127 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str174);
          break;
        }
        case TAG_CPointer: {
          V v_t_24125 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24127 = heff_strAppend(v_t_24125, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str175));
          break;
        }
        case TAG_CVoid: {
          v_t_24127 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str176);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24128 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str177), heff_strAppend(v_t_24127, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str178)));
        V v_t_24129 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str179), heff_strAppend(v_tag_240, v_t_24128));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24129});
      }
      case TAG_CString: {
        V v_t_24133;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24130 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24133 = v_t_24130;
          break;
        }
        case TAG_CDouble: {
          v_t_24133 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str180);
          break;
        }
        case TAG_CBool: {
          v_t_24133 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str181);
          break;
        }
        case TAG_CString: {
          v_t_24133 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str182);
          break;
        }
        case TAG_CText: {
          v_t_24133 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str183);
          break;
        }
        case TAG_COwnedString: {
          v_t_24133 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str184);
          break;
        }
        case TAG_CPointer: {
          V v_t_24131 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24133 = heff_strAppend(v_t_24131, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str185));
          break;
        }
        case TAG_CVoid: {
          v_t_24133 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str186);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24134 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str187), heff_strAppend(v_t_24133, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str188)));
        V v_t_24135 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str189), heff_strAppend(v_tag_240, v_t_24134));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24135});
      }
      case TAG_CText: {
        V v_t_24139;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24136 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24139 = v_t_24136;
          break;
        }
        case TAG_CDouble: {
          v_t_24139 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str190);
          break;
        }
        case TAG_CBool: {
          v_t_24139 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str191);
          break;
        }
        case TAG_CString: {
          v_t_24139 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str192);
          break;
        }
        case TAG_CText: {
          v_t_24139 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str193);
          break;
        }
        case TAG_COwnedString: {
          v_t_24139 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str194);
          break;
        }
        case TAG_CPointer: {
          V v_t_24137 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24139 = heff_strAppend(v_t_24137, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str195));
          break;
        }
        case TAG_CVoid: {
          v_t_24139 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str196);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24140 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str197), heff_strAppend(v_t_24139, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str198)));
        V v_t_24141 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str199), heff_strAppend(v_tag_240, v_t_24140));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24141});
      }
      case TAG_COwnedString: {
        V v_t_24145;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24142 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24145 = v_t_24142;
          break;
        }
        case TAG_CDouble: {
          v_t_24145 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str200);
          break;
        }
        case TAG_CBool: {
          v_t_24145 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str201);
          break;
        }
        case TAG_CString: {
          v_t_24145 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str202);
          break;
        }
        case TAG_CText: {
          v_t_24145 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str203);
          break;
        }
        case TAG_COwnedString: {
          v_t_24145 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str204);
          break;
        }
        case TAG_CPointer: {
          V v_t_24143 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24145 = heff_strAppend(v_t_24143, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str205));
          break;
        }
        case TAG_CVoid: {
          v_t_24145 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str206);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24146 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str207), heff_strAppend(v_t_24145, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str208)));
        V v_t_24147 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str209), heff_strAppend(v_tag_240, v_t_24146));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24147});
      }
      case TAG_CPointer: {
        V v_t_24153;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24150 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24153 = v_t_24150;
          break;
        }
        case TAG_CDouble: {
          v_t_24153 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str210);
          break;
        }
        case TAG_CBool: {
          v_t_24153 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str211);
          break;
        }
        case TAG_CString: {
          v_t_24153 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str212);
          break;
        }
        case TAG_CText: {
          v_t_24153 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str213);
          break;
        }
        case TAG_COwnedString: {
          v_t_24153 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str214);
          break;
        }
        case TAG_CPointer: {
          V v_t_24151 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24153 = heff_strAppend(v_t_24151, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str215));
          break;
        }
        case TAG_CVoid: {
          v_t_24153 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str216);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24154 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str217), heff_strAppend(v_t_24153, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str218)));
        V v_t_24155 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str219), heff_strAppend(v_tag_240, v_t_24154));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24155});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SSum: {
      heff_take_n(v_t_242, 0ULL, 1);
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24161;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24158 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24161 = v_t_24158;
          break;
        }
        case TAG_CDouble: {
          v_t_24161 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str220);
          break;
        }
        case TAG_CBool: {
          v_t_24161 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str221);
          break;
        }
        case TAG_CString: {
          v_t_24161 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str222);
          break;
        }
        case TAG_CText: {
          v_t_24161 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str223);
          break;
        }
        case TAG_COwnedString: {
          v_t_24161 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str224);
          break;
        }
        case TAG_CPointer: {
          V v_t_24159 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24161 = heff_strAppend(v_t_24159, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str225));
          break;
        }
        case TAG_CVoid: {
          v_t_24161 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str226);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24162 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str227), heff_strAppend(v_t_24161, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str228)));
        V v_t_24163 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str229), heff_strAppend(v_tag_240, v_t_24162));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24163});
      }
      case TAG_CDouble: {
        V v_t_24167;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24164 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24167 = v_t_24164;
          break;
        }
        case TAG_CDouble: {
          v_t_24167 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str230);
          break;
        }
        case TAG_CBool: {
          v_t_24167 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str231);
          break;
        }
        case TAG_CString: {
          v_t_24167 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str232);
          break;
        }
        case TAG_CText: {
          v_t_24167 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str233);
          break;
        }
        case TAG_COwnedString: {
          v_t_24167 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str234);
          break;
        }
        case TAG_CPointer: {
          V v_t_24165 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24167 = heff_strAppend(v_t_24165, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str235));
          break;
        }
        case TAG_CVoid: {
          v_t_24167 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str236);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24168 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str237), heff_strAppend(v_t_24167, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str238)));
        V v_t_24169 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str239), heff_strAppend(v_tag_240, v_t_24168));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24169});
      }
      case TAG_CBool: {
        V v_t_24173;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24170 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24173 = v_t_24170;
          break;
        }
        case TAG_CDouble: {
          v_t_24173 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str240);
          break;
        }
        case TAG_CBool: {
          v_t_24173 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str241);
          break;
        }
        case TAG_CString: {
          v_t_24173 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str242);
          break;
        }
        case TAG_CText: {
          v_t_24173 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str243);
          break;
        }
        case TAG_COwnedString: {
          v_t_24173 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str244);
          break;
        }
        case TAG_CPointer: {
          V v_t_24171 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24173 = heff_strAppend(v_t_24171, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str245));
          break;
        }
        case TAG_CVoid: {
          v_t_24173 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str246);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24174 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str247), heff_strAppend(v_t_24173, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str248)));
        V v_t_24175 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str249), heff_strAppend(v_tag_240, v_t_24174));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24175});
      }
      case TAG_CString: {
        V v_t_24179;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24176 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24179 = v_t_24176;
          break;
        }
        case TAG_CDouble: {
          v_t_24179 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str250);
          break;
        }
        case TAG_CBool: {
          v_t_24179 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str251);
          break;
        }
        case TAG_CString: {
          v_t_24179 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str252);
          break;
        }
        case TAG_CText: {
          v_t_24179 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str253);
          break;
        }
        case TAG_COwnedString: {
          v_t_24179 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str254);
          break;
        }
        case TAG_CPointer: {
          V v_t_24177 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24179 = heff_strAppend(v_t_24177, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str255));
          break;
        }
        case TAG_CVoid: {
          v_t_24179 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str256);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24180 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str257), heff_strAppend(v_t_24179, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str258)));
        V v_t_24181 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str259), heff_strAppend(v_tag_240, v_t_24180));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24181});
      }
      case TAG_CText: {
        V v_t_24185;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24182 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24185 = v_t_24182;
          break;
        }
        case TAG_CDouble: {
          v_t_24185 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str260);
          break;
        }
        case TAG_CBool: {
          v_t_24185 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str261);
          break;
        }
        case TAG_CString: {
          v_t_24185 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str262);
          break;
        }
        case TAG_CText: {
          v_t_24185 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str263);
          break;
        }
        case TAG_COwnedString: {
          v_t_24185 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str264);
          break;
        }
        case TAG_CPointer: {
          V v_t_24183 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24185 = heff_strAppend(v_t_24183, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str265));
          break;
        }
        case TAG_CVoid: {
          v_t_24185 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str266);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24186 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str267), heff_strAppend(v_t_24185, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str268)));
        V v_t_24187 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str269), heff_strAppend(v_tag_240, v_t_24186));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24187});
      }
      case TAG_COwnedString: {
        V v_t_24191;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24188 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24191 = v_t_24188;
          break;
        }
        case TAG_CDouble: {
          v_t_24191 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str270);
          break;
        }
        case TAG_CBool: {
          v_t_24191 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str271);
          break;
        }
        case TAG_CString: {
          v_t_24191 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str272);
          break;
        }
        case TAG_CText: {
          v_t_24191 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str273);
          break;
        }
        case TAG_COwnedString: {
          v_t_24191 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str274);
          break;
        }
        case TAG_CPointer: {
          V v_t_24189 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24191 = heff_strAppend(v_t_24189, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str275));
          break;
        }
        case TAG_CVoid: {
          v_t_24191 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str276);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24192 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str277), heff_strAppend(v_t_24191, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str278)));
        V v_t_24193 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str279), heff_strAppend(v_tag_240, v_t_24192));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24193});
      }
      case TAG_CPointer: {
        V v_t_24199;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24196 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24199 = v_t_24196;
          break;
        }
        case TAG_CDouble: {
          v_t_24199 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str280);
          break;
        }
        case TAG_CBool: {
          v_t_24199 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str281);
          break;
        }
        case TAG_CString: {
          v_t_24199 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str282);
          break;
        }
        case TAG_CText: {
          v_t_24199 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str283);
          break;
        }
        case TAG_COwnedString: {
          v_t_24199 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str284);
          break;
        }
        case TAG_CPointer: {
          V v_t_24197 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24199 = heff_strAppend(v_t_24197, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str285));
          break;
        }
        case TAG_CVoid: {
          v_t_24199 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str286);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24200 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str287), heff_strAppend(v_t_24199, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str288)));
        V v_t_24201 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str289), heff_strAppend(v_tag_240, v_t_24200));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24201});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SIsTy: {
      heff_take_n(v_t_242, 0ULL, 1);
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24207;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24204 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24207 = v_t_24204;
          break;
        }
        case TAG_CDouble: {
          v_t_24207 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str290);
          break;
        }
        case TAG_CBool: {
          v_t_24207 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str291);
          break;
        }
        case TAG_CString: {
          v_t_24207 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str292);
          break;
        }
        case TAG_CText: {
          v_t_24207 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str293);
          break;
        }
        case TAG_COwnedString: {
          v_t_24207 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str294);
          break;
        }
        case TAG_CPointer: {
          V v_t_24205 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24207 = heff_strAppend(v_t_24205, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str295));
          break;
        }
        case TAG_CVoid: {
          v_t_24207 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str296);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24208 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str297), heff_strAppend(v_t_24207, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str298)));
        V v_t_24209 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str299), heff_strAppend(v_tag_240, v_t_24208));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24209});
      }
      case TAG_CDouble: {
        V v_t_24213;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24210 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24213 = v_t_24210;
          break;
        }
        case TAG_CDouble: {
          v_t_24213 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str300);
          break;
        }
        case TAG_CBool: {
          v_t_24213 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str301);
          break;
        }
        case TAG_CString: {
          v_t_24213 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str302);
          break;
        }
        case TAG_CText: {
          v_t_24213 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str303);
          break;
        }
        case TAG_COwnedString: {
          v_t_24213 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str304);
          break;
        }
        case TAG_CPointer: {
          V v_t_24211 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24213 = heff_strAppend(v_t_24211, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str305));
          break;
        }
        case TAG_CVoid: {
          v_t_24213 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str306);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24214 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str307), heff_strAppend(v_t_24213, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str308)));
        V v_t_24215 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str309), heff_strAppend(v_tag_240, v_t_24214));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24215});
      }
      case TAG_CBool: {
        V v_t_24219;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24216 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24219 = v_t_24216;
          break;
        }
        case TAG_CDouble: {
          v_t_24219 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str310);
          break;
        }
        case TAG_CBool: {
          v_t_24219 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str311);
          break;
        }
        case TAG_CString: {
          v_t_24219 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str312);
          break;
        }
        case TAG_CText: {
          v_t_24219 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str313);
          break;
        }
        case TAG_COwnedString: {
          v_t_24219 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str314);
          break;
        }
        case TAG_CPointer: {
          V v_t_24217 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24219 = heff_strAppend(v_t_24217, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str315));
          break;
        }
        case TAG_CVoid: {
          v_t_24219 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str316);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24220 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str317), heff_strAppend(v_t_24219, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str318)));
        V v_t_24221 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str319), heff_strAppend(v_tag_240, v_t_24220));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24221});
      }
      case TAG_CString: {
        V v_t_24225;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24222 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24225 = v_t_24222;
          break;
        }
        case TAG_CDouble: {
          v_t_24225 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str320);
          break;
        }
        case TAG_CBool: {
          v_t_24225 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str321);
          break;
        }
        case TAG_CString: {
          v_t_24225 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str322);
          break;
        }
        case TAG_CText: {
          v_t_24225 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str323);
          break;
        }
        case TAG_COwnedString: {
          v_t_24225 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str324);
          break;
        }
        case TAG_CPointer: {
          V v_t_24223 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24225 = heff_strAppend(v_t_24223, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str325));
          break;
        }
        case TAG_CVoid: {
          v_t_24225 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str326);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24226 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str327), heff_strAppend(v_t_24225, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str328)));
        V v_t_24227 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str329), heff_strAppend(v_tag_240, v_t_24226));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24227});
      }
      case TAG_CText: {
        V v_t_24231;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24228 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24231 = v_t_24228;
          break;
        }
        case TAG_CDouble: {
          v_t_24231 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str330);
          break;
        }
        case TAG_CBool: {
          v_t_24231 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str331);
          break;
        }
        case TAG_CString: {
          v_t_24231 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str332);
          break;
        }
        case TAG_CText: {
          v_t_24231 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str333);
          break;
        }
        case TAG_COwnedString: {
          v_t_24231 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str334);
          break;
        }
        case TAG_CPointer: {
          V v_t_24229 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24231 = heff_strAppend(v_t_24229, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str335));
          break;
        }
        case TAG_CVoid: {
          v_t_24231 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str336);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24232 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str337), heff_strAppend(v_t_24231, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str338)));
        V v_t_24233 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str339), heff_strAppend(v_tag_240, v_t_24232));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24233});
      }
      case TAG_COwnedString: {
        V v_t_24237;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24234 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24237 = v_t_24234;
          break;
        }
        case TAG_CDouble: {
          v_t_24237 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str340);
          break;
        }
        case TAG_CBool: {
          v_t_24237 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str341);
          break;
        }
        case TAG_CString: {
          v_t_24237 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str342);
          break;
        }
        case TAG_CText: {
          v_t_24237 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str343);
          break;
        }
        case TAG_COwnedString: {
          v_t_24237 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str344);
          break;
        }
        case TAG_CPointer: {
          V v_t_24235 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24237 = heff_strAppend(v_t_24235, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str345));
          break;
        }
        case TAG_CVoid: {
          v_t_24237 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str346);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24238 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str347), heff_strAppend(v_t_24237, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str348)));
        V v_t_24239 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str349), heff_strAppend(v_tag_240, v_t_24238));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24239});
      }
      case TAG_CPointer: {
        V v_t_24245;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24242 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24245 = v_t_24242;
          break;
        }
        case TAG_CDouble: {
          v_t_24245 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str350);
          break;
        }
        case TAG_CBool: {
          v_t_24245 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str351);
          break;
        }
        case TAG_CString: {
          v_t_24245 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str352);
          break;
        }
        case TAG_CText: {
          v_t_24245 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str353);
          break;
        }
        case TAG_COwnedString: {
          v_t_24245 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str354);
          break;
        }
        case TAG_CPointer: {
          V v_t_24243 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24245 = heff_strAppend(v_t_24243, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str355));
          break;
        }
        case TAG_CVoid: {
          v_t_24245 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str356);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24246 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str357), heff_strAppend(v_t_24245, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str358)));
        V v_t_24247 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str359), heff_strAppend(v_tag_240, v_t_24246));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24247});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SPrimInt: {
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24252;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24249 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24252 = v_t_24249;
          break;
        }
        case TAG_CDouble: {
          v_t_24252 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str360);
          break;
        }
        case TAG_CBool: {
          v_t_24252 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str361);
          break;
        }
        case TAG_CString: {
          v_t_24252 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str362);
          break;
        }
        case TAG_CText: {
          v_t_24252 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str363);
          break;
        }
        case TAG_COwnedString: {
          v_t_24252 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str364);
          break;
        }
        case TAG_CPointer: {
          V v_t_24250 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24252 = heff_strAppend(v_t_24250, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str365));
          break;
        }
        case TAG_CVoid: {
          v_t_24252 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str366);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24253 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str367), heff_strAppend(v_t_24252, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str368)));
        V v_t_24254 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str369), heff_strAppend(v_tag_240, v_t_24253));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24254});
      }
      case TAG_CDouble: {
        V v_t_24258;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24255 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24258 = v_t_24255;
          break;
        }
        case TAG_CDouble: {
          v_t_24258 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str370);
          break;
        }
        case TAG_CBool: {
          v_t_24258 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str371);
          break;
        }
        case TAG_CString: {
          v_t_24258 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str372);
          break;
        }
        case TAG_CText: {
          v_t_24258 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str373);
          break;
        }
        case TAG_COwnedString: {
          v_t_24258 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str374);
          break;
        }
        case TAG_CPointer: {
          V v_t_24256 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24258 = heff_strAppend(v_t_24256, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str375));
          break;
        }
        case TAG_CVoid: {
          v_t_24258 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str376);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24259 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str377), heff_strAppend(v_t_24258, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str378)));
        V v_t_24260 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str379), heff_strAppend(v_tag_240, v_t_24259));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24260});
      }
      case TAG_CBool: {
        V v_t_24264;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24261 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24264 = v_t_24261;
          break;
        }
        case TAG_CDouble: {
          v_t_24264 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str380);
          break;
        }
        case TAG_CBool: {
          v_t_24264 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str381);
          break;
        }
        case TAG_CString: {
          v_t_24264 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str382);
          break;
        }
        case TAG_CText: {
          v_t_24264 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str383);
          break;
        }
        case TAG_COwnedString: {
          v_t_24264 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str384);
          break;
        }
        case TAG_CPointer: {
          V v_t_24262 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24264 = heff_strAppend(v_t_24262, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str385));
          break;
        }
        case TAG_CVoid: {
          v_t_24264 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str386);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24265 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str387), heff_strAppend(v_t_24264, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str388)));
        V v_t_24266 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str389), heff_strAppend(v_tag_240, v_t_24265));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24266});
      }
      case TAG_CString: {
        V v_t_24270;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24267 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24270 = v_t_24267;
          break;
        }
        case TAG_CDouble: {
          v_t_24270 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str390);
          break;
        }
        case TAG_CBool: {
          v_t_24270 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str391);
          break;
        }
        case TAG_CString: {
          v_t_24270 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str392);
          break;
        }
        case TAG_CText: {
          v_t_24270 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str393);
          break;
        }
        case TAG_COwnedString: {
          v_t_24270 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str394);
          break;
        }
        case TAG_CPointer: {
          V v_t_24268 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24270 = heff_strAppend(v_t_24268, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str395));
          break;
        }
        case TAG_CVoid: {
          v_t_24270 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str396);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24271 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str397), heff_strAppend(v_t_24270, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str398)));
        V v_t_24272 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str399), heff_strAppend(v_tag_240, v_t_24271));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24272});
      }
      case TAG_CText: {
        V v_t_24276;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24273 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24276 = v_t_24273;
          break;
        }
        case TAG_CDouble: {
          v_t_24276 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str400);
          break;
        }
        case TAG_CBool: {
          v_t_24276 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str401);
          break;
        }
        case TAG_CString: {
          v_t_24276 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str402);
          break;
        }
        case TAG_CText: {
          v_t_24276 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str403);
          break;
        }
        case TAG_COwnedString: {
          v_t_24276 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str404);
          break;
        }
        case TAG_CPointer: {
          V v_t_24274 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24276 = heff_strAppend(v_t_24274, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str405));
          break;
        }
        case TAG_CVoid: {
          v_t_24276 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str406);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24277 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str407), heff_strAppend(v_t_24276, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str408)));
        V v_t_24278 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str409), heff_strAppend(v_tag_240, v_t_24277));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24278});
      }
      case TAG_COwnedString: {
        V v_t_24282;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24279 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24282 = v_t_24279;
          break;
        }
        case TAG_CDouble: {
          v_t_24282 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str410);
          break;
        }
        case TAG_CBool: {
          v_t_24282 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str411);
          break;
        }
        case TAG_CString: {
          v_t_24282 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str412);
          break;
        }
        case TAG_CText: {
          v_t_24282 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str413);
          break;
        }
        case TAG_COwnedString: {
          v_t_24282 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str414);
          break;
        }
        case TAG_CPointer: {
          V v_t_24280 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24282 = heff_strAppend(v_t_24280, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str415));
          break;
        }
        case TAG_CVoid: {
          v_t_24282 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str416);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24283 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str417), heff_strAppend(v_t_24282, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str418)));
        V v_t_24284 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str419), heff_strAppend(v_tag_240, v_t_24283));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24284});
      }
      case TAG_CPointer: {
        V v_t_24290;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24287 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24290 = v_t_24287;
          break;
        }
        case TAG_CDouble: {
          v_t_24290 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str420);
          break;
        }
        case TAG_CBool: {
          v_t_24290 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str421);
          break;
        }
        case TAG_CString: {
          v_t_24290 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str422);
          break;
        }
        case TAG_CText: {
          v_t_24290 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str423);
          break;
        }
        case TAG_COwnedString: {
          v_t_24290 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str424);
          break;
        }
        case TAG_CPointer: {
          V v_t_24288 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24290 = heff_strAppend(v_t_24288, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str425));
          break;
        }
        case TAG_CVoid: {
          v_t_24290 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str426);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24291 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str427), heff_strAppend(v_t_24290, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str428)));
        V v_t_24292 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str429), heff_strAppend(v_tag_240, v_t_24291));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24292});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SPrimFloat: {
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24297;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24294 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24297 = v_t_24294;
          break;
        }
        case TAG_CDouble: {
          v_t_24297 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str430);
          break;
        }
        case TAG_CBool: {
          v_t_24297 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str431);
          break;
        }
        case TAG_CString: {
          v_t_24297 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str432);
          break;
        }
        case TAG_CText: {
          v_t_24297 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str433);
          break;
        }
        case TAG_COwnedString: {
          v_t_24297 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str434);
          break;
        }
        case TAG_CPointer: {
          V v_t_24295 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24297 = heff_strAppend(v_t_24295, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str435));
          break;
        }
        case TAG_CVoid: {
          v_t_24297 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str436);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24298 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str437), heff_strAppend(v_t_24297, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str438)));
        V v_t_24299 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str439), heff_strAppend(v_tag_240, v_t_24298));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24299});
      }
      case TAG_CDouble: {
        V v_t_24303;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24300 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24303 = v_t_24300;
          break;
        }
        case TAG_CDouble: {
          v_t_24303 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str440);
          break;
        }
        case TAG_CBool: {
          v_t_24303 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str441);
          break;
        }
        case TAG_CString: {
          v_t_24303 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str442);
          break;
        }
        case TAG_CText: {
          v_t_24303 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str443);
          break;
        }
        case TAG_COwnedString: {
          v_t_24303 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str444);
          break;
        }
        case TAG_CPointer: {
          V v_t_24301 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24303 = heff_strAppend(v_t_24301, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str445));
          break;
        }
        case TAG_CVoid: {
          v_t_24303 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str446);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24304 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str447), heff_strAppend(v_t_24303, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str448)));
        V v_t_24305 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str449), heff_strAppend(v_tag_240, v_t_24304));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24305});
      }
      case TAG_CBool: {
        V v_t_24309;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24306 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24309 = v_t_24306;
          break;
        }
        case TAG_CDouble: {
          v_t_24309 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str450);
          break;
        }
        case TAG_CBool: {
          v_t_24309 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str451);
          break;
        }
        case TAG_CString: {
          v_t_24309 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str452);
          break;
        }
        case TAG_CText: {
          v_t_24309 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str453);
          break;
        }
        case TAG_COwnedString: {
          v_t_24309 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str454);
          break;
        }
        case TAG_CPointer: {
          V v_t_24307 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24309 = heff_strAppend(v_t_24307, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str455));
          break;
        }
        case TAG_CVoid: {
          v_t_24309 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str456);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24310 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str457), heff_strAppend(v_t_24309, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str458)));
        V v_t_24311 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str459), heff_strAppend(v_tag_240, v_t_24310));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24311});
      }
      case TAG_CString: {
        V v_t_24315;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24312 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24315 = v_t_24312;
          break;
        }
        case TAG_CDouble: {
          v_t_24315 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str460);
          break;
        }
        case TAG_CBool: {
          v_t_24315 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str461);
          break;
        }
        case TAG_CString: {
          v_t_24315 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str462);
          break;
        }
        case TAG_CText: {
          v_t_24315 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str463);
          break;
        }
        case TAG_COwnedString: {
          v_t_24315 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str464);
          break;
        }
        case TAG_CPointer: {
          V v_t_24313 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24315 = heff_strAppend(v_t_24313, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str465));
          break;
        }
        case TAG_CVoid: {
          v_t_24315 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str466);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24316 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str467), heff_strAppend(v_t_24315, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str468)));
        V v_t_24317 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str469), heff_strAppend(v_tag_240, v_t_24316));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24317});
      }
      case TAG_CText: {
        V v_t_24321;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24318 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24321 = v_t_24318;
          break;
        }
        case TAG_CDouble: {
          v_t_24321 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str470);
          break;
        }
        case TAG_CBool: {
          v_t_24321 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str471);
          break;
        }
        case TAG_CString: {
          v_t_24321 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str472);
          break;
        }
        case TAG_CText: {
          v_t_24321 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str473);
          break;
        }
        case TAG_COwnedString: {
          v_t_24321 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str474);
          break;
        }
        case TAG_CPointer: {
          V v_t_24319 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24321 = heff_strAppend(v_t_24319, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str475));
          break;
        }
        case TAG_CVoid: {
          v_t_24321 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str476);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24322 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str477), heff_strAppend(v_t_24321, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str478)));
        V v_t_24323 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str479), heff_strAppend(v_tag_240, v_t_24322));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24323});
      }
      case TAG_COwnedString: {
        V v_t_24327;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24324 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24327 = v_t_24324;
          break;
        }
        case TAG_CDouble: {
          v_t_24327 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str480);
          break;
        }
        case TAG_CBool: {
          v_t_24327 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str481);
          break;
        }
        case TAG_CString: {
          v_t_24327 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str482);
          break;
        }
        case TAG_CText: {
          v_t_24327 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str483);
          break;
        }
        case TAG_COwnedString: {
          v_t_24327 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str484);
          break;
        }
        case TAG_CPointer: {
          V v_t_24325 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24327 = heff_strAppend(v_t_24325, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str485));
          break;
        }
        case TAG_CVoid: {
          v_t_24327 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str486);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24328 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str487), heff_strAppend(v_t_24327, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str488)));
        V v_t_24329 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str489), heff_strAppend(v_tag_240, v_t_24328));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24329});
      }
      case TAG_CPointer: {
        V v_t_24335;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24332 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24335 = v_t_24332;
          break;
        }
        case TAG_CDouble: {
          v_t_24335 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str490);
          break;
        }
        case TAG_CBool: {
          v_t_24335 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str491);
          break;
        }
        case TAG_CString: {
          v_t_24335 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str492);
          break;
        }
        case TAG_CText: {
          v_t_24335 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str493);
          break;
        }
        case TAG_COwnedString: {
          v_t_24335 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str494);
          break;
        }
        case TAG_CPointer: {
          V v_t_24333 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24335 = heff_strAppend(v_t_24333, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str495));
          break;
        }
        case TAG_CVoid: {
          v_t_24335 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str496);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24336 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str497), heff_strAppend(v_t_24335, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str498)));
        V v_t_24337 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str499), heff_strAppend(v_tag_240, v_t_24336));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24337});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SPrimString: {
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24342;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24339 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24342 = v_t_24339;
          break;
        }
        case TAG_CDouble: {
          v_t_24342 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str500);
          break;
        }
        case TAG_CBool: {
          v_t_24342 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str501);
          break;
        }
        case TAG_CString: {
          v_t_24342 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str502);
          break;
        }
        case TAG_CText: {
          v_t_24342 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str503);
          break;
        }
        case TAG_COwnedString: {
          v_t_24342 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str504);
          break;
        }
        case TAG_CPointer: {
          V v_t_24340 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24342 = heff_strAppend(v_t_24340, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str505));
          break;
        }
        case TAG_CVoid: {
          v_t_24342 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str506);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24343 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str507), heff_strAppend(v_t_24342, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str508)));
        V v_t_24344 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str509), heff_strAppend(v_tag_240, v_t_24343));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24344});
      }
      case TAG_CDouble: {
        V v_t_24348;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24345 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24348 = v_t_24345;
          break;
        }
        case TAG_CDouble: {
          v_t_24348 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str510);
          break;
        }
        case TAG_CBool: {
          v_t_24348 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str511);
          break;
        }
        case TAG_CString: {
          v_t_24348 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str512);
          break;
        }
        case TAG_CText: {
          v_t_24348 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str513);
          break;
        }
        case TAG_COwnedString: {
          v_t_24348 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str514);
          break;
        }
        case TAG_CPointer: {
          V v_t_24346 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24348 = heff_strAppend(v_t_24346, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str515));
          break;
        }
        case TAG_CVoid: {
          v_t_24348 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str516);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24349 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str517), heff_strAppend(v_t_24348, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str518)));
        V v_t_24350 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str519), heff_strAppend(v_tag_240, v_t_24349));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24350});
      }
      case TAG_CBool: {
        V v_t_24354;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24351 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24354 = v_t_24351;
          break;
        }
        case TAG_CDouble: {
          v_t_24354 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str520);
          break;
        }
        case TAG_CBool: {
          v_t_24354 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str521);
          break;
        }
        case TAG_CString: {
          v_t_24354 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str522);
          break;
        }
        case TAG_CText: {
          v_t_24354 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str523);
          break;
        }
        case TAG_COwnedString: {
          v_t_24354 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str524);
          break;
        }
        case TAG_CPointer: {
          V v_t_24352 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24354 = heff_strAppend(v_t_24352, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str525));
          break;
        }
        case TAG_CVoid: {
          v_t_24354 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str526);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24355 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str527), heff_strAppend(v_t_24354, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str528)));
        V v_t_24356 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str529), heff_strAppend(v_tag_240, v_t_24355));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24356});
      }
      case TAG_CString: {
        V v_t_24360;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24357 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24360 = v_t_24357;
          break;
        }
        case TAG_CDouble: {
          v_t_24360 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str530);
          break;
        }
        case TAG_CBool: {
          v_t_24360 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str531);
          break;
        }
        case TAG_CString: {
          v_t_24360 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str532);
          break;
        }
        case TAG_CText: {
          v_t_24360 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str533);
          break;
        }
        case TAG_COwnedString: {
          v_t_24360 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str534);
          break;
        }
        case TAG_CPointer: {
          V v_t_24358 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24360 = heff_strAppend(v_t_24358, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str535));
          break;
        }
        case TAG_CVoid: {
          v_t_24360 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str536);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24361 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str537), heff_strAppend(v_t_24360, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str538)));
        V v_t_24362 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str539), heff_strAppend(v_tag_240, v_t_24361));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24362});
      }
      case TAG_CText: {
        V v_t_24366;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24363 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24366 = v_t_24363;
          break;
        }
        case TAG_CDouble: {
          v_t_24366 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str540);
          break;
        }
        case TAG_CBool: {
          v_t_24366 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str541);
          break;
        }
        case TAG_CString: {
          v_t_24366 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str542);
          break;
        }
        case TAG_CText: {
          v_t_24366 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str543);
          break;
        }
        case TAG_COwnedString: {
          v_t_24366 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str544);
          break;
        }
        case TAG_CPointer: {
          V v_t_24364 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24366 = heff_strAppend(v_t_24364, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str545));
          break;
        }
        case TAG_CVoid: {
          v_t_24366 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str546);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24367 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str547), heff_strAppend(v_t_24366, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str548)));
        V v_t_24368 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str549), heff_strAppend(v_tag_240, v_t_24367));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24368});
      }
      case TAG_COwnedString: {
        V v_t_24372;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24369 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24372 = v_t_24369;
          break;
        }
        case TAG_CDouble: {
          v_t_24372 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str550);
          break;
        }
        case TAG_CBool: {
          v_t_24372 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str551);
          break;
        }
        case TAG_CString: {
          v_t_24372 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str552);
          break;
        }
        case TAG_CText: {
          v_t_24372 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str553);
          break;
        }
        case TAG_COwnedString: {
          v_t_24372 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str554);
          break;
        }
        case TAG_CPointer: {
          V v_t_24370 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24372 = heff_strAppend(v_t_24370, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str555));
          break;
        }
        case TAG_CVoid: {
          v_t_24372 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str556);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24373 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str557), heff_strAppend(v_t_24372, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str558)));
        V v_t_24374 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str559), heff_strAppend(v_tag_240, v_t_24373));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24374});
      }
      case TAG_CPointer: {
        V v_t_24380;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24377 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24380 = v_t_24377;
          break;
        }
        case TAG_CDouble: {
          v_t_24380 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str560);
          break;
        }
        case TAG_CBool: {
          v_t_24380 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str561);
          break;
        }
        case TAG_CString: {
          v_t_24380 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str562);
          break;
        }
        case TAG_CText: {
          v_t_24380 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str563);
          break;
        }
        case TAG_COwnedString: {
          v_t_24380 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str564);
          break;
        }
        case TAG_CPointer: {
          V v_t_24378 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24380 = heff_strAppend(v_t_24378, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str565));
          break;
        }
        case TAG_CVoid: {
          v_t_24380 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str566);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24381 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str567), heff_strAppend(v_t_24380, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str568)));
        V v_t_24382 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str569), heff_strAppend(v_tag_240, v_t_24381));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24382});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SPrimRune: {
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24387;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24384 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24387 = v_t_24384;
          break;
        }
        case TAG_CDouble: {
          v_t_24387 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str570);
          break;
        }
        case TAG_CBool: {
          v_t_24387 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str571);
          break;
        }
        case TAG_CString: {
          v_t_24387 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str572);
          break;
        }
        case TAG_CText: {
          v_t_24387 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str573);
          break;
        }
        case TAG_COwnedString: {
          v_t_24387 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str574);
          break;
        }
        case TAG_CPointer: {
          V v_t_24385 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24387 = heff_strAppend(v_t_24385, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str575));
          break;
        }
        case TAG_CVoid: {
          v_t_24387 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str576);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24388 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str577), heff_strAppend(v_t_24387, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str578)));
        V v_t_24389 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str579), heff_strAppend(v_tag_240, v_t_24388));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24389});
      }
      case TAG_CDouble: {
        V v_t_24393;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24390 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24393 = v_t_24390;
          break;
        }
        case TAG_CDouble: {
          v_t_24393 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str580);
          break;
        }
        case TAG_CBool: {
          v_t_24393 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str581);
          break;
        }
        case TAG_CString: {
          v_t_24393 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str582);
          break;
        }
        case TAG_CText: {
          v_t_24393 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str583);
          break;
        }
        case TAG_COwnedString: {
          v_t_24393 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str584);
          break;
        }
        case TAG_CPointer: {
          V v_t_24391 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24393 = heff_strAppend(v_t_24391, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str585));
          break;
        }
        case TAG_CVoid: {
          v_t_24393 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str586);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24394 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str587), heff_strAppend(v_t_24393, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str588)));
        V v_t_24395 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str589), heff_strAppend(v_tag_240, v_t_24394));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24395});
      }
      case TAG_CBool: {
        V v_t_24399;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24396 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24399 = v_t_24396;
          break;
        }
        case TAG_CDouble: {
          v_t_24399 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str590);
          break;
        }
        case TAG_CBool: {
          v_t_24399 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str591);
          break;
        }
        case TAG_CString: {
          v_t_24399 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str592);
          break;
        }
        case TAG_CText: {
          v_t_24399 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str593);
          break;
        }
        case TAG_COwnedString: {
          v_t_24399 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str594);
          break;
        }
        case TAG_CPointer: {
          V v_t_24397 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24399 = heff_strAppend(v_t_24397, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str595));
          break;
        }
        case TAG_CVoid: {
          v_t_24399 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str596);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24400 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str597), heff_strAppend(v_t_24399, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str598)));
        V v_t_24401 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str599), heff_strAppend(v_tag_240, v_t_24400));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24401});
      }
      case TAG_CString: {
        V v_t_24405;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24402 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24405 = v_t_24402;
          break;
        }
        case TAG_CDouble: {
          v_t_24405 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str600);
          break;
        }
        case TAG_CBool: {
          v_t_24405 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str601);
          break;
        }
        case TAG_CString: {
          v_t_24405 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str602);
          break;
        }
        case TAG_CText: {
          v_t_24405 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str603);
          break;
        }
        case TAG_COwnedString: {
          v_t_24405 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str604);
          break;
        }
        case TAG_CPointer: {
          V v_t_24403 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24405 = heff_strAppend(v_t_24403, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str605));
          break;
        }
        case TAG_CVoid: {
          v_t_24405 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str606);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24406 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str607), heff_strAppend(v_t_24405, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str608)));
        V v_t_24407 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str609), heff_strAppend(v_tag_240, v_t_24406));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24407});
      }
      case TAG_CText: {
        V v_t_24411;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24408 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24411 = v_t_24408;
          break;
        }
        case TAG_CDouble: {
          v_t_24411 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str610);
          break;
        }
        case TAG_CBool: {
          v_t_24411 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str611);
          break;
        }
        case TAG_CString: {
          v_t_24411 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str612);
          break;
        }
        case TAG_CText: {
          v_t_24411 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str613);
          break;
        }
        case TAG_COwnedString: {
          v_t_24411 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str614);
          break;
        }
        case TAG_CPointer: {
          V v_t_24409 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24411 = heff_strAppend(v_t_24409, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str615));
          break;
        }
        case TAG_CVoid: {
          v_t_24411 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str616);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24412 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str617), heff_strAppend(v_t_24411, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str618)));
        V v_t_24413 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str619), heff_strAppend(v_tag_240, v_t_24412));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24413});
      }
      case TAG_COwnedString: {
        V v_t_24417;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24414 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24417 = v_t_24414;
          break;
        }
        case TAG_CDouble: {
          v_t_24417 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str620);
          break;
        }
        case TAG_CBool: {
          v_t_24417 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str621);
          break;
        }
        case TAG_CString: {
          v_t_24417 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str622);
          break;
        }
        case TAG_CText: {
          v_t_24417 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str623);
          break;
        }
        case TAG_COwnedString: {
          v_t_24417 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str624);
          break;
        }
        case TAG_CPointer: {
          V v_t_24415 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24417 = heff_strAppend(v_t_24415, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str625));
          break;
        }
        case TAG_CVoid: {
          v_t_24417 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str626);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24418 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str627), heff_strAppend(v_t_24417, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str628)));
        V v_t_24419 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str629), heff_strAppend(v_tag_240, v_t_24418));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24419});
      }
      case TAG_CPointer: {
        V v_t_24425;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24422 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24425 = v_t_24422;
          break;
        }
        case TAG_CDouble: {
          v_t_24425 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str630);
          break;
        }
        case TAG_CBool: {
          v_t_24425 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str631);
          break;
        }
        case TAG_CString: {
          v_t_24425 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str632);
          break;
        }
        case TAG_CText: {
          v_t_24425 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str633);
          break;
        }
        case TAG_COwnedString: {
          v_t_24425 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str634);
          break;
        }
        case TAG_CPointer: {
          V v_t_24423 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24425 = heff_strAppend(v_t_24423, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str635));
          break;
        }
        case TAG_CVoid: {
          v_t_24425 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str636);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24426 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str637), heff_strAppend(v_t_24425, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str638)));
        V v_t_24427 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str639), heff_strAppend(v_tag_240, v_t_24426));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24427});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SPrimArray: {
      heff_take_n(v_t_242, 0ULL, 1);
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24433;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24430 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24433 = v_t_24430;
          break;
        }
        case TAG_CDouble: {
          v_t_24433 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str640);
          break;
        }
        case TAG_CBool: {
          v_t_24433 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str641);
          break;
        }
        case TAG_CString: {
          v_t_24433 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str642);
          break;
        }
        case TAG_CText: {
          v_t_24433 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str643);
          break;
        }
        case TAG_COwnedString: {
          v_t_24433 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str644);
          break;
        }
        case TAG_CPointer: {
          V v_t_24431 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24433 = heff_strAppend(v_t_24431, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str645));
          break;
        }
        case TAG_CVoid: {
          v_t_24433 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str646);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24434 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str647), heff_strAppend(v_t_24433, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str648)));
        V v_t_24435 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str649), heff_strAppend(v_tag_240, v_t_24434));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24435});
      }
      case TAG_CDouble: {
        V v_t_24439;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24436 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24439 = v_t_24436;
          break;
        }
        case TAG_CDouble: {
          v_t_24439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str650);
          break;
        }
        case TAG_CBool: {
          v_t_24439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str651);
          break;
        }
        case TAG_CString: {
          v_t_24439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str652);
          break;
        }
        case TAG_CText: {
          v_t_24439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str653);
          break;
        }
        case TAG_COwnedString: {
          v_t_24439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str654);
          break;
        }
        case TAG_CPointer: {
          V v_t_24437 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24439 = heff_strAppend(v_t_24437, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str655));
          break;
        }
        case TAG_CVoid: {
          v_t_24439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str656);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24440 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str657), heff_strAppend(v_t_24439, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str658)));
        V v_t_24441 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str659), heff_strAppend(v_tag_240, v_t_24440));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24441});
      }
      case TAG_CBool: {
        V v_t_24445;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24442 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24445 = v_t_24442;
          break;
        }
        case TAG_CDouble: {
          v_t_24445 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str660);
          break;
        }
        case TAG_CBool: {
          v_t_24445 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str661);
          break;
        }
        case TAG_CString: {
          v_t_24445 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str662);
          break;
        }
        case TAG_CText: {
          v_t_24445 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str663);
          break;
        }
        case TAG_COwnedString: {
          v_t_24445 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str664);
          break;
        }
        case TAG_CPointer: {
          V v_t_24443 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24445 = heff_strAppend(v_t_24443, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str665));
          break;
        }
        case TAG_CVoid: {
          v_t_24445 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str666);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24446 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str667), heff_strAppend(v_t_24445, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str668)));
        V v_t_24447 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str669), heff_strAppend(v_tag_240, v_t_24446));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24447});
      }
      case TAG_CString: {
        V v_t_24451;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24448 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24451 = v_t_24448;
          break;
        }
        case TAG_CDouble: {
          v_t_24451 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str670);
          break;
        }
        case TAG_CBool: {
          v_t_24451 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str671);
          break;
        }
        case TAG_CString: {
          v_t_24451 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str672);
          break;
        }
        case TAG_CText: {
          v_t_24451 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str673);
          break;
        }
        case TAG_COwnedString: {
          v_t_24451 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str674);
          break;
        }
        case TAG_CPointer: {
          V v_t_24449 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24451 = heff_strAppend(v_t_24449, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str675));
          break;
        }
        case TAG_CVoid: {
          v_t_24451 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str676);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24452 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str677), heff_strAppend(v_t_24451, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str678)));
        V v_t_24453 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str679), heff_strAppend(v_tag_240, v_t_24452));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24453});
      }
      case TAG_CText: {
        V v_t_24457;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24454 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24457 = v_t_24454;
          break;
        }
        case TAG_CDouble: {
          v_t_24457 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str680);
          break;
        }
        case TAG_CBool: {
          v_t_24457 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str681);
          break;
        }
        case TAG_CString: {
          v_t_24457 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str682);
          break;
        }
        case TAG_CText: {
          v_t_24457 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str683);
          break;
        }
        case TAG_COwnedString: {
          v_t_24457 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str684);
          break;
        }
        case TAG_CPointer: {
          V v_t_24455 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24457 = heff_strAppend(v_t_24455, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str685));
          break;
        }
        case TAG_CVoid: {
          v_t_24457 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str686);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24458 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str687), heff_strAppend(v_t_24457, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str688)));
        V v_t_24459 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str689), heff_strAppend(v_tag_240, v_t_24458));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24459});
      }
      case TAG_COwnedString: {
        V v_t_24463;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24460 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24463 = v_t_24460;
          break;
        }
        case TAG_CDouble: {
          v_t_24463 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str690);
          break;
        }
        case TAG_CBool: {
          v_t_24463 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str691);
          break;
        }
        case TAG_CString: {
          v_t_24463 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str692);
          break;
        }
        case TAG_CText: {
          v_t_24463 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str693);
          break;
        }
        case TAG_COwnedString: {
          v_t_24463 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str694);
          break;
        }
        case TAG_CPointer: {
          V v_t_24461 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24463 = heff_strAppend(v_t_24461, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str695));
          break;
        }
        case TAG_CVoid: {
          v_t_24463 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str696);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24464 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str697), heff_strAppend(v_t_24463, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str698)));
        V v_t_24465 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str699), heff_strAppend(v_tag_240, v_t_24464));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24465});
      }
      case TAG_CPointer: {
        V v_t_24471;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24468 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24471 = v_t_24468;
          break;
        }
        case TAG_CDouble: {
          v_t_24471 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str700);
          break;
        }
        case TAG_CBool: {
          v_t_24471 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str701);
          break;
        }
        case TAG_CString: {
          v_t_24471 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str702);
          break;
        }
        case TAG_CText: {
          v_t_24471 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str703);
          break;
        }
        case TAG_COwnedString: {
          v_t_24471 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str704);
          break;
        }
        case TAG_CPointer: {
          V v_t_24469 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24471 = heff_strAppend(v_t_24469, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str705));
          break;
        }
        case TAG_CVoid: {
          v_t_24471 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str706);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24472 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str707), heff_strAppend(v_t_24471, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str708)));
        V v_t_24473 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str709), heff_strAppend(v_tag_240, v_t_24472));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24473});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SFixed: {
      heff_take_n(v_t_242, 0ULL, 1);
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24479;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24476 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24479 = v_t_24476;
          break;
        }
        case TAG_CDouble: {
          v_t_24479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str710);
          break;
        }
        case TAG_CBool: {
          v_t_24479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str711);
          break;
        }
        case TAG_CString: {
          v_t_24479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str712);
          break;
        }
        case TAG_CText: {
          v_t_24479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str713);
          break;
        }
        case TAG_COwnedString: {
          v_t_24479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str714);
          break;
        }
        case TAG_CPointer: {
          V v_t_24477 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24479 = heff_strAppend(v_t_24477, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str715));
          break;
        }
        case TAG_CVoid: {
          v_t_24479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str716);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24480 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str717), heff_strAppend(v_t_24479, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str718)));
        V v_t_24481 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str719), heff_strAppend(v_tag_240, v_t_24480));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24481});
      }
      case TAG_CDouble: {
        V v_t_24485;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24482 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24485 = v_t_24482;
          break;
        }
        case TAG_CDouble: {
          v_t_24485 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str720);
          break;
        }
        case TAG_CBool: {
          v_t_24485 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str721);
          break;
        }
        case TAG_CString: {
          v_t_24485 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str722);
          break;
        }
        case TAG_CText: {
          v_t_24485 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str723);
          break;
        }
        case TAG_COwnedString: {
          v_t_24485 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str724);
          break;
        }
        case TAG_CPointer: {
          V v_t_24483 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24485 = heff_strAppend(v_t_24483, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str725));
          break;
        }
        case TAG_CVoid: {
          v_t_24485 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str726);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24486 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str727), heff_strAppend(v_t_24485, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str728)));
        V v_t_24487 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str729), heff_strAppend(v_tag_240, v_t_24486));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24487});
      }
      case TAG_CBool: {
        V v_t_24491;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24488 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24491 = v_t_24488;
          break;
        }
        case TAG_CDouble: {
          v_t_24491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str730);
          break;
        }
        case TAG_CBool: {
          v_t_24491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str731);
          break;
        }
        case TAG_CString: {
          v_t_24491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str732);
          break;
        }
        case TAG_CText: {
          v_t_24491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str733);
          break;
        }
        case TAG_COwnedString: {
          v_t_24491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str734);
          break;
        }
        case TAG_CPointer: {
          V v_t_24489 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24491 = heff_strAppend(v_t_24489, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str735));
          break;
        }
        case TAG_CVoid: {
          v_t_24491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str736);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24492 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str737), heff_strAppend(v_t_24491, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str738)));
        V v_t_24493 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str739), heff_strAppend(v_tag_240, v_t_24492));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24493});
      }
      case TAG_CString: {
        V v_t_24497;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24494 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24497 = v_t_24494;
          break;
        }
        case TAG_CDouble: {
          v_t_24497 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str740);
          break;
        }
        case TAG_CBool: {
          v_t_24497 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str741);
          break;
        }
        case TAG_CString: {
          v_t_24497 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str742);
          break;
        }
        case TAG_CText: {
          v_t_24497 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str743);
          break;
        }
        case TAG_COwnedString: {
          v_t_24497 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str744);
          break;
        }
        case TAG_CPointer: {
          V v_t_24495 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24497 = heff_strAppend(v_t_24495, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str745));
          break;
        }
        case TAG_CVoid: {
          v_t_24497 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str746);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24498 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str747), heff_strAppend(v_t_24497, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str748)));
        V v_t_24499 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str749), heff_strAppend(v_tag_240, v_t_24498));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24499});
      }
      case TAG_CText: {
        V v_t_24503;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24500 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24503 = v_t_24500;
          break;
        }
        case TAG_CDouble: {
          v_t_24503 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str750);
          break;
        }
        case TAG_CBool: {
          v_t_24503 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str751);
          break;
        }
        case TAG_CString: {
          v_t_24503 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str752);
          break;
        }
        case TAG_CText: {
          v_t_24503 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str753);
          break;
        }
        case TAG_COwnedString: {
          v_t_24503 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str754);
          break;
        }
        case TAG_CPointer: {
          V v_t_24501 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24503 = heff_strAppend(v_t_24501, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str755));
          break;
        }
        case TAG_CVoid: {
          v_t_24503 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str756);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24504 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str757), heff_strAppend(v_t_24503, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str758)));
        V v_t_24505 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str759), heff_strAppend(v_tag_240, v_t_24504));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24505});
      }
      case TAG_COwnedString: {
        V v_t_24509;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24506 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24509 = v_t_24506;
          break;
        }
        case TAG_CDouble: {
          v_t_24509 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str760);
          break;
        }
        case TAG_CBool: {
          v_t_24509 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str761);
          break;
        }
        case TAG_CString: {
          v_t_24509 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str762);
          break;
        }
        case TAG_CText: {
          v_t_24509 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str763);
          break;
        }
        case TAG_COwnedString: {
          v_t_24509 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str764);
          break;
        }
        case TAG_CPointer: {
          V v_t_24507 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24509 = heff_strAppend(v_t_24507, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str765));
          break;
        }
        case TAG_CVoid: {
          v_t_24509 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str766);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24510 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str767), heff_strAppend(v_t_24509, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str768)));
        V v_t_24511 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str769), heff_strAppend(v_tag_240, v_t_24510));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24511});
      }
      case TAG_CPointer: {
        V v_t_24517;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24514 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24517 = v_t_24514;
          break;
        }
        case TAG_CDouble: {
          v_t_24517 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str770);
          break;
        }
        case TAG_CBool: {
          v_t_24517 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str771);
          break;
        }
        case TAG_CString: {
          v_t_24517 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str772);
          break;
        }
        case TAG_CText: {
          v_t_24517 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str773);
          break;
        }
        case TAG_COwnedString: {
          v_t_24517 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str774);
          break;
        }
        case TAG_CPointer: {
          V v_t_24515 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24517 = heff_strAppend(v_t_24515, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str775));
          break;
        }
        case TAG_CVoid: {
          v_t_24517 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str776);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24518 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str777), heff_strAppend(v_t_24517, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str778)));
        V v_t_24519 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str779), heff_strAppend(v_tag_240, v_t_24518));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24519});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_GivesOrErrno: {
    V v_c_24520 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24GivesOrErrno = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_SU: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_c_24520);
      V v_t_24522 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str780), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str781)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24522});
    }
    case TAG_SDecode: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_c_24520);
      V v_t_24524 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str782), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str783)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24524});
    }
    case TAG_SFunction: {
      V v_dom_24526 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 5);
      V v_t_24533;
      switch (heff_tag_of(v_c_24520)) {
      case TAG_CInteger: {
        v_t_24533 = NTAG(TAG_False);
        break;
      }
      case TAG_CDouble: {
        v_t_24533 = NTAG(TAG_True);
        break;
      }
      case TAG_CBool: {
        v_t_24533 = NTAG(TAG_True);
        break;
      }
      case TAG_CString: {
        v_t_24533 = NTAG(TAG_False);
        break;
      }
      case TAG_CText: {
        v_t_24533 = NTAG(TAG_False);
        break;
      }
      case TAG_COwnedString: {
        v_t_24533 = NTAG(TAG_False);
        break;
      }
      case TAG_CPointer: {
        v_t_24533 = NTAG(TAG_False);
        break;
      }
      case TAG_CVoid: {
        v_t_24533 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_c_24520);
      }
      if ((heff_dup(v_t_24533) == NTAG(TAG_True))) {
        heff_drop(v_dom_24526);
        heff_drop(v_t_24533);
        V v_t_24537;
        switch (heff_tag_of(v_c_24520)) {
        case TAG_CInteger: {
          V v_t_24534 = heff_field(v_c_24520, 0);
          heff_take_n(v_c_24520, 1ULL, 1);
          v_t_24537 = v_t_24534;
          break;
        }
        case TAG_CDouble: {
          v_t_24537 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str784);
          break;
        }
        case TAG_CBool: {
          v_t_24537 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str785);
          break;
        }
        case TAG_CString: {
          v_t_24537 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str786);
          break;
        }
        case TAG_CText: {
          v_t_24537 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str787);
          break;
        }
        case TAG_COwnedString: {
          v_t_24537 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str788);
          break;
        }
        case TAG_CPointer: {
          V v_t_24535 = heff_field(v_c_24520, 0);
          heff_take_n(v_c_24520, 1ULL, 2);
          v_t_24537 = heff_strAppend(v_t_24535, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str789));
          break;
        }
        case TAG_CVoid: {
          v_t_24537 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str790);
          break;
        }
        default: heff_nomatch(v_c_24520);
        }
        V v_t_24538 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str791), heff_strAppend(v_t_24537, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str792)));
        V v_t_24539 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str793), heff_strAppend(v_tag_240, v_t_24538));
        return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24539});
      } else {
        heff_drop(v_t_24533);
        HeffT2 v_t_24540 = (g_heff_2ecompile_2eglue_2erightOf_24cpr(v_dom_24526));
        {
          V v_field_24542 = v_t_24540.f[1];
          int64_t v_tag_24541 = ((int64_t)v_t_24540.f[0]);
          if ((v_tag_24541 == ((int64_t)0ULL))) {
            V v_r_24544 = v_field_24542;
            V v_t_24545 = (g_heff_2ecompile_2eglue_2efits(heff_dup(v_c_24520), v_r_24544));
            if ((heff_dup(v_t_24545) == NTAG(TAG_True))) {
              heff_drop(v_tag_240);
              heff_drop(v_c_24520);
              heff_drop_cell(v_ru_24x2_241_24GivesOrErrno, 1);
              heff_drop(v_t_24545);
              return NTAG(TAG_Nothing);
            } else {
              heff_drop(v_t_24545);
              V v_t_24549;
              switch (heff_tag_of(v_c_24520)) {
              case TAG_CInteger: {
                V v_t_24546 = heff_field(v_c_24520, 0);
                heff_take_n(v_c_24520, 1ULL, 1);
                v_t_24549 = v_t_24546;
                break;
              }
              case TAG_CDouble: {
                v_t_24549 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str794);
                break;
              }
              case TAG_CBool: {
                v_t_24549 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str795);
                break;
              }
              case TAG_CString: {
                v_t_24549 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str796);
                break;
              }
              case TAG_CText: {
                v_t_24549 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str797);
                break;
              }
              case TAG_COwnedString: {
                v_t_24549 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str798);
                break;
              }
              case TAG_CPointer: {
                V v_t_24547 = heff_field(v_c_24520, 0);
                heff_take_n(v_c_24520, 1ULL, 2);
                v_t_24549 = heff_strAppend(v_t_24547, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str799));
                break;
              }
              case TAG_CVoid: {
                v_t_24549 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str800);
                break;
              }
              default: heff_nomatch(v_c_24520);
              }
              V v_t_24550 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str801), heff_strAppend(v_t_24549, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str802)));
              V v_t_24551 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str803), heff_strAppend(v_tag_240, v_t_24550));
              return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24551});
            }
          } else {
            heff_drop(v_c_24520);
            heff_drop(v_field_24542);
            V v_t_24552 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str804), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str805)));
            return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24552});
          }
        }
      }
    }
    case TAG_SRecord: {
      heff_take_n(v_t_242, 0ULL, 3);
      heff_drop(v_c_24520);
      V v_t_24556 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str806), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str807)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24556});
    }
    case TAG_SSum: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_c_24520);
      V v_t_24558 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str808), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str809)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24558});
    }
    case TAG_SIsTy: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_c_24520);
      V v_t_24560 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str810), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str811)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24560});
    }
    case TAG_SPrimInt: {
      heff_drop(v_c_24520);
      V v_t_24561 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str812), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str813)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24561});
    }
    case TAG_SPrimFloat: {
      heff_drop(v_c_24520);
      V v_t_24562 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str814), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str815)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24562});
    }
    case TAG_SPrimString: {
      heff_drop(v_c_24520);
      V v_t_24563 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str816), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str817)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24563});
    }
    case TAG_SPrimRune: {
      heff_drop(v_c_24520);
      V v_t_24564 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str818), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str819)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24564});
    }
    case TAG_SPrimArray: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_c_24520);
      V v_t_24566 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str820), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str821)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24566});
    }
    case TAG_SFixed: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_c_24520);
      V v_t_24568 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str822), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str823)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24568});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_DoneOrErrno: {
    switch (heff_tag_of(v_t_242)) {
    case TAG_SU: {
      V v_ru_24t_242_24SU = heff_take_reuse_n(v_t_242, 0ULL, 1);
      V v_t_24570 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str824), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str825)));
      return heff_tag_at_n(v_ru_24t_242_24SU, TAG_Just, 1, (V[]){v_t_24570});
    }
    case TAG_SDecode: {
      V v_ru_24t_242_24SDecode = heff_take_reuse_n(v_t_242, 0ULL, 1);
      V v_t_24572 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str826), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str827)));
      return heff_tag_at_n(v_ru_24t_242_24SDecode, TAG_Just, 1, (V[]){v_t_24572});
    }
    case TAG_SFunction: {
      V v_dom_24574 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 5);
      HeffT2 v_t_24578 = (g_heff_2ecompile_2eglue_2erightOf_24cpr(v_dom_24574));
      {
        V v_field_24580 = v_t_24578.f[1];
        int64_t v_tag_24579 = ((int64_t)v_t_24578.f[0]);
        if ((v_tag_24579 == ((int64_t)0ULL))) {
          heff_drop(v_tag_240);
          V v_r_24582 = v_field_24580;
          heff_drop(v_r_24582);
          return NTAG(TAG_Nothing);
        } else {
          heff_drop(v_field_24580);
          V v_t_24583 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str828), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str829)));
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_24583});
        }
      }
    }
    case TAG_SRecord: {
      heff_take_n(v_t_242, 0ULL, 3);
      V v_t_24587 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str830), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str831)));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24587});
    }
    case TAG_SSum: {
      V v_ru_24t_242_24SSum = heff_take_reuse_n(v_t_242, 0ULL, 1);
      V v_t_24589 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str832), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str833)));
      return heff_tag_at_n(v_ru_24t_242_24SSum, TAG_Just, 1, (V[]){v_t_24589});
    }
    case TAG_SIsTy: {
      V v_ru_24t_242_24SIsTy = heff_take_reuse_n(v_t_242, 0ULL, 1);
      V v_t_24591 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str834), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str835)));
      return heff_tag_at_n(v_ru_24t_242_24SIsTy, TAG_Just, 1, (V[]){v_t_24591});
    }
    case TAG_SPrimInt: {
      V v_t_24592 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str836), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str837)));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24592});
    }
    case TAG_SPrimFloat: {
      V v_t_24593 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str838), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str839)));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24593});
    }
    case TAG_SPrimString: {
      V v_t_24594 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str840), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str841)));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24594});
    }
    case TAG_SPrimRune: {
      V v_t_24595 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str842), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str843)));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24595});
    }
    case TAG_SPrimArray: {
      V v_ru_24t_242_24SPrimArray = heff_take_reuse_n(v_t_242, 0ULL, 1);
      V v_t_24597 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str844), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str845)));
      return heff_tag_at_n(v_ru_24t_242_24SPrimArray, TAG_Just, 1, (V[]){v_t_24597});
    }
    case TAG_SFixed: {
      V v_ru_24t_242_24SFixed = heff_take_reuse_n(v_t_242, 0ULL, 1);
      V v_t_24599 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str846), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str847)));
      return heff_tag_at_n(v_ru_24t_242_24SFixed, TAG_Just, 1, (V[]){v_t_24599});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eglue_2eresultBad_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2eresultBad(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str0, 13, "ffi.Described");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str2, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str3, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str4, 36, "` is not a description heff can read");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str5, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str6, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str7, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str8, 24, "` could not be evaluated");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str9, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str10, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str11, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str12, 24, "` could not be evaluated");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str13, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str14, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str15, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str16, 24, "` could not be evaluated");
V g_heff_2ecompile_2eglue_2edescribedIn_lam0(V self, V *args); static Clo g_heff_2ecompile_2eglue_2edescribedIn_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2edescribedIn_lam0, 2, 0};
Clo g_heff_2ecompile_2eglue_2edescribedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2edescribedIn_entry, 2, 0};

V g_heff_2ecompile_2eglue_2edescribedIn(V v_g_240, V v_m_241) {
top: ;
  V v_it_242 = ({ V a_0 = heff_dup(v_g_240); V a_1 = v_m_241; V b_2 = ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str0); V r_ = (g_heff_2ecompile_2eglue_2eofType(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Right, 1, (V[]){v_t_243});
  }
  case TAG_Cons: {
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_247 = (g_heff_2ecompile_2einterp_2ereachGlobals(heff_dup(v_g_240), heff_dup(g_std_2emap_2eempty_get()), heff_dup(v_it_242)));
    V v_t_248 = ({ V a_0 = v_it_242; V a_1 = v_t_247; V a_2 = v_g_240; V r_ = (g_heff_2ecompile_2einterp_2eevalReachedIn(a_0, a_1, a_2)); heff_drop_tag(v_it_242, 2); heff_drop(v_t_247); r_; });
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2edescribedIn_lam0_clo); V a_1 = heff_tag_n(TAG_Right, 1, (V[]){v_t_246}); V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2ecompile_2eglue_2edescribedIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eglue_2edescribedIn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eglue_2edescribedIn_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_p_2410 = args[1];
  switch (heff_tag_of(v_acc_249)) {
  case TAG_Left: {
    V v_why_2411 = heff_field(v_acc_249, 0);
    V v_ru_24acc_249_24Left = heff_take_reuse_n(v_acc_249, 1ULL, 1);
    heff_drop(v_p_2410);
    return heff_tag_at_n(v_ru_24acc_249_24Left, TAG_Left, 1, (V[]){v_why_2411});
  }
  case TAG_Right: {
    V v_it1_2412 = heff_field(v_acc_249, 0);
    V v_ru_24acc_249_24Right = heff_take_reuse_n(v_acc_249, 1ULL, 1);
    switch (heff_tag_of(v_it1_2412)) {
    case TAG_MkPair: {
      V v_incs_2413 = heff_field(v_it1_2412, 0);
      V v_ops_2414 = heff_field(v_it1_2412, 1);
      heff_take_n(v_it1_2412, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_p_2410)) {
      case TAG_MkPair: {
        V v_y_2416 = heff_dup(heff_field(v_p_2410, 1));
        v_t_2417 = v_y_2416;
        break;
      }
      default: heff_nomatch(v_p_2410);
      }
      switch (heff_tag_of(v_t_2417)) {
      case TAG_RSucceeded: {
        V v_v_2418 = heff_field(v_t_2417, 0);
        V v_ru_24t_2417_24RSucceeded = heff_take_reuse_n(v_t_2417, 1ULL, 1);
        HeffT2 v_t_2419 = (g_heff_2ecompile_2eglue_2ereadDescribed_24cpr(v_v_2418));
        {
          V v_field_2421 = v_t_2419.f[1];
          int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
          if ((v_tag_2420 == ((int64_t)0ULL))) {
            heff_drop(v_p_2410);
            heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
            V v_it1_2423 = v_field_2421;
            switch (heff_tag_of(v_it1_2423)) {
            case TAG_MkPair: {
              V v_is_2424 = heff_field(v_it1_2423, 0);
              V v_os_2425 = heff_field(v_it1_2423, 1);
              heff_take_n(v_it1_2423, 3ULL, 2);
              V v_t_2426 = (g_heff_2ecompile_2eglue_2eappendF(v_incs_2413, v_is_2424));
              V v_t_2427 = (g_heff_2ecompile_2eglue_2eappendF(v_ops_2414, v_os_2425));
              return heff_tag_at_n(v_ru_24acc_249_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_t_2427})});
            }
            default: return heff_nomatch(v_it1_2423);
            }
          } else {
            heff_drop_cell(v_ru_24acc_249_24Right, 1);
            heff_drop(v_incs_2413);
            heff_drop(v_ops_2414);
            heff_drop(v_field_2421);
            V v_k_2430;
            switch (heff_tag_of(v_p_2410)) {
            case TAG_MkPair: {
              V v_x_2428 = heff_field(v_p_2410, 0);
              heff_take_n(v_p_2410, 1ULL, 2);
              v_k_2430 = v_x_2428;
              break;
            }
            default: heff_nomatch(v_p_2410);
            }
            V v_t_2431 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str1); V a_1 = v_k_2430; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str2), v_k_2430, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
            V v_t_2432 = ({ V a_0 = v_k_2430; V a_1 = v_t_2431; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2431); r_; });
            V v_t_2433 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str3), heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str4)));
            return heff_tag_at_n(v_ru_24t_2417_24RSucceeded, TAG_Left, 1, (V[]){v_t_2433});
          }
        }
      }
      case TAG_RAbandoned: {
        heff_drop_cell(v_ru_24acc_249_24Right, 1);
        heff_drop(v_incs_2413);
        heff_drop(v_ops_2414);
        V v_k_2436;
        switch (heff_tag_of(v_p_2410)) {
        case TAG_MkPair: {
          V v_x_2434 = heff_field(v_p_2410, 0);
          heff_take_n(v_p_2410, 1ULL, 2);
          v_k_2436 = v_x_2434;
          break;
        }
        default: heff_nomatch(v_p_2410);
        }
        V v_t_2437 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str5); V a_1 = v_k_2436; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str6), v_k_2436, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_t_2438 = ({ V a_0 = v_k_2436; V a_1 = v_t_2437; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2437); r_; });
        V v_t_2439 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str7), heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str8)));
        return heff_tag_n(TAG_Left, 1, (V[]){v_t_2439});
      }
      case TAG_RDiverged: {
        heff_drop_cell(v_ru_24acc_249_24Right, 1);
        heff_drop(v_incs_2413);
        heff_drop(v_ops_2414);
        V v_k_2442;
        switch (heff_tag_of(v_p_2410)) {
        case TAG_MkPair: {
          V v_x_2440 = heff_field(v_p_2410, 0);
          heff_take_n(v_p_2410, 1ULL, 2);
          v_k_2442 = v_x_2440;
          break;
        }
        default: heff_nomatch(v_p_2410);
        }
        V v_t_2443 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str9); V a_1 = v_k_2442; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str10), v_k_2442, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_t_2444 = ({ V a_0 = v_k_2442; V a_1 = v_t_2443; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2443); r_; });
        V v_t_2445 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str11), heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str12)));
        return heff_tag_n(TAG_Left, 1, (V[]){v_t_2445});
      }
      case TAG_RBug: {
        V v_ru_24t_2417_24RBug = heff_take_reuse_n(v_t_2417, 0ULL, 1);
        heff_drop_cell(v_ru_24acc_249_24Right, 1);
        heff_drop(v_incs_2413);
        heff_drop(v_ops_2414);
        V v_k_2449;
        switch (heff_tag_of(v_p_2410)) {
        case TAG_MkPair: {
          V v_x_2447 = heff_field(v_p_2410, 0);
          heff_take_n(v_p_2410, 1ULL, 2);
          v_k_2449 = v_x_2447;
          break;
        }
        default: heff_nomatch(v_p_2410);
        }
        V v_t_2450 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str13); V a_1 = v_k_2449; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str14), v_k_2449, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_t_2451 = ({ V a_0 = v_k_2449; V a_1 = v_t_2450; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2450); r_; });
        V v_t_2452 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str15), heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str16)));
        return heff_tag_at_n(v_ru_24t_2417_24RBug, TAG_Left, 1, (V[]){v_t_2452});
      }
      default: return heff_nomatch(v_t_2417);
      }
    }
    default: return heff_nomatch(v_it1_2412);
    }
  }
  default: return heff_nomatch(v_acc_249);
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str3, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str4, 11, "co.HFunctor");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str5, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str6, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str8, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str9, 38, "` is not an operation of an effect of ");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str10, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str11, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str12, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str13, 19, "the operations of `");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str14, 46, "` cannot be read: not an effect of a data type");
V g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2eglue_2ebindingsOf_24cpr(V v_g_240, V v_k_241, V v_ops_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2eglue_2eoperationsOf_24cpr(heff_dup(v_g_240), v_k_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_vs_247 = v_field_245;
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ops_242));
      V v_t_2449 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam0, 2, 3, (V[]){v_vs_247, v_k_241, v_g_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
      return (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2449));
    } else {
      heff_drop(v_g_240);
      heff_drop(v_ops_242);
      heff_drop(v_field_245);
      V v_t_2450 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str11); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str12), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2451 = ({ V a_0 = v_k_241; V a_1 = v_t_2450; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2450); r_; });
      V v_f_2452 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str13), heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str14)));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2452}});
    }
  }
}
V g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam1(V self, V *args) {
  V v_k_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2428 = ({ V a_0 = v_g_240; V a_1 = v_k_2427; HeffT2 r_ = (g_heff_2ecompile_2eglue_2eoperationsOf_24cpr(a_0, a_1)); heff_drop(v_k_2427); r_; });
  {
    V v_field_2430 = v_t_2428.f[1];
    int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
    if ((v_tag_2429 == ((int64_t)0ULL))) {
      V v_vs_2432 = v_field_2430;
      HeffT2 v_t_2433 = ({ V b_0 = heff_get_n(v_vs_2432, 1, 3); V b_1 = heff_get_n(v_x_2410, 0, 4); HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
      {
        V v_field_2435 = v_t_2433.f[1];
        int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
        V v_ret_24bool = heff_bool(((v_tag_2434 == ((int64_t)0ULL)) && ({ V v_x_2437 = heff_dup(v_field_2435); int c_ = 1; heff_drop(v_x_2437); c_; })));
        heff_drop(v_field_2435);
        return v_ret_24bool;
      }
    } else {
      heff_drop_rec(v_x_2410, 4);
      heff_drop(v_field_2430);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_vs_247 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_vs_247, 1), heff_rfield(v_x_2410, 0)));
  V v_t_2420;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_i_2415 = v_field_2413;
      V v_xs_2416 = heff_get_n(v_vs_247, 2, 3);
      if (heff_intLe_c_lent(MK_INT(0LL), v_i_2415, 1)) {
        if (heff_intLt_c(heff_dup(v_i_2415), heff_arrayLength_lent(v_xs_2416, 0))) {
          V v_t_2419 = heff_arrayIndex(v_xs_2416, v_i_2415);
          v_t_2420 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2419});
        } else {
          heff_drop(v_i_2415);
          heff_drop(v_xs_2416);
          v_t_2420 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_i_2415);
        heff_drop(v_xs_2416);
        v_t_2420 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop_rec(v_vs_247, 3);
      heff_drop(v_field_2413);
      v_t_2420 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2448;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Nothing: {
    V v_t_2421 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str0); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str1), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_2422 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2421));
    V v_m_2425;
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      v_m_2425 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      v_m_2425 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str3); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2422);
    }
    V v_t_2426 = ({ V a_0 = heff_dup(v_g_240); V a_1 = v_m_2425; V b_2 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str4); V r_ = (g_heff_2ecompile_2eglue_2eofType(a_0, a_1, b_2)); heff_drop(v_m_2425); heff_drop(b_2); r_; });
    V v_t_2438 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam1, 1, 2, (V[]){v_g_240, heff_dup(v_x_2410)}); V a_1 = v_t_2426; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2426); r_; });
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2410, 4);
      heff_drop(v_k_241);
      heff_drop(v_t_2438);
      v_t_2448 = NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_2438);
      V v_t_2439 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str5); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str6), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_k_241); r_; });
      V v_x2_2440 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2439));
      V v_t_2443;
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_Nil: {
        v_t_2443 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_xs_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        v_t_2443 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str8); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2440);
      }
      V v_t_2444 = heff_strAppend(heff_get_n(v_x_2410, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str9), v_t_2443));
      V v_t_2445 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str10), v_t_2444)});
      v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
    }
    break;
  }
  case TAG_Just: {
    V v_fields_2446 = heff_field(v_t_2420, 0);
    heff_take_n(v_t_2420, 1ULL, 1);
    heff_drop(v_k_241);
    heff_drop(v_g_240);
    V v_t_2447 = (g_heff_2ecompile_2eglue_2ebindingOf(v_x_2410, v_fields_2446));
    v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  return (g_prelude_2e_2b_2b(v_t_2448, v_acc_249));
}