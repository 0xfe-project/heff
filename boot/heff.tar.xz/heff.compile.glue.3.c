// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CBool 61457
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CSharedPointer 39972
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_DoneOrErrno 39355
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_Left 13886
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_args 9498020
#define LBL_byName 571997869
#define LBL_fun 311289
#define LBL_result 1012715336
#define LBL_tag 324116
#define LBL_values 1123329101
static uint32_t shape_tag__fun__args__result[] = {LBL_tag, LBL_fun, LBL_args, LBL_result};
V g_heff_2ecompile_2eglue_2eappendF(V, V);
V g_heff_2ecompile_2eglue_2eappendF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eappendF_clo;
V g_heff_2ecompile_2eglue_2ebindingOf(V, V);
V g_heff_2ecompile_2eglue_2ebindingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ebindingOf_clo;
HeffT2 g_heff_2ecompile_2eglue_2ebindingsOf_24cpr(V, V, V);
V g_heff_2ecompile_2eglue_2ecResultOf(V);
V g_heff_2ecompile_2eglue_2ecResultOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ecResultOf_clo;
HeffT2 g_heff_2ecompile_2eglue_2ecTypeOf_24cpr(V);
V g_heff_2ecompile_2eglue_2edescribedIn(V, V);
V g_heff_2ecompile_2eglue_2edescribedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2edescribedIn_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeachOf_24s1262413731x290637868_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2efieldOf_24cpr(V, V);
V g_heff_2ecompile_2eglue_2efits(V, V);
V g_heff_2ecompile_2eglue_2efits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2efits_clo;
HeffT2 g_heff_2ecompile_2eglue_2elistOf_24cpr(V);
V g_heff_2ecompile_2eglue_2eofType(V, V, V);
V g_heff_2ecompile_2eglue_2eofType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eofType_clo;
HeffT2 g_heff_2ecompile_2eglue_2eoperationsOf_24cpr(V, V);
HeffT2 g_heff_2ecompile_2eglue_2ereadDescribed_24cpr(V);
V g_heff_2ecompile_2eglue_2ereadOp(V);
V g_heff_2ecompile_2eglue_2ereadOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ereadOp_clo;
V g_heff_2ecompile_2eglue_2eresultBad(V, V, V);
V g_heff_2ecompile_2eglue_2eresultBad_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eresultBad_clo;
HeffT2 g_heff_2ecompile_2eglue_2erightOf_24cpr(V);
V g_heff_2ecompile_2eglue_2etyOf(V);
V g_heff_2ecompile_2eglue_2etyOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2etyOf_clo;
V g_heff_2ecompile_2einterp_2eevalReachedIn(V, V, V);
V g_heff_2ecompile_2einterp_2eevalReachedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalReachedIn_clo;
V g_heff_2ecompile_2einterp_2ereachGlobals(V, V, V);
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str0, 8, "CInteger");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str1, 7, "CDouble");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str2, 5, "CBool");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str3, 7, "CString");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str4, 5, "CText");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str5, 12, "COwnedString");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str6, 8, "CPointer");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str7, 14, "CSharedPointer");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str8, 5, "CVoid");

HeffT2 g_heff_2ecompile_2eglue_2ecTypeOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VTag: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_x12_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24VTag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str0), 2)) {
      heff_drop(v_x11_243);
      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nil: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_x121_246 = heff_field(v_x12_244, 0);
        V v_x122_247 = heff_field(v_x12_244, 1);
        heff_take_n(v_x12_244, 3ULL, 2);
        switch (heff_tag_of(v_x121_246)) {
        case TAG_VFun: {
          heff_take_n(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VCons: {
          heff_take_n(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VTag: {
          heff_take_n(v_x121_246, 0ULL, 2);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VInt: {
          heff_take_n(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VFloat: {
          heff_take_na(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VFloat32: {
          heff_take_n(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VStr: {
          V v_t_2415 = heff_field(v_x121_246, 0);
          V v_ru_24x121_246_24VStr = heff_take_reuse_n(v_x121_246, 1ULL, 1);
          switch (heff_tag_of(v_x122_247)) {
          case TAG_Nil: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x121_246_24VStr, TAG_CInteger, 1, (V[]){v_t_2415})}});
          }
          case TAG_Cons: {
            heff_take_n(v_x122_247, 0ULL, 2);
            heff_drop(v_t_2415);
            heff_drop_cell(v_ru_24x121_246_24VStr, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x122_247)}});
          }
        }
        case TAG_VRune: {
          heff_take_n(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VArr: {
          heff_take_n(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VBytes: {
          heff_take_n(v_x121_246, 0ULL, 1);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VBits: {
          heff_take_n(v_x121_246, 0ULL, 2);
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VErased: {
          heff_drop(v_x122_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x121_246)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
      }
    } else {
      if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str1), 2)) {
        heff_drop(v_x11_243);
        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
        switch (heff_tag_of(v_x12_244)) {
        case TAG_Nil: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CDouble)}});
        }
        case TAG_Cons: {
          heff_take_n(v_x12_244, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
        }
      } else {
        if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str2), 2)) {
          heff_drop(v_x11_243);
          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
          switch (heff_tag_of(v_x12_244)) {
          case TAG_Nil: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CBool)}});
          }
          case TAG_Cons: {
            heff_take_n(v_x12_244, 0ULL, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
          }
        } else {
          if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str3), 2)) {
            heff_drop(v_x11_243);
            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
            switch (heff_tag_of(v_x12_244)) {
            case TAG_Nil: {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CString)}});
            }
            case TAG_Cons: {
              heff_take_n(v_x12_244, 0ULL, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
            }
          } else {
            if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str4), 2)) {
              heff_drop(v_x11_243);
              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
              switch (heff_tag_of(v_x12_244)) {
              case TAG_Nil: {
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CText)}});
              }
              case TAG_Cons: {
                heff_take_n(v_x12_244, 0ULL, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
              }
            } else {
              if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str5), 2)) {
                heff_drop(v_x11_243);
                heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                switch (heff_tag_of(v_x12_244)) {
                case TAG_Nil: {
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_COwnedString)}});
                }
                case TAG_Cons: {
                  heff_take_n(v_x12_244, 0ULL, 2);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
                }
              } else {
                if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str6), 2)) {
                  heff_drop(v_x11_243);
                  switch (heff_tag_of(v_x12_244)) {
                  case TAG_Nil: {
                    heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Cons: {
                    V v_x121_2439 = heff_field(v_x12_244, 0);
                    V v_x122_2440 = heff_field(v_x12_244, 1);
                    heff_take_n(v_x12_244, 3ULL, 2);
                    switch (heff_tag_of(v_x121_2439)) {
                    case TAG_VFun: {
                      heff_take_n(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VCons: {
                      heff_take_n(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VTag: {
                      heff_take_n(v_x121_2439, 0ULL, 2);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VInt: {
                      heff_take_n(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VFloat: {
                      heff_take_na(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VFloat32: {
                      heff_take_n(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VStr: {
                      V v_t_2448 = heff_field(v_x121_2439, 0);
                      heff_take_n(v_x121_2439, 1ULL, 1);
                      switch (heff_tag_of(v_x122_2440)) {
                      case TAG_Nil: {
                        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                        heff_drop(v_t_2448);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Cons: {
                        V v_x1221_2449 = heff_field(v_x122_2440, 0);
                        V v_x1222_2450 = heff_field(v_x122_2440, 1);
                        heff_take_n(v_x122_2440, 3ULL, 2);
                        switch (heff_tag_of(v_x1221_2449)) {
                        case TAG_VFun: {
                          heff_take_n(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VCons: {
                          heff_take_n(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VTag: {
                          heff_take_n(v_x1221_2449, 0ULL, 2);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VInt: {
                          heff_take_n(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VFloat: {
                          heff_take_na(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VFloat32: {
                          heff_take_n(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VStr: {
                          V v_r_2458 = heff_field(v_x1221_2449, 0);
                          heff_take_n(v_x1221_2449, 1ULL, 1);
                          switch (heff_tag_of(v_x1222_2450)) {
                          case TAG_Nil: {
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24VTag, TAG_CPointer, 2, (V[]){v_t_2448, v_r_2458})}});
                          }
                          case TAG_Cons: {
                            heff_take_n(v_x1222_2450, 0ULL, 2);
                            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                            heff_drop(v_t_2448);
                            heff_drop(v_r_2458);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x1222_2450)}});
                          }
                        }
                        case TAG_VRune: {
                          heff_take_n(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VArr: {
                          heff_take_n(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VBytes: {
                          heff_take_n(v_x1221_2449, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VBits: {
                          heff_take_n(v_x1221_2449, 0ULL, 2);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VErased: {
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_t_2448);
                          heff_drop(v_x1222_2450);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x1221_2449)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x122_2440)}});
                      }
                    }
                    case TAG_VRune: {
                      heff_take_n(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VArr: {
                      heff_take_n(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VBytes: {
                      heff_take_n(v_x121_2439, 0ULL, 1);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VBits: {
                      heff_take_n(v_x121_2439, 0ULL, 2);
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_VErased: {
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      heff_drop(v_x122_2440);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x121_2439)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
                  }
                } else {
                  heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                  if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str7), 2)) {
                    heff_drop(v_x11_243);
                    switch (heff_tag_of(v_x12_244)) {
                    case TAG_Nil: {
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Cons: {
                      V v_x121_2472 = heff_field(v_x12_244, 0);
                      V v_x122_2473 = heff_field(v_x12_244, 1);
                      heff_take_n(v_x12_244, 3ULL, 2);
                      switch (heff_tag_of(v_x121_2472)) {
                      case TAG_VFun: {
                        heff_take_n(v_x121_2472, 0ULL, 1);
                        heff_drop(v_x122_2473);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_VCons: {
                        heff_take_n(v_x121_2472, 0ULL, 1);
                        heff_drop(v_x122_2473);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_VTag: {
                        heff_take_n(v_x121_2472, 0ULL, 2);
                        heff_drop(v_x122_2473);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_VInt: {
                        heff_take_n(v_x121_2472, 0ULL, 1);
                        heff_drop(v_x122_2473);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_VFloat: {
                        heff_take_na(v_x121_2472, 0ULL, 1);
                        heff_drop(v_x122_2473);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_VFloat32: {
                        heff_take_n(v_x121_2472, 0ULL, 1);
                        heff_drop(v_x122_2473);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_VStr: {
                        V v_t_2481 = heff_field(v_x121_2472, 0);
                        heff_take_n(v_x121_2472, 1ULL, 1);
                        switch (heff_tag_of(v_x122_2473)) {
                        case TAG_Nil: {
                          heff_drop(v_t_2481);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_Cons: {
                          V v_x1221_2482 = heff_field(v_x122_2473, 0);
                          V v_x1222_2483 = heff_field(v_x122_2473, 1);
                          heff_take_n(v_x122_2473, 3ULL, 2);
                          switch (heff_tag_of(v_x1221_2482)) {
                          case TAG_VFun: {
                            heff_take_n(v_x1221_2482, 0ULL, 1);
                            heff_drop(v_t_2481);
                            heff_drop(v_x1222_2483);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_VCons: {
                            heff_take_n(v_x1221_2482, 0ULL, 1);
                            heff_drop(v_t_2481);
                            heff_drop(v_x1222_2483);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_VTag: {
                            heff_take_n(v_x1221_2482, 0ULL, 2);
                            heff_drop(v_t_2481);
                            heff_drop(v_x1222_2483);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_VInt: {
                            heff_take_n(v_x1221_2482, 0ULL, 1);
                            heff_drop(v_t_2481);
                            heff_drop(v_x1222_2483);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_VFloat: {
                            heff_take_na(v_x1221_2482, 0ULL, 1);
                            heff_drop(v_t_2481);
                            heff_drop(v_x1222_2483);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_VFloat32: {
                            heff_take_n(v_x1221_2482, 0ULL, 1);
                            heff_drop(v_t_2481);
                            heff_drop(v_x1222_2483);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_VStr: {
                            V v_r_2491 = heff_field(v_x1221_2482, 0);
                            heff_take_n(v_x1221_2482, 1ULL, 1);
                            switch (heff_tag_of(v_x1222_2483)) {
                            case TAG_Nil: {
                              heff_drop(v_t_2481);
                              heff_drop(v_r_2491);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            case TAG_Cons: {
                              V v_x12221_2492 = heff_field(v_x1222_2483, 0);
                              V v_x12222_2493 = heff_field(v_x1222_2483, 1);
                              heff_take_n(v_x1222_2483, 3ULL, 2);
                              switch (heff_tag_of(v_x12221_2492)) {
                              case TAG_VFun: {
                                heff_take_n(v_x12221_2492, 0ULL, 1);
                                heff_drop(v_t_2481);
                                heff_drop(v_r_2491);
                                heff_drop(v_x12222_2493);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_VCons: {
                                heff_take_n(v_x12221_2492, 0ULL, 1);
                                heff_drop(v_t_2481);
                                heff_drop(v_r_2491);
                                heff_drop(v_x12222_2493);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_VTag: {
                                heff_take_n(v_x12221_2492, 0ULL, 2);
                                heff_drop(v_t_2481);
                                heff_drop(v_r_2491);
                                heff_drop(v_x12222_2493);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_VInt: {
                                heff_take_n(v_x12221_2492, 0ULL, 1);
                                heff_drop(v_t_2481);
                                heff_drop(v_r_2491);
                                heff_drop(v_x12222_2493);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_VFloat: {
                                heff_take_na(v_x12221_2492, 0ULL, 1);
                                heff_drop(v_t_2481);
                                heff_drop(v_r_2491);
                                heff_drop(v_x12222_2493);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_VFloat32: {
                                heff_take_n(v_x12221_2492, 0ULL, 1);
                                heff_drop(v_t_2481);
                                heff_drop(v_r_2491);
                                heff_drop(v_x12222_2493);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_VStr: {
                                V v_s_24101 = heff_field(v_x12221_2492, 0);
                                heff_take_n(v_x12221_2492, 1ULL, 1);
                                switch (heff_tag_of(v_x12222_2493)) {
                                case TAG_Nil: {
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_CSharedPointer, 3, (V[]){v_t_2481, v_r_2491, v_s_24101})}});
                                }
                                case TAG_Cons: {
                                  heff_take_n(v_x12222_2493, 0ULL, 2);
                                  heff_drop(v_t_2481);
                                  heff_drop(v_r_2491);
                                  heff_drop(v_s_24101);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x12222_2493)}});
                                }
                              }
                              case TAG_VRune: {
                                heff_take_n(v_x12221_2492, 0ULL, 1);
                                heff_drop(v_t_2481);
                                heff_drop(v_r_2491);
                                heff_drop(v_x12222_2493);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_VArr: {
                                heff_take_n(v_x12221_2492, 0ULL, 1);
                                heff_drop(v_t_2481);
                                heff_drop(v_r_2491);
                                heff_drop(v_x12222_2493);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_VBytes: {
                                heff_take_n(v_x12221_2492, 0ULL, 1);
                                heff_drop(v_t_2481);
                                heff_drop(v_r_2491);
                                heff_drop(v_x12222_2493);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_VBits: {
                                heff_take_n(v_x12221_2492, 0ULL, 2);
                                heff_drop(v_t_2481);
                                heff_drop(v_r_2491);
                                heff_drop(v_x12222_2493);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              case TAG_VErased: {
                                heff_drop(v_t_2481);
                                heff_drop(v_r_2491);
                                heff_drop(v_x12222_2493);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x12221_2492)}});
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x1222_2483)}});
                            }
                          }
                          case TAG_VRune: {
                            heff_take_n(v_x1221_2482, 0ULL, 1);
                            heff_drop(v_t_2481);
                            heff_drop(v_x1222_2483);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_VArr: {
                            heff_take_n(v_x1221_2482, 0ULL, 1);
                            heff_drop(v_t_2481);
                            heff_drop(v_x1222_2483);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_VBytes: {
                            heff_take_n(v_x1221_2482, 0ULL, 1);
                            heff_drop(v_t_2481);
                            heff_drop(v_x1222_2483);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_VBits: {
                            heff_take_n(v_x1221_2482, 0ULL, 2);
                            heff_drop(v_t_2481);
                            heff_drop(v_x1222_2483);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_VErased: {
                            heff_drop(v_t_2481);
                            heff_drop(v_x1222_2483);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x1221_2482)}});
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x122_2473)}});
                        }
                      }
                      case TAG_VRune: {
                        heff_take_n(v_x121_2472, 0ULL, 1);
                        heff_drop(v_x122_2473);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_VArr: {
                        heff_take_n(v_x121_2472, 0ULL, 1);
                        heff_drop(v_x122_2473);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_VBytes: {
                        heff_take_n(v_x121_2472, 0ULL, 1);
                        heff_drop(v_x122_2473);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_VBits: {
                        heff_take_n(v_x121_2472, 0ULL, 2);
                        heff_drop(v_x122_2473);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_VErased: {
                        heff_drop(v_x122_2473);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x121_2472)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
                    }
                  } else {
                    if (heff_strEq_c(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str8))) {
                      switch (heff_tag_of(v_x12_244)) {
                      case TAG_Nil: {
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CVoid)}});
                      }
                      case TAG_Cons: {
                        heff_take_n(v_x12_244, 0ULL, 2);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
                      }
                    } else {
                      heff_drop(v_x12_244);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBits: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VErased: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str0, 2, "op");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str1, 3, "fun");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str2, 4, "name");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str3, 3, "fun");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str4, 4, "args");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str5, 3, "fun");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str6, 6, "result");
V g_heff_2ecompile_2eglue_2ereadOp_lam0(V self, V *args);
V g_heff_2ecompile_2eglue_2ereadOp_lam1(V self, V *args);
V g_heff_2ecompile_2eglue_2ereadOp_lam2(V self, V *args);
V g_heff_2ecompile_2eglue_2ereadOp_lam3(V self, V *args);
V g_heff_2ecompile_2eglue_2ereadOp_lam4(V self, V *args); static Clo g_heff_2ecompile_2eglue_2ereadOp_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2ereadOp_lam4, 4, 0};
Clo g_heff_2ecompile_2eglue_2ereadOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2ereadOp_entry, 1, 0};

V g_heff_2ecompile_2eglue_2ereadOp(V v_v_240) {
top: ;
  HeffT2 v_t_241 = ({ V a_0 = heff_dup(v_v_240); V b_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str0); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
  {
    V v_field_243 = v_t_241.f[1];
    V v_tag_242 = heff_box_i64(((int64_t)v_t_241.f[0]));
    HeffT2 v_t_244 = ({ V a_0 = heff_dup(v_v_240); V b_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str1); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_x2_2427;
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_246;
        HeffT2 v_t_249 = ({ V a_0 = v_x_248; V b_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str2); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2413 = v_field_2411;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VFun: {
              heff_take_n(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VCons: {
              heff_take_n(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VTag: {
              heff_take_n(v_x_2413, 0ULL, 2);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VInt: {
              heff_take_n(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VFloat: {
              heff_take_na(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VFloat32: {
              heff_take_n(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VStr: {
              V v_s_2421 = heff_field(v_x_2413, 0);
              V v_ru_24x_2413_24VStr = heff_take_reuse_n(v_x_2413, 1ULL, 1);
              v_x2_2427 = heff_tag_at_n(v_ru_24x_2413_24VStr, TAG_Just, 1, (V[]){v_s_2421});
              break;
            }
            case TAG_VRune: {
              heff_take_n(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VArr: {
              heff_take_n(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VBytes: {
              heff_take_n(v_x_2413, 0ULL, 1);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VBits: {
              heff_take_n(v_x_2413, 0ULL, 2);
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VErased: {
              v_x2_2427 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
          } else {
            heff_drop(v_field_2411);
            v_x2_2427 = NTAG(TAG_Nothing);
          }
        }
      } else {
        heff_drop(v_field_246);
        v_x2_2427 = NTAG(TAG_Nothing);
      }
      HeffT2 v_t_2428 = ({ V a_0 = heff_dup(v_v_240); V b_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str3); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_2430 = v_t_2428.f[1];
        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
        V v_t_24122;
        if ((v_tag_2429 == ((int64_t)0ULL))) {
          V v_x_2432 = v_field_2430;
          HeffT2 v_t_2433 = ({ V a_0 = v_x_2432; V b_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str4); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
          {
            V v_field_2435 = v_t_2433.f[1];
            int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
            if ((v_tag_2434 == ((int64_t)0ULL))) {
              V v_x_2437 = v_field_2435;
              HeffT2 v_t_2438 = (g_heff_2ecompile_2eglue_2elistOf_24cpr(v_x_2437));
              {
                V v_field_2440 = v_t_2438.f[1];
                int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                if ((v_tag_2439 == ((int64_t)0ULL))) {
                  V v_x_2442 = v_field_2440;
                  HeffT2 v_t_2443 = (g_heff_2ecompile_2eglue_2eeachOf_24s1262413731x290637868_24cpr(v_x_2442));
                  {
                    V v_field_2445 = v_t_2443.f[1];
                    V v_tag_2444 = heff_box_i64(((int64_t)v_t_2443.f[0]));
                    v_t_24122 = heff_clo_n(g_heff_2ecompile_2eglue_2ereadOp_lam0, 2, 5, (V[]){v_tag_242, v_field_243, v_x2_2427, v_tag_2444, v_field_2445});
                  }
                } else {
                  heff_drop(v_field_2440);
                  v_t_24122 = heff_clo_n(g_heff_2ecompile_2eglue_2ereadOp_lam1, 2, 3, (V[]){v_tag_242, v_field_243, v_x2_2427});
                }
              }
            } else {
              heff_drop(v_field_2435);
              v_t_24122 = heff_clo_n(g_heff_2ecompile_2eglue_2ereadOp_lam2, 2, 3, (V[]){v_tag_242, v_field_243, v_x2_2427});
            }
          }
        } else {
          heff_drop(v_field_2430);
          v_t_24122 = heff_clo_n(g_heff_2ecompile_2eglue_2ereadOp_lam3, 2, 3, (V[]){v_tag_242, v_field_243, v_x2_2427});
        }
        HeffT2 v_t_24123 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str5); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_24133;
        {
          V v_field_24125 = v_t_24123.f[1];
          int64_t v_tag_24124 = ((int64_t)v_t_24123.f[0]);
          if ((v_tag_24124 == ((int64_t)0ULL))) {
            V v_x_24127 = v_field_24125;
            HeffT2 v_t_24128 = ({ V a_0 = v_x_24127; V b_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str6); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
            {
              V v_field_24130 = v_t_24128.f[1];
              int64_t v_tag_24129 = ((int64_t)v_t_24128.f[0]);
              if ((v_tag_24129 == ((int64_t)0ULL))) {
                V v_x_24132 = v_field_24130;
                v_t_24133 = ({ V a_0 = v_x_24132; V r_ = (g_heff_2ecompile_2eglue_2ecResultOf(a_0)); heff_drop(v_x_24132); r_; });
              } else {
                heff_drop(v_field_24130);
                v_t_24133 = NTAG(TAG_Nothing);
              }
            }
          } else {
            heff_drop(v_field_24125);
            v_t_24133 = NTAG(TAG_Nothing);
          }
        }
        return heff_tail(v_t_24122, 2, (V[]){v_t_24133, ((V)&g_heff_2ecompile_2eglue_2ereadOp_lam4_clo)});
      }
    }
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2ereadOp(a[0]);
}
V g_heff_2ecompile_2eglue_2ereadOp_lam0(V self, V *args) {
  V v_x4_2446 = args[0];
  V v_f_2447 = args[1];
  V v_tag_242 = heff_env(self)[0];
  V v_field_243 = heff_env(self)[1];
  V v_x2_2427 = heff_env(self)[2];
  V v_tag_2444 = heff_env(self)[3];
  V v_field_2445 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_unbox_i64(v_tag_242) == ((int64_t)0ULL))) {
    V v_x_2449 = v_field_243;
    switch (heff_tag_of(v_x_2449)) {
    case TAG_VFun: {
      heff_take_n(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VTag: {
      heff_take_n(v_x_2449, 0ULL, 2);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VInt: {
      heff_take_n(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat: {
      heff_take_na(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VStr: {
      V v_s_2457 = heff_field(v_x_2449, 0);
      V v_ru_24x_2449_24VStr = heff_take_reuse_n(v_x_2449, 1ULL, 1);
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nothing: {
        heff_drop(v_x4_2446);
        heff_drop(v_f_2447);
        heff_drop(v_tag_2444);
        heff_drop(v_field_2445);
        heff_drop(v_s_2457);
        heff_drop_cell(v_ru_24x_2449_24VStr, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_b_2458 = heff_field(v_x2_2427, 0);
        heff_take_n(v_x2_2427, 1ULL, 1);
        if ((heff_unbox_i64(v_tag_2444) == ((int64_t)0ULL))) {
          V v_c_2460 = v_field_2445;
          switch (heff_tag_of(v_x4_2446)) {
          case TAG_Nothing: {
            heff_drop(v_f_2447);
            heff_drop(v_s_2457);
            heff_drop_cell(v_ru_24x_2449_24VStr, 1);
            heff_drop(v_b_2458);
            heff_drop(v_c_2460);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_d_2461 = heff_field(v_x4_2446, 0);
            heff_take_n(v_x4_2446, 1ULL, 1);
            V v_t_2462 = heff_tr(heff_call(v_f_2447, 4, (V[]){v_s_2457, v_b_2458, v_c_2460, v_d_2461}));
            return heff_tag_at_n(v_ru_24x_2449_24VStr, TAG_Just, 1, (V[]){v_t_2462});
          }
          default: return heff_nomatch(v_x4_2446);
          }
        } else {
          heff_drop(v_x4_2446);
          heff_drop(v_f_2447);
          heff_drop(v_field_2445);
          heff_drop(v_s_2457);
          heff_drop_cell(v_ru_24x_2449_24VStr, 1);
          heff_drop(v_b_2458);
          return NTAG(TAG_Nothing);
        }
      }
      default: return heff_nomatch(v_x2_2427);
      }
    }
    case TAG_VRune: {
      heff_take_n(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VArr: {
      heff_take_n(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBytes: {
      heff_take_n(v_x_2449, 0ULL, 1);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBits: {
      heff_take_n(v_x_2449, 0ULL, 2);
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    case TAG_VErased: {
      heff_drop(v_x4_2446);
      heff_drop(v_f_2447);
      heff_drop(v_x2_2427);
      heff_drop(v_tag_2444);
      heff_drop(v_field_2445);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x_2449);
    }
  } else {
    heff_drop(v_x4_2446);
    heff_drop(v_f_2447);
    heff_drop(v_field_243);
    heff_drop(v_x2_2427);
    heff_drop(v_tag_2444);
    heff_drop(v_field_2445);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_lam1(V self, V *args) {
  V v_x4_2468 = args[0];
  V v_f_2469 = args[1];
  V v_tag_242 = heff_env(self)[0];
  V v_field_243 = heff_env(self)[1];
  V v_x2_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x4_2468);
  heff_drop(v_f_2469);
  if ((heff_unbox_i64(v_tag_242) == ((int64_t)0ULL))) {
    V v_x_2471 = v_field_243;
    switch (heff_tag_of(v_x_2471)) {
    case TAG_VFun: {
      heff_take_n(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VTag: {
      heff_take_n(v_x_2471, 0ULL, 2);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VInt: {
      heff_take_n(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat: {
      heff_take_na(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VStr: {
      heff_take_n(v_x_2471, 0ULL, 1);
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        heff_take_n(v_x2_2427, 0ULL, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x2_2427);
      }
    }
    case TAG_VRune: {
      heff_take_n(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VArr: {
      heff_take_n(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBytes: {
      heff_take_n(v_x_2471, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBits: {
      heff_take_n(v_x_2471, 0ULL, 2);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VErased: {
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x_2471);
    }
  } else {
    heff_drop(v_field_243);
    heff_drop(v_x2_2427);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_lam2(V self, V *args) {
  V v_x4_2486 = args[0];
  V v_f_2487 = args[1];
  V v_tag_242 = heff_env(self)[0];
  V v_field_243 = heff_env(self)[1];
  V v_x2_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x4_2486);
  heff_drop(v_f_2487);
  if ((heff_unbox_i64(v_tag_242) == ((int64_t)0ULL))) {
    V v_x_2489 = v_field_243;
    switch (heff_tag_of(v_x_2489)) {
    case TAG_VFun: {
      heff_take_n(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VTag: {
      heff_take_n(v_x_2489, 0ULL, 2);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VInt: {
      heff_take_n(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat: {
      heff_take_na(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VStr: {
      heff_take_n(v_x_2489, 0ULL, 1);
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        heff_take_n(v_x2_2427, 0ULL, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x2_2427);
      }
    }
    case TAG_VRune: {
      heff_take_n(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VArr: {
      heff_take_n(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBytes: {
      heff_take_n(v_x_2489, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBits: {
      heff_take_n(v_x_2489, 0ULL, 2);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VErased: {
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x_2489);
    }
  } else {
    heff_drop(v_field_243);
    heff_drop(v_x2_2427);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_lam3(V self, V *args) {
  V v_x4_24104 = args[0];
  V v_f_24105 = args[1];
  V v_tag_242 = heff_env(self)[0];
  V v_field_243 = heff_env(self)[1];
  V v_x2_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x4_24104);
  heff_drop(v_f_24105);
  if ((heff_unbox_i64(v_tag_242) == ((int64_t)0ULL))) {
    V v_x_24107 = v_field_243;
    switch (heff_tag_of(v_x_24107)) {
    case TAG_VFun: {
      heff_take_n(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VTag: {
      heff_take_n(v_x_24107, 0ULL, 2);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VInt: {
      heff_take_n(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat: {
      heff_take_na(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VStr: {
      heff_take_n(v_x_24107, 0ULL, 1);
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        heff_take_n(v_x2_2427, 0ULL, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x2_2427);
      }
    }
    case TAG_VRune: {
      heff_take_n(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VArr: {
      heff_take_n(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBytes: {
      heff_take_n(v_x_24107, 0ULL, 1);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBits: {
      heff_take_n(v_x_24107, 0ULL, 2);
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    case TAG_VErased: {
      heff_drop(v_x2_2427);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x_24107);
    }
  } else {
    heff_drop(v_field_243);
    heff_drop(v_x2_2427);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_lam4(V self, V *args) {
  V v_tag_24134 = args[0];
  V v_fun_24135 = args[1];
  V v_args_24136 = args[2];
  V v_result_24137 = args[3];
  return heff_rec_n(4, shape_tag__fun__args__result, (V[]){v_tag_24134, v_fun_24135, v_args_24136, v_result_24137});
}
Clo g_heff_2ecompile_2eglue_2etyOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2etyOf_entry, 1, 0};

V g_heff_2ecompile_2eglue_2etyOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SU: {
    return v_x1_240;
  }
  case TAG_SDecode: {
    V v_x11_242 = heff_dup(heff_field(v_x1_240, 0));
    switch (heff_tag_of(v_x11_242)) {
    case TAG_SLocal: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SGlobal: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SCode: {
      V v_t_245 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_tag(v_x1_240, 1);
      V t_0 = v_t_245;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_SApp: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SLam: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SCons: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SProj: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_STag: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SMatch: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SSpecialize: {
      heff_take_n(v_x11_242, 0ULL, 3);
      return v_x1_240;
    }
    case TAG_SIs: {
      V v_e_2420 = heff_field(v_x11_242, 0);
      V v_ru_24x11_242_24SIs = heff_take_reuse_n(v_x11_242, 1ULL, 1);
      heff_drop_tag(v_x1_240, 1);
      V t_0 = heff_tag_at_n(v_ru_24x11_242_24SIs, TAG_SDecode, 1, (V[]){v_e_2420});
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_SOpaque: {
      return v_x1_240;
    }
    case TAG_SAbandon: {
      return v_x1_240;
    }
    case TAG_SRec: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SFix: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SImplicit: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SPrim: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SMetaApp: {
      heff_take_n(v_x11_242, 0ULL, 3);
      return v_x1_240;
    }
    case TAG_SLitInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitFixed: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_SFunction: {
    return v_x1_240;
  }
  case TAG_SRecord: {
    return v_x1_240;
  }
  case TAG_SSum: {
    return v_x1_240;
  }
  case TAG_SIsTy: {
    V v_t_2447 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_t_2447;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SPrimInt: {
    return v_x1_240;
  }
  case TAG_SPrimFloat: {
    return v_x1_240;
  }
  case TAG_SPrimString: {
    return v_x1_240;
  }
  case TAG_SPrimRune: {
    return v_x1_240;
  }
  case TAG_SPrimArray: {
    return v_x1_240;
  }
  case TAG_SFixed: {
    return v_x1_240;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eglue_2etyOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2etyOf(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str0, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str2, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str3, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str4, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str5, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str6, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str7, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str8, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str9, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str10, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str11, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str12, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str13, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str14, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str15, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str16, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str17, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str18, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str19, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str20, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str21, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str22, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str23, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str24, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str25, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str26, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str27, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str28, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str29, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str30, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str31, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str32, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str33, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str34, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str35, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str36, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str37, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str38, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str39, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str40, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str41, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str42, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str43, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str44, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str45, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str46, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str47, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str48, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str49, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str50, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str51, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str52, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str53, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str54, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str55, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str56, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str57, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str58, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str59, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str60, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str61, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str62, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str63, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str64, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str65, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str66, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str67, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str68, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str69, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str70, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str71, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str72, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str73, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str74, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str75, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str76, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str77, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str78, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str79, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str80, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str81, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str82, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str83, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str84, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str85, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str86, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str87, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str88, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str89, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str90, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str91, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str92, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str93, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str94, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str95, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str96, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str97, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str98, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str99, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str100, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str101, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str102, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str103, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str104, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str105, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str106, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str107, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str108, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str109, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str110, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str111, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str112, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str113, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str114, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str115, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str116, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str117, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str118, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str119, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str120, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str121, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str122, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str123, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str124, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str125, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str126, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str127, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str128, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str129, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str130, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str131, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str132, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str133, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str134, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str135, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str136, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str137, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str138, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str139, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str140, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str141, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str142, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str143, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str144, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str145, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str146, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str147, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str148, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str149, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str150, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str151, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str152, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str153, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str154, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str155, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str156, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str157, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str158, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str159, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str160, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str161, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str162, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str163, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str164, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str165, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str166, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str167, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str168, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str169, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str170, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str171, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str172, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str173, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str174, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str175, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str176, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str177, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str178, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str179, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str180, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str181, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str182, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str183, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str184, 32, "`'s answer cannot be made of a `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str185, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str186, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str187, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str188, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str189, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str190, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str191, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str192, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str193, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str194, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str195, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str196, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str197, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str198, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str199, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str200, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str201, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str202, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str203, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str204, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str205, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str206, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str207, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str208, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str209, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str210, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str211, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str212, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str213, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str214, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str215, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str216, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str217, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str218, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str219, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str220, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str221, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str222, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str223, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str224, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str225, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str226, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str227, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str228, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str229, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str230, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str231, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str232, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str233, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str234, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str235, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str236, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str237, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str238, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str239, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str240, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str241, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str242, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str243, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str244, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str245, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str246, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str247, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str248, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str249, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str250, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str251, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str252, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str253, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str254, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str255, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str256, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str257, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str258, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str259, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str260, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str261, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str262, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str263, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str264, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str265, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str266, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str267, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str268, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str269, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str270, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str271, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str272, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str273, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str274, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str275, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str276, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str277, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str278, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str279, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str280, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str281, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str282, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str283, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str284, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str285, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str286, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str287, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str288, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str289, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str290, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str291, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str292, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str293, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str294, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str295, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str296, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str297, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str298, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str299, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str300, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str301, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str302, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str303, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str304, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str305, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str306, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str307, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str308, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str309, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str310, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str311, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str312, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str313, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str314, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str315, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str316, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str317, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str318, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str319, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str320, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str321, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str322, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str323, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str324, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str325, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str326, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str327, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str328, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str329, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str330, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str331, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str332, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str333, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str334, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str335, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str336, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str337, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str338, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str339, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str340, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str341, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str342, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str343, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str344, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str345, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str346, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str347, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str348, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str349, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str350, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str351, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str352, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str353, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str354, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str355, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str356, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str357, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str358, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str359, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str360, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str361, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str362, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str363, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str364, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str365, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str366, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str367, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str368, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str369, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str370, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str371, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str372, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str373, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str374, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str375, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str376, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str377, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str378, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str379, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str380, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str381, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str382, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str383, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str384, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str385, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str386, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str387, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str388, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str389, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str390, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str391, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str392, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str393, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str394, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str395, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str396, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str397, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str398, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str399, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str400, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str401, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str402, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str403, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str404, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str405, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str406, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str407, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str408, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str409, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str410, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str411, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str412, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str413, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str414, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str415, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str416, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str417, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str418, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str419, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str420, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str421, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str422, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str423, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str424, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str425, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str426, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str427, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str428, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str429, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str430, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str431, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str432, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str433, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str434, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str435, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str436, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str437, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str438, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str439, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str440, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str441, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str442, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str443, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str444, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str445, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str446, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str447, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str448, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str449, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str450, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str451, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str452, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str453, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str454, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str455, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str456, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str457, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str458, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str459, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str460, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str461, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str462, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str463, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str464, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str465, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str466, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str467, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str468, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str469, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str470, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str471, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str472, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str473, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str474, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str475, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str476, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str477, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str478, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str479, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str480, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str481, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str482, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str483, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str484, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str485, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str486, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str487, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str488, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str489, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str490, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str491, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str492, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str493, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str494, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str495, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str496, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str497, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str498, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str499, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str500, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str501, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str502, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str503, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str504, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str505, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str506, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str507, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str508, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str509, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str510, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str511, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str512, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str513, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str514, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str515, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str516, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str517, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str518, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str519, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str520, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str521, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str522, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str523, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str524, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str525, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str526, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str527, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str528, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str529, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str530, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str531, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str532, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str533, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str534, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str535, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str536, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str537, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str538, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str539, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str540, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str541, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str542, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str543, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str544, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str545, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str546, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str547, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str548, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str549, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str550, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str551, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str552, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str553, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str554, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str555, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str556, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str557, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str558, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str559, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str560, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str561, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str562, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str563, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str564, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str565, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str566, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str567, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str568, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str569, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str570, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str571, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str572, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str573, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str574, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str575, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str576, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str577, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str578, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str579, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str580, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str581, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str582, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str583, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str584, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str585, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str586, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str587, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str588, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str589, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str590, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str591, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str592, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str593, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str594, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str595, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str596, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str597, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str598, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str599, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str600, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str601, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str602, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str603, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str604, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str605, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str606, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str607, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str608, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str609, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str610, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str611, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str612, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str613, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str614, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str615, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str616, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str617, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str618, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str619, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str620, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str621, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str622, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str623, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str624, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str625, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str626, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str627, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str628, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str629, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str630, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str631, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str632, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str633, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str634, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str635, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str636, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str637, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str638, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str639, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str640, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str641, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str642, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str643, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str644, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str645, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str646, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str647, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str648, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str649, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str650, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str651, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str652, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str653, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str654, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str655, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str656, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str657, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str658, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str659, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str660, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str661, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str662, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str663, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str664, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str665, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str666, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str667, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str668, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str669, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str670, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str671, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str672, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str673, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str674, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str675, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str676, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str677, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str678, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str679, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str680, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str681, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str682, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str683, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str684, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str685, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str686, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str687, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str688, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str689, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str690, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str691, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str692, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str693, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str694, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str695, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str696, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str697, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str698, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str699, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str700, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str701, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str702, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str703, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str704, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str705, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str706, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str707, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str708, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str709, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str710, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str711, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str712, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str713, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str714, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str715, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str716, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str717, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str718, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str719, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str720, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str721, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str722, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str723, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str724, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str725, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str726, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str727, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str728, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str729, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str730, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str731, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str732, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str733, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str734, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str735, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str736, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str737, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str738, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str739, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str740, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str741, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str742, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str743, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str744, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str745, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str746, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str747, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str748, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str749, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str750, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str751, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str752, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str753, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str754, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str755, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str756, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str757, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str758, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str759, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str760, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str761, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str762, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str763, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str764, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str765, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str766, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str767, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str768, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str769, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str770, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str771, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str772, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str773, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str774, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str775, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str776, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str777, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str778, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str779, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str780, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str781, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str782, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str783, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str784, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str785, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str786, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str787, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str788, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str789, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str790, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str791, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str792, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str793, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str794, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str795, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str796, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str797, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str798, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str799, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str800, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str801, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str802, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str803, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str804, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str805, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str806, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str807, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str808, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str809, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str810, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str811, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str812, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str813, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str814, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str815, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str816, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str817, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str818, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str819, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str820, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str821, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str822, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str823, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str824, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str825, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str826, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str827, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str828, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str829, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str830, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str831, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str832, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str833, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str834, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str835, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str836, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str837, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str838, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str839, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str840, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str841, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str842, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str843, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str844, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str845, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str846, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str847, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str848, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str849, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str850, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str851, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str852, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str853, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str854, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str855, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str856, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str857, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str858, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str859, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str860, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str861, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str862, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str863, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str864, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str865, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str866, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str867, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str868, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str869, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str870, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str871, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str872, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str873, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str874, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str875, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str876, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str877, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str878, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str879, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str880, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str881, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str882, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str883, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str884, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str885, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str886, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str887, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str888, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str889, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str890, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str891, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str892, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str893, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str894, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str895, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str896, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str897, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str898, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str899, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str900, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str901, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str902, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str903, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str904, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str905, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str906, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str907, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str908, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str909, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str910, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str911, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str912, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str913, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str914, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str915, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str916, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str917, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str918, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str919, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str920, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str921, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str922, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str923, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str924, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str925, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str926, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str927, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str928, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str929, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str930, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str931, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str932, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str933, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str934, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str935, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str936, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str937, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str938, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str939, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str940, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str941, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str942, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str943, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str944, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str945, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str946, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str947, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str948, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str949, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str950, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str951, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str952, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str953, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str954, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str955, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str956, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str957, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str958, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str959, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str960, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str961, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str962, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str963, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str964, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str965, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str966, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str967, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str968, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str969, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str970, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str971, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str972, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str973, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str974, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str975, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str976, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str977, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str978, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str979, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str980, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str981, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str982, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str983, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str984, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str985, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str986, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str987, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str988, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str989, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str990, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str991, 13, "`'s result, `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str992, 32, "`, cannot fail as `-1` or `NULL`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str993, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str994, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str995, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str996, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str997, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str998, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str999, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1000, 11, " * (shared)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1001, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1002, 33, "`'s `Right` cannot be made of a `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1003, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1004, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1005, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1006, 65, "`'s answer is not an `Either Errno a`, as its result is described");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1007, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1008, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1009, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1010, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1011, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1012, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1013, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1014, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1015, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1016, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1017, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1018, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1019, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1020, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1021, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1022, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1023, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1024, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1025, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1026, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1027, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1028, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1029, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1030, 68, "`'s answer is not an `Either Errno Unit`, as its result is described");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1031, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1032, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1033, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1034, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1035, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1036, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1037, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1038, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1039, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1040, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1041, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1042, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1043, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1044, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1045, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1046, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1047, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_str1048, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");
Clo g_heff_2ecompile_2eglue_2eresultBad_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2eresultBad_entry, 3, 0};

V g_heff_2ecompile_2eglue_2eresultBad(V v_tag_240, V v_x2_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Gives: {
    V v_c_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Gives = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_SU: {
      heff_take_n(v_t_242, 0ULL, 1);
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_2412;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_246 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2412 = v_t_246;
          break;
        }
        case TAG_CDouble: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str0);
          break;
        }
        case TAG_CBool: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1);
          break;
        }
        case TAG_CString: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str2);
          break;
        }
        case TAG_CText: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str3);
          break;
        }
        case TAG_COwnedString: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str4);
          break;
        }
        case TAG_CPointer: {
          V v_t_247 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2412 = heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str5));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_249 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_2412 = heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str6));
          break;
        }
        case TAG_CVoid: {
          v_t_2412 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str7);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str8), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str9)));
        V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str10), heff_strAppend(v_tag_240, v_t_2413));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2414});
      }
      case TAG_CDouble: {
        V v_t_2421;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2415 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2421 = v_t_2415;
          break;
        }
        case TAG_CDouble: {
          v_t_2421 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str11);
          break;
        }
        case TAG_CBool: {
          v_t_2421 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str12);
          break;
        }
        case TAG_CString: {
          v_t_2421 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str13);
          break;
        }
        case TAG_CText: {
          v_t_2421 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str14);
          break;
        }
        case TAG_COwnedString: {
          v_t_2421 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str15);
          break;
        }
        case TAG_CPointer: {
          V v_t_2416 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2421 = heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str16));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_2418 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_2421 = heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str17));
          break;
        }
        case TAG_CVoid: {
          v_t_2421 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str18);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str19), heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str20)));
        V v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str21), heff_strAppend(v_tag_240, v_t_2422));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2423});
      }
      case TAG_CBool: {
        V v_t_2430;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2424 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2430 = v_t_2424;
          break;
        }
        case TAG_CDouble: {
          v_t_2430 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str22);
          break;
        }
        case TAG_CBool: {
          v_t_2430 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str23);
          break;
        }
        case TAG_CString: {
          v_t_2430 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str24);
          break;
        }
        case TAG_CText: {
          v_t_2430 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str25);
          break;
        }
        case TAG_COwnedString: {
          v_t_2430 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str26);
          break;
        }
        case TAG_CPointer: {
          V v_t_2425 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2430 = heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str27));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_2427 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_2430 = heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str28));
          break;
        }
        case TAG_CVoid: {
          v_t_2430 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str29);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str30), heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str31)));
        V v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str32), heff_strAppend(v_tag_240, v_t_2431));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2432});
      }
      case TAG_CString: {
        V v_t_2439;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2433 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2439 = v_t_2433;
          break;
        }
        case TAG_CDouble: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str33);
          break;
        }
        case TAG_CBool: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str34);
          break;
        }
        case TAG_CString: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str35);
          break;
        }
        case TAG_CText: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str36);
          break;
        }
        case TAG_COwnedString: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str37);
          break;
        }
        case TAG_CPointer: {
          V v_t_2434 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2439 = heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str38));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_2436 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_2439 = heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str39));
          break;
        }
        case TAG_CVoid: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str40);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2440 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str41), heff_strAppend(v_t_2439, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str42)));
        V v_t_2441 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str43), heff_strAppend(v_tag_240, v_t_2440));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2441});
      }
      case TAG_CText: {
        V v_t_2448;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2442 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2448 = v_t_2442;
          break;
        }
        case TAG_CDouble: {
          v_t_2448 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str44);
          break;
        }
        case TAG_CBool: {
          v_t_2448 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str45);
          break;
        }
        case TAG_CString: {
          v_t_2448 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str46);
          break;
        }
        case TAG_CText: {
          v_t_2448 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str47);
          break;
        }
        case TAG_COwnedString: {
          v_t_2448 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str48);
          break;
        }
        case TAG_CPointer: {
          V v_t_2443 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2448 = heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str49));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_2445 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_2448 = heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str50));
          break;
        }
        case TAG_CVoid: {
          v_t_2448 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str51);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2449 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str52), heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str53)));
        V v_t_2450 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str54), heff_strAppend(v_tag_240, v_t_2449));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2450});
      }
      case TAG_COwnedString: {
        V v_t_2457;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2451 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2457 = v_t_2451;
          break;
        }
        case TAG_CDouble: {
          v_t_2457 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str55);
          break;
        }
        case TAG_CBool: {
          v_t_2457 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str56);
          break;
        }
        case TAG_CString: {
          v_t_2457 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str57);
          break;
        }
        case TAG_CText: {
          v_t_2457 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str58);
          break;
        }
        case TAG_COwnedString: {
          v_t_2457 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str59);
          break;
        }
        case TAG_CPointer: {
          V v_t_2452 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2457 = heff_strAppend(v_t_2452, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str60));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_2454 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_2457 = heff_strAppend(v_t_2454, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str61));
          break;
        }
        case TAG_CVoid: {
          v_t_2457 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str62);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2458 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str63), heff_strAppend(v_t_2457, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str64)));
        V v_t_2459 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str65), heff_strAppend(v_tag_240, v_t_2458));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2459});
      }
      case TAG_CPointer: {
        V v_t_2468;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2462 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2468 = v_t_2462;
          break;
        }
        case TAG_CDouble: {
          v_t_2468 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str66);
          break;
        }
        case TAG_CBool: {
          v_t_2468 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str67);
          break;
        }
        case TAG_CString: {
          v_t_2468 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str68);
          break;
        }
        case TAG_CText: {
          v_t_2468 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str69);
          break;
        }
        case TAG_COwnedString: {
          v_t_2468 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str70);
          break;
        }
        case TAG_CPointer: {
          V v_t_2463 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2468 = heff_strAppend(v_t_2463, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str71));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_2465 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_2468 = heff_strAppend(v_t_2465, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str72));
          break;
        }
        case TAG_CVoid: {
          v_t_2468 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str73);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2469 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str74), heff_strAppend(v_t_2468, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str75)));
        V v_t_2470 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str76), heff_strAppend(v_tag_240, v_t_2469));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2470});
      }
      case TAG_CSharedPointer: {
        V v_t_2480;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2474 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2480 = v_t_2474;
          break;
        }
        case TAG_CDouble: {
          v_t_2480 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str77);
          break;
        }
        case TAG_CBool: {
          v_t_2480 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str78);
          break;
        }
        case TAG_CString: {
          v_t_2480 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str79);
          break;
        }
        case TAG_CText: {
          v_t_2480 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str80);
          break;
        }
        case TAG_COwnedString: {
          v_t_2480 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str81);
          break;
        }
        case TAG_CPointer: {
          V v_t_2475 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2480 = heff_strAppend(v_t_2475, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str82));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_2477 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_2480 = heff_strAppend(v_t_2477, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str83));
          break;
        }
        case TAG_CVoid: {
          v_t_2480 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str84);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2481 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str85), heff_strAppend(v_t_2480, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str86)));
        V v_t_2482 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str87), heff_strAppend(v_tag_240, v_t_2481));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2482});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SDecode: {
      heff_take_n(v_t_242, 0ULL, 1);
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_2491;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2485 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2491 = v_t_2485;
          break;
        }
        case TAG_CDouble: {
          v_t_2491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str88);
          break;
        }
        case TAG_CBool: {
          v_t_2491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str89);
          break;
        }
        case TAG_CString: {
          v_t_2491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str90);
          break;
        }
        case TAG_CText: {
          v_t_2491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str91);
          break;
        }
        case TAG_COwnedString: {
          v_t_2491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str92);
          break;
        }
        case TAG_CPointer: {
          V v_t_2486 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2491 = heff_strAppend(v_t_2486, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str93));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_2488 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_2491 = heff_strAppend(v_t_2488, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str94));
          break;
        }
        case TAG_CVoid: {
          v_t_2491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str95);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2492 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str96), heff_strAppend(v_t_2491, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str97)));
        V v_t_2493 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str98), heff_strAppend(v_tag_240, v_t_2492));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_2493});
      }
      case TAG_CDouble: {
        V v_t_24100;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2494 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24100 = v_t_2494;
          break;
        }
        case TAG_CDouble: {
          v_t_24100 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str99);
          break;
        }
        case TAG_CBool: {
          v_t_24100 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str100);
          break;
        }
        case TAG_CString: {
          v_t_24100 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str101);
          break;
        }
        case TAG_CText: {
          v_t_24100 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str102);
          break;
        }
        case TAG_COwnedString: {
          v_t_24100 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str103);
          break;
        }
        case TAG_CPointer: {
          V v_t_2495 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24100 = heff_strAppend(v_t_2495, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str104));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_2497 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24100 = heff_strAppend(v_t_2497, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str105));
          break;
        }
        case TAG_CVoid: {
          v_t_24100 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str106);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24101 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str107), heff_strAppend(v_t_24100, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str108)));
        V v_t_24102 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str109), heff_strAppend(v_tag_240, v_t_24101));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24102});
      }
      case TAG_CBool: {
        V v_t_24109;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24103 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24109 = v_t_24103;
          break;
        }
        case TAG_CDouble: {
          v_t_24109 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str110);
          break;
        }
        case TAG_CBool: {
          v_t_24109 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str111);
          break;
        }
        case TAG_CString: {
          v_t_24109 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str112);
          break;
        }
        case TAG_CText: {
          v_t_24109 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str113);
          break;
        }
        case TAG_COwnedString: {
          v_t_24109 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str114);
          break;
        }
        case TAG_CPointer: {
          V v_t_24104 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24109 = heff_strAppend(v_t_24104, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str115));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24106 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24109 = heff_strAppend(v_t_24106, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str116));
          break;
        }
        case TAG_CVoid: {
          v_t_24109 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str117);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24110 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str118), heff_strAppend(v_t_24109, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str119)));
        V v_t_24111 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str120), heff_strAppend(v_tag_240, v_t_24110));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24111});
      }
      case TAG_CString: {
        V v_t_24118;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24112 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24118 = v_t_24112;
          break;
        }
        case TAG_CDouble: {
          v_t_24118 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str121);
          break;
        }
        case TAG_CBool: {
          v_t_24118 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str122);
          break;
        }
        case TAG_CString: {
          v_t_24118 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str123);
          break;
        }
        case TAG_CText: {
          v_t_24118 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str124);
          break;
        }
        case TAG_COwnedString: {
          v_t_24118 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str125);
          break;
        }
        case TAG_CPointer: {
          V v_t_24113 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24118 = heff_strAppend(v_t_24113, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str126));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24115 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24118 = heff_strAppend(v_t_24115, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str127));
          break;
        }
        case TAG_CVoid: {
          v_t_24118 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str128);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24119 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str129), heff_strAppend(v_t_24118, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str130)));
        V v_t_24120 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str131), heff_strAppend(v_tag_240, v_t_24119));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24120});
      }
      case TAG_CText: {
        V v_t_24127;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24121 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24127 = v_t_24121;
          break;
        }
        case TAG_CDouble: {
          v_t_24127 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str132);
          break;
        }
        case TAG_CBool: {
          v_t_24127 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str133);
          break;
        }
        case TAG_CString: {
          v_t_24127 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str134);
          break;
        }
        case TAG_CText: {
          v_t_24127 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str135);
          break;
        }
        case TAG_COwnedString: {
          v_t_24127 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str136);
          break;
        }
        case TAG_CPointer: {
          V v_t_24122 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24127 = heff_strAppend(v_t_24122, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str137));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24124 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24127 = heff_strAppend(v_t_24124, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str138));
          break;
        }
        case TAG_CVoid: {
          v_t_24127 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str139);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24128 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str140), heff_strAppend(v_t_24127, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str141)));
        V v_t_24129 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str142), heff_strAppend(v_tag_240, v_t_24128));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24129});
      }
      case TAG_COwnedString: {
        V v_t_24136;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24130 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24136 = v_t_24130;
          break;
        }
        case TAG_CDouble: {
          v_t_24136 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str143);
          break;
        }
        case TAG_CBool: {
          v_t_24136 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str144);
          break;
        }
        case TAG_CString: {
          v_t_24136 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str145);
          break;
        }
        case TAG_CText: {
          v_t_24136 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str146);
          break;
        }
        case TAG_COwnedString: {
          v_t_24136 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str147);
          break;
        }
        case TAG_CPointer: {
          V v_t_24131 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24136 = heff_strAppend(v_t_24131, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str148));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24133 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24136 = heff_strAppend(v_t_24133, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str149));
          break;
        }
        case TAG_CVoid: {
          v_t_24136 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str150);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24137 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str151), heff_strAppend(v_t_24136, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str152)));
        V v_t_24138 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str153), heff_strAppend(v_tag_240, v_t_24137));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24138});
      }
      case TAG_CPointer: {
        V v_t_24147;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24141 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24147 = v_t_24141;
          break;
        }
        case TAG_CDouble: {
          v_t_24147 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str154);
          break;
        }
        case TAG_CBool: {
          v_t_24147 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str155);
          break;
        }
        case TAG_CString: {
          v_t_24147 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str156);
          break;
        }
        case TAG_CText: {
          v_t_24147 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str157);
          break;
        }
        case TAG_COwnedString: {
          v_t_24147 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str158);
          break;
        }
        case TAG_CPointer: {
          V v_t_24142 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24147 = heff_strAppend(v_t_24142, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str159));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24144 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24147 = heff_strAppend(v_t_24144, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str160));
          break;
        }
        case TAG_CVoid: {
          v_t_24147 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str161);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24148 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str162), heff_strAppend(v_t_24147, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str163)));
        V v_t_24149 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str164), heff_strAppend(v_tag_240, v_t_24148));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24149});
      }
      case TAG_CSharedPointer: {
        V v_t_24159;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24153 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24159 = v_t_24153;
          break;
        }
        case TAG_CDouble: {
          v_t_24159 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str165);
          break;
        }
        case TAG_CBool: {
          v_t_24159 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str166);
          break;
        }
        case TAG_CString: {
          v_t_24159 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str167);
          break;
        }
        case TAG_CText: {
          v_t_24159 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str168);
          break;
        }
        case TAG_COwnedString: {
          v_t_24159 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str169);
          break;
        }
        case TAG_CPointer: {
          V v_t_24154 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24159 = heff_strAppend(v_t_24154, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str170));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24156 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24159 = heff_strAppend(v_t_24156, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str171));
          break;
        }
        case TAG_CVoid: {
          v_t_24159 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str172);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24160 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str173), heff_strAppend(v_t_24159, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str174)));
        V v_t_24161 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str175), heff_strAppend(v_tag_240, v_t_24160));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24161});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SFunction: {
      V v_dom_24163 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 5);
      V v_t_24167 = (g_heff_2ecompile_2eglue_2efits(heff_dup(v_c_243), v_dom_24163));
      if ((heff_dup(v_t_24167) == NTAG(TAG_True))) {
        heff_drop(v_tag_240);
        heff_drop(v_c_243);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        heff_drop(v_t_24167);
        return NTAG(TAG_Nothing);
      } else {
        heff_drop(v_t_24167);
        V v_t_24174;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24168 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24174 = v_t_24168;
          break;
        }
        case TAG_CDouble: {
          v_t_24174 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str176);
          break;
        }
        case TAG_CBool: {
          v_t_24174 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str177);
          break;
        }
        case TAG_CString: {
          v_t_24174 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str178);
          break;
        }
        case TAG_CText: {
          v_t_24174 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str179);
          break;
        }
        case TAG_COwnedString: {
          v_t_24174 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str180);
          break;
        }
        case TAG_CPointer: {
          V v_t_24169 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24174 = heff_strAppend(v_t_24169, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str181));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24171 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24174 = heff_strAppend(v_t_24171, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str182));
          break;
        }
        case TAG_CVoid: {
          v_t_24174 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str183);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24175 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str184), heff_strAppend(v_t_24174, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str185)));
        V v_t_24176 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str186), heff_strAppend(v_tag_240, v_t_24175));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24176});
      }
    }
    case TAG_SRecord: {
      heff_take_n(v_t_242, 0ULL, 3);
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24187;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24181 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24187 = v_t_24181;
          break;
        }
        case TAG_CDouble: {
          v_t_24187 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str187);
          break;
        }
        case TAG_CBool: {
          v_t_24187 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str188);
          break;
        }
        case TAG_CString: {
          v_t_24187 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str189);
          break;
        }
        case TAG_CText: {
          v_t_24187 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str190);
          break;
        }
        case TAG_COwnedString: {
          v_t_24187 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str191);
          break;
        }
        case TAG_CPointer: {
          V v_t_24182 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24187 = heff_strAppend(v_t_24182, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str192));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24184 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24187 = heff_strAppend(v_t_24184, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str193));
          break;
        }
        case TAG_CVoid: {
          v_t_24187 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str194);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24188 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str195), heff_strAppend(v_t_24187, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str196)));
        V v_t_24189 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str197), heff_strAppend(v_tag_240, v_t_24188));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24189});
      }
      case TAG_CDouble: {
        V v_t_24196;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24190 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24196 = v_t_24190;
          break;
        }
        case TAG_CDouble: {
          v_t_24196 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str198);
          break;
        }
        case TAG_CBool: {
          v_t_24196 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str199);
          break;
        }
        case TAG_CString: {
          v_t_24196 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str200);
          break;
        }
        case TAG_CText: {
          v_t_24196 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str201);
          break;
        }
        case TAG_COwnedString: {
          v_t_24196 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str202);
          break;
        }
        case TAG_CPointer: {
          V v_t_24191 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24196 = heff_strAppend(v_t_24191, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str203));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24193 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24196 = heff_strAppend(v_t_24193, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str204));
          break;
        }
        case TAG_CVoid: {
          v_t_24196 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str205);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24197 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str206), heff_strAppend(v_t_24196, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str207)));
        V v_t_24198 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str208), heff_strAppend(v_tag_240, v_t_24197));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24198});
      }
      case TAG_CBool: {
        V v_t_24205;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24199 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24205 = v_t_24199;
          break;
        }
        case TAG_CDouble: {
          v_t_24205 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str209);
          break;
        }
        case TAG_CBool: {
          v_t_24205 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str210);
          break;
        }
        case TAG_CString: {
          v_t_24205 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str211);
          break;
        }
        case TAG_CText: {
          v_t_24205 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str212);
          break;
        }
        case TAG_COwnedString: {
          v_t_24205 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str213);
          break;
        }
        case TAG_CPointer: {
          V v_t_24200 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24205 = heff_strAppend(v_t_24200, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str214));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24202 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24205 = heff_strAppend(v_t_24202, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str215));
          break;
        }
        case TAG_CVoid: {
          v_t_24205 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str216);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24206 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str217), heff_strAppend(v_t_24205, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str218)));
        V v_t_24207 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str219), heff_strAppend(v_tag_240, v_t_24206));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24207});
      }
      case TAG_CString: {
        V v_t_24214;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24208 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24214 = v_t_24208;
          break;
        }
        case TAG_CDouble: {
          v_t_24214 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str220);
          break;
        }
        case TAG_CBool: {
          v_t_24214 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str221);
          break;
        }
        case TAG_CString: {
          v_t_24214 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str222);
          break;
        }
        case TAG_CText: {
          v_t_24214 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str223);
          break;
        }
        case TAG_COwnedString: {
          v_t_24214 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str224);
          break;
        }
        case TAG_CPointer: {
          V v_t_24209 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24214 = heff_strAppend(v_t_24209, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str225));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24211 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24214 = heff_strAppend(v_t_24211, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str226));
          break;
        }
        case TAG_CVoid: {
          v_t_24214 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str227);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24215 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str228), heff_strAppend(v_t_24214, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str229)));
        V v_t_24216 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str230), heff_strAppend(v_tag_240, v_t_24215));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24216});
      }
      case TAG_CText: {
        V v_t_24223;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24217 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24223 = v_t_24217;
          break;
        }
        case TAG_CDouble: {
          v_t_24223 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str231);
          break;
        }
        case TAG_CBool: {
          v_t_24223 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str232);
          break;
        }
        case TAG_CString: {
          v_t_24223 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str233);
          break;
        }
        case TAG_CText: {
          v_t_24223 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str234);
          break;
        }
        case TAG_COwnedString: {
          v_t_24223 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str235);
          break;
        }
        case TAG_CPointer: {
          V v_t_24218 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24223 = heff_strAppend(v_t_24218, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str236));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24220 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24223 = heff_strAppend(v_t_24220, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str237));
          break;
        }
        case TAG_CVoid: {
          v_t_24223 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str238);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24224 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str239), heff_strAppend(v_t_24223, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str240)));
        V v_t_24225 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str241), heff_strAppend(v_tag_240, v_t_24224));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24225});
      }
      case TAG_COwnedString: {
        V v_t_24232;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24226 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24232 = v_t_24226;
          break;
        }
        case TAG_CDouble: {
          v_t_24232 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str242);
          break;
        }
        case TAG_CBool: {
          v_t_24232 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str243);
          break;
        }
        case TAG_CString: {
          v_t_24232 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str244);
          break;
        }
        case TAG_CText: {
          v_t_24232 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str245);
          break;
        }
        case TAG_COwnedString: {
          v_t_24232 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str246);
          break;
        }
        case TAG_CPointer: {
          V v_t_24227 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24232 = heff_strAppend(v_t_24227, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str247));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24229 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24232 = heff_strAppend(v_t_24229, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str248));
          break;
        }
        case TAG_CVoid: {
          v_t_24232 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str249);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24233 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str250), heff_strAppend(v_t_24232, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str251)));
        V v_t_24234 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str252), heff_strAppend(v_tag_240, v_t_24233));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24234});
      }
      case TAG_CPointer: {
        V v_t_24243;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24237 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24243 = v_t_24237;
          break;
        }
        case TAG_CDouble: {
          v_t_24243 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str253);
          break;
        }
        case TAG_CBool: {
          v_t_24243 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str254);
          break;
        }
        case TAG_CString: {
          v_t_24243 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str255);
          break;
        }
        case TAG_CText: {
          v_t_24243 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str256);
          break;
        }
        case TAG_COwnedString: {
          v_t_24243 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str257);
          break;
        }
        case TAG_CPointer: {
          V v_t_24238 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24243 = heff_strAppend(v_t_24238, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str258));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24240 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24243 = heff_strAppend(v_t_24240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str259));
          break;
        }
        case TAG_CVoid: {
          v_t_24243 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str260);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24244 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str261), heff_strAppend(v_t_24243, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str262)));
        V v_t_24245 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str263), heff_strAppend(v_tag_240, v_t_24244));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24245});
      }
      case TAG_CSharedPointer: {
        V v_t_24255;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24249 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24255 = v_t_24249;
          break;
        }
        case TAG_CDouble: {
          v_t_24255 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str264);
          break;
        }
        case TAG_CBool: {
          v_t_24255 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str265);
          break;
        }
        case TAG_CString: {
          v_t_24255 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str266);
          break;
        }
        case TAG_CText: {
          v_t_24255 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str267);
          break;
        }
        case TAG_COwnedString: {
          v_t_24255 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str268);
          break;
        }
        case TAG_CPointer: {
          V v_t_24250 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24255 = heff_strAppend(v_t_24250, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str269));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24252 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24255 = heff_strAppend(v_t_24252, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str270));
          break;
        }
        case TAG_CVoid: {
          v_t_24255 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str271);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24256 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str272), heff_strAppend(v_t_24255, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str273)));
        V v_t_24257 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str274), heff_strAppend(v_tag_240, v_t_24256));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24257});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SSum: {
      heff_take_n(v_t_242, 0ULL, 1);
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24266;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24260 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24266 = v_t_24260;
          break;
        }
        case TAG_CDouble: {
          v_t_24266 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str275);
          break;
        }
        case TAG_CBool: {
          v_t_24266 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str276);
          break;
        }
        case TAG_CString: {
          v_t_24266 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str277);
          break;
        }
        case TAG_CText: {
          v_t_24266 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str278);
          break;
        }
        case TAG_COwnedString: {
          v_t_24266 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str279);
          break;
        }
        case TAG_CPointer: {
          V v_t_24261 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24266 = heff_strAppend(v_t_24261, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str280));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24263 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24266 = heff_strAppend(v_t_24263, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str281));
          break;
        }
        case TAG_CVoid: {
          v_t_24266 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str282);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24267 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str283), heff_strAppend(v_t_24266, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str284)));
        V v_t_24268 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str285), heff_strAppend(v_tag_240, v_t_24267));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24268});
      }
      case TAG_CDouble: {
        V v_t_24275;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24269 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24275 = v_t_24269;
          break;
        }
        case TAG_CDouble: {
          v_t_24275 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str286);
          break;
        }
        case TAG_CBool: {
          v_t_24275 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str287);
          break;
        }
        case TAG_CString: {
          v_t_24275 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str288);
          break;
        }
        case TAG_CText: {
          v_t_24275 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str289);
          break;
        }
        case TAG_COwnedString: {
          v_t_24275 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str290);
          break;
        }
        case TAG_CPointer: {
          V v_t_24270 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24275 = heff_strAppend(v_t_24270, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str291));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24272 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24275 = heff_strAppend(v_t_24272, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str292));
          break;
        }
        case TAG_CVoid: {
          v_t_24275 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str293);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24276 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str294), heff_strAppend(v_t_24275, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str295)));
        V v_t_24277 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str296), heff_strAppend(v_tag_240, v_t_24276));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24277});
      }
      case TAG_CBool: {
        V v_t_24284;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24278 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24284 = v_t_24278;
          break;
        }
        case TAG_CDouble: {
          v_t_24284 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str297);
          break;
        }
        case TAG_CBool: {
          v_t_24284 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str298);
          break;
        }
        case TAG_CString: {
          v_t_24284 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str299);
          break;
        }
        case TAG_CText: {
          v_t_24284 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str300);
          break;
        }
        case TAG_COwnedString: {
          v_t_24284 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str301);
          break;
        }
        case TAG_CPointer: {
          V v_t_24279 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24284 = heff_strAppend(v_t_24279, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str302));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24281 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24284 = heff_strAppend(v_t_24281, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str303));
          break;
        }
        case TAG_CVoid: {
          v_t_24284 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str304);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24285 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str305), heff_strAppend(v_t_24284, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str306)));
        V v_t_24286 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str307), heff_strAppend(v_tag_240, v_t_24285));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24286});
      }
      case TAG_CString: {
        V v_t_24293;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24287 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24293 = v_t_24287;
          break;
        }
        case TAG_CDouble: {
          v_t_24293 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str308);
          break;
        }
        case TAG_CBool: {
          v_t_24293 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str309);
          break;
        }
        case TAG_CString: {
          v_t_24293 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str310);
          break;
        }
        case TAG_CText: {
          v_t_24293 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str311);
          break;
        }
        case TAG_COwnedString: {
          v_t_24293 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str312);
          break;
        }
        case TAG_CPointer: {
          V v_t_24288 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24293 = heff_strAppend(v_t_24288, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str313));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24290 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24293 = heff_strAppend(v_t_24290, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str314));
          break;
        }
        case TAG_CVoid: {
          v_t_24293 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str315);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24294 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str316), heff_strAppend(v_t_24293, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str317)));
        V v_t_24295 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str318), heff_strAppend(v_tag_240, v_t_24294));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24295});
      }
      case TAG_CText: {
        V v_t_24302;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24296 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24302 = v_t_24296;
          break;
        }
        case TAG_CDouble: {
          v_t_24302 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str319);
          break;
        }
        case TAG_CBool: {
          v_t_24302 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str320);
          break;
        }
        case TAG_CString: {
          v_t_24302 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str321);
          break;
        }
        case TAG_CText: {
          v_t_24302 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str322);
          break;
        }
        case TAG_COwnedString: {
          v_t_24302 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str323);
          break;
        }
        case TAG_CPointer: {
          V v_t_24297 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24302 = heff_strAppend(v_t_24297, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str324));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24299 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24302 = heff_strAppend(v_t_24299, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str325));
          break;
        }
        case TAG_CVoid: {
          v_t_24302 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str326);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24303 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str327), heff_strAppend(v_t_24302, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str328)));
        V v_t_24304 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str329), heff_strAppend(v_tag_240, v_t_24303));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24304});
      }
      case TAG_COwnedString: {
        V v_t_24311;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24305 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24311 = v_t_24305;
          break;
        }
        case TAG_CDouble: {
          v_t_24311 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str330);
          break;
        }
        case TAG_CBool: {
          v_t_24311 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str331);
          break;
        }
        case TAG_CString: {
          v_t_24311 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str332);
          break;
        }
        case TAG_CText: {
          v_t_24311 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str333);
          break;
        }
        case TAG_COwnedString: {
          v_t_24311 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str334);
          break;
        }
        case TAG_CPointer: {
          V v_t_24306 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24311 = heff_strAppend(v_t_24306, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str335));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24308 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24311 = heff_strAppend(v_t_24308, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str336));
          break;
        }
        case TAG_CVoid: {
          v_t_24311 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str337);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24312 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str338), heff_strAppend(v_t_24311, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str339)));
        V v_t_24313 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str340), heff_strAppend(v_tag_240, v_t_24312));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24313});
      }
      case TAG_CPointer: {
        V v_t_24322;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24316 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24322 = v_t_24316;
          break;
        }
        case TAG_CDouble: {
          v_t_24322 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str341);
          break;
        }
        case TAG_CBool: {
          v_t_24322 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str342);
          break;
        }
        case TAG_CString: {
          v_t_24322 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str343);
          break;
        }
        case TAG_CText: {
          v_t_24322 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str344);
          break;
        }
        case TAG_COwnedString: {
          v_t_24322 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str345);
          break;
        }
        case TAG_CPointer: {
          V v_t_24317 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24322 = heff_strAppend(v_t_24317, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str346));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24319 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24322 = heff_strAppend(v_t_24319, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str347));
          break;
        }
        case TAG_CVoid: {
          v_t_24322 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str348);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24323 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str349), heff_strAppend(v_t_24322, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str350)));
        V v_t_24324 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str351), heff_strAppend(v_tag_240, v_t_24323));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24324});
      }
      case TAG_CSharedPointer: {
        V v_t_24334;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24328 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24334 = v_t_24328;
          break;
        }
        case TAG_CDouble: {
          v_t_24334 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str352);
          break;
        }
        case TAG_CBool: {
          v_t_24334 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str353);
          break;
        }
        case TAG_CString: {
          v_t_24334 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str354);
          break;
        }
        case TAG_CText: {
          v_t_24334 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str355);
          break;
        }
        case TAG_COwnedString: {
          v_t_24334 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str356);
          break;
        }
        case TAG_CPointer: {
          V v_t_24329 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24334 = heff_strAppend(v_t_24329, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str357));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24331 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24334 = heff_strAppend(v_t_24331, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str358));
          break;
        }
        case TAG_CVoid: {
          v_t_24334 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str359);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24335 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str360), heff_strAppend(v_t_24334, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str361)));
        V v_t_24336 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str362), heff_strAppend(v_tag_240, v_t_24335));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24336});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SIsTy: {
      heff_take_n(v_t_242, 0ULL, 1);
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24345;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24339 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24345 = v_t_24339;
          break;
        }
        case TAG_CDouble: {
          v_t_24345 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str363);
          break;
        }
        case TAG_CBool: {
          v_t_24345 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str364);
          break;
        }
        case TAG_CString: {
          v_t_24345 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str365);
          break;
        }
        case TAG_CText: {
          v_t_24345 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str366);
          break;
        }
        case TAG_COwnedString: {
          v_t_24345 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str367);
          break;
        }
        case TAG_CPointer: {
          V v_t_24340 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24345 = heff_strAppend(v_t_24340, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str368));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24342 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24345 = heff_strAppend(v_t_24342, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str369));
          break;
        }
        case TAG_CVoid: {
          v_t_24345 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str370);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24346 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str371), heff_strAppend(v_t_24345, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str372)));
        V v_t_24347 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str373), heff_strAppend(v_tag_240, v_t_24346));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24347});
      }
      case TAG_CDouble: {
        V v_t_24354;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24348 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24354 = v_t_24348;
          break;
        }
        case TAG_CDouble: {
          v_t_24354 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str374);
          break;
        }
        case TAG_CBool: {
          v_t_24354 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str375);
          break;
        }
        case TAG_CString: {
          v_t_24354 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str376);
          break;
        }
        case TAG_CText: {
          v_t_24354 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str377);
          break;
        }
        case TAG_COwnedString: {
          v_t_24354 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str378);
          break;
        }
        case TAG_CPointer: {
          V v_t_24349 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24354 = heff_strAppend(v_t_24349, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str379));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24351 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24354 = heff_strAppend(v_t_24351, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str380));
          break;
        }
        case TAG_CVoid: {
          v_t_24354 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str381);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24355 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str382), heff_strAppend(v_t_24354, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str383)));
        V v_t_24356 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str384), heff_strAppend(v_tag_240, v_t_24355));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24356});
      }
      case TAG_CBool: {
        V v_t_24363;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24357 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24363 = v_t_24357;
          break;
        }
        case TAG_CDouble: {
          v_t_24363 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str385);
          break;
        }
        case TAG_CBool: {
          v_t_24363 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str386);
          break;
        }
        case TAG_CString: {
          v_t_24363 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str387);
          break;
        }
        case TAG_CText: {
          v_t_24363 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str388);
          break;
        }
        case TAG_COwnedString: {
          v_t_24363 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str389);
          break;
        }
        case TAG_CPointer: {
          V v_t_24358 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24363 = heff_strAppend(v_t_24358, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str390));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24360 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24363 = heff_strAppend(v_t_24360, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str391));
          break;
        }
        case TAG_CVoid: {
          v_t_24363 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str392);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24364 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str393), heff_strAppend(v_t_24363, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str394)));
        V v_t_24365 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str395), heff_strAppend(v_tag_240, v_t_24364));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24365});
      }
      case TAG_CString: {
        V v_t_24372;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24366 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24372 = v_t_24366;
          break;
        }
        case TAG_CDouble: {
          v_t_24372 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str396);
          break;
        }
        case TAG_CBool: {
          v_t_24372 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str397);
          break;
        }
        case TAG_CString: {
          v_t_24372 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str398);
          break;
        }
        case TAG_CText: {
          v_t_24372 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str399);
          break;
        }
        case TAG_COwnedString: {
          v_t_24372 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str400);
          break;
        }
        case TAG_CPointer: {
          V v_t_24367 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24372 = heff_strAppend(v_t_24367, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str401));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24369 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24372 = heff_strAppend(v_t_24369, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str402));
          break;
        }
        case TAG_CVoid: {
          v_t_24372 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str403);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24373 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str404), heff_strAppend(v_t_24372, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str405)));
        V v_t_24374 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str406), heff_strAppend(v_tag_240, v_t_24373));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24374});
      }
      case TAG_CText: {
        V v_t_24381;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24375 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24381 = v_t_24375;
          break;
        }
        case TAG_CDouble: {
          v_t_24381 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str407);
          break;
        }
        case TAG_CBool: {
          v_t_24381 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str408);
          break;
        }
        case TAG_CString: {
          v_t_24381 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str409);
          break;
        }
        case TAG_CText: {
          v_t_24381 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str410);
          break;
        }
        case TAG_COwnedString: {
          v_t_24381 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str411);
          break;
        }
        case TAG_CPointer: {
          V v_t_24376 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24381 = heff_strAppend(v_t_24376, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str412));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24378 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24381 = heff_strAppend(v_t_24378, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str413));
          break;
        }
        case TAG_CVoid: {
          v_t_24381 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str414);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24382 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str415), heff_strAppend(v_t_24381, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str416)));
        V v_t_24383 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str417), heff_strAppend(v_tag_240, v_t_24382));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24383});
      }
      case TAG_COwnedString: {
        V v_t_24390;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24384 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24390 = v_t_24384;
          break;
        }
        case TAG_CDouble: {
          v_t_24390 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str418);
          break;
        }
        case TAG_CBool: {
          v_t_24390 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str419);
          break;
        }
        case TAG_CString: {
          v_t_24390 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str420);
          break;
        }
        case TAG_CText: {
          v_t_24390 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str421);
          break;
        }
        case TAG_COwnedString: {
          v_t_24390 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str422);
          break;
        }
        case TAG_CPointer: {
          V v_t_24385 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24390 = heff_strAppend(v_t_24385, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str423));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24387 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24390 = heff_strAppend(v_t_24387, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str424));
          break;
        }
        case TAG_CVoid: {
          v_t_24390 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str425);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24391 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str426), heff_strAppend(v_t_24390, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str427)));
        V v_t_24392 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str428), heff_strAppend(v_tag_240, v_t_24391));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24392});
      }
      case TAG_CPointer: {
        V v_t_24401;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24395 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24401 = v_t_24395;
          break;
        }
        case TAG_CDouble: {
          v_t_24401 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str429);
          break;
        }
        case TAG_CBool: {
          v_t_24401 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str430);
          break;
        }
        case TAG_CString: {
          v_t_24401 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str431);
          break;
        }
        case TAG_CText: {
          v_t_24401 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str432);
          break;
        }
        case TAG_COwnedString: {
          v_t_24401 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str433);
          break;
        }
        case TAG_CPointer: {
          V v_t_24396 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24401 = heff_strAppend(v_t_24396, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str434));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24398 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24401 = heff_strAppend(v_t_24398, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str435));
          break;
        }
        case TAG_CVoid: {
          v_t_24401 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str436);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24402 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str437), heff_strAppend(v_t_24401, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str438)));
        V v_t_24403 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str439), heff_strAppend(v_tag_240, v_t_24402));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24403});
      }
      case TAG_CSharedPointer: {
        V v_t_24413;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24407 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24413 = v_t_24407;
          break;
        }
        case TAG_CDouble: {
          v_t_24413 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str440);
          break;
        }
        case TAG_CBool: {
          v_t_24413 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str441);
          break;
        }
        case TAG_CString: {
          v_t_24413 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str442);
          break;
        }
        case TAG_CText: {
          v_t_24413 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str443);
          break;
        }
        case TAG_COwnedString: {
          v_t_24413 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str444);
          break;
        }
        case TAG_CPointer: {
          V v_t_24408 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24413 = heff_strAppend(v_t_24408, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str445));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24410 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24413 = heff_strAppend(v_t_24410, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str446));
          break;
        }
        case TAG_CVoid: {
          v_t_24413 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str447);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24414 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str448), heff_strAppend(v_t_24413, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str449)));
        V v_t_24415 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str450), heff_strAppend(v_tag_240, v_t_24414));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24415});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SPrimInt: {
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24423;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24417 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24423 = v_t_24417;
          break;
        }
        case TAG_CDouble: {
          v_t_24423 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str451);
          break;
        }
        case TAG_CBool: {
          v_t_24423 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str452);
          break;
        }
        case TAG_CString: {
          v_t_24423 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str453);
          break;
        }
        case TAG_CText: {
          v_t_24423 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str454);
          break;
        }
        case TAG_COwnedString: {
          v_t_24423 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str455);
          break;
        }
        case TAG_CPointer: {
          V v_t_24418 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24423 = heff_strAppend(v_t_24418, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str456));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24420 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24423 = heff_strAppend(v_t_24420, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str457));
          break;
        }
        case TAG_CVoid: {
          v_t_24423 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str458);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24424 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str459), heff_strAppend(v_t_24423, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str460)));
        V v_t_24425 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str461), heff_strAppend(v_tag_240, v_t_24424));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24425});
      }
      case TAG_CDouble: {
        V v_t_24432;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24426 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24432 = v_t_24426;
          break;
        }
        case TAG_CDouble: {
          v_t_24432 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str462);
          break;
        }
        case TAG_CBool: {
          v_t_24432 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str463);
          break;
        }
        case TAG_CString: {
          v_t_24432 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str464);
          break;
        }
        case TAG_CText: {
          v_t_24432 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str465);
          break;
        }
        case TAG_COwnedString: {
          v_t_24432 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str466);
          break;
        }
        case TAG_CPointer: {
          V v_t_24427 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24432 = heff_strAppend(v_t_24427, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str467));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24429 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24432 = heff_strAppend(v_t_24429, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str468));
          break;
        }
        case TAG_CVoid: {
          v_t_24432 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str469);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24433 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str470), heff_strAppend(v_t_24432, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str471)));
        V v_t_24434 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str472), heff_strAppend(v_tag_240, v_t_24433));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24434});
      }
      case TAG_CBool: {
        V v_t_24441;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24435 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24441 = v_t_24435;
          break;
        }
        case TAG_CDouble: {
          v_t_24441 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str473);
          break;
        }
        case TAG_CBool: {
          v_t_24441 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str474);
          break;
        }
        case TAG_CString: {
          v_t_24441 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str475);
          break;
        }
        case TAG_CText: {
          v_t_24441 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str476);
          break;
        }
        case TAG_COwnedString: {
          v_t_24441 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str477);
          break;
        }
        case TAG_CPointer: {
          V v_t_24436 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24441 = heff_strAppend(v_t_24436, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str478));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24438 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24441 = heff_strAppend(v_t_24438, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str479));
          break;
        }
        case TAG_CVoid: {
          v_t_24441 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str480);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24442 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str481), heff_strAppend(v_t_24441, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str482)));
        V v_t_24443 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str483), heff_strAppend(v_tag_240, v_t_24442));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24443});
      }
      case TAG_CString: {
        V v_t_24450;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24444 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24450 = v_t_24444;
          break;
        }
        case TAG_CDouble: {
          v_t_24450 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str484);
          break;
        }
        case TAG_CBool: {
          v_t_24450 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str485);
          break;
        }
        case TAG_CString: {
          v_t_24450 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str486);
          break;
        }
        case TAG_CText: {
          v_t_24450 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str487);
          break;
        }
        case TAG_COwnedString: {
          v_t_24450 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str488);
          break;
        }
        case TAG_CPointer: {
          V v_t_24445 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24450 = heff_strAppend(v_t_24445, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str489));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24447 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24450 = heff_strAppend(v_t_24447, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str490));
          break;
        }
        case TAG_CVoid: {
          v_t_24450 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str491);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24451 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str492), heff_strAppend(v_t_24450, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str493)));
        V v_t_24452 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str494), heff_strAppend(v_tag_240, v_t_24451));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24452});
      }
      case TAG_CText: {
        V v_t_24459;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24453 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24459 = v_t_24453;
          break;
        }
        case TAG_CDouble: {
          v_t_24459 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str495);
          break;
        }
        case TAG_CBool: {
          v_t_24459 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str496);
          break;
        }
        case TAG_CString: {
          v_t_24459 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str497);
          break;
        }
        case TAG_CText: {
          v_t_24459 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str498);
          break;
        }
        case TAG_COwnedString: {
          v_t_24459 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str499);
          break;
        }
        case TAG_CPointer: {
          V v_t_24454 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24459 = heff_strAppend(v_t_24454, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str500));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24456 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24459 = heff_strAppend(v_t_24456, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str501));
          break;
        }
        case TAG_CVoid: {
          v_t_24459 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str502);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24460 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str503), heff_strAppend(v_t_24459, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str504)));
        V v_t_24461 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str505), heff_strAppend(v_tag_240, v_t_24460));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24461});
      }
      case TAG_COwnedString: {
        V v_t_24468;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24462 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24468 = v_t_24462;
          break;
        }
        case TAG_CDouble: {
          v_t_24468 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str506);
          break;
        }
        case TAG_CBool: {
          v_t_24468 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str507);
          break;
        }
        case TAG_CString: {
          v_t_24468 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str508);
          break;
        }
        case TAG_CText: {
          v_t_24468 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str509);
          break;
        }
        case TAG_COwnedString: {
          v_t_24468 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str510);
          break;
        }
        case TAG_CPointer: {
          V v_t_24463 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24468 = heff_strAppend(v_t_24463, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str511));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24465 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24468 = heff_strAppend(v_t_24465, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str512));
          break;
        }
        case TAG_CVoid: {
          v_t_24468 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str513);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24469 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str514), heff_strAppend(v_t_24468, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str515)));
        V v_t_24470 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str516), heff_strAppend(v_tag_240, v_t_24469));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24470});
      }
      case TAG_CPointer: {
        V v_t_24479;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24473 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24479 = v_t_24473;
          break;
        }
        case TAG_CDouble: {
          v_t_24479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str517);
          break;
        }
        case TAG_CBool: {
          v_t_24479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str518);
          break;
        }
        case TAG_CString: {
          v_t_24479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str519);
          break;
        }
        case TAG_CText: {
          v_t_24479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str520);
          break;
        }
        case TAG_COwnedString: {
          v_t_24479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str521);
          break;
        }
        case TAG_CPointer: {
          V v_t_24474 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24479 = heff_strAppend(v_t_24474, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str522));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24476 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24479 = heff_strAppend(v_t_24476, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str523));
          break;
        }
        case TAG_CVoid: {
          v_t_24479 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str524);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24480 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str525), heff_strAppend(v_t_24479, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str526)));
        V v_t_24481 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str527), heff_strAppend(v_tag_240, v_t_24480));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24481});
      }
      case TAG_CSharedPointer: {
        V v_t_24491;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24485 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24491 = v_t_24485;
          break;
        }
        case TAG_CDouble: {
          v_t_24491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str528);
          break;
        }
        case TAG_CBool: {
          v_t_24491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str529);
          break;
        }
        case TAG_CString: {
          v_t_24491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str530);
          break;
        }
        case TAG_CText: {
          v_t_24491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str531);
          break;
        }
        case TAG_COwnedString: {
          v_t_24491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str532);
          break;
        }
        case TAG_CPointer: {
          V v_t_24486 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24491 = heff_strAppend(v_t_24486, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str533));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24488 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24491 = heff_strAppend(v_t_24488, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str534));
          break;
        }
        case TAG_CVoid: {
          v_t_24491 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str535);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24492 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str536), heff_strAppend(v_t_24491, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str537)));
        V v_t_24493 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str538), heff_strAppend(v_tag_240, v_t_24492));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24493});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SPrimFloat: {
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24501;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24495 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24501 = v_t_24495;
          break;
        }
        case TAG_CDouble: {
          v_t_24501 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str539);
          break;
        }
        case TAG_CBool: {
          v_t_24501 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str540);
          break;
        }
        case TAG_CString: {
          v_t_24501 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str541);
          break;
        }
        case TAG_CText: {
          v_t_24501 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str542);
          break;
        }
        case TAG_COwnedString: {
          v_t_24501 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str543);
          break;
        }
        case TAG_CPointer: {
          V v_t_24496 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24501 = heff_strAppend(v_t_24496, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str544));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24498 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24501 = heff_strAppend(v_t_24498, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str545));
          break;
        }
        case TAG_CVoid: {
          v_t_24501 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str546);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24502 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str547), heff_strAppend(v_t_24501, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str548)));
        V v_t_24503 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str549), heff_strAppend(v_tag_240, v_t_24502));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24503});
      }
      case TAG_CDouble: {
        V v_t_24510;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24504 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24510 = v_t_24504;
          break;
        }
        case TAG_CDouble: {
          v_t_24510 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str550);
          break;
        }
        case TAG_CBool: {
          v_t_24510 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str551);
          break;
        }
        case TAG_CString: {
          v_t_24510 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str552);
          break;
        }
        case TAG_CText: {
          v_t_24510 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str553);
          break;
        }
        case TAG_COwnedString: {
          v_t_24510 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str554);
          break;
        }
        case TAG_CPointer: {
          V v_t_24505 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24510 = heff_strAppend(v_t_24505, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str555));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24507 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24510 = heff_strAppend(v_t_24507, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str556));
          break;
        }
        case TAG_CVoid: {
          v_t_24510 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str557);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24511 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str558), heff_strAppend(v_t_24510, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str559)));
        V v_t_24512 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str560), heff_strAppend(v_tag_240, v_t_24511));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24512});
      }
      case TAG_CBool: {
        V v_t_24519;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24513 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24519 = v_t_24513;
          break;
        }
        case TAG_CDouble: {
          v_t_24519 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str561);
          break;
        }
        case TAG_CBool: {
          v_t_24519 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str562);
          break;
        }
        case TAG_CString: {
          v_t_24519 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str563);
          break;
        }
        case TAG_CText: {
          v_t_24519 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str564);
          break;
        }
        case TAG_COwnedString: {
          v_t_24519 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str565);
          break;
        }
        case TAG_CPointer: {
          V v_t_24514 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24519 = heff_strAppend(v_t_24514, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str566));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24516 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24519 = heff_strAppend(v_t_24516, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str567));
          break;
        }
        case TAG_CVoid: {
          v_t_24519 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str568);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24520 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str569), heff_strAppend(v_t_24519, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str570)));
        V v_t_24521 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str571), heff_strAppend(v_tag_240, v_t_24520));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24521});
      }
      case TAG_CString: {
        V v_t_24528;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24522 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24528 = v_t_24522;
          break;
        }
        case TAG_CDouble: {
          v_t_24528 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str572);
          break;
        }
        case TAG_CBool: {
          v_t_24528 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str573);
          break;
        }
        case TAG_CString: {
          v_t_24528 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str574);
          break;
        }
        case TAG_CText: {
          v_t_24528 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str575);
          break;
        }
        case TAG_COwnedString: {
          v_t_24528 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str576);
          break;
        }
        case TAG_CPointer: {
          V v_t_24523 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24528 = heff_strAppend(v_t_24523, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str577));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24525 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24528 = heff_strAppend(v_t_24525, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str578));
          break;
        }
        case TAG_CVoid: {
          v_t_24528 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str579);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24529 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str580), heff_strAppend(v_t_24528, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str581)));
        V v_t_24530 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str582), heff_strAppend(v_tag_240, v_t_24529));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24530});
      }
      case TAG_CText: {
        V v_t_24537;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24531 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24537 = v_t_24531;
          break;
        }
        case TAG_CDouble: {
          v_t_24537 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str583);
          break;
        }
        case TAG_CBool: {
          v_t_24537 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str584);
          break;
        }
        case TAG_CString: {
          v_t_24537 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str585);
          break;
        }
        case TAG_CText: {
          v_t_24537 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str586);
          break;
        }
        case TAG_COwnedString: {
          v_t_24537 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str587);
          break;
        }
        case TAG_CPointer: {
          V v_t_24532 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24537 = heff_strAppend(v_t_24532, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str588));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24534 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24537 = heff_strAppend(v_t_24534, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str589));
          break;
        }
        case TAG_CVoid: {
          v_t_24537 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str590);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24538 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str591), heff_strAppend(v_t_24537, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str592)));
        V v_t_24539 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str593), heff_strAppend(v_tag_240, v_t_24538));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24539});
      }
      case TAG_COwnedString: {
        V v_t_24546;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24540 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24546 = v_t_24540;
          break;
        }
        case TAG_CDouble: {
          v_t_24546 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str594);
          break;
        }
        case TAG_CBool: {
          v_t_24546 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str595);
          break;
        }
        case TAG_CString: {
          v_t_24546 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str596);
          break;
        }
        case TAG_CText: {
          v_t_24546 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str597);
          break;
        }
        case TAG_COwnedString: {
          v_t_24546 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str598);
          break;
        }
        case TAG_CPointer: {
          V v_t_24541 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24546 = heff_strAppend(v_t_24541, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str599));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24543 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24546 = heff_strAppend(v_t_24543, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str600));
          break;
        }
        case TAG_CVoid: {
          v_t_24546 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str601);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24547 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str602), heff_strAppend(v_t_24546, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str603)));
        V v_t_24548 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str604), heff_strAppend(v_tag_240, v_t_24547));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24548});
      }
      case TAG_CPointer: {
        V v_t_24557;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24551 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24557 = v_t_24551;
          break;
        }
        case TAG_CDouble: {
          v_t_24557 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str605);
          break;
        }
        case TAG_CBool: {
          v_t_24557 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str606);
          break;
        }
        case TAG_CString: {
          v_t_24557 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str607);
          break;
        }
        case TAG_CText: {
          v_t_24557 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str608);
          break;
        }
        case TAG_COwnedString: {
          v_t_24557 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str609);
          break;
        }
        case TAG_CPointer: {
          V v_t_24552 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24557 = heff_strAppend(v_t_24552, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str610));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24554 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24557 = heff_strAppend(v_t_24554, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str611));
          break;
        }
        case TAG_CVoid: {
          v_t_24557 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str612);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24558 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str613), heff_strAppend(v_t_24557, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str614)));
        V v_t_24559 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str615), heff_strAppend(v_tag_240, v_t_24558));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24559});
      }
      case TAG_CSharedPointer: {
        V v_t_24569;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24563 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24569 = v_t_24563;
          break;
        }
        case TAG_CDouble: {
          v_t_24569 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str616);
          break;
        }
        case TAG_CBool: {
          v_t_24569 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str617);
          break;
        }
        case TAG_CString: {
          v_t_24569 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str618);
          break;
        }
        case TAG_CText: {
          v_t_24569 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str619);
          break;
        }
        case TAG_COwnedString: {
          v_t_24569 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str620);
          break;
        }
        case TAG_CPointer: {
          V v_t_24564 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24569 = heff_strAppend(v_t_24564, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str621));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24566 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24569 = heff_strAppend(v_t_24566, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str622));
          break;
        }
        case TAG_CVoid: {
          v_t_24569 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str623);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24570 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str624), heff_strAppend(v_t_24569, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str625)));
        V v_t_24571 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str626), heff_strAppend(v_tag_240, v_t_24570));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24571});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SPrimString: {
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24579;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24573 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24579 = v_t_24573;
          break;
        }
        case TAG_CDouble: {
          v_t_24579 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str627);
          break;
        }
        case TAG_CBool: {
          v_t_24579 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str628);
          break;
        }
        case TAG_CString: {
          v_t_24579 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str629);
          break;
        }
        case TAG_CText: {
          v_t_24579 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str630);
          break;
        }
        case TAG_COwnedString: {
          v_t_24579 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str631);
          break;
        }
        case TAG_CPointer: {
          V v_t_24574 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24579 = heff_strAppend(v_t_24574, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str632));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24576 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24579 = heff_strAppend(v_t_24576, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str633));
          break;
        }
        case TAG_CVoid: {
          v_t_24579 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str634);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24580 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str635), heff_strAppend(v_t_24579, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str636)));
        V v_t_24581 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str637), heff_strAppend(v_tag_240, v_t_24580));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24581});
      }
      case TAG_CDouble: {
        V v_t_24588;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24582 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24588 = v_t_24582;
          break;
        }
        case TAG_CDouble: {
          v_t_24588 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str638);
          break;
        }
        case TAG_CBool: {
          v_t_24588 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str639);
          break;
        }
        case TAG_CString: {
          v_t_24588 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str640);
          break;
        }
        case TAG_CText: {
          v_t_24588 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str641);
          break;
        }
        case TAG_COwnedString: {
          v_t_24588 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str642);
          break;
        }
        case TAG_CPointer: {
          V v_t_24583 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24588 = heff_strAppend(v_t_24583, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str643));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24585 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24588 = heff_strAppend(v_t_24585, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str644));
          break;
        }
        case TAG_CVoid: {
          v_t_24588 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str645);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24589 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str646), heff_strAppend(v_t_24588, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str647)));
        V v_t_24590 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str648), heff_strAppend(v_tag_240, v_t_24589));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24590});
      }
      case TAG_CBool: {
        V v_t_24597;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24591 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24597 = v_t_24591;
          break;
        }
        case TAG_CDouble: {
          v_t_24597 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str649);
          break;
        }
        case TAG_CBool: {
          v_t_24597 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str650);
          break;
        }
        case TAG_CString: {
          v_t_24597 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str651);
          break;
        }
        case TAG_CText: {
          v_t_24597 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str652);
          break;
        }
        case TAG_COwnedString: {
          v_t_24597 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str653);
          break;
        }
        case TAG_CPointer: {
          V v_t_24592 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24597 = heff_strAppend(v_t_24592, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str654));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24594 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24597 = heff_strAppend(v_t_24594, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str655));
          break;
        }
        case TAG_CVoid: {
          v_t_24597 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str656);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24598 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str657), heff_strAppend(v_t_24597, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str658)));
        V v_t_24599 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str659), heff_strAppend(v_tag_240, v_t_24598));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24599});
      }
      case TAG_CString: {
        V v_t_24606;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24600 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24606 = v_t_24600;
          break;
        }
        case TAG_CDouble: {
          v_t_24606 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str660);
          break;
        }
        case TAG_CBool: {
          v_t_24606 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str661);
          break;
        }
        case TAG_CString: {
          v_t_24606 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str662);
          break;
        }
        case TAG_CText: {
          v_t_24606 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str663);
          break;
        }
        case TAG_COwnedString: {
          v_t_24606 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str664);
          break;
        }
        case TAG_CPointer: {
          V v_t_24601 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24606 = heff_strAppend(v_t_24601, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str665));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24603 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24606 = heff_strAppend(v_t_24603, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str666));
          break;
        }
        case TAG_CVoid: {
          v_t_24606 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str667);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24607 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str668), heff_strAppend(v_t_24606, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str669)));
        V v_t_24608 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str670), heff_strAppend(v_tag_240, v_t_24607));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24608});
      }
      case TAG_CText: {
        V v_t_24615;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24609 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24615 = v_t_24609;
          break;
        }
        case TAG_CDouble: {
          v_t_24615 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str671);
          break;
        }
        case TAG_CBool: {
          v_t_24615 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str672);
          break;
        }
        case TAG_CString: {
          v_t_24615 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str673);
          break;
        }
        case TAG_CText: {
          v_t_24615 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str674);
          break;
        }
        case TAG_COwnedString: {
          v_t_24615 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str675);
          break;
        }
        case TAG_CPointer: {
          V v_t_24610 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24615 = heff_strAppend(v_t_24610, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str676));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24612 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24615 = heff_strAppend(v_t_24612, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str677));
          break;
        }
        case TAG_CVoid: {
          v_t_24615 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str678);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24616 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str679), heff_strAppend(v_t_24615, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str680)));
        V v_t_24617 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str681), heff_strAppend(v_tag_240, v_t_24616));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24617});
      }
      case TAG_COwnedString: {
        V v_t_24624;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24618 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24624 = v_t_24618;
          break;
        }
        case TAG_CDouble: {
          v_t_24624 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str682);
          break;
        }
        case TAG_CBool: {
          v_t_24624 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str683);
          break;
        }
        case TAG_CString: {
          v_t_24624 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str684);
          break;
        }
        case TAG_CText: {
          v_t_24624 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str685);
          break;
        }
        case TAG_COwnedString: {
          v_t_24624 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str686);
          break;
        }
        case TAG_CPointer: {
          V v_t_24619 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24624 = heff_strAppend(v_t_24619, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str687));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24621 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24624 = heff_strAppend(v_t_24621, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str688));
          break;
        }
        case TAG_CVoid: {
          v_t_24624 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str689);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24625 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str690), heff_strAppend(v_t_24624, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str691)));
        V v_t_24626 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str692), heff_strAppend(v_tag_240, v_t_24625));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24626});
      }
      case TAG_CPointer: {
        V v_t_24635;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24629 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24635 = v_t_24629;
          break;
        }
        case TAG_CDouble: {
          v_t_24635 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str693);
          break;
        }
        case TAG_CBool: {
          v_t_24635 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str694);
          break;
        }
        case TAG_CString: {
          v_t_24635 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str695);
          break;
        }
        case TAG_CText: {
          v_t_24635 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str696);
          break;
        }
        case TAG_COwnedString: {
          v_t_24635 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str697);
          break;
        }
        case TAG_CPointer: {
          V v_t_24630 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24635 = heff_strAppend(v_t_24630, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str698));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24632 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24635 = heff_strAppend(v_t_24632, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str699));
          break;
        }
        case TAG_CVoid: {
          v_t_24635 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str700);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24636 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str701), heff_strAppend(v_t_24635, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str702)));
        V v_t_24637 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str703), heff_strAppend(v_tag_240, v_t_24636));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24637});
      }
      case TAG_CSharedPointer: {
        V v_t_24647;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24641 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24647 = v_t_24641;
          break;
        }
        case TAG_CDouble: {
          v_t_24647 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str704);
          break;
        }
        case TAG_CBool: {
          v_t_24647 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str705);
          break;
        }
        case TAG_CString: {
          v_t_24647 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str706);
          break;
        }
        case TAG_CText: {
          v_t_24647 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str707);
          break;
        }
        case TAG_COwnedString: {
          v_t_24647 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str708);
          break;
        }
        case TAG_CPointer: {
          V v_t_24642 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24647 = heff_strAppend(v_t_24642, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str709));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24644 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24647 = heff_strAppend(v_t_24644, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str710));
          break;
        }
        case TAG_CVoid: {
          v_t_24647 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str711);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24648 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str712), heff_strAppend(v_t_24647, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str713)));
        V v_t_24649 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str714), heff_strAppend(v_tag_240, v_t_24648));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24649});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SPrimRune: {
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24657;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24651 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24657 = v_t_24651;
          break;
        }
        case TAG_CDouble: {
          v_t_24657 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str715);
          break;
        }
        case TAG_CBool: {
          v_t_24657 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str716);
          break;
        }
        case TAG_CString: {
          v_t_24657 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str717);
          break;
        }
        case TAG_CText: {
          v_t_24657 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str718);
          break;
        }
        case TAG_COwnedString: {
          v_t_24657 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str719);
          break;
        }
        case TAG_CPointer: {
          V v_t_24652 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24657 = heff_strAppend(v_t_24652, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str720));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24654 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24657 = heff_strAppend(v_t_24654, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str721));
          break;
        }
        case TAG_CVoid: {
          v_t_24657 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str722);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24658 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str723), heff_strAppend(v_t_24657, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str724)));
        V v_t_24659 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str725), heff_strAppend(v_tag_240, v_t_24658));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24659});
      }
      case TAG_CDouble: {
        V v_t_24666;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24660 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24666 = v_t_24660;
          break;
        }
        case TAG_CDouble: {
          v_t_24666 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str726);
          break;
        }
        case TAG_CBool: {
          v_t_24666 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str727);
          break;
        }
        case TAG_CString: {
          v_t_24666 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str728);
          break;
        }
        case TAG_CText: {
          v_t_24666 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str729);
          break;
        }
        case TAG_COwnedString: {
          v_t_24666 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str730);
          break;
        }
        case TAG_CPointer: {
          V v_t_24661 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24666 = heff_strAppend(v_t_24661, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str731));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24663 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24666 = heff_strAppend(v_t_24663, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str732));
          break;
        }
        case TAG_CVoid: {
          v_t_24666 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str733);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24667 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str734), heff_strAppend(v_t_24666, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str735)));
        V v_t_24668 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str736), heff_strAppend(v_tag_240, v_t_24667));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24668});
      }
      case TAG_CBool: {
        V v_t_24675;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24669 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24675 = v_t_24669;
          break;
        }
        case TAG_CDouble: {
          v_t_24675 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str737);
          break;
        }
        case TAG_CBool: {
          v_t_24675 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str738);
          break;
        }
        case TAG_CString: {
          v_t_24675 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str739);
          break;
        }
        case TAG_CText: {
          v_t_24675 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str740);
          break;
        }
        case TAG_COwnedString: {
          v_t_24675 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str741);
          break;
        }
        case TAG_CPointer: {
          V v_t_24670 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24675 = heff_strAppend(v_t_24670, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str742));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24672 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24675 = heff_strAppend(v_t_24672, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str743));
          break;
        }
        case TAG_CVoid: {
          v_t_24675 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str744);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24676 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str745), heff_strAppend(v_t_24675, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str746)));
        V v_t_24677 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str747), heff_strAppend(v_tag_240, v_t_24676));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24677});
      }
      case TAG_CString: {
        V v_t_24684;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24678 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24684 = v_t_24678;
          break;
        }
        case TAG_CDouble: {
          v_t_24684 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str748);
          break;
        }
        case TAG_CBool: {
          v_t_24684 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str749);
          break;
        }
        case TAG_CString: {
          v_t_24684 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str750);
          break;
        }
        case TAG_CText: {
          v_t_24684 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str751);
          break;
        }
        case TAG_COwnedString: {
          v_t_24684 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str752);
          break;
        }
        case TAG_CPointer: {
          V v_t_24679 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24684 = heff_strAppend(v_t_24679, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str753));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24681 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24684 = heff_strAppend(v_t_24681, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str754));
          break;
        }
        case TAG_CVoid: {
          v_t_24684 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str755);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24685 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str756), heff_strAppend(v_t_24684, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str757)));
        V v_t_24686 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str758), heff_strAppend(v_tag_240, v_t_24685));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24686});
      }
      case TAG_CText: {
        V v_t_24693;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24687 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24693 = v_t_24687;
          break;
        }
        case TAG_CDouble: {
          v_t_24693 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str759);
          break;
        }
        case TAG_CBool: {
          v_t_24693 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str760);
          break;
        }
        case TAG_CString: {
          v_t_24693 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str761);
          break;
        }
        case TAG_CText: {
          v_t_24693 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str762);
          break;
        }
        case TAG_COwnedString: {
          v_t_24693 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str763);
          break;
        }
        case TAG_CPointer: {
          V v_t_24688 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24693 = heff_strAppend(v_t_24688, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str764));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24690 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24693 = heff_strAppend(v_t_24690, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str765));
          break;
        }
        case TAG_CVoid: {
          v_t_24693 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str766);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24694 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str767), heff_strAppend(v_t_24693, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str768)));
        V v_t_24695 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str769), heff_strAppend(v_tag_240, v_t_24694));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24695});
      }
      case TAG_COwnedString: {
        V v_t_24702;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24696 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24702 = v_t_24696;
          break;
        }
        case TAG_CDouble: {
          v_t_24702 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str770);
          break;
        }
        case TAG_CBool: {
          v_t_24702 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str771);
          break;
        }
        case TAG_CString: {
          v_t_24702 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str772);
          break;
        }
        case TAG_CText: {
          v_t_24702 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str773);
          break;
        }
        case TAG_COwnedString: {
          v_t_24702 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str774);
          break;
        }
        case TAG_CPointer: {
          V v_t_24697 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24702 = heff_strAppend(v_t_24697, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str775));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24699 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24702 = heff_strAppend(v_t_24699, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str776));
          break;
        }
        case TAG_CVoid: {
          v_t_24702 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str777);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24703 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str778), heff_strAppend(v_t_24702, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str779)));
        V v_t_24704 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str780), heff_strAppend(v_tag_240, v_t_24703));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24704});
      }
      case TAG_CPointer: {
        V v_t_24713;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24707 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24713 = v_t_24707;
          break;
        }
        case TAG_CDouble: {
          v_t_24713 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str781);
          break;
        }
        case TAG_CBool: {
          v_t_24713 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str782);
          break;
        }
        case TAG_CString: {
          v_t_24713 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str783);
          break;
        }
        case TAG_CText: {
          v_t_24713 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str784);
          break;
        }
        case TAG_COwnedString: {
          v_t_24713 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str785);
          break;
        }
        case TAG_CPointer: {
          V v_t_24708 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24713 = heff_strAppend(v_t_24708, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str786));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24710 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24713 = heff_strAppend(v_t_24710, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str787));
          break;
        }
        case TAG_CVoid: {
          v_t_24713 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str788);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24714 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str789), heff_strAppend(v_t_24713, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str790)));
        V v_t_24715 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str791), heff_strAppend(v_tag_240, v_t_24714));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24715});
      }
      case TAG_CSharedPointer: {
        V v_t_24725;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24719 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24725 = v_t_24719;
          break;
        }
        case TAG_CDouble: {
          v_t_24725 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str792);
          break;
        }
        case TAG_CBool: {
          v_t_24725 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str793);
          break;
        }
        case TAG_CString: {
          v_t_24725 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str794);
          break;
        }
        case TAG_CText: {
          v_t_24725 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str795);
          break;
        }
        case TAG_COwnedString: {
          v_t_24725 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str796);
          break;
        }
        case TAG_CPointer: {
          V v_t_24720 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24725 = heff_strAppend(v_t_24720, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str797));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24722 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24725 = heff_strAppend(v_t_24722, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str798));
          break;
        }
        case TAG_CVoid: {
          v_t_24725 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str799);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24726 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str800), heff_strAppend(v_t_24725, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str801)));
        V v_t_24727 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str802), heff_strAppend(v_tag_240, v_t_24726));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24727});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SPrimArray: {
      heff_take_n(v_t_242, 0ULL, 1);
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24736;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24730 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24736 = v_t_24730;
          break;
        }
        case TAG_CDouble: {
          v_t_24736 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str803);
          break;
        }
        case TAG_CBool: {
          v_t_24736 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str804);
          break;
        }
        case TAG_CString: {
          v_t_24736 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str805);
          break;
        }
        case TAG_CText: {
          v_t_24736 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str806);
          break;
        }
        case TAG_COwnedString: {
          v_t_24736 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str807);
          break;
        }
        case TAG_CPointer: {
          V v_t_24731 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24736 = heff_strAppend(v_t_24731, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str808));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24733 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24736 = heff_strAppend(v_t_24733, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str809));
          break;
        }
        case TAG_CVoid: {
          v_t_24736 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str810);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24737 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str811), heff_strAppend(v_t_24736, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str812)));
        V v_t_24738 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str813), heff_strAppend(v_tag_240, v_t_24737));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24738});
      }
      case TAG_CDouble: {
        V v_t_24745;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24739 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24745 = v_t_24739;
          break;
        }
        case TAG_CDouble: {
          v_t_24745 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str814);
          break;
        }
        case TAG_CBool: {
          v_t_24745 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str815);
          break;
        }
        case TAG_CString: {
          v_t_24745 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str816);
          break;
        }
        case TAG_CText: {
          v_t_24745 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str817);
          break;
        }
        case TAG_COwnedString: {
          v_t_24745 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str818);
          break;
        }
        case TAG_CPointer: {
          V v_t_24740 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24745 = heff_strAppend(v_t_24740, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str819));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24742 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24745 = heff_strAppend(v_t_24742, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str820));
          break;
        }
        case TAG_CVoid: {
          v_t_24745 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str821);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24746 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str822), heff_strAppend(v_t_24745, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str823)));
        V v_t_24747 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str824), heff_strAppend(v_tag_240, v_t_24746));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24747});
      }
      case TAG_CBool: {
        V v_t_24754;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24748 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24754 = v_t_24748;
          break;
        }
        case TAG_CDouble: {
          v_t_24754 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str825);
          break;
        }
        case TAG_CBool: {
          v_t_24754 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str826);
          break;
        }
        case TAG_CString: {
          v_t_24754 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str827);
          break;
        }
        case TAG_CText: {
          v_t_24754 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str828);
          break;
        }
        case TAG_COwnedString: {
          v_t_24754 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str829);
          break;
        }
        case TAG_CPointer: {
          V v_t_24749 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24754 = heff_strAppend(v_t_24749, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str830));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24751 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24754 = heff_strAppend(v_t_24751, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str831));
          break;
        }
        case TAG_CVoid: {
          v_t_24754 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str832);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24755 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str833), heff_strAppend(v_t_24754, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str834)));
        V v_t_24756 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str835), heff_strAppend(v_tag_240, v_t_24755));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24756});
      }
      case TAG_CString: {
        V v_t_24763;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24757 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24763 = v_t_24757;
          break;
        }
        case TAG_CDouble: {
          v_t_24763 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str836);
          break;
        }
        case TAG_CBool: {
          v_t_24763 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str837);
          break;
        }
        case TAG_CString: {
          v_t_24763 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str838);
          break;
        }
        case TAG_CText: {
          v_t_24763 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str839);
          break;
        }
        case TAG_COwnedString: {
          v_t_24763 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str840);
          break;
        }
        case TAG_CPointer: {
          V v_t_24758 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24763 = heff_strAppend(v_t_24758, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str841));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24760 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24763 = heff_strAppend(v_t_24760, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str842));
          break;
        }
        case TAG_CVoid: {
          v_t_24763 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str843);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24764 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str844), heff_strAppend(v_t_24763, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str845)));
        V v_t_24765 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str846), heff_strAppend(v_tag_240, v_t_24764));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24765});
      }
      case TAG_CText: {
        V v_t_24772;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24766 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24772 = v_t_24766;
          break;
        }
        case TAG_CDouble: {
          v_t_24772 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str847);
          break;
        }
        case TAG_CBool: {
          v_t_24772 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str848);
          break;
        }
        case TAG_CString: {
          v_t_24772 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str849);
          break;
        }
        case TAG_CText: {
          v_t_24772 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str850);
          break;
        }
        case TAG_COwnedString: {
          v_t_24772 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str851);
          break;
        }
        case TAG_CPointer: {
          V v_t_24767 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24772 = heff_strAppend(v_t_24767, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str852));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24769 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24772 = heff_strAppend(v_t_24769, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str853));
          break;
        }
        case TAG_CVoid: {
          v_t_24772 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str854);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24773 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str855), heff_strAppend(v_t_24772, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str856)));
        V v_t_24774 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str857), heff_strAppend(v_tag_240, v_t_24773));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24774});
      }
      case TAG_COwnedString: {
        V v_t_24781;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24775 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24781 = v_t_24775;
          break;
        }
        case TAG_CDouble: {
          v_t_24781 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str858);
          break;
        }
        case TAG_CBool: {
          v_t_24781 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str859);
          break;
        }
        case TAG_CString: {
          v_t_24781 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str860);
          break;
        }
        case TAG_CText: {
          v_t_24781 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str861);
          break;
        }
        case TAG_COwnedString: {
          v_t_24781 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str862);
          break;
        }
        case TAG_CPointer: {
          V v_t_24776 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24781 = heff_strAppend(v_t_24776, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str863));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24778 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24781 = heff_strAppend(v_t_24778, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str864));
          break;
        }
        case TAG_CVoid: {
          v_t_24781 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str865);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24782 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str866), heff_strAppend(v_t_24781, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str867)));
        V v_t_24783 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str868), heff_strAppend(v_tag_240, v_t_24782));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24783});
      }
      case TAG_CPointer: {
        V v_t_24792;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24786 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24792 = v_t_24786;
          break;
        }
        case TAG_CDouble: {
          v_t_24792 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str869);
          break;
        }
        case TAG_CBool: {
          v_t_24792 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str870);
          break;
        }
        case TAG_CString: {
          v_t_24792 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str871);
          break;
        }
        case TAG_CText: {
          v_t_24792 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str872);
          break;
        }
        case TAG_COwnedString: {
          v_t_24792 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str873);
          break;
        }
        case TAG_CPointer: {
          V v_t_24787 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24792 = heff_strAppend(v_t_24787, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str874));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24789 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24792 = heff_strAppend(v_t_24789, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str875));
          break;
        }
        case TAG_CVoid: {
          v_t_24792 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str876);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24793 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str877), heff_strAppend(v_t_24792, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str878)));
        V v_t_24794 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str879), heff_strAppend(v_tag_240, v_t_24793));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24794});
      }
      case TAG_CSharedPointer: {
        V v_t_24804;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24798 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24804 = v_t_24798;
          break;
        }
        case TAG_CDouble: {
          v_t_24804 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str880);
          break;
        }
        case TAG_CBool: {
          v_t_24804 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str881);
          break;
        }
        case TAG_CString: {
          v_t_24804 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str882);
          break;
        }
        case TAG_CText: {
          v_t_24804 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str883);
          break;
        }
        case TAG_COwnedString: {
          v_t_24804 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str884);
          break;
        }
        case TAG_CPointer: {
          V v_t_24799 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24804 = heff_strAppend(v_t_24799, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str885));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24801 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24804 = heff_strAppend(v_t_24801, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str886));
          break;
        }
        case TAG_CVoid: {
          v_t_24804 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str887);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24805 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str888), heff_strAppend(v_t_24804, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str889)));
        V v_t_24806 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str890), heff_strAppend(v_tag_240, v_t_24805));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24806});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    case TAG_SFixed: {
      heff_take_n(v_t_242, 0ULL, 1);
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInteger: {
        V v_t_24815;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24809 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24815 = v_t_24809;
          break;
        }
        case TAG_CDouble: {
          v_t_24815 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str891);
          break;
        }
        case TAG_CBool: {
          v_t_24815 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str892);
          break;
        }
        case TAG_CString: {
          v_t_24815 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str893);
          break;
        }
        case TAG_CText: {
          v_t_24815 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str894);
          break;
        }
        case TAG_COwnedString: {
          v_t_24815 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str895);
          break;
        }
        case TAG_CPointer: {
          V v_t_24810 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24815 = heff_strAppend(v_t_24810, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str896));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24812 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24815 = heff_strAppend(v_t_24812, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str897));
          break;
        }
        case TAG_CVoid: {
          v_t_24815 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str898);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24816 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str899), heff_strAppend(v_t_24815, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str900)));
        V v_t_24817 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str901), heff_strAppend(v_tag_240, v_t_24816));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24817});
      }
      case TAG_CDouble: {
        V v_t_24824;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24818 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24824 = v_t_24818;
          break;
        }
        case TAG_CDouble: {
          v_t_24824 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str902);
          break;
        }
        case TAG_CBool: {
          v_t_24824 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str903);
          break;
        }
        case TAG_CString: {
          v_t_24824 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str904);
          break;
        }
        case TAG_CText: {
          v_t_24824 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str905);
          break;
        }
        case TAG_COwnedString: {
          v_t_24824 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str906);
          break;
        }
        case TAG_CPointer: {
          V v_t_24819 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24824 = heff_strAppend(v_t_24819, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str907));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24821 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24824 = heff_strAppend(v_t_24821, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str908));
          break;
        }
        case TAG_CVoid: {
          v_t_24824 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str909);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24825 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str910), heff_strAppend(v_t_24824, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str911)));
        V v_t_24826 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str912), heff_strAppend(v_tag_240, v_t_24825));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24826});
      }
      case TAG_CBool: {
        V v_t_24833;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24827 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24833 = v_t_24827;
          break;
        }
        case TAG_CDouble: {
          v_t_24833 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str913);
          break;
        }
        case TAG_CBool: {
          v_t_24833 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str914);
          break;
        }
        case TAG_CString: {
          v_t_24833 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str915);
          break;
        }
        case TAG_CText: {
          v_t_24833 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str916);
          break;
        }
        case TAG_COwnedString: {
          v_t_24833 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str917);
          break;
        }
        case TAG_CPointer: {
          V v_t_24828 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24833 = heff_strAppend(v_t_24828, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str918));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24830 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24833 = heff_strAppend(v_t_24830, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str919));
          break;
        }
        case TAG_CVoid: {
          v_t_24833 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str920);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24834 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str921), heff_strAppend(v_t_24833, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str922)));
        V v_t_24835 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str923), heff_strAppend(v_tag_240, v_t_24834));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24835});
      }
      case TAG_CString: {
        V v_t_24842;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24836 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24842 = v_t_24836;
          break;
        }
        case TAG_CDouble: {
          v_t_24842 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str924);
          break;
        }
        case TAG_CBool: {
          v_t_24842 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str925);
          break;
        }
        case TAG_CString: {
          v_t_24842 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str926);
          break;
        }
        case TAG_CText: {
          v_t_24842 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str927);
          break;
        }
        case TAG_COwnedString: {
          v_t_24842 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str928);
          break;
        }
        case TAG_CPointer: {
          V v_t_24837 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24842 = heff_strAppend(v_t_24837, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str929));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24839 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24842 = heff_strAppend(v_t_24839, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str930));
          break;
        }
        case TAG_CVoid: {
          v_t_24842 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str931);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24843 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str932), heff_strAppend(v_t_24842, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str933)));
        V v_t_24844 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str934), heff_strAppend(v_tag_240, v_t_24843));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24844});
      }
      case TAG_CText: {
        V v_t_24851;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24845 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24851 = v_t_24845;
          break;
        }
        case TAG_CDouble: {
          v_t_24851 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str935);
          break;
        }
        case TAG_CBool: {
          v_t_24851 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str936);
          break;
        }
        case TAG_CString: {
          v_t_24851 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str937);
          break;
        }
        case TAG_CText: {
          v_t_24851 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str938);
          break;
        }
        case TAG_COwnedString: {
          v_t_24851 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str939);
          break;
        }
        case TAG_CPointer: {
          V v_t_24846 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24851 = heff_strAppend(v_t_24846, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str940));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24848 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24851 = heff_strAppend(v_t_24848, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str941));
          break;
        }
        case TAG_CVoid: {
          v_t_24851 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str942);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24852 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str943), heff_strAppend(v_t_24851, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str944)));
        V v_t_24853 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str945), heff_strAppend(v_tag_240, v_t_24852));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24853});
      }
      case TAG_COwnedString: {
        V v_t_24860;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24854 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24860 = v_t_24854;
          break;
        }
        case TAG_CDouble: {
          v_t_24860 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str946);
          break;
        }
        case TAG_CBool: {
          v_t_24860 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str947);
          break;
        }
        case TAG_CString: {
          v_t_24860 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str948);
          break;
        }
        case TAG_CText: {
          v_t_24860 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str949);
          break;
        }
        case TAG_COwnedString: {
          v_t_24860 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str950);
          break;
        }
        case TAG_CPointer: {
          V v_t_24855 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24860 = heff_strAppend(v_t_24855, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str951));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24857 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24860 = heff_strAppend(v_t_24857, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str952));
          break;
        }
        case TAG_CVoid: {
          v_t_24860 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str953);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24861 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str954), heff_strAppend(v_t_24860, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str955)));
        V v_t_24862 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str956), heff_strAppend(v_tag_240, v_t_24861));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24862});
      }
      case TAG_CPointer: {
        V v_t_24871;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24865 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24871 = v_t_24865;
          break;
        }
        case TAG_CDouble: {
          v_t_24871 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str957);
          break;
        }
        case TAG_CBool: {
          v_t_24871 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str958);
          break;
        }
        case TAG_CString: {
          v_t_24871 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str959);
          break;
        }
        case TAG_CText: {
          v_t_24871 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str960);
          break;
        }
        case TAG_COwnedString: {
          v_t_24871 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str961);
          break;
        }
        case TAG_CPointer: {
          V v_t_24866 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24871 = heff_strAppend(v_t_24866, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str962));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24868 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24871 = heff_strAppend(v_t_24868, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str963));
          break;
        }
        case TAG_CVoid: {
          v_t_24871 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str964);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24872 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str965), heff_strAppend(v_t_24871, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str966)));
        V v_t_24873 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str967), heff_strAppend(v_tag_240, v_t_24872));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24873});
      }
      case TAG_CSharedPointer: {
        V v_t_24883;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_24877 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_24883 = v_t_24877;
          break;
        }
        case TAG_CDouble: {
          v_t_24883 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str968);
          break;
        }
        case TAG_CBool: {
          v_t_24883 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str969);
          break;
        }
        case TAG_CString: {
          v_t_24883 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str970);
          break;
        }
        case TAG_CText: {
          v_t_24883 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str971);
          break;
        }
        case TAG_COwnedString: {
          v_t_24883 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str972);
          break;
        }
        case TAG_CPointer: {
          V v_t_24878 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_24883 = heff_strAppend(v_t_24878, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str973));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24880 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 3);
          v_t_24883 = heff_strAppend(v_t_24880, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str974));
          break;
        }
        case TAG_CVoid: {
          v_t_24883 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str975);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_24884 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str976), heff_strAppend(v_t_24883, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str977)));
        V v_t_24885 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str978), heff_strAppend(v_tag_240, v_t_24884));
        return heff_tag_at_n(v_ru_24x2_241_24Gives, TAG_Just, 1, (V[]){v_t_24885});
      }
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        heff_drop_cell(v_ru_24x2_241_24Gives, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_c_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_GivesOrErrno: {
    V v_c_24886 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24GivesOrErrno = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_SU: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_c_24886);
      V v_t_24888 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str979), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str980)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24888});
    }
    case TAG_SDecode: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_c_24886);
      V v_t_24890 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str981), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str982)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24890});
    }
    case TAG_SFunction: {
      V v_dom_24892 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 5);
      V v_t_24902;
      switch (heff_tag_of(v_c_24886)) {
      case TAG_CInteger: {
        v_t_24902 = NTAG(TAG_False);
        break;
      }
      case TAG_CDouble: {
        v_t_24902 = NTAG(TAG_True);
        break;
      }
      case TAG_CBool: {
        v_t_24902 = NTAG(TAG_True);
        break;
      }
      case TAG_CString: {
        v_t_24902 = NTAG(TAG_False);
        break;
      }
      case TAG_CText: {
        v_t_24902 = NTAG(TAG_False);
        break;
      }
      case TAG_COwnedString: {
        v_t_24902 = NTAG(TAG_False);
        break;
      }
      case TAG_CPointer: {
        v_t_24902 = NTAG(TAG_False);
        break;
      }
      case TAG_CSharedPointer: {
        v_t_24902 = NTAG(TAG_False);
        break;
      }
      case TAG_CVoid: {
        v_t_24902 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_c_24886);
      }
      if ((heff_dup(v_t_24902) == NTAG(TAG_True))) {
        heff_drop(v_dom_24892);
        heff_drop(v_t_24902);
        V v_t_24909;
        switch (heff_tag_of(v_c_24886)) {
        case TAG_CInteger: {
          V v_t_24903 = heff_field(v_c_24886, 0);
          heff_take_n(v_c_24886, 1ULL, 1);
          v_t_24909 = v_t_24903;
          break;
        }
        case TAG_CDouble: {
          v_t_24909 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str983);
          break;
        }
        case TAG_CBool: {
          v_t_24909 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str984);
          break;
        }
        case TAG_CString: {
          v_t_24909 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str985);
          break;
        }
        case TAG_CText: {
          v_t_24909 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str986);
          break;
        }
        case TAG_COwnedString: {
          v_t_24909 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str987);
          break;
        }
        case TAG_CPointer: {
          V v_t_24904 = heff_field(v_c_24886, 0);
          heff_take_n(v_c_24886, 1ULL, 2);
          v_t_24909 = heff_strAppend(v_t_24904, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str988));
          break;
        }
        case TAG_CSharedPointer: {
          V v_t_24906 = heff_field(v_c_24886, 0);
          heff_take_n(v_c_24886, 1ULL, 3);
          v_t_24909 = heff_strAppend(v_t_24906, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str989));
          break;
        }
        case TAG_CVoid: {
          v_t_24909 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str990);
          break;
        }
        default: heff_nomatch(v_c_24886);
        }
        V v_t_24910 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str991), heff_strAppend(v_t_24909, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str992)));
        V v_t_24911 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str993), heff_strAppend(v_tag_240, v_t_24910));
        return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24911});
      } else {
        heff_drop(v_t_24902);
        HeffT2 v_t_24912 = (g_heff_2ecompile_2eglue_2erightOf_24cpr(v_dom_24892));
        {
          V v_field_24914 = v_t_24912.f[1];
          int64_t v_tag_24913 = ((int64_t)v_t_24912.f[0]);
          if ((v_tag_24913 == ((int64_t)0ULL))) {
            V v_r_24916 = v_field_24914;
            V v_t_24917 = (g_heff_2ecompile_2eglue_2efits(heff_dup(v_c_24886), v_r_24916));
            if ((heff_dup(v_t_24917) == NTAG(TAG_True))) {
              heff_drop(v_tag_240);
              heff_drop(v_c_24886);
              heff_drop_cell(v_ru_24x2_241_24GivesOrErrno, 1);
              heff_drop(v_t_24917);
              return NTAG(TAG_Nothing);
            } else {
              heff_drop(v_t_24917);
              V v_t_24924;
              switch (heff_tag_of(v_c_24886)) {
              case TAG_CInteger: {
                V v_t_24918 = heff_field(v_c_24886, 0);
                heff_take_n(v_c_24886, 1ULL, 1);
                v_t_24924 = v_t_24918;
                break;
              }
              case TAG_CDouble: {
                v_t_24924 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str994);
                break;
              }
              case TAG_CBool: {
                v_t_24924 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str995);
                break;
              }
              case TAG_CString: {
                v_t_24924 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str996);
                break;
              }
              case TAG_CText: {
                v_t_24924 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str997);
                break;
              }
              case TAG_COwnedString: {
                v_t_24924 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str998);
                break;
              }
              case TAG_CPointer: {
                V v_t_24919 = heff_field(v_c_24886, 0);
                heff_take_n(v_c_24886, 1ULL, 2);
                v_t_24924 = heff_strAppend(v_t_24919, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str999));
                break;
              }
              case TAG_CSharedPointer: {
                V v_t_24921 = heff_field(v_c_24886, 0);
                heff_take_n(v_c_24886, 1ULL, 3);
                v_t_24924 = heff_strAppend(v_t_24921, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1000));
                break;
              }
              case TAG_CVoid: {
                v_t_24924 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1001);
                break;
              }
              default: heff_nomatch(v_c_24886);
              }
              V v_t_24925 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1002), heff_strAppend(v_t_24924, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1003)));
              V v_t_24926 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1004), heff_strAppend(v_tag_240, v_t_24925));
              return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24926});
            }
          } else {
            heff_drop(v_c_24886);
            heff_drop(v_field_24914);
            V v_t_24927 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1005), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1006)));
            return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24927});
          }
        }
      }
    }
    case TAG_SRecord: {
      heff_take_n(v_t_242, 0ULL, 3);
      heff_drop(v_c_24886);
      V v_t_24931 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1007), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1008)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24931});
    }
    case TAG_SSum: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_c_24886);
      V v_t_24933 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1009), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1010)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24933});
    }
    case TAG_SIsTy: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_c_24886);
      V v_t_24935 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1011), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1012)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24935});
    }
    case TAG_SPrimInt: {
      heff_drop(v_c_24886);
      V v_t_24936 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1013), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1014)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24936});
    }
    case TAG_SPrimFloat: {
      heff_drop(v_c_24886);
      V v_t_24937 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1015), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1016)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24937});
    }
    case TAG_SPrimString: {
      heff_drop(v_c_24886);
      V v_t_24938 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1017), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1018)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24938});
    }
    case TAG_SPrimRune: {
      heff_drop(v_c_24886);
      V v_t_24939 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1019), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1020)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24939});
    }
    case TAG_SPrimArray: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_c_24886);
      V v_t_24941 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1021), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1022)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24941});
    }
    case TAG_SFixed: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_c_24886);
      V v_t_24943 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1023), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1024)));
      return heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_Just, 1, (V[]){v_t_24943});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_DoneOrErrno: {
    switch (heff_tag_of(v_t_242)) {
    case TAG_SU: {
      V v_ru_24t_242_24SU = heff_take_reuse_n(v_t_242, 0ULL, 1);
      V v_t_24945 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1025), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1026)));
      return heff_tag_at_n(v_ru_24t_242_24SU, TAG_Just, 1, (V[]){v_t_24945});
    }
    case TAG_SDecode: {
      V v_ru_24t_242_24SDecode = heff_take_reuse_n(v_t_242, 0ULL, 1);
      V v_t_24947 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1027), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1028)));
      return heff_tag_at_n(v_ru_24t_242_24SDecode, TAG_Just, 1, (V[]){v_t_24947});
    }
    case TAG_SFunction: {
      V v_dom_24949 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 5);
      HeffT2 v_t_24953 = (g_heff_2ecompile_2eglue_2erightOf_24cpr(v_dom_24949));
      {
        V v_field_24955 = v_t_24953.f[1];
        int64_t v_tag_24954 = ((int64_t)v_t_24953.f[0]);
        if ((v_tag_24954 == ((int64_t)0ULL))) {
          heff_drop(v_tag_240);
          V v_r_24957 = v_field_24955;
          heff_drop(v_r_24957);
          return NTAG(TAG_Nothing);
        } else {
          heff_drop(v_field_24955);
          V v_t_24958 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1029), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1030)));
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_24958});
        }
      }
    }
    case TAG_SRecord: {
      heff_take_n(v_t_242, 0ULL, 3);
      V v_t_24962 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1031), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1032)));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24962});
    }
    case TAG_SSum: {
      V v_ru_24t_242_24SSum = heff_take_reuse_n(v_t_242, 0ULL, 1);
      V v_t_24964 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1033), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1034)));
      return heff_tag_at_n(v_ru_24t_242_24SSum, TAG_Just, 1, (V[]){v_t_24964});
    }
    case TAG_SIsTy: {
      V v_ru_24t_242_24SIsTy = heff_take_reuse_n(v_t_242, 0ULL, 1);
      V v_t_24966 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1035), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1036)));
      return heff_tag_at_n(v_ru_24t_242_24SIsTy, TAG_Just, 1, (V[]){v_t_24966});
    }
    case TAG_SPrimInt: {
      V v_t_24967 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1037), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1038)));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24967});
    }
    case TAG_SPrimFloat: {
      V v_t_24968 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1039), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1040)));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24968});
    }
    case TAG_SPrimString: {
      V v_t_24969 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1041), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1042)));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24969});
    }
    case TAG_SPrimRune: {
      V v_t_24970 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1043), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1044)));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24970});
    }
    case TAG_SPrimArray: {
      V v_ru_24t_242_24SPrimArray = heff_take_reuse_n(v_t_242, 0ULL, 1);
      V v_t_24972 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1045), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1046)));
      return heff_tag_at_n(v_ru_24t_242_24SPrimArray, TAG_Just, 1, (V[]){v_t_24972});
    }
    case TAG_SFixed: {
      V v_ru_24t_242_24SFixed = heff_take_reuse_n(v_t_242, 0ULL, 1);
      V v_t_24974 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_str1047), heff_strAppend(v_tag_240, ((V)&g_heff_2ecompile_2eglue_2eresultBad_str1048)));
      return heff_tag_at_n(v_ru_24t_242_24SFixed, TAG_Just, 1, (V[]){v_t_24974});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eglue_2eresultBad_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2eresultBad(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str0, 13, "ffi.Described");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str2, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str3, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str4, 36, "` is not a description heff can read");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str5, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str6, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str7, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str8, 24, "` could not be evaluated");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str9, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str10, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str11, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str12, 24, "` could not be evaluated");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str13, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str14, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str15, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str16, 24, "` could not be evaluated");
V g_heff_2ecompile_2eglue_2edescribedIn_lam0(V self, V *args); static Clo g_heff_2ecompile_2eglue_2edescribedIn_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2edescribedIn_lam0, 2, 0};
Clo g_heff_2ecompile_2eglue_2edescribedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2edescribedIn_entry, 2, 0};

V g_heff_2ecompile_2eglue_2edescribedIn(V v_g_240, V v_m_241) {
top: ;
  V v_it_242 = ({ V a_0 = heff_dup(v_g_240); V a_1 = v_m_241; V b_2 = ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str0); V r_ = (g_heff_2ecompile_2eglue_2eofType(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Right, 1, (V[]){v_t_243});
  }
  case TAG_Cons: {
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_247 = (g_heff_2ecompile_2einterp_2ereachGlobals(heff_dup(v_g_240), heff_dup(g_std_2emap_2eempty_get()), heff_dup(v_it_242)));
    V v_t_248 = ({ V a_0 = v_it_242; V a_1 = v_t_247; V a_2 = v_g_240; V r_ = (g_heff_2ecompile_2einterp_2eevalReachedIn(a_0, a_1, a_2)); heff_drop_tag(v_it_242, 2); heff_drop(v_t_247); r_; });
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2edescribedIn_lam0_clo); V a_1 = heff_tag_n(TAG_Right, 1, (V[]){v_t_246}); V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2ecompile_2eglue_2edescribedIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eglue_2edescribedIn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eglue_2edescribedIn_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_p_2410 = args[1];
  switch (heff_tag_of(v_acc_249)) {
  case TAG_Left: {
    V v_why_2411 = heff_field(v_acc_249, 0);
    V v_ru_24acc_249_24Left = heff_take_reuse_n(v_acc_249, 1ULL, 1);
    heff_drop(v_p_2410);
    return heff_tag_at_n(v_ru_24acc_249_24Left, TAG_Left, 1, (V[]){v_why_2411});
  }
  case TAG_Right: {
    V v_it1_2412 = heff_field(v_acc_249, 0);
    V v_ru_24acc_249_24Right = heff_take_reuse_n(v_acc_249, 1ULL, 1);
    switch (heff_tag_of(v_it1_2412)) {
    case TAG_MkPair: {
      V v_incs_2413 = heff_field(v_it1_2412, 0);
      V v_ops_2414 = heff_field(v_it1_2412, 1);
      heff_take_n(v_it1_2412, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_p_2410)) {
      case TAG_MkPair: {
        V v_y_2416 = heff_dup(heff_field(v_p_2410, 1));
        v_t_2417 = v_y_2416;
        break;
      }
      default: heff_nomatch(v_p_2410);
      }
      switch (heff_tag_of(v_t_2417)) {
      case TAG_RSucceeded: {
        V v_v_2418 = heff_field(v_t_2417, 0);
        V v_ru_24t_2417_24RSucceeded = heff_take_reuse_n(v_t_2417, 1ULL, 1);
        HeffT2 v_t_2419 = (g_heff_2ecompile_2eglue_2ereadDescribed_24cpr(v_v_2418));
        {
          V v_field_2421 = v_t_2419.f[1];
          int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
          if ((v_tag_2420 == ((int64_t)0ULL))) {
            heff_drop(v_p_2410);
            heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
            V v_it1_2423 = v_field_2421;
            switch (heff_tag_of(v_it1_2423)) {
            case TAG_MkPair: {
              V v_is_2424 = heff_field(v_it1_2423, 0);
              V v_os_2425 = heff_field(v_it1_2423, 1);
              heff_take_n(v_it1_2423, 3ULL, 2);
              V v_t_2426 = (g_heff_2ecompile_2eglue_2eappendF(v_incs_2413, v_is_2424));
              V v_t_2427 = (g_heff_2ecompile_2eglue_2eappendF(v_ops_2414, v_os_2425));
              return heff_tag_at_n(v_ru_24acc_249_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_t_2427})});
            }
            default: return heff_nomatch(v_it1_2423);
            }
          } else {
            heff_drop_cell(v_ru_24acc_249_24Right, 1);
            heff_drop(v_incs_2413);
            heff_drop(v_ops_2414);
            heff_drop(v_field_2421);
            V v_k_2430;
            switch (heff_tag_of(v_p_2410)) {
            case TAG_MkPair: {
              V v_x_2428 = heff_field(v_p_2410, 0);
              heff_take_n(v_p_2410, 1ULL, 2);
              v_k_2430 = v_x_2428;
              break;
            }
            default: heff_nomatch(v_p_2410);
            }
            V v_t_2431 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str1); V a_1 = v_k_2430; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str2), v_k_2430, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
            V v_t_2432 = ({ V a_0 = v_k_2430; V a_1 = v_t_2431; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2431); r_; });
            V v_t_2433 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str3), heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str4)));
            return heff_tag_at_n(v_ru_24t_2417_24RSucceeded, TAG_Left, 1, (V[]){v_t_2433});
          }
        }
      }
      case TAG_RAbandoned: {
        heff_drop_cell(v_ru_24acc_249_24Right, 1);
        heff_drop(v_incs_2413);
        heff_drop(v_ops_2414);
        V v_k_2436;
        switch (heff_tag_of(v_p_2410)) {
        case TAG_MkPair: {
          V v_x_2434 = heff_field(v_p_2410, 0);
          heff_take_n(v_p_2410, 1ULL, 2);
          v_k_2436 = v_x_2434;
          break;
        }
        default: heff_nomatch(v_p_2410);
        }
        V v_t_2437 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str5); V a_1 = v_k_2436; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str6), v_k_2436, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_t_2438 = ({ V a_0 = v_k_2436; V a_1 = v_t_2437; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2437); r_; });
        V v_t_2439 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str7), heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str8)));
        return heff_tag_n(TAG_Left, 1, (V[]){v_t_2439});
      }
      case TAG_RDiverged: {
        heff_drop_cell(v_ru_24acc_249_24Right, 1);
        heff_drop(v_incs_2413);
        heff_drop(v_ops_2414);
        V v_k_2442;
        switch (heff_tag_of(v_p_2410)) {
        case TAG_MkPair: {
          V v_x_2440 = heff_field(v_p_2410, 0);
          heff_take_n(v_p_2410, 1ULL, 2);
          v_k_2442 = v_x_2440;
          break;
        }
        default: heff_nomatch(v_p_2410);
        }
        V v_t_2443 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str9); V a_1 = v_k_2442; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str10), v_k_2442, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_t_2444 = ({ V a_0 = v_k_2442; V a_1 = v_t_2443; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2443); r_; });
        V v_t_2445 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str11), heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str12)));
        return heff_tag_n(TAG_Left, 1, (V[]){v_t_2445});
      }
      case TAG_RBug: {
        V v_ru_24t_2417_24RBug = heff_take_reuse_n(v_t_2417, 0ULL, 1);
        heff_drop_cell(v_ru_24acc_249_24Right, 1);
        heff_drop(v_incs_2413);
        heff_drop(v_ops_2414);
        V v_k_2449;
        switch (heff_tag_of(v_p_2410)) {
        case TAG_MkPair: {
          V v_x_2447 = heff_field(v_p_2410, 0);
          heff_take_n(v_p_2410, 1ULL, 2);
          v_k_2449 = v_x_2447;
          break;
        }
        default: heff_nomatch(v_p_2410);
        }
        V v_t_2450 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str13); V a_1 = v_k_2449; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str14), v_k_2449, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_t_2451 = ({ V a_0 = v_k_2449; V a_1 = v_t_2450; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2450); r_; });
        V v_t_2452 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str15), heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str16)));
        return heff_tag_at_n(v_ru_24t_2417_24RBug, TAG_Left, 1, (V[]){v_t_2452});
      }
      default: return heff_nomatch(v_t_2417);
      }
    }
    default: return heff_nomatch(v_it1_2412);
    }
  }
  default: return heff_nomatch(v_acc_249);
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str3, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str4, 11, "co.HFunctor");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str5, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str6, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str8, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str9, 38, "` is not an operation of an effect of ");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str10, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str11, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str12, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str13, 19, "the operations of `");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str14, 46, "` cannot be read: not an effect of a data type");
V g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2eglue_2ebindingsOf_24cpr(V v_g_240, V v_k_241, V v_ops_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2eglue_2eoperationsOf_24cpr(heff_dup(v_g_240), v_k_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_vs_247 = v_field_245;
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ops_242));
      V v_t_2449 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam0, 2, 3, (V[]){v_vs_247, v_k_241, v_g_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
      return (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2449));
    } else {
      heff_drop(v_g_240);
      heff_drop(v_ops_242);
      heff_drop(v_field_245);
      V v_t_2450 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str11); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str12), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2451 = ({ V a_0 = v_k_241; V a_1 = v_t_2450; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2450); r_; });
      V v_f_2452 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str13), heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str14)));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2452}});
    }
  }
}
V g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam1(V self, V *args) {
  V v_k_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2428 = ({ V a_0 = v_g_240; V a_1 = v_k_2427; HeffT2 r_ = (g_heff_2ecompile_2eglue_2eoperationsOf_24cpr(a_0, a_1)); heff_drop(v_k_2427); r_; });
  {
    V v_field_2430 = v_t_2428.f[1];
    int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
    if ((v_tag_2429 == ((int64_t)0ULL))) {
      V v_vs_2432 = v_field_2430;
      HeffT2 v_t_2433 = ({ V b_0 = heff_get_n(v_vs_2432, 1, 3); V b_1 = heff_get_n(v_x_2410, 0, 4); HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
      {
        V v_field_2435 = v_t_2433.f[1];
        int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
        V v_ret_24bool = heff_bool(((v_tag_2434 == ((int64_t)0ULL)) && ({ V v_x_2437 = heff_dup(v_field_2435); int c_ = 1; heff_drop(v_x_2437); c_; })));
        heff_drop(v_field_2435);
        return v_ret_24bool;
      }
    } else {
      heff_drop_rec(v_x_2410, 4);
      heff_drop(v_field_2430);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_vs_247 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_vs_247, 1), heff_rfield(v_x_2410, 0)));
  V v_t_2420;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_i_2415 = v_field_2413;
      V v_xs_2416 = heff_get_n(v_vs_247, 2, 3);
      if (heff_intLe_c_lent(MK_INT(0LL), v_i_2415, 1)) {
        if (heff_intLt_c(heff_dup(v_i_2415), heff_arrayLength_lent(v_xs_2416, 0))) {
          V v_t_2419 = heff_arrayIndex(v_xs_2416, v_i_2415);
          v_t_2420 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2419});
        } else {
          heff_drop(v_i_2415);
          heff_drop(v_xs_2416);
          v_t_2420 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_i_2415);
        heff_drop(v_xs_2416);
        v_t_2420 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop_rec(v_vs_247, 3);
      heff_drop(v_field_2413);
      v_t_2420 = NTAG(TAG_Nothing);
    }
  }
  V v_t_2448;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Nothing: {
    V v_t_2421 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str0); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str1), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_2422 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2421));
    V v_m_2425;
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      v_m_2425 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      v_m_2425 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str3); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2422);
    }
    V v_t_2426 = ({ V a_0 = heff_dup(v_g_240); V a_1 = v_m_2425; V b_2 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str4); V r_ = (g_heff_2ecompile_2eglue_2eofType(a_0, a_1, b_2)); heff_drop(v_m_2425); heff_drop(b_2); r_; });
    V v_t_2438 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam1, 1, 2, (V[]){v_g_240, heff_dup(v_x_2410)}); V a_1 = v_t_2426; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2426); r_; });
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2410, 4);
      heff_drop(v_k_241);
      heff_drop(v_t_2438);
      v_t_2448 = NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_2438);
      V v_t_2439 = ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str5); V a_1 = v_k_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str6), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_k_241); r_; });
      V v_x2_2440 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2439));
      V v_t_2443;
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_Nil: {
        v_t_2443 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_xs_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        v_t_2443 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str8); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2440);
      }
      V v_t_2444 = heff_strAppend(heff_get_n(v_x_2410, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str9), v_t_2443));
      V v_t_2445 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str10), v_t_2444)});
      v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
    }
    break;
  }
  case TAG_Just: {
    V v_fields_2446 = heff_field(v_t_2420, 0);
    heff_take_n(v_t_2420, 1ULL, 1);
    heff_drop(v_k_241);
    heff_drop(v_g_240);
    V v_t_2447 = (g_heff_2ecompile_2eglue_2ebindingOf(v_x_2410, v_fields_2446));
    v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  return (g_prelude_2e_2b_2b(v_t_2448, v_acc_249));
}